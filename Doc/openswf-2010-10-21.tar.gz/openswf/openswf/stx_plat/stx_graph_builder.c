/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/
#include "stdio.h"
#include "stdlib.h"
#include "fcntl.h"
#include "malloc.h"
#include "memory.h"
#include "string.h"

#include "stx_mem.h"
#include "stx_debug.h"
#include "stx_mutex.h"
#include "stx_gid_def.h"
#include "stx_module_reg.h"
#include "stx_graph_builder.h"
#include "stx_filter_graph.h"
#include "stx_gid_def.h"
#include "stx_thread.h"
#include "stx_connect_ctx.h"

#include "stx_sync_source.h"
#include "stx_heap.h"
#include "stx_message.h"

#include "stx_dll.h"

#include "stx_prop_def.h"


#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif


/***********************************************************************************
***********************************************************************************/
STREAM_TYPE_MAP_BEGIN(g_default_streams)
/**/STREAM_TYPE_MAP_ITEM(MEDIATYPE_Stream,MEDIASUBTYPE_FLV,"flv")
/**/STREAM_TYPE_MAP_ITEM(MEDIATYPE_Stream,MEDIASUBTYPE_MP4,"mp4,qt,mov,ipod,3gp,f4v")
STREAM_TYPE_MAP_END()




STX_INTERF(stx_module_ctx);
struct stx_module_ctx {
	s32					i_filter_num;
	stx_gid*			cls_gid;
	stx_dll*			h_stx_dll;
	char*				sz_path;
	stx_base_module*	h_module;
	s32                 i_ref;
};

STX_INTERF(stx_filter_user_data);
struct stx_filter_user_data{
	stx_module_ctx*			h_modctx;
	stx_gid					stx_uuid;
	stx_filter_user_data*	p_next;

	// instance pointer;
	base_graph_builder*     g_gbd;
	STX_HANDLE				h_com;

	_STX_PURE STX_RESULT (*query_interf)( STX_HANDLE h, stx_gid gid, STX_HANDLE* p_interf );
	_STX_PURE s32		 (*add_ref)( STX_HANDLE h );
	_STX_PURE s32		 (*release)( STX_HANDLE h );
};


#define STX_MAX_MODULE 128



STX_PURE s32				filter_release(STX_HANDLE h);
STX_PURE STX_RESULT			filter_query_interf(STX_HANDLE h,stx_gid iid,STX_HANDLE* h_interf);
STX_PURE s32				filter_add_ref( STX_HANDLE h );

#define stx_module_lock(a)		stx_waitfor_mutex(a, INFINITE )
#define stx_module_unlock(a)	stx_release_mutex(a )

//#define TRACE_STX_ADDREF



STX_API_IMP
CREATE_STX_COM(stx_base_graph_builder,STX_IID_GraphBuilder,base_graph_builder);



char* g_szStreamX_BaseGraphBuilder = "StreamX GraphBuilder filter";

STX_INTERF(ssrc_elem);

struct ssrc_elem{
	stx_sync_source* ssrc;
	stxHeapElem       elem;
};


STX_COM_BEGIN(base_graph_builder);
/**/
/**/STX_PUBLIC(stx_base_graph_builder)
/**/STX_COM_DATA_DEFAULT(stx_base_graph_builder)
/**/
/**/s32						i_ssrc;
/**/u8**					pp_ssrc_buf;
/**/stx_sync_source**		hh_ssrc;
/**/ssrc_elem**             hh_elem;
/**/
/**/stx_filter_user_data*	p_first_udat;
/**/s32						g_iModuleNum;
/**/s32						g_iMaxModuleNum;
/**/stx_module_ctx**		g_pStxModule;
/**/STX_HANDLE				g_hMutex;
/**/u32						g_i_debug;
/**/s32						i_dlib;
/**/stx_module_ctx**		hh_dlib;
/**/
STX_COM_END();


// pay attention: only can see the g_gbd at this file scope;
//STX_PRIVATE base_graph_builder* g_gbd;


STX_COM_FUNC_DECL_DEFAULT(stx_base_graph_builder,stx_base_graph_builder_vt);
STX_COM_FUNCIMP_DEFAULT(base_graph_builder,stx_base_graph_builder,stx_base_graph_builder_vt);



/*{{{STX_MSG_ENTRY_DECLARE**************************************************/
/* to do : add msg proc entry  declaration here; */
//STX_MSG_ENTRY_DECLARE(on_set_err_hnd)
STX_MSG_ENTRY_DECLARE(on_unregister_module)

/*}}}***********************************************************************/


/*{{{STX_BEGIN_MSG_MAP******************************************************/
STX_BEGIN_MSG_MAP(the_msg_data)
/* to do : add msg proc entry name here; */
/**/ON_STX_MSG(STX_MSG_UnregModule,on_unregister_module)
STX_END_MSG_MAP
/*}}}***********************************************************************/


/*{{{STX_BEGIN_MSG_RESPONSE_MAP*********************************************/
STX_BEGIN_MSG_RESPONSE_MAP(the_msg_response)
/* to do : add msg process entry name here; */
STX_END_MSG_RESPONSE_MAP
/*}}}***********************************************************************/


/*{{{STX_DISPATHCH_MSG_PROC*************************************************/
STX_DISPATCH_MSG_PROC( dispatch_msg,the_msg_data )
/*}}}***********************************************************************/


/*{{{STX_RESPONSE_MSG_PROC**************************************************/
STX_RESPONSE_MSG_PROC( response_msg,the_msg_response )
/*}}}***********************************************************************/

/*}}}async_plugin inherit block; ***********************************************/

STX_PURE STX_RESULT stx_co_query_obj(THEE h, stx_gid cls_gid ,  char** sz_dll_path );
STX_PURE STX_RESULT stx_co_create_obj(THEE h, stx_gid cls_gid ,  stx_base_com** pp_com );
STX_PURE STX_RESULT stx_co_create_obj_svr
(
	THEE h, 
	stx_gid cls_gid , 
	char* sz_svr, 
	stx_base_com** pp_com 
);
STX_PURE STX_RESULT	stx_get_svr_inf(THEE h, char* sz_svr, stx_xini* h_xini );
STX_PURE STX_RESULT	stx_get_filter_inf(THEE h, stx_base_filter* p_flt, stx_xini* h_xini );
STX_PURE STX_RESULT	stx_reg_svr(THEE h, char* sz_svr );
STX_PURE STX_RESULT stx_unreg_svr(THEE h, char* sz_svr );
STX_PURE STX_RESULT	stx_reg_protocol(THEE h, char* sz_svr );
STX_PURE STX_RESULT stx_unreg_protocol(THEE h, char* sz_svr );
STX_PURE STX_RESULT	stx_reg_dlib(THEE h, char* sz_svr );
STX_PURE STX_RESULT stx_unreg_dlib(THEE h, char* sz_svr );
STX_PURE void		stx_unregister_module_as(THEE h,THEE h_dat);
STX_PURE STX_RESULT	stx_reg_query_input_type
( 
	THEE h,
	stx_gid				major_type, 
	stx_gid				sub_type,
	stx_connect_ctx*	p_con_ctx 
);
STX_PURE STX_RESULT	stx_reg_query_src_ext
( 
	THEE h,
	char*				sz_ext, 
	stx_connect_ctx*	p_con_ctx 
);
STX_PURE STX_RESULT	stx_reg_query_src_type
( 
	THEE h,
	stx_gid				major_type,
	stx_gid				sub_type,
	stx_connect_ctx*	p_con_ctx 
);
STX_PURE STX_RESULT	stx_reg_query_ren_type
( 
	THEE h,
	stx_gid				major_type,
	stx_gid				sub_type,
	stx_connect_ctx*	p_con_ctx 
);
STX_PURE STX_RESULT	stx_reg_query_cat_desc
( 
	THEE h,
	stx_gid				cat_gid,
	char*				sz_cat_desc,
	stx_connect_ctx*	p_con_ctx 
);
STX_PURE STX_RESULT	stx_reg_query_flt_type
( 
	THEE h,
	stx_gid				major_type_in,
	stx_gid				sub_type_in,
	stx_gid				major_type_out,
	stx_gid				sub_type_out,
	stx_connect_ctx*	p_con_ctx 
);
STX_PURE STX_RESULT  stx_reg_stream(THEE h,stx_reg_stream_ctx* h_stream);
STX_PURE STX_RESULT  stx_unreg_stream(THEE h,stx_reg_stream_ctx* h_stream);
/***********************************************************************************
stx_reg_find_ctx
parameters struct used in STX_PURE
stx_reg_find_class
stx_reg_find_next
stx_reg_find_close
**********************************************************************************/
STX_PURE STX_RESULT		stx_reg_find_class(	THEE h,stx_reg_find_ctx* h_find_ctx,STX_HANDLE* h_find);
STX_PURE STX_RESULT		stx_reg_find_next(	THEE h,stx_reg_find_ctx* h_find_ctx,STX_HANDLE h_find);
STX_PURE void			stx_reg_find_close(	THEE h,STX_HANDLE h_find);
STX_PURE STX_RESULT		stx_reg_stream_default(THEE h);
STX_PURE STX_RESULT		stx_unreg_stream_default(THEE h);

STX_PURE stx_thread*	stx_get_cur_thread(THEE h);
STX_PURE STX_RESULT		stx_set_main_data(THEE h,THEE h_module,THEE h_dat);
STX_PURE THEE			stx_get_main_data(THEE h,THEE h_module);


STX_PRIVATE STX_RESULT		stx_co_query_obj_internal(stx_gid cls_gid ,  char** sz_dll_path );
STX_PRIVATE void			stx_module_ctx_close(stx_module_ctx* p);

STX_PRIVATE STX_RESULT		stx_filter_overload
(
	base_graph_builder* the,
	stx_base_com*		p_obj,
	stx_module_ctx*		p_module
);
STX_PRIVATE STX_RESULT		stx_module_reg(	base_graph_builder* the,stx_module_ctx* p_ctx );
STX_PRIVATE STX_RESULT		stx_module_unreg(base_graph_builder* the,stx_module_ctx* p_ctx );
STX_PRIVATE STX_RESULT		stx_module_query
(
	base_graph_builder* the,
	stx_gid cls_gid, 
	stx_module_ctx** p_ctx 
);
STX_PRIVATE STX_RESULT		stx_module_query_by_path
( 
	base_graph_builder* the,
	char* sz_path, 
	stx_module_ctx** p_ctx 
);
STX_PRIVATE void			stx_module_clear(base_graph_builder* the);


STX_PRIVATE STX_RESULT gbd_connect_internal
(
	base_graph_builder*			the, 
	stx_gid						major_type, 
	stx_gid						sub_type,
	stx_base_pin*				p_in, 
	stx_connect_ctx*			p_connect_ctx
);


STX_PRIVATE STX_RESULT gbd_rend_internal
(
	base_graph_builder*			the, 
	stx_gid						major_type, 
	stx_gid						sub_type,
	stx_connect_ctx*			p_connect_ctx
);


STX_PRIVATE STX_RESULT gdb_rend_render
(
	STX_HANDLE					h,
	stx_base_pin*				p_out 
);


STX_PRIVATE STX_RESULT	gbd_config(base_graph_builder* the);

STX_PRIVATE STX_RESULT	load_dlib(base_graph_builder* the);
STX_PRIVATE void		close_dlib(base_graph_builder* the);

/***************************************************************************
stx_base_graph_builder_create
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_COM_MAP_BEGIN(base_graph_builder)
/**/STX_COM_MAP_ITEM(STX_IID_GraphBuilder)
STX_COM_MAP_END()

STX_API_IMP STX_NEW_BEGIN(base_graph_builder)
{
	STX_RESULT		i_err;

	i_err = STX_FAIL;

	STX_SET_THE(stx_base_graph_builder);
	STX_COM_NEW_DEFAULT(
		stx_base_graph_builder,
		the->stx_base_graph_builder_vt,
		stx_base_graph_builder_vt,
		STX_CLSID_BaseGraphBuilder,
		STX_CATEGORY_GraphBuilder,
		g_szStreamX_BaseGraphBuilder);

#define LOAD_CALLBACK(a) the->stx_base_graph_builder_vt.a = stx_ ## a
	LOAD_CALLBACK(co_query_obj);
	LOAD_CALLBACK(co_create_obj);
	LOAD_CALLBACK(co_create_obj_svr);
	LOAD_CALLBACK(get_svr_inf);
	LOAD_CALLBACK(get_filter_inf);
	LOAD_CALLBACK(reg_svr);
	LOAD_CALLBACK(unreg_svr);
	LOAD_CALLBACK(reg_protocol);
	LOAD_CALLBACK(unreg_protocol);
	LOAD_CALLBACK(unregister_module_as);
	LOAD_CALLBACK(reg_query_input_type);
	LOAD_CALLBACK(reg_query_src_ext);
	LOAD_CALLBACK(reg_query_src_type);
	LOAD_CALLBACK(reg_query_ren_type);
	LOAD_CALLBACK(reg_query_cat_desc);
	LOAD_CALLBACK(reg_query_flt_type);
	LOAD_CALLBACK(reg_stream);
	LOAD_CALLBACK(unreg_stream);
	LOAD_CALLBACK(reg_find_class);
	LOAD_CALLBACK(reg_find_next); 
	LOAD_CALLBACK(reg_find_close);
	LOAD_CALLBACK(reg_stream_default);
	LOAD_CALLBACK(unreg_stream_default);
	LOAD_CALLBACK(get_cur_thread);
	LOAD_CALLBACK(set_main_data);
	LOAD_CALLBACK(get_main_data);
	LOAD_CALLBACK(reg_dlib);
	LOAD_CALLBACK(unreg_dlib);
#undef LOAD_CALLBACK

	the->stx_base_graph_builder_vt.create_thread = stx_thread_init;
	the->stx_base_graph_builder_vt.close_thread = stx_thread_destory;


	if( STX_OK != gbd_config(the) ) {
		break;
	}

	the->g_hMutex = stx_create_mutex( STX_NULL, 0, STX_NULL );
	if( !the->g_hMutex ) {
		break;
	}

	the->g_i_debug = g_i_debug & (STX_TRACE_CONSOLE | STX_TRACE_WINDOW);

	the->g_iModuleNum = 0;

	the->g_iMaxModuleNum = STX_MAX_MODULE;

	the->g_pStxModule = (stx_module_ctx**)xmallocz(sizeof(stx_module_ctx*)*the->g_iMaxModuleNum);
	if( !the->g_pStxModule ) {
		break;
	}

	// config ssrc;
	{
		s32 i;

		if( !the->i_ssrc ) {
			s32 i_cpu = stx_get_cpu_num();
			the->i_ssrc = i_cpu < 2 ? i_cpu + 1 : i_cpu;
		}

		the->pp_ssrc_buf = (u8**)xmallocz( the->i_ssrc * sizeof( u8* ));
		if( !the->pp_ssrc_buf ) {
			break;
		}

		the->hh_ssrc = (stx_sync_source**)xmallocz(the->i_ssrc * sizeof( STX_HANDLE ));
		if( !the->hh_ssrc ) {
			break;
		}

		the->hh_elem = (ssrc_elem**)xmallocz(the->i_ssrc * sizeof( STX_HANDLE ));
		if( !the->hh_elem ) {
			break;
		}

		for( i = 0; i < the->i_ssrc; i ++ ) {

			stx_base_com*	p;
			u8*				h_inst;

			the->pp_ssrc_buf[i] = (u8*)xmallocz(STX_COM_SIZE(sync_source) + sizeof( STX_HANDLE ));

			if( !the->pp_ssrc_buf[i] ) {
				break;
			}

			*(STX_HANDLE*)the->pp_ssrc_buf[i] = (STX_HANDLE)&the->stx_base_graph_builder_vt;

			h_inst = the->pp_ssrc_buf[i] + sizeof(STX_HANDLE);

			p = XNEW(sync_source,h_inst);
			if( !p ) {
				i_err = STX_FAIL;
				break;
			}

			i_err = p->query_interf(p,STX_IID_SyncSource,(void**)&the->hh_ssrc[i] );
			SAFE_XDELETE(p);
			if( STX_OK != i_err ) {
				i_err = STX_FAIL;
				break;
			}

			the->hh_elem[i] = (ssrc_elem*)xmallocz(sizeof( ssrc_elem ));
			if( !the->hh_elem[i] ) {
				i_err = STX_FAIL;
				break;
			}
			the->hh_elem[i]->ssrc = the->hh_ssrc[i];

		} // for( i = 0; i < the->i_ssrc; i ++ ) {

		if( STX_OK != i_err ) {
			break;
		}

	}// config ssrc;

}
STX_NEW_END()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_DELETE_BEGIN(base_graph_builder )
{
	s32 i;

	if( the->g_pStxModule ) {
		for( i = 0; i < the->g_iModuleNum ; i ++ ) {
			stx_module_ctx_close(the->g_pStxModule[i]);
		}
		stx_free(the->g_pStxModule);
	}

	if( the->g_hMutex ) {
		stx_close_mutex( the->g_hMutex );
	}

	if( the->hh_ssrc ) {
		for( i = 0; i < the->i_ssrc; i ++ ) {
			SAFE_XDELETE(the->hh_ssrc[i]);
		}
		stx_free( the->hh_ssrc );
	}

	if( the->pp_ssrc_buf ) {
		for( i = 0; i < the->i_ssrc; i ++ ) {
			if( the->pp_ssrc_buf[i] ) {
				stx_free(the->pp_ssrc_buf[i]);
			}
		}
		stx_free( the->pp_ssrc_buf );
	}

	if( the->hh_elem ) {
		for( i = 0; i < the->i_ssrc; i ++ ) {
			if( the->hh_elem[i] ) {
				stx_free(the->hh_elem[i]);
			}
		}
		stx_free( the->hh_elem );
	}


	STX_COM_DELETE_DEFAULT(stx_base_graph_builder);

}
STX_DELETE_END
(
STX_COM_DELETE_BEGIN(stx_base_graph_builder)
,
STX_COM_DELETE_END(stx_base_graph_builder)
)



/**************************************************************************
query_interf
RETURN VALUE: success , is STX_OK; or return STX_ERR_INVALID_PARAM;
INPUT: gid, the class guid;
OUTPUT: p_interf, address of the object pointer;
NOTE: we always return the stx_base_com based interface;
*************************************************************************/
STX_API_IMP	STX_QUERY_BEGIN(base_graph_builder)
{
     STX_COM_QUERY_DEFAULT(stx_base_graph_builder,the->stx_base_graph_builder_vt);
}
STX_QUERY_END()





/***************************************************************************
send_msg
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
overloaded function, simply to call the base class routine;
***************************************************************************/
STX_PURE STX_RESULT	stx_base_graph_builder_vt_plug_xxx_send_msg
( STX_HANDLE h, stx_base_message* p_msg )
{
	STX_RESULT i_err;
	STX_MAP_THE(base_graph_builder);

	i_err = dispatch_msg(h,p_msg);
	if(i_err < 0 || p_msg->is_msg_closed(p_msg) ) {
		return i_err;
	}
	{
		u32 i_type = p_msg->get_msg_type(p_msg);
		if( i_type & STX_MSG_TYPE_UPSTREAM ) {
			if( !the->p_parent ) {
				return STX_ERR_OBJ_UNINIT;
			}
			i_err = the->p_parent->send_msg(the->p_parent,p_msg);
			if(i_err < 0 || p_msg->is_msg_closed(p_msg) ) {
				return i_err;
			}
		}
	}
	i_err = response_msg(h,p_msg);

	return i_err;
}

/***************************************************************************
RETURN VALUE: 
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_graph_builder_vt_plug_xxx_flush
(STX_HANDLE h,u32 i_flag,stx_sync_inf *h_sync)
{
	return STX_OK;
}

/***************************************************************************
RETURN VALUE: 
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_graph_builder_vt_plug_xxx_start
(STX_HANDLE h,u32 i_flag,stx_sync_inf *h_sync)
{
	s32					i,j;
	STX_RESULT			i_err;

	stx_base_message*	p_msg;

	STX_MAP_THE(base_graph_builder);


	if( STX_OK != load_dlib(the) ) {
		return STX_FAIL;
	}

	p_msg = XCREATE(base_msg,NULL,NULL);
	if( !p_msg ) {
		return STX_FAIL;
	}

	do{

		p_msg->set_msg_type(p_msg,STX_MSG_TYPE_DIRECT);
		p_msg->set_msg_dest(p_msg,STX_CLSID_SyncSource);
		p_msg->get_msg_cnt(p_msg)->msg_gid = STX_MSG_AsPlay;

		for( i = 0; i < the->i_ssrc; i ++ ) {

			i_err = the->hh_ssrc[i]->send_msg(the->hh_ssrc[i],p_msg);
			if( i_err < 0 ) {
				break;
			}

		}// for( i = 0; i < the->i_ssrc; i ++ ) {

		if( i_err < 0 ) {
			break;
		}

		j = 0;

		while( j < the->i_ssrc ) {

			stx_sleep(10);

			j = 0;

			for( i = 0; i < the->i_ssrc; i ++ ) {
				if( XCALL(is_started,the->hh_ssrc[i]) ) {
					j ++;
				}
			}
		}

		if( i_err < 0 ) {
			break;
		}

		i_err = STX_OK;

	}while(FALSE);

	SAFE_XDELETE(p_msg);

	return i_err;
}


/***************************************************************************
RETURN VALUE: 
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_graph_builder_vt_plug_xxx_stop
(STX_HANDLE h,u32 i_flag,stx_sync_inf *h_sync)
{

	s32					i;
	STX_RESULT			i_err;

	stx_base_message*	p_msg;

	STX_MAP_THE(base_graph_builder);

	p_msg = XCREATE(base_msg,NULL,NULL);
	if( !p_msg ) {
		return STX_FAIL;
	}

	do{

		u32 const utype = STX_MSG_TYPE_BLOCK | STX_MSG_TYPE_ASYNC;
		p_msg->set_msg_type(p_msg,utype );
		p_msg->set_msg_dest(p_msg,STX_CLSID_SyncSource);
		p_msg->get_msg_cnt(p_msg)->msg_gid = STX_MSG_AsStop;

		for( i = 0; i < the->i_ssrc; i ++ ) {

			i_err = the->hh_ssrc[i]->send_msg(the->hh_ssrc[i],p_msg);
			if( i_err < 0 ) {
				break;
			}
		}// for( i = 0; i < the->i_ssrc; i ++ ) {

		if( i_err < 0 ) {
			break;
		}

		i_err = STX_OK;

	}while(FALSE);

	SAFE_XDELETE(p_msg);

	close_dlib(the);

	return i_err;
}

/***************************************************************************
RETURN VALUE: 
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_graph_builder_vt_plug_xxx_run
(STX_HANDLE h,stx_sync_inf* h_sync )
{
	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_graph_builder_vt_xxx_enum_ssrc
(THEE h,s32* i_idx,stx_sync_source** hh)
{
	STX_MAP_THE(base_graph_builder);

	if( !i_idx ) {
		return STX_ERR_INVALID_PARAM;
	}

	if( !hh ) {
		*i_idx = the->i_ssrc;
		return STX_OK;
	}

	if( *i_idx >= 0 && *i_idx < the->i_ssrc ) {
		XCALL(add_ref,the->hh_ssrc[*i_idx]);
		*hh = the->hh_ssrc[*i_idx];
		return STX_OK;
	}

	return STX_ERR_INVALID_PARAM;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
stx_inline stx_sync_source* find_min_ssrc
(base_graph_builder* the,stx_sync_source *h_ori,stx_sync_source **hh_alloc,s32 n)
{
	s32					j,k,m;
	stx_sync_source*	ssrc;
	u32					i_occupy;
	u32					t;

	i_occupy = (1000*10000) + 9999;
	k = the->i_ssrc;

	for( j = 0; j < the->i_ssrc; j ++ ){

		ssrc = the->hh_ssrc[j];
		t = (ssrc->get_occupy(ssrc)*10000) + ssrc->get_task_num(ssrc);

		//stx_log("ssrc idx = %d, occupy = %d \r\n",j,t);

		if( t <= i_occupy && h_ori != ssrc ) {
			for( m = 0; m < n; m ++ ) {
				if( hh_alloc[m] == ssrc) {
					goto skip_ssrc;
				}
			}
			i_occupy = t;
			k = j;
		} //if( t < i_occupy ) { 
skip_ssrc:
		continue;
	} // for( j = 0; j < the->i_ssrc; j ++ ){

	if( k == the->i_ssrc ){
		return NULL;
	}

	//stx_log("allocated ssrc idx = %d, occupy = %d \r\n",k,i_occupy);

	return the->hh_ssrc[k];
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_graph_builder_vt_xxx_alloc_ssrc
(STX_HANDLE h,b32 b_cpu,stx_sync_source *h_ori,s32 i_ssrc,stx_sync_source* hh_alloc[] )
{
	s32					i,j;
	stx_sync_source*	ssrc;

	STX_MAP_THE(base_graph_builder);

	stx_module_lock(the->g_hMutex);

	if( b_cpu ) {
		i = 0;
		for( j = 0; j < i_ssrc; j++  ) {
			ssrc = the->hh_ssrc[i++];
			if( i >= the->i_ssrc ) {
				i = 0;
			}
			ssrc->add_ref(ssrc);
			hh_alloc[j] = ssrc;
		}
	}
	else {
		for( i = 0; i < i_ssrc; i ++ ) {
			ssrc = find_min_ssrc(the,h_ori,hh_alloc,i);
			if( !ssrc ){
				ssrc = find_min_ssrc(the,NULL,hh_alloc,i);
			}
			assert(ssrc);
			hh_alloc[i] = ssrc;
			ssrc->add_ref(ssrc);
		}// for( i = 0; i < i_ssrc; i ++ ) {
	}

	stx_module_unlock(the->g_hMutex);

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE u32 
stx_base_graph_builder_vt_xxx_get_occupy(STX_HANDLE h)
{
	STX_MAP_THE(base_graph_builder);
	{
		s32 i;
		s32 i_occupy;
		
		i_occupy = 0;

		for( i = 0; i < the->i_ssrc; i ++ ) {

			u32 i_val = the->hh_ssrc[i]->get_occupy(the->hh_ssrc[i]);
			i_occupy += i_val;
			//stx_log("get_occupy = %d\r\n",i_val);
		}

		return i_occupy / the->i_ssrc;
	}

}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE s32 
stx_base_graph_builder_vt_xxx_get_max_subtask(STX_HANDLE h)
{
	STX_MAP_THE(base_graph_builder);

	return the->i_ssrc;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static STX_RESULT stx_base_graph_builder_vt_xxx_create_graph
(STX_HANDLE h,stx_base_graph **hh_graph)
{
	STX_RESULT				i_err;
	stx_sync_source*		ssrc;
	stx_base_graph_builder* h_gbd;
	stx_base_graph*			h_gph;

	STX_MAP_THE(base_graph_builder);

	i_err = STX_FAIL;
	h_gbd = (stx_base_graph_builder*)h;
	h_gph = NULL;

	do{

		h_gph = XCREATE(base_graph,NULL);
		if( !h_gph ) {
			break;
		}
		h_gph->set_gbd(h_gph,h_gbd);
		h_gbd->add_ref(h_gbd);

		// create ssrc, set ssrc;
		ssrc = NULL;
		i_err = h_gbd->alloc_ssrc(h_gbd,FALSE,NULL,1,&ssrc); // add ref by 1;
		if( STX_OK != i_err ) {
			break;
		}
		h_gph->set_ssrc(h_gph,ssrc);

		i_err = STX_OK;

	}while(FALSE);

	if( STX_OK != i_err ) {
		SAFE_XDELETE(h_gph);
	}

	*hh_graph = h_gph;

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static STX_RESULT stx_base_graph_builder_vt_xxx_detach_graph
(STX_HANDLE h,stx_base_graph *h_graph)
{
	return STX_OK;
}





/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_graph_builder_vt_plug_xxx_get_property
(STX_HANDLE h,stx_xio* h_xio)
{
	STX_MAP_THE(base_graph_builder);

	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_graph_builder_vt_plug_xxx_set_property
(STX_HANDLE h,stx_xio* h_xio)
{
	STX_MAP_THE(base_graph_builder);

	return STX_ERR_NOT_SUPPORT;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_base_graph_builder_vt_xxx_reg_plug(THEE h,stx_base_plugin* plug)
{
	STX_MAP_THE(base_graph_builder);

	if( g_i_debug & GBD_DEBUG_PLUG_MONITOR ){

		STX_RESULT			i_err;
		stx_plug_monitor*	h_mor;

		do{
			i_err = STX_FAIL;
			h_mor = (stx_plug_monitor*)xmallocz(sizeof(stx_plug_monitor));
			if( !h_mor){
				break;
			}
			h_mor->h_stat = stx_stat_create();
			if( !h_mor->h_stat ) {
				break;
			}
			h_mor->i_last_time = h_mor->i_report_time = stx_get_microsec();
			i_err = plug->reg_key(plug,STX_REG_MONITOR,sizeof(void*));
			if( STX_OK != i_err ) {
				break;
			}
			i_err = plug->write_key(plug,STX_REG_MONITOR,(u8*)&h_mor,(s32)sizeof(h_mor));

		}while(FALSE);

		if( STX_OK != i_err ) {
			if( h_mor ) {
				if( h_mor->h_stat ) {
					stx_stat_close(h_mor->h_stat);
				}
				stx_free(h_mor);
			}
		}
		
		return i_err;
	}

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE void
stx_base_graph_builder_vt_xxx_unreg_plug(THEE h,stx_base_plugin* plug)
{
	STX_MAP_THE(base_graph_builder);

	if( g_i_debug & GBD_DEBUG_PLUG_MONITOR ){

		STX_RESULT			i_err;
		stx_plug_monitor*	h_mor;
		u8*					h_data;
		s32					i_len;

		h_mor = NULL;
		i_len = sizeof(h_mor);

		h_data = plug->read_key(plug,STX_REG_MONITOR,&i_len);
		if( !h_data ) {
			return;
		}

		h_mor = *(stx_plug_monitor**)h_data;
		if( h_mor ) {
			if( h_mor->h_stat ) {
				stx_stat_close(h_mor->h_stat);
			}
			stx_free(h_mor);
		}

		plug->rem_key(plug,STX_REG_MONITOR);
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG STX_RESULT 
on_unregister_module(STX_HANDLE h,stx_base_message* p_msg)
{
	STX_RESULT				i_err;
	stx_sync_source*		hssrc;
	stx_base_graph_builder* gbd;

	STX_MAP_THE(base_graph_builder);

	gbd = &the->stx_base_graph_builder_vt;
	i_err = gbd->alloc_ssrc(gbd,FALSE,STX_NULL,1,&hssrc);
	if( STX_OK != i_err ) {
		return i_err;
	}
	//stx_log("before ssrc->send_msg \r\n");
	i_err = hssrc->send_msg(hssrc,p_msg);
	//stx_log("after ssrc->send_msg \r\n");
	SAFE_XDELETE(hssrc);
	return i_err;
}











/***********************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***********************************************************************************/
STX_PRIVATE STX_RESULT stx_filter_overload
(base_graph_builder* h_gbd, stx_base_com* p_obj,stx_module_ctx* p_module)
{
	STX_RESULT				i_err;
	stx_filter_user_data*	h_user;
	stx_base_plugin*		h;

	i_err = p_obj->query_interf(p_obj,STX_IID_BasePlugin,(void**)&h);
	if( STX_OK != i_err ) {
		return i_err;
	}
	SAFE_XDELETE(h);

	do{
		// all the filter instance pointer is stx_base_com type;
		STX_MAP_THE(stx_base_com);

		i_err = STX_FAIL;

		h_user = (stx_filter_user_data*)xmallocz(sizeof(stx_filter_user_data));
		if( !h_user ) {
			break;
		}

		// add module context reference counter;
		h_user->h_modctx = p_module;
		p_module->i_ref ++;

		h_user->stx_uuid = h->get_uuid(h);

		h_user->h_com = the;
		h_user->g_gbd = h_gbd;

		// overload THEE->release method;
		h_user->release = the->release;
		the->release = filter_release;

#ifdef TRACE_STX_QUERY
		h_user->query_interf = the->query_interf;
		the->query_interf = filter_query_interf;
#endif

#ifdef TRACE_STX_ADDREF
		h_user->add_ref = the->add_ref;
		the->add_ref = filter_add_ref;
#endif

// #if defined(TRACE_STX_QUERY) || defined(TRACE_STX_ADDREF)
// 		if( !p_first_udat ) {
// 			h_gbd->p_first_udat = h_user;
// 		}
// 		else{
// 			stx_filter_user_data* prev;
// 			stx_filter_user_data* next = h_gbd->p_first_udat;
// 			while(next){
// 				prev = next;
// 				next = next->p_next;
// 			}
// 			prev->p_next = h_user;
// 		}
// #endif

		// for fast release;
		h->set_user_data(h,h_user);

		i_err = STX_OK;

	}while( FALSE);

	return i_err;
}


/***********************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***********************************************************************************/
STX_PURE s32 filter_add_ref( STX_HANDLE h )
{
	STX_RESULT              i_err;
	s32						i_ref;
	stx_filter_user_data*	h_user;
	stx_base_plugin*		plug;

	// h, must be stx_base_com type;
	STX_DIRECT_THE(stx_base_com);

	i_err = the->query_interf(the,STX_IID_BasePlugin,(void**)&plug);
	if( STX_OK != i_err ) {
		return (s32)i_err;
	}

	// muse get the user data before the release method;
	h_user = (stx_filter_user_data*)plug->get_user_data(plug);

	//use original release method to replace: SAFE_XDELETE(plug);
	i_ref = h_user->release(h);

	stx_log("filter_add_ref::%s::i_ref = %d\r\n",plug->get_name(plug),i_ref);

	//use original add_ref method
	return h_user->add_ref(h);
}


/***********************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***********************************************************************************/
STX_PURE STX_RESULT 
filter_query_interf(STX_HANDLE h,stx_gid iid,STX_HANDLE* h_interf)
{
#if 0
	STX_RESULT              i_err;
	s32						i_ref;
	stx_filter_user_data*	h_user;
	stx_base_plugin*		plug;


	h_user = g_gbd->p_first_udat;
	while(h_user->h_com != h){
		h_user = h_user->p_next;
	}

	i_err = h_user->query_interf(h,STX_IID_BasePlugin,(void**)&plug);
	if( STX_OK != i_err ) {
		return i_err;
	}

	h_user = plug->get_user_data(plug);

	//use original release method to replace: XDELETE(plug);
	i_ref = h_user->release(h);

	stx_log("%s::i_ref = %d\r\n",plug->get_name(plug),i_ref);

	//use original query_interf method
	return h_user->query_interf(h,iid,h_interf);
#endif 

	return STX_ERR_NOT_SUPPORT;
}




/***********************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***********************************************************************************/
STX_PURE s32 filter_release(STX_HANDLE h)
{
	STX_RESULT              i_err;
	s32						i_ref;
	stx_filter_user_data*	h_user;

	stx_base_plugin*		plug;
	stx_base_message*		p_msg;
	stx_msg_cnt*			cnt;
	base_graph_builder*		h_base_gbd;

	// h, must be stx_base_com type;
	STX_DIRECT_THE(stx_base_com);

	plug = NULL;
	p_msg = NULL;

	i_err = the->query_interf(the,STX_IID_BasePlugin,(void**)&plug);
	if( STX_OK != i_err ) { // FATAL ERROR;
		return STX_FAIL;
	}

	// muse get the user data before the release method;
	h_user = plug->get_user_data(plug);
	h_base_gbd = h_user->g_gbd;


	do{

		//use original release method to replace: XDELETE(plug);
		i_ref = h_user->release(h);

#if 0
		{
			char szins[64];
			stx_gid insgid = plug->get_insid(plug);
			binary_to_string(16,insgid.data,szins);
			stx_log("%s<%s>::i_ref = %d\r\n",plug->get_name(plug),szins,i_ref-1);
		}
#endif

		// this time is the actual release;
		i_ref = h_user->release(h);
		if( i_ref > 0 ) {
			break;
		}

		// must use asynchronous message, send to gbd, gbd unregister the module;
		p_msg = XCREATE(base_msg,NULL,NULL);
		if( !p_msg){
			stx_set_interrupted();
			break;
		}
		p_msg->set_msg_type(p_msg,STX_MSG_TYPE_ASYNC);
		cnt = p_msg->get_msg_cnt(p_msg);
		cnt->msg_gid = STX_MSG_UnregModule;
		cnt->param.i_param[0] = (size_t)h_user;
		{
			stx_base_graph_builder* g_gbd = &h_base_gbd->stx_base_graph_builder_vt;
			//stx_log("before g_gbd->send_msg\r\n");
			stx_module_lock(h_base_gbd->g_hMutex);
			i_err = g_gbd->send_msg(g_gbd,p_msg);
			if( STX_OK != i_err ){
				stx_set_interrupted();
			}
			stx_module_unlock( h_base_gbd->g_hMutex );
			//stx_log("after g_gbd->send_msg\r\n");
			SAFE_XDELETE(p_msg);
		}

	}while(FALSE);

	return i_ref;
}






/***********************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***********************************************************************************/
STX_API_IMP stx_base_graph_builder*	stx_initialize( void (*p)(char*) ,u32 i_debug )
{
	DECL_TRACE

	STX_RESULT				i_err;
	stx_base_graph_builder* h;


	i_err = STX_FAIL;
	h = NULL;

	do{

		if( STX_OK != stx_base_init( p, i_debug ) ) {
			break;
		}

		h = XCREATE(base_graph_builder,NULL);
		if( !h ) {
			break;
		}

		i_err = STX_OK;

	}while(FALSE);

	if( STX_OK != i_err ) {
		stx_cleanup(h);
		return NULL;
	}

	return h;
}


/***********************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***********************************************************************************/
STX_PRIVATE void stx_module_ctx_close( stx_module_ctx* p)
{
	SAFE_XDELETE(p->h_module);
	SAFE_CLOSEXIO(p->h_stx_dll);
	if( p->sz_path ) {
		stx_free( p->sz_path );
	}
	if( p->cls_gid ) {
		stx_free(p->cls_gid);
	}
	stx_free( p );
}

/***********************************************************************************
stx_StreamX_CleanUp
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***********************************************************************************/
STX_API_IMP void stx_cleanup(stx_base_graph_builder* h)
{
	SAFE_XDELETE(h);

	stx_base_cleanup();
}



/***********************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***********************************************************************************/
static STX_RESULT stx_module_reg( base_graph_builder* the,stx_module_ctx* p_ctx )
{
	if( the->g_iModuleNum == the->g_iMaxModuleNum ) {

		stx_module_ctx** tmp;

		tmp = xmallocz(sizeof(stx_module_ctx*)*(the->g_iMaxModuleNum + STX_MAX_MODULE ));
		if( !tmp ) {
			return STX_FAIL;
		}

		if( the->g_pStxModule ) {
			s32 i;
			for( i = 0; i < the->g_iModuleNum; i ++ ) {
				tmp[i] = the->g_pStxModule[i];
			}
			stx_free(the->g_pStxModule);
		}//if( g_pStxModule ) {

		the->g_pStxModule = tmp;
		the->g_iMaxModuleNum += STX_MAX_MODULE;

	} // if( g_iModuleNum == g_iMaxModuleNum ) {

	the->g_pStxModule[the->g_iModuleNum] = p_ctx;

	the->g_iModuleNum ++;

	return STX_OK;
}


/***********************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***********************************************************************************/
static STX_RESULT stx_module_unreg(base_graph_builder* the, stx_module_ctx* p_ctx )
{
	s32 i,j;

	for( i = 0; i < the->g_iModuleNum; i ++ ) {

		if( the->g_pStxModule[i] == p_ctx ) {

			stx_module_ctx_close(p_ctx);

			for( j = i; j < the->g_iModuleNum - 1; j ++ ) {
				the->g_pStxModule[j] = the->g_pStxModule[j+1];
			}
			the->g_pStxModule[the->g_iModuleNum - 1] = NULL;
			the->g_iModuleNum --;

			return STX_OK;

		} // if( the->g_pStxModule[i] == p_ctx ) {

	} // for( i = 0; i < the->g_iModuleNum; i ++ ) {

	return STX_OK;
}




/***********************************************************************************
stx_module_query_by_path
RETURN VALUE: 
INPUT:stx_gid cls_gidsizeof(sz_key),
OUTPUT:stx_module_ctx** p_ctx
NOTE:
***********************************************************************************/
static STX_RESULT	stx_module_query_by_path
(base_graph_builder* the, char* sz_path, stx_module_ctx** p_ctx )
{
	STX_RESULT	i_err;
	s32			i;

	i_err = STX_FAIL;

	for( i = 0; i < the->g_iModuleNum; i ++ ) {
		if(  !strcmp( sz_path, the->g_pStxModule[i]->sz_path ) ) {
			*p_ctx = the->g_pStxModule[i];
			i_err = STX_OK;
			break;
		} // if(  !strcmp( sz_path, the->g_p
	}// for( i = 0; i < the->g_iModuleNum; i ++ ) {

	return i_err;
}

/***********************************************************************************
stx_module_query
RETURN VALUE: 
INPUT:stx_gid cls_gid
OUTPUT:stx_module_ctx** p_ctx
NOTE:
***********************************************************************************/
static STX_RESULT stx_module_query
(base_graph_builder* the,  stx_gid cls_gid, stx_module_ctx** p_ctx )
{
	STX_RESULT	i_err;

	s32			i,j;

	i_err = STX_FAIL;


	for( i = 0; i < the->g_iModuleNum; i ++ ) {
		stx_module_ctx* p = the->g_pStxModule[i];
		for( j = 0; j < p->i_filter_num; j ++ ) {
			stx_gid gid = p->cls_gid[j];
			if(  IS_EQUAL_GID( gid , cls_gid ) ) {
				*p_ctx = p;
				i_err = STX_OK;
				break;
			}
		}
		if( j < the->g_pStxModule[i]->i_filter_num ) {
			break;
		}
	}

	return i_err;
}





/***********************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***********************************************************************************/
STX_PRIVATE STX_RESULT  stx_co_query_obj_internal
( stx_gid cls_gid ,  char** sz_dll_path )
{
	DECL_TRACE

	STX_RESULT					i_err;
	char*						sz_path;
	stx_xini*					h_xini;
	STX_HANDLE					h_all;
	STX_HANDLE					h_gid,h_path;
	char						sz_cfg[1024];
	char						sz_gid[64];

	i_err = STX_FAIL;

	sz_path = STX_NULL;
	h_xini = STX_NULL;

	i_err = STX_FAIL;

	do{
		binary_to_string( 16, cls_gid.data, sz_gid);

		stx_sprintf(sz_cfg, sizeof(sz_cfg),"%s\\%s",g_szStreamX_Path,g_szStreamX_Cfg);

		i_err = stx_ini_create( sz_cfg, STX_NULL, STX_INI_READ_ONLY, 0, &h_xini );
		if( STX_INI_OK != i_err ) {
			break;
		}

		/* all modules ; */
		i_err = h_xini->create_key( h_xini, STX_NULL, g_szStreamX_AllModule, STX_NULL, &h_all );
		if( STX_INI_OK != i_err ) {
			break;
		}

		/* the module with class gid ; */
		i_err = h_xini->create_key( h_xini, h_all, sz_gid, STX_NULL, &h_gid );
		if( STX_INI_OK != i_err ) {
			break;
		}

		/* module path; */
		i_err = h_xini->create_key( h_xini, h_gid, g_szStreamX_PathName, STX_NULL, &h_path );
		if( STX_INI_OK != i_err ) {
			break;
		}

		sz_path = NULL;
		i_err = h_xini->read_string( h_xini, h_path, &sz_path );
		if( STX_INI_OK != i_err ) {
			break;
		}

		*sz_dll_path = xstrdup(sz_path);
		if( !*sz_dll_path ) {
			i_err = STX_FAIL;
			break;
		}

		i_err = STX_OK;

	}while(FALSE);

	if( h_xini ) {
		h_xini->close(h_xini);
	}

	return i_err;
}




/***********************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***********************************************************************************/
STX_PURE void stx_unregister_module_as(THEE h,THEE h_dat) 
{
	stx_module_ctx*			h_mod;
	stx_filter_user_data*	h_user;

	STX_MAP_THE(base_graph_builder);

	h_user = (stx_filter_user_data*)h_dat;

	//stx_log("before stx_unregister_module_as\r\n");

	stx_module_lock(the->g_hMutex);
	{

		h_mod = h_user->h_modctx;			
		h_mod->i_ref --;
		if( 0 == h_mod->i_ref ) {  
			//stx_log("stx_module_unreg\r\n");
			stx_module_unreg(the,h_mod);
		}
// #if defined(TRACE_STX_QUERY)
// 		// remove h_user from list;
// 		{
// 			stx_filter_user_data* prev = NULL;
// 			stx_filter_user_data* next = the->p_first_udat;
// 			while(next != h_user){
// 				prev = next;
// 				next = next->p_next;
// 			}
// 			if( !prev ) {
// 				the->p_first_udat = h_user->p_next;
// 			}
// 			else{
// 				prev->p_next = h_user->p_next;
// 			}
// 		}
// #endif
		stx_free(h_user);
	}
	stx_module_unlock(the->g_hMutex);
	
	//stx_log("after stx_unregister_module_as\r\n");

}

/***********************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***********************************************************************************/
STX_PURE STX_RESULT  stx_co_query_obj
(THEE h, stx_gid cls_gid ,  char** sz_dll_path )
{
	STX_RESULT i_err;

	STX_MAP_THE(base_graph_builder);

	stx_module_lock(the->g_hMutex);

	i_err = stx_co_query_obj_internal(cls_gid,sz_dll_path);

	stx_module_unlock(the->g_hMutex);

	return i_err;
}





/***********************************************************************************
stx_co_create_obj
RETURN VALUE: success, is STX_OK; or is a negative value;
INPUT: cls_gid, the class guid of the object want to be created;
OUTPUT: pp_com, the address of the object pointer;
NOTE:
first find the static module pool by class id, if have right item, use the buffered
dll handle;
or search the streamx configure file, locate the module path name;
if the module pool have same path name item, use it;
or load the dll, create module register interface,
enum the filter, enum the pin, add to the streamx configure file; 
***********************************************************************************/
STX_API_IMP STX_RESULT  stx_co_create_obj
( THEE h, stx_gid cls_gid ,  stx_base_com** pp_com )
{
	STX_RESULT					i_err;
	stx_base_com*				p_obj;
	stx_dll*					h_dll;
	stx_module_ctx*				p_module_ctx;
	stx_base_module*			p_module;
	s32                         i;

	LP_STX_CREATE_MODULE_PROC(	create_module	);

	b32							b_load;

	STX_MAP_THE(base_graph_builder);

	i_err = STX_FAIL;
	p_obj = STX_NULL;
	h_dll = STX_NULL;
	create_module = STX_NULL;
	p_module_ctx = STX_NULL;
	p_module = STX_NULL;
	b_load = FALSE;

	stx_module_lock(the->g_hMutex);

	i_err = stx_module_query( the, cls_gid, &p_module_ctx );

	if( STX_OK != i_err ) {

		p_module_ctx = (stx_module_ctx*)xmallocz( sizeof(stx_module_ctx ));
		if( !p_module_ctx ) {
			goto fail;
		}

		i_err = stx_co_query_obj_internal(cls_gid,&p_module_ctx->sz_path);
		if( STX_OK != i_err ) {
			goto fail;
		}

		p_module_ctx->h_stx_dll = stx_dll_create();
		if( !p_module_ctx->h_stx_dll ) {
			goto fail;
		}

		i_err = XCALL(load_library,p_module_ctx->h_stx_dll, p_module_ctx->sz_path );
		if( STX_OK != i_err ) {
			goto fail;
		}

		b_load = TRUE;

		i_err = STX_FAIL;

		create_module = (STX_CREATE_MODULE_PROC_PTR)
			XCALL(entry_by_name,p_module_ctx->h_stx_dll, g_szStreamX_CreateModule );
		if( !create_module ) {
			goto fail;
		}

		p_module_ctx->h_module = create_module(&i_err,(stx_base_graph_builder*)h,stx_trace,the->g_i_debug);
		if( !p_module_ctx->h_module ) {
			goto fail;
		}

		p_module_ctx->i_filter_num = XCALL(get_filter_num,p_module_ctx->h_module);

		if( p_module_ctx->i_filter_num ) {
			p_module_ctx->cls_gid = (stx_gid*)xmallocz(sizeof(stx_gid)*p_module_ctx->i_filter_num);
			if( !p_module_ctx->cls_gid ) {
				goto fail;
			}

			for( i = 0; i < p_module_ctx->i_filter_num; i ++ ) {
				i_err = XCALL(get_filter_gid,p_module_ctx->h_module,i,&p_module_ctx->cls_gid[i]);
				if( STX_OK != i_err) {
					goto fail;
				}
			}//for( i = 0; i < p_module_ctx->i_filter_num; i ++ ) {

		}//if( p_module_ctx->i_filter_num ) {

	}//if( STX_OK != i_err ) {


	p_module = p_module_ctx->h_module;

	i_err = p_module->create_instance( p_module, cls_gid, (void**)&p_obj );
	if( STX_OK != i_err ) {
		goto fail;
	}

	i_err = stx_filter_overload(the,p_obj,p_module_ctx);
	if( STX_OK != i_err ) {
		goto fail;
	}

	if( b_load ) {
		i_err = stx_module_reg( the, p_module_ctx );
		if( STX_OK != i_err ) {
			goto fail;
		}
	}

	*pp_com = p_obj;

	i_err = STX_OK;

fail:

	if( STX_OK != i_err ) {
		if( p_obj ) {
			p_obj->release(p_obj);
		}
		if( p_module_ctx ) {
			stx_module_ctx_close(p_module_ctx);
		}
	}

	stx_module_unlock( the->g_hMutex);

	return i_err;
}






/***********************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***********************************************************************************/
STX_PURE STX_RESULT stx_co_create_obj_svr
( THEE h,stx_gid cls_gid , char* sz_svr, stx_base_com** pp_com )
{
	STX_RESULT					i_err;
	char*						sz_gid;
	stx_base_com*				p_obj;

	stx_dll*					h_dll;
	stx_module_ctx*				p_module_ctx;
	stx_base_module*			p_module;
	s32                         i;

	LP_STX_CREATE_MODULE_PROC(	create_module	);

	b32							b_load;


	STX_MAP_THE(base_graph_builder);

	i_err = STX_FAIL;
	sz_gid = STX_NULL;
	p_obj = STX_NULL;

	h_dll = STX_NULL;
	create_module = STX_NULL;
	p_module_ctx = STX_NULL;
	p_module = STX_NULL;
	b_load = FALSE;

	stx_module_lock( the->g_hMutex);

	i_err = stx_module_query_by_path( the,sz_svr, &p_module_ctx );

	if( STX_OK != i_err ) {

		p_module_ctx = (stx_module_ctx*)xmallocz( sizeof(stx_module_ctx ));
		if( !p_module_ctx ) {
			goto fail;
		}

		p_module_ctx->sz_path = xstrdup( sz_svr);
		if( !p_module_ctx->sz_path ) {
			goto fail;
		}

		p_module_ctx->h_stx_dll = stx_dll_create();
		if( !p_module_ctx->h_stx_dll ) {
			goto fail;
		}

		i_err = p_module_ctx->h_stx_dll->load_library( p_module_ctx->h_stx_dll, sz_svr );
		if( STX_OK != i_err ) {
			goto fail;
		}

		b_load = TRUE;

		i_err = STX_FAIL;

		create_module = (STX_CREATE_MODULE_PROC_PTR)
			XCALL(entry_by_name,p_module_ctx->h_stx_dll, g_szStreamX_CreateModule );
		if( !create_module ) {
			goto fail;
		}

		p_module_ctx->h_module = create_module(&i_err,(stx_base_graph_builder*)h,stx_trace,the->g_i_debug);
		if( !p_module_ctx->h_module ) {
			goto fail;
		}

		p_module_ctx->i_filter_num = XCALL(get_filter_num,p_module_ctx->h_module);

		if( p_module_ctx->i_filter_num ) {
			p_module_ctx->cls_gid = (stx_gid*)xmallocz(sizeof(stx_gid)*p_module_ctx->i_filter_num);
			if( !p_module_ctx->cls_gid ) {
				goto fail;
			}

			for( i = 0; i < p_module_ctx->i_filter_num; i ++ ) {
				i_err = XCALL(get_filter_gid,p_module_ctx->h_module,i,&p_module_ctx->cls_gid[i]);
				if( STX_OK != i_err ) {
					goto fail;
				}
			}//for( i = 0; i < p_module_ctx->i_filter_num; i ++ ) {

		}//if( p_module_ctx->i_filter_num ) {

	}//if( STX_OK != i_err ) {


	p_module = p_module_ctx->h_module;

	i_err = p_module->create_instance( p_module, cls_gid, (void**)&p_obj );
	if( STX_OK != i_err ) {
		goto fail;
	}

	i_err = stx_filter_overload(the,p_obj,p_module_ctx);
	if( STX_OK != i_err ) {
		goto fail;
	}

	if( b_load ) {
		i_err = stx_module_reg( the,p_module_ctx );
		if( STX_OK != i_err ) {
			goto fail;
		}
	}

	*pp_com = p_obj;

	i_err = STX_OK;

fail:

	if( STX_OK != i_err ) {
		if( p_obj ) {
			p_obj->release(p_obj);
		}
		if( p_module_ctx ) {
			stx_module_ctx_close(p_module_ctx);
		}
	}

	if( sz_gid ) {
		stx_gid_close_string(&sz_gid);
	}

	stx_module_unlock(the->g_hMutex);

	return i_err;
}




/***********************************************************************************
RETURN VALUE: success, is STX_OK; or is a negative value;
INPUT:  sz_svr, the dll path and name;
OUTPUT: no output value;
NOTE: 
***********************************************************************************/
STX_PURE STX_RESULT	stx_get_filter_inf
( THEE h,stx_base_filter* p_flt, stx_xini* h_xini )
{

	STX_RESULT					i_err;

	s32							j,m;
	char						sz_gid[64];
	char						sz_type[64];
	stx_gid						cls_gid;
	stx_gid						cat_gid;
	char*						sz_cat_desc;

	STX_HANDLE					h_all;
	STX_HANDLE					h_gid;
	STX_HANDLE					h_cat;
	STX_HANDLE					h_type;
	STX_HANDLE					h_name;
	STX_HANDLE					h_subtype;
	char                        sz_key[2048];
	stx_media_type_inf          minf;


	STX_MAP_THE(base_graph_builder);

	i_err = STX_FAIL;

	/* all modules ; */
	i_err = h_xini->create_key( h_xini, STX_NULL, g_szStreamX_AllModule, STX_NULL, &h_all );
	if( STX_INI_OK != i_err ) {
		goto fail;
	}


	cls_gid = p_flt->get_clsid(p_flt);
	binary_to_string(sizeof(stx_gid),cls_gid.data,sz_gid);

	/* the module registered as:  class gid value = class id; */
	i_err = h_xini->create_key( h_xini, h_all, sz_gid, g_szStreamX_ClassId, &h_gid );
	if( STX_INI_OK != i_err ) {
		goto fail;
	}

	/* description */
	sz_cat_desc = p_flt->get_name(p_flt);
	if( !sz_cat_desc ) {
		goto fail;
	}
	/* filter name = StreamX rtsp file source filter */
	i_err = h_xini->create_key( h_xini, h_gid, g_szStreamX_FilterName, sz_cat_desc,  &h_cat );
	if( STX_INI_OK != i_err ) {
		goto fail;
	}

	sz_cat_desc = p_flt->get_clsid_name(p_flt);
	if( !sz_cat_desc ) {
		goto fail;
	}
	/* class id name = ; */
	i_err = h_xini->create_key( h_xini, h_gid, g_szStreamX_ClassIdName, sz_cat_desc,  &h_cat );
	if( STX_INI_OK != i_err ) {
		goto fail;
	}

	cat_gid = p_flt->get_catid(p_flt);
	binary_to_string(sizeof(stx_gid),cat_gid.data,sz_type);

	/* Main category = 1F2EA6D1-C7B3-4ae7-B22E-F89975469D9A (file source); */
	i_err = h_xini->create_key( h_xini, h_gid, g_szStreamX_MainCategory, sz_type, &h_cat );
	if( STX_INI_OK != i_err ) {
		goto fail;
	}

	sz_cat_desc = p_flt->get_catid_name(p_flt);
	if( !sz_cat_desc ) {
		goto fail;
	}
	i_err = h_xini->create_key( h_xini, h_cat, g_szStreamX_CategoryDesc, sz_cat_desc, &h_name );
	if( STX_INI_OK != i_err ) {
		goto fail;
	}

	i_err = p_flt->enum_input_media_type( p_flt,&m,STX_NULL );
	if( STX_OK != i_err || m == MAX_MEDIA_TYPE ) { // skip emulator;
		goto fail;
	}

	i_err = h_xini->create_key( h_xini, h_gid, g_szStreamX_InputType, g_szStreamX_InputType, &h_cat);
	if( STX_INI_OK != i_err ) {
		goto fail;
	}

	for( j = 0; j < m; j ++ ) {

		i_err = p_flt->enum_input_media_type( p_flt,&j,&minf );
		if( STX_OK != i_err ) { // skip emulator;
			goto fail;
		}

		binary_to_string(sizeof(stx_gid),minf.major_type.data,sz_type);

		/* Major Type - 0 = ( 73646976-0000-0010-8000-00AA00389B71 vids ); */
		stx_sprintf(sz_key,sizeof(sz_key),"%s-%d",g_szStreamX_MajorDataType,j);
		i_err = h_xini->create_key( h_xini, h_cat, sz_key, sz_type, &h_type);
		if( STX_INI_OK != i_err ) {
			goto fail;
		}

		i_err = h_xini->create_key( h_xini, h_type, 
			g_szStreamX_MajorDataTypeName, *minf.major_type_name, &h_name );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}

		binary_to_string(sizeof(stx_gid),minf.sub_type.data,sz_type);

		i_err = h_xini->create_key( h_xini, h_type, g_szStreamX_SubDataType, sz_type, &h_subtype);
		if( STX_INI_OK != i_err ) {
			goto fail;
		}

		i_err = h_xini->create_key( h_xini, h_type, 
			g_szStreamX_SubDataTypeName, *minf.sub_type_name, &h_name );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}

	} /* for( j = 0; j < m; j ++ ) { */


	i_err = h_xini->create_key( h_xini, h_gid, g_szStreamX_OutputType, g_szStreamX_OutputType, &h_cat );
	if( STX_INI_OK != i_err ) {
		goto fail;
	}

	i_err = p_flt->enum_output_media_type( p_flt,&m,STX_NULL );
	if( STX_OK != i_err || m == MAX_MEDIA_TYPE ) { // skip emulator;
		goto fail;
	}

	for( j = 0; j < m; j ++ ) {

		i_err = p_flt->enum_output_media_type( p_flt,&j,&minf );
		if( STX_OK != i_err ) { // skip emulator;
			goto fail;
		}

		binary_to_string(sizeof(stx_gid),minf.major_type.data,sz_type);

		stx_sprintf(sz_key,sizeof(sz_key),"%s-%d",g_szStreamX_MajorDataType,j);
		i_err = h_xini->create_key( h_xini, h_cat, sz_key, sz_type, &h_type);
		if( STX_INI_OK != i_err ) {
			goto fail;
		}

		i_err = h_xini->create_key( h_xini, h_type, g_szStreamX_MajorDataTypeName, 
			*minf.major_type_name, &h_name);
		if( STX_INI_OK != i_err ) {
			goto fail;
		}

		binary_to_string(sizeof(stx_gid),minf.sub_type.data,sz_type);

		i_err = h_xini->create_key( h_xini, h_type, g_szStreamX_SubDataType, sz_type, &h_subtype);
		if( STX_INI_OK != i_err ) {
			goto fail;
		}

		i_err = h_xini->create_key( h_xini, h_type, g_szStreamX_SubDataTypeName, 
			*minf.sub_type_name, &h_name);
		if( STX_INI_OK != i_err ) {
			goto fail;
		}

	} /* for( j = 0; j < m; j ++ ) { */


	i_err = STX_OK;


fail:

	if( i_err < 0 ) {
		i_err = h_xini->delete_key( h_xini, h_gid );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
	} /*if( i_err < 0 ) {*/

	return i_err;
}



/***********************************************************************************
RETURN VALUE: success, is STX_OK; or is a negative value;
INPUT:  sz_svr, the dll path and name;
OUTPUT: no output value;
NOTE: 
***********************************************************************************/
STX_PURE STX_RESULT	stx_get_svr_inf
( THEE h,char* sz_svr, stx_xini* h_xini )
{
	STX_RESULT					i_err;
	s32							i_filter_num;
	s32							i,j,m;
	char						sz_gid[64];
	char						sz_type[64];
	stx_gid						cls_gid;
	stx_gid						cat_gid;
	char*						sz_cat_desc;
	stx_base_com*				p_obj;
	stx_com_helper*				p_helper;
	stx_base_plugin*			p_plug;
	stx_base_filter*			p_filter;
	stx_stream_writer*          p_writer;
	stx_base_source*            p_source;
	STX_HANDLE					h_all;
	STX_HANDLE					h_gid;
	STX_HANDLE					h_cat;
	STX_HANDLE					h_name;
	THEE						h_interf;
	THEE						h_subinterf;
	STX_HANDLE					h_type;
	STX_HANDLE					h_subtype;
	stx_dll*					h_dll;

	stx_base_module*			p_module;

	LP_STX_CREATE_MODULE_PROC(create_module) ;

	char						sz_key[1024];

	stx_media_type_inf          minf;

	b32							b_filter;


	STX_MAP_THE(base_graph_builder);


	i_err = STX_FAIL;
	h_dll = NULL;
	create_module = NULL;
	p_obj = NULL;
	p_module = NULL;
	p_helper = NULL;
	p_plug = NULL;
	p_filter = NULL;
	p_writer = NULL;
	p_source = NULL;


	/* all modules ; */
	i_err = h_xini->create_key( h_xini, STX_NULL, g_szStreamX_AllModule, STX_NULL, &h_all );
	if( STX_INI_OK != i_err ) {
		goto fail;
	}

	h_dll = stx_dll_create();
	if( !h_dll ) {
		goto fail;
	}

	i_err = h_dll->load_library( h_dll, sz_svr );
	if( STX_OK != i_err ) {
		goto fail;
	}

	create_module = (STX_CREATE_MODULE_PROC_PTR)h_dll->entry_by_name(
		h_dll, g_szStreamX_CreateModule );
	if( !create_module ) {
		goto fail;
	}

	p_module = create_module(&i_err,(stx_base_graph_builder*)h,stx_trace,the->g_i_debug);
	if( !p_module ) {
		goto fail;
	}

	i_filter_num = p_module->get_filter_num( p_module );
	if( !i_filter_num ) {
		goto fail;
	}

	for( i = 0; i < i_filter_num; i ++ ) {

		p_module->get_filter_gid(p_module,i,&cls_gid);

		binary_to_string(sizeof(stx_gid),cls_gid.data,sz_gid);

		/* the module registered as:  class gid value = class id; */

		// first try to delete the existing sub key;
		h_xini->delete_sub_key( h_xini, h_all, sz_gid );

		i_err = h_xini->create_key( h_xini, h_all, sz_gid, g_szStreamX_ClassId, &h_gid );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}

		/* Path Name = sz_svr; */
		i_err = h_xini->create_key( h_xini, h_gid, g_szStreamX_PathName, sz_svr, &h_cat );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}

		if( p_obj ) {
			p_obj->release(p_obj);
		}
		i_err = p_module->create_instance( p_module, cls_gid, (void**)&p_obj );
		if( STX_OK != i_err ) {
			goto delete_key;
		}

		SAFE_XDELETE( p_plug );
		i_err = p_obj->query_interf( p_obj, STX_IID_BasePlugin, (void**)&p_plug);
		if( STX_OK != i_err ) {
			goto delete_key;
		}

		/* description */
		sz_cat_desc = p_plug->get_name(p_plug);
		if( sz_cat_desc ) {
			/* filter name = StreamX rtsp file source filter */
			i_err = h_xini->create_key( h_xini, h_gid, g_szStreamX_FilterName, sz_cat_desc,  &h_cat );
			if( STX_INI_OK != i_err ) {
				goto fail;
			}
		}

		sz_cat_desc = p_plug->get_clsid_name(p_plug);
		if( sz_cat_desc ) {
			/* class id name = ; */
			i_err = h_xini->create_key( h_xini, h_gid, g_szStreamX_ClassIdName, sz_cat_desc,  &h_cat );
			if( STX_INI_OK != i_err ) {
				goto fail;
			}
		}

		cat_gid = p_plug->get_catid(p_plug);
		binary_to_string(sizeof(stx_gid),cat_gid.data,sz_type);

		/* Main category = 1F2EA6D1-C7B3-4ae7-B22E-F89975469D9A (file source); */
		i_err = h_xini->create_key( h_xini, h_gid, g_szStreamX_MainCategory, sz_type, &h_cat );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}

		sz_cat_desc = p_plug->get_catid_name(p_plug);
		if( sz_cat_desc ) {
			i_err = h_xini->create_key( h_xini, h_cat, g_szStreamX_CategoryDesc, sz_cat_desc, &h_name );
			if( STX_INI_OK != i_err ) {
				goto fail;
			}
		}


		// get com helper;
		// if have com helper, enum the interface;
		i_err = p_obj->query_interf( p_obj, STX_IID_StxComHelper, (void**)&p_helper);
		if( STX_OK == i_err ) {

			s32					i_com,i_total;
			stx_com_map_ctx		comctx;

			// add g_szStreamX_Interface key;

			i_err = h_xini->create_key( h_xini, h_gid, g_szStreamX_Interface, sz_STX_IID_StxComHelper, &h_interf );
			if( STX_INI_OK != i_err ) {
				goto fail;
			}

			i_err = p_helper->enum_interf(p_helper,&i_total,NULL);
			if( STX_OK != i_err ) {
				goto delete_key;
			}

			for( i_com = 0; i_com < i_total; i_com ++) {
				i_err = p_helper->enum_interf(p_helper,&i_com,&comctx);
				if( STX_OK != i_err ) {
					goto delete_key;
				}
				// iid = iid_name;
				binary_to_string(sizeof(stx_gid),comctx.iid.data,sz_gid);
				i_err = h_xini->create_key( h_xini, h_interf, sz_gid, comctx.iid_name, &h_subinterf );
				if( STX_INI_OK != i_err ) {
					goto fail;
				}
			} // for( i_com = 0; i_com < i_total; i_com ++) {

			SAFE_XDELETE0(p_helper);

		} // if( STX_OK == i_err ) {


		SAFE_XDELETE( p_filter );
		i_err = p_obj->query_interf( p_obj, STX_IID_BaseFilter, (void**)&p_filter);
		if( STX_OK != i_err ) {
			// only register the plugin filter;
			continue;
		}

		// if have filter interface;

		i_err = p_filter->enum_input_media_type( p_filter,&m,STX_NULL );
		if( STX_OK != i_err || m == MAX_MEDIA_TYPE ) { // skip emulator;
			goto fail;
		}

		i_err = h_xini->create_key( h_xini, h_gid, g_szStreamX_InputType, "0", &h_cat);
		if( STX_INI_OK != i_err ) {
			goto fail;
		}

		i_err = h_xini->write_int32(h_xini,h_cat,m);
		if( STX_INI_OK != i_err ) {
			goto fail;
		}

		for( j = 0; j < m; j ++ ) {

			i_err = p_filter->enum_input_media_type( p_filter,&j,&minf );
			if( STX_OK != i_err ) { // skip emulator;
				goto fail;
			}

			binary_to_string(sizeof(stx_gid),minf.major_type.data,sz_type);

			/* Major Type - 0 = ( 73646976-0000-0010-8000-00AA00389B71 vids ); */
			stx_sprintf(sz_key,sizeof(sz_key),"%s-%d",g_szStreamX_MajorDataType,j);
			i_err = h_xini->create_key( h_xini, h_cat, sz_key, sz_type, &h_type);
			if( STX_INI_OK != i_err ) {
				goto fail;
			}

			i_err = h_xini->create_key( h_xini, h_type, 
				g_szStreamX_MajorDataTypeName, *minf.major_type_name, &h_name );
			if( STX_INI_OK != i_err ) {
				goto fail;
			}

			binary_to_string(sizeof(stx_gid),minf.sub_type.data,sz_type);

			i_err = h_xini->create_key( h_xini, h_type, g_szStreamX_SubDataType, sz_type, &h_subtype);
			if( STX_INI_OK != i_err ) {
				goto fail;
			}

			i_err = h_xini->create_key( h_xini, h_type, 
				g_szStreamX_SubDataTypeName, *minf.sub_type_name, &h_name );
			if( STX_INI_OK != i_err ) {
				goto fail;
			}

		} /* for( j = 0; j < m; j ++ ) { */


		i_err = h_xini->create_key( h_xini, h_gid, g_szStreamX_OutputType, "0", &h_cat );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}

		i_err = p_filter->enum_output_media_type( p_filter,&m,STX_NULL );
		if( STX_OK != i_err || m == MAX_MEDIA_TYPE ) { // skip emulator;
			goto fail;
		}

		i_err = h_xini->write_int32(h_xini,h_cat,m);
		if( STX_INI_OK != i_err ) {
			goto fail;
		}

		for( j = 0; j < m; j ++ ) {

			i_err = p_filter->enum_output_media_type( p_filter,&j,&minf );
			if( STX_OK != i_err ) { // skip emulator;
				goto fail;
			}

			binary_to_string(sizeof(stx_gid),minf.major_type.data,sz_type);

			stx_sprintf(sz_key,sizeof(sz_key),"%s-%d",g_szStreamX_MajorDataType,j);
			i_err = h_xini->create_key( h_xini, h_cat, sz_key, sz_type, &h_type);
			if( STX_INI_OK != i_err ) {
				goto fail;
			}

			i_err = h_xini->create_key( h_xini, h_type, g_szStreamX_MajorDataTypeName, 
				*minf.major_type_name, &h_name);
			if( STX_INI_OK != i_err ) {
				goto fail;
			}

			binary_to_string(sizeof(stx_gid),minf.sub_type.data,sz_type);

			i_err = h_xini->create_key( h_xini, h_type, g_szStreamX_SubDataType, sz_type, &h_subtype);
			if( STX_INI_OK != i_err ) {
				goto fail;
			}

			i_err = h_xini->create_key( h_xini, h_type, g_szStreamX_SubDataTypeName, 
				*minf.sub_type_name, &h_name);
			if( STX_INI_OK != i_err ) {
				goto fail;
			}

		} /* for( j = 0; j < m; j ++ ) { */


delete_key:

		SAFE_XDELETE0( p_writer );
		SAFE_XDELETE0( p_source );
		SAFE_XDELETE0( p_filter );
		SAFE_XDELETE0( p_plug );
		SAFE_XDELETE0( p_helper );
		SAFE_XDELETE0( p_obj );

		if( i_err < 0 ) {
			i_err = h_xini->delete_key( h_xini, h_gid );
			if( STX_INI_OK != i_err ) {
				goto fail;
			}
		} /*if( i_err < 0 ) {*/

	} /*for( i = 0; i < i_filter_num; i ++ ) {*/

	i_err = STX_OK;

fail:

	SAFE_XDELETE( p_filter );
	SAFE_XDELETE( p_writer );
	SAFE_XDELETE( p_source );
	SAFE_XDELETE0( p_plug );
	SAFE_XDELETE0( p_helper );
	SAFE_XDELETE( p_obj );
	SAFE_XDELETE( p_module );

	if( h_dll ) {
		h_dll->close(h_dll);
	}

	return i_err;
}





/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT add_protocol_filter(THEE h,stx_gid cls_gid,char* sz_name)
{
	STX_MAP_THE(base_graph_builder);
	{
		STX_RESULT					i_err;
		stx_xini*					h_xini;
		STX_HANDLE					h_all;
		STX_HANDLE					h_clsid,h_svr;
		char						sz_cfg[1024];
		char						sz_gid[64];
		s32							i,i_val;

		i_err = STX_FAIL;
		h_xini = STX_NULL;

		INIT_MEMBER(sz_cfg);
		INIT_MEMBER(sz_gid);

		do{

			stx_module_lock(the->g_hMutex);

			stx_sprintf(sz_cfg, sizeof(sz_cfg),"%s"STX_SEP"%s",g_szStreamX_Root,"gbd.xini");

			// open xini;		
			i_err = stx_ini_create( sz_cfg, STX_NULL, STX_INI_READ_WRITE|STX_INI_NO_COMMENT, 0, &h_xini );
			if( STX_INI_OK != i_err ) {
				i_err = stx_ini_create( sz_cfg, STX_NULL, STX_INI_CREATE_NEW|STX_INI_NO_COMMENT, 0, &h_xini );
				if( STX_INI_OK != i_err ) {
					break;
				}
			}

			// read key;

			/*all Service ; */
			i_err = h_xini->create_key( h_xini, STX_NULL, g_szStreamX_AllService, "1", &h_all );
			if( STX_INI_OK != i_err ) {
				break;
			}

			binary_to_string(sizeof(stx_gid),cls_gid.data,sz_gid);

			i_err = h_xini->create_key( h_xini, h_all, sz_gid, sz_name,  &h_clsid );
			if( STX_INI_OK != i_err ) {
				break;
			}

			i_err = h_xini->create_key( h_xini, h_clsid, g_szStreamX_enable, "1",  &h_svr );
			if( STX_INI_OK != i_err ) {
				break;
			}

			i_err = STX_OK;

		}while(FALSE);

		SAFE_CLOSEXIO(h_xini);

		stx_module_unlock(the->g_hMutex);

		return i_err;
	}
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT rem_protocol_filter(THEE h,stx_gid cls_gid)
{
	STX_MAP_THE(base_graph_builder);
	{
		STX_RESULT					i_err;
		stx_xini*					h_xini;
		STX_HANDLE					h_all;
		STX_HANDLE					h_clsid;
		char						sz_cfg[1024];
		char						sz_gid[64];
		s32							i,i_val;

		i_err = STX_FAIL;
		h_xini = STX_NULL;

		INIT_MEMBER(sz_cfg);
		INIT_MEMBER(sz_gid);

		do{

			stx_module_lock(the->g_hMutex);

			stx_sprintf(sz_cfg, sizeof(sz_cfg),"%s"STX_SEP"%s",g_szStreamX_Root,"gbd.xini");

			// open xini;		
			i_err = stx_ini_create( sz_cfg, STX_NULL, STX_INI_READ_WRITE|STX_INI_NO_COMMENT, 0, &h_xini );
			if( STX_INI_OK != i_err ) {
				i_err = stx_ini_create( sz_cfg, STX_NULL, STX_INI_CREATE_NEW|STX_INI_NO_COMMENT, 0, &h_xini );
				break;
			}

			// read key;

			/*all Service ; */
			i_err = h_xini->create_key( h_xini, STX_NULL, g_szStreamX_AllService,NULL, &h_all );
			if( STX_INI_OK != i_err ) {
				break;
			}

			binary_to_string(sizeof(stx_gid),cls_gid.data,sz_gid);

			i_err = h_xini->create_key( h_xini, h_all, sz_gid, NULL,  &h_clsid );
			if( STX_INI_OK != i_err ) {
				break;
			}

			i_err = h_xini->delete_key( h_xini, h_clsid );
			if( STX_INI_OK != i_err ) {
				break;
			}

			i_err = STX_OK;

		}while(FALSE);

		SAFE_CLOSEXIO(h_xini);

		stx_module_unlock(the->g_hMutex);

		return i_err;
	}
}


/***********************************************************************************
RETURN VALUE: success, is STX_OK; or is a negative value;
INPUT:  sz_svr, the dll path and name;
OUTPUT: no output value;
NOTE: 
***********************************************************************************/
STX_PRIVATE STX_RESULT reg_protocol(THEE h, char* sz_svr,b32 b_reg )
{
	STX_MAP_THE(base_graph_builder);
	{
		STX_RESULT					i_err;
		s32							i_filter_num;
		s32							i,j;
		stx_gid						cls_gid;
		stx_gid						cat_gid;
		stx_base_com*				p_obj;
		stx_base_plugin*			p_plug;
		stx_dll*					h_dll;

		stx_base_module*			p_module;

		LP_STX_CREATE_MODULE_PROC(create_module) ;


		i_err = STX_FAIL;
		h_dll = STX_NULL;
		create_module = STX_NULL;
		p_obj = STX_NULL;
		p_module = STX_NULL;
		p_plug = STX_NULL;


		h_dll = stx_dll_create();
		if( !h_dll ) {
			goto fail;
		}

		i_err = h_dll->load_library( h_dll, sz_svr );
		if( STX_OK != i_err ) {
			goto fail;
		}

		create_module = (STX_CREATE_MODULE_PROC_PTR)h_dll->entry_by_name(
			h_dll, g_szStreamX_CreateModule );
		if( !create_module ) {
			goto fail;
		}

		p_module = create_module(&i_err,(stx_base_graph_builder*)h,stx_trace,the->g_i_debug);
		if( !p_module ) {
			goto fail;
		}

		i_filter_num = p_module->get_filter_num( p_module );
		if( !i_filter_num ) {
			i_err = STX_EOF;
			goto fail;
		}

		j = 0;

		for( i = 0; i < i_filter_num; i ++ ) {

			p_module->get_filter_gid(p_module,i,&cls_gid);

			/* the module registered as:  class gid value = class id; */

			i_err = p_module->create_instance( p_module, cls_gid, (void**)&p_obj );
			if( STX_OK != i_err ) {
				goto fail;
			}

			i_err = p_obj->query_interf( p_obj, STX_IID_BasePlugin, (void**)&p_plug);
			if( STX_OK != i_err ) {
				goto fail;
			}

			cat_gid = p_plug->get_catid(p_plug);

			if( IS_EQUAL_GID(STX_CATEGORY_BaseProtocol,cat_gid ) ) {

				if( b_reg ) {
					i_err = add_protocol_filter(h,cls_gid,XCALL(get_clsid_name,p_plug));
				}
				else {
					i_err = rem_protocol_filter(h,cls_gid);
				}

				if( STX_OK != i_err ) {
					goto fail;
				}

				j ++;

			} // if( IS_EQUAL_GID(STX_CATEGORY_BaseProtocol,cat_gid ) ) {

			SAFE_XDELETE0( p_plug );
			SAFE_XDELETE0( p_obj );

		} /*for( i = 0; i < i_filter_num; i ++ ) {*/

		if( 0 == j ) {
			i_err = STX_EOF;
		}
		else{
			i_err = STX_OK;
		}


fail:

		SAFE_XDELETE( p_plug );
		SAFE_XDELETE( p_obj );
		SAFE_XDELETE( p_module );

		if( h_dll ) {
			h_dll->close(h_dll);
		}

		return i_err;

	}
}

/***********************************************************************************
RETURN VALUE: success, is STX_OK; or is a negative value;
INPUT:  sz_svr, the dll path and name;
OUTPUT: no output value;
NOTE: 
***********************************************************************************/
STX_PURE STX_RESULT	stx_reg_protocol(THEE h, char* sz_svr )
{
	return reg_protocol(h,sz_svr,TRUE);
}

/***********************************************************************************
RETURN VALUE: success, is STX_OK; or is a negative value;
INPUT:  sz_svr, the dll path and name;
OUTPUT: no output value;
NOTE: 
***********************************************************************************/
STX_PURE STX_RESULT stx_unreg_protocol(THEE h, char* sz_svr )
{
	return reg_protocol(h,sz_svr,FALSE);
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT add_dlib(THEE h,char* sz_name)
{
	STX_MAP_THE(base_graph_builder);
	{
		STX_RESULT					i_err;
		stx_xini*					h_xini;
		STX_HANDLE					h_all,h_svr;
		char						sz_cfg[1024];

		i_err = STX_FAIL;
		h_xini = STX_NULL;

		INIT_MEMBER(sz_cfg);

		do{

			stx_module_lock(the->g_hMutex);

			stx_sprintf(sz_cfg, sizeof(sz_cfg),"%s"STX_SEP"%s",g_szStreamX_Root,"gbd.xini");

			// open xini;		
			i_err = stx_ini_create( sz_cfg, STX_NULL, STX_INI_READ_WRITE|STX_INI_NO_COMMENT, 0, &h_xini );
			if( STX_INI_OK != i_err ) {
				i_err = stx_ini_create( sz_cfg, STX_NULL, STX_INI_CREATE_NEW|STX_INI_NO_COMMENT, 0, &h_xini );
				if( STX_INI_OK != i_err ) {
					break;
				}
			}

			// read key;

			/*all Service ; */
			i_err = h_xini->create_key( h_xini, STX_NULL, g_szStreamX_AllDlib, "1", &h_all );
			if( STX_INI_OK != i_err ) {
				break;
			}

			i_err = h_xini->create_key( h_xini, h_all,  sz_name, "1", &h_svr );
			if( STX_INI_OK != i_err ) {
				break;
			}

			i_err = STX_OK;

		}while(FALSE);

		SAFE_CLOSEXIO(h_xini);

		stx_module_unlock(the->g_hMutex);

		return i_err;
	}
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT rem_dlib(THEE h,char* sz_name)
{
	STX_MAP_THE(base_graph_builder);
	{
		STX_RESULT					i_err;
		stx_xini*					h_xini;
		STX_HANDLE					h_all;
		STX_HANDLE					h_svr;
		char						sz_cfg[1024];

		i_err = STX_FAIL;
		h_xini = STX_NULL;

		INIT_MEMBER(sz_cfg);

		do{

			stx_module_lock(the->g_hMutex);

			stx_sprintf(sz_cfg, sizeof(sz_cfg),"%s"STX_SEP"%s",g_szStreamX_Root,"gbd.xini");

			// open xini;		
			i_err = stx_ini_create( sz_cfg, NULL, STX_INI_READ_WRITE|STX_INI_NO_COMMENT, 0, &h_xini );
			if( STX_INI_OK != i_err ) {
				i_err = stx_ini_create( sz_cfg, NULL, STX_INI_CREATE_NEW|STX_INI_NO_COMMENT, 0, &h_xini );
				break;
			}

			// read key;

			/*all Service ; */
			i_err = h_xini->create_key( h_xini, NULL, g_szStreamX_AllDlib,NULL, &h_all );
			if( STX_INI_OK != i_err ) {
				break;
			}

			i_err = h_xini->create_key( h_xini, h_all, sz_name, NULL,  &h_svr );
			if( STX_INI_OK != i_err ) {
				break;
			}

			i_err = h_xini->delete_key( h_xini, h_svr );
			if( STX_INI_OK != i_err ) {
				break;
			}

			i_err = STX_OK;

		}while(FALSE);

		SAFE_CLOSEXIO(h_xini);

		stx_module_unlock(the->g_hMutex);

		return i_err;
	}
}


/***********************************************************************************
RETURN VALUE: success, is STX_OK; or is a negative value;
INPUT:  sz_svr, the dll path and name;
OUTPUT: no output value;
NOTE: 
***********************************************************************************/
STX_PURE STX_RESULT	stx_reg_dlib(THEE h, char* sz_svr )
{
	STX_MAP_THE(base_graph_builder);
	{
		STX_RESULT					i_err;
		stx_dll*					h_dll;
		stx_base_module*			p_module;

		LP_STX_CREATE_MODULE_PROC(create_module) ;


		i_err = STX_FAIL;
		h_dll = STX_NULL;
		create_module = STX_NULL;
		p_module = STX_NULL;

		h_dll = stx_dll_create();
		if( !h_dll ) {
			goto fail;
		}

		i_err = h_dll->load_library( h_dll, sz_svr );
		if( STX_OK != i_err ) {
			goto fail;
		}

		create_module = (STX_CREATE_MODULE_PROC_PTR)h_dll->entry_by_name(
			h_dll, g_szStreamX_CreateModule );
		if( !create_module ) {
			goto fail;
		}

		p_module = create_module(&i_err,(stx_base_graph_builder*)h,stx_trace,the->g_i_debug);
		if( !p_module ) {
			goto fail;
		}

		i_err = add_dlib(h,sz_svr);


fail:
		SAFE_XDELETE( p_module );

		if( h_dll ) {
			h_dll->close(h_dll);
		}

		return i_err;

	}
}

/***********************************************************************************
RETURN VALUE: success, is STX_OK; or is a negative value;
INPUT:  sz_svr, the dll path and name;
OUTPUT: no output value;
NOTE: 
***********************************************************************************/
STX_PURE STX_RESULT stx_unreg_dlib(THEE h, char* sz_svr )
{
	return rem_dlib(h,sz_svr);
}


/***********************************************************************************
RETURN VALUE: success, is STX_OK; or is a negative value;
INPUT:  sz_svr, the dll path and name;
OUTPUT: no output value;
NOTE: 
***********************************************************************************/
STX_PURE STX_RESULT	stx_reg_svr( THEE h,char* sz_svr )
{
	STX_RESULT                  i_err;
	stx_xini*					h_xini;
	char						sz_cfg[1024];

	STX_MAP_THE(base_graph_builder);

	i_err = STX_FAIL;
	h_xini = STX_NULL;

	do{

		/* open StreamX xini configure file; */

		stx_sprintf(sz_cfg,sizeof(sz_cfg),"%s\\%s",g_szStreamX_Path,g_szStreamX_Cfg);

		i_err = stx_ini_create( sz_cfg, STX_NULL, STX_INI_READ_WRITE | STX_INI_NO_COMMENT, 0, &h_xini );
		if( STX_INI_OK != i_err ) {
			break;
		}

		i_err = stx_get_svr_inf(h,sz_svr,h_xini);

	}while(FALSE);

	if( h_xini ) {
		h_xini->close(h_xini);
	}

	return i_err;
}




/***********************************************************************************
stx_unreg_svr
RETURN VALUE: success, is STX_OK; or is a negative value;
INPUT:  sz_svr, the dll path and name;
OUTPUT: no output value;
NOTE: all the filter in the dll will be removed from streamx configure file;
***********************************************************************************/
STX_PURE STX_RESULT  stx_unreg_svr( THEE h,char* sz_svr )
{
	STX_RESULT					i_err;
	s32							i_filter_num;
	s32							i;
	char*						sz_gid;
	stx_gid						filter_gid;
	stx_xini*					h_xini;
	STX_HANDLE					h_all;
	STX_HANDLE					h_gid;
	stx_dll*					h_dll;

	stx_base_module*			p_module;
	char						sz_cfg[1024];

	LP_STX_CREATE_MODULE_PROC(create_module);

	STX_MAP_THE(base_graph_builder);

	i_err = STX_FAIL;
	sz_gid = STX_NULL;
	h_xini = STX_NULL;
	h_dll = STX_NULL;
	create_module = STX_NULL;
	p_module = STX_NULL;

	stx_module_lock( the->g_hMutex);

	/* open StreamX xini configure file; */

	stx_sprintf( sz_cfg, sizeof(sz_cfg),"%s\\%s", g_szStreamX_Path, g_szStreamX_Cfg );

	i_err = stx_ini_create( sz_cfg, STX_NULL, STX_INI_READ_WRITE | STX_INI_NO_COMMENT, 0, &h_xini );
	if( STX_INI_OK != i_err ) {
		goto fail;
	}

	/* all modules ; */
	i_err = h_xini->create_key( h_xini, STX_NULL, g_szStreamX_AllModule, STX_NULL, &h_all );
	if( STX_INI_OK != i_err ) {
		goto fail;
	}

	h_dll = stx_dll_create();
	if( !h_dll ) {
		goto fail;
	}

	i_err = h_dll->load_library( h_dll, sz_svr );
	if( STX_OK != i_err ) {
		goto fail;
	}

	create_module = (STX_CREATE_MODULE_PROC_PTR)
		h_dll->entry_by_name(h_dll, g_szStreamX_CreateModule );

	if( !create_module ) {
		goto fail;
	}

	p_module = create_module(&i_err,(stx_base_graph_builder*)h,stx_trace,the->g_i_debug);
	if( !p_module ) {
		goto fail;
	}

	i_filter_num = p_module->get_filter_num( p_module );
	if( !i_filter_num ) {
		goto fail;
	}

	for( i = 0; i < i_filter_num; i ++ ) {

		p_module->get_filter_gid(p_module,i,&filter_gid);
		sz_gid = stx_gid_to_string(filter_gid);
		if( !sz_gid ) {
			goto fail;
		}

		/* the module with class gid ; */
		/* module path; */
		i_err = h_xini->create_key( h_xini, h_all, sz_gid, sz_svr, &h_gid );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		stx_gid_close_string( &sz_gid );

		i_err = h_xini->delete_key( h_xini, h_gid );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}

	} /*for( i = 0; i < i_filter_num; i ++ ) {*/

	i_err = STX_OK;

fail:

	if( sz_gid ) {
		stx_gid_close_string(&sz_gid);
	}

	if( p_module ) {
		p_module->release(p_module);
	}

	if( h_dll ) {
		h_dll->close(h_dll);
	}

	if( h_xini ) {
		h_xini->close(h_xini);
	}

	stx_module_unlock( the->g_hMutex );

	return i_err;
}





/***********************************************************************************
stx_reg_query_input_type
RETURN VALUE: success, is STX_OK; or is a negative value;
INPUT:  
OUTPUT: 
NOTE: 
***********************************************************************************/
STX_PURE STX_RESULT	stx_reg_query_input_type
( 
	THEE					h,
	stx_gid					major_type, 
	stx_gid					sub_type,
	stx_connect_ctx*		p_con_ctx 
)
{

	STX_RESULT					i_err;
	s32							i_filter_num;
	s32							i_pin_num;
	s32							i,j,k;
	char*						sz_gid;
	char*						sz_type;
	stx_gid						cls_gid;
	stx_gid						filter_gid;
	stx_gid						md_type;
	stx_gid						md_subtype;
	stx_xini*					h_xini;

	STX_HANDLE					h_all;
	STX_HANDLE					h_gid;
	STX_HANDLE					h_pin;
	STX_HANDLE					h_item;
	STX_HANDLE					h_type;
	char						sz_cfg[1024];
	char						sz_key[1024];


	STX_MAP_THE(base_graph_builder);

	i_err = STX_FAIL;
	sz_gid = STX_NULL;
	sz_type = STX_NULL;
	h_xini = STX_NULL;

	/* open StreamX xini configure file; */

	stx_sprintf(sz_cfg,sizeof(sz_cfg),"%s\\%s",g_szStreamX_Path,g_szStreamX_Cfg);

	i_err = stx_ini_create( sz_cfg, STX_NULL, STX_INI_READ_ONLY, 0, &h_xini );
	if( STX_INI_OK != i_err ) {
		goto fail;
	}

	/* all modules ; */
	i_err = h_xini->create_key( h_xini, STX_NULL, g_szStreamX_AllModule, STX_NULL, &h_all );
	if( STX_INI_OK != i_err ) {
		goto fail;
	}

	i_err = h_xini->get_sub_key_num(h_xini,h_all,&i_filter_num);
	if( STX_INI_OK != i_err ) {
		goto fail;
	}
	if( !i_filter_num ) {
		goto fail;
	}

	for( i = 0; i < i_filter_num; i ++ ) {

		i_err = h_xini->get_sub_key( h_xini, h_all, i, &h_gid );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		i_err = h_xini->read_key( h_xini, h_gid, &sz_gid );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		filter_gid = stx_gid_from_string(sz_gid);

		for( k = 0; k < p_con_ctx->get_skip_cls_num(p_con_ctx); k ++ ) {
			i_err = p_con_ctx->get_skip_cls_gid(p_con_ctx,k,&cls_gid);
			if( STX_OK != i_err ) {
				goto fail;
			}
			if( IS_EQUAL_GID(filter_gid,cls_gid) ) {
				goto next_filter;
			}
		}

		i_err = h_xini->create_key( h_xini, h_gid, g_szStreamX_InputPin, STX_NULL, &h_pin );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}

		i_err = h_xini->read_int32( h_xini, h_pin, &i_pin_num );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		if( !i_pin_num ) {
			continue;
		}


		for( j = 0; j < i_pin_num; j ++ ) {

			stx_sprintf(sz_key,sizeof(sz_key),"%s-%d", g_szStreamX_InputPin, j );
			i_err = h_xini->create_key( h_xini, h_pin, sz_key, sz_type, &h_item );
			if( STX_INI_OK != i_err ) {
				goto fail;
			}

			i_err = h_xini->read_string(h_xini,h_item,&sz_type);
			if( STX_INI_OK != i_err ) {
				goto fail;
			}
			md_type = stx_gid_from_string(sz_type); 

			if( !IS_EQUAL_GID(md_type,major_type) ) {
				continue;
			}

			i_err = h_xini->create_key( h_xini, h_item, g_szStreamX_SubDataType,STX_NULL, &h_type );
			if( STX_INI_OK != i_err ) {
				goto fail;
			}

			i_err = h_xini->read_string(h_xini,h_item,&sz_type);
			if( STX_INI_OK != i_err ) {
				goto fail;
			}
			md_subtype = stx_gid_from_string(sz_type); 

			if( !IS_EQUAL_GID(md_subtype,sub_type) ) {
				continue;
			}

			i_err = h_xini->create_key( h_xini, h_gid, g_szStreamX_OutputPin, STX_NULL, &h_pin );
			if( STX_INI_OK != i_err ) {
				goto fail;
			}

			i_err = h_xini->read_int32( h_xini, h_pin, &i_pin_num );
			if( STX_INI_OK != i_err ) {
				goto fail;
			}

			i_err = p_con_ctx->set_cur_cls_gid(p_con_ctx,filter_gid);
			if( STX_OK != i_err ) {
				goto fail;
			}
			i_err = p_con_ctx->set_cur_cls_pin_num(p_con_ctx,i_pin_num);
			if( STX_OK != i_err ) {
				goto fail;
			}

			for( k  = 0;  k < i_pin_num;  k ++   ) {

				stx_sprintf(sz_key,sizeof(sz_key),"%s-%d", g_szStreamX_OutputPin, k );
				i_err = h_xini->create_key( h_xini, h_pin, sz_key, sz_type, &h_item );
				if( STX_INI_OK != i_err ) {
					goto fail;
				}

				i_err = h_xini->read_string(h_xini,h_item,&sz_type);
				if( STX_INI_OK != i_err ) {
					goto fail;
				}
				md_type = stx_gid_from_string(sz_type); 

				i_err = h_xini->create_key( h_xini, h_item, g_szStreamX_SubDataType,STX_NULL, &h_type );
				if( STX_INI_OK != i_err ) {
					goto fail;
				}

				i_err = h_xini->read_string(h_xini,h_item,&sz_type);
				if( STX_INI_OK != i_err ) {
					goto fail;
				}
				md_subtype = stx_gid_from_string(sz_type); 

				i_err = p_con_ctx->set_cur_cls_pin_type(p_con_ctx,k,md_type,md_subtype);
				if( STX_OK != i_err ) {
					goto fail;
				}

			} /* for( k  = 0;  k < i_pin_num;  k ++   ) { */

			i_err = STX_OK;

			goto fail;

		} /*for( j = 0; j < i_pin_num; j ++ ) {*/

next_filter:
		continue;

	} /*for( i = 0; i < i_filter_num; i ++ ) {*/

	i_err = STX_EOF;  /* no compatible filter found; */ 

fail:

	if( h_xini ) {
		h_xini->close(h_xini);
	}

	return i_err;
}


/***********************************************************************************
stx_reg_query_src_ext
RETURN VALUE: success, is STX_OK; or is a negative value;
INPUT:  
OUTPUT: 
NOTE: 
***********************************************************************************/
STX_PURE STX_RESULT	stx_reg_query_src_ext
(THEE h, char*	sz_ext,stx_connect_ctx*	p_con_ctx )
{
	STX_RESULT					i_err;
	s32							i,j,i_all_streams,i_all_ext;
	char*						sz_major_type;
	char*						sz_sub_type;
	char*						sz_tmp_ext;
	stx_xini*					h_xini;

	STX_HANDLE					h_all;
	STX_HANDLE					h_major_type;
	STX_HANDLE					h_sub_type;
	STX_HANDLE					h_ext;
	char						sz_cfg[1024];
	char						sz_key[1024];

	char						sz_ext_upr[1024];

	STX_MAP_THE(base_graph_builder);

	i_err = STX_FAIL;
	h_xini = STX_NULL;
	sz_major_type = STX_NULL;
	sz_sub_type = STX_NULL;



	/* open StreamX xini configure file; */

	stx_sprintf(sz_cfg,sizeof(sz_cfg),"%s\\%s",g_szStreamX_Path,g_szStreamX_Cfg);

	i_err = stx_ini_create( sz_cfg, STX_NULL, STX_INI_READ_WRITE, 0, &h_xini );
	if( STX_INI_OK != i_err ) {
		goto fail;
	}

	/* all streams key; */
	i_err = h_xini->create_key( h_xini, STX_NULL, g_szStreamX_AllStream, STX_NULL, &h_all );
	if( STX_INI_OK != i_err ) {
		goto fail;
	}

	i_err = h_xini->get_sub_key_num( h_xini, h_all,&i_all_streams);
	if( STX_INI_OK != i_err ) {
		goto fail;
	}

	stx_strcpy(sz_ext_upr,sizeof(sz_ext_upr),sz_ext);
	stx_strupr(sz_ext_upr,sizeof(sz_ext_upr));

	for( i = 0; i < i_all_streams; i ++ ) {

		i_err = h_xini->get_sub_key( h_xini, h_all, i, &h_major_type );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}

		i_err = h_xini->read_string( h_xini, h_major_type, &sz_major_type );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}

		/* for example: 
		Sub Type = e436eb89-524f-11ce-9f53-0020af0ba770( sub type gid: MEDIASUBTYPE_QTMovie ); */
		i_err = h_xini->create_key( h_xini, h_major_type, g_szStreamX_SubDataType, STX_NULL,  &h_sub_type );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}

		i_err = h_xini->read_string( h_xini, h_sub_type, &sz_sub_type );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}

		i_err = h_xini->get_sub_key_num( h_xini, h_sub_type, &i_all_ext);
		if( STX_INI_OK != i_err ) {
			goto fail;
		}

		for( j = 0 ; j < i_all_ext; j ++ ) {

			stx_sprintf( sz_key, sizeof(sz_key),"%s-%d", g_szStreamX_Extension,i);

			i_err = h_xini->create_key( h_xini, h_sub_type, sz_key, STX_NULL, &h_ext );

			if( STX_INI_OK != i_err ) {
				goto fail;
			}

			i_err = h_xini->read_key( h_xini, h_ext, &sz_tmp_ext );
			if( STX_INI_OK != i_err ) {
				goto fail;
			}

			if( ! strcmp(sz_tmp_ext,sz_ext_upr ) ) {

				/* found, add to connect context ;*/

				i_err = p_con_ctx->set_cur_cls_pin_num(p_con_ctx,1);
				if( STX_OK != i_err ) {
					goto fail;
				}

				i_err = p_con_ctx->set_cur_cls_pin_type(
					p_con_ctx,
					0,
					stx_gid_from_string(sz_major_type),
					stx_gid_from_string(sz_sub_type) );

				if( STX_OK != i_err ) {
					goto fail;
				}

				i_err = STX_OK;

				goto fail;

			}/* if( ! strcmp(sz_tmp_ext,sz_ext ) ) { */

		} /* for( j = 0 ; j < i_all_ext; j ++ ) { */

	} /* for( i = 0; i < i_all_streams; i ++ ) { */


	i_err = STX_ERR_FILE_NOT_FOUND;

fail:

	if( h_xini ) {
		h_xini->close(h_xini);
	}

	return i_err;

}



/***********************************************************************************
stx_reg_stream
RETURN VALUE: success, is STX_OK; or is a negative value;
INPUT:  
OUTPUT: 
NOTE: 
***********************************************************************************/
STX_PURE STX_RESULT  stx_reg_stream(THEE h,stx_reg_stream_ctx* h_stream)
{
	STX_RESULT					i_err;
	s32							i;
	char						sz_major_type[64];
	char						sz_sub_type[64];
	stx_xini*					h_xini;

	STX_HANDLE					h_all;
	STX_HANDLE					h_major_type;
	STX_HANDLE					h_sub_type;
	STX_HANDLE					h_ext;
	char						sz_cfg[1024];
	char						sz_key[1024];

	STX_MAP_THE(base_graph_builder);

	i_err = STX_FAIL;
	h_xini = STX_NULL;

	binary_to_string(sizeof(stx_gid),(u8*)h_stream->major_type,sz_major_type);

	binary_to_string(sizeof(stx_gid),(u8*)h_stream->sub_type,sz_sub_type);

	/* open StreamX xini configure file; */

	stx_sprintf(sz_cfg,sizeof(sz_cfg),"%s\\%s",g_szStreamX_Path,g_szStreamX_Cfg);

	i_err = stx_ini_create( sz_cfg, STX_NULL, STX_INI_READ_WRITE | STX_INI_NO_COMMENT, 0, &h_xini );
	if( STX_INI_OK != i_err ) {
		goto fail;
	}

	/* all streams key; */
	i_err = h_xini->create_key( h_xini, STX_NULL, g_szStreamX_AllStream, STX_NULL, &h_all );
	if( STX_INI_OK != i_err ) {
		goto fail;
	}

	/* major type key; 
	for example: (major type gid: MEDIATYPE_Video )
	73646976-0000-0010-8000-00AA00389B71 = video file;	*/
	i_err = h_xini->create_key( h_xini, h_all, sz_major_type, h_stream->sz_major_name,  &h_major_type );
	if( STX_INI_OK != i_err ) {
		goto fail;
	}

	/* for example: (sub type gid: MEDIASUBTYPE_QTMovie ) 
	e436eb89-524f-11ce-9f53-0020af0ba770 = quick time movies; */
	i_err = h_xini->create_key( h_xini, h_major_type, sz_sub_type, h_stream->sz_sub_name,   &h_sub_type );
	if( STX_INI_OK != i_err ) {
		goto fail;
	}

	// split;
	{
		char	val;
		char*	p;
		char*   s;
		char*   end;
		char    sz_ext[256];

		i = 0;
		p = h_stream->sz_ext;
		end = h_stream->sz_ext + sizeof(h_stream->sz_ext);

		s = sz_ext;

		for( ; ; ) {

			if( p >= end ){
				break;
			}

			val = *p++;

			if( ',' ==  val || !val ) {
				if( s != sz_ext ) {
					*s++ = 0;
					stx_strupr(sz_ext,sizeof(sz_ext));
					stx_sprintf( sz_key, sizeof(sz_key),"%s-%d", g_szStreamX_Extension,i);
					i_err = h_xini->create_key( h_xini, h_sub_type, sz_ext ,sz_key,  &h_ext );
					if( STX_INI_OK != i_err ) {
						goto fail;
					}
					i ++;
					s = sz_ext;
				}
			}
			else if( ' ' != val ) {
				*s++ = val;
			}

			if( !val ) {
				break;
			}

		} // for( ; ; ) {

	} // block;

	if( i == 0 ) {
		i_err = STX_FAIL;
		goto fail;
	}

	i_err = STX_OK;

fail:

	if( h_xini ) {
		h_xini->close(h_xini);
	}

	return i_err;
}



/***********************************************************************************
RETURN VALUE: success, is STX_OK; or is a negative value;
INPUT:  
OUTPUT: 
NOTE: 
***********************************************************************************/
STX_PURE STX_RESULT  stx_unreg_stream(THEE h,stx_reg_stream_ctx* h_stream)
{
	STX_RESULT					i_err;
	s32							i;
	char						sz_major_type[64];
	char						sz_sub_type[64];
	stx_xini*					h_xini;

	STX_HANDLE					h_all;
	STX_HANDLE					h_major_type;
	STX_HANDLE					h_sub_type;
	STX_HANDLE					h_ext;
	char						sz_cfg[1024];

	STX_MAP_THE(base_graph_builder);

	i_err = STX_FAIL;
	h_xini = STX_NULL;

	binary_to_string(sizeof(stx_gid),(u8*)h_stream->major_type,sz_major_type);

	binary_to_string(sizeof(stx_gid),(u8*)h_stream->sub_type,sz_sub_type);

	/* open StreamX xini configure file; */

	stx_sprintf(sz_cfg,sizeof(sz_cfg),"%s\\%s",g_szStreamX_Path,g_szStreamX_Cfg);

	i_err = stx_ini_create( sz_cfg, STX_NULL, STX_INI_READ_WRITE| STX_INI_NO_COMMENT, 0, &h_xini );
	if( STX_INI_OK != i_err ) {
		goto fail;
	}

	/* all streams key; */
	i_err = h_xini->create_key( h_xini, STX_NULL, g_szStreamX_AllStream, STX_NULL, &h_all );
	if( STX_INI_OK != i_err ) {
		goto fail;
	}

	/* major type key; 
	for example: (major type gid: MEDIATYPE_Video )
	73646976-0000-0010-8000-00AA00389B71 = video file;	*/
	i_err = h_xini->create_key( h_xini, h_all, sz_major_type, h_stream->sz_major_name,  &h_major_type );
	if( STX_INI_OK != i_err ) {
		goto fail;
	}

	/* for example: (sub type gid: MEDIASUBTYPE_QTMovie ) 
	e436eb89-524f-11ce-9f53-0020af0ba770 = quick time movies; */
	i_err = h_xini->create_key( h_xini, h_major_type, sz_sub_type, h_stream->sz_sub_name,   &h_sub_type );
	if( STX_INI_OK != i_err ) {
		goto fail;
	}

	// split;
	{
		char	val;
		char*	p;
		char*   s;
		char*   end;
		char    sz_ext[256];

		i = 0;
		p = h_stream->sz_ext;
		end = h_stream->sz_ext + sizeof(h_stream->sz_ext);

		s = sz_ext;

		for( ; ; ) {

			if( p >= end ){
				break;
			}

			val = *p++;

			if( ',' ==  val || !val ) {
				if( s != sz_ext ) {
					*s++ = 0;
					stx_strupr(sz_ext,sizeof(sz_ext));
					i_err = h_xini->create_key( h_xini, h_sub_type, sz_ext ,NULL,  &h_ext );
					if( STX_INI_OK == i_err ) {
						i_err = h_xini->delete_key( h_xini,h_ext );
						if( STX_INI_OK != i_err ) {
							goto fail;
						}
					}
					i ++;
					s = sz_ext;
				}
			}
			else if( ' ' != val ) {
				*s++ = val;
			}

			if( !val ) {
				break;
			}

		} // for( ; ; ) {

	} // block;

	if( i == 0 ) {
		i_err = STX_FAIL;
		goto fail;
	}

	i_err = STX_OK;

fail:

	if( h_xini ) {
		h_xini->close(h_xini);
	}

	return i_err;

}

/***********************************************************************************
stx_reg_query_src_type
RETURN VALUE: success, is STX_OK; or is a negative value;
INPUT:  
OUTPUT: 
NOTE: 
***********************************************************************************/
STX_PURE STX_RESULT	stx_reg_query_src_type
( 
	THEE					h,
	stx_gid					major_type,
	stx_gid					sub_type,
	stx_connect_ctx*		p_con_ctx 
)
{
	STX_RESULT					i_err;
	s32							i_filter_num;
	s32							i_pin_num;
	s32							i,j,k;
	char*						sz_gid;
	char*						sz_type;
	char*						sz_cat;
	stx_gid						cls_gid;
	stx_gid						cat_gid;
	stx_gid						filter_gid;
	stx_gid						md_type;
	stx_gid						md_subtype;
	stx_xini*					h_xini;

	STX_HANDLE					h_all;
	STX_HANDLE					h_gid;
	STX_HANDLE					h_pin;
	STX_HANDLE					h_item;
	STX_HANDLE					h_type;
	char						sz_cfg[1024];
	char						sz_key[1024];


	STX_MAP_THE(base_graph_builder);

	i_err = STX_FAIL;
	sz_gid = STX_NULL;
	sz_type = STX_NULL;
	h_xini = STX_NULL;

	/* open StreamX xini configure file; */

	stx_sprintf(sz_cfg,sizeof(sz_cfg),"%s\\%s",g_szStreamX_Path,g_szStreamX_Cfg);

	i_err = stx_ini_create( sz_cfg, STX_NULL, STX_INI_READ_ONLY, 0, &h_xini );
	if( STX_INI_OK != i_err ) {
		goto fail;
	}

	/* all modules ; */
	i_err = h_xini->create_key( h_xini, STX_NULL, g_szStreamX_AllModule, STX_NULL, &h_all );
	if( STX_INI_OK != i_err ) {
		goto fail;
	}

	i_err = h_xini->get_sub_key_num(h_xini,h_all,&i_filter_num);
	if( STX_INI_OK != i_err ) {
		goto fail;
	}
	if( !i_filter_num ) {
		goto fail;
	}

	for( i = 0; i < i_filter_num; i ++ ) {

		i_err = h_xini->get_sub_key( h_xini, h_all, i, &h_gid );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		i_err = h_xini->read_key( h_xini, h_gid, &sz_gid );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		filter_gid = stx_gid_from_string(sz_gid);

		for( k = 0; k < p_con_ctx->get_skip_cls_num(p_con_ctx); k ++ ) {
			i_err = p_con_ctx->get_skip_cls_gid(p_con_ctx,k,&cls_gid);
			if( STX_OK != i_err ) {
				goto fail;
			}
			if( IS_EQUAL_GID(filter_gid,cls_gid) ) {
				goto next_filter;
			}
		}

		i_err = h_xini->create_key( h_xini, h_gid, g_szStreamX_MainCategory, STX_NULL, &h_pin );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}

		i_err = h_xini->read_string( h_xini, h_pin, &sz_cat );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		cat_gid = stx_gid_from_string(sz_cat);

		if( !IS_EQUAL_GID(cat_gid,STX_CATEGORY_FileSource) ) {
			continue;
		}

		i_err = h_xini->create_key( h_xini, h_gid, g_szStreamX_InputPin, STX_NULL, &h_pin );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}

		i_err = h_xini->read_int32( h_xini, h_pin, &i_pin_num );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		if( !i_pin_num ) {
			continue;
		}


		for( j = 0; j < i_pin_num; j ++ ) {

			stx_sprintf(sz_key,sizeof(sz_key),"%s-%d", g_szStreamX_InputPin, j );
			i_err = h_xini->create_key( h_xini, h_pin, sz_key, sz_type, &h_item );
			if( STX_INI_OK != i_err ) {
				goto fail;
			}

			i_err = h_xini->read_string(h_xini,h_item,&sz_type);
			if( STX_INI_OK != i_err ) {
				goto fail;
			}
			md_type = stx_gid_from_string(sz_type); 

			if( !IS_EQUAL_GID(md_type,major_type) ) {
				continue;
			}

			i_err = h_xini->create_key( h_xini, h_item, g_szStreamX_SubDataType,STX_NULL, &h_type );
			if( STX_INI_OK != i_err ) {
				goto fail;
			}

			i_err = h_xini->read_string(h_xini,h_item,&sz_type);
			if( STX_INI_OK != i_err ) {
				goto fail;
			}
			md_subtype = stx_gid_from_string(sz_type); 

			if( !IS_EQUAL_GID(md_subtype,sub_type) ) {
				continue;
			}

			i_err = p_con_ctx->add_con_cls_gid(p_con_ctx,filter_gid);
			if( STX_OK != i_err ) {
				goto fail;
			}

			break;

		} /*for( j = 0; j < i_pin_num; j ++ ) {*/

next_filter:
		continue;

	} /*for( i = 0; i < i_filter_num; i ++ ) {*/

	if( !p_con_ctx->get_con_cls_num(p_con_ctx)) {

		i_err = STX_EOF;  /* no compatible filter found; */ 
	}
	else {
		i_err = STX_OK;
	}


fail:

	if( h_xini ) {
		h_xini->close(h_xini);
	}

	return i_err;

}



/***********************************************************************************
stx_reg_query_flt_type
RETURN VALUE: success, is STX_OK; or is a negative value;
INPUT:  
OUTPUT: 
NOTE: 
***********************************************************************************/
STX_PURE STX_RESULT	stx_reg_query_flt_type
( 
THEE				h,
stx_gid				major_type_in,
stx_gid				sub_type_in,
stx_gid				major_type_out,
stx_gid				sub_type_out,
stx_connect_ctx*	p_con_ctx 
)
{
	STX_RESULT					i_err;
	s32							i_filter_num;
	s32							i_pin_num;
	s32							i,j,k;
	char*						sz_gid;
	char*						sz_type;
	char*						sz_cat;
	stx_gid						cls_gid;
	stx_gid						cat_gid;
	stx_gid						filter_gid;
	stx_gid						md_type;
	stx_gid						md_subtype;
	stx_xini*					h_xini;

	STX_HANDLE					h_all;
	STX_HANDLE					h_gid;
	STX_HANDLE					h_pin;
	STX_HANDLE					h_item;
	STX_HANDLE					h_type;
	char						sz_cfg[1024];
	char						sz_key[1024];

	STX_MAP_THE(base_graph_builder);

	i_err = STX_FAIL;
	sz_gid = STX_NULL;
	sz_type = STX_NULL;
	h_xini = STX_NULL;

	/* open StreamX xini configure file; */

	stx_sprintf(sz_cfg,sizeof(sz_cfg),"%s\\%s",g_szStreamX_Path,g_szStreamX_Cfg);

	i_err = stx_ini_create( sz_cfg, STX_NULL, STX_INI_READ_ONLY, 0, &h_xini );
	if( STX_INI_OK != i_err ) {
		goto fail;
	}

	/* all modules ; */
	i_err = h_xini->create_key( h_xini, STX_NULL, g_szStreamX_AllModule, STX_NULL, &h_all );
	if( STX_INI_OK != i_err ) {
		goto fail;
	}

	i_err = h_xini->get_sub_key_num(h_xini,h_all,&i_filter_num);
	if( STX_INI_OK != i_err ) {
		goto fail;
	}
	if( !i_filter_num ) {
		goto fail;
	}

	for( i = 0; i < i_filter_num; i ++ ) {

		i_err = h_xini->get_sub_key( h_xini, h_all, i, &h_gid );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		i_err = h_xini->read_key( h_xini, h_gid, &sz_gid );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		filter_gid = stx_gid_from_string(sz_gid);

		for( k = 0; k < p_con_ctx->get_skip_cls_num(p_con_ctx); k ++ ) {
			i_err = p_con_ctx->get_skip_cls_gid(p_con_ctx,k,&cls_gid);
			if( STX_OK != i_err ) {
				goto fail;
			}
			if( IS_EQUAL_GID(filter_gid,cls_gid) ) {
				goto next_filter;
			}
		}

		i_err = h_xini->create_key( h_xini, h_gid, g_szStreamX_MainCategory, STX_NULL, &h_pin );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}

		i_err = h_xini->read_string( h_xini, h_pin, &sz_cat );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		cat_gid = stx_gid_from_string(sz_cat);

		if( !IS_EQUAL_GID(cat_gid,STX_CATEGORY_IntermediateFilter)  ) {
			continue;
		}

		if( !IS_EQUAL_GID(major_type_in,STX_GID_NULL) ) {

			i_err = h_xini->create_key( h_xini, h_gid, g_szStreamX_InputPin, STX_NULL, &h_pin );
			if( STX_INI_OK != i_err ) {
				goto fail;
			}

			i_err = h_xini->read_int32( h_xini, h_pin, &i_pin_num );
			if( STX_INI_OK != i_err ) {
				goto fail;
			}
			if( !i_pin_num ) {
				continue;
			}


			for( j = 0; j < i_pin_num; j ++ ) {

				stx_sprintf(sz_key,sizeof(sz_key),"%s-%d", g_szStreamX_InputPin, j );
				i_err = h_xini->create_key( h_xini, h_pin, sz_key, sz_type, &h_item );
				if( STX_INI_OK != i_err ) {
					goto fail;
				}

				i_err = h_xini->read_string(h_xini,h_item,&sz_type);
				if( STX_INI_OK != i_err ) {
					goto fail;
				}
				md_type = stx_gid_from_string(sz_type); 

				if( !IS_EQUAL_GID(md_type,major_type_in) ) {
					continue;
				}

				i_err = h_xini->create_key( h_xini, h_item, g_szStreamX_SubDataType,STX_NULL, &h_type );
				if( STX_INI_OK != i_err ) {
					goto fail;
				}

				i_err = h_xini->read_string(h_xini,h_item,&sz_type);
				if( STX_INI_OK != i_err ) {
					goto fail;
				}
				md_subtype = stx_gid_from_string(sz_type); 

				if( !IS_EQUAL_GID(md_subtype,sub_type_in) ) {
					continue;
				}

				break;

			} /*for( j = 0; j < i_pin_num; j ++ ) {*/

			if( j == i_pin_num ){
				continue;
			}

		} /* if( !IS_EQUAL_GID(major_type_in,STX_GID_NULL) ) { */

		if( IS_EQUAL_GID(major_type_out,STX_GID_NULL) ) {

			i_err = p_con_ctx->add_con_cls_gid(p_con_ctx,filter_gid);
			if( STX_OK != i_err ) {
				goto fail;
			}

			continue;

		}/* if( IS_EQUAL_GID(major_type_out,STX_GID_NULL) ) { */


		i_err = h_xini->create_key( h_xini, h_gid, g_szStreamX_OutputPin, STX_NULL, &h_pin );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}

		i_err = h_xini->read_int32( h_xini, h_pin, &i_pin_num );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		if( !i_pin_num ) {
			continue;
		}

		for( j = 0; j < i_pin_num; j ++ ) {

			stx_sprintf(sz_key,sizeof(sz_key),"%s-%d", g_szStreamX_InputPin, j );
			i_err = h_xini->create_key( h_xini, h_pin, sz_key, sz_type, &h_item );
			if( STX_INI_OK != i_err ) {
				goto fail;
			}

			i_err = h_xini->read_string(h_xini,h_item,&sz_type);
			if( STX_INI_OK != i_err ) {
				goto fail;
			}
			md_type = stx_gid_from_string(sz_type); 

			if( !IS_EQUAL_GID(md_type,major_type_out) ) {
				continue;
			}

			i_err = h_xini->create_key( h_xini, h_item, g_szStreamX_SubDataType,STX_NULL, &h_type );
			if( STX_INI_OK != i_err ) {
				goto fail;
			}

			i_err = h_xini->read_string(h_xini,h_item,&sz_type);
			if( STX_INI_OK != i_err ) {
				goto fail;
			}
			md_subtype = stx_gid_from_string(sz_type); 

			if( !IS_EQUAL_GID(md_subtype,sub_type_out) ) {
				continue;
			}

			i_err = p_con_ctx->add_con_cls_gid(p_con_ctx,filter_gid);
			if( STX_OK != i_err ) {
				goto fail;
			}

			break;

		} /*for( j = 0; j < i_pin_num; j ++ ) {*/



next_filter:
		continue;

	} /*for( i = 0; i < i_filter_num; i ++ ) {*/

	if( !p_con_ctx->get_con_cls_num(p_con_ctx)) {
		i_err = STX_EOF;  /* no compatible filter found; */ 
	}
	else {
		i_err = STX_OK;
	}


fail:

	if( h_xini ) {
		h_xini->close(h_xini);
	}

	return i_err;

}




/***********************************************************************************
stx_reg_query_ren_type
RETURN VALUE: success, is STX_OK; or is a negative value;
INPUT:  
OUTPUT: 
NOTE: 
***********************************************************************************/
STX_PURE STX_RESULT	stx_reg_query_ren_type
( 
THEE					h,
stx_gid					major_type,
stx_gid					sub_type,
stx_connect_ctx*		p_con_ctx 
)
{
	STX_RESULT					i_err;
	s32							i_filter_num;
	s32							i_pin_num;
	s32							i,j,k;
	char*						sz_gid;
	char*						sz_type;
	char*						sz_cat;
	stx_gid						cls_gid;
	stx_gid						cat_gid;
	stx_gid						filter_gid;
	stx_gid						md_type;
	stx_gid						md_subtype;
	stx_xini*					h_xini;

	STX_HANDLE					h_all;
	STX_HANDLE					h_gid;
	STX_HANDLE					h_pin;
	STX_HANDLE					h_item;
	STX_HANDLE					h_type;
	char						sz_cfg[1024];
	char						sz_key[1024];

	STX_MAP_THE(base_graph_builder);

	i_err = STX_FAIL;
	sz_gid = STX_NULL;
	sz_type = STX_NULL;
	h_xini = STX_NULL;

	/* open StreamX xini configure file; */

	stx_sprintf(sz_cfg,sizeof(sz_cfg),"%s\\%s",g_szStreamX_Path,g_szStreamX_Cfg);

	i_err = stx_ini_create( sz_cfg, STX_NULL, STX_INI_READ_ONLY, 0,&h_xini );
	if( STX_INI_OK != i_err ) {
		goto fail;
	}

	/* all modules ; */
	i_err = h_xini->create_key( h_xini, STX_NULL, g_szStreamX_AllModule, STX_NULL, &h_all );
	if( STX_INI_OK != i_err ) {
		goto fail;
	}

	i_err = h_xini->get_sub_key_num(h_xini,h_all,&i_filter_num);
	if( STX_INI_OK != i_err ) {
		goto fail;
	}
	if( !i_filter_num ) {
		goto fail;
	}

	for( i = 0; i < i_filter_num; i ++ ) {

		i_err = h_xini->get_sub_key( h_xini, h_all, i, &h_gid );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		i_err = h_xini->read_key( h_xini, h_gid, &sz_gid );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		filter_gid = stx_gid_from_string(sz_gid);

		for( k = 0; k < p_con_ctx->get_skip_cls_num(p_con_ctx); k ++ ) {
			i_err = p_con_ctx->get_skip_cls_gid(p_con_ctx,k,&cls_gid);
			if( STX_OK != i_err ) {
				goto fail;
			}
			if( IS_EQUAL_GID(filter_gid,cls_gid) ) {
				goto next_filter;
			}
		}//for( k = 0; k < p_con_c

		i_err = h_xini->create_key( h_xini, h_gid, g_szStreamX_MainCategory, STX_NULL, &h_pin );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}

		i_err = h_xini->read_string( h_xini, h_pin, &sz_cat );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		cat_gid = stx_gid_from_string(sz_cat);

		if( !IS_EQUAL_GID(cat_gid,STX_CATEGORY_Render) ) {
			continue;
		}

		i_err = h_xini->create_key( h_xini, h_gid, g_szStreamX_InputPin, STX_NULL, &h_pin );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}

		i_err = h_xini->read_int32( h_xini, h_pin, &i_pin_num );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		if( !i_pin_num ) {
			continue;
		}


		for( j = 0; j < i_pin_num; j ++ ) {

			stx_sprintf(sz_key,sizeof(sz_key),"%s-%d", g_szStreamX_InputPin, j );
			i_err = h_xini->create_key( h_xini, h_pin, sz_key, sz_type, &h_item );
			if( STX_INI_OK != i_err ) {
				goto fail;
			}

			i_err = h_xini->read_string(h_xini,h_item,&sz_type);
			if( STX_INI_OK != i_err ) {
				goto fail;
			}
			md_type = stx_gid_from_string(sz_type); 

			if( !IS_EQUAL_GID(md_type,major_type) ) {
				continue;
			}

			i_err = h_xini->create_key( h_xini, h_item, g_szStreamX_SubDataType,STX_NULL, &h_type );
			if( STX_INI_OK != i_err ) {
				goto fail;
			}

			i_err = h_xini->read_string(h_xini,h_item,&sz_type);
			if( STX_INI_OK != i_err ) {
				goto fail;
			}
			md_subtype = stx_gid_from_string(sz_type); 

			if( !IS_EQUAL_GID(md_subtype,sub_type) ) {
				continue;
			}

			i_err = p_con_ctx->add_con_cls_gid(p_con_ctx,filter_gid);
			if( STX_OK != i_err ) {
				goto fail;
			}

			break;

		} /*for( j = 0; j < i_pin_num; j ++ ) {*/

next_filter:
		continue;

	} /*for( i = 0; i < i_filter_num; i ++ ) {*/

	if( !p_con_ctx->get_con_cls_num(p_con_ctx)) {
		i_err = STX_EOF;  /* no compatible filter found; */ 
	}
	else {
		i_err = STX_OK;
	}


fail:

	if( h_xini ) {
		h_xini->close(h_xini);
	}

	return i_err;

}



/***********************************************************************************
stx_reg_query_cat_desc
RETURN VALUE: success, is STX_OK; or is a negative value;
INPUT:  
OUTPUT: 
NOTE: 
***********************************************************************************/
STX_API STX_RESULT	stx_reg_query_cat_desc
( 
	THEE				h,
	stx_gid				cat_gid,
	char*				sz_cat_desc,
	stx_connect_ctx*	p_con_ctx 
)
{
	STX_RESULT					i_err;
	s32							i_filter_num;
	s32							i,k;
	char*						sz_gid;
	char*						sz_type;
	char*						sz_cat;
	stx_gid						tmp_cat_gid;
	stx_gid						cls_gid;
	stx_gid						filter_gid;
	stx_xini*					h_xini;

	STX_HANDLE					h_all;
	STX_HANDLE					h_gid;
	STX_HANDLE					h_pin;
	STX_HANDLE					h_type;
	char						sz_cfg[1024];


	STX_MAP_THE(base_graph_builder);

	i_err = STX_FAIL;
	sz_gid = STX_NULL;
	sz_type = STX_NULL;
	h_xini = STX_NULL;

	/* open StreamX xini configure file; */

	stx_sprintf(sz_cfg,sizeof(sz_cfg),"%s\\%s",g_szStreamX_Path,g_szStreamX_Cfg);

	i_err = stx_ini_create( sz_cfg, STX_NULL, STX_INI_READ_ONLY, 0, &h_xini );
	if( STX_INI_OK != i_err ) {
		goto fail;
	}

	/* all modules ; */
	i_err = h_xini->create_key( h_xini, STX_NULL, g_szStreamX_AllModule, STX_NULL, &h_all );
	if( STX_INI_OK != i_err ) {
		goto fail;
	}

	i_err = h_xini->get_sub_key_num(h_xini,h_all,&i_filter_num);
	if( STX_INI_OK != i_err ) {
		goto fail;
	}
	if( !i_filter_num ) {
		goto fail;
	}

	for( i = 0; i < i_filter_num; i ++ ) {

		i_err = h_xini->get_sub_key( h_xini, h_all, i, &h_gid );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		i_err = h_xini->read_key( h_xini, h_gid, &sz_gid );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		filter_gid = stx_gid_from_string(sz_gid);

		for( k = 0; k < p_con_ctx->get_skip_cls_num(p_con_ctx); k ++ ) {
			i_err = p_con_ctx->get_skip_cls_gid(p_con_ctx,k,&cls_gid);
			if( STX_OK != i_err ) {
				goto fail;
			}
			if( IS_EQUAL_GID(filter_gid,cls_gid) ) {
				goto next_filter;
			}
		}//for( k = 0; k < p_con_ctx->get_skip_cls_num(p_con_ctx); k ++ ) {

		i_err = h_xini->create_key( h_xini, h_gid, g_szStreamX_MainCategory, STX_NULL, &h_pin );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}

		i_err = h_xini->read_string( h_xini, h_pin, &sz_cat );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		tmp_cat_gid = stx_gid_from_string(sz_cat);

		if( !IS_EQUAL_GID(cat_gid,tmp_cat_gid) ) {
			continue;
		}

		i_err = h_xini->create_key( h_xini, h_pin, g_szStreamX_InputPin, STX_NULL, &h_type );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}

		i_err = h_xini->read_string(h_xini,h_type,&sz_cat_desc);
		if( STX_INI_OK != i_err ) {
			goto fail;
		}

		if( !strcmp(sz_cat_desc,sz_cat) ) {

			i_err = p_con_ctx->add_con_cls_gid(p_con_ctx,filter_gid);
			if( STX_OK != i_err ) {
				goto fail;
			}

			i_err = STX_OK;

			goto fail;
		}


next_filter:
		continue;

	} /*for( i = 0; i < i_filter_num; i ++ ) {*/

	i_err = STX_EOF;  /* no compatible filter found; */ 

fail:

	if( h_xini ) {
		h_xini->close(h_xini);
	}

	return i_err;

}




/***********************************************************************************
stx_find_hnd_ctx
private struct used in STX_API
stx_reg_find_class,
stx_reg_find_next,
stx_reg_find_close.
***********************************************************************************/

typedef struct stx_find_hnd_ctx  stx_find_hnd_ctx;
struct stx_find_hnd_ctx{
	s32				 i_find_idx;
	stx_connect_ctx* h_connect;
};


/***********************************************************************************
stx_reg_find_class
RETURN VALUE: success, is STX_OK; or is a negative value;
INPUT:  
OUTPUT: 
NOTE: 
***********************************************************************************/
STX_PURE STX_RESULT stx_reg_find_class
(THEE h,stx_reg_find_ctx* h_find_ctx,STX_HANDLE* h_find)
{
	STX_RESULT			i_err;
	stx_find_hnd_ctx*	h_ctx;

	STX_MAP_THE(base_graph_builder);

	i_err = STX_FAIL;
	h_ctx = STX_NULL;

	h_ctx = (stx_find_hnd_ctx*)xmallocz( sizeof(stx_find_hnd_ctx));
	if( !h_ctx ) {
		goto fail;
	}

	/* initialize the context; */

	h_ctx->h_connect = stx_connect_ctx_create();
	if( !h_ctx->h_connect ) {
		goto fail;
	}

	if( h_find_ctx->i_find_flags & STX_REG_FIND_SRC ) {

		if( h_find_ctx->i_find_flags & STX_REG_FIND_BY_EXTENSION ) {

			/* get the stream major type and sub type; */
			i_err = stx_reg_query_src_ext( h, h_find_ctx->sz_text, h_ctx->h_connect );
			if( STX_OK != i_err ) {
				goto fail;
			}

			i_err = h_ctx->h_connect->get_cur_cls_type( h_ctx->h_connect,0,&h_find_ctx->major_type,&h_find_ctx->sub_type);
			if( STX_OK != i_err ) {
				goto fail;
			}

			/* reconstruct the connect context; */
			h_ctx->h_connect->release(h_ctx->h_connect);
			h_ctx->h_connect = stx_connect_ctx_create();
			if( !h_ctx->h_connect ) {
				goto fail;
			}

			/* get the file source match the media type; */
			i_err = stx_reg_query_src_type(h, h_find_ctx->major_type, h_find_ctx->sub_type, h_ctx->h_connect );
			if( STX_OK != i_err ) {
				goto fail;
			}

		}
		else if( h_find_ctx->i_find_flags & STX_REG_FIND_BY_INPUT_MDTYPE ) {  /* */

			/* get the file source match the media type; */
			i_err = stx_reg_query_src_type(h, h_find_ctx->major_type, h_find_ctx->sub_type, h_ctx->h_connect );
			if( STX_OK != i_err ) {
				goto fail;
			}
		}
		else if( h_find_ctx->i_find_flags & STX_REG_FIND_BY_CATEGORY_DESC ){

			/* find the file source match the category description; */
			i_err = stx_reg_query_cat_desc( h, STX_CATEGORY_FileSource, h_find_ctx->sz_text, h_ctx->h_connect );

			if( STX_OK != i_err ) {
				goto fail;
			}

		}

	}
	else if( h_find_ctx->i_find_flags & STX_REG_FIND_REN ) {

		if( h_find_ctx->i_find_flags & STX_REG_FIND_BY_INPUT_MDTYPE ) {

			/* the major type & sub type must be valid; */

			i_err = stx_reg_query_ren_type(h, h_find_ctx->major_type, h_find_ctx->sub_type, h_ctx->h_connect );

			if( STX_OK != i_err ) {
				goto fail;
			}

		}
		else if( h_find_ctx->i_find_flags & STX_REG_FIND_BY_CATEGORY_DESC ){

			/* find the file source match the category description; */
			i_err = stx_reg_query_cat_desc(h, STX_CATEGORY_FileSource, h_find_ctx->sz_text, h_ctx->h_connect );

			if( STX_OK != i_err ) {
				goto fail;
			}

		}
		else {
			i_err = STX_ERR_INVALID_PARAM;
			goto fail;
		}

	}
	else if( h_find_ctx->i_find_flags & STX_REG_FIND_FILTER ) {

		if( ( h_find_ctx->i_find_flags & (STX_REG_FIND_BY_INPUT_MDTYPE|STX_REG_FIND_BY_OUTPUT_MDTYPE))
			== (STX_REG_FIND_BY_INPUT_MDTYPE|STX_REG_FIND_BY_OUTPUT_MDTYPE) ) {

				i_err = stx_reg_query_flt_type(
					h,
					h_find_ctx->major_type,
					h_find_ctx->sub_type,
					h_find_ctx->major_type_out,
					h_find_ctx->sub_type_out,
					h_ctx->h_connect );

				if( STX_OK != i_err ) {

					goto fail;
				}
		}
		else if( h_find_ctx->i_find_flags & STX_REG_FIND_BY_INPUT_MDTYPE) {

			i_err = stx_reg_query_flt_type( 
				h,
				h_find_ctx->major_type,
				h_find_ctx->sub_type,
				STX_GID_NULL,
				STX_GID_NULL,
				h_ctx->h_connect );

			if( STX_OK != i_err ) {

				goto fail;
			}
		}
		else if(h_find_ctx->i_find_flags & STX_REG_FIND_BY_OUTPUT_MDTYPE) {

			i_err = stx_reg_query_flt_type( 
				h,
				STX_GID_NULL,
				STX_GID_NULL,
				h_find_ctx->major_type_out,
				h_find_ctx->sub_type_out,
				h_ctx->h_connect );

			if( STX_OK != i_err ) {

				goto fail;
			}
		}
		else {

			i_err = STX_ERR_NOT_IMP;

			goto fail;
		}

	}
	else if( h_find_ctx->i_find_flags & STX_REG_FIND_BY_CATEGORY ) {

		/* find a module have the same input name; */

		if( h_find_ctx->i_find_flags & STX_REG_FIND_BY_CATEGORY_DESC ){

			i_err = stx_reg_query_cat_desc( h,h_find_ctx->cat_gid, h_find_ctx->sz_text, h_ctx->h_connect );
			if( STX_OK != i_err ) {
				goto fail;
			}

		}
		else {

			/* list all the filter match the category; */
			i_err = STX_ERR_INVALID_PARAM;
			goto fail;
		}

	}
	else {

		i_err = STX_ERR_INVALID_PARAM;
		goto fail;
	}

	*h_find = h_ctx;

	i_err = STX_OK;


fail:

	if( STX_OK != i_err ) {

		if( h_ctx ) {

			stx_reg_find_close(h,h_ctx);
		}
	}

	return i_err;
}



/***********************************************************************************
stx_reg_find_next
RETURN VALUE: success, is STX_OK; or is a negative value;
INPUT:  
OUTPUT: 
NOTE: 
***********************************************************************************/
STX_PURE STX_RESULT stx_reg_find_next
(THEE h,stx_reg_find_ctx* h_find_ctx,STX_HANDLE h_find)
{
	STX_RESULT			i_err;

	stx_find_hnd_ctx*	h_ctx;


	i_err = STX_FAIL;

	h_ctx = (stx_find_hnd_ctx*)h_find;

	if( h_ctx->i_find_idx == h_ctx->h_connect->get_con_cls_num(h_ctx->h_connect) ) {
		return STX_EOF;
	}

	i_err = h_ctx->h_connect->get_con_cls_gid(h_ctx->h_connect,
		h_ctx->i_find_idx,&h_find_ctx->cls_gid);

	h_ctx->i_find_idx ++;

	return i_err;
}




/***********************************************************************************
stx_reg_find_close
RETURN VALUE: success, is STX_OK; or is a negative value;
INPUT:  
OUTPUT: 
NOTE: 
***********************************************************************************/
STX_PURE void stx_reg_find_close(THEE h, STX_HANDLE h_find)
{
	stx_find_hnd_ctx*	h_ctx;

	h_ctx = (stx_find_hnd_ctx*)h_find;

	if( h_ctx->h_connect ) {
		h_ctx->h_connect->release(h_ctx->h_connect);
	}

	stx_free( h_ctx );
}



/***********************************************************************************
RETURN VALUE: success, is STX_OK; or is a negative value;
INPUT:  
OUTPUT: 
NOTE: 
***********************************************************************************/
STX_PURE STX_RESULT  stx_reg_stream_default(THEE h)
{
	STX_RESULT	i_err;
	s32			i;

	s32			i_size;

	i_size = sizeof(g_default_streams)/sizeof(g_default_streams[0]);

	i_err = STX_FAIL;

	for( i = 1; i < i_size; i ++ ) {
		i_err = stx_reg_stream(h,&g_default_streams[i]);
		if( STX_OK != i_err ) {
			goto fail;
		}
	}

	i_err = STX_OK;

fail:
	return i_err;
}




/***********************************************************************************
RETURN VALUE: success, is STX_OK; or is a negative value;
INPUT:  
OUTPUT: 
NOTE: 
***********************************************************************************/
STX_PURE STX_RESULT  stx_unreg_stream_default(THEE h)
{
	STX_RESULT	i_err;
	s32			i;

	s32			i_size;

	i_size = sizeof(g_default_streams)/sizeof(g_default_streams[0]);

	i_err = STX_FAIL;

	for( i = 1; i < i_size; i ++ ) {
		i_err = stx_unreg_stream(h,&g_default_streams[i]);
		if( STX_OK != i_err ) {
			goto fail;
		}
	}

	i_err = STX_OK;

fail:
	return i_err;
}




/***********************************************************************************
RETURN VALUE:
INPUT:  
OUTPUT: 
NOTE: 
***********************************************************************************/
STX_PURE stx_thread* stx_get_cur_thread(THEE h)
{
	return get_cur_thread();
}


/***********************************************************************************
RETURN VALUE:
INPUT:  
OUTPUT: 
NOTE: 
***********************************************************************************/
STX_PURE STX_RESULT	stx_set_main_data(THEE h,THEE h_module,THEE h_dat)
{
	return set_main_thread_data(h_module,h_dat);
}

/***********************************************************************************
RETURN VALUE:
INPUT:  
OUTPUT: 
NOTE: 
***********************************************************************************/
STX_PURE THEE stx_get_main_data(THEE h,THEE h_module)
{
	return get_main_thread_data(h_module);
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static const char* g_sz_commnets = 
"if thread num is set to 0, it will be decided by the gbd kernal;";

STX_PRIVATE STX_RESULT gbd_config(base_graph_builder* the)
{

	STX_RESULT					i_err;
	stx_xini*					h_xini;
	STX_HANDLE					h_ip,h_port;
	char						sz_cfg[1024];
	char						sz_buf[32];
	char*						sz_val;
	s32							i_val;

	i_err = STX_FAIL;

	sz_val = STX_NULL;
	h_xini = STX_NULL;


	do{

		stx_sprintf(sz_cfg, sizeof(sz_cfg),"%s"STX_SEP"%s",g_szStreamX_Root,"gbd.xini");

		// open ini;		
		i_err = stx_ini_create( sz_cfg, STX_NULL, STX_INI_READ_WRITE|STX_INI_NO_COMMENT, 0, &h_xini );
		if( STX_INI_OK != i_err ) {
			i_err = stx_ini_create( sz_cfg, STX_NULL, STX_INI_CREATE_NEW|STX_INI_NO_COMMENT, 0, &h_xini );
			if( STX_INI_OK != i_err ) {
				break;
			}
		}

		// comments
		i_err = h_xini->create_key( h_xini, NULL, "comments", g_sz_commnets, &h_ip );
		if( STX_INI_OK != i_err ) {
			break;
		}

		// thread num;
		i_err = h_xini->create_key( h_xini, NULL, g_sz_key_thread_num, "0", &h_ip );
		if( STX_INI_OK != i_err ) {
			break;
		}
		i_err = h_xini->read_int32(h_xini,h_ip,&the->i_ssrc);
		if( STX_INI_OK != i_err ) {
			break;
		}

		i_err = h_xini->create_key( h_xini, NULL, g_sz_key_task_status, "1", &h_ip );
		if( STX_INI_OK != i_err ) {
			break;
		}
		i_err = h_xini->read_int32(h_xini,h_ip,&i_val);
		if( STX_INI_OK != i_err ) {
			break;
		}
		if( i_val ) {
			g_i_debug |= GBD_DEBUG_TASK_STATUS;
		}

		i_err = h_xini->create_key( h_xini, NULL, g_sz_key_task_monitor, "1", &h_ip );
		if( STX_INI_OK != i_err ) {
			break;
		}
		i_err = h_xini->read_int32(h_xini,h_ip,&i_val);
		if( STX_INI_OK != i_err ) {
			break;
		}
		if( i_val ) {
			g_i_debug |= GBD_DEBUG_TASK_MONITOR;
		}

		i_err = h_xini->create_key( h_xini, NULL, g_sz_key_plug_monitor, "1", &h_ip );
		if( STX_INI_OK != i_err ) {
			break;
		}
		i_err = h_xini->read_int32(h_xini,h_ip,&i_val);
		if( STX_INI_OK != i_err ) {
			break;
		}
		if( i_val ) {
			g_i_debug |= GBD_DEBUG_PLUG_MONITOR;
		}

		i_err = h_xini->create_key( h_xini, NULL, g_sz_key_last_plug, "1", &h_ip );
		if( STX_INI_OK != i_err ) {
			break;
		}
		i_err = h_xini->read_int32(h_xini,h_ip,&i_val);
		if( STX_INI_OK != i_err ) {
			break;
		}
		if( i_val ) {
			g_i_debug |= GBD_DEBUG_LAST_PLUG;
		}

		i_err = STX_OK;

	}while(FALSE);

	SAFE_CLOSEXIO(h_xini);

	return i_err;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT load_dlib(base_graph_builder* the)
{
	STX_RESULT					i_err;
	stx_xini*					h_xini;
	STX_HANDLE					h_all;
	STX_HANDLE					h_clsid,h_svr;
	char						sz_cfg[1024];
	char						sz_key[1024];
	char						sz_gid[64];
	char*						sz_val;
	s32							i,i_val;

	LP_STX_CREATE_MODULE_PROC(	create_module	);

	i_err = STX_FAIL;

	sz_val = STX_NULL;
	h_xini = STX_NULL;

	INIT_MEMBER(sz_cfg);
	INIT_MEMBER(sz_key);
	INIT_MEMBER(sz_gid);


	do{

		stx_sprintf(sz_cfg, sizeof(sz_cfg),"%s"STX_SEP"%s",g_szStreamX_Root,"gbd.xini");

		// open ini;		
		i_err = stx_ini_create( sz_cfg, STX_NULL, STX_INI_READ_ONLY|STX_INI_NO_COMMENT, 0, &h_xini );
		if( STX_INI_OK != i_err ) {
			break;
		}

		// read key;

		/*all Service ; */

		i_err = h_xini->create_key( h_xini, STX_NULL, g_szStreamX_AllDlib, "1", &h_all );
		if( STX_INI_OK != i_err ) {
			i_err = STX_OK; // ignore;
			break;
		}

		i_val = 0;
		i_err = h_xini->get_sub_key_num(h_xini,h_all,&i_val);
		if( STX_INI_OK != i_err ) {
			break;
		}

		if( !i_val ) {
			i_err = STX_OK; // no dlib to load;
			break;
		}

		the->i_dlib = i_val;

		the->hh_dlib = (stx_module_ctx**)xmallocz(sizeof(stx_module_ctx*)*i_val);
		if( !the->hh_dlib ) {
			i_err = STX_FAIL;
			break;
		}

		for( i = 0; i < i_val; i ++ ) {

			s32		b_enable;

			i_err = h_xini->get_sub_key( h_xini, h_all, i, &h_clsid );
			if( STX_INI_OK != i_err ) {
				continue;
			}

			i_err = h_xini->read_key(h_xini,h_clsid,&sz_val);
			if( STX_INI_OK != i_err ) {
				break;
			}

			b_enable = FALSE;
			i_err = h_xini->read_int32(h_xini,h_clsid,&b_enable);
			if( STX_INI_OK != i_err ) {
				break;
			}

			if( !b_enable ) {
				continue;
			}

			the->hh_dlib[i] = (stx_module_ctx*)xmallocz( sizeof(stx_module_ctx ));
			if( !the->hh_dlib[i] ) {
				break;
			}

			the->hh_dlib[i]->h_stx_dll = stx_dll_create();
			if( !the->hh_dlib[i]->h_stx_dll ) {
				break;
			}
			the->hh_dlib[i]->sz_path = xstrdup(sz_val);
			if( !the->hh_dlib[i]->sz_path ) {
				break;
			}

			i_err = XCALL(load_library,the->hh_dlib[i]->h_stx_dll, the->hh_dlib[i]->sz_path );
			if( STX_OK != i_err ) {
				break;
			}

			create_module = (STX_CREATE_MODULE_PROC_PTR)
				XCALL(entry_by_name,the->hh_dlib[i]->h_stx_dll, g_szStreamX_CreateModule );
			if( !create_module ) {
				i_err = STX_FAIL;
				break;
			}

			the->hh_dlib[i]->h_module = create_module(&i_err,&the->stx_base_graph_builder_vt,stx_trace,the->g_i_debug);
			if( !the->hh_dlib[i]->h_module ) {
				i_err = STX_FAIL;
				break;
			}

			the->hh_dlib[i]->i_ref ++;

			i_err = stx_module_reg( the, the->hh_dlib[i] );
			if( STX_OK != i_err ) {
				i_err = STX_FAIL;
				break;
			}

		} //for( i = 0; i < i_val; i ++ ) {

	}while(FALSE);

	SAFE_CLOSEXIO(h_xini);

	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE void close_dlib(base_graph_builder* the)
{
	if( the->hh_dlib ) {
		s32 i;
		for( i = 0; i < the->i_dlib; i ++ ) {
			if( the->hh_dlib[i] ) {
				if( the->hh_dlib[i]->i_ref > 0 ){
					the->hh_dlib[i]->i_ref --;
				}
				if( 0 == the->hh_dlib[i]->i_ref ) {  
					//stx_log("stx_module_unreg\r\n");
					stx_module_unreg(the,the->hh_dlib[i]);
				}
			}
		}
		stx_free(the->hh_dlib);
	}

	the->hh_dlib = NULL;
	the->i_dlib = 0;
}
