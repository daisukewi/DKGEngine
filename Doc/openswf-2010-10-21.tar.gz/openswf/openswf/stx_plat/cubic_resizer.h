
/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/


#ifndef __CUBIC_RESIZE
#define __CUBIC_RESIZE

#include "stx_base_type.h"

#if defined( __cplusplus )
extern "C" {
#endif


#define STX_MSK_RESIZE                     0x01
#define STX_RESIZE_TRUE                    0x01
#define STX_RESIZE_FALSE                   0x00
#define STX_GET_RESIZE_CODE(flag)          ( flag & STX_MSK_RESIZE )
#define STX_PUT_RESIZE_CODE(flag,tok)      ( flag |= tok )

#define STX_MSK_ALG                        0xe //1110b
#define STX_RESIZE_ALG_AUTO                0x7
#define STX_RESIZE_ALG_NEARP               0x0
#define STX_RESIZE_ALG_BILIN               0x1
#define STX_RESIZE_ALG_BICUB               0x2
#define STX_RESIZE_ALG_LAN3                0x3
#define STX_RESIZE_ALG_LAN8                0x4
#define STX_GET_ALG_CODE(flag)             ( (flag & STX_MSK_ALG)>>1 )
#define STX_PUT_ALG_CODE(flag,tok)         ( flag |= (tok<<1) )
#define STX_CLEAR_ALG_CODE(flag)           ( flag &= (~STX_MSK_ALG) )


#define STX_MSK_SIZE_CODE                  0xe0  //1110000b
#define STX_NOT_FAST_SIZE                  0x00
#define STX_FAST_SIZE_XH_YH                0x01  //001b
#define STX_FAST_SIZE_XH_Y0                0x02  //010b
#define STX_FAST_SIZE_X0_YH                0x03  //011b
#define STX_FAST_SIZE_X0_YD                0x04  //100b
#define STX_FAST_SIZE_XD_Y0                0x05  //101b
#define STX_FAST_SIZE_XD_YD                0x06  //110b
#define STX_GET_SIZE_CODE(flag)            ( (flag & STX_MSK_SIZE_CODE)>>4 )
#define STX_PUT_SIZE_CODE(flag,tok)        ( flag |= (tok<<4) )
#define STX_CLEAR_SIZE_CODE(flag)          ( flag &= (~STX_MSK_SIZE_CODE) )
	//]]

	//[[ BYTE 1
#define STX_MSK_INPUT_FORMAT       0x0f00
#define STX_MSK_OUTPUT_FORMAT      0xf000

#define STX_FORMAT_YV12            0x01
#define STX_FORMAT_YUY2            0x02
#define STX_FORMAT_FYUVA420        0x03
#define STX_FORMAT_YUV444          0x04
#define STX_FORMAT_YUVA422         0x05
#define STX_FORMAT_YUVA420         0x06
#define STX_FORMAT_RGBA            0x07
#define STX_FORMAT_RGB32           0x08
#define STX_FORMAT_RGB24           0x09
#define STX_FORMAT_RGB16           0x0a
#define STX_FORMAT_RGB16_555       0x0b
#define STX_FORMAT_RGB16_565       0x0c
#define STX_FORMAT_RGB16_655       0x0d
#define STX_FORMAT_RGB16_664       0x0e
#define STX_FORMAT_RGB8            0x0f


#define STX_GET_INPUT_FORMAT(flag)            ( (flag & STX_MSK_INPUT_FORMAT)>>8 )
#define STX_PUT_INPUT_FORMAT(flag,tok)        ( flag |= (tok<<8) )
#define STX_CLEAR_INPUT_FORMAT(flag)          ( flag &= (~STX_MSK_INPUT_FORMAT) )
#define STX_GET_OUTPUT_FORMAT(flag)            ( (flag & STX_MSK_OUTPUT_FORMAT)>>12 )
#define STX_PUT_OUTPUT_FORMAT(flag,tok)        ( flag |= (tok<<12) )
#define STX_CLEAR_OUTPUT_FORMAT(flag)          ( flag &= (~STX_MSK_OUTPUT_FORMAT) )
	//]]

	//[[ BYTE 2
#define STX_MSK_EFFECT             0xff0000
#define STX_EFFECT_AJUSTCOLOR      0x01
#define STX_EFFECT_SHARP           0x02
#define STX_EFFECT_SMOOTH          0x04
#define STX_EFFECT_DEINTERLACE     0x08
#define STX_EFFECT_MIX             0x10
#define STX_GET_EFFECT(flag)            ( (flag & STX_MSK_EFFECT)>>16 )
#define STX_PUT_EFFECT(flag,tok)        ( flag |= (tok<<16) )
#define STX_CLEAR_EFFECT(flag,tok)      ( flag &= (~(tok<<16)) )
#define STX_CLEAR_ALL_EFFECT(flag,tok)      ( flag &= (~STX_MSK_EFFECT) )
	//]]

	//[[ BYTE 3
#define STX_MSK_EFFECT_EXT         0xff000000
#define STX_EFFECT_DG0             0x00
#define STX_EFFECT_DG1             0x01
#define STX_EFFECT_NDG             0xff
#define STX_GET_EFFECT_EXT(flag)            ( (flag & STX_MSK_EFFECT_EXT)>>24 )
#define STX_PUT_EFFECT_EXT(flag,tok)        ( flag |= (tok<<24) )
#define STX_CLEAR_EFFECT_EXT(flag,tok)      ( flag &= (~STX_MSK_EFFECT_EXT) )
	//]]




typedef struct CUBIC_RESIZE_PARAM
{
	u32				dwFlags;
	u32				dwFlagsExt;

	size_t			extend_info;         // pointer to contrast data matrix;
	size_t			extend_info2;        //

	u8*				lpSrc[4]; 
	s32				SrcWidth[4]; 
	s32				SrcHeight[4];
	s32				SrcPitch[4];

	u8*				lpSub[4]; 
	s32				SubStart[4];
	s32				SubWidth[4]; 
	s32				SubHeight[4];
	s32				SubPitch[4];

	u8*				lpDst[4];
	s32				DstWidth[4];
	s32				DstHeight[4];
	s32				DstPitch[4];

}CUBIC_RESIZE_PARAM;



STX_HANDLE  open_bicubic_resize();
void		close_bicubic_resize(STX_HANDLE h);
s32			bicubic_resize(STX_HANDLE h,CUBIC_RESIZE_PARAM *lpTpa);


#if defined( __cplusplus )
}
#endif


#endif