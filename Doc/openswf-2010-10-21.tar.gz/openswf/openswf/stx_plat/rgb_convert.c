
#include "stx_rgb_convert.h"


// ,RGB24_TO_RGB32_LINE_C0 = 585017
// ,RGB24_TO_RGB32_LINE_C = 187962
// ,RGB24_TO_RGB32_LINE_SSE2 = 289303

// 582386
void  RGB24_TO_RGB32_LINE_C0(u8* lpSrc,u8* lpDst,s32 nWidth)
{
	s32 j;

	for( j = 0; j < nWidth; j ++ ) {
		lpDst[0] = lpSrc[0];
		lpDst[1] = lpSrc[1];
		lpDst[2] = lpSrc[2];
		lpDst[3] = 0;
		lpDst += 4;
		lpSrc += 3;
	}
}


// 190437
void  RGB24_TO_RGB32_LINE_C(u8* lpSrc,u8* lpDst,s32 nWidth)
{
	s32 i,j;
	u32 dwBRGB;
	u32 dwGBRG;
	u32 dwRGBR;
	s32 const w8 = nWidth & ~7;

	for( i = 0; i < w8; i += 8 ) {
		dwBRGB = *(u32*)lpSrc;
		dwGBRG = *(u32*)(lpSrc+4);
		dwRGBR = *(u32*)(lpSrc+8);
		*(u32*)(lpDst) = ( dwBRGB << 8 ) >> 8;
		*(u32*)(lpDst+4) = ( dwBRGB >> 24 ) | ((dwGBRG & 0xffff) << 8) ;
		*(u32*)(lpDst+8) = ( dwGBRG >> 16 ) | ((dwRGBR & 0xff) << 16);
		*(u32*)(lpDst+12) = dwRGBR >> 8;
		dwBRGB = *(u32*)(lpSrc+12);
		dwGBRG = *(u32*)(lpSrc+16);
		dwRGBR = *(u32*)(lpSrc+20);
		*(u32*)(lpDst+16) = ( dwBRGB << 8 ) >> 8;
		*(u32*)(lpDst+20) = ( dwBRGB >> 24 ) | ((dwGBRG & 0xffff) << 8) ;
		*(u32*)(lpDst+24) = ( dwGBRG >> 16 ) | ((dwRGBR & 0xff) << 16);
		*(u32*)(lpDst+28) = dwRGBR >> 8;
		lpSrc += 24;
		lpDst += 32;
	}

	for( j = i; j < nWidth; j ++ ) {
		lpDst[0] = lpSrc[0];
		lpDst[1] = lpSrc[1];
		lpDst[2] = lpSrc[2];
		lpDst[3] = 0;
		lpDst += 4;
		lpSrc += 3;
	}
}


#ifndef STX64
// 487646
void  RGB24_TO_RGB32_LINE_MMX(u8* lpSrc,u8* lpDst,s32 nWidth)
{
	MM_DECLARE8;
	s32 i,j;
	u32 d0,d1,d2,d3;
	s32 const w8 = nWidth & ~7;

	// 65 lines, 8 pixes;

	imm7 = _mm_setzero_si64();

	for( i = 0; i < w8; i += 8 ) {

		imm0 = *CONV_PM64(lpSrc);      // G2 B2 R1 G1 B1 R0 G0 B0
		imm1 = *CONV_PM64(lpSrc+8);    // B5 R4 G4 B4 R3 G3 B3 R2
		imm2 = *CONV_PM64(lpSrc+16);   // R7 G7 B7 R6 G6 B6 R5 G5
		imm3 = imm0;
		imm4 = imm1;
		imm5 = imm2;
		imm0 = _m_psrlqi(imm0,40);    //                   G2 B2
		imm1 = _m_psllqi(imm1,16);    // X  X  R3 G3 B3 R2
		imm2 = _m_psllqi(imm2,32);    // X  X  R5 G5
		imm4 = _m_psrlqi(imm4,32);    //             B5 R4 G4 B4
		imm5 = _m_psrlqi(imm5,16);    // X  X  R7G7B7 R6G6B6
		imm0 = _m_por(imm0,imm1);     // X  X  R3G3B3 R2G2B2
		imm2 = _m_por(imm2,imm4);     // X  X  R5G5B5 R4G4B4
		imm4 = imm3;
		imm3 = _m_punpcklbw(imm3,imm0); // B3B1 R2R0 G2G0 B2B0
		imm4 = _m_punpckhbw(imm4,imm0); // XXXX XXXX R3R1 G3G1
		imm1 = imm2;
		imm2 = _m_punpcklbw(imm2,imm5); // B7B5 R6R4 G6G4 B6B4
		imm1 = _m_punpckhbw(imm1,imm5); // XXXX XXXX R7R5 G7G5

		imm0 = imm3;
		imm5 = imm2;
		imm0 = _m_psrlqi(imm0,48);      //                B3B1
		imm4 = _m_psllqi(imm4,16);      // XXXX R3R1 G3G1
		imm0 = _m_por(imm0,imm4);       // XXXX R3R1 G3G1 B3B1  0
		imm5 = _m_psrlqi(imm5,48);      //                B7B5
		imm1 = _m_psllqi(imm1,16);      // XXXX R7R5 G7G5
		imm1 = _m_por(imm1,imm5);       // XXXX R7R5 G7G5 B7B5  1

		imm4 = imm3;
		imm3 = _m_punpcklbw(imm3,imm0); // G3210 B3210
		imm4 = _m_punpckhbw(imm4,imm0); // XXXXX R3210

		imm5 = imm2;
		imm2 = _m_punpcklbw(imm2,imm1); // G7654 B7654
		imm5 = _m_punpckhbw(imm5,imm1); // XXXXX R7654

		imm0 = imm3;
		imm0 = _m_punpckldq(imm0,imm2); // B76543210
		imm3 = _m_punpckhdq(imm3,imm2); // G76543210
		imm4 = _m_punpcklbw(imm4,imm7); // _R_R_R_R 3210
		imm5 = _m_punpcklbw(imm5,imm7); // _R_R_R_R 7654

		imm1 = imm0;
		imm0 = _m_punpcklbw(imm0,imm3); // GB 3210
		imm1 = _m_punpckhbw(imm1,imm3); // GB 7654

		imm2 = imm0;
		imm3 = imm1;
		imm0 = _m_punpcklwd(imm0,imm4); // 0
		imm2 = _m_punpckhwd(imm2,imm4); // 1
		imm1 = _m_punpcklwd(imm1,imm5);
		imm3 = _m_punpckhwd(imm3,imm5); 

		*CONV_PM64(lpDst+0) = imm0;
		*CONV_PM64(lpDst+8) = imm2;
		*CONV_PM64(lpDst+16) = imm1;
		*CONV_PM64(lpDst+24) = imm3;

		lpSrc += 24;
		lpDst += 32;
	}

	for( j = i; j < nWidth; j ++ ) {
		lpDst[0] = lpSrc[2];
		lpDst[1] = lpSrc[1];
		lpDst[2] = lpSrc[0];
		lpDst += 3;
		lpSrc += 3;
	}

	_m_empty();
}
#endif // !STX64


static __m128i RGB24toRGB32mask = { 0,0,0,0,0,0,0,0,0,0,0,0,0xff,0xff,0xff,0xff};
static __m128i RGB24toRGB32mask1 = { 0xff,0xff,0xff,0xff,0,0,0,0,0,0,0,0,0,0,0,0};

void  RGB24_TO_RGB32_LINE_SSE2(u8* lpSrc,u8* lpDst,s32 nWidth)
{
#if 1

#if 0
	// 324540
	XMMI_DECLARE16;

	ixmm7 = _mm_setzero_si128();
	ixmm6 = RGB24toRGB32mask;

	for( ; ; ) {

		do{
			ixmm0 = _mm_loadu_si128( CONV_PXMMI(lpSrc) );   // BRGBRGBRGBRGBRGB
			ixmm1 = _mm_loadl_epi64( CONV_PXMMI(lpSrc+16)); //         RGBRGBRG
			ixmm2 = ixmm6;
			ixmm2 = _mm_and_si128(ixmm2,ixmm0);          // BRGB
			ixmm1 = _mm_shuffle_epi32(ixmm1,0x93);    //0x10010011  RGBRGBRG____
			ixmm2 = _mm_shuffle_epi32(ixmm2,0xc0);    // 0x11000000            BRGB
			ixmm1 = _mm_or_si128(ixmm1,ixmm2);              //     RGBRGBRGBRGB  1
			ixmm2 = ixmm0;									//     RGBRGBRGBRGB  0
			ixmm0 = _mm_unpacklo_epi8(ixmm0,ixmm1);         // GGBBRRGGBBRRGGBB 
			ixmm2 = _mm_unpackhi_epi8(ixmm2,ixmm1);         //         RRGGBBRR
			ixmm1 = ixmm2;
			ixmm2 = ixmm6;
			ixmm2 = _mm_and_si128(ixmm2,ixmm0);          // GGBB
			ixmm1 = _mm_shuffle_epi32(ixmm1,0x93);		// 0x10010011    RRGGBBRR
			ixmm2 = _mm_shuffle_epi32(ixmm2,0xc0);    //0x11000000             GGBB
			ixmm1 = _mm_or_si128(ixmm1,ixmm2);              //     RRGGBBRRGGBB  1
			ixmm2 = ixmm0;									//     RRGGBBRRGGBB  0
			ixmm0 = _mm_unpacklo_epi16(ixmm0,ixmm1);         // BBBBRRRRGGGGBBBB 
			ixmm2 = _mm_unpackhi_epi16(ixmm2,ixmm1);         //         RRRRGGGG
			ixmm0 = _mm_shuffle_epi32(ixmm0,0xD9);  // 11001001 BBBBBBBB RRRRGGGG
			ixmm1 = ixmm0;
			ixmm0 = _mm_unpacklo_epi32(ixmm0,ixmm2); //        RRRRRRRR GGGGGGGG
			ixmm1 = _mm_unpackhi_epi64(ixmm1,ixmm7); //                 BBBBBBBB
			ixmm1 = _mm_unpacklo_epi8(ixmm1,ixmm0);  //        GBGBGBGBGBGBGBGB
			ixmm0 = _mm_unpackhi_epi8(ixmm0,ixmm7);  //        _R_R_R_R_R_R_R_R      
			ixmm2 = ixmm1;
			ixmm1 = _mm_unpacklo_epi16(ixmm1,ixmm0);         // _RGB_RGB_RGB_RGB
			ixmm2 = _mm_unpackhi_epi16(ixmm2,ixmm0);         // _RGB_RGB_RGB_RGB
			_mm_storeu_si128(CONV_PXMMI(lpDst),ixmm1);
			_mm_storeu_si128(CONV_PXMMI(lpDst+16),ixmm2);
			lpSrc += 24;
			lpDst += 32;
			nWidth -= 8;
		}while( nWidth >= 8 );

		if( nWidth == 0 ) {
			break;
		}

		lpSrc -= ( 8 - nWidth ) * 3;
		lpDst -= ( 8 - nWidth ) * 4;
		nWidth = 8;
	}
#else
	// aligned(288904), not aligned(336861)

	XMMI_DECLARE16;

	__m128i const ixmmZ = _mm_setzero_si128();
	__m128i const ixmmK0 = RGB24toRGB32mask;
	__m128i const ixmmK1 = RGB24toRGB32mask1;

	for( ; ; ) {

		do{
			ixmm0 = _mm_load_si128( CONV_PXMMI(lpSrc) );   // B5 R4G4B4 R3G3B3 R2G2B2 R1G1B1 R0G0B0   xmm0:0
			ixmm1 = _mm_load_si128( CONV_PXMMI(lpSrc+16)); // GaBa R9G9B9 R8G8B8 R7G7B7 R6G6B6 R5G5
			ixmm2 = _mm_load_si128( CONV_PXMMI(lpSrc+32)); // RfGfBf ReGeBe RdGdBd RcGcBc RbGbBb Ra

			ixmm3 = ixmmK0;
			ixmm4 = ixmmK1;
			ixmm3 = _mm_and_si128(ixmm3,ixmm0);             // B5 R4G4B4
			ixmm5 = _mm_setzero_si128();
			ixmm4 = _mm_and_si128(ixmm4,ixmm2);             //                             RbGbBb Ra xmm4
			ixmm5 = _mm_unpackhi_epi64(ixmm5,ixmm1);        // GaBa R9G9B9 R8G8B8
			ixmm1 = _mm_unpacklo_epi64(ixmm1,ixmmZ);        //                    R7G7B7 R6G6B6 R5G5
			ixmm4 = _mm_or_si128(ixmm4,ixmm5);              // GaBa R9G9B9 R8G8B8          RbGbBb Ra    xmm4:2
			ixmm1 = _mm_or_si128(ixmm1,ixmm3);              // B5 R4G4B4          R7G7B7 R6G6B6 R5G5    xmm1:1
			ixmm2 = _mm_shuffle_epi32(ixmm2,0x71);          //           RfGfBf ReGeBe RdGdBd RcGcBc    00111001  xmm2:3
			ixmm1 = _mm_shuffle_epi32(ixmm1,0x93);          //			 R7G7B7 R6G6B6 R5G5B5 R4G4B4    10010011  xmm1:1
			ixmm4 = _mm_shuffle_epi32(ixmm4,0x4e);          //           RbGbBb RaGaBa R9G9B9 R8G8B8     01001110 xmm4:2

			ixmm3 = ixmm0;
			ixmm0 = _mm_unpacklo_epi8(ixmm0,ixmm1);         // G6G2B6B2 R5R1G5G1 B5B1R4R0 G4G0B4B0    
			ixmm3 = _mm_unpackhi_epi8(ixmm3,ixmm1);         //                   R7R3G7G3 B7B3R6R2    
			ixmm5 = ixmm4;
			ixmm4 = _mm_unpacklo_epi8(ixmm4,ixmm2);         // GeGaBeBa RdR9GdG9 BdB9RcR8 GcG8BcB8    
			ixmm5 = _mm_unpackhi_epi8(ixmm5,ixmm2);         //                   RfRbGfGb BfBbReRa 

			ixmm1 = ixmm0;
			ixmm0 = _mm_unpacklo_epi16(ixmm0,ixmm4);        // BdB9B5B1 RcR8R4R0 GcG8G4G0 BcB8B4B0
			ixmm1 = _mm_unpackhi_epi16(ixmm1,ixmm4);        // GeGaG6G2 BeBaB6B2 RdR9R5R1 GdG9G5G1
			ixmm3 = _mm_unpacklo_epi16(ixmm3,ixmm5);        // RfRbR7R3 GfGbG7G3 BfBbB7B3 ReRaR6R2
			ixmm2 = ixmm3;

			ixmm3 = ixmmK0;
			ixmm4 = ixmmK1;
			ixmm3 = _mm_and_si128(ixmm3,ixmm0);             // BdB9B5B1
			ixmm5 = _mm_setzero_si128();
			ixmm4 = _mm_and_si128(ixmm4,ixmm2);             //                             ReRaR6R2 xmm4
			ixmm5 = _mm_unpackhi_epi64(ixmm5,ixmm1);        // GeGaG6G2 BeBaB6B2
			ixmm1 = _mm_unpacklo_epi64(ixmm1,ixmmZ);        //                    RdR9R5R1 GdG9G5G1
			ixmm4 = _mm_or_si128(ixmm4,ixmm5);              // GeGaG6G2 BeBaB6B2           ReRaR6R2    xmm4:2
			ixmm1 = _mm_or_si128(ixmm1,ixmm3);              // BdB9B5B1           RdR9R5R1 GdG9G5G1    xmm1:1
			//           RcR8R4R0 GcG8G4G0 BcB8B4B0              xmm0 0
			ixmm2 = _mm_shuffle_epi32(ixmm2,0x71);          //           RfRbR7R3 GfGbG7G3 BfBbB7B3    00111001  xmm2:3
			ixmm1 = _mm_shuffle_epi32(ixmm1,0x93);          //			 RdR9R5R1 GdG9G5G1 BdB9B5B1    10010011  xmm1:1
			ixmm4 = _mm_shuffle_epi32(ixmm4,0x4e);          //           ReRaR6R2 GeGaG6G2 BeBaB6B2    01001110  xmm4:2

			ixmm3 = ixmm0;
			ixmm0 = _mm_unpacklo_epi8(ixmm0,ixmm1);         // Gdc985410  Bdc985410  
			ixmm3 = _mm_unpackhi_epi8(ixmm3,ixmm1);         //            Rdc985410    
			ixmm5 = ixmm4;
			ixmm4 = _mm_unpacklo_epi8(ixmm4,ixmm2);         // Gfeab7632  Bfeab7632   
			ixmm5 = _mm_unpackhi_epi8(ixmm5,ixmm2);         //            Rfeab7632

			ixmm1 = ixmm0;
			ixmm0 = _mm_unpacklo_epi16(ixmm0,ixmm4);        // B fedcab9876543210
			ixmm1 = _mm_unpackhi_epi16(ixmm1,ixmm4);        // G 
			ixmm3 = _mm_unpacklo_epi16(ixmm3,ixmm5);        // R 

			ixmm2 = ixmm0;
			ixmm0 = _mm_unpacklo_epi8(ixmm0,ixmm1);
			ixmm2 = _mm_unpackhi_epi8(ixmm2,ixmm1);         // GB

			ixmm4 = ixmm3;
			ixmm3 = _mm_unpacklo_epi8(ixmm3,ixmmZ);
			ixmm4 = _mm_unpackhi_epi8(ixmm4,ixmmZ);         // R

			ixmm1 = ixmm0;
			ixmm0 = _mm_unpacklo_epi16(ixmm0,ixmm3);
			ixmm1 = _mm_unpackhi_epi16(ixmm1,ixmm3); 
			_mm_store_si128(CONV_PXMMI(lpDst),ixmm0);
			_mm_store_si128(CONV_PXMMI(lpDst+16),ixmm1);

			ixmm0 = ixmm2;
			ixmm2 = _mm_unpacklo_epi16(ixmm2,ixmm4);
			ixmm0 = _mm_unpackhi_epi16(ixmm0,ixmm4);
			_mm_store_si128(CONV_PXMMI(lpDst+32),ixmm2);
			_mm_store_si128(CONV_PXMMI(lpDst+48),ixmm0);

			lpSrc += 48;
			lpDst += 64;
			nWidth -= 16;

		}while( nWidth >= 16 );

		if( nWidth == 0 ) {
			break;
		}

		lpSrc -= ( 16 - nWidth ) * 3;
		lpDst -= ( 16 - nWidth ) * 4;
		nWidth = 16;
	}
#endif


#else 
	// 252569
	__asm
	{
		mov         esi,[lpSrc]
		mov         edi,[lpDst]
		mov         eax,[nWidth]
		sub         esi,12
		sub         edi,16

ccc:
		sub         eax,4
		add         esi,12
		add         edi,16
		cmp         eax,4

		movd        mm0,[esi]     //  b1 r0 g0 b0
		movd        mm1,[esi+4]   //  g2 b2 r1 g1
		movd        mm6,[esi+8]   //  r3 g3 b3 r2
		movq        mm2,mm0       //  b1 r0 g0 b0
		movq        mm3,mm6       //  r3 g3 b3 r2 
		pslld       mm0,8         //  r0 g0 b0 
		psrld       mm6,8         //  r3 g3 b3; mm6;
		movq        mm4,mm1       //  g2 b2 r1 g1
		psrld       mm0,8         //  00 r0 g0 b0; mm0;
		pslld       mm4,16        //  r1 g1 00 00
		psrld       mm2,24        //  00 00 00 b1
		psrld       mm4,8         //  00 r1 g1 00
		pslld       mm3,24        //  r2;
		por         mm2,mm4       //  00 r1 g1 b1  mm2;
		psrld       mm3,8         //  00 r2;
		psrld       mm1,16        //  00 00 g2 b2;
		por         mm3,mm1       //  00 r2 g2 b2; mm3;
		punpckldq   mm0,mm2
		punpckldq   mm3,mm6
		movq        [edi],mm0
		movq        [edi+8],mm3
		jae         ccc

		test        eax,eax
		jz          over

		sub         eax,4
		mov         ecx,eax
		add         eax,eax 
		add         ecx,eax   // *3
		add         eax,eax   // *4
		add         esi,ecx
		add         edi,eax

		mov         eax,4
		jmp         ccc

over:
		emms
	}

#endif
}



static __m128i RGB24to32RGBmask = { 0,1,2,128, 3,4,5,128, 6,7,8,128, 9,10,11,128	};

void  RGB24_TO_RGB32_LINE_SSSE3(u8* lpSrc,u8* lpDst,s32 nWidth)
{
	XMMI_DECLARE16;

	ixmm7 = RGB24to32RGBmask;

	for( ; ; ) {

		do{
			ixmm0 = _mm_loadu_si128(CONV_PXMMI(lpSrc));		// b  B5 R4G4B4    R3G3B3 R2G2B2 R1G1B1 R0G0B0  xmm0
			ixmm1 = _mm_loadl_epi64(CONV_PXMMI(lpSrc+16));  // b                       R7G7B7 R6G6B6 R5 G5  xmm1
			ixmm1 = _mm_alignr_epi8(ixmm1,ixmm0,12);        // b               R7G7B7 R6G6B6 R5G5B5 R4G4B4
			ixmm0 = _mm_shuffle_epi8(ixmm0,ixmm7);
			ixmm1 = _mm_shuffle_epi8(ixmm1,ixmm7);			// 
			_mm_storeu_si128(CONV_PXMMI(lpDst),ixmm0);
			_mm_storeu_si128(CONV_PXMMI(lpDst+16),ixmm1);
			ixmm0 = _mm_loadu_si128(CONV_PXMMI(lpSrc+24));		// b  B5 R4G4B4    R3G3B3 R2G2B2 R1G1B1 R0G0B0  xmm0
			ixmm1 = _mm_loadl_epi64(CONV_PXMMI(lpSrc+24+16));  // b                       R7G7B7 R6G6B6 R5 G5  xmm1
			ixmm1 = _mm_alignr_epi8(ixmm1,ixmm0,12);        // b               R7G7B7 R6G6B6 R5G5B5 R4G4B4
			ixmm0 = _mm_shuffle_epi8(ixmm0,ixmm7);
			ixmm1 = _mm_shuffle_epi8(ixmm1,ixmm7);			// 
			_mm_storeu_si128(CONV_PXMMI(lpDst+32),ixmm0);
			_mm_storeu_si128(CONV_PXMMI(lpDst+32+16),ixmm1);
			nWidth -= 16;
			lpSrc += 48;
			lpDst += 64;
		}while( nWidth >= 16 );

		if( nWidth == 0 ) {
			break;
		}

		lpDst -= ( 16 - nWidth ) * 4;
		lpSrc -= ( 16 - nWidth ) * 3;
		nWidth = 16;
	}

}


//467530
void  RGB32_TO_RGB24_LINE_C0(u8* lpSrc,u8* lpDst,s32 nWidth)
{
	s32 j;
	for( j = 0; j < nWidth; j ++ ) {
		lpDst[0] = lpSrc[0];
		lpDst[1] = lpSrc[1];
		lpDst[2] = lpSrc[2];
		lpSrc += 4;
		lpDst += 3;
	}
}

//223719
void  RGB32_TO_RGB24_LINE_C(u8* lpSrc,u8* lpDst,s32 nWidth)
{
	s32 i,j;
	u32 d0;
	u32 d1;
	u32 d2;
	u32 d3;
	s32 const w8 = nWidth & ~7;

	for( i = 0; i < w8; i += 8 ) {
		d0 = *(u32*)lpSrc;
		d1 = *(u32*)(lpSrc+4);
		d2 = *(u32*)(lpSrc+8);
		d3 = *(u32*)(lpSrc+12);
		*(u32*)(lpDst)   = ( d0 & 0xffffff ) | ( d1 << 24 );            // b1 r0 g0 b0;
		*(u32*)(lpDst+4) = ( (d1 & 0xffffff) >> 8 ) | ( d2 << 16 ) ;    // g2 b2 r1 g1;
		*(u32*)(lpDst+8) = ( (d2 & 0xffffff) >> 16 ) | ( d3 << 8 );     // r3 g3 b3 r2;
		d0 = *(u32*)(lpSrc+16);
		d1 = *(u32*)(lpSrc+20);
		d2 = *(u32*)(lpSrc+24);
		d3 = *(u32*)(lpSrc+28);
		*(u32*)(lpDst+12)   = ( d0 & 0xffffff ) | ( d1 << 24 );            // b1 r0 g0 b0;
		*(u32*)(lpDst+16) = ( (d1 & 0xffffff) >> 8 ) | ( d2 << 16 ) ;    // g2 b2 r1 g1;
		*(u32*)(lpDst+20) = ( (d2 & 0xffffff) >> 16 ) | ( d3 << 8 );     // r3 g3 b3 r2;
		lpSrc += 32;
		lpDst += 24;
	}

	for( j = i; j < nWidth; j ++ ) {
		lpDst[0] = lpSrc[0];
		lpDst[1] = lpSrc[1];
		lpDst[2] = lpSrc[2];
		lpSrc += 4;
		lpDst += 3;
	}
}

//233120
void  RGB32_TO_RGB24_LINE_SSE2(u8* lpSrc,u8* lpDst,s32 nWidth)
{
#if 1
	XMMI_DECLARE16;

	for( ; ; ) {

		do{
			ixmm0 = _mm_loadl_epi64(CONV_PXMMI(lpSrc));
			ixmm1 = _mm_loadl_epi64(CONV_PXMMI(lpSrc+8));
			ixmm2 = ixmm0;
			ixmm3 = ixmm0;
			ixmm0 = _mm_slli_epi64(ixmm0,40);
			ixmm2 = _mm_srli_epi64(ixmm2,32);
			ixmm0 = _mm_srli_epi64(ixmm0,40);
			ixmm2 = _mm_slli_epi64(ixmm2,24);
			ixmm3 = ixmm1;
			ixmm4 = ixmm1;
			ixmm0 = _mm_or_si128(ixmm0,ixmm2);
			ixmm1 = _mm_slli_epi64(ixmm1,48);
			ixmm3 = _mm_slli_epi64(ixmm3,40);
			ixmm4 = _mm_srli_epi64(ixmm4,32);
			ixmm3 = _mm_srli_epi64(ixmm3,56);
			ixmm4 = _mm_slli_epi64(ixmm4,8);
			ixmm0 = _mm_or_si128(ixmm0,ixmm1);
			ixmm4 = _mm_or_si128(ixmm4,ixmm3);
			_mm_storel_epi64(CONV_PXMMI(lpDst),ixmm0);
			ixmm7 = ixmm4;
			ixmm0 = _mm_loadl_epi64(CONV_PXMMI(lpSrc+16));
			ixmm1 = _mm_loadl_epi64(CONV_PXMMI(lpSrc+24));
			ixmm2 = ixmm0;
			ixmm3 = ixmm0;
			ixmm0 = _mm_slli_epi64(ixmm0,40);
			ixmm2 = _mm_srli_epi64(ixmm2,32);
			ixmm0 = _mm_srli_epi64(ixmm0,40);
			ixmm2 = _mm_slli_epi64(ixmm2,24);
			ixmm3 = ixmm1;
			ixmm4 = ixmm1;
			ixmm1 = _mm_slli_epi64(ixmm1,48);
			ixmm3 = _mm_slli_epi64(ixmm3,40);
			ixmm4 = _mm_srli_epi64(ixmm4,32);
			ixmm3 = _mm_srli_epi64(ixmm3,56);
			ixmm4 = _mm_slli_epi64(ixmm4,8);
			ixmm0 = _mm_or_si128(ixmm0,ixmm1);
			ixmm4 = _mm_or_si128(ixmm4,ixmm3);
			ixmm0 = _mm_or_si128(ixmm0,ixmm2);
			ixmm4 = _mm_slli_epi64(ixmm4,32);
			ixmm7 = _mm_unpacklo_epi32(ixmm7,ixmm0);
			ixmm0 = _mm_unpacklo_epi32(ixmm0,ixmm4);
			ixmm0 = _mm_unpackhi_epi64(ixmm0,ixmm0);
			_mm_storel_epi64(CONV_PXMMI(lpDst+8),ixmm7);
			_mm_storel_epi64(CONV_PXMMI(lpDst+16),ixmm0);
			lpSrc += 32;
			lpDst += 24;
			nWidth -= 8;
		}while( nWidth >= 8 );

		if( nWidth == 0 ) {
			break;
		}

		lpSrc -= ( 8 - nWidth ) * 4;
		lpDst -= ( 8 - nWidth ) * 3;
		nWidth = 8;
	}

#else
	__asm
	{
		mov              esi,[lpSrc]
		mov              edi,[lpDst]
		mov              eax,[nWidth]
		sub              esi,32
		sub              edi,24

ccc:
		// unpack rgb32;
		sub              eax,8
		add              esi,32
		add              edi,24
		cmp              eax,8

		movq             mm0,[esi]          // 10;
		movq             mm1,[esi+8]        // 32;
		movq             mm2,mm0
		movq             mm3,mm0
		psllq            mm0,40
		psrlq            mm2,32
		psrlq            mm0,40
		psllq            mm2,24
		movq             mm3,mm1
		movq             mm4,mm1
		por              mm0,mm2    // 0 0 r g b r g b
		psllq            mm1,48     // g b
		psllq            mm3,40     // r g b 0 0 0 0 0
		psrlq            mm4,32     // 0 0 0 0 0 r g b
		psrlq            mm3,56     // 0 0 0 0 0 0 0 r
		psllq            mm4,8
		por              mm0,mm1
		por              mm4,mm3
		movq             [edi],mm0
		movq             mm7,mm4
		movq             mm0,[esi+16]        // 10;
		movq             mm1,[esi+24]        // 32;
		movq             mm2,mm0
		movq             mm3,mm0
		psllq            mm0,40
		psrlq            mm2,32
		psrlq            mm0,40
		psllq            mm2,24
		movq             mm3,mm1
		movq             mm4,mm1
		psllq            mm1,48     // g b
		psllq            mm3,40     // r g b 0 0 0 0 0
		psrlq            mm4,32     // 0 0 0 0 0 r g b
		psrlq            mm3,56     // 0 0 0 0 0 0 0 r
		psllq            mm4,8
		por              mm0,mm1
		por              mm4,mm3
		por              mm0,mm2    // 0 0 r g b r g b
		psllq            mm4,32
		punpckldq        mm7,mm0    //
		punpckhdq        mm0,mm4
		movq             [edi+8],mm7
		movq             [edi+16],mm0
		jae              ccc

		test             eax,eax
		jz               over

		sub              eax,8
		mov              ecx,eax
		add              eax,eax 
		add              ecx,eax   // *3
		add              eax,eax   // *4
		add              esi,eax
		add              edi,ecx

		mov              eax,8
		jmp              ccc

over:	
		emms
	}

#endif

}

static __m128i RGB32toRGB24mask = { 0,1,2, 4,5,6, 8,9, 128,128,128,128, 10,12,13,14 };
static __m128i RGB32toRGB24mask1 = { 0,1,2, 4,5,6, 8,9,10, 12,13,14, 128,128,128,128 };


void  RGB32_TO_RGB24_LINE_SSSE3(u8* lpSrc,u8* lpDst,s32 nWidth)
{

	XMMI_DECLARE16;

	ixmm6 = RGB32toRGB24mask;
	ixmm7 = RGB32toRGB24mask1;

	for( ; ; ) {

		do{
			ixmm0 = _mm_loadu_si128(CONV_PXMMI(lpSrc));		// b  __R3G3B3 __R2G2B2 __R1G1B1 __R0G0B0
			ixmm1 = _mm_loadu_si128(CONV_PXMMI(lpSrc+16));	// b  __R7G7B7 __R6G6B6 __R5G5B5 __R4G4B4
			ixmm0 = _mm_shuffle_epi8(ixmm0,ixmm6);			// b  R3G3B3 R2________G2B2 R1G1B1 R0G0B0
			ixmm1 = _mm_shuffle_epi8(ixmm1,ixmm7);			// b  ________R7G7B7 R6G6B6 R5G5B5 R4G4B4
			_mm_storel_epi64(CONV_PXMMI(lpDst),ixmm0);      //                     G2B2 R1G1B1 R0G0B0
			ixmm1 = _mm_alignr_epi8(ixmm1,ixmm0,12);        // b  R7G7B7 R6G6B6 R5G5B5 R4G4B4 R3G3B3 R2
			_mm_storeu_si128(CONV_PXMMI(lpDst+8),ixmm1);

			ixmm0 = _mm_loadu_si128(CONV_PXMMI(lpSrc+32));		// b  __R3G3B3 __R2G2B2 __R1G1B1 __R0G0B0
			ixmm1 = _mm_loadu_si128(CONV_PXMMI(lpSrc+32+16));	// b  __R7G7B7 __R6G6B6 __R5G5B5 __R4G4B4
			ixmm0 = _mm_shuffle_epi8(ixmm0,ixmm6);			// b  R3G3B3 R2________G2B2 R1G1B1 R0G0B0
			ixmm1 = _mm_shuffle_epi8(ixmm1,ixmm7);			// b  ________R7G7B7 R6G6B6 R5G5B5 R4G4B4
			_mm_storel_epi64(CONV_PXMMI(lpDst+24),ixmm0);      //                     G2B2 R1G1B1 R0G0B0
			ixmm1 = _mm_alignr_epi8(ixmm1,ixmm0,12);        // b  R7G7B7 R6G6B6 R5G5B5 R4G4B4 R3G3B3 R2
			_mm_storeu_si128(CONV_PXMMI(lpDst+24+8),ixmm1);

			lpSrc += 32*2;
			lpDst += 24*2;
			nWidth -= 8*2;

		}while( nWidth >= 8*2 );

		if( nWidth == 0 ) {
			break;
		}

		lpSrc -= ( 8*2 - nWidth ) * 4;
		lpDst -= ( 8*2 - nWidth ) * 3;
		nWidth = 8*2;
	}

}

// 553142
void  RGB24_TO_BGR24_C0(u8* lpSrc,u8* lpDst,s32 nWidth)
{
	s32 j;
	for( j = 0; j < nWidth; j ++ ) {
		lpDst[0] = lpSrc[2];
		lpDst[1] = lpSrc[1];
		lpDst[2] = lpSrc[0];
		lpDst += 3;
		lpSrc += 3;
	}
}

// 203370
void  RGB24_TO_BGR24_C(u8* lpSrc,u8* lpDst,s32 nWidth)
{
	s32 i,j;
	u32 d0,d1,d2,d3;
	s32 const w8 = nWidth & ~7;

	// 15 lines, 4 pixels;
	for( i = 0; i < w8; i += 8 ) {

		FAST_SWAP32(d0,*(u32*)lpSrc);
		FAST_SWAP32(d1,*(u32*)(lpSrc+2));
		FAST_SWAP32(d2,*(u32*)(lpSrc+5));
		FAST_SWAP32(d3,*(u32*)(lpSrc+8));
		*(u32*)(lpDst) =  d0 >> 8;
		*(u32*)(lpDst+3) = d1;
		*(u32*)(lpDst+6) = d2;
		*(u16*)(lpDst+9) = (u16)d3;
		*(u8*)(lpDst+11) = (u8)(d3 >> 16);

		FAST_SWAP32(d0,*(u32*)(lpSrc+12));
		FAST_SWAP32(d1,*(u32*)(lpSrc+12+2));
		FAST_SWAP32(d2,*(u32*)(lpSrc+12+5));
		FAST_SWAP32(d3,*(u32*)(lpSrc+12+8));
		*(u32*)(lpDst+12) =  d0 >> 8;
		*(u32*)(lpDst+12+3) = d1;
		*(u32*)(lpDst+12+6) = d2;
		*(u16*)(lpDst+12+9) = (u16)d3;
		*(u8*)(lpDst+12+11) = (u8)(d3 >> 16);

		lpSrc += 24;
		lpDst += 24;
	}

	for( j = i; j < nWidth; j ++ ) {  // 5 lines, 1 pixes;
		lpDst[0] = lpSrc[2];
		lpDst[1] = lpSrc[1];
		lpDst[2] = lpSrc[0];
		lpDst += 3;
		lpSrc += 3;
	}
}






static __m128i RGB24toBGA24mask = { 128,  2,1,0,  5,4,3,  8,7,6,  11,10,9,  14,13,12 };
static __m128i RGB24toBGA24mask1 = { 2,1,0,  5,4,3,  8,7,6,  128,128,128,128 };

void RGB24_TO_BGR24_SSSE3(u8* lpSrc,u8* lpDst,s32 nWidth)
{
	XMMI_DECLARE16;

	s32 i_pit;

	ixmm6 = RGB24toBGA24mask;
	ixmm7 = RGB24toBGA24mask1;

	for( ; ; ) {

		do{
			ixmm0 = _mm_loadu_si128(CONV_PXMMI(lpSrc));		// b  B5 R4G4B4    R3G3B3 R2G2B2 R1G1B1 R0G0B0  xmm0
			ixmm1 = _mm_loadl_epi64(CONV_PXMMI(lpSrc+16));  // b                       R7G7B7 R6G6B6 R5 G5  xmm1
			ixmm1 = _mm_alignr_epi8(ixmm1,ixmm0,15);        // b                      R7G7B7 R6G6B6 R5G5B5  xmm1
			ixmm0 = _mm_shuffle_epi8(ixmm0,ixmm6);          // b  R4G4B4 B3G3R3 B2G2R2 B1G1R1 B0G0R0 00
			ixmm1 = _mm_shuffle_epi8(ixmm1,ixmm7);			// b  00000000 000000 B7G7R7 B6G6R6 B5G5R5 
			ixmm2 = ixmm1;
			ixmm1 = _mm_alignr_epi8(ixmm1,ixmm0,1);         // b  R5 R4G4B4 B3G3R3 B2G2R2 B1G1R1 B0G0R0
			ixmm2 = _mm_srli_si128(ixmm2,1);                // b                     B7G7R7 B6G6R6 B5G5
			_mm_storel_epi64(CONV_PXMMI(lpDst),ixmm2);      // b
			_mm_storeu_si128(CONV_PXMMI(lpDst+16),ixmm1);

			ixmm0 = _mm_loadu_si128(CONV_PXMMI(lpSrc+24));		// b  B5 R4G4B4    R3G3B3 R2G2B2 R1G1B1 R0G0B0  xmm0
			ixmm1 = _mm_loadl_epi64(CONV_PXMMI(lpSrc+24+16));  // b                       R7G7B7 R6G6B6 R5 G5  xmm1
			ixmm1 = _mm_alignr_epi8(ixmm1,ixmm0,15);        // b                      R7G7B7 R6G6B6 R5G5B5  xmm1
			ixmm0 = _mm_shuffle_epi8(ixmm0,ixmm6);          // b  R4G4B4 B3G3R3 B2G2R2 B1G1R1 B0G0R0 00
			ixmm1 = _mm_shuffle_epi8(ixmm1,ixmm7);			// b  00000000 000000 B7G7R7 B6G6R6 B5G5R5 
			ixmm2 = ixmm1;
			ixmm1 = _mm_alignr_epi8(ixmm1,ixmm0,1);         // b  R5 R4G4B4 B3G3R3 B2G2R2 B1G1R1 B0G0R0
			ixmm2 = _mm_srli_si128(ixmm2,1);                // b                     B7G7R7 B6G6R6 B5G5
			_mm_storel_epi64(CONV_PXMMI(lpDst+24),ixmm2);      // b
			_mm_storeu_si128(CONV_PXMMI(lpDst+24+16),ixmm1);

			lpSrc += 24*2;
			lpDst += 24*2;
			nWidth -= 8*2;

		}while( nWidth >= 8*2 );

		if( nWidth == 0 ) {
			break;
		}

		i_pit = ( 8*2 - nWidth ) * 3;
		lpDst -= i_pit;
		lpSrc -= i_pit;
		nWidth = 8*2;
	}

}
