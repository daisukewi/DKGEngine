
/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/


/* stx_stream_pin.c: implementation of the stx_stream_pin class.*/

#include "stdio.h"
#include "stdlib.h"
#include "fcntl.h"
#include "malloc.h"
#include "memory.h"
#include "string.h"

#include "stx_mem.h"
#include "stx_debug.h"
#include "stx_mutex.h"
#include "stx_semaphore.h"
#include "stx_module_reg.h"
#include "stx_media_type_base.h"
#include "stx_thread.h"
#include "stx_gid_def.h"
#include "stx_stream_pin.h"

#include "stx_async_plugin.h"
#include "stx_io.h"
#include "stx_io_stream.h"


#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif

STX_COM(stx_stream_pin_ctx);

STX_COM_BEGIN(stx_stream_pin_ctx);
/**/
/**/STX_PUBLIC(stx_base_pin)
/**/STX_COM_DATA_DEFAULT(stx_base_pin)
/**/
/* other members; */
/**/stx_base_pin*		p_output;
/**/stx_media_type*		p_mtyp;
/**/
/*	stream sync members; */
/**/stx_media_data*		p_mdat;
/**/STX_BOOL			b_ouput_pin_wait;
/**/STX_HANDLE			h_sem_output_pin;
/**/STX_BOOL			b_filter_wait;
/**/STX_HANDLE			h_sem_filter;
/**/STX_HANDLE  		h_deliver;
/**/
/**/stx_media_data*		p_mdat_input;
/**/
/**/STX_HANDLE          h_default_task;
/**/stx_sync_source*    h_sync_ssrc;
/**/STX_HANDLE          h_sync_task;
/**/
/**/stx_xio*            h_property;
/**/
/**/stx_base_pin*		p_next_pin;
/**/stx_base_pin*		p_curr_pin;
/**/stx_media_data*		p_curr_data;
/**/
STX_COM_END();


STX_COM_FUNC_DECL_DEFAULT(stx_base_pin,stx_base_pin_vt);
STX_COM_FUNCIMP_DEFAULT(stx_stream_pin_ctx,stx_base_pin,stx_base_pin_vt);



/*{{{STX_MSG_ENTRY_DECLARE**************************************************/

/* to do : add msg proc entry  declaration here; */

/*}}}***********************************************************************/


/*{{{STX_BEGIN_MSG_MAP******************************************************/
STX_BEGIN_MSG_MAP(the_msg_data)

/* to do : add msg proc entry name here; */

STX_END_MSG_MAP
/*}}}***********************************************************************/


/*{{{STX_BEGIN_MSG_RESPONSE_MAP*********************************************/
STX_BEGIN_MSG_RESPONSE_MAP(the_msg_response)

/* to do : add msg process entry name here; */

STX_END_MSG_RESPONSE_MAP
/*}}}***********************************************************************/


/*{{{STX_DISPATHCH_MSG_PROC*************************************************/
STX_DISPATCH_MSG_PROC(  dispatch_msg ,the_msg_data )
/*}}}***********************************************************************/


/*{{{STX_RESPONSE_MSG_PROC**************************************************/
STX_RESPONSE_MSG_PROC(  response_msg, the_msg_response)
/*}}}***********************************************************************/





/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API_IMP
stx_base_pin*	stx_stream_pin_input_create( )
{

	STX_RESULT			i_err;
	stx_base_com*		p;
	stx_base_pin*       pin;

	
	i_err = STX_FAIL;
	p = STX_NULL;
	pin = STX_NULL;


	p = STX_NEW(stx_stream_pin_ctx,NULL,"stx_stream_pin_ctx");
	if( !p ) {
		return NULL;
	}

	i_err = p->query_interf(p,STX_IID_BasePin,(void**)&pin);
	STX_DELETE(p);
	if( STX_OK != i_err ) {
		return NULL;
	}
	return pin;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_COM_MAP_BEGIN(stx_stream_pin_ctx)
/**/STX_COM_MAP_ITEM(STX_IID_BasePin)
STX_COM_MAP_END()

STX_NEW_BEGIN(stx_stream_pin_ctx)
{
	STX_RESULT			i_err;

	i_err = STX_FAIL;

	the = STX_NULL;

	/* initialize the object; */

	STX_COM_NEW_DEFAULT(
		stx_base_pin,
		the->stx_base_pin_vt,
		stx_base_pin_vt,
		STX_GID_NULL,
		STX_CATEGORY_BasePin,
		"StreamX input pin");

	the->h_sem_filter = stx_semaphore_create( STX_NULL, 0, 1, STX_NULL );
	if( ! the->h_sem_filter ) {
		break;
	}

	the->h_sem_output_pin = stx_semaphore_create( STX_NULL, 0, 1, STX_NULL );
	if( ! the->h_sem_output_pin ) {
		break;
	}
}
STX_NEW_END()




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_QUERY_BEGIN(stx_stream_pin_ctx)
{
	STX_COM_QUERY_DEFAULT(stx_base_pin,the->stx_base_pin_vt);
}
STX_QUERY_END()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_DELETE_BEGIN(stx_stream_pin_ctx)
{
	STX_DELETE(the->p_mtyp);
	STX_DELETE(the->p_mdat);

	if( the->h_sem_filter ) {
		stx_semaphore_destory( the->h_sem_filter );
	}

	if( the->h_sem_output_pin ) {
		stx_semaphore_destory( the->h_sem_output_pin );
	}

	if( the->h_sync_ssrc) {
		the->h_sync_ssrc->unreg_task(the->h_sync_ssrc,the->h_sync_task);
		STX_DELETE(the->h_sync_ssrc);
	}

	if( the->h_property) {
		the->h_property->close(the->h_property);
	}

	STX_COM_DELETE_DEFAULT(stx_base_pin);
}
STX_DELETE_END
(
STX_COM_DELETE_BEGIN(stx_base_pin),STX_COM_DELETE_END(stx_base_pin)
)





/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE	STX_BOOL 
stx_base_pin_vt_xxx_is_connected( STX_HANDLE h ,stx_base_pin** pp_pin)
{
	STX_MAP_THE(stx_stream_pin_ctx);

    if( the->p_output ) {

        if( pp_pin ) {

            if( STX_OK != the->p_output->query_interf(
                the->p_output,
                STX_IID_OutputPin , 
                (void**)pp_pin ) )
            {
                return FALSE;
            }
        }

        return TRUE;
    }

	return FALSE;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE	STX_RESULT 
stx_base_pin_vt_xxx_connect( STX_HANDLE h, stx_base_pin* p_pin )
{
	STX_MAP_THE(stx_stream_pin_ctx);

	if( !p_pin ) {

		return STX_ERR_INVALID_PARAM;
	}

    p_pin->add_ref(p_pin);

	the->p_output = p_pin;

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE	STX_RESULT 
stx_base_pin_vt_xxx_break_connect( STX_HANDLE h )
{
	STX_MAP_THE(stx_stream_pin_ctx);

    if( the->p_output ){

        the->p_output->release(the->p_output);

        the->p_output = STX_NULL;
    }

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE	stx_media_type* 
stx_base_pin_vt_xxx_get_media_type( STX_HANDLE h )
{
	STX_MAP_THE(stx_stream_pin_ctx);

	if( the->p_mtyp ){

		the->p_mtyp->add_ref(the->p_mtyp);
	}

	return the->p_mtyp;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE	STX_RESULT 
stx_base_pin_vt_xxx_set_media_type( 
	STX_HANDLE h, stx_media_type* p_media_type )
{
	STX_MAP_THE(stx_stream_pin_ctx);

	if( !p_media_type ) {

		if( the->p_mtyp ) {

			the->p_mtyp->release(the->p_mtyp);
			the->p_mtyp = STX_NULL;
		}

		return STX_OK;
	}

	if( the->p_mtyp ) {

		the->p_mtyp->release(the->p_mtyp);
	}

	STX_MAKE_TRACE
	the->p_mtyp = stx_media_type_create(p_media_type,STX_MAP_TRACE);

	if( !the->p_mtyp ) {

		return STX_FAIL;
	}

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE: pull mode use only;
***************************************************************************/
STX_PURE STX_RESULT 
stx_base_pin_vt_xxx_get_media_data
(STX_HANDLE h,stx_media_data ** pp_media_data,s32 i_wait)
{
	STX_MAP_THE(stx_stream_pin_ctx);

	if( !the->p_output ) {
		return STX_FAIL;
	}

	return the->p_output->get_media_data( the->p_output, pp_media_data,i_wait );
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE	STX_RESULT 
stx_base_pin_vt_xxx_release_media_data( 
	STX_HANDLE h, stx_media_data* p_media_data )
{
	STX_MAP_THE(stx_stream_pin_ctx);

	if( !the->p_output ) {
		return STX_FAIL;
	}

	return the->p_output->release_media_data( the->p_output, p_media_data );
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE	STX_RESULT 
stx_base_pin_vt_xxx_deliver
( STX_HANDLE h, stx_media_data* p_media_data, stx_sync_inf* h_sync)
{
	STX_RESULT				i_err;

	STX_MAP_THE(stx_stream_pin_ctx);


	for( ; ; ){

		//the->async_plugin_vt.lock(&the->async_plugin_vt);

		/* if p_media_data is NULL, return if op would block; */

		if( ! p_media_data  ) {

			i_err = the->p_mdat ? STX_WOUNLD_BLOCK : STX_OK;

			break;
		}

		if( the->p_mdat ) {

			h_sync->i_idle_time = MILISEC2REFTIME(1); // 1ms;
			return STX_IDLE;
		}

		the->p_mdat = p_media_data;

		i_err = STX_OK;

		break;

	}/* for(; ; ){ */

	//the->async_plugin_vt.unlock(&the->async_plugin_vt);

	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE	STX_RESULT stx_base_pin_vt_xxx_receive
( STX_HANDLE h, stx_media_data** pp_media_data,stx_sync_inf* h_sync)
{
	STX_RESULT				i_err;

	STX_MAP_THE(stx_stream_pin_ctx);

	for( ; ; ){

		//the->async_plugin_vt.lock(&the->async_plugin_vt);

		if( ! pp_media_data  ) {

			/* if pp_media_data is NULL, return if op would block; */

			i_err = the->p_mdat ? STX_OK : STX_WOUNLD_BLOCK;

			break;
		}

		if( ! the->p_mdat ) {

		} /* if( ! the->p_mdat ) { */

		*pp_media_data = the->p_mdat ;

		the->p_mdat = STX_NULL;

		if( the->b_ouput_pin_wait ) {

			the->b_ouput_pin_wait = FALSE;

			stx_semaphore_release( the->h_sem_output_pin, 1, STX_NULL );
		}

		i_err = STX_OK;

        break;

	}/* for( ; ; ) { */

	//the->async_plugin_vt.unlock(&the->async_plugin_vt);

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_pin_vt_plug_xxx_flush
(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	STX_RESULT i_err;

	STX_MAP_THE(stx_stream_pin_ctx);

	i_err = STX_OK;

	the->b_filter_wait = FALSE;

	the->b_ouput_pin_wait = FALSE;

	if( the->p_mdat ) {
		the->p_mdat->release(the->p_mdat);
		the->p_mdat = STX_NULL;
	}

	if( the->p_mdat_input ) {
		the->p_mdat_input->release(the->p_mdat_input);
		the->p_mdat_input = STX_NULL;
	}

	return the->p_flt->flush(the->p_flt,i_flag,h_sync);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_pin_vt_plug_xxx_start
(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	STX_MAP_THE(stx_stream_pin_ctx);

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_pin_vt_plug_xxx_stop
(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
//	STX_RESULT i_err;

	STX_MAP_THE(stx_stream_pin_ctx);

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_base_pin_vt_plug_xxx_send_msg( STX_HANDLE h, stx_base_message* p_msg )
{
	STX_MAP_THE(stx_stream_pin_ctx);

//	return the->async_plugin_vt.send_msg(&the->async_plugin_vt,p_msg);

	return STX_OK;
}



/***************************************************************************
stream_filter_run
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_SHARE STX_RESULT stx_base_pin_vt_plug_xxx_run
(STX_HANDLE h, stx_sync_inf* h_sync )
{

	STX_RESULT			   i_err;

	stx_sync_source*		h_ssrc;
	stx_base_graph*			h_gph;
	stx_base_graph_builder* h_gbd;
	stx_base_plugin*		h_com;

	STX_MAP_THE(stx_stream_pin_ctx);

	i_err = STX_OK;

	h_ssrc = NULL;
	h_gph = NULL;
	h_gbd = NULL;
	h_com = NULL;

	if( !the->h_default_task ) {

		do{
			// first time run;
			i_err = the->p_parent->query_interf(the->p_parent,STX_IID_FilterGraph,(void**)&h_gph);
			if( STX_OK != i_err ) {
				break;
			}

			h_com = h_gph->get_parent(h_gph);
			i_err = the->p_parent->query_interf(the->p_parent,STX_IID_GraphBuilder,(void**)&h_gbd);
			if( STX_OK != i_err ) {
				break;
			}

			i_err = h_gbd->alloc_ssrc(h_gbd,the->h_ssrc,1,&h_ssrc);
			if( STX_OK != i_err ) {
				break;
			}

			the->h_sync_ssrc = h_ssrc;

			i_err = h_ssrc->reg_task(
				h_ssrc,&the->h_sync_task,(stx_base_plugin*)&the->stx_base_pin_vt,TASK_NORMAL);

			h_ssrc = NULL;

			if( STX_OK != i_err ) {
				break;
			}

			i_err = STX_OK;

		}while(FALSE);

		STX_DELETE( h_gbd );
		STX_DELETE( h_gph );
		STX_DELETE( h_com );
		STX_DELETE( h_ssrc);

		return i_err;

	} // if( !the->h_default_task ) {


	if( h_sync->h_task == the->h_sync_task ){

		stx_base_filter* p_flt = (stx_base_filter*)the->p_parent;

		// first flush out last time output data;
		if( the->p_next_pin ) {

			i_err = p_flt->deliver(p_flt, &the->stx_base_pin_vt,
				&the->p_next_pin, NULL , h_sync );

			if( i_err < 0 ) {
				return i_err;
			}
			if( STX_AGAIN == i_err ) {
				return i_err;
			}
			the->h_deliver = NULL;
		} // if( the->p_mtyp_out && the->p_mdat_out ) {

		// get input data;
		if( !the->p_mdat_input ) {

			i_err = stx_base_pin_vt_xxx_receive( the, &the->p_mdat_input, h_sync );
			if( STX_WOUNLD_BLOCK == i_err ) {
				return STX_AGAIN;
			}
			if( i_err < 0 ) {
				return i_err;
			}
		} // if( !the->p_mdat_input ) {

		// do filter operations;
		i_err = p_flt->transform( 
			p_flt, 
			&the->stx_base_pin_vt,
			the->p_mdat_input,
			&the->p_curr_pin,
			&the->p_curr_data,
			h_sync );

		if( STX_AGAIN != i_err ) { // sample exhausted;
			the->p_mdat_input = STX_NULL;
		}

		if( the->p_curr_pin ) { // have output sample;
			do{
				i_err = p_flt->deliver(p_flt,&the->stx_base_pin_vt, 
					&the->p_curr_pin, &the->p_curr_data,h_sync );
			}while(STX_AGAIN == i_err);
			if( i_err < 0 || STX_WOUNLD_BLOCK == i_err ) {
				return i_err;
			}
			the->p_curr_pin = NULL;
			return STX_OK;
		} // if( the->p_next_pin ) {

	} // if( h_sync->h_task == the->h_sync_task ){

	return i_err;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT up_stream_msg
(STX_HANDLE h, stx_base_message* p_msg)
{
	STX_MAP_THE(stx_stream_pin_ctx);

	return the->p_output->send_msg(the->p_output,p_msg);
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT 
down_stream_msg
(STX_HANDLE h, stx_base_message* p_msg)
{
	STX_MAP_THE(stx_stream_pin_ctx);

	{
		stx_base_filter* p_flt = (stx_base_filter*)the->p_parent;

		return p_flt->send_msg(p_flt,p_msg);
	}

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_base_pin_vt_plug_xxx_get_property
(STX_HANDLE h,stx_xio* h_xio)
{
	STX_MAP_THE(stx_stream_pin_ctx);
	{
		STX_RESULT		i_err;
		stx_io_op_param	inf;
		size_t          i_size;
		size_t			i_write;

		if( !the->h_property ) {
			return STX_ERR_FILE_NOT_FOUND;
		}

		i_size = (size_t)the->h_property->size(the->h_property);

		i_err = the->h_property->get(the->h_property,STX_IO_READ_P,&inf);
		if( STX_OK != i_err ){
			return i_err;
		}

		h_xio->write(h_xio,inf.buf,i_size,&i_write);

		return STX_OK;

	}
	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_base_pin_vt_plug_xxx_set_property
(STX_HANDLE h,stx_xio* h_xio)
{
	STX_MAP_THE(stx_stream_pin_ctx);
	{

		STX_RESULT		i_err;
		stx_io_op_param	inf;
		size_t          i_size;
		size_t			i_write;

		if( !the->h_property) {

			STX_MAKE_TRACE
			the->h_property = stx_create_io_stream(STX_MAP_TRACE);
			if( !the->h_property ) {
				return STX_FAIL;
			}
		}

		i_size = (size_t) h_xio->size(h_xio);

		i_err = h_xio->get(h_xio,STX_IO_READ_P,&inf);

		if( STX_OK != i_err ){
			return STX_FAIL;
		}

		the->h_property->clear(the->h_property);

		the->h_property->write(the->h_property,inf.buf,i_size,&i_write);

		return STX_OK;
	}

	return STX_ERR_NOT_SUPPORT;
}