/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/
#include "stdio.h"
#include "stdlib.h"
#include "fcntl.h"
#include "malloc.h"
#include "memory.h"
#include "string.h"

#include "stx_mem.h"
#include "stx_debug.h"
#include "stx_mutex.h"
#include "stx_semaphore.h"
#include "stx_module_reg.h"
#include "xdisk_loop.h"
#include "stx_thread.h"
#include "stx_gid_def.h"


#include "stx_malloc_lxvideoframe.h"
#include "stx_mdat_lxvideoframe.h"


#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif



struct vfrm_alloc{

	stx_media_data_allocator	mda_alloc;

	int32_t						i_ref;

	STX_HANDLE					h_mutex;

	stx_mda_alloc_base_param	prop;

	xloop*						mda_loop;

	stx_media_data**			pp_mda;

	STX_BOOL					b_request_wait;

	STX_HANDLE					h_sem_request;
};


STX_PURE	STX_RESULT			query_interf( STX_HANDLE h, stx_gid gid, STX_HANDLE* p_interf);

STX_PURE	sint32 				add_ref( STX_HANDLE h );

STX_PURE	sint32 				release( STX_HANDLE h );


STX_PURE	STX_RESULT			set_param( STX_HANDLE h, void* param, sint32 i_len );

STX_PURE	STX_RESULT			get_param( STX_HANDLE h, void* param , sint32* i_len );

STX_PURE	STX_RESULT			get_media_data( STX_HANDLE h, stx_media_data** pp_mda, sint32 i_wait );

STX_PURE	STX_RESULT			free_media_data( STX_HANDLE h, stx_media_data* p_mda );

STX_PURE	STX_RESULT			reset(STX_HANDLE h);



static	STX_RESULT init_allocator
( vfrm_alloc* the,stx_mda_alloc_base_param* param );

STX_PRIVATE	void release_allocator( vfrm_alloc* the );

#define MA_LOCK() stx_waitfor_mutex( the->h_mutex, INFINITE )

#define MA_UNLOCK() stx_release_mutex( the->h_mutex )


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
#ifdef __USE_STX_DEBUG__
STX_API stx_media_data_allocator* create_vfrm_alloc(THEE hinst,const char* file,s32 line)
#else
STX_API stx_media_data_allocator* create_vfrm_alloc(THEE hinst)
#endif
{

	STX_RESULT					i_err;
	vfrm_alloc*					the;
	stx_mda_alloc_base_param	prop;

	the = STX_NULL;
	i_err = STX_FAIL;

	do {
#ifdef __USE_STX_DEBUG__
		the = (vfrm_alloc*)debug_mallocz( sizeof (vfrm_alloc),file,line);
#else
		the = (vfrm_alloc*)xmallocz( sizeof (vfrm_alloc));
#endif
		if( ! the ) {
			break;
		}

		the->i_ref = 1;

		/* fill the vtable; */

		the->mda_alloc.add_ref	= add_ref;
		the->mda_alloc.release	= release;
		the->mda_alloc.query_interf	= query_interf;

		the->mda_alloc.free_media_data	= free_media_data;
		the->mda_alloc.get_media_data	= get_media_data;
		the->mda_alloc.get_param		= get_param;
		the->mda_alloc.reset			= reset;
		the->mda_alloc.set_param		= set_param;

		the->h_mutex = stx_create_mutex( STX_NULL, 0, STX_NULL );
		if( ! the->h_mutex ) {
			break;
		}

		the->h_sem_request = stx_semaphore_create( STX_NULL, 0, 1, STX_NULL );
		if( ! the->h_sem_request ) {
			break;
		}

		prop.i_mda_num = 4;
		prop.i_mda_size = 0;

		i_err = init_allocator(the,&prop);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = STX_OK;

	}while(FALSE);

	if( STX_OK != i_err ) {
		SAFE_XDELETE(the);
		return STX_NULL;
	}

	return (stx_mem_alloc_base*)the;

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static	STX_RESULT query_interf( STX_HANDLE h, stx_gid gid, STX_HANDLE* p_interf)
{
	vfrm_alloc*		the;

	the = (vfrm_alloc*) h;

	if( IS_EQUAL_GID(gid,STX_IID_MemAllocator ) ) {
		the->i_ref ++;
		*p_interf = the;
		return STX_OK;
	}

	if( IS_EQUAL_GID(gid,STX_IID_LxVideoFrameAllocator) ) {
		the->i_ref ++;
		*p_interf = the;
		return STX_OK;
	}

	return STX_ERR_INVALID_PARAM;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE sint32 add_ref( STX_HANDLE h )
{
	vfrm_alloc*		the;

	the = (vfrm_alloc*) h;

	the->i_ref ++;

	return the->i_ref;

}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE sint32 release( STX_HANDLE h )
{
	vfrm_alloc*		the;


	the = (vfrm_alloc*) h;

	the->i_ref --;

	if( the->i_ref > 0 ) {

		return the->i_ref;
	}

	release_allocator(the);

	if( the->mda_loop ) {
		xloopRelease(the->mda_loop);
	}

	if( the->h_mutex ) {
		stx_close_mutex( the->h_mutex );
	}

	if( the->h_sem_request ) {
		stx_semaphore_destory( the->h_sem_request );
	}

	stx_free( the );

	return 0;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static	STX_RESULT set_param( STX_HANDLE h, void* param, sint32 i_len )
{
	vfrm_alloc*		the;

	the = (vfrm_alloc*)h;

	if( i_len != sizeof(stx_mda_alloc_base_param) ) {

		return STX_ERR_INVALID_PARAM;
	}

	return init_allocator(the,(stx_mda_alloc_base_param*)param);
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static	STX_RESULT get_param( STX_HANDLE h, void* param , sint32* i_len )
{
	vfrm_alloc*		the;

	the = (vfrm_alloc*)h;

	if( !param ) {

		*i_len = sizeof(stx_mda_alloc_base_param);

		return STX_OK;
	}

	memcpy( param, &the->prop, sizeof(stx_mda_alloc_base_param) ) ;

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static	void release_allocator( vfrm_alloc* the )
{
	sint32 i;

	if( the->pp_mda ) {

		for( i = 0; i < the->prop.i_mda_num; i ++ ) {
			SAFE_XDELETE(the->pp_mda[i]);
		}

		stx_free( the->pp_mda );

		the->pp_mda = NULL;
	}

	if( the->mda_loop ) {

		xloopRelease(the->mda_loop);

		the->mda_loop = NULL;
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static	STX_RESULT init_allocator
( vfrm_alloc* the,stx_mda_alloc_base_param* param )
{

	sint32 i;
 
	release_allocator(the);

	memcpy(&the->prop,param,sizeof(stx_mda_alloc_base_param));

	the->pp_mda = (stx_media_data**)xmallocz( sizeof(stx_media_data*)*the->prop.i_mda_num);
	if( !the->pp_mda ) {
		return STX_FAIL;
	}

	the->mda_loop = xloopCreate( the->prop.i_mda_num );
	if( ! the->mda_loop ) {
		return STX_FAIL;
	}


	for( i = 0; i < the->prop.i_mda_num; i ++ ) {

		the->pp_mda[i] = stx_mdat_lxvideoframe_create( STX_NULL );
		if( !the->pp_mda[i] ) {
			return STX_FAIL;
		}

		xloopPush( the->mda_loop, the->pp_mda[i] );

	}// for( i = 0; i < the->prop.i_mda_num; i ++ ) {


	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static	STX_RESULT reset(STX_HANDLE h)
{
	vfrm_alloc*		the;

	sint32						i;

	the = (vfrm_alloc*)h;

	MA_LOCK();

	if( ! the->mda_loop ) {

		return STX_ERR_OBJ_UNINIT;
	}

	xloopFlush(the->mda_loop);

	for( i = 0; i < the->prop.i_mda_num; i ++ ) {

		xloopPush( the->mda_loop, the->pp_mda[i] );
	}

	MA_UNLOCK();

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static	STX_RESULT get_media_data( STX_HANDLE h, stx_media_data** pp_mda , sint32 i_wait)
{
	vfrm_alloc*		the;

	STX_RESULT					i_err;

	stx_media_data*				p_mda;


	i_err = STX_FAIL;

	the = (vfrm_alloc*)h;

	for( ; ; ) {

		MA_LOCK();

		p_mda = (stx_media_data*)xloopPull( the->mda_loop );

		if( !p_mda ) {

			if( !pp_mda ) {

				MA_UNLOCK();

				return STX_WOUNLD_BLOCK;
			}

			the->b_request_wait = TRUE;

			MA_UNLOCK();

// 			stx_log("wait for video frame\r\n");

			i_err = stx_semaphore_wait( the->h_sem_request, i_wait );

			if( WAIT_OBJECT_0 == i_err ) {

				continue;
			}

			if( WAIT_TIMEOUT == i_err ) {

				return STX_WOUNLD_BLOCK;
			}

			return STX_FAIL;
		}

		*pp_mda = p_mda;

		//stx_log("get media data success\r\n" );

		i_err = STX_OK;

		break;
	}

	MA_UNLOCK();

	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static STX_RESULT free_media_data( STX_HANDLE h, stx_media_data* p_mda )
{
	vfrm_alloc*		the;


	the = (vfrm_alloc*)h;

	MA_LOCK();

	xloopPush( the->mda_loop, p_mda );

	if( the->b_request_wait ) {

		the->b_request_wait = FALSE;

		stx_semaphore_release( the->h_sem_request, 1, STX_NULL );
	}

	MA_UNLOCK();

	//stx_log("release media data \r\n");

	return STX_OK;

}



#undef  MA_LOCK
#undef  MA_UNLOCK