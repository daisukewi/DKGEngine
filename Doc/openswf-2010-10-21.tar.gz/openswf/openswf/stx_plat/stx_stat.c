
/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/
#include "stdio.h"
#include "stdlib.h"
#include "fcntl.h"
#include "malloc.h"
#include "memory.h"
#include "string.h"
#include "stdarg.h"
#include "math.h"

#include "stx_os.h"
#include "stx_mem.h"
#include "stx_debug.h"
#include "stx_stat.h"


STX_INTERF(stx_stat);

struct stx_stat{
	s64 i_period;
	s64 i_limit;
	s64 i_last_time;
	s64 i_last_val;
	s64 i_start_time;
	s64 i_curr_val;
};


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_HANDLE stx_stat_create()
{
	stx_stat* the;
	DECL_TRACE

	MAKE_TRACE2
	the = (stx_stat*)smart_mallocz( sizeof(stx_stat),MAP_TRACE);
	if( !the) {
		return NULL;
	}

	the->i_period = 500*1000; // 0.5 second;
	the->i_limit = the->i_period / 5;

	return (STX_HANDLE)the;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void stx_stat_close(STX_HANDLE h)
{
	STX_DIRECT_THE(stx_stat);
	
	stx_free(the);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void stx_stat_set_period(STX_HANDLE h, u32 i_mili_sec)
{
	STX_DIRECT_THE(stx_stat);

	the->i_period = (s64)i_mili_sec;
	the->i_limit = the->i_period / 5;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void stx_stat_pause(STX_HANDLE h)
{
	STX_DIRECT_THE(stx_stat);

	// need to think about the logic;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void stx_stat_reset(STX_HANDLE h)
{
	STX_DIRECT_THE(stx_stat);
	the->i_curr_val = 0;
	the->i_last_val = 0;
	the->i_start_time = 0;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
s64 stx_stat_update(STX_HANDLE h)
{
	STX_DIRECT_THE(stx_stat);
	{
		s64 i_curr_time;

		i_curr_time = stx_get_microsec();

		if( !the->i_start_time ) {
			the->i_start_time = i_curr_time;
		}

		if( i_curr_time - the->i_start_time > the->i_period ) {

			the->i_last_time = the->i_start_time;
			the->i_start_time = i_curr_time;
			the->i_last_val = the->i_curr_val;
			the->i_curr_val = 0;
		}

		return i_curr_time;
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
data size, or idle time;
***************************************************************************/
void stx_stat_add_val(STX_HANDLE h, s64 i_val)
{
	STX_DIRECT_THE(stx_stat);
	the->i_curr_val += i_val;
	//stx_log("i_val = %d\r\n",i_val);
	stx_stat_update(h);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
u32 stx_stat_get_occupy(STX_HANDLE h)
{
	STX_DIRECT_THE(stx_stat);
	{
		s64 i_last,i_curr,i_curr_time,i_last_time;
		s64 i_val,i_total_time;

		if( the->i_curr_val + the->i_last_time == 0 ) {
			return 0;
		}

		i_curr_time = stx_stat_update(h) - the->i_start_time;

		if( ! the->i_last_time ) {
			if( i_curr_time > 0 ) {
				return (u32)( ( i_curr_time - the->i_curr_val) * 1000  / i_curr_time ); 
			}
			return 0;
		} // if( ! the->i_last_time ) {

		i_last_time = the->i_start_time - the->i_last_time;

		i_last = i_last_time ? (i_last_time - the->i_last_val) * 1000 / i_last_time : 0;

		i_curr = i_curr_time ? ( i_curr_time - the->i_curr_val ) * 1000 / i_curr_time : 0;

		i_total_time = i_last_time + i_curr_time;

		i_val = (i_last*i_last_time + i_curr*i_curr_time ) / i_total_time; // weighted run time;

		// occupied time;
		return (u32)i_val; 

	}

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
s64 stx_stat_get_speed(STX_HANDLE h)
{
	STX_DIRECT_THE(stx_stat);
	{
		s64 i_curr_time,i_last_time;
		s64 i_val,i_total_time;

		i_curr_time = stx_stat_update(h) - the->i_start_time;

		if( ! the->i_last_time ) {
			if( i_curr_time > 0 ) {
				return the->i_curr_val * 1000 * 1000 / i_curr_time; 
			}
			return 0;
		} // if( ! the->i_last_time ) {

		i_last_time = the->i_start_time - the->i_last_time;

		i_total_time = i_last_time + i_curr_time;

		i_val = (the->i_last_val + the->i_curr_val ) * 1000 * 1000 / i_total_time;

		return i_val; // val at  1 second;

	}

}



