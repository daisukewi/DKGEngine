

/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/


#include "stdio.h"
#include "stdlib.h"
#include "fcntl.h"
#include "malloc.h"
#include "memory.h"
#include "string.h"

#include "stx_mem.h"
#include "stx_debug.h"
#include "stx_mutex.h"
#include "stx_semaphore.h"
#include "stx_gid_def.h"
#include "stx_module_reg.h"

#include "stx_stream_filter.h"


/******************************************************************************

stream filter:

at run proc, 
1) get sample from input pin, until no sample avalible;
2) if have no output sample pointer, first get a output sample from output pin;
3) call transform pure virtual method, if have delivered data,
call outputpin deliver method;


the decoder and encoder, only imp the input/output pin initialize, check media type,
transform, etc.

******************************************************************************/


/*{{{ async_plugin inherit block; *********************************************/

STX_COM_FUNC_DECL_ALL(async_plugin,async_plugin_vt);


/*{{{STX_MSG_ENTRY_DECLARE**************************************************/

/* to do : add msg proc entry  declaration here; */
STX_MSG_ENTRY_DECLARE(on_new_segment)

/*}}}***********************************************************************/

/*{{{STX_BEGIN_MSG_MAP******************************************************/
STX_BEGIN_MSG_MAP

/* to do : add msg proc entry name here; */
ON_STX_MSG(STX_MSG_NewSegment,on_new_segment)

STX_END_MSG_MAP
/*}}}***********************************************************************/


/*{{{STX_BEGIN_MSG_RESPONSE_MAP*********************************************/
STX_BEGIN_MSG_RESPONSE_MAP

/* to do : add msg process entry name here; */

STX_END_MSG_RESPONSE_MAP
/*}}}***********************************************************************/

/*{{{***********************************************************************/
STX_MSG_PROC STX_RESULT 
async_plugin_vt_xxx_dispatch_msg
( STX_HANDLE h, stx_base_message* p_msg  )
{
    STX_RESULT			i_err;

    async_plugin*		p_asy;

    STX_MAKE_THE(stream_filter);

    i_err = the->dispatch_msg( h, p_msg );
    if( STX_MSG_CLOSED == i_err ) {
        return i_err;
    }

    p_asy = &the->async_plugin_vt;

    STX_DISPATCH_MSG( p_asy, p_msg )
}
/*}}}***********************************************************************/


/*{{{***********************************************************************/
STX_MSG_PROC STX_RESULT 
async_plugin_vt_xxx_response_msg
( STX_HANDLE h, stx_base_message* p_msg  )
{
    STX_RESULT			i_err;

    async_plugin*		p_asy;

    STX_MAKE_THE(stream_filter);

    i_err = the->response_msg( h, p_msg );
    if( STX_MSG_CLOSED == i_err ) {
        return i_err;
    }

    p_asy = &the->async_plugin_vt;

    STX_RESPONSE_MSG( p_asy, p_msg );
}
/*}}}***********************************************************************/

/*}}}async_plugin inherit block; ***********************************************/



/*{{{***********************************************************************/
STX_SHARE	void		stream_filter_flush(STX_HANDLE h);

STX_SHARE    void 	  	stream_filter_new_segment(STX_HANDLE h);
/*}}}***********************************************************************/







/***************************************************************************
stx_stream_filter_create
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
p_obj is not NULL, meaning the interface is declared at sub class internal;
***************************************************************************/
STX_CONSTRUCTOR_IMP 
STX_NEW_BEGIN(stream_filter)

	STX_RESULT i_err;

    i_err = STX_FAIL;

	the->run = stream_filter_run;
	the->flush = stream_filter_flush;
	the->new_segment = stream_filter_new_segment;

	STX_SET_THE(async_plugin);
	STX_COM_FUNC_INIT_ALL(async_plugin,the->async_plugin_vt,async_plugin_vt);

STX_NEW_END()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API_IMP	STX_RESULT	
STX_COM_FUNC_NAME(stream_filter,query_interf)
(STX_HANDLE h, stx_gid gid, STX_HANDLE* pp_interf)
{
	stream_filter* the = (stream_filter*)h;
	// add code;
	if( IS_EQUAL_GID(gid,STX_IID_BaseCom) ) {
		the->i_ref ++;
		*pp_interf = the;
		return STX_OK;
	}
	if( IS_EQUAL_GID(gid,STX_IID_BaseFilter) ) {
		the->i_ref ++;
		*pp_interf = &the->stx_base_filter_vt;
		return STX_OK;
	}

	return STX_ERR_INVALID_PARAM;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API_IMP	s32 
STX_COM_FUNC_NAME(stream_filter,add_ref)
( STX_HANDLE h )
{
	stream_filter* the = (stream_filter*)h;
	// add code;
	the->i_ref ++;
	return the->i_ref;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_PURE_IMP s32 
STX_COM_FUNC_NAME(stream_filter,release)
( STX_HANDLE h )
{
	STX_DIRECT_THE(stream_filter);

	the->i_ref --;

	if( the->i_ref > 0 ){
		return the->i_ref;
	}

    STX_DELETE( &the->async_plugin_vt );

	if( the->b_inst){
		stx_free(the);
	}

	return 0;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_SHARE_IMP void	
stream_filter_flush(STX_HANDLE h)
{
    STX_MAKE_THE(stream_filter);

    if( the->p_input_data ) {
        the->p_input_data = STX_NULL;
    }

    if( the->p_output_data ) {
        the->p_output_data = STX_NULL;
    }

}



/***************************************************************************
stream_filter_run
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_SHARE_IMP STX_RESULT	
async_plugin_vt_xxx_run
(STX_HANDLE h,u32 i_wait_milisec)
{

    STX_RESULT			   i_err;

    stx_media_type*        p_in;

    stx_media_type*        p_out;


    STX_MAKE_THE(stream_filter);

    for( ; ; ) {

        if( !the->p_output_data ) {

            i_err = the->p_mem_alloc->get_media_data( the->p_mem_alloc,&the->p_output_data, 10 ); 

            if( STX_WOUNLD_BLOCK == i_err ) {
                i_err = STX_OK;
                break;
            }

            if( STX_OK != i_err ) {
                break;
            }
        }

        if( !the->b_deliver ) {

            if( !the->p_input_data ) {

                i_err = the->p_input_pin->receive( the->p_input_pin, &the->p_input_data, 10 );
                if( STX_WOUNLD_BLOCK == i_err ) {
                    i_err = STX_OK;
                    break;
                }
                if( i_err < 0 ) {
                    break;
                }
            }

            i_err = the->stx_base_filter_vt.transform( 
                &the->stx_base_filter_vt, 
                p_in = the->p_input_pin->get_media_type(the->p_input_pin),
                the->p_input_data, 
                p_out = the->p_output_pin->get_media_type(the->p_output_pin),
                the->p_output_data );

            the->p_input_data->com.release(the->p_input_data);
            the->p_input_data = STX_NULL;

            p_in->com.release(p_in);
            p_out->com.release(p_out);

            if( STX_DELIVER == i_err ) {

                i_err = the->p_output_pin->deliver( the->p_output_pin, the->p_output_data, 10 );
                if( STX_WOUNLD_BLOCK == i_err ) {
                    the->b_deliver = TRUE;
                    i_err = STX_OK;
                    break;
                }

                the->p_output_data->com.release(the->p_output_data);
                the->p_output_data = STX_NULL;

                return STX_OK;
            }
        }
        else {

            i_err = the->p_output_pin->deliver( the->p_output_pin, the->p_output_data, 10 );
            if( STX_WOUNLD_BLOCK == i_err ) {
                i_err = STX_OK;
                break;
            }

            the->b_deliver = FALSE;
            the->p_output_data->com.release(the->p_output_data);
            the->p_output_data = STX_NULL;

            return STX_OK;
        }

        if( i_err < 0 ) {
            break;
        }
    }

    return i_err;
}



/***************************************************************************
on_new_segment
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT on_new_segment(STX_HANDLE h,stx_msg_param* p_param )
{
    STX_MAKE_THE(stream_filter);

    return STX_MSG_CLOSED;
}


/***************************************************************************
stream_filter_new_segment
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_SHARE_IMP void 
stream_filter_new_segment(STX_HANDLE h)
{
    STX_MAKE_THE(stream_filter);
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT 
async_plugin_vt_xxx_up_stream_msg
(STX_HANDLE h, stx_base_message* p_msg )
{
	STX_MAKE_THE(stream_filter);
	return the->up_stream_msg(the,p_msg);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
render have no output stream pin , so return pass value;
***************************************************************************/
STX_MSG_PROC STX_RESULT 
async_plugin_vt_xxx_down_stream_msg
(STX_HANDLE h, stx_base_message* p_msg)
{
	STX_MAKE_THE(stream_filter);
	return the->down_stream_msg(the,p_msg);
}
