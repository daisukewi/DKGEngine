

/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/


#include "stdio.h"
#include "stdlib.h"
#include "fcntl.h"
#include "malloc.h"
#include "memory.h"
#include "string.h"

#include "stx_mem.h"
#include "stx_debug.h"
#include "stx_mutex.h"
#include "stx_semaphore.h"
#include "stx_gid_def.h"
#include "stx_module_reg.h"
#include "stx_direct_pin.h"
#include "stx_async_plugin.h"



#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif

/*  to do:

*/
STX_INPUT_MEDIA_TYPE_MAP_BEGIN(source_demo)
MEDIA_TYPE_MAP_ITEM(MEDIATYPE_Video,STX_GID_NULL)
STX_INPUT_MEDIA_TYPE_MAP_END()

STX_OUTPUT_MEDIA_TYPE_MAP_BEGIN(source_demo)
MEDIA_TYPE_MAP_ITEM(MEDIATYPE_Stream,STX_GID_NULL)
STX_OUTPUT_MEDIA_TYPE_MAP_END()




STX_API
STX_COM(source_demo);


STX_COM_BEGIN(source_demo);

	/* */
	STX_PUBLIC(stx_base_source)

	/* base filter; */
	STX_PUBLIC(stx_base_filter)
	STX_COM_DATA_DEFAULT(stx_base_filter)

	/* */
	STX_PUBLIC(stx_base_control)

	/* */
	STX_PUBLIC(stx_media_info)

	/* other members; */

	sint32						i_streams;

	stx_base_pin**				pp_output_pin;
};



STX_COM_FUNC_DECL_DEFAULT(stx_media_info,stx_media_info_vt);
STX_COM_FUNC_DECL_DEFAULT(stx_base_control,stx_base_control_vt);

STX_COM_FUNC_DECL_DEFAULT(stx_base_filter,stx_base_filter_vt);
STX_COM_FUNCIMP_DEFAULT(source_demo,stx_base_filter,stx_base_filter_vt);


STX_COM_FUNC_DECL_DEFAULT(stx_base_source,stx_base_source_vt);
STX_COM_FUNCIMP_DEFAULT(source_demo,stx_base_source,stx_base_source_vt);



/*{{{STX_MSG_ENTRY_DECLARE**************************************************/

/* to do : add msg proc entry  declaration here; */

/*}}}***********************************************************************/


/*{{{STX_BEGIN_MSG_MAP******************************************************/
STX_BEGIN_MSG_MAP(the_msg_data)

/* to do : add msg proc entry name here; */

STX_END_MSG_MAP
/*}}}***********************************************************************/


/*{{{STX_BEGIN_MSG_RESPONSE_MAP*********************************************/
STX_BEGIN_MSG_RESPONSE_MAP(the_msg_response)

/* to do : add msg process entry name here; */

STX_END_MSG_RESPONSE_MAP
/*}}}***********************************************************************/


/*{{{STX_DISPATHCH_MSG_PROC*************************************************/
STX_DISPATCH_MSG_PROC( dispatch_msg ,the_msg_data)
/*}}}***********************************************************************/


/*{{{STX_RESPONSE_MSG_PROC**************************************************/
STX_RESPONSE_MSG_PROC( response_msg, the_msg_response )
/*}}}***********************************************************************/


/*}}}async_plugin inherit block; ***********************************************/


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_COM_MAP_BEGIN(source_demo)
/**/STX_COM_MAP_ITEM(STX_IID_FileSource)
/**/STX_COM_MAP_ITEM(STX_IID_BaseFilter)
/**/STX_COM_MAP_ITEM(STX_IID_BaseControl)
/**/STX_COM_MAP_ITEM(STX_IID_MediaInfo)
STX_COM_MAP_END()

STX_NEW_BEGIN(source_demo)

	STX_SET_THE(stx_base_source);
	STX_COM_NEW_DEFAULT(
		stx_base_source,
		the->stx_base_source_vt,
		stx_base_source_vt,
		STX_GID_NULL,
		STX_CATEGORY_FileSource,
		"StreamX source demo");

	STX_SET_THE(stx_base_filter);
	STX_COM_NEW_DEFAULT(
		stx_base_filter,
		the->stx_base_filter_vt,
		stx_base_filter_vt,
		STX_GID_NULL,
		STX_CATEGORY_FileSource,
		"StreamX source demo");

	STX_SET_THE(stx_base_control);
	STX_COM_NEW_DEFAULT(
		stx_base_control,
		the->stx_base_control_vt,
		stx_base_control_vt,
		STX_GID_NULL,
		STX_CATEGORY_FileSource,
		"StreamX source demo");

	STX_SET_THE(stx_media_info);
	STX_COM_NEW_DEFAULT(
		stx_media_info,
		the->stx_media_info_vt,
		stx_media_info_vt,
		STX_GID_NULL,
		STX_CATEGORY_FileSource,
		"StreamX source demo");

STX_NEW_END()




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API_IMP	
STX_QUERY_BEGIN(source_demo)
	STX_COM_QUERY_DEFAULT(stx_base_source,the->stx_base_source_vt);
	STX_COM_QUERY_DEFAULT(stx_base_filter,the->stx_base_filter_vt);
	STX_COM_QUERY_DEFAULT(stx_base_control,the->stx_base_control_vt);
	STX_COM_QUERY_DEFAULT(stx_media_info,the->stx_media_info_vt);
STX_QUERY_END()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API_IMP
STX_DELETE_BEGIN(source_demo)

	STX_COM_DELETE_DEFAULT(stx_base_filter);

STX_DELETE_END(
STX_COM_DELETE_BEGIN(stx_base_filter)
,
STX_COM_DELETE_END(stx_base_filter)
)




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_base_filter_vt_xxx_set_input_media_type
( STX_HANDLE h,stx_media_type * p_mtype)
{
	STX_MAP_THE(source_demo);

	return STX_ERR_NOT_IMP;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_base_filter_vt_xxx_set_output_media_type
( STX_HANDLE h,stx_media_type * p_mtype)
{
	STX_MAP_THE(source_demo);

	return STX_ERR_NOT_IMP;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE	STX_RESULT		
stx_base_filter_vt_xxx_enum_input_pin
(STX_HANDLE h,sint32* i_index,stx_base_pin** pp_pin)
{
	STX_MAP_THE(source_demo);

	return STX_ERR_NOT_IMP;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE	STX_RESULT 
stx_base_filter_vt_plug_xxx_send_msg
(STX_HANDLE h,stx_base_message * p_msg)
{
	STX_MAP_THE(source_demo);

	return STX_OK;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE	STX_RESULT		
stx_base_filter_vt_xxx_enum_output_pin
(STX_HANDLE h,sint32* i_index,stx_base_pin** pp_pin)
{
	STX_MAP_THE(source_demo);

	return STX_ERR_NOT_IMP;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_check_input_media_type
(STX_HANDLE h,stx_media_type* p_mtyp)
{
	STX_MAP_THE(source_demo);

	return STX_ERR_NOT_IMP;
}

/***************************************************************************
 RETURN VALUE:
 INPUT:
 OUTPUT:
 NOTE:
 ***************************************************************************/
STX_PURE STX_RESULT	stx_base_filter_vt_xxx_check_output_media_type
(STX_HANDLE h,stx_media_type* p_mtyp)
{
	STX_MAP_THE(source_demo);

	return STX_ERR_NOT_IMP;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_new_segment( STX_HANDLE h)
{
	STX_MAP_THE(source_demo);

	return STX_ERR_NOT_IMP;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_flush
(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	STX_MAP_THE(source_demo);

	return STX_ERR_NOT_IMP;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_start
(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	STX_MAP_THE(source_demo);

	return STX_ERR_NOT_IMP;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_stop
(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	STX_MAP_THE(source_demo);

	return STX_ERR_NOT_IMP;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_receive
(
	STX_HANDLE			h,
	stx_base_pin*		h_pin, // which input pin;
	stx_base_pin**		hh_pin, // output pin;
	stx_media_data**	pp_mdat, // output media data;
	stx_sync_inf*		h_sync 
)
{
	STX_MAP_THE(source_demo);

	return STX_ERR_NOT_SUPPORT;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_deliver
(
	STX_HANDLE			h,
	stx_base_pin*		h_pin, // which input pin;
	stx_base_pin**		hh_pin, // output pin;
	stx_media_data**	pp_mdat, // output media data;
	stx_sync_inf*		h_sync 
)
{
	STX_MAP_THE(source_demo);

	return STX_ERR_NOT_IMP;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_transform
(
 /**/STX_HANDLE			h, 
 /**/stx_base_pin*		h_pin, 
 /**/stx_media_data*	p_mdat, 
 /**/stx_base_pin**		hh_pin,
 /**/stx_media_data**	pp_mdat,
 /**/stx_sync_inf*		h_sync
 )
{
	STX_MAP_THE(source_demo);

	return STX_ERR_NOT_IMP;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT async_plugin_vt_xxx_run
( STX_HANDLE h, u32 i_wait_time_milisec)
{
	STX_MAP_THE(source_demo);

	return STX_ERR_NOT_IMP;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT async_plugin_vt_xxx_up_stream_msg
(STX_HANDLE h, stx_base_message* p_msg)
{
	STX_MAP_THE(source_demo);

	return STX_ERR_NOT_IMP;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT async_plugin_vt_xxx_down_stream_msg
(STX_HANDLE h, stx_base_message* p_msg)
{
	STX_MAP_THE(source_demo);

	return STX_ERR_NOT_IMP;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_source_vt_xxx_load_stream
(STX_HANDLE h, const char* sz_stream, stx_sync_inf* h_sync )
{
	STX_MAP_THE(source_demo);

	return STX_ERR_NOT_IMP;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE void 
stx_base_source_vt_xxx_close_stream(STX_HANDLE h)
{
	STX_MAP_THE(source_demo);

	__STX_ERR_NOT_IMP
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT		
stx_base_source_vt_xxx_set_pos(STX_HANDLE h,int64_t i_pos)
{
	STX_MAP_THE(source_demo);

	return STX_ERR_NOT_IMP;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT		
stx_base_source_vt_xxx_get_pos(STX_HANDLE h,int64_t *i_pos)
{
	STX_MAP_THE(source_demo);

	return STX_ERR_NOT_IMP;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT		
stx_base_source_vt_xxx_get_size(STX_HANDLE h,int64_t *i_size)
{
	STX_MAP_THE(source_demo);

	return STX_ERR_NOT_IMP;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_media_info_vt_xxx_get_statistic
(STX_HANDLE h,s32 * size,char ** desc )
{
	STX_MAP_THE(source_demo);

	return STX_ERR_NOT_IMP;

}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_media_info_vt_xxx_get_desc
(STX_HANDLE h, sint32* i_len, char** sz_desc )
{
	STX_MAP_THE(source_demo);

	return STX_ERR_NOT_IMP;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_media_info_vt_xxx_get_total_time
(STX_HANDLE h,int64_t *i_time)
{
	STX_MAP_THE(source_demo);

	return STX_ERR_NOT_IMP;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_media_info_vt_xxx_get_current_time
(STX_HANDLE h,int64_t *i_time)
{
	STX_MAP_THE(source_demo);

	return STX_ERR_NOT_IMP;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_media_info_vt_xxx_time_to_pos
(STX_HANDLE h,int64_t i_time,offset_t * pos )
{
	STX_MAP_THE(source_demo);

	return STX_ERR_NOT_IMP;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT	stx_media_info_vt_xxx_pos_to_time
(STX_HANDLE h, offset_t pos ,int64_t* i_time )
{
	STX_MAP_THE(source_demo);

	return STX_ERR_NOT_IMP;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_get_caps
(STX_HANDLE h,stx_xio* h_xio)
{
	STX_MAP_THE(source_demo);

	return STX_ERR_NOT_IMP;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT	stx_base_control_vt_xxx_get_status
(STX_HANDLE h,uint32* i_status)
{
	STX_MAP_THE(source_demo);

	return STX_ERR_NOT_IMP;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT	stx_base_control_vt_xxx_play(STX_HANDLE h)
{
	STX_MAP_THE(source_demo);

	return STX_ERR_NOT_IMP;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_pause(STX_HANDLE h)
{
	STX_MAP_THE(source_demo);

	return STX_ERR_NOT_IMP;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT	stx_base_control_vt_xxx_resume(STX_HANDLE h)
{
	STX_MAP_THE(source_demo);

	return STX_ERR_NOT_IMP;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_set
(STX_HANDLE h,u32 i_flag,size_t i_set)
{
	STX_MAP_THE(source_demo);
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_stop(STX_HANDLE h)
{
	STX_MAP_THE(source_demo);

	return STX_ERR_NOT_IMP;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_next(STX_HANDLE h)
{
	STX_MAP_THE(source_demo);

	return STX_ERR_NOT_IMP;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_prev(STX_HANDLE h)
{
	STX_MAP_THE(source_demo);

	return STX_ERR_NOT_IMP;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_step(STX_HANDLE h)
{
	STX_MAP_THE(source_demo);

	return STX_ERR_NOT_IMP;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static STX_RESULT stx_base_filter_vt_plug_xxx_run
(STX_HANDLE h,stx_sync_inf* h_sync )
{
	STX_MAP_THE(source_demo);

	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_get_property
(STX_HANDLE h,stx_xio* h_xio)
{
	STX_MAP_THE(source_demo);

	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_set_property
(STX_HANDLE h,stx_xio* h_xio)
{
	STX_MAP_THE(source_demo);

	return STX_ERR_NOT_SUPPORT;
}