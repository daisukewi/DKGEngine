/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#include "stdio.h"
#include "stdlib.h"
#include "fcntl.h"
#include "malloc.h"
#include "memory.h"
#include "string.h"
#include "math.h"

#include "stx_mem.h"
#include "stx_debug.h"

#include "blend_api.h"
#include "stx_cpuid.h"



static void blend_field_c(u8* three[3],u8* dest,s32 width);

static void blend_field_sse2(u8* three[3],u8* dest,s32 width);

static void (*blend)(u8* three[3],u8* dest,s32 width);



void blend_api_init(u32 mm_flags)
{
	blend = blend_field_c;

	if( mm_flags & MM_SSE2 ) {
		blend = blend_field_sse2;
	}
}


void blend_field(u8* three[3],u8* dest,s32 width)
{
	blend(three,dest,width);
}



#define CAVGB(A,B)	 ( ( ( (A|B) & x_01 ) + ((A >> 1) & x_7f)  + ( (B >> 1) & x_7f) ) )


static void blend_field_c(u8* three[3],u8* dest,s32 width)
{
	size_t x0,x1,x2;
	s32 const step = sizeof(size_t);

	for( ; ; ) {

		do{
			x0 = *(size_t*)three[0];
			x1 = *(size_t*)three[1];
			x2 = *(size_t*)three[2];
			three[0] += step;
			three[1] += step;
			three[2] += step;
			x2 = CAVGB(x0,x2);
			*(size_t*)dest = CAVGB(x1,x2);
			dest += step;
			width -= step;

		}while( width >= step);

		if( 0 == width ) {
			break;
		}

		{
			s32 const dit = step - width;
			three[0] -= dit;
			three[1] -= dit;
			three[2] -= dit;
			width = step;
		}

	} // for( ; ; ) {
}



static void blend_field_sse2(u8* three[3],u8* dest,s32 width)
{
	XMMI_DECLARE16;

	for( ; ; ) {

		do{
			ixmm0 = _mm_loadu_si128(CONV_PXMMI(three[0]));
			ixmm1 = _mm_loadu_si128(CONV_PXMMI(three[1]));
			ixmm2 = _mm_loadu_si128(CONV_PXMMI(three[2]));
			three[0] += 16;
			three[1] += 16;
			three[2] += 16;
			dest += 16;
			width -= 16;
			ixmm0 = _mm_avg_epu16(ixmm0,ixmm2);
			ixmm0 = _mm_avg_epu16(ixmm0,ixmm1);
			_mm_storeu_si128(CONV_PXMMI(dest-16),ixmm0);
		}while( width >= 16);

		if( 0 == width ) {
			break;
		}

		{
			s32 const dit = 16 - width;
			three[0] -= dit;
			three[1] -= dit;
			three[2] -= dit;
			width = 16;
		}

	} // for( ; ; ) {

}
