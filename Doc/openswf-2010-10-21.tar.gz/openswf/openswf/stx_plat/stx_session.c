/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-11
***********************************************************************************/
#include "stdio.h"
#include "stdlib.h"
#include "fcntl.h"
#include "malloc.h"
#include "memory.h"
#include "string.h"

#include "stx_protocol.h"
#include "stx_session.h"
#include "stx_os.h"
#include "stx_mem.h"
#include "stx_debug.h"
#include "stx_module_reg.h"
#include "stx_io_as.h"
#include "stx_stack.h"
#include "stx_io_interleaved.h"
#include "stp_download.h"


#include "base_canvas.h"


#include "app_wnd.h"
#include "ActiveMovieWindow.h"

#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif


// {481DEE52-C8EE-4ecb-803A-A9B822603C67}
DEFINE_XGUID( STX_IID_BaseSession,
0x481dee52, 0xc8ee, 0x4ecb, 0x80, 0x3a, 0xa9, 0xb8, 0x22, 0x60, 0x3c, 0x67);


// {ECC1649C-8CAE-4224-8911-C0B0677058E4}
DEFINE_XGUID( STX_CLSID_StxSession,
0xecc1649c, 0x8cae, 0x4224, 0x89, 0x11, 0xc0, 0xb0, 0x67, 0x70, 0x58, 0xe4);

char* g_sz_StreamX_StxSession = "StreamX stx session plugin";



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API_IMP CREATE_STX_COM(stx_base_session,STX_IID_BaseSession,stx_session);


enum stx_prot_stat{
	STX_PROT_PREFETCH_HDR = 1,
	STX_PROT_PREFETCH_BODY,
	STX_PROT_RPEFETCH_PACKAGE,  // got .gph; create canvas, load stream, run graph;
	STX_PROT_OPEN_URL,			// get graph status;
	STX_PROT_SEND_RESPONSE,
	STX_PROT_FLUSH_RESPONSE,
	STX_PROT_RUN_GRAPH,
	STX_PROT_STOP_BEGIN,
	STX_PROT_STOP_GRAPH,
	STX_PROT_STOP_STREAM,
	STX_PROT_IDLE,
	STX_PROT_STOP,
};

STX_INPUT_MEDIA_TYPE_MAP_BEGIN(stx_session)
STX_INPUT_MEDIA_TYPE_MAP_END()

STX_OUTPUT_MEDIA_TYPE_MAP_BEGIN(stx_session)
STX_OUTPUT_MEDIA_TYPE_MAP_END()


STX_COM_BEGIN(stx_session);
/**/
/**/STX_PUBLIC(stx_base_filter)
/**/STX_COM_DATA_DEFAULT(stx_base_filter)
/**/
/**/STX_PUBLIC(stx_base_session)
/**/STX_PUBLIC(stx_app_wnd_callback)
/**/
/**/stx_base_plugin*		h_plug;
/**/stx_base_filter*		h_flt;
/**/stx_base_session*		h_ses;
/**/stx_app_wnd_callback*	h_wcall;
/**/
/**/THEE					h_task;
/**/THEE					h_stack;
/**/THEE					h_run;
/**/THEE					h_stop;
/**/THEE					h_mutex;
/**/stx_prot_callback*		h_callback;
/**/stx_xio*				h_socket;			// connection io;
/**/stx_xio*				h_input_stream;		// read in buffer;
/**/
/**/stx_xio*				h_response;			// response buffer
/**/s32						i_response_size;
/**/
/**/stx_interleaved*		h_output_base;		// interleaved io;
/**/stx_xio*				h_output_response;	// response/msg channel
/**/s32						i_output;
/**/stp_subchannel			h_output_stream[8];   // stream channel
/**/
/**/char*					sz_url;
/**/char*					sz_graph;
/**/base_canvas*			h_canvas;		// convert graph use canvas;
/**/s64						i_last_time; // last time have data received;
/**/b32						b_graph_run;
/**/
STX_COM_END();

#define session_lock()	stx_waitfor_mutex(the->h_mutex,INFINITE)
#define session_unlock() stx_release_mutex(the->h_mutex)


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_COM_FUNC_DECL_DEFAULT(stx_base_filter,stx_base_filter_vt);
STX_COM_FUNCIMP_DEFAULT(stx_session,stx_base_filter,stx_base_filter_vt);


STX_COM_FUNC_DECL_DEFAULT(stx_base_session,stx_base_session_vt);
STX_COM_FUNCIMP_DEFAULT(stx_session,stx_base_session,stx_base_session_vt);

STX_COM_FUNC_DECL_DEFAULT(stx_app_wnd_callback,stx_app_wnd_callback_vt);
STX_COM_FUNCIMP_DEFAULT(stx_session,stx_app_wnd_callback,stx_app_wnd_callback_vt);


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_PRIVATE STX_RESULT	init_context(stx_session* the);
STX_PRIVATE void		close_context(stx_session* the);


STX_PRIVATE STX_RESULT	parse_header(stx_session* the,stx_sync_inf* h_sync);
STX_PRIVATE STX_RESULT	parse_body(stx_session* the,stx_sync_inf* h_sync);
STX_PRIVATE STX_RESULT	parse_attachment(stx_session* the,stx_sync_inf* h_sync);

STX_PRIVATE STX_RESULT	open_url(stx_session* the, stx_sync_inf* h_sync );
STX_PRIVATE STX_RESULT	write_response( stx_session* the,stx_sync_inf* h_sync );
STX_PRIVATE STX_RESULT	write_response_play( stx_session* the,stx_sync_inf* h_sync );
STX_PRIVATE STX_RESULT	send_response(stx_session* the,stx_sync_inf* h_sync);
STX_PRIVATE STX_RESULT	flush_response(stx_session* the,stx_sync_inf* h_sync);
STX_PRIVATE STX_RESULT	response_err( stx_session* the, s32 i_err_code );
STX_PRIVATE STX_RESULT	run_graph(stx_session* the,stx_sync_inf* h_sync);
STX_PRIVATE STX_RESULT	stop_graph(stx_session* the,stx_sync_inf* h_sync);
STX_PRIVATE STX_RESULT	stop_stream(stx_session* the,stx_sync_inf* h_sync);

STX_PRIVATE STX_RESULT  get_url(stx_session* the, stx_xini* h_xini);

STX_PRIVATE STX_RESULT	run_proc(stx_session* the,stx_sync_inf* h_sync );


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

/*{{{STX_MSG_ENTRY_DECLARE**************************************************/
STX_MSG_ENTRY_DECLARE(on_query)
STX_MSG_ENTRY_DECLARE(on_auto_stop)
STX_MSG_ENTRY_DECLARE(on_app_stop)
/*}}}***********************************************************************/


/*{{{STX_BEGIN_MSG_MAP******************************************************/
STX_BEGIN_MSG_MAP(the_msg_data)
/* to do : add msg process entry here; */
/**/ON_STX_MSG(STX_MSG_QueryObject,on_query)
/**/ON_STX_MSG(STX_MSG_AutoStop,on_auto_stop)
/**/ON_STX_MSG(STX_MSG_AppStop,on_app_stop)
STX_END_MSG_MAP
/*}}}***********************************************************************/


/*{{{STX_DISPATCH_MSG_PROC**************************************************/
STX_DISPATCH_MSG_PROC( dispatch_msg,the_msg_data )
/*}}}***********************************************************************/


/*{{{STX_BEGIN_MSG_RESPONSE_MAP*********************************************/
STX_BEGIN_MSG_RESPONSE_MAP(the_msg_response)
/* to do : add msg process entry here; */
STX_END_MSG_RESPONSE_MAP
/*}}}***********************************************************************/

/*{{{STX_RESPONSE_MSG_PROC**************************************************/
STX_RESPONSE_MSG_PROC( response_msg,the_msg_response )
/*}}}***********************************************************************/






/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_COM_MAP_BEGIN(stx_session)
/**/STX_COM_MAP_ITEM(STX_IID_BaseFilter)
/**/STX_COM_MAP_ITEM(STX_IID_BaseSession)
/**/STX_COM_MAP_ITEM(STX_IID_AppWndCallback)
STX_COM_MAP_END()


STX_NEW_BEGIN(stx_session)
{
	//STX_RESULT i_err;

	STX_SET_THE(stx_base_filter);
	STX_COM_NEW_DEFAULT(stx_base_filter,the->stx_base_filter_vt,stx_base_filter_vt,
		STX_CLSID_StxSession,STX_CATEGORY_IntermediateFilter,g_sz_StreamX_StxSession);

	STX_SET_THE(stx_base_session);
	STX_COM_NEW_DEFAULT(stx_base_session,the->stx_base_session_vt,stx_base_session_vt,
		STX_CLSID_StxSession,STX_CATEGORY_IntermediateFilter,g_sz_StreamX_StxSession);

	STX_SET_THE(stx_app_wnd_callback);
	STX_COM_NEW_DEFAULT(stx_app_wnd_callback,the->stx_app_wnd_callback_vt,stx_app_wnd_callback_vt,
		STX_CLSID_StxSession,STX_CATEGORY_IntermediateFilter,g_sz_StreamX_StxSession);

	// init interface pointer;
	the->h_plug = (stx_base_plugin*)&the->stx_base_filter_vt;
	the->h_flt = &the->stx_base_filter_vt;
	the->h_ses = &the->stx_base_session_vt;
	the->h_wcall = &the->stx_app_wnd_callback_vt;

	the->h_mutex = stx_create_mutex(NULL,0,NULL);
	if( !the->h_mutex ) {
		break;
	}

	the->h_run = stx_stack_create();
	if( !the->h_run) {
		break;
	}
	the->h_stop = stx_stack_create();
	if( !the->h_stop) {
		break;
	}

	the->h_input_stream = XCREATE(stx_io_stream,NULL);
	if( !the->h_input_stream ) {
		break;
	}

	the->h_response = XCREATE(stx_io_stream,NULL);
	if( !the->h_response ) {
		break;
	}

	// write log;
}
STX_NEW_END()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API_IMP	STX_QUERY_BEGIN(stx_session)
{
	STX_COM_QUERY_DEFAULT(stx_base_filter,the->stx_base_filter_vt);
	STX_COM_QUERY_DEFAULT(stx_base_session,the->stx_base_session_vt);
	STX_COM_QUERY_DEFAULT(stx_app_wnd_callback,the->stx_app_wnd_callback_vt);
}
STX_QUERY_END()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API_IMP	STX_DELETE_BEGIN(stx_session)
{
	//write log;
	if( the->h_callback ) {
		the->h_callback->notify_ses_close(the->h_callback,the->h_plug);
		the->h_callback->release(the->h_callback);
	}

	{
		char szins[64];
		stx_gid insgid = the->h_plug->get_insid(the->h_plug);
		binary_to_string(16,insgid.data,szins);
		stx_log("session<%s> closed \r\n",szins);
	}

	if( the->sz_url ) {
		stx_free(the->sz_url); 
		the->sz_url = NULL;
	}

	if( the->sz_graph ) {
		stx_free(the->sz_graph); 
		the->sz_graph = NULL;
	}

	close_context(the);

	// release input buffer;
	SAFE_CLOSEXIO( the->h_input_stream );

	// release respond buffer;
	SAFE_CLOSEXIO( the->h_response );

	if( the->h_run ) {
		stx_stack_close(the->h_run);
	}

	if( the->h_stop ) {
		stx_stack_close(the->h_stop);
	}

	if( the->h_mutex) {
		stx_close_mutex(the->h_mutex);
	}

	STX_COM_DELETE_DEFAULT(stx_base_filter);
}
STX_DELETE_END
(
STX_COM_DELETE_BEGIN(stx_base_filter)
,
STX_COM_DELETE_END(stx_base_filter)
)



 /***************************************************************************
 RETURN VALUE:
 INPUT:
 OUTPUT:
 NOTE:
 ***************************************************************************/
 STX_PRIVATE STX_RESULT init_context(stx_session* the)
{
	STX_RESULT		i_err;

	i_err = STX_FAIL;

	do{
		// create output io base;
		the->h_output_base = XCREATE(stx_io_int,NULL,the->h_socket,O_WRONLY);
		if( !the->h_output_base ) {
			break;
		}

		// create response channel;
		i_err = the->h_output_base->create_channel(the->h_output_base,
			STP_ID_SYS_RESPONSE,&the->h_output_response);
		if( STX_OK != i_err ) {
			break;
		}

		//the->h_output_stream->open(the->h_output_stream,"e:\\write.dump",O_CREAT);

		i_err = STX_OK;

	}while(FALSE);

	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE void close_context(stx_session* the)
{
	// release stream channel;
	if( the->i_output ) {
		s32 i;
		for( i = 0; i < the->i_output; i ++ ) {
			SAFE_CLOSEXIO(the->h_output_stream[i].h_data);
			if( the->h_output_stream[i].major_name ) {
				stx_free(the->h_output_stream[i].major_name);
				the->h_output_stream[i].major_name = NULL;
			}
			if( the->h_output_stream[i].sub_name ) {
				stx_free(the->h_output_stream[i].sub_name);
				the->h_output_stream[i].sub_name = NULL;
			}
			if( the->h_output_stream[i].p_hdr ) {
				stx_free(the->h_output_stream[i].p_hdr);
				the->h_output_stream[i].p_hdr = NULL;
			}
		}
		the->i_output = 0;
	}

	// release response channel;
	SAFE_CLOSEXIO(the->h_output_response );
	// release output base;
	SAFE_XDELETE0( the->h_output_base );

	if( the->h_canvas ) {
		canvas_close(the->h_canvas);
		the->h_canvas = NULL;
	}

}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_send_msg
(STX_HANDLE h,stx_base_message * p_msg)
{
	STX_RESULT	i_err;

	STX_MAP_THE(stx_session);

	do{
		u32			i_type;
		s32			i = 0;

		i_err = dispatch_msg(h,p_msg);
		if( i_err < 0 || p_msg->is_msg_closed(p_msg)) {
			break;
		}

		i_type = p_msg->get_msg_type(p_msg);

		if( i_type & STX_MSG_TYPE_UPSTREAM ) {
			i_err = the->p_parent->send_msg(the->p_parent,p_msg);
		}
		else if (i_type & STX_MSG_TYPE_DOWNSTREAM ) {
			i_err = the->h_canvas->m_hGph->send_msg(the->h_canvas->m_hGph,p_msg);
		}
		if( i_err < 0 || p_msg->is_msg_closed(p_msg)) {
			break;
		}

		i_err = response_msg(h,p_msg);
		if( i_err < 0 || p_msg->is_msg_closed(p_msg)) {
			break;
		}

		i_err = STX_OK;

	}while(FALSE);

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT: 
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT 
on_auto_stop(STX_HANDLE h,stx_base_message* p_msg )
{
	STX_MAP_THE(stx_session);
	{
		// push plugin interface pointer;
		STX_HANDLE h_stack = p_msg->get_stack(p_msg);
		stx_stack_push(h_stack,(size_t)&the->stx_base_filter_vt);
		return STX_OK;
	}
}


/***************************************************************************
RETURN VALUE:
INPUT: 
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT 
on_app_stop(STX_HANDLE h,stx_base_message* p_msg )
{

	STX_MAP_THE(stx_session);
	{

		//#error first need stop the task, so need a stop status, to call control->stop method;

		STX_RESULT			i_err,i_err_ext;
		stx_msg_cnt*		p_cnt;
		STX_HANDLE			h_stack;
		stx_base_filter*	h_plug;
		stx_base_source*	h_src;

		p_cnt = p_msg->get_msg_cnt(p_msg);

		h_plug = NULL;
		h_src = the->h_canvas->m_hSrc;
		i_err = h_src->query_interf(h_src,STX_IID_BasePlugin,(void**)&h_plug);
		if( STX_OK != i_err ) {
			return i_err;
		}
		SAFE_XDELETE(h_plug);

		if( (size_t)h_plug == p_cnt->param.i_param[1] ) {

			stx_stack_reset(the->h_stack);
			the->h_input_stream->clear(the->h_input_stream);

			i_err_ext = (STX_RESULT)p_cnt->param.i_param[0];

			if( STX_EOF == i_err_ext ) {
				stx_stack_push(the->h_stack,STX_PROT_HDR_SIZE);
				stx_stack_push(the->h_stack,STX_PROT_PREFETCH_HDR);
			}
			else{ // i_err_ext < 0 or other invalid value;
				stx_stack_push(the->h_stack,STX_PROT_STOP);
			}

			stx_stack_push(the->h_stack,0); // STOP INDEX;
			stx_stack_push(the->h_stack,STX_PROT_STOP_STREAM);
			stx_stack_push(the->h_stack,STX_PROT_STOP_GRAPH);

			p_msg->set_msg_close(p_msg);

			return STX_OK;

		} // if( h_plug == the->h_src_plug ) {

		h_stack = p_msg->get_stack(p_msg);
		{
			stx_base_filter* const plug = (stx_base_filter*)*stx_stack_pop(h_stack);
			return plug->send_msg(plug,p_msg);
		} // block

	} // 

}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE: return the output stream channel xio interface;
***************************************************************************/
STX_RESULT on_query(STX_HANDLE h,stx_base_message* p_msg)
{
	STX_RESULT		i_err;

	stx_gid			buf_iid;
	stx_msg_cnt*	cnt;
	stx_media_type* p_mtype;
	s32				i_len;
	u8*				p_hdr;


	STX_MAP_THE(stx_session);

	buf_iid = *(stx_gid*)p_msg->get_msg_buf(p_msg,&i_len);

	if( IS_EQUAL_GID(STX_IID_OutputIo,buf_iid) ) {

		stp_subchannel* h_sub = &the->h_output_stream[the->i_output];

		cnt = p_msg->get_msg_cnt(p_msg);

		p_mtype = (stx_media_type*)cnt->param.i_param[0];

		h_sub->major_type = p_mtype->get_type(p_mtype);
		h_sub->sub_type = p_mtype->get_subtype(p_mtype);

		h_sub->major_name = xstrdup(p_mtype->get_type_name(p_mtype));
		if( !h_sub->major_name ) {
			return STX_FAIL;
		}
		h_sub->sub_name = xstrdup(p_mtype->get_subtype_name(p_mtype));
		if( !h_sub->sub_name ) {
			return STX_FAIL;
		}

		if( IS_EQUAL_GID(MEDIATYPE_Audio,h_sub->major_type)) {
			h_sub->i_chid = STP_ID_AUDIO; // sub stream channel;
		}
		else if( IS_EQUAL_GID(MEDIATYPE_Video,h_sub->major_type)) {
			h_sub->i_chid = STP_ID_VIDEO; // sub stream channel;
		}
		else {
			h_sub->i_chid = STP_ID_STREAM_DATA;
		}

		i_err = the->h_output_base->create_channel(the->h_output_base,h_sub->i_chid, &h_sub->h_data);
		if( STX_OK != i_err ) {
			return i_err;
		}

		stx_log("stx_session, create sub channel id = %d\r\n",h_sub->i_chid);

		if( h_sub->i_chid != STP_ID_STREAM_DATA ) {
			i_err = p_mtype->get_header(p_mtype,&p_hdr,&h_sub->i_hdr_size);
			if( STX_OK != i_err ) {
				return i_err;
			}
			h_sub->p_hdr = (u8*)xmallocz(h_sub->i_hdr_size);
			if( ! h_sub->p_hdr) {
				return STX_FAIL;
			}
			memcpy(h_sub->p_hdr,p_hdr,h_sub->i_hdr_size);
		} //if( h_sub->i_chid != STP_ID_STREAM_DATA ) {

		// export stream channel, add base writer ref count;
		the->i_output ++;
		the->h_output_base->add_ref(the->h_output_base);
		cnt->param.i_param[0] = (size_t)h_sub->h_data;

		p_msg->set_msg_close(p_msg);

		return STX_OK;
	}

	if( IS_EQUAL_GID(STX_IID_InputIo,buf_iid) ) {

		cnt = p_msg->get_msg_cnt(p_msg);

		// export stream channel, add base writer ref count;
		cnt->param.i_param[0] = (size_t)the->h_socket;

		p_msg->set_msg_close(p_msg);

		return STX_OK;
	}

	if( IS_EQUAL_GID(STX_IID_ActiveMovieWindow,buf_iid) ) {

		stx_active_movie_wnd*	h_active_wnd;
		stx_base_plugin*		h_PlayWnd = NULL;


		do{

			i_err = STX_FAIL;
			h_active_wnd = NULL;

			h_PlayWnd = XCREATE(app_wnd,NULL);
			if( !h_PlayWnd ) {
				break;
			}
			h_PlayWnd->set_parent(h_PlayWnd,(stx_base_plugin*)&the->stx_base_filter_vt);

			i_err = h_PlayWnd->query_interf(h_PlayWnd,STX_IID_ActiveMovieWindow,(void**)&h_active_wnd);
			if( STX_OK != i_err ) {
				break;
			}

			i_err = h_active_wnd->create(h_active_wnd,NULL);
			if( STX_OK != i_err ) {
				break;
			}

			i_err = STX_OK;

		}while(FALSE);

		SAFE_XDELETE(h_active_wnd);

		if( STX_OK != i_err ) {
			return (int)i_err;
		}

		cnt = p_msg->get_msg_cnt(p_msg);

		cnt->param.i_param[0] = (size_t)h_PlayWnd;

		p_msg->set_msg_close(p_msg);

		return STX_OK;
	}

	return STX_ERR_FILE_NOT_FOUND;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_get_property
(STX_HANDLE h,stx_xio* h_xio)
{
	STX_MAP_THE(stx_session);

	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_set_property
(STX_HANDLE h,stx_xio* h_xio)
{
	STX_MAP_THE(stx_session);

	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT run_proc(stx_session* the,stx_sync_inf* h_sync )
{
	STX_RESULT	i_err;
	size_t*		h_status;
	size_t		i_status;

	h_status = stx_stack_pop(the->h_stack);
	if( !h_status ) { // wait for stack reset, or initialized;
		h_sync->i_idle = MILISEC2REFTIME(10);
		RESET_XENTRY(h_sync,&the->stx_base_filter_vt);
		return STX_WOUNLD_BLOCK;
	}

	i_status = *h_status;

	if( i_status < STX_PROT_OPEN_URL ){

		size_t i_data_prefetch;

		h_status = stx_stack_pop(the->h_stack);
		if( !h_status ) {
			return STX_FAIL; // fatal;
		}
		i_data_prefetch = *h_status;


		for( ; ; ) {

			size_t		i_data;
			size_t		i_read;
			size_t		i_write;
			char		buf[1500];

			i_data = i_data_prefetch > sizeof(buf) ? sizeof(buf) : i_data_prefetch;

			do{
				i_err = the->h_socket->read(the->h_socket,buf,i_data,&i_read );

			}while(STX_AGAIN == i_err);

			if( i_err < 0 ||  STX_EOF == i_err ) {

				// if graph running;
				if( the->b_graph_run ) {
					stx_stack_push(the->h_stack,STX_PROT_STOP); // need not stop stream;
					stx_stack_push(the->h_stack,STX_PROT_STOP_GRAPH);
					i_err = STX_AGAIN;
				}
				return i_err;

			} //if( i_err < 0 || STX_EOF == i_err || (

			if( STX_IDLE == i_err || STX_WOUNLD_BLOCK == i_err ) {
				stx_stack_push(the->h_stack,i_data_prefetch);
				stx_stack_push(the->h_stack,i_status);
				h_sync->i_idle = MILISEC2REFTIME(10);
				RESET_XENTRY(h_sync,&the->stx_base_filter_vt);
				return i_err;
			} //if( STX_IDLE == i_err || STX_WOUNLD_BLOCK == i_err ) {

			the->i_last_time = 0; // clear idle time;

			the->h_input_stream->write(the->h_input_stream,buf,i_read,&i_write);

			i_data_prefetch -= i_read;

			if( !i_data_prefetch ) {
				break;
			}

		} // for( ; ; ) {

		if( STX_PROT_PREFETCH_HDR == i_status ) {

			return parse_header(the,h_sync);
		}
		else if( STX_PROT_PREFETCH_BODY == i_status ) {

			return parse_body(the,h_sync);
		}
		else if( STX_PROT_RPEFETCH_PACKAGE == i_status ) {

			return parse_attachment(the,h_sync);
		}

		// fatal;
		return STX_FAIL;

	} //if( i_status < STX_PROT_OPEN_URL ){


	switch( i_status ) {

		case STX_PROT_OPEN_URL:
			return open_url(the,h_sync);

		case STX_PROT_SEND_RESPONSE:
			return send_response(the,h_sync);

		case STX_PROT_FLUSH_RESPONSE:
			return flush_response(the,h_sync);

		case STX_PROT_RUN_GRAPH:
			return run_graph(the,h_sync);

		case STX_PROT_STOP_GRAPH:
			return stop_graph(the,h_sync);

		case STX_PROT_STOP_STREAM:
			return stop_stream(the,h_sync);

		case STX_PROT_IDLE:
			stx_stack_push(the->h_stack,STX_PROT_IDLE);
			h_sync->i_idle = MILISEC2REFTIME(100);
			RESET_XENTRY(h_sync,&the->stx_base_filter_vt);
			return STX_WOUNLD_BLOCK;

		case STX_PROT_STOP:
			return STX_EOF; // destroy protocol;

		default:
			break;

	} // switch( i_status ) {

	// fatal;
	return STX_FAIL;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_run 
(STX_HANDLE h,stx_sync_inf* h_sync )
{
	STX_MAP_THE(stx_session);
	{
		STX_RESULT i_err;
		session_lock();
		i_err = run_proc(the,h_sync);
		session_unlock();
		return i_err;
	}
}





/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT	flush_response(stx_session* the,stx_sync_inf* h_sync)
{
	STX_RESULT			i_err;

	i_err = the->h_output_response->flush(the->h_output_response);
	if( i_err < 0 || STX_EOF == i_err ) {
		return i_err;
	}

	if( STX_OK == i_err ) {
		return STX_AGAIN;
	}

	stx_stack_push(the->h_stack,STX_PROT_FLUSH_RESPONSE);
	h_sync->i_idle = MILISEC2REFTIME(10);
	RESET_XENTRY(h_sync,&the->stx_base_filter_vt);

	return STX_WOUNLD_BLOCK;

}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT	send_response(stx_session* the,stx_sync_inf* h_sync)
{
	STX_RESULT			i_err;
	stx_io_op_param		para;
	size_t				i_write;

	i_err = the->h_response->get(the->h_response,STX_IO_READ_P,&para);
	if( STX_OK != i_err ) {
		return i_err;
	}

	i_err = the->h_output_response->write(the->h_output_response,
		para.buf + para.i_available_data - the->i_response_size,
		the->i_response_size,
		&i_write);

	if( i_err < 0 || STX_EOF == i_err ) {
		return i_err;
	}

	the->i_response_size -= (s32)i_write;

	if( ! the->i_response_size ) { 
		return STX_AGAIN;
	}

	// retry next time run;

	h_sync->i_idle = MILISEC2REFTIME(10);
	stx_stack_push(the->h_stack,STX_PROT_SEND_RESPONSE);
	RESET_XENTRY(h_sync,&the->stx_base_filter_vt);

	return STX_WOUNLD_BLOCK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT	stop_stream(stx_session* the,stx_sync_inf* h_sync)
{
	STX_RESULT			i_err;
	s32					i;

	size_t*				h_status;
	size_t				i_status;

	h_status = stx_stack_pop(the->h_stack);
	if( !h_status) {
		return STX_FAIL;
	}

	i_status = *h_status;

	for( i = (s32)i_status; i < the->i_output; i ++ ) {

		i_err = the->h_output_stream[i].h_data->stop(the->h_output_stream[i].h_data );
		if( i_err < 0 ) {
			return i_err;
		}
		if( STX_EOF == i_err ) {
			continue;
		}
		// retry next time run;
		if( STX_IDLE == i_err || STX_WOUNLD_BLOCK == i_err ) {

			// 			auto stop: should stop the data channel, let the stp_client could receive all the data;
			// 			if auto stop in stop data channel case, and a close reqeust send:
			// 			maybe a dead lock ? so we add a time limit here, to avoid the dead lock;

			s64 i_time = stx_get_milisec();
			if( !the->i_last_time ) {
				the->i_last_time = i_time;
			}
			else if( the->i_last_time - i_time > STX_PROT_STOP_TIME ) {
				the->i_last_time = 0;
				continue;
			}

			stx_stack_push(the->h_stack,i);
			stx_stack_push(the->h_stack,STX_PROT_STOP_STREAM);
			h_sync->i_idle = MILISEC2REFTIME(10);
			RESET_XENTRY(h_sync,&the->stx_base_filter_vt);

			return STX_WOUNLD_BLOCK;
		}

	} // for( i = i_status; i < the->i_output; i ++ ) {

	return STX_AGAIN;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT 
parse_attachment(stx_session* the,stx_sync_inf* h_sync)
{

	STX_RESULT i_err;


	do{
		// init the canvas;
		the->h_canvas = canvas_create(NULL,NULL,(stx_base_plugin*)&the->stx_base_filter_vt,the->h_gbd);
		if( !the->h_canvas  ) {
			i_err = STX_FAIL;
			break;
		}

		i_err = canvas_initialize(the->h_canvas,NULL,the->h_input_stream);
		if( STX_OK != i_err ) {
			break;
		}

		stx_stack_push(the->h_stack,STX_PROT_OPEN_URL);
		i_err = STX_AGAIN;

	}while(FALSE);

	if( i_err < 0 ) {

		return response_err(the,STX_SERVICE_RESPOND_BAD_MODULE);
	}

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT	parse_body(stx_session* the,stx_sync_inf* h_sync)
{
	STX_RESULT		i_err;
	stx_xini*		h_xini;
	stx_xio*		h_stream;
	stx_io_op_param param;
	size_t			i_write;
	STX_HANDLE      h_key;
	s32				i_request;

	h_stream = NULL;
	h_xini = NULL;
	i_err = STX_FAIL;

	do{

		h_stream = XCREATE(stx_io_stream,NULL);
		if(!h_stream ) {
			break;
		}

		INIT_MEMBER(param);
		i_err = the->h_input_stream->get(the->h_input_stream,STX_IO_READ_P,&param);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = h_stream->write(h_stream,
			param.buf + STX_PROT_HDR_SIZE,
			(size_t)( param.i_available_data - STX_PROT_HDR_SIZE),
			&i_write);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = stx_ini_create(NULL,h_stream,STX_INI_READ_ONLY|STX_INI_NO_COMMENT,0,&h_xini);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = h_xini->create_key(h_xini,NULL,g_sz_service_request,NULL,&h_key);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = h_xini->read_int32(h_xini,h_key,&i_request);
		if( STX_OK != i_err ) {
			break;
		}


		i_err = the->h_callback->filter(the->h_callback,the->h_plug,h_xini,the->h_response);

		if( i_err < 0 ) {
			// change status to send error message ;
			i_err = response_err(the,(s32)i_err);
			break;
		}

		if( STX_EOF == i_err ){ // stx_protocol filter it over;
			the->i_response_size = (s32)the->h_response->size(the->h_response);
			if( the->i_response_size ) {
				stx_stack_push(the->h_stack,STX_PROT_HDR_SIZE);
				stx_stack_push(the->h_stack,STX_PROT_PREFETCH_HDR);
				stx_stack_push(the->h_stack,STX_PROT_FLUSH_RESPONSE);
				stx_stack_push(the->h_stack,STX_PROT_SEND_RESPONSE);
			}
			i_err = STX_AGAIN;
			break;
		}// if( STX_EOF == i_err ){

		// STX_OK


		switch( i_request ) {

			//add  other request;
			case STX_SERVICE_REQUEST_DOWNLOAD:
			case STX_SERVICE_REQUEST_CONVERT: //added by xmp
				i_err = get_url(the, h_xini);
				break;

			case STX_SERVICE_REQUEST_PLAY:
				stx_stack_push(the->h_stack,STX_PROT_RUN_GRAPH);
				i_err = STX_AGAIN;
				break;

			case STX_SERVICE_REQUEST_CLOSE:
				{
					char szins[64];
					stx_gid insgid = the->h_plug->get_insid(the->h_plug);
					binary_to_string(16,insgid.data,szins);
					stx_log("session<%s> execute close request\r\n",szins);
				}
				//avoid render output suspending and could not be stopped;
				//XCALL(stop,the->h_socket);
				stx_stack_push(the->h_stack,STX_PROT_STOP); // need not stop stream;
				stx_stack_push(the->h_stack,STX_PROT_STOP_GRAPH);
				i_err = STX_AGAIN;
				break;

			default:
				i_err = response_err(the,(s32)STX_ERR_NOT_SUPPORT);
				break;

		} //switch( i_request ) {

	}while(FALSE);

	if( h_xini ) {
		h_xini->close(h_xini);
	}

	if( h_stream ) {
		h_stream->close(h_stream);
	}

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT parse_header(stx_session* the,stx_sync_inf* h_sync)
{
	STX_RESULT		i_err;

	ByteIOContext	pb;

	char			hdr[8];
	stx_io_op_param param;
	u32				prot_flag;
	u32				body_len;

	INIT_MEMBER(param);
	i_err = the->h_input_stream->get(the->h_input_stream,STX_IO_READ_P,&param);
	if( STX_OK != i_err ) {
		return i_err;
	}

	INIT_BYTEIO_DIRECT(pb,STX_DEFAULT_PATH,param.buf );

	INIT_MEMBER(hdr);
	*(u32*)hdr = get_le32(&pb);
	if( strcmp(hdr,g_sz_prot_stx) ) {
		stx_log("stx_session:invalid header:%X,should be %X\r\n",hdr,*(u32*)g_sz_prot_stx);
		return STX_ERR_NOT_SUPPORT;
	}

	prot_flag = get_be32(&pb);
	if( !( prot_flag & STX_PROTOCOL_XINI ) ) {
		return STX_ERR_NOT_SUPPORT;
	}

	body_len = get_be32(&pb); // must not be zero;

	stx_stack_push(the->h_stack,body_len);
	stx_stack_push(the->h_stack,STX_PROT_PREFETCH_BODY);
	RESET_XENTRY(h_sync,&the->stx_base_filter_vt);
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
stx_gid stx_base_session_vt_xxx_get_session_id(THEE h)
{
	STX_MAP_THE(stx_session);

	return the->ins_gid;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_session_vt_xxx_enum_method
(STX_HANDLE h,s32 * i_idx,char ** method_name)
{
	STX_MAP_THE(stx_session);

	return STX_ERR_NOT_SUPPORT;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_session_vt_xxx_initialize
(STX_HANDLE h,stx_xio* h_xio,THEE h_callback)
{
	STX_MAP_THE(stx_session);

	// set io;
	the->h_socket = h_xio;

	// set stx_protocol callback interface pointer;
	the->h_callback = (stx_prot_callback*)h_callback;
	the->h_callback->add_ref(the->h_callback);

	return init_context(the);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT	
stop_graph(stx_session* the,stx_sync_inf* h_sync)
{
	STX_RESULT	i_err;

	i_err = canvas_OnStop(the->h_canvas);
	if( i_err < 0 ) {
		return response_err(the,STX_SERVICE_MSG_INTERNAL_ERR);
	}

	if( STX_OK != i_err ) {
		stx_stack_push(the->h_stack,STX_PROT_STOP_GRAPH);
		h_sync->i_idle = MILISEC2REFTIME(10);
		RESET_XENTRY(h_sync,&the->stx_base_filter_vt);
		return i_err;
	}

	// later status already saved in stack;
	return STX_AGAIN;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT 
run_graph( stx_session* the, stx_sync_inf* h_sync )
{
	STX_RESULT	i_err;

	i_err = canvas_OnRunGraph(the->h_canvas);
	if( i_err < 0 ) {
		return response_err(the,STX_SERVICE_MSG_INTERNAL_ERR);
	}

	if( STX_OK != i_err ) {
		stx_stack_push(the->h_stack,STX_PROT_RUN_GRAPH);
		RESET_XENTRY(h_sync,&the->stx_base_filter_vt);
		return i_err;
	}

	// change status to wait task finish;

	//stx_stack_push(the->h_stack,STX_PROT_IDLE);

	the->b_graph_run = TRUE;

	the->h_input_stream->clear(the->h_input_stream);
	stx_stack_push(the->h_stack,STX_PROT_HDR_SIZE);
	stx_stack_push(the->h_stack,STX_PROT_PREFETCH_HDR);

#if 1
	{
		char szins[64];
		stx_gid insgid = the->h_plug->get_insid(the->h_plug);
		binary_to_string(16,insgid.data,szins);
		stx_log("session<%s> start play\r\n",szins);
	}
#endif

	return write_response_play(the,h_sync);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT	
write_response_play( stx_session* the,stx_sync_inf* h_sync )
{
	STX_RESULT		i_err;
	STX_HANDLE		h_key;
	s64				i_file_size;
	ByteIOContext	pb;
	char            buf[STX_DEFAULT_PATH];
	stx_io_op_param param;
	size_t			i_write;

	stx_xini*		h_xini = NULL;  
	stx_xio*		h_tmp = NULL;

	i_err = STX_FAIL;


	do{

		the->h_response->clear(the->h_response);

		h_tmp = XCREATE(stx_io_stream,NULL);
		if( !h_tmp ) {
			break;
		}

		i_err = stx_ini_create(NULL,h_tmp,STX_INI_CREATE_NEW|STX_INI_NO_COMMENT,0,&h_xini);
		if( STX_OK != i_err ) {
			break;
		}

		// respond key;
		i_err = h_xini->create_key(h_xini,NULL,g_sz_service_respond,NULL,&h_key);
		if( STX_OK != i_err ) {
			break;
		}

		// OK
		i_err = h_xini->write_int32(h_xini,h_key,STX_SERVICE_RESPOND_OK);
		if( STX_OK != i_err ) {
			break;
		}

		h_xini->close(h_xini);
		h_xini = NULL;

		// get xini body data pointer and length;
		INIT_MEMBER(param);
		i_err = h_tmp->get(h_tmp,STX_IO_READ_P,&param);
		if( STX_OK != i_err ) {
			break;
		}

		// write header;
		INIT_BYTEIO_W(pb,STX_DEFAULT_PATH,(uint8*)buf,the->h_response);
		put_tag(&pb,g_sz_prot_stx);
		put_be32(&pb,STX_PROTOCOL_XINI);
		put_be32(&pb,(u32)param.i_available_data);

		// write xini body;
		i_err = xio_fwrite(&pb,(const u8*)param.buf,(size_t)param.i_available_data,&i_write);
		if( STX_OK != i_err ) {
			break;
		}

		// flush out data;
		xio_flush(&pb);

		stx_stack_push(the->h_stack,STX_PROT_FLUSH_RESPONSE);
		stx_stack_push(the->h_stack,STX_PROT_SEND_RESPONSE);

		stx_log(" send response of play\r\n");

		i_err = STX_AGAIN;

	}while(FALSE);

	if( h_xini ) {
		h_xini->close(h_xini);
	}
	SAFE_CLOSEXIO(h_tmp);

	the->i_response_size = (s32)the->h_response->size(the->h_response);

	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT 
write_response( stx_session* the ,stx_sync_inf* h_sync)
{
	STX_RESULT		i_err;
	STX_HANDLE		h_key;
	s64				i_file_size;
	s64				i_file_time;
	ByteIOContext	pb;
	char            buf[STX_DEFAULT_PATH];
	stx_io_op_param param;
	size_t			i_write;

	stx_xini*		h_xini = NULL;  
	stx_xio*		h_tmp = NULL;

	i_err = STX_FAIL;


	do{

		the->h_response->clear(the->h_response);

		h_tmp = XCREATE(stx_io_stream,NULL);
		if( !h_tmp ) {
			break;
		}

		i_err = stx_ini_create(NULL,h_tmp,STX_INI_CREATE_NEW|STX_INI_NO_COMMENT,0,&h_xini);
		if( STX_OK != i_err ) {
			break;
		}

		// respond key;
		i_err = h_xini->create_key(h_xini,NULL,g_sz_service_respond,NULL,&h_key);
		if( STX_OK != i_err ) {
			break;
		}

		// OK
		i_err = h_xini->write_int32(h_xini,h_key,STX_SERVICE_RESPOND_OK);
		if( STX_OK != i_err ) {
			break;
		}


		// file size key;
		i_err = h_xini->create_key(h_xini,NULL,g_sz_file_size,NULL,&h_key);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = the->h_canvas->m_hSrc->get_size(the->h_canvas->m_hSrc,&i_file_size);
		if( STX_OK != i_err ) {
			i_file_size = -1;
		}
		i_err = h_xini->write_int64(h_xini,h_key,i_file_size);
		if( STX_OK != i_err ) {
			break;
		}

		// file duration
		{
			stx_media_info* pinf = NULL;
			i_err = XCALL(query_interf,the->h_canvas->m_hSrc,STX_IID_MediaInfo,(void**)&pinf);
			if( STX_OK != i_err ) {
				break;
			}
			SAFE_XDELETE(pinf);
			i_err = pinf->get_total_time(pinf,&i_file_time);
			if( STX_OK != i_err ) {
				i_file_time = 0;
			}
			i_err = h_xini->create_key(h_xini,NULL,g_sz_file_time,"0",&h_key);
			if( STX_OK != i_err ) {
				break;
			}
			i_err = h_xini->write_int64(h_xini,h_key,i_file_time);
			if( STX_OK != i_err ) {
				break;
			}
		}

		// file moddate
		i_err = h_xini->create_key(h_xini,NULL,g_sz_moddate,"0",&h_key);
		if( STX_OK != i_err ) {
			break;
		}

		// channel num, and each channel id;
		i_err = h_xini->create_key(h_xini,NULL,g_sz_channel,NULL,&h_key);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = h_xini->write_int32(h_xini,h_key,the->i_output);
		if( STX_OK != i_err ) {
			break;
		}

		{
			s32			i;
			STX_HANDLE	h_cha,h_type;
			char		sz_key[256];
			stx_xio*	h_hdr_stream;

			h_hdr_stream = XCREATE(stx_io_stream,NULL);
			if( !h_hdr_stream ) {
				i_err = STX_FAIL;
				break;
			}


			for( i = 0; i < the->i_output; i ++ ) {

				stp_subchannel* h_sub = &the->h_output_stream[i];

				stx_sprintf(sz_key,sizeof(sz_key),"%s-%d",g_sz_channel,i);

				i_err = h_xini->create_key(h_xini,h_key,sz_key,NULL,&h_cha);
				if( STX_OK != i_err ) {
					break;
				}
				i_err = h_xini->write_int32(h_xini,h_cha,(s32)h_sub->i_chid);
				if( STX_OK != i_err ) {
					break;
				}

				// write media type;

				h_hdr_stream->clear(h_hdr_stream);

				i_err = h_xini->create_key(h_xini,h_cha,g_szStreamX_MajorDataType,NULL,&h_type);
				if( STX_OK != i_err ) {
					break;
				}
				i_err = h_xini->write_binary(h_xini,h_type,sizeof(h_sub->major_type),h_sub->major_type.data);
				if( STX_OK != i_err ) {
					break;
				}
				i_err = h_xini->create_key(h_xini,h_cha,g_szStreamX_MajorDataTypeName,h_sub->major_name,&h_type);
				if( STX_OK != i_err ) {
					break;
				}


				i_err = h_xini->create_key(h_xini,h_cha,g_szStreamX_SubDataType,NULL,&h_type);
				if( STX_OK != i_err ) {
					break;
				}
				i_err = h_xini->write_binary(h_xini,h_type,sizeof(h_sub->sub_type),h_sub->sub_type.data);
				if( STX_OK != i_err ) {
					break;
				}
				i_err = h_xini->create_key(h_xini,h_cha,g_szStreamX_SubDataTypeName,h_sub->sub_name,&h_type);
				if( STX_OK != i_err ) {
					break;
				}

				if( !h_sub->i_hdr_size ) {
					continue;
				}

				// header;
				i_err = h_xini->create_key(h_xini,h_cha,g_szStreamX_header,NULL,&h_type);
				if( STX_OK != i_err ) {
					break;
				}

				if( IS_EQUAL_GID(h_sub->major_type,MEDIATYPE_Video)) {
					i_err = encode_vd2((STX_VIDEOINFOHEADER2*)h_sub->p_hdr,h_sub->i_hdr_size,h_hdr_stream);
					if( STX_OK != i_err ) {
						break;
					}
				}
				else if( IS_EQUAL_GID(h_sub->major_type,MEDIATYPE_Audio) ) {
					i_err = encode_wex((STX_WAVEFORMATEXTENSIBLE*)h_sub->p_hdr,h_sub->i_hdr_size,h_hdr_stream);
					if( STX_OK != i_err ) {
						break;
					}
				}
				else {
					i_err = STX_FAIL;
					break;
				}

				INIT_MEMBER(param);
				i_err = h_hdr_stream->get(h_hdr_stream,STX_IO_READ_P,&param);
				if( STX_OK != i_err ) {
					break;
				}

				i_err = h_xini->write_base64(h_xini,h_type,(u32)param.i_available_data,param.buf);
				if( STX_OK != i_err ) {
					break;
				}

			} // for( i = 0; i < the->i_output; i ++ ) {

			SAFE_CLOSEXIO(h_hdr_stream);

			if( STX_OK != i_err ) {
				break;
			}

		} // block;


		h_xini->close(h_xini);
		h_xini = NULL;

		// get xini body data pointer and length;
		INIT_MEMBER(param);
		i_err = h_tmp->get(h_tmp,STX_IO_READ_P,&param);
		if( STX_OK != i_err ) {
			break;
		}

		// write header;
		INIT_BYTEIO_W(pb,STX_DEFAULT_PATH,(uint8*)buf,the->h_response);
		put_tag(&pb,g_sz_prot_stx);
		put_be32(&pb,STX_PROTOCOL_XINI);
		put_be32(&pb,(u32)param.i_available_data);

		// write xini body;
		i_err = xio_fwrite(&pb,(const u8*)param.buf,(size_t)param.i_available_data,&i_write);
		if( STX_OK != i_err ) {
			break;
		}

		// flush out data;
		xio_flush(&pb);

		stx_stack_push(the->h_stack,STX_PROT_FLUSH_RESPONSE);
		stx_stack_push(the->h_stack,STX_PROT_SEND_RESPONSE);

		stx_log(" send response of request\r\n");

		i_err = STX_AGAIN;

	}while(FALSE);

	if( h_xini ) {
		h_xini->close(h_xini);
	}
	SAFE_CLOSEXIO(h_tmp);

	the->i_response_size = (s32)the->h_response->size(the->h_response);

	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT 
response_err( stx_session* the, s32 i_err_code )
{
	STX_RESULT	i_err;
	STX_HANDLE  h_key;

	stx_xini*	h_xini = NULL;  


	do{

		the->h_response->clear(the->h_response);

		i_err = stx_ini_create(NULL,the->h_response,STX_INI_CREATE_NEW|STX_INI_NO_COMMENT,0,&h_xini);
		if( STX_OK != i_err ) {
			break;
		}

		// respond key;
		i_err = h_xini->create_key(h_xini,NULL,g_sz_service_respond,NULL,&h_key);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = h_xini->write_int32(h_xini,h_key,i_err_code);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = STX_AGAIN;

	}while(FALSE);

	if( h_xini ) {
		h_xini->close(h_xini);
	}

	the->i_response_size = (s32)the->h_response->size(the->h_response);

	if( the->i_response_size ) {

		stx_log("stx_session:response data size = %d, error code = %d\r\n",the->i_response_size,i_err_code);

		stx_stack_push(the->h_stack,STX_PROT_HDR_SIZE);
		stx_stack_push(the->h_stack,STX_PROT_PREFETCH_HDR);
		stx_stack_push(the->h_stack,STX_PROT_FLUSH_RESPONSE);
		stx_stack_push(the->h_stack,STX_PROT_SEND_RESPONSE);
	}


	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT 
open_url( stx_session* the, stx_sync_inf* h_sync )
{
	STX_RESULT i_err;

	// change status to load stream; 
	i_err = canvas_OnLoadStream(the->h_canvas,the->sz_url,h_sync);
	if( i_err < 0 ) {
		return response_err(the, STX_SERVICE_RESPOND_FILE_NOT_FOUND);
	}

	if( STX_OK != i_err ) {
		stx_stack_push(the->h_stack,STX_PROT_OPEN_URL);
		RESET_XENTRY(h_sync,&the->stx_base_filter_vt);
		return i_err;
	}

	// success 

	// after send response, still need wait play command;
	the->h_input_stream->clear(the->h_input_stream);
	stx_stack_push(the->h_stack,STX_PROT_HDR_SIZE);
	stx_stack_push(the->h_stack,STX_PROT_PREFETCH_HDR);

	stx_log("open url success\r\n");

	return write_response(the,h_sync);
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT get_url(stx_session* the,stx_xini* h_xini)
{
	STX_RESULT	i_err;
	STX_HANDLE	h_key,h_size;
	s32			i_size;

	do{

		i_err = STX_FAIL;

		// get URL;
		i_err = h_xini->create_key(h_xini, NULL, g_sz_URL, NULL, &h_key);
		if(STX_OK != i_err){
			break;
		}

		i_err = h_xini->read_base64(h_xini,h_key,&i_size,NULL);
		if(STX_OK != i_err){
			break;
		}

		if( the->sz_url ) {
			stx_free(the->sz_url);
		}
		the->sz_url = (char*)xmallocz(i_size);
		if( !the->sz_url ) {
			break;
		}
		i_err = h_xini->read_base64(h_xini,h_key,&i_size,the->sz_url);
		if(STX_OK != i_err){
			break;
		}

		// if have attachment ? must be true; g_sz_GRAPH
		i_err = h_xini->create_key(h_xini, NULL, g_sz_GRAPH, NULL, &h_key);
		if(STX_OK == i_err){
			char* sz_val;
			i_err = h_xini->read_string(h_xini,h_key,&sz_val);
			if(STX_OK != i_err){
				break;
			}

			stx_log("graph file = %s\r\n",sz_val);

			if( the->sz_graph ) {
				stx_free(the->sz_graph);
			}
			the->sz_graph = xstrdup(sz_val);
			if( !the->sz_graph ) {
				break;
			}
			i_err = h_xini->create_key(h_xini, h_key, g_sz_file_size, NULL, &h_size);
			if(STX_OK != i_err){
				break;
			}
			i_err = h_xini->read_int32(h_xini,h_size,&i_size);
			if(STX_OK != i_err){
				break;
			}
		}

		XCALL(clear,the->h_input_stream);

		stx_stack_push(the->h_stack,i_size);
		stx_stack_push(the->h_stack,STX_PROT_RPEFETCH_PACKAGE);

		i_err = STX_AGAIN;

	}while(FALSE);

	if( i_err < 0 ) {
		return response_err(the,STX_SERVICE_RESPOND_BAD_MODULE);
	}

	return i_err;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_start
(STX_HANDLE h,u32 i_flag,stx_sync_inf *h_sync)
{
	STX_MAP_THE(stx_session);
	{
		STX_RESULT i_err;

		i_err = the->h_gbd->alloc_ssrc(the->h_gbd,FALSE,NULL,1,&the->h_ssrc);
		if(STX_OK != i_err ){
			return i_err;
		}

		// active ssrc handle;
		{
			s64 i_time = 0;
			i_err = the->h_ssrc->reg_task(the->h_ssrc,&the->h_task,(stx_base_plugin*)h,TASK_NORMAL);
			if( STX_OK != i_err ) {
				return i_err;
			}

			the->h_stack = the->h_run;
			stx_stack_push(the->h_stack,STX_PROT_HDR_SIZE);
			stx_stack_push(the->h_stack,STX_PROT_PREFETCH_HDR);
			the->em_status = emStxStatusPlay;

			XCALL(reset_task,the->h_ssrc,the->h_task,0,0);
		}

		return STX_OK;
	}

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_stop
(STX_HANDLE h,u32 i_flag,stx_sync_inf *h_sync)
{
	STX_MAP_THE(stx_session);
	{
		STX_RESULT		i_err;
		size_t*			h_status;
		size_t			i_status;

		if( i_flag ) {
			// unreg task handle;
			if( the->h_task ) {
				the->h_ssrc->unreg_task(the->h_ssrc,the->h_task);
				the->h_task = NULL;
			}
			the->em_status = emStxStatusInit;
			return STX_OK;
		}

		session_lock();

		do{
			if( emStxStatusInit == the->em_status ){
				i_err = STX_OK;
				break;
			}

			h_status = (size_t*)stx_stack_pop(the->h_stop);
			if( !h_status ) {
				the->h_ssrc->set_task_events(the->h_ssrc,the->h_task,ev_stop);
				stx_stack_push(the->h_stop,STX_PROT_STOP_BEGIN);
				i_err = STX_WOUNLD_BLOCK;
				break;
			}

			i_status = *h_status;

			if( STX_PROT_STOP_BEGIN == i_status ) {
				if( emStxStatusStop != the->em_status ){
					stx_stack_push(the->h_stop,STX_PROT_STOP_BEGIN);
					i_err = STX_WOUNLD_BLOCK;
					break;
				}
				// task stopped;
				the->h_stack = the->h_stop;
				stx_stack_push(the->h_stack,STX_PROT_STOP);
				stx_stack_push(the->h_stack,0); // STOP INDEX;
				stx_stack_push(the->h_stack,STX_PROT_STOP_STREAM);
				i_status = STX_PROT_STOP_GRAPH;
			} // if( STX_PROT_STOP_BEGIN == i_status ) {

			if( STX_PROT_STOP_GRAPH == i_status ) {
				i_err = stop_graph(the,h_sync);
				break;
			}

			if( STX_PROT_STOP_STREAM == i_status ) {
				i_err = stop_stream(the,h_sync);
				break;
			}

			assert( STX_PROT_STOP == i_status );

			// unreg task handle;
			if( the->h_task ) {
				the->h_ssrc->unreg_task(the->h_ssrc,the->h_task);
				the->h_task = NULL;
			}
			the->em_status = emStxStatusInit;
			i_err = STX_OK;

		}while(FALSE);

		session_unlock();

		return i_err;
	}

}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_transform
(
 /**/STX_HANDLE			h, 
 /**/stx_base_pin*		h_pin, 
 /**/stx_media_data*	p_mdat, 
 /**/stx_base_pin**		hh_pin,
 /**/stx_media_data**	pp_mdat, 
 /**/stx_sync_inf*		h_sync
 )
{
	return STX_ECHO;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_check_input_media_type
( STX_HANDLE h, stx_media_type* p_mtyp )
{
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_check_output_media_type
( STX_HANDLE h, stx_media_type* p_mtyp )
{
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_set_input_media_type
( STX_HANDLE h, stx_media_type* p_mdt )
{
	STX_MAP_THE(stx_session);

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_set_output_media_type
(STX_HANDLE	h,stx_media_type* p_mdt )
{
	STX_MAP_THE(stx_session);

	return STX_OK;

}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_base_filter_vt_xxx_new_segment( STX_HANDLE h )
{
	STX_MAP_THE(stx_session);

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_flush
(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	STX_MAP_THE(stx_session);

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_receive
(
 STX_HANDLE			h,
 stx_base_pin*		h_pin, // which input pin;
 stx_media_data**	pp_mdat,stx_sync_inf* h_sync // output media data;
 )
{
	STX_MAP_THE(stx_session);

	return STX_ERR_NOT_SUPPORT;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_deliver
(
 STX_HANDLE			h,
 stx_base_pin*		h_pin, // which input pin;
 stx_media_data*	p_mdat,stx_sync_inf* h_sync // output media data;
 )
{
	STX_MAP_THE(stx_session);

	return STX_OK;

}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
as for emulate filter, the initial state of this render have no input pin and 
any data type;
so the emulate filter could not be registered, must be load and unload at run time;
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_enum_input_pin
(STX_HANDLE h,sint32 *i_idx,stx_base_pin** pp_pin )
{
	STX_MAP_THE(stx_session);
	if( !i_idx ) {
		return STX_ERR_INVALID_PARAM;
	}

	if( !pp_pin ) {
		*i_idx = 0;
		return STX_OK;
	}

	return STX_ERR_INVALID_PARAM;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_enum_output_pin
(STX_HANDLE h,sint32* i_idx,stx_base_pin** pp_pin )
{
	STX_MAP_THE(stx_session);
	if( !i_idx ) {
		return STX_ERR_INVALID_PARAM;
	}

	if( !pp_pin ) {
		*i_idx = 0;
		return STX_OK;
	}

	return STX_ERR_INVALID_PARAM;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_get_property
(STX_HANDLE h,stx_xio* h_xio)
{
	STX_MAP_THE(stx_session);

	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_set_property
(STX_HANDLE h,stx_xio* h_xio)
{
	STX_MAP_THE(stx_session);

	return STX_OK;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_app_wnd_callback_vt_xxx_cmd
(THEE h,size_t i_cmd,size_t i_wparam,size_t i_lparam)
{
	STX_MAP_THE(stx_session);

	switch(i_cmd) {

#ifdef __WIN32_LIB
		case STXM_WCMD:
			if( WM_PLAY == i_wparam){
				return canvas_OnRunGraph(the->h_canvas);
			}
			else if( WM_STOP == i_wparam ) {
				return canvas_OnStop(the->h_canvas);
			}
			else if( WM_PAUSE == i_wparam ) {
				return canvas_OnPause(the->h_canvas);
			}
			else if( WM_RESUME == i_wparam ) {
				return canvas_OnResume(the->h_canvas);
			}
			break;
#endif

		case STXM_SET_DST_RECT:
			canvas_set_dst_rect(the->h_canvas,*(RECT*)i_wparam);
			return STX_OK;

		case STXM_GET_CAPS:
			return canvas_get_graph_caps(the->h_canvas);

		case STXM_GET_STATUS:
			return canvas_get_graph_status(the->h_canvas);

		case STXM_SHOW_RENDER:
			canvas_show_render(the->h_canvas,(b32)i_wparam);
			return STX_OK;

		case STXM_CLOSE:
			{
				s32 i_status = canvas_get_graph_status(the->h_canvas);

				if( i_status != emStxStatusInit && i_status != emStxStatusReady) {
					return canvas_OnStop(the->h_canvas);
				}
			}
			break;
	}


	return STX_ERR_INVALID_PARAM;
}