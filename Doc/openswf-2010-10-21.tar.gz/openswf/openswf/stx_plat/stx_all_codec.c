/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#include "stdio.h"
#include "stdlib.h"
#include "fcntl.h"
#include "malloc.h"
#include "memory.h"
#include "string.h"

#include "stx_mem.h"
#include "stx_io.h"
#include "stx_io_file.h"
#include "stx_io_stream.h"
#include "stx_all_codec.h"
#include "stx_h264_preroll.h"
#include "stx_media_type_base.h"

#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif

/* {E2413885-4044-49b2-B133-A7787293D4FD}*/
DEFINE_XGUID( MEDIASUBTYPE_SDP_DATA,
             0xe2413885, 0x4044, 0x49b2, 0xb1, 0x33, 0xa7, 0x78, 0x72, 0x93, 0xd4, 0xfd)

// /* {2EB24117-F67D-4874-84B6-8E34EB8A387B}*/
// DEFINE_XGUID( STX_MTYPE_H264Sequence,
//              0x2eb24117, 0xf67d, 0x4874, 0x84, 0xb6, 0x8e, 0x34, 0xeb, 0x8a, 0x38, 0x7b)
// 

/* {8C13BEE7-EF0F-456a-8263-229D6497C193} */
DEFINE_XGUID( STX_CLSID_x264Encoder,
0x8c13bee7, 0xef0f, 0x456a, 0x82, 0x63, 0x22, 0x9d, 0x64, 0x97, 0xc1, 0x93 )
char* g_szStreamX_x264Encoder = STX_PLUGIN_STRING(x264 encoder);


DEFINE_XGUID( STX_CLSID_ActiveMovieWindow,
0x42e1975, 0x9b62, 0x409a, 0xb8, 0x7f, 0xfd, 0x2b, 0x65, 0x13, 0xa8, 0x1c )
char* g_szStreamX_ActiveMovieWindow = STX_PLUGIN_STRING(ActiveMovieWindow);

// {83E28F38-46DD-49b1-8B0F-BE513B45D473}
DEFINE_XGUID( STX_CLSID_Mpeg2Decoder,
0x83e28f38, 0x46dd, 0x49b1, 0x8b, 0xf, 0xbe, 0x51, 0x3b, 0x45, 0xd4, 0x73)
char* g_szStreamX_Mpeg2Decoder = STX_PLUGIN_STRING(mpeg2 decoder);

// {F69C0EF9-8903-46de-98C3-F6DD9B7FA0F4}
DEFINE_XGUID( STX_CLSID_TsSource,
0xf69c0ef9, 0x8903, 0x46de, 0x98, 0xc3, 0xf6, 0xdd, 0x9b, 0x7f, 0xa0, 0xf4)
char* g_szStreamX_TsSource = STX_PLUGIN_STRING(ts stream source);


// {464D987A-2D23-4b48-8C88-DED1FE35AE92}
DEFINE_XGUID( STX_CLSID_Mp3Encoder,
0x464d987a, 0x2d23, 0x4b48, 0x8c, 0x88, 0xde, 0xd1, 0xfe, 0x35, 0xae, 0x92)
char* g_szStreamX_Mp3Encoder = STX_PLUGIN_STRING(mp3 encoder);

DEFINE_XGUID( STX_CLSID_Mp3Decoder,
0x27c3cbab, 0x5dc4, 0x4101, 0x83, 0xa4, 0xf4, 0x5a, 0x85, 0x1b, 0x40, 0xa2);
char* g_szStreamX_Mp3Decoder = STX_PLUGIN_STRING(mp3 decoder);

// {3F27B4AE-8E59-4fed-8F60-5B816E957B91}
DEFINE_XGUID( STX_CLSID_AvbDecoder,
0x3f27b4ae, 0x8e59, 0x4fed, 0x8f, 0x60, 0x5b, 0x81, 0x6e, 0x95, 0x7b, 0x91);
char* g_szStreamX_AvbDecoder = STX_PLUGIN_STRING(avb decoder);


// {ADFE85A3-4667-49f8-B518-011D98E0EFE7}
DEFINE_XGUID( STX_CLSID_h264decoder,
0xadfe85a3, 0x4667, 0x49f8, 0xb5, 0x18, 0x1, 0x1d, 0x98, 0xe0, 0xef, 0xe7);
char* g_szStreamX_h264decoder = STX_PLUGIN_STRING(h264decoder);




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT encode_vd2
( STX_VIDEOINFOHEADER2* hdr, s32  i_len, stx_xio* h_stream )
{
	ByteIOContext   pb;
	u8              pb_buf[128];
	size_t			i_write;

	h_stream->clear(h_stream);

	INIT_BYTEIO_W(pb,sizeof(pb_buf),pb_buf,h_stream);

	put_be32(&pb,hdr->rcSource.left);

	put_be32(&pb,hdr->rcSource.top);

	put_be32(&pb,hdr->rcSource.right);

	put_be32(&pb,hdr->rcSource.bottom);

	put_be32(&pb,hdr->rcTarget.left);

	put_be32(&pb,hdr->rcTarget.top);

	put_be32(&pb,hdr->rcTarget.right);

	put_be32(&pb,hdr->rcTarget.bottom);

	put_be32(&pb,hdr->dwBitRate);

	put_be32(&pb,hdr->dwBitErrorRate);

	put_be64(&pb,hdr->AvgTimePerFrame);

	put_be32(&pb,hdr->dwInterlaceFlags);  

	put_be32(&pb,hdr->dwCopyProtectFlags); 

	put_be32(&pb,hdr->dwPictAspectRatioX); 

	put_be32(&pb,hdr->dwPictAspectRatioY); 

	put_be32(&pb,hdr->dwReserved1); 

	put_be32(&pb,hdr->dwReserved2); 


	put_be32(&pb,hdr->bmiHeader.biSize);

	put_be32(&pb,hdr->bmiHeader.biWidth);

	put_be32(&pb,hdr->bmiHeader.biHeight);

	put_be16(&pb,hdr->bmiHeader.biPlanes);

	put_be16(&pb,hdr->bmiHeader.biBitCount);

	put_be32(&pb,hdr->bmiHeader.biCompression);

	put_be32(&pb,hdr->bmiHeader.biSizeImage);

	put_be32(&pb,hdr->bmiHeader.biXPelsPerMeter);

	put_be32(&pb,hdr->bmiHeader.biYPelsPerMeter);

	put_be32(&pb,hdr->bmiHeader.biClrUsed);

	put_be32(&pb,hdr->bmiHeader.biClrImportant);

	i_len -= sizeof(STX_VIDEOINFOHEADER2);
	if( i_len > 0 ) {
		xio_fwrite(&pb,( (u8*)hdr) + sizeof(STX_VIDEOINFOHEADER2),i_len,&i_write);
	}

	xio_flush(&pb);

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT decode_vd2
( STX_VIDEOINFOHEADER2* hdr, s32* i_len, stx_xio* h_stream )
{
	ByteIOContext   pb;
	u8              pb_buf[128];
	size_t			i_size,i_read;

	s32 const i_vsize = sizeof(STX_VIDEOINFOHEADER2);

	h_stream->seek(h_stream,0,SEEK_SET);

	if( !hdr ) {
		*i_len = (s32)i_vsize + (s32)h_stream->size(h_stream) - VIDEOINFOHEADER2_size();
		return STX_OK;
	}


	INIT_BYTEIO_R(pb,sizeof(pb_buf),pb_buf,h_stream);

	hdr->rcSource.left   = get_be32(&pb);

	hdr->rcSource.top    = get_be32(&pb);

	hdr->rcSource.right  = get_be32(&pb);

	hdr->rcSource.bottom = get_be32(&pb);

	hdr->rcTarget.left   = get_be32(&pb);

	hdr->rcTarget.top    = get_be32(&pb);

	hdr->rcTarget.right  = get_be32(&pb);

	hdr->rcTarget.bottom = get_be32(&pb);

	hdr->dwBitRate         = get_be32(&pb);

	hdr->dwBitErrorRate    = get_be32(&pb);

	hdr->AvgTimePerFrame   = get_be64(&pb);

	hdr->dwInterlaceFlags  = get_be32(&pb);  

	hdr->dwCopyProtectFlags = get_be32(&pb); 

	hdr->dwPictAspectRatioX = get_be32(&pb); 

	hdr->dwPictAspectRatioY = get_be32(&pb); 

	hdr->dwReserved1 = get_be32(&pb); 

	hdr->dwReserved2 = get_be32(&pb); 

	hdr->bmiHeader.biSize = get_be32(&pb);

	hdr->bmiHeader.biWidth = get_be32(&pb);

	hdr->bmiHeader.biHeight = get_be32(&pb);

	hdr->bmiHeader.biPlanes = (u16)get_be16(&pb);

	hdr->bmiHeader.biBitCount = (u16)get_be16(&pb);

	hdr->bmiHeader.biCompression = get_be32(&pb);

	hdr->bmiHeader.biSizeImage = get_be32(&pb);

	hdr->bmiHeader.biXPelsPerMeter = get_be32(&pb);

	hdr->bmiHeader.biYPelsPerMeter = get_be32(&pb);

	hdr->bmiHeader.biClrUsed = get_be32(&pb);

	hdr->bmiHeader.biClrImportant = get_be32(&pb);

	i_size = *i_len - VIDEOINFOHEADER2_size();

	if( i_size > 0 ) {

		xio_fread(&pb,(u8*)hdr + sizeof(STX_VIDEOINFOHEADER2), i_size, &i_read );
	}

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT encode_wex
(STX_WAVEFORMATEXTENSIBLE* hdr, s32  i_len, stx_xio* h_stream )
{
	ByteIOContext	pb;
	u8				pb_buf[128];
	size_t			i_write;


	h_stream->clear(h_stream);

	INIT_BYTEIO_W(pb,sizeof(pb_buf),pb_buf,h_stream);

	put_be16(&pb,hdr->Format.wFormatTag      );

	put_be16(&pb,hdr->Format.nChannels       );

	put_be32(&pb,hdr->Format.nSamplesPerSec   );

	put_be32(&pb,hdr->Format.nAvgBytesPerSec  );

	put_be16(&pb,hdr->Format.nBlockAlign     );

	put_be16(&pb,hdr->Format.wBitsPerSample   );

	put_be16(&pb,hdr->Format.cbSize          );

	put_be16(&pb,hdr->Samples.wSamplesPerBlock);

	put_be32(&pb,hdr->dwChannelMask        );

	xio_fwrite(&pb,hdr->SubFormat.data,16,&i_write);

	i_len -= sizeof(STX_WAVEFORMATEXTENSIBLE);

	if( i_len > 0 ) {
		xio_fwrite(&pb,(u8*)hdr +  sizeof(STX_WAVEFORMATEXTENSIBLE), i_len, &i_write);
	}

	xio_flush(&pb);

	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT decode_wex
(STX_WAVEFORMATEXTENSIBLE* hdr, s32* i_len, stx_xio* h_stream )
{
	ByteIOContext   pb;
	u8				pb_buf[128];
	size_t			i_read,i_size;

	s32 const i_asize = sizeof(STX_WAVEFORMATEXTENSIBLE);

	h_stream->seek(h_stream,0,SEEK_SET);

	if( !hdr ) {
		*i_len = (s32)i_asize + (s32)h_stream->size(h_stream) - WAVEFORMATEXTENS_size();
		return STX_OK;
	}

	INIT_BYTEIO_R(pb,sizeof(pb_buf),pb_buf,h_stream);

	/* format type */
	hdr->Format.wFormatTag     = (u16)get_be16(&pb) ;

	/* number of channels (i.e. mono, stereo...) */
	hdr->Format.nChannels     = (u16)get_be16(&pb)  ;  

	/* sample rate */
	hdr->Format.nSamplesPerSec = get_be32(&pb) ;   

	/* for buffer estimation */
	hdr->Format.nAvgBytesPerSec= get_be32(&pb) ;   

	/* block size of data */
	hdr->Format.nBlockAlign    = (u16)get_be16(&pb) ;  

	/* Number of bits per sample of mono data */
	hdr->Format.wBitsPerSample = (u16)get_be16(&pb)  ; 

	/* The count in bytes of the size of*/
	hdr->Format.cbSize        = (u16)get_be16(&pb)  ;    

	hdr->Samples.wSamplesPerBlock = (u16)get_be16(&pb)  ;

	hdr->dwChannelMask = get_be32(&pb);

	xio_fread(&pb,hdr->SubFormat.data,16,&i_read);

	i_size = *i_len - WAVEFORMATEXTENS_size();

	if( i_size > 0 ) {
		xio_fread(&pb,(u8*)hdr + sizeof(STX_WAVEFORMATEXTENSIBLE), i_size, &i_read);
	}

	return STX_OK;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT load_videoinfoheader2( STX_VIDEOINFOHEADER2* hdr, u8* buf, size_t i_len )
{
    STX_RESULT     i_err;

    stx_xio*       pstream;

    ByteIOContext   pb;

    u8             pb_buf[128];

	size_t			i_read;

    i_err = STX_FAIL;


    do {

        if( i_len < sizeof(STX_VIDEOINFOHEADER2) ) {
            break;
        }

		pstream = XCREATE(stx_io_stream,NULL);
        if( !pstream ) {
            break;
		}

        pstream->read(pstream,buf,i_len,&i_read);

        INIT_BYTEIO_R(pb,sizeof(pb_buf),pb_buf,pstream);

        hdr->rcSource.left   = get_be32(&pb);

        hdr->rcSource.top    = get_be32(&pb);

        hdr->rcSource.right  = get_be32(&pb);

        hdr->rcSource.bottom = get_be32(&pb);

        hdr->rcTarget.left   = get_be32(&pb);

        hdr->rcTarget.top    = get_be32(&pb);

        hdr->rcTarget.right  = get_be32(&pb);

        hdr->rcTarget.bottom = get_be32(&pb);

        hdr->dwBitRate         = get_be32(&pb);

        hdr->dwBitErrorRate    = get_be32(&pb);

        hdr->AvgTimePerFrame   = get_be64(&pb);

        hdr->dwInterlaceFlags  = get_be32(&pb);  

        hdr->dwCopyProtectFlags = get_be32(&pb); 

        hdr->dwPictAspectRatioX = get_be32(&pb); 

        hdr->dwPictAspectRatioY = get_be32(&pb); 

        hdr->dwReserved1 = get_be32(&pb); 

        hdr->dwReserved2 = get_be32(&pb); 

        hdr->bmiHeader.biSize = get_be32(&pb);

        hdr->bmiHeader.biWidth = get_be32(&pb);

        hdr->bmiHeader.biHeight = get_be32(&pb);

        hdr->bmiHeader.biPlanes = (u16)get_be16(&pb);

        hdr->bmiHeader.biBitCount = (u16)get_be16(&pb);

        hdr->bmiHeader.biCompression = get_be32(&pb);

        hdr->bmiHeader.biSizeImage = get_be32(&pb);

        hdr->bmiHeader.biXPelsPerMeter = get_be32(&pb);

        hdr->bmiHeader.biYPelsPerMeter = get_be32(&pb);

        hdr->bmiHeader.biClrUsed = get_be32(&pb);

        hdr->bmiHeader.biClrImportant = get_be32(&pb);

        i_err = STX_OK;

    }while(FALSE);

    if( pstream ) {

        pstream->close(pstream);
    }

    return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT save_videoinfoheader2( STX_VIDEOINFOHEADER2* hdr, u8* buf, size_t* i_len )
{

    STX_RESULT      i_err;

    stx_xio*        pstream;

    ByteIOContext   pb;

    u8              pb_buf[128];

	size_t			i_read;


    i_err = STX_FAIL;
    

    do{

        if( *i_len < sizeof(STX_VIDEOINFOHEADER2) ) {
            break;
        }

		pstream = XCREATE(stx_io_stream,NULL);
        if( !pstream ) {
            break;
        }

        INIT_BYTEIO_W(pb,sizeof(pb_buf),pb_buf,pstream);

        put_be32(&pb,hdr->rcSource.left);

        put_be32(&pb,hdr->rcSource.top);

        put_be32(&pb,hdr->rcSource.right);

        put_be32(&pb,hdr->rcSource.bottom);

        put_be32(&pb,hdr->rcTarget.left);

        put_be32(&pb,hdr->rcTarget.top);

        put_be32(&pb,hdr->rcTarget.right);

        put_be32(&pb,hdr->rcTarget.bottom);

        put_be32(&pb,hdr->dwBitRate);

        put_be32(&pb,hdr->dwBitErrorRate);

        put_be64(&pb,hdr->AvgTimePerFrame);

        put_be32(&pb,hdr->dwInterlaceFlags);  

        put_be32(&pb,hdr->dwCopyProtectFlags); 

        put_be32(&pb,hdr->dwPictAspectRatioX); 

        put_be32(&pb,hdr->dwPictAspectRatioY); 

        put_be32(&pb,hdr->dwReserved1); 

        put_be32(&pb,hdr->dwReserved2); 


        put_be32(&pb,hdr->bmiHeader.biSize);

        put_be32(&pb,hdr->bmiHeader.biWidth);

        put_be32(&pb,hdr->bmiHeader.biHeight);

        put_be16(&pb,hdr->bmiHeader.biPlanes);

        put_be16(&pb,hdr->bmiHeader.biBitCount);

        put_be32(&pb,hdr->bmiHeader.biCompression);

        put_be32(&pb,hdr->bmiHeader.biSizeImage);

        put_be32(&pb,hdr->bmiHeader.biXPelsPerMeter);

        put_be32(&pb,hdr->bmiHeader.biYPelsPerMeter);

        put_be32(&pb,hdr->bmiHeader.biClrUsed);

        put_be32(&pb,hdr->bmiHeader.biClrImportant);

        xio_flush(&pb);

        *i_len = (size_t)pstream->size(pstream);

        pstream->read(pstream,buf,*i_len,&i_read);

        i_err = STX_OK;

    }while(FALSE);

    if( pstream ) {

        pstream->close(pstream);
    }

    return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT load_wavefomatex( STX_WAVEFORMATEXTENSIBLE* hdr, u8* buf, size_t i_len )
{
    STX_RESULT     i_err;

    stx_xio*       pstream;

    ByteIOContext   pb;

    u8             pb_buf[128];

    s32            i;

	size_t			i_read;


    i_err = STX_FAIL;


    do {

        if( i_len < sizeof(STX_WAVEFORMATEXTENSIBLE) ) {
            break;
        }

		pstream = XCREATE(stx_io_stream,NULL);
        if( !pstream ) {
            break;
        }

        pstream->read(pstream,buf,i_len,&i_read);

        INIT_BYTEIO_R(pb,sizeof(pb_buf),pb_buf,pstream);

        /* format type */
        hdr->Format.wFormatTag     = (u16)get_be16(&pb) ;

        /* number of channels (i.e. mono, stereo...) */
        hdr->Format.nChannels     = (u16)get_be16(&pb)  ;  

        /* sample rate */
        hdr->Format.nSamplesPerSec = get_be32(&pb) ;   

        /* for buffer estimation */
        hdr->Format.nAvgBytesPerSec= get_be32(&pb) ;   

        /* block size of data */
        hdr->Format.nBlockAlign    = (u16)get_be16(&pb) ;  

        /* Number of bits per sample of mono data */
        hdr->Format.wBitsPerSample = (u16)get_be16(&pb)  ; 

        /* The count in bytes of the size of*/
        hdr->Format.cbSize        = (u16)get_be16(&pb)  ;    

        hdr->Samples.wSamplesPerBlock = (u16)get_be16(&pb)  ;

        hdr->dwChannelMask = get_be32(&pb);

        for( i = 0; i < 16; i ++ ) {
            hdr->SubFormat.data[i] = (u8)get_byte(&pb);
        }

        i_err = STX_OK;

    }while(FALSE);

    if( pstream ) {
        pstream->close(pstream);
    }

    return i_err;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT save_wavefomatex( STX_WAVEFORMATEXTENSIBLE* hdr, u8* buf, size_t* i_len )
{
    STX_RESULT     i_err;

    stx_xio*       pstream;

    ByteIOContext   pb;

    u8             pb_buf[128];

    s32            i;

	size_t			i_read;


    i_err = STX_FAIL;


    do{

        if( *i_len < sizeof(STX_WAVEFORMATEXTENSIBLE) ) {
            break;
        }

		pstream = XCREATE(stx_io_stream,NULL);
        if( !pstream ) {
            break;
        }

        INIT_BYTEIO_W(pb,sizeof(pb_buf),pb_buf,pstream);

        put_be16(&pb,hdr->Format.wFormatTag      );

        put_be16(&pb,hdr->Format.nChannels       );

        put_be32(&pb,hdr->Format.nSamplesPerSec   );

        put_be32(&pb,hdr->Format.nAvgBytesPerSec  );

        put_be16(&pb,hdr->Format.nBlockAlign     );

        put_be16(&pb,hdr->Format.wBitsPerSample   );

        put_be16(&pb,hdr->Format.cbSize          );

        put_be16(&pb,hdr->Samples.wSamplesPerBlock);

        put_be32(&pb,hdr->dwChannelMask        );

        for( i = 0; i < 16 ; i ++ ) {

            put_byte(&pb,hdr->SubFormat.data[i]);
        }

        xio_flush(&pb);

        *i_len = (size_t)pstream->size(pstream);

        pstream->read(pstream,buf,*i_len,&i_read);

        i_err = STX_OK;

    }while(FALSE);


    if( pstream ) {

        pstream->close(pstream);
    }

    return i_err;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT aac_config_to_mtype
( u8* mtype_hdr, size_t* i_buf_len, u8* buf, size_t i_len )
{

    STX_RESULT					i_err;
    STX_WAVEFORMATEXTENSIBLE	adr;
    size_t						i_hdr_len,i_write;
	ByteIOContext				pb;


    if( ! i_buf_len ) {
		return STX_FAIL;
    }

	memset(&adr,0,sizeof(adr));
	i_hdr_len = sizeof(adr) + 8 + i_len;

    if( !mtype_hdr ) {
        *i_buf_len = i_hdr_len;
		return STX_OK;
    }

    if( *i_buf_len < i_hdr_len ) {
		return STX_FAIL;
    }

    i_err = aac_config_to_wavefomatex(&adr,&i_hdr_len,buf,i_len);
    if( STX_OK != i_err ) {
        return i_err;
    }

	INIT_BYTEIO_DIRECT(pb,i_hdr_len,mtype_hdr);

	xio_fwrite(&pb,(u8*)&adr,sizeof(adr),&i_write);
	put_be32(&pb,(u32)i_len + 8);
	put_le32(&pb,tag_ASCF);
	xio_fwrite(&pb,buf,i_len,&i_write);
	xio_flush(&pb);

    *i_buf_len = i_hdr_len;
    return STX_OK;

}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_PRIVATE s32 sampleFreqTab[] = {
    96000,
    88200,
    64000,
    48000,
    44100,
    32000,
    24000,
    22050,
    16000,
    12000,
    11025,
    8000,
    7350,
/*
    0xd reserved
    0xe reserved
    0xf escape value
*/
};

STX_PRIVATE s32 channelMapTab[][2] = {

    {
        0,
        0
    },

    {
        1,
        STX_SPEAKER_FRONT_CENTER
    },

    {
        2,
        STX_SPEAKER_FRONT_LEFT|
        STX_SPEAKER_FRONT_RIGHT
    },

    {
        3,
        STX_SPEAKER_FRONT_LEFT|
        STX_SPEAKER_FRONT_RIGHT|
        STX_SPEAKER_FRONT_CENTER
    },

    {
        4,
        STX_SPEAKER_FRONT_LEFT|
        STX_SPEAKER_FRONT_RIGHT|
        STX_SPEAKER_FRONT_CENTER|
        STX_SPEAKER_BACK_CENTER
    },

    {
        5,
        STX_SPEAKER_FRONT_LEFT|
        STX_SPEAKER_FRONT_RIGHT|
        STX_SPEAKER_FRONT_CENTER|
        STX_SPEAKER_BACK_LEFT|
        STX_SPEAKER_BACK_RIGHT
    },

    {
        5+1,
        STX_SPEAKER_FRONT_LEFT|
        STX_SPEAKER_FRONT_RIGHT|
        STX_SPEAKER_FRONT_CENTER|
        STX_SPEAKER_BACK_LEFT|
        STX_SPEAKER_BACK_RIGHT|
        STX_SPEAKER_LOW_FREQUENCY
    },

    {
        7+1,
        STX_SPEAKER_FRONT_LEFT|
        STX_SPEAKER_FRONT_RIGHT|
        STX_SPEAKER_FRONT_CENTER|
        STX_SPEAKER_BACK_LEFT|
        STX_SPEAKER_BACK_RIGHT|
        STX_SPEAKER_LOW_FREQUENCY|
        STX_SPEAKER_FRONT_LEFT_OF_CENTER|
        STX_SPEAKER_FRONT_RIGHT_OF_CENTER
    },
};


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT decode_aac_config_data
(faacDecConfiguration* hdec,s32 i_len,u8* data)
{
	STX_RESULT		i_err;
	ByteIOContext	pb;

	INIT_BYTEIO_DIRECT(pb,i_len,data);

	init_get_bits(&pb);

	hdec->config.objectTypeIndex = get_bits(&pb,5); /*5 bslbf*/

	hdec->config.samplingFrequencyIndex = get_bits(&pb,4); /*4 bslbf*/

	if ( hdec->config.samplingFrequencyIndex == 0x0f ){

		hdec->config.samplingFrequency = get_bits(&pb,24); /*24 uimsbf*/
	}
	else if( hdec->config.samplingFrequencyIndex <= 0x0c ) {

		hdec->config.samplingFrequency = sampleFreqTab[hdec->config.samplingFrequencyIndex];
	}


	if( 5 == hdec->config.objectTypeIndex ) {

		// SBR decode;
		hdec->config.sbr_present_flag = 1;
		hdec->config.samplingFrequencyIndex = (u8)get_bits(&pb, 4);
		if (hdec->config.samplingFrequencyIndex == 0x0f){
			hdec->config.samplingFrequency = (u8)get_bits(&pb,24);
		} 
		else {
			hdec->config.samplingFrequency = sampleFreqTab[hdec->config.samplingFrequencyIndex];
		}

		hdec->config.objectTypeIndex = (u8)get_bits(&pb,5);
	}
	

	hdec->config.channelsConfiguration = get_bits(&pb,4); /*4 bslbf*/


#if 0

	switch(hdec->config.objectTypeIndex) {

		case 1:
		case 2:
		case 3:
		case 6: 
		case 7:
			GASpecificConfig();
			break;

		case 8:
			CelpSpecificConfig();
			break;
			
		case 9:
			HvxcSpecificConfig();
			break;

		case 12:
			TTSSpecificConfig();
			break;

		case 13:
		case 14:
		case 15:
		case 16:
			StructuredAudioSpecificConfig();
			break;

		case 17:
		case 19:
		case 20:
		case 21:
		case 22:
		case 23:
			GASpecificConfig();
			break;

		case 24:
			ErrorResilientCelpSpecificConfig();
			break;

		case 25:
			ErrorResilientHvxcSpecificConfig();
			break;

		case 26:
		case 27:
			ParametricSpecificConfig();
			break;

	}


	switch(hdec->config.objectTypeIndex) {

		case 17:
		case 19:
		case 20:
		case 21: 
		case 22:
		case 23:
		case 24:
		case 25:
		case 26: 
		case 27:
			{
				s32 epConfig = get_bits(&pb,2); //2 bslbf

				if ( epConfig == 2 || epConfig == 3 ) {

					ErrorProtectionSpecificConfig();
				}

				if ( epConfig == 3 ) {

					s32 directMapping = get_bits(&pb,1); //1 bslbf

					if ( ! directMapping ) {

						/* tbd */
					}
				}
			}
			break;
	}

#endif


	return STX_OK;

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT aac_config_to_wavefomatex
( STX_WAVEFORMATEXTENSIBLE* hdr, size_t* i_size, u8* buf, size_t i_len )
{

	if( !i_size  ) {
		*i_size = i_len + sizeof(*hdr)  + 8;
		return STX_OK;
	}

	{

		STX_RESULT				i_err;
		faacDecConfiguration	hdec;

		INIT_MEMBER(hdec);
		i_err = decode_aac_config_data(&hdec,(s32)i_len,buf);
		if( STX_OK != i_err ) {
			return i_err;
		}


		/* parse it; */
		if( hdec.config.channelsConfiguration > 0  && hdec.config.channelsConfiguration <= 7 ) {

			hdr->SubFormat = MEDIASUBTYPE_AAC_AUDIO;

			hdr->Format.nChannels = (u16)channelMapTab[hdec.config.channelsConfiguration][0];

			hdr->dwChannelMask = channelMapTab[hdec.config.channelsConfiguration][1];
		}
		else {

			return STX_ERR_NOT_SUPPORT;
		}

		hdr->Format.cbSize = sizeof( STX_WAVEFORMATEXTENSIBLE );
		hdr->Format.nSamplesPerSec = hdec.config.samplingFrequency;
		hdr->Format.wBitsPerSample = 16;
		hdr->Format.wFormatTag = WAVE_FORMAT_AAC;
		hdr->Format.nBlockAlign = hdr->Format.nChannels * hdr->Format.wBitsPerSample / 8;
		hdr->Format.nAvgBytesPerSec = hdr->Format.nBlockAlign * hdr->Format.nSamplesPerSec;

		{
			ByteIOContext	pb;
			size_t			i_write;
			INIT_BYTEIO_DIRECT(pb,(*i_size - sizeof(*hdr)),((u8*)hdr + sizeof(*hdr)) );
			put_be32(&pb,(u32)i_len+8);
			put_le32(&pb,tag_ASCF);
			i_err = xio_fwrite(&pb,buf,i_len,&i_write);
			if( STX_OK != i_err ) {
				return i_err;
			}
			xio_flush(&pb);
		}

		return STX_OK;

	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT h264_config_to_videoinfoheader2
(STX_VIDEOINFOHEADER2* hdr, size_t* i_size, u8* buf, size_t i_len )
{

    STX_RESULT		i_err;
    THEE			h_parse;
    SPS*			sps;
    s32				width,height ;
	ByteIOContext	pb;
	size_t			i_write;
	s32				i_profile;


	if( !i_size ) {
		*i_size = i_len + sizeof(*hdr)  + 20;
		return STX_OK;
	}


    i_err = STX_FAIL;
    h_parse = STX_NULL;
    sps = STX_NULL;

    do {

        h_parse = stx_h264_preroll_create();
        if( !h_parse ) {
            break;
        }

        i_err = stx_h264_preroll_decode_pack(h_parse,buf,i_len);
        if( STX_OK != i_err ) {
            break;
        }

        sps = stx_h264_preroll_get_sps(h_parse);
        if( !sps ) {
            i_err = STX_FAIL;
            break;
        }

        hdr->bmiHeader.biWidth = sps->mb_width * 16;

        hdr->bmiHeader.biHeight = sps->mb_height * 16;

        hdr->rcSource.left = sps->crop_left * 2;

        hdr->rcSource.top = sps->crop_top * ( sps->frame_mbs_only_flag ? 2 : 4 );

        hdr->rcSource.right = hdr->bmiHeader.biWidth - ( sps->crop_right * 2 );

        hdr->rcSource.bottom = hdr->bmiHeader.biHeight - 
            (sps->crop_bottom * ( sps->frame_mbs_only_flag ? 2 : 4 )  );

        hdr->rcTarget = hdr->rcSource;

        if( sps->vui_parameters_present_flag ) {

            if( sps->timing_info_present_flag && sps->time_scale ) {

                 hdr->AvgTimePerFrame = 
                    (s64)( (double)sps->num_units_in_tick * 2000 * 10000 / sps->time_scale );
            }

            if( sps->sar.den && sps->sar.num ) {

                width = hdr->rcTarget.right - hdr->rcTarget.left;

                height = hdr->rcTarget.bottom - hdr->rcTarget.top;

                if( sps->sar.num > sps->sar.den ) {

                      width = height * sps->sar.num / sps->sar.den;
                }
                else {

                      height = width * sps->sar.den / sps->sar.num;
                }

               hdr->rcTarget.right = hdr->rcTarget.left + width;

               hdr->rcTarget.bottom = hdr->rcTarget.top + height;

            }/*if( sps->sar.den && sps->sar.num ) {*/

        }/* if( sps->vui_parameters_present_flag ) { */

		INIT_BYTEIO_DIRECT(pb,(*i_size - sizeof(*hdr)),((u8*)hdr + sizeof(*hdr)) );
		put_be32(&pb,12);
		put_le32(&pb,tag_PFID);
		i_profile = sps->sps_id | (sps->profile_idc<<8) | (sps->level_idc<<16);
		put_be32(&pb,i_profile);
		put_be32(&pb,(u32)i_len+8);
		put_le32(&pb,tag_SPS);
		i_err = xio_fwrite(&pb,buf,i_len,&i_write);
		if( STX_OK != i_err ) {
			break;
		}
		xio_flush(&pb);

        i_err = STX_OK;

    }while(FALSE);


    if( h_parse ) {
        stx_h264_preroll_close(h_parse);
    }

    return i_err;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT h264_config_to_mtype( 
    u8* mtype_hdr, size_t* i_buf_len, u8* buf, size_t i_len )
{

    STX_RESULT				i_err;
    STX_VIDEOINFOHEADER2	vdr;
    size_t					i_hdr_len,i_write;
    u8*						p;

    i_err = STX_FAIL;

    do{

        if( ! i_buf_len ) {
            break;
        }

		i_hdr_len = sizeof(vdr) + 8 + i_len;

        if( !mtype_hdr ) {
            *i_buf_len = i_hdr_len;
            i_err = STX_OK;
            break;
        }

        if( *i_buf_len < i_hdr_len ) {
            break;
        }

		memset(&vdr,0,sizeof(vdr));
        i_err = h264_config_to_videoinfoheader2(&vdr,&i_hdr_len,buf,i_len);
        if( STX_OK != i_err ) {
            break;
        }

        i_err = STX_OK;

    }while(FALSE);

    return i_err;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_INTERF(subfmt2pt);
struct subfmt2pt{
	stx_gid*	fmt;
	s32			payload;
};
static subfmt2pt fmt2pttab[] = {
	{
		&MEDIASUBTYPE_AMR,0
	},
	{
		&MEDIASUBTYPE_AMR_WB,0
	},
// 	{
// 		&MEDIASUBTYPE_G723,4
// 	},
	{
		&MEDIASUBTYPE_MPEG1Audio_Layer1,14
	},
	{
		&MEDIASUBTYPE_MPEG1Audio_Layer2,14
	},
	{
		&MEDIASUBTYPE_MPEG1Audio_Layer3,14
	},
	{
		&MEDIASUBTYPE_H261,31
	},
	{
		&MEDIASUBTYPE_h261,31
	},
	{
		&MEDIASUBTYPE_MPEG2_TRANSPORT,33
	},
	{
		&MEDIASUBTYPE_H263,34
	},
	{
		&MEDIASUBTYPE_h263,34
	},
	{
		&MEDIASUBTYPE_S263,34
	},
	{
		&MEDIASUBTYPE_s263,34
	},
	{
		&MEDIASUBTYPE_H264,96
	},
	{
		&MEDIASUBTYPE_h264,96
	},
	{
		&MEDIASUBTYPE_AAC_AUDIO,97
	},
	{
		&MEDIASUBTYPE_MPEG4_VIDEO,98
	},
};


s32 subfmt_to_rtp_payload_type(stx_gid subfmt)
{
	s32 i;

	for( i = 0; i < sizeof(fmt2pttab)/sizeof(fmt2pttab[0]); i ++ ) {
		if( IS_EQUAL_GID(*fmt2pttab[i].fmt,subfmt) ) {
			return fmt2pttab[i].payload;
		}
	}
	return -1;
}
