/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/
#include "stx_valve.h"

#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif


#ifdef _MAP_THE	
#	undef _MAP_THE	
#endif	
#define _MAP_THE STX_MAP_THE(valve_outpin)



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API_IMP 
CREATE_STX_COM_BEGIN(stx_output_pin,STX_IID_OutputPin,valve_outpin,valve_callback* h_valve)
CREATE_STX_COM_END(stx_output_pin,STX_IID_OutputPin,valve_outpin,h_valve)


STX_COM_BEGIN(valve_outpin);
/**/
/**/STX_PUBLIC(stx_output_pin)
/**/STX_COM_DATA_DEFAULT(stx_output_pin)
/**/
/* other members; */
/**/stx_media_type*			    p_mtyp;
/**/stx_base_pin*			    p_input;
/**/stx_xio*					h_property;
/**/valve_callback*				h_valve;
/**/
STX_COM_END();


STX_COM_FUNC_DECL_DEFAULT(stx_output_pin,stx_output_pin_vt);
STX_COM_FUNCIMP_DEFAULT(valve_outpin,stx_output_pin,stx_output_pin_vt);

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_COM_MAP_BEGIN(valve_outpin)
/**/STX_COM_MAP_ITEM(STX_IID_OutputPin)
STX_COM_MAP_END()

STX_API_IMP
STX_NEW_BEGIN(valve_outpin,valve_callback* h_valve)
{
	STX_RESULT			i_err;

	i_err = STX_FAIL;

	STX_SET_THE(stx_output_pin);
	STX_COM_NEW_DEFAULT(
		stx_output_pin,
		the->stx_output_pin_vt,
		stx_output_pin_vt,
		STX_GID_NULL,
		STX_CATEGORY_BasePin,
		"StreamX valve output pin");

	the->h_valve = h_valve;
}
STX_NEW_END()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE 
STX_QUERY_BEGIN(valve_outpin)
{
	STX_COM_QUERY_DEFAULT(stx_output_pin,the->stx_output_pin_vt);
}
STX_QUERY_END()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE	
STX_DELETE_BEGIN(valve_outpin)
{
	if( the->h_property) {
		the->h_property->close(the->h_property);
	}
	SAFE_XDELETE( the->p_mtyp );
	STX_COM_DELETE_DEFAULT(stx_output_pin);
}
STX_DELETE_END
(
 STX_COM_DELETE_BEGIN(stx_output_pin)
 ,
 STX_COM_DELETE_END(stx_output_pin)
 )




 /***************************************************************************
 RETURN VALUE:
 INPUT:
 OUTPUT:
 NOTE: not used;
 ***************************************************************************/
 STX_PURE STX_RESULT stx_output_pin_vt_pin_plug_xxx_run
 (THEE h,stx_sync_inf* h_sync)
{
	_MAP_THE;
	return STX_ERR_NOT_SUPPORT;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_output_pin_vt_pin_plug_xxx_send_msg
( STX_HANDLE h, stx_base_message* p_msg )
{
	_MAP_THE;
	if( STX_MSG_TYPE_DOWNSTREAM & p_msg->get_msg_type(p_msg) ) {
		if( !the->p_input ) {
			return STX_OK;
		}
		return the->p_input->send_msg( the->p_input, p_msg );
	}
	/* upstream, send msg to filter; */
	return the->p_parent->send_msg( the->p_parent, p_msg );
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE b32 stx_output_pin_vt_pin_xxx_is_connected
( STX_HANDLE h ,stx_base_pin** pp_pin)
{
	_MAP_THE;
	if( the->p_input ) {
		if( pp_pin ) {
			the->p_input->add_ref(the->p_input);
			*pp_pin = the->p_input;
		}
		return TRUE;
	}
	return FALSE;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_output_pin_vt_pin_xxx_connect
(STX_HANDLE h, stx_base_pin* p_pin )
{
	_MAP_THE;
	if( !p_pin ) {
		return STX_ERR_INVALID_PARAM;
	}
	p_pin->add_ref(p_pin);
	the->p_input = p_pin;
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_output_pin_vt_pin_xxx_break_connect
( STX_HANDLE h )
{
	_MAP_THE;
	if( the->p_input ) {
		the->p_input->release(the->p_input);
		the->p_input = STX_NULL;
	}
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE stx_media_type* stx_output_pin_vt_pin_xxx_get_media_type
( STX_HANDLE h )
{
	_MAP_THE;
	if( the->p_mtyp){
		the->p_mtyp->add_ref(the->p_mtyp);
	}
	return the->p_mtyp;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_output_pin_vt_pin_xxx_set_media_type
( STX_HANDLE h, stx_media_type* p_media_type )
{
	STX_RESULT i_err;

	_MAP_THE;

	SAFE_XDELETE0( the->p_mtyp );

	if( !p_media_type ) {
		return STX_OK;
	}

	i_err = STX_FAIL;

	do{
		the->p_mtyp = XCREATE(base_media_type,NULL,p_media_type);
		if( !the->p_mtyp ) {
			break;
		}
		i_err = STX_OK;
	}while(FALSE);

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE: pull mode use only;
***************************************************************************/
STX_PURE STX_RESULT stx_output_pin_vt_pin_xxx_get_media_data
(STX_HANDLE h,stx_media_data ** pp_mdat,s32 i_wait)
{
	_MAP_THE;
	return STX_ERR_NOT_SUPPORT;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_output_pin_vt_pin_xxx_release_media_data
( STX_HANDLE h, stx_media_data* p_mdat )
{
	_MAP_THE;
	return XCALL(release_media_data,the->h_valve, p_mdat );
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_output_pin_vt_pin_xxx_deliver
( THEE h, stx_media_data* p_mdat,stx_sync_inf* h_sync)
{
	_MAP_THE;
	if( !the->p_input ) {
		return STX_ERR_PIN_NOT_CONNECTED;
	}
	if( p_mdat ) {
		p_mdat->incr(p_mdat);
	}
	return the->p_input->deliver( the->p_input, p_mdat, h_sync );
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_output_pin_vt_pin_plug_xxx_flush
(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	_MAP_THE;
	if( the->p_input ) {
		return the->p_input->flush(the->p_input,i_flag,h_sync);
	}
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_output_pin_vt_pin_plug_xxx_start
(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	_MAP_THE;
	if( the->p_input ) {
		return the->p_input->start(the->p_input,i_flag,h_sync);
	}
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_output_pin_vt_pin_plug_xxx_stop
(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	_MAP_THE;

	if( the->p_input ) {
		return the->p_input->stop(the->p_input,i_flag,h_sync);
	}

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE: pull mode use only;
***************************************************************************/
STX_PURE STX_RESULT stx_output_pin_vt_pin_xxx_receive
( THEE h, stx_media_data** pp_mdat,stx_sync_inf* h_sync)
{
	_MAP_THE;
	{
		STX_RESULT i_err;
		i_err = the->p_flt->receive(the->p_flt,(stx_base_pin*)&the->stx_output_pin_vt,pp_mdat,h_sync);
		if( STX_OK == i_err ) {
			stx_media_data* const p = *pp_mdat;
			p->incr(p);
		}
		return i_err;
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
the filter must set allocator before set media-type;
***************************************************************************/
STX_PURE STX_RESULT	stx_output_pin_vt_xxx_set_mem_allocator
( STX_HANDLE h, stx_media_data_allocator* p_alloc )
{
	_MAP_THE;
	return STX_ERR_NOT_SUPPORT;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE	stx_media_data_allocator* 
stx_output_pin_vt_xxx_get_mem_allocator( STX_HANDLE h )
{
	_MAP_THE;
	return NULL;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_output_pin_vt_pin_plug_xxx_get_property
(STX_HANDLE h,stx_xio* h_xio)
{
	_MAP_THE;
	{
		STX_RESULT		i_err;
		stx_io_op_param	inf;
		size_t          i_size;
		size_t			i_write;

		if( !the->h_property ) {
			return STX_ERR_FILE_NOT_FOUND;
		}
		i_size = (size_t)the->h_property->size(the->h_property);
		i_err = the->h_property->get(the->h_property,STX_IO_READ_P,&inf);
		if( STX_OK != i_err ){
			return i_err;
		}
		h_xio->write(h_xio,inf.buf,i_size,&i_write);
		return STX_OK;
	}

	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_output_pin_vt_pin_plug_xxx_set_property
(STX_HANDLE h,stx_xio* h_xio)
{
	_MAP_THE;
	{
		STX_RESULT		i_err;
		stx_io_op_param	inf;
		size_t          i_size;
		size_t			i_write;
		if( !the->h_property) {
			the->h_property = XCREATE(stx_io_stream,NULL);
			if( !the->h_property ) {
				return STX_FAIL;
			}
		}
		i_size = (size_t) h_xio->size(h_xio);
		i_err = h_xio->get(h_xio,STX_IO_READ_P,&inf);
		if( STX_OK != i_err ){
			return STX_FAIL;
		}
		the->h_property->clear(the->h_property);
		the->h_property->write(the->h_property,inf.buf,i_size,&i_write);
		return STX_OK;
	}
	return STX_ERR_NOT_SUPPORT;
}