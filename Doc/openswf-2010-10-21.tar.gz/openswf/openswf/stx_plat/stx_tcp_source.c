/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#include "stx_all.h"

#include "stx_sync_source.h"
#include "stx_protocol.h"
#include "stp_client.h"

#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif

#ifdef _MAP_THE	
#	undef _MAP_THE	
#endif	
#define _MAP_THE STX_MAP_THE(stx_tcp_source)


DEFINE_XGUID( STX_CLSID_tcp_source,
			 0x2903cbd0, 0xf91f, 0x4962, 0xb0, 0x74, 0xf3, 0xb1, 0x25, 0x5c, 0x9a, 0x6d );

char* g_szStreamX_tcp_source = STX_PLUGIN_STRING(tcp_source);


enum tcp_src_status{
	tcp_src_stp_open,
	tcp_src_stp_play,
	tcp_src_prefetch,
	tcp_src_get_hdr,
	tcp_src_get_ini,
	tcp_src_make_data,
	tcp_src_deliver,
	tcp_src_stop,
	tcp_src_stop_pin,
	tcp_src_stop_io,
};

STX_INPUT_MEDIA_TYPE_MAP_BEGIN(stx_tcp_source)
/**/MEDIA_TYPE_MAP_ITEM(STX_GID_NULL,STX_GID_NULL)
STX_INPUT_MEDIA_TYPE_MAP_END()


STX_OUTPUT_MEDIA_TYPE_MAP_BEGIN(stx_tcp_source)
/**/MEDIA_TYPE_MAP_ITEM(STX_GID_NULL,STX_GID_NULL)
STX_OUTPUT_MEDIA_TYPE_MAP_END()



STX_COM_BEGIN(stx_tcp_source);
/**/
/* base source; */
/**/STX_PUBLIC( stx_base_source )
/**/
/* base filter; */
/**/STX_PUBLIC( stx_base_filter)
/**/STX_COM_DATA_DEFAULT(stx_base_filter)
/**/
/* base graph control;*/
/**/STX_PUBLIC( stx_base_control)
/**/
/* base media information; */
/**/STX_PUBLIC( stx_media_info)
/**/
/* other members; */
/**/STX_HANDLE					h_task;
/**/STX_HANDLE					h_mutex;
/**/
/**/s64							i_file_time;
/**/
/**/s32							i_chid;
/**/s32							i_idx;
/**/char						sz_ip[128];	// prop
/**/u16							i_port;		// prop
/**/char*						sz_url;		// prop
/**/char*						sz_graph;	// prop
/**/stx_xio*					h_client;
/**/
/**/stx_output_pin*				p_output_pin;  /* only support video and audio; */
/**/
/**/b32							b_opened;
/**/THEE						h_stack;
/**/THEE						h_stop;
/**/s64							i_last_time;
/**/stx_xio*					h_input_stream;
/**/stx_gid						major_type;
/**/stx_gid						sub_type;
/**/char						major_name[256];
/**/char						sub_name[256];
/**/stx_media_data*				p_mdat; // temp;
/**/s32							i_width;
/**/s32							i_height;
/**/s32							i_pitch[3];
/**/
STX_COM_END();



STX_COM_FUNC_DECL_DEFAULT(stx_media_info,stx_media_info_vt);
STX_COM_FUNC_DECL_DEFAULT(stx_base_control,stx_base_control_vt);
STX_COM_FUNC_DECL_DEFAULT(stx_base_filter,stx_base_filter_vt);
STX_COM_FUNC_DECL_DEFAULT(stx_base_source,stx_base_source_vt);

STX_COM_FUNCIMP_DEFAULT(stx_tcp_source,stx_media_info,stx_media_info_vt);
STX_COM_FUNCIMP_DEFAULT(stx_tcp_source,stx_base_control,stx_base_control_vt);
STX_COM_FUNCIMP_DEFAULT(stx_tcp_source,stx_base_filter,stx_base_filter_vt);
STX_COM_FUNCIMP_DEFAULT(stx_tcp_source,stx_base_source,stx_base_source_vt);


/*{{{STX_MSG_ENTRY_DECLARE**************************************************/
/* to do : add msg proc entry  declaration here; */
/**/STX_MSG_ENTRY_DECLARE(on_play)
/**/STX_MSG_ENTRY_DECLARE(on_pause)
/**/STX_MSG_ENTRY_DECLARE(on_resume)
/**/STX_MSG_ENTRY_DECLARE(on_stop)
/**/STX_MSG_ENTRY_DECLARE(at_BreakPin)
/**/STX_MSG_ENTRY_DECLARE(at_play)
/**/STX_MSG_ENTRY_DECLARE(at_pause)
/**/STX_MSG_ENTRY_DECLARE(at_resume)
/**/STX_MSG_ENTRY_DECLARE(at_stop)
/**/STX_MSG_ENTRY_DECLARE(on_auto_stop)
/**/STX_MSG_ENTRY_DECLARE(on_app_stop)
/*}}}***********************************************************************/

/*{{{STX_BEGIN_MSG_MAP******************************************************/
STX_BEGIN_MSG_MAP(the_msg_data)
/* to do : add msg proc entry name here; */
/**/ON_STX_MSG(STX_MSG_Play,on_play)
/**/ON_STX_MSG(STX_MSG_Pause,on_pause)
/**/ON_STX_MSG(STX_MSG_Resume,on_resume)
/**/ON_STX_MSG(STX_MSG_Stop,on_stop)
/**/ON_STX_MSG(STX_MSG_AutoStop,on_auto_stop)
/**/ON_STX_MSG(STX_MSG_AppStop,on_app_stop)
STX_END_MSG_MAP
/*}}}***********************************************************************/


/*{{{STX_BEGIN_MSG_RESPONSE_MAP*********************************************/
STX_BEGIN_MSG_RESPONSE_MAP(the_msg_response)
/* to do : add msg process entry name here; */
/**/ON_STX_MSG(STX_MSG_Play,at_play)
/**/ON_STX_MSG(STX_MSG_Pause,at_pause)
/**/ON_STX_MSG(STX_MSG_Resume,at_resume)
/**/ON_STX_MSG(STX_MSG_Stop,at_stop)
/**/ON_STX_MSG(STX_MSG_BreakPin,at_BreakPin)
STX_END_MSG_RESPONSE_MAP
/*}}}***********************************************************************/


/*{{{STX_DISPATHCH_MSG_PROC*************************************************/
STX_DISPATCH_MSG_PROC( dispatch_msg,the_msg_data )
/*}}}***********************************************************************/


/*{{{STX_RESPONSE_MSG_PROC**************************************************/
STX_RESPONSE_MSG_PROC( response_msg,the_msg_response )
/*}}}***********************************************************************/


STX_PRIVATE STX_RESULT parse_status( stx_tcp_source* the, stx_sync_inf* h_sync );
STX_PRIVATE STX_RESULT parse_header(stx_tcp_source* the,stx_sync_inf* h_sync);
STX_PRIVATE STX_RESULT parse_body(stx_tcp_source*the,stx_sync_inf* h_sync);
STX_PRIVATE STX_RESULT on_connect(stx_tcp_source* the, stx_xini* h_xini,stx_sync_inf* h_sync);
STX_PRIVATE STX_RESULT on_deliver(stx_tcp_source* the, stx_xini* h_xini,stx_sync_inf* h_sync);

STX_PRIVATE STX_RESULT deliver_media_data(stx_tcp_source* the, stx_sync_inf* h_sync );
STX_PRIVATE STX_RESULT make_media_data(stx_tcp_source* the,stx_sync_inf* h_sync );
STX_PRIVATE STX_RESULT init_video_outputpin(stx_tcp_source* the,u8* p_hdr,s32 i_size);
STX_PRIVATE STX_RESULT init_outputpin(stx_tcp_source* the,u8* p_hdr,s32 i_size);


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_COM_MAP_BEGIN(stx_tcp_source)
/**/STX_COM_MAP_ITEM(STX_IID_FileSource)
/**/STX_COM_MAP_ITEM(STX_IID_BaseFilter)
/**/STX_COM_MAP_ITEM(STX_IID_BaseControl)
/**/STX_COM_MAP_ITEM(STX_IID_MediaInfo)
STX_COM_MAP_END()

STX_API_IMP	STX_NEW_BEGIN(stx_tcp_source)
{
	STX_SET_THE(stx_base_source);
	STX_COM_NEW_DEFAULT(stx_base_source,the->stx_base_source_vt,stx_base_source_vt,
		STX_CLSID_tcp_source,STX_CATEGORY_FileSource,g_szStreamX_tcp_source);

	STX_SET_THE(stx_base_filter);
	STX_COM_NEW_DEFAULT(stx_base_filter,the->stx_base_filter_vt,stx_base_filter_vt,
		STX_CLSID_tcp_source,STX_CATEGORY_FileSource,g_szStreamX_tcp_source);

	STX_SET_THE(stx_base_control);
	STX_COM_NEW_DEFAULT(stx_base_control,the->stx_base_control_vt,stx_base_control_vt,
		STX_CLSID_tcp_source,STX_CATEGORY_FileSource,g_szStreamX_tcp_source);

	STX_SET_THE(stx_media_info);
	STX_COM_NEW_DEFAULT(stx_media_info,the->stx_media_info_vt,stx_media_info_vt,
		STX_CLSID_tcp_source,STX_CATEGORY_FileSource,g_szStreamX_tcp_source);

	the->h_mutex = stx_create_mutex(NULL,0,NULL);
	if(!the->h_mutex ) {
		break;
	}

	the->h_input_stream = XCREATE(stx_io_stream,NULL);
	if(!the->h_input_stream ) {
		break;
	}

	// default sub channel id is video;
	the->i_chid = STP_ID_VIDEO;

	// service ip/port;
	stx_strcpy(the->sz_ip,sizeof(the->sz_ip),g_sz_ip4_default);
	the->i_port = atoi(g_sz_port_default);

	// graph
	the->sz_graph = xstrdup("@input valid graph file");
	if( !the->sz_graph ) {
		break;
	}

	// URL
	the->sz_url = xstrdup("@input valid URL");
	if( !the->sz_url ) {
		break;
	}

}
STX_NEW_END()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_QUERY_BEGIN(stx_tcp_source)
{
	STX_COM_QUERY_DEFAULT(stx_base_source,the->stx_base_source_vt);
	STX_COM_QUERY_DEFAULT(stx_base_filter,the->stx_base_filter_vt);
	STX_COM_QUERY_DEFAULT(stx_base_control,the->stx_base_control_vt);
	STX_COM_QUERY_DEFAULT(stx_media_info,the->stx_media_info_vt);
}
STX_QUERY_END()



/***************************************************************************
STX_PURE sint32 flv_release(STX_HANDLE h)
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_DELETE_BEGIN(stx_tcp_source)
{
	{
		stx_base_source* const src = &the->stx_base_source_vt;
		src->close_stream(src);
	}


	if( the->sz_graph ) {
		stx_free(the->sz_graph);
		the->sz_graph = NULL;
	}

	if( the->sz_url ) {
		stx_free(the->sz_url);
		the->sz_url = NULL;
	}

	if( the->h_mutex ) {
		stx_close_mutex(the->h_mutex);
	}

	if( the->h_stack ) {
		stx_stack_close(the->h_stack);
		the->h_stack = NULL;
	}

	if( the->h_stop ) {
		stx_stack_close(the->h_stop);
		the->h_stop = NULL;
	}

	STX_COM_DELETE_DEFAULT(stx_base_filter);
}
STX_DELETE_END
(
STX_COM_DELETE_BEGIN(stx_base_filter)
,
STX_COM_DELETE_END(stx_base_filter)
)



 /***************************************************************************
 RETURN VALUE:
 INPUT:
 OUTPUT:
 NOTE:
 ***************************************************************************/
 STX_PURE void 
 stx_base_source_vt_xxx_close_stream(STX_HANDLE h)
{
	stx_base_message* h_msg;

	STX_MAP_THE(stx_tcp_source);

	/* close all output pin; */

	h_msg = XCREATE(base_msg,NULL,NULL);
	h_msg->set_msg_type(h_msg,STX_MSG_TYPE_DOWNSTREAM);
	h_msg->get_msg_cnt(h_msg)->msg_gid = STX_MSG_BreakPin;
	stx_base_filter_vt_plug_xxx_send_msg(&the->stx_base_filter_vt,h_msg);
	SAFE_XDELETE(h_msg);

	/* todo : release object; */
	if( the->p_output_pin ) {

		if( the->p_mdat ) {
			the->p_output_pin->release_media_data(the->p_output_pin,the->p_mdat);
			the->p_mdat = NULL;
		}
		{
			s32 i_ref = the->p_output_pin->release(the->p_output_pin);

			stx_log("output pin i_ref = %d\r\n",i_ref);
			the->p_output_pin = STX_NULL;
		}

	} // if( the->p_output_pin ) {

	if( the->h_client ) {
		the->h_client->close(the->h_client );
		the->h_client = STX_NULL;
	}

	if(the->h_input_stream ) {
		the->h_input_stream->close(the->h_input_stream );
		the->h_input_stream = STX_NULL;
	}
}




/***************************************************************************
stx_base_source_vt_xxx_load_stream
RETURN VALUE:
INPUT:
OUTPUT:
NOTE: push and pull

	push, the socket is created outside of filter;
	pull, the filter create the stp_client itself;

	as for tcp source filter,

	push mode, the graph and the tcp source must created by a service protocol;
	load_stream is calling from the protocol->canvas->;
	so the input io socket handle should be query from the protocol;

	pull mode, the tcp source at editor, and the other pear: tcp render, is at service;
	so only one output pin, one socket data channel allowed;

***************************************************************************/
STX_PURE STX_RESULT stx_base_source_vt_xxx_load_stream
(STX_HANDLE h, const char* sz_stream,stx_sync_inf* h_sync)
{
	STX_RESULT		i_err;


	STX_MAP_THE(stx_tcp_source);

	i_err = STX_FAIL;


	if( !the->h_stack ) {

		the->h_stack = stx_stack_create();
		if( !the->h_stack ) {
			return STX_FAIL;
		}

		if( ! sz_stream ) {   
			
			//
			the->h_input_stream->clear(the->h_input_stream);

			// get input xio;
			{
				// send upstream message, try to get a xio interface;
				stx_base_message*       p_msg_internal;
				stx_msg_cnt*			p_cnt;
				stp_subchannel*			stp_cha;

				i_err = STX_FAIL;
				p_msg_internal = NULL;

				do{
					p_msg_internal = XCREATE(base_msg,NULL,NULL);
					if( !p_msg_internal ) {
						break;
					}
					XCALL(set_msg_type,p_msg_internal,STX_MSG_TYPE_UPSTREAM);
					i_err = XCALL(set_msg_buf,p_msg_internal,(u8*)&STX_IID_InputIo,sizeof(STX_IID_InputIo));
					if( STX_OK != i_err ) {
						break;
					}
					p_cnt = XCALL(get_msg_cnt,p_msg_internal);
					p_cnt->msg_gid = STX_MSG_QueryObject;
					p_cnt->param.i_param[0] = (size_t)h; // source interface, who am I;

					i_err = XCALL(send_msg,the->p_parent,p_msg_internal);
					if( STX_OK != i_err ) {
						break;
					}

					if( !XCALL(is_msg_closed,p_msg_internal) ) {
						i_err = STX_FAIL;
						break;
					}

					// media header, init output mediatype;
					stp_cha = (stp_subchannel*)p_cnt->param.i_param[0];
					
					the->major_type = stp_cha->major_type;
					the->sub_type = stp_cha->sub_type;
					stx_strcpy(the->major_name,sizeof(the->major_name),stp_cha->major_name);
					stx_strcpy(the->sub_name,sizeof(the->sub_name),stp_cha->sub_name);

					// stp channel id;
					the->i_chid = stp_cha->i_chid;
					// stp channel index;
					the->i_idx = stp_cha->i_idx;

					i_err = init_outputpin(the,stp_cha->p_hdr,stp_cha->i_hdr_size);
					if( STX_OK != i_err ) {
						break;
					}

					// stp client;
					the->h_client = (stx_xio*)p_cnt->param.i_param[1];
					if( !the->h_client ) {
						i_err = STX_FAIL;
						break;
					}

					stx_stack_push(the->h_stack,tcp_src_get_hdr);
					stx_stack_push(the->h_stack,STX_PROT_HDR_SIZE);
					stx_stack_push(the->h_stack,tcp_src_prefetch);
					i_err = STX_OK;

				}while(FALSE); // do{

				SAFE_XDELETE(p_msg_internal);

				return i_err;

			} // block

		}  // if( ! sz_stream ) {


		// the tcp source should first to create the stx client, link to service;

		if(the->sz_url) {
			stx_free(the->sz_url);
		}
		the->sz_url = xstrdup(sz_stream);
		if( !the->sz_url ) {
			return STX_FAIL;
		}

		// open stx_client;
		the->h_client = stx_create_io_stp(the->sz_ip,the->i_port,the->sz_url,the->sz_graph,NULL);
		if( !the->h_client) {
			return STX_FAIL;
		}

		stx_stack_push(the->h_stack,tcp_src_stp_open);


	}// if( !the->h_stack ) {

	return parse_status(the,h_sync);
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT parse_status( stx_tcp_source* the, stx_sync_inf* h_sync )
{
	STX_RESULT		i_err;
	size_t*			h_status;
	size_t			i_status;

	h_status = stx_stack_pop(the->h_stack);
	if( !h_status ) { // wait for stack reset, or initialized;
		h_sync->i_idle = MILISEC2REFTIME(10);
		RESET_XENTRY(h_sync,&the->stx_base_filter_vt);
		return STX_WOUNLD_BLOCK;
	}

	i_status = *h_status;

	if( tcp_src_stp_open == i_status ) {

		// pull mode only; tcp source at graph editor;
		// tcp source only use one one data stream.

		do{
			i_err = the->h_client->open(the->h_client,NULL,STX_SERVICE_REQUEST_CONVERT);
		}while(STX_AGAIN == i_err);

		if( STX_IDLE == i_err || STX_WOUNLD_BLOCK == i_err ) {
			stx_stack_push(the->h_stack,tcp_src_stp_open);
			h_sync->i_idle = MILISEC2REFTIME(10);
			RESET_XENTRY(h_sync,&the->stx_base_filter_vt);
			return STX_WOUNLD_BLOCK;
		}

		if( i_err < 0 ) {
			stx_stack_close(the->h_stack);
			the->h_stack = NULL;
			return i_err;
		}

		// open success; should first quote mediatype from stp_client;
		{
			stp_op_param	param;
			stp_subchannel* h_sub;
			s32				idx = 0;

			INIT_MEMBER(param);
			param.i_idx = &idx;
			i_err = the->h_client->get(the->h_client,STX_IO_ENUM,&param);
			if( STX_OK!= i_err ) {
				return i_err;
			}

			h_sub = (stp_subchannel*)param.h_obj;

			the->i_idx = h_sub->i_idx;
			the->i_chid = h_sub->i_chid;
			the->major_type = h_sub->major_type;
			the->sub_type = h_sub->sub_type;
			stx_strcpy(the->major_name,sizeof(the->major_name),h_sub->major_name);
			stx_strcpy(the->sub_name,sizeof(the->sub_name),h_sub->sub_name);

			// set output pin;
			if( IS_EQUAL_GID(the->major_type,MEDIATYPE_Video) 
				&& IS_EQUAL_GID(the->sub_type,MEDIASUBTYPE_LxVideoFrame)) {

					i_err = init_video_outputpin(the,h_sub->p_hdr,h_sub->i_hdr_size);
					if( STX_OK != i_err ) {
						return i_err;
					}
			}
			else {

				i_err = init_outputpin(the,h_sub->p_hdr,h_sub->i_hdr_size);
				if( STX_OK != i_err ) {
					return i_err;
				}
			}

		}

		stx_stack_close(the->h_stack);
		the->h_stack = NULL;

		RESET_XENTRY(h_sync,&the->stx_base_filter_vt);
		return STX_OK;

	} // if( tcp_src_stp_open == i_status ) {


	if( tcp_src_prefetch ==  i_status){

		size_t i_data_prefetch;

		h_status = stx_stack_pop(the->h_stack);
		if( !h_status ) {
			return STX_FAIL; // fatal;
		}
		i_data_prefetch = *h_status;


		for( ; ; ) {

			size_t		i_data;
			size_t		i_read;
			size_t		i_write;
			char		buf[1500];

			i_data = i_data_prefetch > sizeof(buf) ? sizeof(buf) : i_data_prefetch;

			do{
				i_read = the->i_idx; // 
				i_err = the->h_client->read(the->h_client,buf,i_data,&i_read );

			}while(STX_AGAIN == i_err);

			if( i_err < 0 ||  STX_EOF == i_err ) {
				return i_err;
			} //if( i_err < 0 || STX_EOF == i_err || (

			if( STX_IDLE == i_err || STX_WOUNLD_BLOCK == i_err ) {
				s64 i_time = stx_get_milisec();
				if( !the->i_last_time ) {
					the->i_last_time = i_time;
				}
				else if( the->i_last_time - i_time > STX_PROT_LIMIT_TIME ) {
					return STX_EOF;
				}
				stx_stack_push(the->h_stack,i_data_prefetch);
				stx_stack_push(the->h_stack,i_status);
				h_sync->i_idle = MILISEC2REFTIME(10);
				RESET_XENTRY(h_sync,&the->stx_base_filter_vt);
				return i_err;
			} //if( STX_IDLE == i_err || STX_WOUNLD_BLOCK == i_err ) {

			the->i_last_time = 0; // clear idle time;

			the->h_input_stream->write(the->h_input_stream,buf,i_read,&i_write);

			i_data_prefetch -= i_read;

			if( !i_data_prefetch ) {

/*
				{
					char sz_data[32];
					stx_io_op_param param;
					INIT_MEMBER(param);
					i_err = the->h_input_stream->get(the->h_input_stream,STX_IO_READ_P,&param);
					if( param.i_available_data == STX_PROT_HDR_SIZE ) {
						binary_to_string(12,param.buf,sz_data);
						stx_log("tcp_source:prefetch_data:%s\r\n",sz_data);
					}
				}
*/

				break;
			}

		} // for( ; ; ) {

		h_status = stx_stack_pop(the->h_stack);
		if( !h_status ) {
			return STX_FAIL; // fatal;
		}
		i_status = *h_status;

	} //if( i_status < STX_PROT_OPEN_URL ){


	if( tcp_src_get_hdr == i_status ) {
		//stx_log("tcp_source:tcp_src_get_hdr\r\n");
		return parse_header(the,h_sync);
	}
	else if( tcp_src_get_ini == i_status ) {
		//stx_log("tcp_source:tcp_src_get_ini\r\n");
		return parse_body(the,h_sync);
	}
	else if( tcp_src_make_data == i_status ) {
		//stx_log("tcp_source:tcp_src_make_data\r\n");
		return make_media_data(the,h_sync);
	}
	else if( tcp_src_deliver == i_status ) {
		//stx_log("tcp_source:tcp_src_deliver\r\n");
		return deliver_media_data(the,h_sync);
	}

	// fatal;
	stx_log("tcp_source:invalid status\r\n");
	return STX_FAIL;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT parse_header(stx_tcp_source* the,stx_sync_inf* h_sync)
{
	STX_RESULT		i_err;

	ByteIOContext	pb;

	u32				hdr;
	stx_io_op_param param;
	u32				prot_flag;
	u32				body_len;

	INIT_MEMBER(param);
	i_err = the->h_input_stream->get(the->h_input_stream,STX_IO_READ_P,&param);
	if( STX_OK != i_err ) {
		return i_err;
	}

	INIT_BYTEIO_DIRECT(pb,STX_DEFAULT_PATH,param.buf );

	hdr = get_le32(&pb);
	if( hdr != *(u32*)g_sz_prot_stx ) {
		stx_log("invalid stx protocol header:0x%X\r\n",hdr);
		return STX_ERR_NOT_SUPPORT;
	}

	prot_flag = get_be32(&pb);
	if( !( prot_flag & STX_PROTOCOL_XINI ) ) {
		return STX_ERR_NOT_SUPPORT;
	}

	body_len = get_be32(&pb); // must not be zero;

	stx_stack_push(the->h_stack,tcp_src_get_ini);
	stx_stack_push(the->h_stack,body_len);
	stx_stack_push(the->h_stack,tcp_src_prefetch);

	the->h_input_stream->clear(the->h_input_stream);

	return STX_AGAIN;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT parse_body(stx_tcp_source*the,stx_sync_inf* h_sync)
{

	STX_RESULT		i_err;
	stx_xini*		h_xini;
	STX_HANDLE      h_key;
	s32				i_request;

	h_xini = NULL;
	i_err = STX_FAIL;

	do{

		i_err = stx_ini_create(NULL,the->h_input_stream,STX_INI_READ_ONLY|STX_INI_NO_COMMENT,0,&h_xini);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = h_xini->create_key(h_xini,NULL,g_sz_service_request,NULL,&h_key);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = h_xini->read_int32(h_xini,h_key,&i_request);
		if( STX_OK != i_err ) {
			break;
		}

		switch( i_request ) {

			case STX_SERVICE_REQUEST_CONNECT:
				i_err = on_connect(the,h_xini,h_sync); // media type;
				break;

				//add  other request;
			case STX_SERVICE_REQUEST_DELIVER:
				i_err = on_deliver(the, h_xini,h_sync); // media data header;
				break;

			case STX_SERVICE_REQUEST_CLOSE:
			default:
				i_err = STX_EOF; // destroy protocol;
				break;

		} //switch( i_request ) {

	}while(FALSE);

	if( h_xini ) {
		h_xini->close(h_xini);
	}

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE: 
***************************************************************************/
STX_PRIVATE STX_RESULT 
on_connect(stx_tcp_source* the, stx_xini* h_xini,stx_sync_inf* h_sync)
{
	// if success, set stack status to run proc, then return STX_OK;

	STX_RESULT		i_err;

	u8*				p_hdr;
	s32				i_hdr_size;
	stx_xio*		h_stream;
	size_t			i_write;

	char*			sz_val;

	stx_media_type* p_mtype;

	STX_HANDLE		h_key;

	p_mtype = NULL;
	p_hdr = NULL;

	h_stream = NULL;

	do{
		// media type 

		i_err = h_xini->create_key(h_xini,NULL,g_szStreamX_MajorDataType,NULL,&h_key);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = h_xini->read_binary(h_xini,h_key,&i_hdr_size,NULL);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = h_xini->read_binary(h_xini,h_key,&i_hdr_size,the->major_type.data);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = h_xini->create_key(h_xini,NULL,g_szStreamX_MajorDataTypeName,NULL,&h_key);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = h_xini->read_string(h_xini,h_key,&sz_val);
		if( STX_OK != i_err ) {
			break;
		}
		stx_strcpy(the->major_name,sizeof(the->major_name),sz_val);


		i_err = h_xini->create_key(h_xini,NULL,g_szStreamX_SubDataType,NULL,&h_key);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = h_xini->read_binary(h_xini,h_key,&i_hdr_size,NULL);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = h_xini->read_binary(h_xini,h_key,&i_hdr_size,the->sub_type.data);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = h_xini->create_key(h_xini,NULL,g_szStreamX_SubDataTypeName,NULL,&h_key);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = h_xini->read_string(h_xini,h_key,&sz_val);
		if( STX_OK != i_err ) {
			break;
		}
		stx_strcpy(the->sub_name,sizeof(the->sub_name),sz_val);

		//		
		i_err = h_xini->create_key(h_xini,NULL,g_szStreamX_header,NULL,&h_key);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = h_xini->read_base64(h_xini,h_key,&i_hdr_size,NULL);
		if( STX_OK != i_err ) {
			break;
		}
		p_hdr = (u8*)xmallocz(i_hdr_size);
		if(!p_hdr ) {
			i_err = STX_FAIL;
			break;
		}
		i_err = h_xini->read_base64(h_xini,h_key,&i_hdr_size,p_hdr);
		if( STX_OK != i_err ) {
			break;
		}

		h_stream = XCREATE(stx_io_stream,NULL);
		if( !h_stream ) {
			i_err = STX_FAIL;
			break;
		}

		i_err = h_stream->write(h_stream,p_hdr,i_hdr_size,&i_write);
		if( STX_OK != i_err ) {
			break;
		}

		stx_free(p_hdr);
		p_hdr = NULL;

		if( IS_EQUAL_GID(the->major_type,MEDIATYPE_Video)) {
			i_err = decode_vd2(NULL,&i_hdr_size,h_stream);
			if( STX_OK != i_err ) {
				break;
			}
			p_hdr = (u8*)xmallocz(i_hdr_size);
			if(!p_hdr ) {
				i_err = STX_FAIL;
				break;
			}
			i_err = decode_vd2((STX_VIDEOINFOHEADER2*)p_hdr,&i_hdr_size,h_stream);
			if( STX_OK != i_err ) {
				break;
			}
		}
		else if( IS_EQUAL_GID(the->major_type,MEDIATYPE_Audio) ) {
			i_err = decode_wex(NULL,&i_hdr_size,h_stream);
			if( STX_OK != i_err ) {
				break;
			}
			p_hdr = (u8*)xmallocz(i_hdr_size);
			if(!p_hdr ) {
				i_err = STX_FAIL;
				break;
			}
			i_err = decode_wex((STX_WAVEFORMATEXTENSIBLE*)p_hdr,&i_hdr_size,h_stream);
			if( STX_OK != i_err ) {
				break;
			}
		}
		else {
			i_err = STX_FAIL;
			break;
		}


		// set output pin;
		if( IS_EQUAL_GID(the->major_type,MEDIATYPE_Video) 
			&& IS_EQUAL_GID(the->sub_type,MEDIASUBTYPE_LxVideoFrame)) {

				i_err = init_video_outputpin(the,p_hdr,i_hdr_size);
				if( STX_OK != i_err ) {
					break;
				}
		}
		else {

			i_err = init_outputpin(the,p_hdr,i_hdr_size);
			if( STX_OK != i_err ) {
				break;
			}
		}

		i_err = STX_OK;

	}while(FALSE);

	if( p_hdr ) {
		stx_free(p_hdr);
	}

	SAFE_XDELETE(p_mtype);
	SAFE_CLOSEXIO(h_stream);

	if( STX_OK == i_err ) {
		the->h_input_stream->clear(the->h_input_stream);
		stx_stack_close(the->h_stack);
		the->h_stack = NULL;
		RESET_XENTRY(h_sync,&the->stx_base_filter_vt);
	}

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:stx_lxvidf_alloc_create
***************************************************************************/
STX_PRIVATE STX_RESULT init_video_outputpin(stx_tcp_source* the,u8* p_hdr,s32 i_size)
{
	STX_RESULT					i_err;
	stx_mda_alloc_base_param	prop;
	stx_mem_alloc_base*			palloc;
	stx_media_type*				pmtype;

	i_err = STX_FAIL;
	palloc = NULL;
	pmtype = NULL;

	do{

		stx_output_pin* p;

		p =  XCREATE(output_pin,NULL);
		if( !p ) {
			break;
		}		
		the->p_output_pin = p;
		p->set_parent(p,(stx_base_plugin*)&the->stx_base_filter_vt);

		palloc = XCREATE(vfrm_alloc,NULL);
		if( !palloc ) {
			break;
		}

		prop.i_mda_num = 2;
		prop.i_mda_size = 0;  // check at deliver time;

		i_err = palloc->set_param(palloc,&prop,sizeof(prop));

		if( STX_OK != i_err ) {
			break;
		}

		i_err = p->set_mem_allocator(p,palloc);
		if( STX_OK != i_err ) {
			break;
		}

		// set header, WAVEFORMATEXTENSIBLE;
		pmtype = XCREATE(base_media_type,NULL,NULL);
		if( !pmtype ) {
			i_err = STX_FAIL;
			break;
		}
		pmtype->set_type(pmtype,MEDIATYPE_Video);
		pmtype->set_subtype(pmtype,MEDIASUBTYPE_LxVideoFrame);
		pmtype->set_type_name(pmtype,the->major_name);
		pmtype->set_subtype_name(pmtype,the->sub_name);

		i_err = pmtype->set_header(pmtype,p_hdr,i_size);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = p->set_media_type(p,pmtype);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = STX_OK;

	}while(FALSE);

	SAFE_XDELETE( pmtype);// release
	SAFE_XDELETE( palloc);

	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:stx_lxvidf_alloc_create
***************************************************************************/
STX_PRIVATE STX_RESULT init_outputpin(stx_tcp_source* the,u8* p_hdr,s32 i_size)
{
	STX_RESULT					i_err;
	stx_media_type*				pmtype;

	i_err = STX_FAIL;
	pmtype = NULL;

	do{

		stx_output_pin* p;

		p =  XCREATE(output_pin,NULL);
		if( !p ) {
			break;
		}		
		the->p_output_pin = p;
		p->set_parent(p,(stx_base_plugin*)&the->stx_base_filter_vt);

		// set header, WAVEFORMATEXTENSIBLE;
		pmtype = XCREATE(base_media_type,NULL,NULL);
		if( !pmtype ) {
			i_err = STX_FAIL;
			break;
		}
		pmtype->set_type(pmtype,the->major_type);
		pmtype->set_subtype(pmtype,the->sub_type);
		pmtype->set_type_name(pmtype,the->major_name);
		pmtype->set_subtype_name(pmtype,the->sub_name);

		i_err = pmtype->set_header(pmtype,p_hdr,i_size);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = p->set_media_type(p,pmtype);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = STX_OK;

	}while(FALSE);

	SAFE_XDELETE( pmtype);// release

	return i_err;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT 
on_deliver(stx_tcp_source* the, stx_xini* h_xini,stx_sync_inf* h_sync)
{
	STX_RESULT		i_err;
	STX_HANDLE		h_key;
	s32				i;
	s32				i_data_size;
	s64				dts,pts,dura;
	char			sz_key[STX_DEFAULT_PATH];

	i_err = STX_FAIL;

	do{

		i_err = XCALL(get_media_data,the->p_output_pin,&the->p_mdat,INFINITE);
		if( STX_OK != i_err ) {
			break;
		}

		// get media data header;
		i_err = h_xini->create_key(h_xini,NULL,g_szStreamX_length,NULL,&h_key);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = h_xini->read_int32(h_xini,h_key,&i_data_size);
		if( STX_OK != i_err ) {
			break;
		}

		// dts; pts;
		pts = dts = -1;
		i_err = h_xini->create_key(h_xini,NULL,g_szStreamX_pts,NULL,&h_key);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = h_xini->read_int64(h_xini,h_key,&pts);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = h_xini->create_key(h_xini,NULL,g_szStreamX_dts,NULL,&h_key);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = h_xini->read_int64(h_xini,h_key,&dts);
		if( STX_OK != i_err ) {
			break;
		}
		the->p_mdat->set_time(the->p_mdat,pts,dts);

		// duration;
		i_err = h_xini->create_key(h_xini,NULL,g_szStreamX_duration,NULL,&h_key);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = h_xini->read_int64(h_xini,h_key,&dura);
		if( STX_OK != i_err ) {
			break;
		}
		the->p_mdat->set_duration(the->p_mdat,dura);

		if( IS_EQUAL_GID(MEDIATYPE_Video,the->major_type) 
			&& IS_EQUAL_GID(MEDIASUBTYPE_LxVideoFrame,the->sub_type) ) {

				// width
				i_err = h_xini->create_key(h_xini,NULL,g_szStreamX_width,NULL,&h_key);
				if( STX_OK != i_err ) {
					break;
				}
				i_err = h_xini->read_int32(h_xini,h_key,&the->i_width);
				if( STX_OK != i_err ) {
					break;
				}
				// height
				i_err = h_xini->create_key(h_xini,NULL,g_szStreamX_height,NULL,&h_key);
				if( STX_OK != i_err ) {
					break;
				}
				i_err = h_xini->read_int32(h_xini,h_key,&the->i_height);
				if( STX_OK != i_err ) {
					break;
				}

				// pitch
				for( i = 0; i < 3; i++ ) {

					stx_sprintf(sz_key,sizeof(sz_key),"%s-%d",g_szStreamX_pitch,i);

					i_err = h_xini->create_key(h_xini,NULL,sz_key,NULL,&h_key);
					if( STX_OK != i_err ) {
						break;
					}
					i_err = h_xini->read_int32(h_xini,h_key,&the->i_pitch[i]);
					if( STX_OK != i_err ) {
						break;
					}
				}

				if( STX_OK != i_err ) {
					break;
				}	
				
				
				// if success, compute the data size, and  change status to prefetch data;

				i_data_size = the->i_pitch[0] * the->i_height 
					+ the->i_pitch[1]*the->i_height/2
					+ the->i_pitch[2]*the->i_height/2;



		}
		else {

			i_err = the->p_mdat->resize(the->p_mdat,i_data_size);
			if( STX_OK != i_err ) {
				break;
			}

		}

		i_err = STX_OK;

	}while(FALSE);


	if( STX_OK != i_err ) {

		if( the->p_mdat ) {
			the->p_output_pin->release_media_data(the->p_output_pin,the->p_mdat);
			the->p_mdat = NULL;
		}
	}


	if( STX_OK == i_err ) {
		stx_stack_push(the->h_stack,tcp_src_make_data);
		stx_stack_push(the->h_stack,i_data_size);
		stx_stack_push(the->h_stack,tcp_src_prefetch);
		the->h_input_stream->clear(the->h_input_stream);
		RESET_XENTRY(h_sync,&the->stx_base_filter_vt);
	}

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT 
make_media_data(stx_tcp_source* the ,stx_sync_inf* h_sync)
{
	STX_RESULT		i_err;
	stx_io_op_param param;

	i_err = STX_FAIL;

	do{

		INIT_MEMBER(param);
		i_err = the->h_input_stream->get(the->h_input_stream,STX_IO_READ_P,&param);
		if( STX_OK != i_err ) {
			break;
		}

		if( IS_EQUAL_GID(MEDIATYPE_Video,the->major_type) 
			&& IS_EQUAL_GID(MEDIASUBTYPE_LxVideoFrame,the->sub_type) ) {

				VideoFrame*		p_frame;

				i_err = the->p_mdat->query_interf(the->p_mdat,STX_IID_LxVideoFrame,&p_frame);
				if( STX_OK != i_err ) {
					break;
				}
				SAFE_XDELETE(the->p_mdat);
				i_err = vfrmAjustSurfaceSize(p_frame,the->i_width,the->i_height,CHROMA420);
				if( STX_OK != i_err ) {
					break;
				}

				p_frame->nCodedPictureWidth = the->i_width ;
				p_frame->nCodedPictureHeight = the->i_height;

				// fill the video frame attributes;
				p_frame->PictureCodingType = 1 ; //I_TYPE;
				p_frame->ChromaFormat = CHROMA420;
				p_frame->RepeatDisplayTimes = 0;
				p_frame->dwFmtFourCC = MKTAG('Y','V','1','2');
				p_frame->dwDisplayWhr = 0;
				p_frame->dwNvWhr = 0;
				vfrmSetFlags(p_frame,0);
				vfrmSetDecoded(p_frame,TRUE);    // = TRUE;
				vfrmSetDisplay(p_frame,TRUE);    // bDisplay = 1;

				p_frame->PresentTimeStamp =  REFTIME2PTS(the->p_mdat->get_time(the->p_mdat,NULL));

				//stx_log("video time code = %d\r\n", REFTIME2MILISEC(pframe->PresentTimeStamp) );

				// copy data;
				{
					s32 i;

					u8 *src, *dst;

					src = param.buf;
					dst = p_frame->lpData[0];

					for( i = 0; i < the->i_height; i ++ ) {
						memcpy(dst,src,the->i_width);
						dst += p_frame->nPitch[0];
						src += the->i_pitch[0];
					}
					dst = p_frame->lpData[1];
					for( i = 0; i < the->i_height>>1; i ++ ) {
						memcpy(dst,src,the->i_width>>1);
						dst += p_frame->nPitch[1];
						src += the->i_pitch[1];
					}
					dst = p_frame->lpData[2];
					for( i = 0; i < the->i_height>>1; i ++ ) {
						memcpy(dst,src,the->i_width>>1);
						dst += p_frame->nPitch[2];
						src += the->i_pitch[2];
					}

				}



		}
		else {

			u8*			buf;
			size_t		i_size;

			i_err = the->p_mdat->get_data(the->p_mdat,&buf,&i_size);
			if( STX_OK != i_err ) {
				break;
			}

			memcpy(buf,param.buf,(size_t)param.i_available_data);

			the->p_mdat->set_data(the->p_mdat,buf,(size_t)param.i_available_data);

		}

		i_err = STX_OK;

	}while(FALSE);


	if(STX_OK != i_err ) {
		return i_err;
	}

	// 
	stx_stack_push(the->h_stack,tcp_src_deliver);

	return STX_AGAIN;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT 
deliver_media_data(stx_tcp_source* the, stx_sync_inf* h_sync )
{
	STX_RESULT i_err;

	RESET_XENTRY(h_sync,&the->stx_base_filter_vt);

	i_err = the->p_output_pin->deliver(the->p_output_pin,the->p_mdat,h_sync);

	if( i_err < 0 ) {
		XCALL(release_media_data,the->p_output_pin,the->p_mdat);
		the->p_mdat = NULL;
	}

	if( STX_OK == i_err ) {
		the->p_mdat = NULL;
		stx_stack_push(the->h_stack,tcp_src_get_hdr);
		stx_stack_push(the->h_stack,STX_PROT_HDR_SIZE);
		stx_stack_push(the->h_stack,tcp_src_prefetch);
		the->h_input_stream->clear(the->h_input_stream);
	}

	return i_err;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT run_proc( stx_tcp_source* the, stx_sync_inf* h_sync )
{
	//stx_log("current time = %"PRId64"d;\r\n",stx_get_milisec());

	if( !the->h_stack ) {

		the->h_stack = stx_stack_create();
		if( !the->h_stack ) {
			return STX_FAIL;
		}

		stx_stack_push(the->h_stack,tcp_src_get_hdr);
		stx_stack_push(the->h_stack,STX_PROT_HDR_SIZE);
		stx_stack_push(the->h_stack,tcp_src_prefetch);
		XCALL(clear,the->h_input_stream);

	} // if( !the->h_stack ) {

	return parse_status(the,h_sync);
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_run
( STX_HANDLE h , stx_sync_inf* h_sync )
{
	STX_RESULT		i_err;

	STX_MAP_THE(stx_tcp_source);

	stx_waitfor_mutex(the->h_mutex,INFINITE);

	i_err = run_proc(the,h_sync);

	stx_release_mutex(the->h_mutex);

	return i_err;
}



/* filter */
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_enum_input_pin
(STX_HANDLE h, sint32* i_idx, stx_base_pin** pp_pin )
{
	return 0;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_enum_output_pin
(STX_HANDLE h,sint32* i_idx,stx_base_pin** pp_pin )
{
	STX_MAP_THE(stx_tcp_source);

	if( !i_idx ) {
		return STX_ERR_INVALID_PARAM;
	}

	if( !pp_pin ) {
		*i_idx = 1;
		return STX_OK;
	}

	{
		s32 idx = *i_idx;

		if( idx != 0 ) {
			return STX_ERR_INVALID_PARAM;
		}

		{
			stx_output_pin*p = the->p_output_pin;
			p->add_ref(p);
			*pp_pin = (stx_base_pin *)p;
		}// block

		return STX_OK;
	}// block
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_check_input_media_type
(STX_HANDLE h,stx_media_type* p_mdt)
{
	return STX_ERR_NOT_SUPPORT;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_check_output_media_type
(STX_HANDLE h,stx_media_type* p_mdt)
{
	return STX_ERR_NOT_SUPPORT;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_set_input_media_type
(STX_HANDLE h, stx_media_type* p_media_type )
{
	return STX_ERR_NOT_SUPPORT;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_set_output_media_type
(STX_HANDLE h, stx_media_type* p_media_type )
{
	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_new_segment( STX_HANDLE h)
{
	STX_MAP_THE(stx_tcp_source);

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_flush
(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	STX_MAP_THE(stx_tcp_source);
	return XCALL(flush,the->p_output_pin,i_flag,h_sync);;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_start
(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	STX_MAP_THE(stx_tcp_source);

	return XCALL(start,the->p_output_pin,i_flag,h_sync);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_stop
(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	STX_MAP_THE(stx_tcp_source);
	return XCALL(stop,the->p_output_pin,i_flag,h_sync);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_receive
(
STX_HANDLE			h,
stx_base_pin*		h_pin, // which input pin;
stx_media_data**	pp_mdat, // output media data;
stx_sync_inf*		h_sync
)
{
	return STX_ERR_NOT_SUPPORT;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_deliver
(
STX_HANDLE			h,
stx_base_pin*		h_pin,	// which input pin;
stx_media_data*		p_mdat,	// output media data;
stx_sync_inf*		h_sync 
)
{
	return STX_ERR_NOT_SUPPORT;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_get_property
(STX_HANDLE h,stx_xio* h_xio)
{
	STX_MAP_THE(stx_tcp_source);
	{
		STX_RESULT i_err;
		stx_xini*  h_xini;
		STX_HANDLE h_prop;

		i_err = STX_FAIL;
		h_xini = NULL;


		do{

			i_err = stx_ini_create(NULL,h_xio,STX_INI_READ_WRITE|STX_INI_NO_COMMENT,0,&h_xini);
			if(STX_INI_OK != i_err ) {
				break;
			}

			// push mode;
// 			i_err = h_xini->create_key(h_xini,NULL,g_szStreamX_pushmode,NULL,&h_prop);
// 			if(STX_INI_OK == i_err ) {
// 				i_err = h_xini->write_int32(h_xini,h_prop,the->b_push_mode);
// 				if(STX_OK != i_err ) {
// 					break;
// 				}
// 			}

			// service ip
			i_err = h_xini->create_key(h_xini,NULL,g_sz_ip4,NULL,&h_prop);
			if(STX_INI_OK == i_err ) {
				i_err = h_xini->write_string(h_xini,h_prop,(char*)the->sz_ip);
				if(STX_OK != i_err ) {
					break;
				}
			}

			// service port
			i_err = h_xini->create_key(h_xini,NULL,g_sz_port,NULL,&h_prop);
			if(STX_INI_OK == i_err ) {
				i_err = h_xini->write_int32(h_xini,h_prop,the->i_port);
				if(STX_OK != i_err ) {
					break;
				}
			}

			// graph file;
			i_err = h_xini->create_key(h_xini,NULL,g_sz_GRAPH,NULL,&h_prop);
			if(STX_INI_OK == i_err ) {
				i_err = h_xini->write_string(h_xini,h_prop,the->sz_graph);
				if(STX_OK != i_err ) {
					break;
				}
			}

			i_err = STX_OK;

		}while(FALSE);

		if( h_xini ) {
			h_xini->close(h_xini);
		}

		return i_err;
	}

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_set_property
(STX_HANDLE h,stx_xio* h_xio)
{
	STX_MAP_THE(stx_tcp_source);
	{
		STX_RESULT	i_err;
		stx_xini*	h_xini;
		STX_HANDLE	h_prop;
		s32			i_val;
		char*		sz_val;

		i_err = STX_FAIL;
		h_xini = NULL;


		do{

			i_err = stx_ini_create(NULL,h_xio,STX_INI_READ_ONLY|STX_INI_NO_COMMENT,0,&h_xini);
			if(STX_INI_OK != i_err ) {
				break;
			}

			// push mode;
// 			i_err = h_xini->create_key(h_xini,NULL,g_szStreamX_pushmode,NULL,&h_prop);
// 			if(STX_INI_OK == i_err ) {
// 				i_err = h_xini->read_int32(h_xini,h_prop,&i_val);
// 				if(STX_OK != i_err ) {
// 					break;
// 				}
// 				the->b_push_mode = (b32)i_val;
// 			}

			// service ip
			i_err = h_xini->create_key(h_xini,NULL,g_sz_ip4,NULL,&h_prop);
			if(STX_INI_OK == i_err ) {
				i_err = h_xini->read_string(h_xini,h_prop,&sz_val);
				if(STX_INI_OK != i_err ) {
					break;
				}
				stx_strcpy(the->sz_ip,sizeof(the->sz_ip),sz_val);
			}

			// service port
			i_err = h_xini->create_key(h_xini,NULL,g_sz_port,NULL,&h_prop);
			if(STX_INI_OK == i_err ) {
				i_err = h_xini->read_int32(h_xini,h_prop,&i_val);
				if(STX_OK != i_err ) {
					break;
				}
				the->i_port = (u16)i_val;
			}

			// graph file;
			i_err = h_xini->create_key(h_xini,NULL,g_sz_GRAPH,NULL,&h_prop);
			if(STX_INI_OK == i_err ) {
				i_err = h_xini->read_string(h_xini,h_prop,&sz_val);
				if(STX_INI_OK != i_err ) {
					break;
				}
				if( the->sz_graph ) {
					stx_free(the->sz_graph);
				}
				the->sz_graph = xstrdup(sz_val);
				if( !the->sz_graph) {
					break;
				}
			} // if(STX_INI_OK == i_err ) {

			i_err = STX_OK;

		}while(FALSE);

		if( h_xini ) {
			h_xini->close(h_xini);
		}

		return i_err;
	}
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_send_msg
( STX_HANDLE h, stx_base_message* p_msg )
{
	STX_RESULT	i_err;

	STX_MAP_THE(stx_tcp_source);

	do{
		u32			i_type;
		//s32			i;

		i_err = dispatch_msg(h,p_msg);
		if( i_err < 0 || p_msg->is_msg_closed(p_msg)) {
			break;
		}

		i_type = p_msg->get_msg_type(p_msg);

		if( (i_type & STX_MSG_TYPE_DOWNSTREAM) && the->p_output_pin ) {

			stx_output_pin* p = the->p_output_pin;
			if( p->is_connected(p,NULL) ) {
				i_err = p->send_msg(p,p_msg);
				if( i_err < 0 || p_msg->is_msg_closed(p_msg)) {
					break;
				}
			}
		}
		else if( (i_type & STX_MSG_TYPE_UPSTREAM) && the->p_parent ) {
			stx_base_plugin* h_gph = the->p_parent;
			i_err = h_gph->send_msg(h_gph,p_msg);
		}

		if( i_err < 0 || p_msg->is_msg_closed(p_msg)) {
			break;
		}

		i_err = response_msg(h,p_msg);
		if( i_err < 0 || p_msg->is_msg_closed(p_msg)) {
			break;
		}

		i_err = STX_OK;

	}while(FALSE);

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_media_info_vt_xxx_get_desc
(STX_HANDLE h, sint32* i_len, char** sz_desc )
{
	STX_RESULT i_err;

	STX_MAP_THE(stx_tcp_source);

	i_err = STX_FAIL;


	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_media_info_vt_xxx_get_total_time
(STX_HANDLE h,sint64 *i_time)
{
	STX_MAP_THE(stx_tcp_source);

	*i_time = the->i_file_time;

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_media_info_vt_xxx_get_statistic
(STX_HANDLE h,s32 * i_size,char ** pp_sz )
{
	return STX_ERR_NOT_IMP;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_media_info_vt_xxx_get_current_time
(STX_HANDLE h,sint64 *i_time)
{
	STX_RESULT i_err;

	STX_MAP_THE(stx_tcp_source);

	i_err = STX_FAIL;


	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_media_info_vt_xxx_time_to_pos
(STX_HANDLE h,sint64 i_time,offset_t * pos )
{
	STX_RESULT i_err;

	STX_MAP_THE(stx_tcp_source);

	i_err = STX_FAIL;


	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_media_info_vt_xxx_pos_to_time
(STX_HANDLE h, offset_t pos ,sint64* i_time )
{
	STX_RESULT i_err;

	STX_MAP_THE(stx_tcp_source);

	i_err = STX_FAIL;


	return i_err;
}

/***************************************************************************
STX_MSG_PROC STX_RESULT on_play(STX_HANDLE h, stx_base_message* p_msg )
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT on_play(STX_HANDLE h, stx_base_message* p_msg )
{
	STX_MAP_THE(stx_tcp_source);
	{
	}

	return STX_OK;
}

/***************************************************************************
STX_MSG_PROC STX_RESULT on_stop(STX_HANDLE h,stx_base_message* p_msg )
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT on_stop(STX_HANDLE h,stx_base_message* p_msg)
{	
	STX_MAP_THE(stx_tcp_source);

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_ENTRY STX_RESULT 
at_BreakPin(STX_HANDLE h, stx_base_message* p_msg )
{
	STX_MAP_THE(stx_tcp_source);
	if( the->p_output_pin ) {
		the->p_output_pin->break_connect(the->p_output_pin);
	}

	return STX_OK;
}


/***************************************************************************
STX_MSG_PROC STX_RESULT on_pause(STX_HANDLE h, stx_base_message* p_msg )
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT on_pause(STX_HANDLE h, stx_base_message* p_msg)
{
	STX_MAP_THE(stx_tcp_source);

	return STX_OK;
}

/***************************************************************************
STX_MSG_PROC STX_RESULT on_resume( STX_HANDLE h, stx_base_message* p_msg )
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT on_resume( STX_HANDLE h, stx_base_message* p_msg )
{
	STX_MAP_THE(stx_tcp_source);

	return STX_OK;
}


/***************************************************************************
STX_MSG_PROC STX_RESULT at_play(STX_HANDLE h, stx_base_message* p_msg )
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT at_play(STX_HANDLE h, stx_base_message* p_msg )
{
	STX_MAP_THE(stx_tcp_source);

	// source filter status is not correct ;
	return STX_OK;
}

/***************************************************************************
STX_MSG_PROC STX_RESULT at_stop(STX_HANDLE h,stx_base_message* p_msg)
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT at_stop(STX_HANDLE h,stx_base_message* p_msg )
{
	STX_MAP_THE(stx_tcp_source);

	return STX_OK;
}



/***************************************************************************
STX_MSG_PROC STX_RESULT at_pause(STX_HANDLE h, stx_base_message* p_msg )
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT at_pause(STX_HANDLE h, stx_base_message* p_msg )
{
	STX_MAP_THE(stx_tcp_source);

	// source filter status is not correct ;
	return STX_OK;
}


/***************************************************************************
STX_MSG_PROC STX_RESULT at_resume( STX_HANDLE h, stx_base_message* p_msg )
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT at_resume( STX_HANDLE h, stx_base_message* p_msg )
{
	STX_MAP_THE(stx_tcp_source);

	return STX_OK;
}




/***************************************************************************
RETURN VALUE:
INPUT: 
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT 
on_auto_stop(STX_HANDLE h,stx_base_message* p_msg )
{

	STX_MAP_THE(stx_tcp_source);
	{
		STX_HANDLE h_stack = p_msg->get_stack(p_msg);

		// push plugin interface pointer;
		stx_stack_push(h_stack,(size_t)&the->stx_base_filter_vt);

		return STX_OK;
	}
}




/***************************************************************************
RETURN VALUE:
INPUT: 
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT 
on_app_stop(STX_HANDLE h,stx_base_message* p_msg )
{
	STX_MAP_THE(stx_tcp_source);
	{
		stx_msg_cnt* p_cnt = p_msg->get_msg_cnt(p_msg);

		p_msg->set_msg_close(p_msg);

		// must be as io; send stop message to app handler;
		return stx_base_plugin_stop(
			(stx_base_plugin*)&the->stx_base_filter_vt,
			(STX_RESULT)p_cnt->param.i_param[0],
			FALSE);
	}

}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_get_caps
(STX_HANDLE h,stx_xio* h_xio)
{
	STX_MAP_THE(stx_tcp_source);
	{

		STX_RESULT i_err;
		stx_xini*  h_xini;
		STX_HANDLE h_key;

		i_err = STX_FAIL;
		h_xini = NULL;

		do{

			i_err = stx_ini_create(NULL,h_xio,STX_INI_READ_WRITE|STX_INI_NO_COMMENT,0,&h_xini);
			if(STX_INI_OK != i_err ) {
				break;
			}

			i_err = h_xini->create_key(h_xini,NULL,(char*)g_szCtlCaps_play_stop,(char*)g_szTrue,&h_key);
			if(STX_INI_OK != i_err ) {
				break;
			}

			i_err = h_xini->create_key(h_xini,NULL,(char*)g_szCtlCaps_pause_resume,(char*)g_szTrue,&h_key);
			if(STX_INI_OK != i_err ) {
				break;
			}

			i_err = STX_OK;

		}while(FALSE);

		if( h_xini ) {
			h_xini->close(h_xini);
		}

		return i_err;
	}
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_get_status
(STX_HANDLE h,u32* i_status)
{
	STX_MAP_THE(stx_tcp_source);

	*i_status = the->em_status;

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_play(STX_HANDLE h)
{
	STX_RESULT			i_err;
	stx_base_filter*    pflt;
	size_t*				h_status;
	size_t				i_status;

	STX_MAP_THE(stx_tcp_source);

	pflt = &the->stx_base_filter_vt;

	// should add stp_client open(play) stage;

	if( !the->h_stack ) {

		the->h_stack = stx_stack_create();
		if( !the->h_stack ) {
			return STX_FAIL;
		}

		stx_stack_push(the->h_stack,tcp_src_stp_play);
	}


	h_status = stx_stack_pop(the->h_stack);
	if( !h_status ) { 
		return STX_FAIL;
	}
	i_status = *h_status;

	if( tcp_src_stp_play == i_status ) {

		do{
			i_err = the->h_client->open(the->h_client,NULL,STX_SERVICE_REQUEST_PLAY);
		}while(STX_AGAIN == i_err);

		if( STX_IDLE == i_err || STX_WOUNLD_BLOCK == i_err ) {
			stx_stack_push(the->h_stack,tcp_src_stp_play);
			return STX_WOUNLD_BLOCK;
		}

		stx_stack_close(the->h_stack);
		the->h_stack = NULL;

		if( i_err < 0 ) {
			return i_err;
		}

		// open success; should first quote mediatype from stp_client;
		the->h_input_stream->clear(the->h_input_stream);

	} // tcp_src_stp_play
	else {
		stx_stack_push(the->h_stack,i_status);
	}


	// first send play message;
	{
		stx_base_message*	p_msg;
		stx_msg_cnt*		cnt;


		p_msg = XCREATE(base_msg,NULL,NULL);
		if( !p_msg) {
			return STX_FAIL;
		}

		p_msg->set_msg_type(p_msg,STX_MSG_TYPE_DOWNSTREAM);

		do{

			cnt = p_msg->get_msg_cnt(p_msg);
			cnt->msg_gid = STX_MSG_Play;
			i_err = pflt->send_msg(pflt,p_msg);
			if( i_err < 0 ) {
				break;
			}
			i_err = STX_OK;

		}while(FALSE);

		SAFE_XDELETE(p_msg);

		if( STX_OK != i_err ) {
			return i_err;
		}

	} //

	i_err = the->h_ssrc->reg_task(the->h_ssrc,&the->h_task,(stx_base_plugin*)pflt,TASK_NORMAL);
	if( STX_OK != i_err ) {
		return i_err;
	}

	the->em_status = emStxStatusPlay;
	// active ssrc handle;
	XCALL(reset_task,the->h_ssrc,the->h_task,0,0);

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_pause(STX_HANDLE h)
{
	// first send pause message;
	STX_RESULT			i_err;
	stx_base_filter*    p_flt;

	STX_MAP_THE(stx_tcp_source);

	stx_waitfor_mutex(the->h_mutex,INFINITE);

	do{
		i_err = STX_OK;

		if( emStxStatusPause != the->em_status ){
			the->h_ssrc->set_task_events(the->h_ssrc,the->h_task,ev_pause);
			i_err = STX_WOUNLD_BLOCK;
			break;
		}

		// send pause message;
		{
			stx_base_message*	p_msg;
			stx_msg_cnt*		cnt;

			p_msg= XCREATE(base_msg,NULL,NULL);
			if( !p_msg) {
				i_err = STX_FAIL;
				break;
			}

			p_msg->set_msg_type(p_msg,STX_MSG_TYPE_DOWNSTREAM);

			cnt = p_msg->get_msg_cnt(p_msg);
			cnt->msg_gid = STX_MSG_Pause;
			p_flt = &the->stx_base_filter_vt;
			i_err = p_flt->send_msg(p_flt,p_msg);
			if( i_err < 0 ) {
				break;
			}

			SAFE_XDELETE(p_msg);

			i_err = STX_OK;

		} // block;

	}while(FALSE);

	stx_release_mutex(the->h_mutex);

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_resume(STX_HANDLE h)
{
	// first send pause message;
	STX_RESULT			i_err;
	stx_base_filter*    p_flt;

	STX_MAP_THE(stx_tcp_source);

	stx_waitfor_mutex(the->h_mutex,INFINITE);

	do{

		if( emStxStatusPause != the->em_status ){
			i_err = STX_ERR_OBJ_STATUS;
			break;
		}

		// send resume message;
		{
			stx_base_message*	p_msg;
			stx_msg_cnt*		cnt;

			p_msg= XCREATE(base_msg,NULL,NULL);
			if( !p_msg) {
				return STX_FAIL;
			}

			p_msg->set_msg_type(p_msg,STX_MSG_TYPE_DOWNSTREAM);

			cnt = p_msg->get_msg_cnt(p_msg);
			cnt->msg_gid = STX_MSG_Resume;
			p_flt = &the->stx_base_filter_vt;
			i_err = p_flt->send_msg(p_flt,p_msg);
			if( i_err < 0 ) {
				break;
			}

			SAFE_XDELETE(p_msg);

			i_err = STX_OK;

		} // block;

		the->em_status = emStxStatusPlay;

	}while(FALSE);

	stx_release_mutex(the->h_mutex);

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_set
(STX_HANDLE h,u32 i_flag,size_t i_set)
{
	STX_MAP_THE(stx_tcp_source);
	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT stop_proc( stx_tcp_source* the)
{
	STX_RESULT			i_err;
	stx_base_filter*    p_flt;
	size_t				i_status;
	size_t*				p_status;

	p_flt = &the->stx_base_filter_vt;

	if( !the->h_stop ) {
		the->h_stop = stx_stack_create();
		if( !the->h_stop ) {
			return STX_FAIL;
		}
		XCALL(set_task_events,the->h_ssrc,the->h_task,ev_stop);
		stx_stack_push(the->h_stop,tcp_src_stop);
	} //if( !the->b_stop ) {

	p_status = stx_stack_pop(the->h_stop);
	if( !p_status ) {
		return STX_FAIL;
	}

	i_status = *p_status;

	if( tcp_src_stop == i_status ) {

		if( emStxStatusStop != the->em_status ){
			stx_stack_push(the->h_stop,tcp_src_stop);
			return STX_WOUNLD_BLOCK;
		}

		i_status = tcp_src_stop_pin;

	} // if( tcp_src_stop == i_status ) {

	if( tcp_src_stop_pin == i_status ) {

		stx_sync_inf sync_inf = {0};

		i_err = p_flt->stop(p_flt,0,&sync_inf); //->stx_base_filter_vt_xxx_stop
		if( STX_OK != i_err ) {
			if( STX_WOUNLD_BLOCK == i_err ){
				stx_stack_push(the->h_stop,tcp_src_stop_pin);
			}
			return i_err;
		}

		i_status = tcp_src_stop_io;

	} // if( em_flv_stop_data == i_status ) {


	if( tcp_src_stop_io == i_status ) {

		// check the as io;
		if( the->h_client ) {
			i_err = XCALL(stop,the->h_client);
			if( STX_WOUNLD_BLOCK == i_err ){
				stx_stack_push(the->h_stop,tcp_src_stop_io);
			}
			if( STX_OK != i_err ) {
				return i_err;
			}
		}

	} // if( em_flv_stop_io == i_status ) {


	// unreg ssrc handle;
	XCALL(unreg_task,the->h_ssrc,the->h_task);

	// send stop message;
	{
		stx_base_message*	p_msg;
		stx_msg_cnt*		cnt;

		p_msg= XCREATE(base_msg,NULL,NULL);
		if( !p_msg) {
			return STX_FAIL;
		}

		p_msg->set_msg_type(p_msg,STX_MSG_TYPE_DOWNSTREAM);

		do{
			cnt = p_msg->get_msg_cnt(p_msg);
			cnt->msg_gid = STX_MSG_Stop;
			i_err = p_flt->send_msg(p_flt,p_msg);
			if( i_err < 0 ) {
				break;
			}
			i_err = STX_OK;

		}while(FALSE);

		SAFE_XDELETE(p_msg);

		if( STX_OK != i_err ) {
			return i_err;
		}

	} //

	stx_stack_close(the->h_stack);
	the->h_stack = NULL;

	stx_stack_close(the->h_stop);
	the->h_stop = NULL;

	the->em_status = emStxStatusInit;

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_next(STX_HANDLE h)
{
	STX_RESULT i_err;

	STX_MAP_THE(stx_tcp_source);

	i_err = STX_FAIL;


	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_prev(STX_HANDLE h)
{
	STX_RESULT i_err;

	STX_MAP_THE(stx_tcp_source);

	i_err = STX_FAIL;


	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_step(STX_HANDLE h)
{
	STX_RESULT i_err;

	STX_MAP_THE(stx_tcp_source);

	i_err = STX_FAIL;

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_stop(STX_HANDLE h)
{
	STX_RESULT			i_err;

	STX_MAP_THE(stx_tcp_source);

	stx_waitfor_mutex(the->h_mutex,INFINITE);

	i_err = stop_proc(the);

	stx_release_mutex(the->h_mutex);

	return i_err;
}





/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_base_source_vt_xxx_get_pos(STX_HANDLE h,sint64 *i_pos)
{
	STX_RESULT i_err;

	STX_MAP_THE(stx_tcp_source);

	i_err = STX_FAIL;


	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_source_vt_xxx_get_size(STX_HANDLE h,sint64 *i_size)
{
	STX_RESULT i_err;

	STX_MAP_THE(stx_tcp_source);

	i_err = STX_FAIL;


	return i_err;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_base_source_vt_xxx_set_pos(STX_HANDLE h,sint64 i_pos)
{
	STX_RESULT i_err;

	STX_MAP_THE(stx_tcp_source);

	i_err = STX_FAIL;


	return i_err;
}
