

/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#include "stdio.h"

#include "stdlib.h"

#include "fcntl.h"

#include "malloc.h"

#include "memory.h"

#include "string.h"


#include "stx_os.h"

#include "stx_mem.h"

#include "stx_debug.h"

#include "stx_mutex.h"

#include "stx_semaphore.h"

#include "stx_gid_def.h"


#include "stx_connect_ctx.h"




typedef struct stx_connect_ctx_imp stx_connect_ctx_imp;


struct stx_connect_ctx_imp{

	stx_connect_ctx		ctx;

	int					i_skip_idx;

	int					i_max_skip;

	stx_gid*			p_skip_gid;

	int					i_con_idx;

	int					i_max_con;

	stx_gid*			p_con_gid;

	stx_gid				cls_gid;

	stx_gid				cat_gid;

	char*				sz_cat_desc;

	int					i_pin_num;

	int					i_max_pin;

	stx_gid*			p_md_type;

	stx_gid*			p_md_subtype;

	DECL_TRACE
};


STX_PURE	void		release(STX_HANDLE h);

STX_PURE	STX_RESULT	add_skip_cls_gid( STX_HANDLE h, stx_gid cls_gid );

STX_PURE	STX_RESULT	rem_skip_cls_gid( STX_HANDLE h, stx_gid cls_gid );

STX_PURE	int32_t		get_skip_cls_num( STX_HANDLE h );

STX_PURE	STX_RESULT  get_skip_cls_gid(
	STX_HANDLE h, int i_idx, stx_gid* cls_gid );

STX_PURE	STX_RESULT	add_con_cls_gid( STX_HANDLE h, stx_gid cls_gid );

STX_PURE	STX_RESULT	rem_con_cls_gid( STX_HANDLE h, stx_gid cls_gid );

STX_PURE	int32_t		get_con_cls_num( STX_HANDLE h );

STX_PURE	STX_RESULT  get_con_cls_gid(
	STX_HANDLE h, int i_idx, stx_gid* cls_gid );

STX_PURE	STX_RESULT	set_cur_cls_gid( STX_HANDLE h, stx_gid cls_gid );

STX_PURE	STX_RESULT  get_cur_cls_gid( STX_HANDLE h, stx_gid* cls_gid );

STX_PURE	STX_RESULT	set_cur_cls_pin_num( STX_HANDLE h, int i_pin_num );

STX_PURE	STX_RESULT	set_cur_cls_pin_type( 
	STX_HANDLE h, int i_idx, stx_gid major_gid, stx_gid sub_gid );

STX_PURE	int32_t		get_cur_cls_pin_num( STX_HANDLE h );

STX_PURE	STX_RESULT  get_cur_cls_type(
	STX_HANDLE h, int i_idx, stx_gid* major_gid, stx_gid* sub_gid);


STX_PURE	STX_RESULT	set_cur_cls_cat( STX_HANDLE h, stx_gid cat_gid );

STX_PURE	STX_RESULT	set_cur_cls_desc( STX_HANDLE h, char* sz_desc);

STX_PURE    STX_RESULT  get_cur_cls_cat( STX_HANDLE h, stx_gid* cat_gid );

STX_PURE    char*		get_cur_cls_desc( STX_HANDLE h );


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
stx_connect_ctx* stx_connect_ctx_create()
{

	STX_RESULT			i_err;

	STX_DECLARE_THE(stx_connect_ctx_imp);


	the = STX_NULL;

	i_err = STX_FAIL;


	the = (stx_connect_ctx_imp*)smart_mallocz(sizeof(stx_connect_ctx_imp),
		"stx_connect_ctx.c::stx_connect_ctx_create::the;" );

	if( !the ) {
		goto fail;
	}

	the->ctx.release				= release;
	the->ctx.add_con_cls_gid		= add_con_cls_gid;
	the->ctx.add_skip_cls_gid		= add_skip_cls_gid;
	the->ctx.get_con_cls_gid		= get_con_cls_gid;
	the->ctx.get_con_cls_num		= get_con_cls_num;
	the->ctx.get_cur_cls_gid		= get_cur_cls_gid;
	the->ctx.get_cur_cls_pin_num	= get_cur_cls_pin_num;
	the->ctx.get_cur_cls_type		= get_cur_cls_type;
	the->ctx.get_skip_cls_gid		= get_skip_cls_gid;
	the->ctx.get_skip_cls_num		= get_skip_cls_num;
	the->ctx.get_cur_cls_cat        = get_cur_cls_cat;
	the->ctx.get_cur_cls_desc       = get_cur_cls_desc;
	the->ctx.rem_con_cls_gid		= rem_con_cls_gid;
	the->ctx.rem_skip_cls_gid		= rem_skip_cls_gid;
	the->ctx.set_cur_cls_gid		= set_cur_cls_gid;
	the->ctx.set_cur_cls_pin_num	= set_cur_cls_pin_num;
	the->ctx.set_cur_cls_pin_type	= set_cur_cls_pin_type;
	the->ctx.set_cur_cls_cat        = set_cur_cls_cat;
	the->ctx.set_cur_cls_desc       = set_cur_cls_desc;


	the->i_max_skip = STX_MAX_PLUGINS;
	STX_MAKE_TRACE
	the->p_skip_gid = (stx_gid*)smart_mallocz( sizeof(stx_gid) * the->i_max_skip,
		STX_MAP_TRACE);
	if( !the->p_skip_gid ) {
		goto fail;
	}
	
	the->i_max_con	= STX_MAX_PLUGINS;
	STX_MAKE_TRACE
	the->p_con_gid = (stx_gid*)smart_mallocz( sizeof(stx_gid) * the->i_max_con,
		STX_MAP_TRACE );
	if( !the->p_con_gid ) {
		goto fail;
	}
	
	the->i_max_pin	= STX_MAX_PLUGINS;
	STX_MAKE_TRACE
	the->p_md_type = (stx_gid*)smart_mallocz( sizeof(stx_gid) * the->i_max_pin,
		STX_MAP_TRACE );
	if( !the->p_md_type ) {
		goto fail;
	}
	STX_MAKE_TRACE
	the->p_md_subtype = (stx_gid*)smart_mallocz( sizeof(stx_gid) * the->i_max_pin,
		STX_MAP_TRACE );
	if( !the->p_md_subtype ) {
		goto fail;
	}
	
	i_err = STX_OK;

fail:
	if( STX_OK != i_err ) {
		if( the ) {
			the->ctx.release(the);
		}
		return STX_NULL;
	}

	return (stx_connect_ctx *)the;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE	void		release(STX_HANDLE h)
{
	STX_DIRECT_THE(stx_connect_ctx_imp);

	if( the->p_con_gid ) {
		stx_free( the->p_con_gid );
	}

	if( the->p_skip_gid ) {
		stx_free( the->p_skip_gid );
	}

	if( the->p_md_type ) {
		stx_free( the->p_md_type );
	}

	if( the->p_md_subtype ) {
		stx_free( the->p_md_subtype );
	}

	stx_free( the );
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE	STX_RESULT	add_skip_cls_gid( STX_HANDLE h, stx_gid cls_gid )
{
	STX_RESULT	i_err;

	stx_gid*	p_gid;

	STX_DIRECT_THE(stx_connect_ctx_imp);

	i_err = STX_FAIL;

	p_gid = STX_NULL;

	if( the->i_skip_idx == the->i_max_skip ) {

		the->i_max_skip += STX_MAX_PLUGINS;
		STX_MAKE_TRACE
		p_gid = (stx_gid*)smart_mallocz( sizeof(stx_gid) * the->i_max_skip,
			STX_MAP_TRACE );
		if( !p_gid) {
			goto fail;
		}
		memcpy(p_gid,the->p_skip_gid,sizeof(stx_gid)*the->i_skip_idx);
		stx_free(the->p_skip_gid);
		the->p_skip_gid = p_gid;
	}

	the->p_skip_gid[the->i_skip_idx] = cls_gid;
	the->i_skip_idx ++;

	i_err = STX_OK;

fail:

	if( STX_OK != i_err ) {
		if( p_gid ) {
			stx_free( p_gid );
		}
	}
	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE	STX_RESULT	rem_skip_cls_gid( STX_HANDLE h, stx_gid cls_gid )
{

	STX_RESULT		i_err;

	int				i,j;

	STX_DIRECT_THE(stx_connect_ctx_imp);

	i_err = STX_ERR_FILE_NOT_FOUND;

	for( i = 0; i < the->i_skip_idx ; i ++ ) {
		if( IS_EQUAL_GID(the->p_skip_gid[i],cls_gid) ) {
			for( j = i; j + 1 < the->i_skip_idx; j ++ ) {
				the->p_skip_gid[j].guid = the->p_skip_gid[j+1].guid;
			}
			the->i_skip_idx --;
			i_err = STX_OK;
			break;
		}
	}

	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE	int32_t		get_skip_cls_num( STX_HANDLE h )
{
	STX_DIRECT_THE(stx_connect_ctx_imp);

	return the->i_skip_idx;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE	STX_RESULT  get_skip_cls_gid(
	STX_HANDLE h, int i_idx, stx_gid* cls_gid )
{
	STX_DIRECT_THE(stx_connect_ctx_imp);

	if( i_idx < 0 || i_idx >= the->i_skip_idx ) {

		return STX_ERR_INVALID_PARAM;
	}

	*cls_gid = the->p_skip_gid[i_idx];

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE	STX_RESULT	add_con_cls_gid( STX_HANDLE h, stx_gid cls_gid )
{
	STX_RESULT	i_err;

	stx_gid*	p_gid;

	STX_DIRECT_THE(stx_connect_ctx_imp);

	i_err = STX_FAIL;

	p_gid = STX_NULL;

	if( the->i_con_idx == the->i_max_con ) {

		the->i_max_con += STX_MAX_PLUGINS;
		p_gid = (stx_gid*)smart_mallocz( sizeof(stx_gid) * the->i_max_con,
			"stx_connect_ctx.c::add_con_cls_gid::p_gid;" );
		if( !p_gid) {
			goto fail;
		}
		memcpy(p_gid,the->p_con_gid,sizeof(stx_gid)*the->i_con_idx);
		stx_free(the->p_con_gid);
		the->p_con_gid = p_gid;
	}

	the->p_con_gid[the->i_con_idx] = cls_gid;
	the->i_con_idx ++;

	i_err = STX_OK;

fail:

	if( STX_OK != i_err ) {
		if( p_gid ) {
			stx_free( p_gid );
		}
	}
	return i_err;

}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE	STX_RESULT	rem_con_cls_gid( STX_HANDLE h, stx_gid cls_gid )
{
	STX_RESULT		i_err;

	int				i,j;

	STX_DIRECT_THE(stx_connect_ctx_imp);

	i_err = STX_ERR_FILE_NOT_FOUND;

	for( i = 0; i < the->i_con_idx ; i ++ ) {
		if( IS_EQUAL_GID(the->p_con_gid[i],cls_gid) ) {
			for( j = i; j + 1 < the->i_con_idx; j ++ ) {
				the->p_con_gid[j].guid = the->p_con_gid[j+1].guid;
			}
			the->i_con_idx --;
			i_err = STX_OK;
			break;
		}
	}

	return i_err;

}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE	int32_t		get_con_cls_num( STX_HANDLE h )
{
	STX_DIRECT_THE(stx_connect_ctx_imp);

	return the->i_con_idx;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE	STX_RESULT  get_con_cls_gid(
	STX_HANDLE h, int i_idx, stx_gid* cls_gid )
{
	STX_DIRECT_THE(stx_connect_ctx_imp);

	if( i_idx < 0 || i_idx >= the->i_con_idx ) {

		return STX_ERR_INVALID_PARAM;
	}

	*cls_gid = the->p_con_gid[i_idx];

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE	STX_RESULT	set_cur_cls_gid( STX_HANDLE h, stx_gid cls_gid )
{
	STX_DIRECT_THE(stx_connect_ctx_imp);

	the->cls_gid = cls_gid;

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE	STX_RESULT  get_cur_cls_gid( STX_HANDLE h, stx_gid* cls_gid )
{
	STX_DIRECT_THE(stx_connect_ctx_imp);

	*cls_gid = the->cls_gid;

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE	STX_RESULT	set_cur_cls_pin_num( STX_HANDLE h, int i_pin_num )
{
	STX_DIRECT_THE(stx_connect_ctx_imp);

	while( i_pin_num >= the->i_max_pin ) {

		the->i_max_pin += STX_MAX_PLUGINS;
		stx_free(the->p_md_type);
		STX_MAKE_TRACE
		the->p_md_type = (stx_gid*)smart_mallocz( sizeof(stx_gid) * the->i_max_pin,
			STX_MAP_TRACE );
		if( !the->p_md_type) {
			goto fail;
		}
		stx_free(the->p_md_subtype);
		STX_MAKE_TRACE
		the->p_md_subtype = (stx_gid*)smart_mallocz( sizeof(stx_gid) * the->i_max_pin,
			STX_MAP_TRACE );
		if( !the->p_md_subtype) {
			goto fail;
		}
	}

	the->i_pin_num = i_pin_num;

	return STX_OK;

fail:
	return STX_FAIL;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE	STX_RESULT	set_cur_cls_pin_type( 
	STX_HANDLE h, int i_idx, stx_gid major_gid, stx_gid sub_gid )
{
	STX_DIRECT_THE(stx_connect_ctx_imp);

	if( i_idx < 0 || i_idx >= the->i_pin_num ) {

		return STX_ERR_INVALID_PARAM;
	}

	the->p_md_type[i_idx] = major_gid;
	the->p_md_subtype[i_idx] = sub_gid;

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE	int32_t		get_cur_cls_pin_num( STX_HANDLE h )
{
	STX_DIRECT_THE(stx_connect_ctx_imp);

	return the->i_pin_num;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE	STX_RESULT  get_cur_cls_type(
	STX_HANDLE h, int i_idx, stx_gid* major_gid, stx_gid* sub_gid)
{
	STX_DIRECT_THE(stx_connect_ctx_imp);

	if( i_idx < 0 || i_idx >= the->i_pin_num ) {

		return STX_ERR_INVALID_PARAM;
	}

	*major_gid = the->p_md_type[i_idx];
	*sub_gid = the->p_md_subtype[i_idx];

	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_PURE	STX_RESULT	set_cur_cls_cat( STX_HANDLE h, stx_gid cat_gid )
{
	STX_DIRECT_THE(stx_connect_ctx_imp);

	the->cat_gid = cat_gid;

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE	STX_RESULT	set_cur_cls_desc( STX_HANDLE h, char* sz_desc)
{
	STX_DIRECT_THE(stx_connect_ctx_imp);

	if( the->sz_cat_desc ) {
		stx_free( the->sz_cat_desc );
	}

	the->sz_cat_desc = smart_strdup( sz_desc ,"stx_connect_ctx.c::set_cur_cls_desc::the->sz_cat_desc;" );

	if( !the->sz_cat_desc ) {
		return STX_FAIL;
	}

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE    STX_RESULT  get_cur_cls_cat( STX_HANDLE h, stx_gid* cat_gid )
{
	STX_DIRECT_THE(stx_connect_ctx_imp);

	*cat_gid = the->cat_gid;

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE    char*		get_cur_cls_desc( STX_HANDLE h )
{
	STX_DIRECT_THE(stx_connect_ctx_imp);

	return the->sz_cat_desc;
}
