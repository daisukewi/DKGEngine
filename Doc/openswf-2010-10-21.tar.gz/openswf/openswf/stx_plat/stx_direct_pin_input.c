/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
stx_direct_pin_input.c: implementation of the stx_direct_pin_input interface.
direct pin input, directly pass the media sample to the filter;	
***********************************************************************************/
#include "stdio.h"
#include "stdlib.h"
#include "fcntl.h"
#include "malloc.h"
#include "memory.h"
#include "string.h"

#include "stx_mem.h"
#include "stx_debug.h"
#include "stx_gid_def.h"
#include "stx_module_reg.h"
#include "stx_media_type_base.h"
#include "stx_direct_pin.h"
#include "stx_sync_source.h"

#include "stx_io.h"
#include "stx_io_stream.h"


#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif

#ifdef _MAP_THE	
#undef _MAP_THE	
#endif		
#define _MAP_THE STX_MAP_THE(stx_input_pin)	

#ifdef _DIRECT_THE	
#undef _DIRECT_THE	
#endif	
#define _DIRECT_THE STX_DIRECT_THE(stx_input_pin)	



STX_COM_BEGIN(stx_input_pin);
/**/
/**/STX_PUBLIC(stx_base_pin)
/**/STX_COM_DATA_DEFAULT(stx_base_pin)
/**/
/* other members; */
/**/stx_base_pin*		p_next_pin;
/**/stx_media_data*		p_curr_data;
/**/stx_base_pin*		p_curr_pin;
/**/stx_base_pin*		p_output;
/**/stx_media_type*		p_mtyp;
/**/stx_xio*            h_property;
/**/
STX_COM_END();


STX_COM_FUNC_DECL_DEFAULT(stx_base_pin,stx_base_pin_vt);
STX_COM_FUNCIMP_DEFAULT(stx_input_pin,stx_base_pin,stx_base_pin_vt);


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API_IMP CREATE_STX_COM(stx_base_pin,STX_IID_BasePin,stx_input_pin);


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_COM_MAP_BEGIN(stx_input_pin)
/**/STX_COM_MAP_ITEM(STX_IID_BasePin)
STX_COM_MAP_END()

STX_NEW_BEGIN(stx_input_pin)
{
	STX_SET_THE(stx_base_pin);
	STX_COM_NEW_DEFAULT(stx_base_pin,the->stx_base_pin_vt,stx_base_pin_vt,
		STX_GID_NULL,STX_CATEGORY_BasePin,"StreamX base pin");
}
STX_NEW_END()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_QUERY_BEGIN(stx_input_pin)
{
	STX_COM_QUERY_DEFAULT(stx_base_pin,the->stx_base_pin_vt);
}
STX_QUERY_END()




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_DELETE_BEGIN(stx_input_pin)
{
	SAFE_XDELETE(the->p_mtyp);

	SAFE_CLOSEXIO(the->h_property);

	STX_COM_DELETE_DEFAULT(stx_base_pin);
}
STX_DELETE_END
(
/**/STX_COM_DELETE_BEGIN(stx_base_pin)
/**/,
/**/STX_COM_DELETE_END(stx_base_pin)
)





/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_pin_vt_plug_xxx_send_msg
( THEE h, stx_base_message* p_msg )
{
	STX_RESULT i_err;
	STX_HANDLE h_stack;

	_MAP_THE;

	if( STX_MSG_TYPE_UPSTREAM & XCALL(get_msg_type,p_msg) ) {
		if( !the->p_output ) {
			return STX_OK;
		}

		h_stack = p_msg->get_stack(p_msg);
		if( !h_stack ) {
			i_err = p_msg->set_stack(p_msg);
			if( STX_OK != i_err ) {
				return i_err;
			}
			h_stack = p_msg->get_stack(p_msg);
		}

		stx_stack_push(h_stack,(size_t)h);

		i_err = XCALL(send_msg,the->p_output, p_msg );

		stx_stack_pop(h_stack);

		return i_err;
	}

	if( the->p_parent ){

		h_stack = p_msg->get_stack(p_msg);
		if( !h_stack ) {
			i_err = p_msg->set_stack(p_msg);
			if( STX_OK != i_err ) {
				return i_err;
			}
			h_stack = p_msg->get_stack(p_msg);
		}

		stx_stack_push(h_stack,(size_t)h);

		i_err = XCALL(send_msg,the->p_parent, p_msg );

		stx_stack_pop(h_stack);

		return i_err;
	}

	return STX_OK;

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE b32 stx_base_pin_vt_xxx_is_connected
( THEE h ,stx_base_pin** pp_pin)
{
	_MAP_THE;

	if( the->p_output ) {
        if( pp_pin ) {
			XCALL(add_ref,the->p_output);
			*pp_pin = the->p_output;
        }
		return TRUE;
	}

	return FALSE;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_pin_vt_xxx_connect
(THEE h, stx_base_pin* p_pin)
{
	_MAP_THE;

	if( !p_pin ) {
		return STX_ERR_INVALID_PARAM;
	}

	XCALL(add_ref,p_pin);

	the->p_output = p_pin;

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_pin_vt_xxx_break_connect( THEE h )
{
	_MAP_THE;
	SAFE_XDELETE0(the->p_output);
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE stx_media_type* stx_base_pin_vt_xxx_get_media_type( THEE h )
{
	_MAP_THE;

	if( the->p_mtyp){
		XCALL(add_ref,the->p_mtyp);
	}

	return the->p_mtyp;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_pin_vt_xxx_set_media_type
( THEE h, stx_media_type* p_media_type )
{
	_MAP_THE;

	SAFE_XDELETE0(the->p_mtyp);

	if( !p_media_type ) {
		return STX_OK;
	}//if( !p_media_type ) {

	the->p_mtyp = XCREATE(base_media_type,NULL,p_media_type);
	if( !the->p_mtyp ) {
		return STX_FAIL;
	}//

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE: pull mode use only;
***************************************************************************/
STX_PURE STX_RESULT stx_base_pin_vt_xxx_get_media_data
(STX_HANDLE h,stx_media_data ** pp_mdat,s32 i_wait)
{
	_MAP_THE;

	if( !the->p_output ) {
		return STX_ERR_PIN_NOT_CONNECTED;
	}

	return XCALL(get_media_data,the->p_output,pp_mdat,i_wait);
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE: pull mode use only;
***************************************************************************/
STX_PURE STX_RESULT stx_base_pin_vt_xxx_release_media_data
( STX_HANDLE h, stx_media_data* p_mdat )
{
	_MAP_THE;

	if( !the->p_output ) {
		return STX_ERR_PIN_NOT_CONNECTED;
	}

	// test XCALL;
	return XCALL(release_media_data,the->p_output,p_mdat);
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_pin_vt_xxx_deliver
( THEE h, stx_media_data* p_mdat,stx_sync_inf* h_sync)
{
	_MAP_THE;

	if( !the->p_flt ) {
		return STX_ERR_OBJ_UNINIT;
	}

	return XCALL(deliver,the->p_flt,&the->stx_base_pin_vt,p_mdat,h_sync);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_pin_vt_plug_xxx_flush
(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	_MAP_THE;

	return XCALL(flush,the->p_flt,i_flag,h_sync);
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT	stx_base_pin_vt_plug_xxx_stop
(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	_MAP_THE;

	if( the->p_flt ){
		return XCALL(stop,the->p_flt,i_flag,h_sync);
	}

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT	stx_base_pin_vt_plug_xxx_start
(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	_MAP_THE;

	if( the->p_flt ){
		return XCALL(start,the->p_flt,i_flag,h_sync);
	}

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE: pull mode use only; 
**************************************************************************/
STX_PURE STX_RESULT stx_base_pin_vt_xxx_receive
(THEE h, stx_media_data** pp_mdat,stx_sync_inf* h_sync)
{
	_MAP_THE;

	if( !the->p_output ) {
		return STX_ERR_PIN_NOT_CONNECTED;
	}

	return XCALL(receive,the->p_output,pp_mdat,h_sync);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE: NOT USED
**************************************************************************/
STX_PURE STX_RESULT stx_base_pin_vt_plug_xxx_run
(STX_HANDLE h,stx_sync_inf* h_sync)
{
	_MAP_THE;
	return STX_ERR_NOT_SUPPORT;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_pin_vt_plug_xxx_get_property
(STX_HANDLE h,stx_xio* h_xio)
{
	_MAP_THE;
	{
		STX_RESULT		i_err;

		stx_io_op_param	inf;
		size_t          i_size;
		size_t			i_write;

		if( !the->h_property ) {
			return STX_ERR_FILE_NOT_FOUND;
		}

		i_size = (size_t)XCALL(size,the->h_property);

		i_err = XCALL(get,the->h_property,STX_IO_READ_P,&inf);
		if( STX_OK != i_err ){
			return i_err;
		}

		return XCALL(write,h_xio,inf.buf,i_size,&i_write);

	}// block

	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_pin_vt_plug_xxx_set_property
(STX_HANDLE h,stx_xio* h_xio)
{
	_MAP_THE;
	{

		STX_RESULT		i_err;
		stx_io_op_param	inf;
		size_t          i_size;
		size_t			i_write;

		if( !the->h_property) {
			the->h_property = XCREATE(stx_io_stream,NULL);
			if( !the->h_property ) {
				return STX_FAIL;
			}
		}

		i_size = (size_t) h_xio->size(h_xio);

		i_err = XCALL(get,h_xio,STX_IO_READ_P,&inf);

		if( STX_OK != i_err ){
			return STX_FAIL;
		}

		XCALL(clear,the->h_property);
		XCALL(write,the->h_property,inf.buf,i_size,&i_write);

		return STX_OK;
	}

	return STX_ERR_NOT_SUPPORT;
}