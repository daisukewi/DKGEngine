/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/
#include "stdio.h"
#include "stdlib.h"
#include "fcntl.h"
#include "malloc.h"
#include "memory.h"
#include "string.h"

#include "base_canvas.h"

#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif

enum base_canvas_status{
	em_first_open,
	em_open_stream,
	em_confirm_connection,
	em_start_graph,
	em_run_graph,
	em_run_graph_play,
};



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

base_canvas* canvas_create
(
	base_canvas				*the,
	HWND					hwnd,
	stx_base_plugin			*h_parent,
	stx_base_graph_builder	*gbd
)
{
	if( !the ) {
		the = (base_canvas*)xmallocz(sizeof(base_canvas) );
		if( !the ) {
			return NULL;
		}
	}
	else{
		the->m_the = the;
	}

	the->m_hParent = h_parent;
	the->m_hWnd = hwnd;
	the->m_hGbd = gbd;

	the->m_szFileName = NULL;
	the->m_hGph = NULL;
	the->m_hCtl = NULL;
	the->m_icaps = 0;

	the->m_iMaxGrades = 0;
	the->m_iGrades = 0;
	the->m_hhGrade = NULL;

	the->m_iAllConnectTions = 0;
	the->m_iMaxConnectTions = 0;
	the->m_ppConnectRect = NULL;

	INIT_MEMBER(the->m_lastPoint);
	INIT_MEMBER(the->m_start_point);
	INIT_MEMBER(the->m_end_point);
	INIT_MEMBER(the->m_clip);

	// default position;
	SetRect(&the->m_pos,
		CANVAS_LEFT,
		CANVAS_TOP,
		CANVAS_LEFT + CANVAS_MIN_WIDTH,
		CANVAS_TOP + CANVAS_MIN_HEIGHT);

	UPDATE_RESIZE;
	UPDATE_DUSTBIN;
	UPDATE_VIEW;

	the->m_bDrag = FALSE;
	the->m_bResize = FALSE;
	the->m_bDrawConnection = FALSE;

	the->m_dwColorKey = 0x131313;

	the->m_hStack = NULL;
	the->m_hSrc = NULL;

	return the;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void canvas_close(base_canvas*the)
{

	s32 i;

	if( the->m_hStack) {
		stx_stack_close(the->m_hStack);
		the->m_hStack = NULL;
	}

	SAFE_XDELETE0(the->m_hCtl);
	SAFE_XDELETE0(the->m_hSrc);

	// break connections;
	canvas_break_connections(the);

	if( the->m_ppConnectRect ) {
		for( i = 0; i < the->m_iAllConnectTions; i ++ ) {
			if( the->m_ppConnectRect[i] ) {
				stx_free(the->m_ppConnectRect[i]);
			}
		}
		stx_free(the->m_ppConnectRect);
	}

	if( the->m_szFileName ) {
		stx_free (the->m_szFileName);
	}

	canvas_remove_all_grade(the);

	if( the->m_hGph ) {
		the->m_hGbd->detach_graph(the->m_hGbd,the->m_hGph);
		XDELETE(the->m_hGph);
	}

	if( !the->m_the ) {
		stx_free(the);
	}

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void canvas_release_grade( stx_grade* g )
{
	s32 j;

	if( g->ppFilterWnd ) {

		for( j = 0; j < g->i_filter; j ++ ) {

			base_flt_wnd* flt = g->ppFilterWnd[j];
			if( flt) {
				fw_close(flt);
			}//if( g->ppFilterWnd[j] ) {

		}//for( j = 0; j < g->i_filter; j ++ ) {

		stx_free(g->ppFilterWnd);

	}//if( g->ppFilterWnd ) {

	stx_free(g);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void canvas_remove_all_grade(base_canvas* the)
{
	s32 i;
	// close all grade/filters;

	if( the->m_hhGrade ) {
		for( i = 0; i < the->m_iGrades; i ++ ) {
			stx_grade* g = the->m_hhGrade[i];
			if( g ) {
				canvas_release_grade(g);
			}//if( g ) {
		}//for( i = 0; i < m_iGrades; i ++ ) {
		stx_free(the->m_hhGrade);
		the->m_hhGrade = NULL;
		the->m_iGrades = 0;
	}//if( m_hhGrade ) {
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT	canvas_initialize(base_canvas* the,char* sz_file,stx_xio* h_xio)
{
	// load graph;

	STX_RESULT	i_err;

	stx_xini*	h_cfg;

	STX_HANDLE  h_pos;
	STX_HANDLE  h_grade;
	STX_HANDLE  h_grade_item;
	STX_HANDLE  h_flt;

	STX_HANDLE  h_connections;
	STX_HANDLE  h_subcon;
	STX_HANDLE  h_param;

	s32         i,j;


	i_err = STX_FAIL;
	h_cfg = STX_NULL;

	do{
		u32 flag;

		if( !h_xio ) {

			if( !sz_file) {   // create new graph;
				return canvas_initialize_default(the);
			}

			flag = STX_INI_READ_ONLY|STX_INI_NO_COMMENT;
			i_err = stx_ini_create(sz_file,STX_NULL,flag,0,&h_cfg);
			if( STX_INI_OK != i_err ) {
				if( STX_ERR_FILE_NOT_FOUND == i_err ){
					flag = STX_INI_CREATE_NEW|STX_INI_NO_COMMENT;
					i_err = stx_ini_create(sz_file,STX_NULL,flag,0,&h_cfg);
					if( STX_INI_OK != i_err ) {
						break;
					}
				}
				else{
					break;
				}			
			}
		}
		else {
			flag = STX_INI_READ_ONLY|STX_INI_NO_COMMENT;
			i_err = stx_ini_create(STX_NULL,h_xio,flag,0,&h_cfg);
			if( STX_INI_OK != i_err ) {
				break;
			}
		}

		// position;
		i_err = h_cfg->create_key(h_cfg,STX_NULL,g_szCanvasPos,NULL,&h_pos);
		if( STX_INI_OK != i_err ) {
			break;
		}
		{
			size_t i_val[4];
			i_err = h_cfg->read_array(h_cfg,h_pos,4,i_val);
			if( STX_INI_OK != i_err ) {
				break;
			}
			SetRect(&the->m_pos,(s32)i_val[0],(s32)i_val[1],(s32)i_val[2],(s32)i_val[3]);
		}
		UPDATE_RESIZE;
		UPDATE_DUSTBIN;	
		UPDATE_VIEW;

		// create graph;
		i_err  = the->m_hGbd->create_graph(the->m_hGbd,&the->m_hGph);
		if( STX_OK != i_err ) {
			break;
		}
		the->m_hGph->set_parent(the->m_hGph,the->m_hParent);

		// Grades;
		i_err = h_cfg->create_key(h_cfg,STX_NULL,g_szAllGrades,"0",&h_grade);
		if( STX_INI_OK != i_err ) {
			break;
		}
		i_err = h_cfg->read_int32(h_cfg,h_grade,&the->m_iGrades);
		if( STX_INI_OK != i_err ) {
			break;
		}

		if( the->m_iGrades ) {

			the->m_hhGrade = (stx_grade**)xmallocz(sizeof(stx_grade*)*the->m_iGrades);
			if( !the->m_hhGrade ) {
				i_err = STX_FAIL;
				break;
			}
			the->m_iMaxGrades = the->m_iGrades;

			for( i = 0; i < the->m_iGrades; i ++ ) {

				stx_grade*	g;
				char		sz_grade[2048];

				the->m_hhGrade[i] = (stx_grade*)xmallocz(sizeof(stx_grade));
				if( !the->m_hhGrade[i] ) {
					i_err = STX_FAIL;
					break;
				}
				the->m_hhGrade[i]->i_grade = i;

				g = the->m_hhGrade[i];

				// all
				stx_sprintf(sz_grade,sizeof(sz_grade),"%s-%d",g_szAllGrades,i);
				i_err = h_cfg->create_key(h_cfg,h_grade,sz_grade,"0",&h_grade_item);
				if( STX_INI_OK != i_err ) {
					break;
				}
				i_err = h_cfg->read_int32(h_cfg,h_grade_item,&g->i_filter);
				if( STX_INI_OK != i_err ) {
					break;
				}

				if( g->i_filter ) {

					g->i_max_filter = g->i_filter;

					g->ppFilterWnd = (base_flt_wnd**)xmallocz(sizeof(base_flt_wnd*)*g->i_filter);
					if( !g->ppFilterWnd ) {
						i_err = STX_FAIL;
						break;
					}


					for( j = 0; j < g->i_filter; j ++ ) {

						base_flt_wnd* f;
						char sz_key[2048];

						// create filter window;
						g->ppFilterWnd[j] = fw_create(the->m_hWnd,the->m_hGbd);
						if( !g->ppFilterWnd[j] ) {
							i_err = STX_FAIL;
							break;
						}

						f = g->ppFilterWnd[j];

						// set i_grade, index, etc;
						fw_set_grade(f,i);
						fw_set_zorder(f,j);

						stx_sprintf(sz_key,sizeof(sz_key),"%s-%d",g_szAllFilters,j);
						i_err = h_cfg->create_key(h_cfg,h_grade_item,sz_key,NULL,&h_flt);
						if( STX_INI_OK != i_err ) {
							break;
						}

						i_err = fw_initialize(f,h_cfg,h_flt);
						if( STX_OK != i_err ) {
							break;
						}

						i_err = the->m_hGph->add_plugin( the->m_hGph,(stx_base_plugin*)fw_get_filter(f) );
						if( STX_OK != i_err ) {
							break;
						}

					} // for( j = 0; j < m_hhGrade[i]->i_filter; j ++ ) {

					if( STX_OK != i_err ) {
						break;
					}

				} // if( the->m_iAllFilter ) {

			} // for( i = 0; i < the->m_iGrades; i ++ ) {

			if( STX_OK != i_err ) {
				break;
			}

		} // if( the->m_iGrades ) {

		// all connections;
		i_err = h_cfg->create_key(h_cfg,STX_NULL,g_szAllConnectTions,NULL,&h_connections);
		if( STX_INI_OK != i_err ) {
			i_err = STX_OK; // no connections, ignore it;
			break;
		}
		i_err = h_cfg->get_sub_key_num(h_cfg,h_connections,&the->m_iAllConnectTions);
		if( STX_INI_OK != i_err ) {
			break;
		}

		if( the->m_iAllConnectTions ) {

			s32 k = 0;

			the->m_iMaxConnectTions = the->m_iAllConnectTions;

			the->m_ppConnectRect = (stx_connection**)xmallocz(
				sizeof(stx_connection*)*the->m_iAllConnectTions);
			if( !the->m_ppConnectRect ) {
				i_err = STX_FAIL;
				break;
			}

			for( i = 0; i < the->m_iAllConnectTions; i ++ ) {

				the->m_ppConnectRect[i-k] = (stx_connection*)xmallocz(sizeof(stx_connection));
				if( !the->m_ppConnectRect[i-k]) {
					i_err = STX_FAIL;
					break;
				}
				the->m_ppConnectRect[i-k]->start_pos.b_start = TRUE;
				the->m_ppConnectRect[i-k]->end_pos.b_start = FALSE;

				i_err = h_cfg->get_sub_key(h_cfg,h_connections,i,&h_subcon);
				if( STX_INI_OK != i_err ) {
					break;
				}

				// start pin;
				i_err = h_cfg->create_key(h_cfg,h_subcon,g_szStartPin,NULL,&h_param);
				if( STX_INI_OK != i_err ) {
					break;
				}
				i_err = canvas_initialize_connection_point(the,h_cfg,h_param,&the->m_ppConnectRect[i-k]->start_pos);
				if( STX_OK != i_err ) {
					stx_free(the->m_ppConnectRect[i-k]);
					the->m_ppConnectRect[i-k] = NULL;
					k ++;
					i_err = STX_OK;
					continue;
				}

				// end pin;
				i_err = h_cfg->create_key(h_cfg,h_subcon,g_szEndPin,NULL,&h_param);
				if( STX_INI_OK != i_err ) {
					break;
				}
				i_err = canvas_initialize_connection_point(the,h_cfg,h_param,&the->m_ppConnectRect[i-k]->end_pos);
				if( STX_OK != i_err ) {
					stx_free(the->m_ppConnectRect[i-k]);
					the->m_ppConnectRect[i-k] = NULL;
					k ++;
					i_err = STX_OK;
					continue;
				}

			} // for( i = 0; i < the->m_iAllConnectTions; i ++ ) {

			if( STX_OK != i_err ) {
				break;
			}

			the->m_iAllConnectTions -= k;

		} // if( the->m_iAllConnectTions ) {

		i_err = STX_OK;

	}while(FALSE);


	if( h_cfg ) {
		h_cfg->close(h_cfg);
	}

	if( STX_OK == i_err && sz_file ) {
		the->m_szFileName = xstrdup(sz_file);
		if( !the->m_szFileName ) {
			return STX_FAIL;
		}
	}

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT	canvas_serialize(base_canvas* the,char* sz_file,stx_xio* h_xio)
{

	if( !h_xio ){

		if( !sz_file ) {
			// input a name;
			if( !the->m_szFileName ) {
				return STX_RET_SAVE;
			}//
			sz_file = the->m_szFileName;
		}//if( !sz_file ) {
		else{

			b32 b_dup = FALSE;

			if( the->m_szFileName ) {
				if( strcmp(sz_file,the->m_szFileName) ) {
					stx_free(the->m_szFileName );
					b_dup = TRUE;
				}
			}
			else{
				b_dup = TRUE;
			}

			if(b_dup){
				the->m_szFileName = xstrdup(sz_file);
				if( !the->m_szFileName ){
					return STX_FAIL;
				}
			}
		}

	} // if( !h_xio ){

	{

		// if file exist , 
		STX_RESULT	i_err;
		stx_xini*	h_cfg;
		u32			flag;
		STX_HANDLE  h_pos;
		STX_HANDLE  h_grade;
		STX_HANDLE  h_grade_item;
		STX_HANDLE  h_flt;
		STX_HANDLE  h_connections;
		STX_HANDLE  h_subcon;
		STX_HANDLE  h_param;
		s32         i,j;
		char*       sz_gid;
		char*       sz_tmp_file;
		stx_gid     tmp_gid;
		char		sz_tmp_gid[64];
		char		szDriver[STX_DEFAULT_PATH] = { 0 } ;
		char		szPath[STX_DEFAULT_PATH]= { 0 } ;
		char		szName[STX_DEFAULT_PATH]= { 0 } ;
		char		szExt[STX_DEFAULT_PATH] = { 0 };

		i_err = STX_FAIL;
		sz_gid = NULL;
		sz_tmp_file = NULL;

		h_cfg = NULL;

		do{
			if( !h_xio ) {

				flag = STX_INI_READ_ONLY|STX_INI_NO_COMMENT;
				i_err = stx_ini_create(sz_file,STX_NULL,flag,0,&h_cfg);

				if( STX_OK == i_err ) {

					h_cfg->close(h_cfg);
					h_cfg = NULL;

					i = (s32)( strlen(sz_file) + binary_to_string_size(sizeof(stx_gid)) );

					sz_tmp_file = (char*)xmallocz(i);
					if( !sz_tmp_file ) {
						break;
					}

					tmp_gid = stx_gid_create();
					binary_to_string(sizeof(stx_gid),(u8*)&tmp_gid,sz_tmp_gid);

					stx_splitpath( 
						sz_file, 
						szDriver,
						STX_DEFAULT_PATH,
						szPath,
						STX_DEFAULT_PATH,
						szName, 
						STX_DEFAULT_PATH,
						szExt,
						STX_DEFAULT_PATH );

					stx_sprintf(sz_tmp_file,i,"%s%s%s%s",szDriver,szPath,(char*)sz_tmp_gid,".gph");

					flag = STX_INI_CREATE_NEW|STX_INI_NO_COMMENT;
					i_err = stx_ini_create(sz_tmp_file,STX_NULL,flag,0,&h_cfg);
					if( STX_OK != i_err ) {
						break;
					}
				}
				else{
					if( STX_ERR_FILE_NOT_FOUND == i_err ) {
						flag = STX_INI_CREATE_NEW|STX_INI_NO_COMMENT;
						i_err = stx_ini_create(sz_file,STX_NULL,flag,0,&h_cfg);
						if( STX_OK != i_err ) {
							break;
						}
					}
					else {
						break;
					}
				}
			}
			else {
				flag = STX_INI_READ_WRITE|STX_INI_NO_COMMENT;
				i_err = stx_ini_create(NULL,h_xio,flag,0,&h_cfg);
				if( STX_OK != i_err ) {
					break;
				}
			}


			// position;
			i_err = h_cfg->create_key(h_cfg,STX_NULL,g_szCanvasPos,NULL,&h_pos);
			if( STX_INI_OK != i_err ) {
				break;
			}
			{
				size_t i_val[4] = {the->m_pos.left,the->m_pos.top,the->m_pos.right,the->m_pos.bottom};
				i_err = h_cfg->write_array(h_cfg,h_pos,4,i_val);
				if( STX_INI_OK != i_err ) {
					break;
				}
			}

			if( the->m_iGrades ) {

				// Grades;
				i_err = h_cfg->create_key(h_cfg,STX_NULL,g_szAllGrades,"0",&h_grade);
				if( STX_INI_OK != i_err ) {
					break;
				}
				i_err = h_cfg->write_int32(h_cfg,h_grade,the->m_iGrades);
				if( STX_INI_OK != i_err ) {
					break;
				}

				for( i = 0; i < the->m_iGrades; i ++ ) {

					char		sz_grade[2048];
					stx_grade*	g = the->m_hhGrade[i];

					stx_sprintf(sz_grade,sizeof(sz_grade),"%s-%d",g_szAllGrades,i);

					i_err = h_cfg->create_key(h_cfg,h_grade,sz_grade,"0",&h_grade_item);
					if( STX_INI_OK != i_err ) {
						break;
					}
					i_err = h_cfg->write_int32(h_cfg,h_grade_item,g->i_filter);
					if( STX_INI_OK != i_err ) {
						break;
					}

					// all filters;
					for( j = 0; j < g->i_filter; j ++ ) {

						char sz_key[2048];
						stx_sprintf(sz_key,sizeof(sz_key),"%s-%d",g_szAllFilters,j);
						i_err = h_cfg->create_key(h_cfg,h_grade_item,sz_key,g_szAllFilters,&h_flt);
						if( STX_INI_OK != i_err ) {
							break;
						}

						i_err = fw_serialize(g->ppFilterWnd[j],h_cfg,h_flt);
						if( STX_OK != i_err ) {
							break;
						}

					} // for( j = 0; j < g->i_filter; j ++ ) {

					if( STX_OK != i_err ) {
						break;
					}

				} // for( i = 0; i < m_iGrades; i ++ ) {

				if( STX_OK != i_err ) {
					break;
				}

			} // if( m_iGrades ) {

			// h_grade:			Grades = m_iGrades; 
			// h_grade_item:		Grades-0 = g->i_filter;
			// h_flt:				    Filters-0
			//								filter wnd init/save;


			// all connections;
			i_err = h_cfg->create_key(h_cfg,STX_NULL,g_szAllConnectTions,"0",&h_connections);
			if( STX_INI_OK != i_err ) {
				break;
			}
			i_err = h_cfg->write_int32(h_cfg,h_connections,the->m_iAllConnectTions);
			if( STX_INI_OK != i_err ) {
				break;
			}

			for( i = 0; i < the->m_iAllConnectTions; i ++ ) {

				if( the->m_ppConnectRect[i] ) {

					char sz_key[2048];
					stx_sprintf(sz_key,sizeof(sz_key),"%s-%d",g_szConnectTion,i);
					i_err = h_cfg->create_key(h_cfg,h_connections,sz_key,"0",&h_subcon);
					if( STX_INI_OK != i_err ) {
						break;
					}

					// start pin;
					i_err = h_cfg->create_key(h_cfg,h_subcon,g_szStartPin,NULL,&h_param);
					if( STX_INI_OK != i_err ) {
						break;
					}
					i_err = canvas_serialize_connection_point(the,
						h_cfg,h_param,&the->m_ppConnectRect[i]->start_pos);
					if( STX_OK != i_err ) {
						break;
					}

					// end pin;
					i_err = h_cfg->create_key(h_cfg,h_subcon,g_szEndPin,NULL,&h_param);
					if( STX_INI_OK != i_err ) {
						break;
					}
					i_err = canvas_serialize_connection_point(the,
						h_cfg,h_param,&the->m_ppConnectRect[i]->end_pos);
					if( STX_OK != i_err ) {
						break;
					}

				} // if( the->m_ppConnectRect[i] ) {

			} // for( i = 0; i < the->m_iAllConnectTions; i ++ ) {


			if( STX_OK != i_err ) {
				break;
			}

			i_err = STX_OK;

		}while(FALSE);

		if( sz_gid ) {
			stx_gid_close_string(&sz_gid);
		}

		if( h_cfg ) {
			h_cfg->close(h_cfg);
		}

		if( STX_OK == i_err  && sz_tmp_file ) {
			stx_fcopy(sz_tmp_file,sz_file,FALSE);
		}

		if( sz_tmp_file ) {
			remove(sz_tmp_file);
			stx_free(sz_tmp_file);
		}

		return i_err;
	
	}

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT	canvas_OnAddFilter(base_canvas* the,stx_gid clsid,char* sz_dll)
{
	STX_RESULT			i_err;
	stx_base_com*		p;
	base_flt_wnd*       fltwnd;

	i_err = STX_FAIL;
	p = NULL;
	fltwnd = NULL;

	do{
		if( sz_dll ) { // load filter from dll;
			i_err = the->m_hGbd->co_create_obj_svr(the->m_hGbd,clsid,sz_dll,&p);
		}//if( sz_dll ) {
		else {
			i_err = the->m_hGbd->co_create_obj(the->m_hGbd,clsid,&p);
		}
		if( STX_OK != i_err ) {
			break;
		}


		{
			stx_base_plugin* plug = NULL;
			i_err = p->query_interf(p,STX_IID_BasePlugin,(void**)&plug);
			if( STX_OK != i_err ) {
				break;
			}
			i_err = the->m_hGph->add_plugin(the->m_hGph,plug);
			SAFE_XDELETE(plug);
			if( STX_OK != i_err ) {
				break;
			}
		}

		// create new filter wnd;
		fltwnd = fw_create(the->m_hWnd,the->m_hGbd);
		if( !fltwnd ) {
			i_err = STX_FAIL;
			break;
		}

		i_err = canvas_initialize_fltwnd(the,fltwnd,p);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = STX_OK;

	}while(FALSE);

	SAFE_XDELETE(p);

	if( STX_OK != i_err ) {
		if( fltwnd ) {
			fw_close(fltwnd);
		}
	}

	return i_err;

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT	canvas_OnRendStream(base_canvas* the,char* sz_url)
{
	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT	canvas_OnCloseStream(base_canvas* the)
{
	STX_RESULT			i_err;

	size_t				i;
	size_t				i_plugin;
	stx_base_plugin*	p;
	stx_base_source*    psrc;


	i_err = canvas_OnStop(the);
	if( STX_OK != i_err ) {
		return i_err;
	}


	do{

		i_plugin = 0;
		p = NULL;
		psrc = NULL;

		// enum plugins;

		i_err = the->m_hGph->enum_plugin(the->m_hGph,&i_plugin,NULL);
		if( STX_OK != i_err ){
			break;
		}

		if( i_plugin == 0 ) {
			break;
		}


		for( i = 0; i < i_plugin; i ++ ) {

			i_err =  the->m_hGph->enum_plugin(the->m_hGph,&i,&p);
			if( STX_OK != i_err ){
				break;
			}
			i_err = p->query_interf(p,STX_IID_FileSource,(void**)&psrc);
			SAFE_XDELETE(p);
			p = NULL;
			if( STX_OK != i_err ) {
				continue;
			}

			break;

		} // for( i = 0; i < i_plugin; i ++ ) {

		if( STX_OK != i_err ){
			break;
		}

		if( i_plugin == i ) {
			break;
		}

		if( !psrc ) {
			break;
		}

		// source filter close stream;
		psrc->close_stream(psrc);
		
		i_err = canvas_invalid_connections(the);

	}while(FALSE);

	SAFE_XDELETE(p);
	SAFE_XDELETE(psrc);

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT	canvas_OnLoadStream
(base_canvas* the,char* sz_url, stx_sync_inf* h_sync)
{

	STX_RESULT			i_err;
	size_t				i;
	size_t				i_plugin;
	stx_base_plugin*	p;

	size_t*				p_status;
	size_t				i_status;

	p = NULL;

	do{

		if( !the->m_hStack) {

			the->m_hStack = stx_stack_create();
			if( !the->m_hStack) {
				return STX_FAIL;
			}

			i_plugin = 0;
			p = NULL;

			// enum plugins;

			i_err = the->m_hGph->enum_plugin(the->m_hGph,&i_plugin,NULL);
			if( STX_OK != i_err ){
				break;
			}

			if( i_plugin == 0 ) {
				break;
			}


			for( i = 0; i < i_plugin; i ++ ) {

				i_err =  the->m_hGph->enum_plugin(the->m_hGph,&i,&p);
				if( STX_OK != i_err ){
					break;
				}
				i_err = p->query_interf(p,STX_IID_FileSource,(void**)&the->m_hSrc);
				SAFE_XDELETE(p);
				p = NULL;
				if( STX_OK != i_err ) {
					continue;
				}

				break;

			} // for( i = 0; i < i_plugin; i ++ ) {

			if( STX_OK != i_err ){
				break;
			}

			if( i_plugin == i ) {
				break;
			}

			if( !the->m_hSrc ) {
				break;
			}

			i_status = em_open_stream;

		}
		else {
			p_status = stx_stack_pop(the->m_hStack);
			if( !p_status ) {
				i_err = STX_FAIL;
				break;
			}

			i_status = *p_status;
		}


		if( em_open_stream == i_status ) {

			// source filter load stream;
			do{
				i_err = the->m_hSrc->load_stream(the->m_hSrc,sz_url,h_sync);
			}while(STX_AGAIN == i_err );

			if( STX_OK != i_err ) {
				stx_stack_push(the->m_hStack,em_open_stream);
				break;
			}

			i_status = em_confirm_connection;

		} // if( em_open_stream == i_status ) {


		if( em_confirm_connection == i_status ) {

			// confirm connections;
			i_err = canvas_confirm_connections(the);
			if( i_err < 0 ) {
				break;
			}

			i_status = em_start_graph;

			// 
		}


		if( em_start_graph == i_status ){

			// start the file source plugin;
			i_err = the->m_hSrc->query_interf(the->m_hSrc,STX_IID_BasePlugin,(void**)&p);
			if( i_err < 0 ) {
				break;
			}
			SAFE_XDELETE(p);

			i_err = p->start(p,0,h_sync);

			if( STX_OK != i_err ) {
				stx_stack_push(the->m_hStack,em_start_graph);
				break;
			}

			// set all the plugin status to ready;
			i_plugin = 0;
			p = NULL;

			// enum plugins;

			i_err = the->m_hGph->enum_plugin(the->m_hGph,&i_plugin,NULL);
			if( STX_OK != i_err ){
				break;
			}

			if( i_plugin == 0 ) {
				i_err = STX_FAIL;
				break;
			}

			for( i = 0; i < i_plugin; i ++ ) {
				i_err =  the->m_hGph->enum_plugin(the->m_hGph,&i,&p);
				if( STX_OK != i_err ){
					break;
				}
				p->set_status(p,emStxStatusReady);
				SAFE_XDELETE(p);
				p = NULL;
			} // for( i = 0; i < i_plugin; i ++ ) {

			if( STX_OK != i_err ){
				break;
			}

			// initialize control interface;
			i_err = canvas_initialize_control(the);
			if( STX_OK != i_err ){
				break;
			}

			stx_stack_close(the->m_hStack);
			the->m_hStack = NULL;

			i_err = STX_OK;

		} // if( em_confirm_connection == i_status ) {


	}while(FALSE);

	SAFE_XDELETE(p);

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT	canvas_OnRendPin(base_canvas* the)
{
	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT	canvas_OnRendRender(base_canvas* the)
{
	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT	canvas_OnRunGraph(base_canvas* the)
{
	STX_RESULT			i_err;
	size_t*				p_status;
	size_t				i_status;

	if( !the->m_hStack) {

		the->m_hStack = stx_stack_create();
		if( !the->m_hStack) {
			return STX_FAIL;
		}

		canvas_set_color_key(the,the->m_dwColorKey);

		i_status = em_run_graph;
	}
	else{
		p_status = stx_stack_pop(the->m_hStack);
		if( !p_status ) {
			return STX_FAIL;
		}

		i_status = *p_status;

	}

	// only one status;

	do{
		i_err = the->m_hCtl->play(the->m_hCtl);
	}while(STX_AGAIN == i_err);

	if( STX_OK == i_err || i_err < 0 ) {
		stx_stack_close(the->m_hStack);
		the->m_hStack = NULL;
		return i_err;
	}

	stx_stack_push(the->m_hStack,em_run_graph);

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT	canvas_OnPause(base_canvas* the)
{
	return the->m_hCtl->pause(the->m_hCtl);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT	canvas_OnResume(base_canvas* the)
{
	return the->m_hCtl->resume(the->m_hCtl);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT	canvas_OnStop(base_canvas* the)
{
	STX_RESULT	i_err;

	if( !the->m_hCtl ) {
		return STX_FAIL;
	}


	for( ; ; ) {

		do{

			i_err = the->m_hCtl->stop(the->m_hCtl);
		}while(STX_AGAIN == i_err );

		if( i_err < 0 ){
			return i_err;
		}

		if( STX_IDLE == i_err || STX_WOUNLD_BLOCK == i_err ) {
			return i_err;
		}

		if( STX_OK == i_err ) {
			break;
		}

	} // for( ; ; ) {


	SAFE_XDELETE0(the->m_hCtl);

	the->m_icaps = 0;

	return i_err;

}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT canvas_on_auto_stop(base_canvas* the,stx_base_message* p_msg)
{
	STX_HANDLE h_stack = p_msg->get_stack(p_msg);

	stx_base_plugin* const plug = (stx_base_plugin*)*stx_stack_pop(h_stack);

	// reset msg type;
	p_msg->set_msg_type(p_msg,STX_MSG_TYPE_DOWNSTREAM);

	// reset msg gid;
	p_msg->get_msg_cnt(p_msg)->msg_gid = STX_MSG_AppStop;

	return plug->send_msg(plug,p_msg);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
s32 canvas_get_graph_caps(base_canvas* the)
{
	return the->m_icaps;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
s32 canvas_get_graph_status(base_canvas* the)
{
	u32 i_status;

	if( !the->m_hCtl ) {
		return emStxStatusInit;
	}

	if( STX_OK != the->m_hCtl->get_status(the->m_hCtl,&i_status)) {
		return emStxStatusInit;
	}

	return i_status;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT canvas_initialize_control(base_canvas* the)
{
	STX_RESULT			i_err;
	size_t				i;
	size_t				i_plugin;

	stx_base_plugin*	p;
	stx_base_control*   pctl;


	i_plugin = 0;
	p = NULL;
	i_err = STX_FAIL;


	do{
		// enum plugins; get MediaControl interface;
		i_err = the->m_hGph->enum_plugin(the->m_hGph,&i_plugin,NULL);
		if( STX_OK != i_err ){
			break;
		}

		if( i_plugin == 0 ) {
			break;
		}

		for( i = 0; i < i_plugin; i ++ ) {
			i_err =  the->m_hGph->enum_plugin(the->m_hGph,&i,&p);
			if( STX_OK != i_err ){
				break;
			}
			pctl = NULL;
			i_err = p->query_interf(p,STX_IID_BaseControl,(void**)&pctl);
			if( STX_OK == i_err ) {
				the->m_hCtl = pctl;
				break;
			}
			SAFE_XDELETE(p);
			p = NULL;
		} // for( i = 0; i < i_plugin; i ++ ) {

		if( i == i_plugin ) {
			i_err = STX_FAIL;
		}

	}while(FALSE);

	SAFE_XDELETE(p);

	if( STX_OK != i_err ) {
		return i_err;
	}

	// get play control caps;
	i_err = canvas_get_control_caps(the);
	if( STX_OK != i_err ) {
		return i_err;
	}


	return i_err;

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT canvas_get_control_caps(base_canvas* the)
{
	STX_RESULT	i_err;
	stx_xio*	h_xio;
	stx_xini*	h_xini;
	STX_HANDLE	h_prop;
	char*		sz_val;

	h_xio = NULL;
	h_xini = NULL;
	i_err = STX_FAIL;

	the->m_icaps = 0;

	do{

		h_xio = XCREATE(stx_io_stream,NULL);
		if( !h_xio ) {
			break;
		}

		i_err = the->m_hCtl->get_caps(the->m_hCtl,h_xio);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = stx_ini_create(NULL,h_xio,STX_INI_READ_ONLY | STX_INI_NO_COMMENT,0,&h_xini);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = h_xini->create_key(h_xini,STX_NULL,g_szCtlCaps_play_stop,NULL, &h_prop);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = h_xini->read_string(h_xini,h_prop,&sz_val);
		if( STX_OK != i_err ) {
			break;
		}
		if( !strcmp(sz_val,g_szTrue) ) {
			the->m_icaps |= CTL_CAPS_PLAY_STOP;
		}

		i_err = h_xini->create_key(h_xini,STX_NULL,g_szCtlCaps_pause_resume,NULL, &h_prop);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = h_xini->read_string(h_xini,h_prop,&sz_val);
		if( STX_OK != i_err ) {
			break;
		}
		if( !strcmp(sz_val,g_szTrue) ) {
			the->m_icaps |= CTL_CAPS_PAUSE_RESUME;
		}

		i_err = STX_OK;

	}while(FALSE);

	if( h_xini ){
		h_xini->close(h_xini);
	}

	if( h_xio ) {
		h_xio->close(h_xio);
	}

	return i_err;



}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT canvas_initialize_default(base_canvas* the)
{
	STX_RESULT i_err;

	do{
		i_err  = the->m_hGbd->create_graph(the->m_hGbd,&the->m_hGph);
		if( STX_OK != i_err ) {
			break;
		}

		the->m_hGph->set_parent(the->m_hGph,the->m_hParent);

		i_err  = canvas_add_grade(the);
		if( STX_OK != i_err ) {
			break;
		}

	}while(FALSE);

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT canvas_invalid_connections(base_canvas* the)
{
	s32 i,j;

	// for each fltwnd, release pin;

	for( i = 0 ;i < the->m_iGrades; i ++ ) {
		stx_grade* g = the->m_hhGrade[i];
		for( j = 0; j < g->i_filter; j ++ ) {
			if(g->ppFilterWnd[j]) {
				fw_ReleasePinWndPin(g->ppFilterWnd[j]);
			}
		}
	}

	// for each connections, set invalid;
	for( i = 0; i < the->m_iAllConnectTions; i ++ ) {
		the->m_ppConnectRect[i]->b_valid = FALSE;
	}

	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT canvas_confirm_connections(base_canvas* the)
{
	STX_RESULT			i_err;
	s32					i,j;
	stx_grade*			g;
	base_flt_wnd*		f;
	stx_base_filter*	h_filter;
	stx_base_source*	h_src;

	// from source filter
	h_src = NULL;

	for( i = 0; i < the->m_iGrades; i ++ ) {
		g = the->m_hhGrade[i];
		for( j = 0; j < g->i_filter; j ++ ) {
			f = g->ppFilterWnd[j];
			h_filter = fw_get_filter(f);
			i_err = h_filter->query_interf(h_filter,STX_IID_FileSource,(void**)&h_src);
			if( STX_OK == i_err ) {
				SAFE_XDELETE(h_src);
				break;
			}
		}
		if( j < g->i_filter ) {
			break;
		}
	}


	if( i == the->m_iGrades ) {
		return STX_FAIL;
	}

	return canvas_confirm_filter_connections(the,f);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT canvas_confirm_filter_connections
(base_canvas* the,base_flt_wnd* fltwnd)
{

	STX_RESULT			i_err;
	s32					i,j,k,m,n;
	stx_gid				cat_gid;
	b32					b_src;
	stx_base_filter*	h_filter;
	s32					i_all_output;
	s32					i_all_major_type;
	s32					i_rended_major_type;
	stx_gid*			p_major_gid;
	b32*				b_rended;
	s32					i_output_pin;

	stx_output_pin*		h_output_pin;
	base_flt_wnd*		h_next_fltwnd;
	stx_base_filter*	h_next_filter;
	s32					i_all_input;
	s32					i_input_pin;

	stx_base_pin*		h_input_pin;
	stx_media_type_inf  minf;
	stx_grade*			g;
	stx_media_type*		h_type;
	stx_connection*		p;

	base_pin_wnd*		input_pwnd;
	output_pin_wnd*     output_pwnd;

	stx_gid				majortype,subtype;

	i_err = STX_FAIL;
	h_filter = NULL;
	h_next_filter = NULL;

	h_output_pin = NULL;
	h_input_pin = NULL;
	p_major_gid = NULL;
	b_rended = NULL;
	h_type = NULL;

	i_all_major_type = 0;
	i_rended_major_type = 0;

	do{

		h_filter = fw_get_filter(fltwnd);

		cat_gid = h_filter->get_catid(h_filter);

		// if is render or writer, end of connections, return STX_EOF;
		if( IS_EQUAL_GID(cat_gid,STX_CATEGORY_FileWriter)){
			i_err = STX_EOF;
			break;
		}
		if( IS_EQUAL_GID(cat_gid,STX_CATEGORY_Render)){
			i_err = STX_EOF;
			break;
		}

		// enum all the output major types;
		i_all_major_type = 0;
		i_err = h_filter->enum_output_media_type(h_filter,&i_all_output,NULL);
		if( STX_OK != i_err ) {
			break;
		}

		// if no  output pins;
		if( !i_all_output ) {  // no output types, stop connection;
			i_err = STX_EOF;
			break;
		}

		b_src = IS_EQUAL_GID(cat_gid,STX_CATEGORY_FileSource);

		p_major_gid = (stx_gid*)xmallocz(sizeof(stx_gid)*i_all_output);
		if( !p_major_gid) {
			i_err = STX_FAIL;
			break;
		}

		b_rended = (b32*)xmallocz(sizeof(b32)*i_all_output );
		if( !b_rended) {
			i_err = STX_FAIL;
			break;
		}

		for( i = 0; i < i_all_output; i ++ ){

#if 1
			stx_log("%s:output pin:%d\r\n",h_filter->get_name(h_filter),i);
#endif

			i_err = h_filter->enum_output_media_type(h_filter,&i,&minf);
			if( STX_OK != i_err ) {
				break;
			}
			for( j = 0; j < i_all_major_type; j ++ ) {
				if( is_compatible_gid(p_major_gid[j],minf.major_type)) {
					break;
				}
			}
			if( j == i_all_major_type ) {
				p_major_gid[i_all_major_type++] = minf.major_type;
			}

			// find connection;
			for(j = 0; j < the->m_iAllConnectTions; j ++ ) {
				p = the->m_ppConnectRect[j];
				if( p->start_pos.i_grade != fw_get_grade(fltwnd) ){
					continue;
				}
				if( p->start_pos.i_filter != fw_get_zorder(fltwnd) ) {
					continue;
				}
				if( !is_compatible_gid(p->start_pos.major_type,minf.major_type ) ) {
					continue;
				}
				if( is_compatible_gid(p->start_pos.sub_type,minf.sub_type ) ) {
					break;
				}
			}// for(j = 0; j < m_iAllConnectTions; j ++ ) {

			// not found;
			if( j == the->m_iAllConnectTions ){
				continue;
			}


			if( !b_src ) {
				// if current filter is not file source, should set the output media type;
				h_type = XCREATE(base_media_type,NULL,NULL);
				if( !h_type){
					i_err = STX_FAIL;
					break;
				}
				h_type->set_type(h_type,minf.major_type);
				h_type->set_subtype(h_type,minf.sub_type);
				h_type->set_type_name(h_type,*minf.major_type_name);
				h_type->set_subtype_name(h_type,*minf.sub_type_name);
				i_err = h_filter->set_output_media_type(h_filter,h_type);
				// if is a valve filter, the type maybe changed;
				majortype = h_type->get_type(h_type);
				subtype = h_type->get_subtype(h_type);
				SAFE_XDELETE0(h_type);
				if( STX_OK != i_err ) {
					break;
				}
			}// if( !b_src ) {
			else{
				majortype = minf.major_type;
				subtype = minf.sub_type;
			}


			// found connections; get next filter;
			g = the->m_hhGrade[p->end_pos.i_grade];
			h_next_fltwnd = g->ppFilterWnd[p->end_pos.i_filter];
			h_next_filter = fw_get_filter(h_next_fltwnd);


			// enum all the input major types;
			i_all_input = 0;
			i_err = h_next_filter->enum_input_media_type(h_next_filter,&i_all_input,NULL);
			if( STX_OK != i_err ) {
				break;
			}

			for( k = 0; k < i_all_input; k ++ ) {
				stx_media_type_inf  minf_input;
				i_err = h_next_filter->enum_input_media_type(h_next_filter,&k,&minf_input);
				if( STX_OK != i_err ) {
					break;
				}
				if( !is_compatible_gid(minf_input.major_type,majortype ) ) {
					continue;
				}
				if( is_compatible_gid(minf_input.sub_type,subtype ) ) {
					break;
				}
			}//for( k = 0; k < i_all_input; k ++ ) {

			if( k == i_all_input ) {
				i_err = STX_FAIL;
				break;
			}

			// enum output pin;
			i_err = h_filter->enum_output_pin(h_filter,&i_output_pin,NULL);
			if(STX_OK != i_err ) {
				return i_err;
			}

			for( m = 0; m < i_output_pin; m ++ ) {

				stx_gid major_type,sub_type;

				i_err = h_filter->enum_output_pin(h_filter,&m,(stx_base_pin**)&h_output_pin);
				if(STX_OK != i_err ) {
					break;
				}
				// get output media type;
				h_type = h_output_pin->get_media_type(h_output_pin);
				if( !h_type) {
					i_err = STX_FAIL;
					break;
				}

				major_type = h_type->get_type(h_type);
				if( is_compatible_gid(major_type,minf.major_type)) {
					sub_type = h_type->get_subtype(h_type);
					if( is_compatible_gid(sub_type,minf.sub_type)) {
						majortype = major_type;
						subtype = sub_type;
						break;
					}
				}
				SAFE_XDELETE0(h_type);
				SAFE_XDELETE0(h_output_pin);
			}

			if( STX_OK != i_err ) {
				break;
			}
			if( m == i_output_pin ) { //
				i_err = STX_FAIL;
				break;
			}

			// set next filter's input media type;
#if 1
			{
				void*	hdr = NULL;
				s32		i_size = 0;
				stx_log("next filter:%s\r\n",h_next_filter->get_name(h_next_filter));
				h_type->get_header(h_type,&hdr,&i_size);
				assert(hdr);
			}
#endif
			i_err = h_next_filter->set_input_media_type(h_next_filter,h_type);
			if( STX_OK != i_err ) {
				break;
			}
			SAFE_XDELETE0(h_type);

			// enum input pin; connect pin;
			i_err = h_next_filter->enum_input_pin(h_next_filter,&i_input_pin,NULL);
			if(STX_OK != i_err ) {
				return i_err;
			}
			for( n = 0; n < i_input_pin; n ++ ) {
				stx_gid major_type,sub_type;
				i_err = h_next_filter->enum_input_pin(h_next_filter,&n,&h_input_pin);
				if(STX_OK != i_err ) {
					break;
				}
				// get media type;
				h_type = h_input_pin->get_media_type(h_input_pin);
				if( !h_type) {
					i_err = STX_FAIL;
					break;
				}
				major_type = h_type->get_type(h_type);
				if( is_compatible_gid(major_type,majortype)) {
					sub_type = h_type->get_subtype(h_type);
					SAFE_XDELETE0(h_type);
					if( is_compatible_gid(sub_type,subtype)) {
						break;
					}
				}
				SAFE_XDELETE0(h_input_pin);
				SAFE_XDELETE0(h_type);
			}
			if( STX_OK != i_err ) {
				break;
			}
			if( n == i_input_pin ) { //  
				i_err = STX_FAIL;
				break;
			}

#if 1
			stx_log("next filter pin = %d\r\n",n);
#endif

			i_err = h_output_pin->connect(h_output_pin,h_input_pin);
			if( STX_OK != i_err ) {
				break;
			}

			i_err = h_input_pin->connect(h_input_pin,(stx_base_pin*)h_output_pin);
			if( STX_OK != i_err ) {
				break;
			}

			// set the pin window pin;
			output_pwnd = (output_pin_wnd*)p->start_pos.pwnd;
			output_pwnd->SetPin(output_pwnd,(stx_base_pin*)h_output_pin);

			input_pwnd = p->end_pos.pwnd;
			input_pwnd->SetPin(input_pwnd,(stx_base_pin*)h_input_pin);
			
			// this connection confirmed;
			p->b_valid = TRUE;

			SAFE_XDELETE0(h_output_pin);
			SAFE_XDELETE0(h_input_pin);

			i_err = canvas_confirm_filter_connections(the,h_next_fltwnd);
			if( i_err < 0 ) {
				break;
			}

			if( STX_EOF == i_err && b_src ) {
				b_rended[i_all_major_type-1] = TRUE;
			}

		} // for( i = 0; i < i_all_output; i ++ ){

		if( i_err < 0 ) {
			break;
		}

		if( b_src ) {
			// at least have one major type rendered;
			i_err = STX_FAIL;
			for( i = 0; i < i_all_major_type; i ++ ){
				if( b_rended[i] ) {
					i_err = STX_OK;
					break;
				}
			}
		}

	}while(FALSE);

#if 1	
	if( i_err < 0 ) {
		stx_log("conection comfirm failed! curr filter:%s\r\n",h_filter->get_name(h_filter));
	}
#endif	
	
	SAFE_XDELETE(h_output_pin);
	SAFE_XDELETE(h_input_pin);
	SAFE_XDELETE(h_type);

	if( p_major_gid ) {
		stx_free(p_major_gid);
	}

	if( b_rended ) {
		stx_free(b_rended);
	}

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT canvas_break_connections(base_canvas* the)
{
	s32					i,j;
	stx_grade*			g;
	base_flt_wnd*		f;


	for( i = 0; i < the->m_iGrades; i ++ ) {
		if( g = the->m_hhGrade[i] ) {
			for( j = 0; j < g->i_filter; j ++ ) {
				if( f = g->ppFilterWnd[j] ) {
					canvas_break_filter_connections(the,f);
				}
			}
		}// 
	}

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT canvas_break_filter_connections(base_canvas* the,base_flt_wnd* fltwnd)
{
	fw_ReleasePinWndPin(fltwnd);
	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT canvas_add_connections
(base_canvas* the,base_pin_wnd* start,base_pin_wnd* end)
{
	STX_RESULT			i_err;
	s32					i;
	stx_gid				start_insid,end_insid;
	stx_connection*		p_new;
	stx_media_type_inf	minf;
	base_flt_wnd*		fwnd;

	p_new = NULL;
	start_insid = base_pin_wnd_GetInsId(start);
	end_insid = base_pin_wnd_GetInsId(end);

	for( i = 0; i < the->m_iAllConnectTions; i ++ ) {
		stx_connection* p = the->m_ppConnectRect[i];
		if( is_compatible_gid(p->start_pos.insid,start_insid) && is_compatible_gid(p->end_pos.insid,end_insid)  ) {
			return STX_OK;
		}
	} // for( i = 0; i < m_iAllConnectTions; i ++ ) {

	// add new;
	i_err = STX_FAIL;

	do {
		p_new = (stx_connection*)xmallocz(sizeof(stx_connection));
		if( !p_new ) {
			return STX_FAIL;
		}

		p_new->start_pos.b_start = TRUE;
		p_new->start_pos.pwnd = start;
		p_new->start_pos.insid = base_pin_wnd_GetInsId(start);
		base_pin_wnd_get_pin_inf(start,&p_new->start_pos.i_pin,&minf);
		p_new->start_pos.major_type = minf.major_type;
		p_new->start_pos.sub_type = minf.sub_type;
		fwnd = base_pin_wnd_get_fltwnd(start);
		p_new->start_pos.i_filter = fw_get_zorder(fwnd);
		p_new->start_pos.i_grade = fw_get_grade(fwnd);

		p_new->end_pos.b_start = FALSE;
		p_new->end_pos.pwnd = end;
		p_new->end_pos.insid = base_pin_wnd_GetInsId(end);
		base_pin_wnd_get_pin_inf(end,&p_new->end_pos.i_pin,&minf);
		p_new->end_pos.major_type = minf.major_type;
		p_new->end_pos.sub_type = minf.sub_type;
		fwnd = base_pin_wnd_get_fltwnd(end);
		p_new->end_pos.i_filter = fw_get_zorder(fwnd);
		p_new->end_pos.i_grade = fw_get_grade(fwnd);

		if( the->m_iAllConnectTions >= the->m_iMaxConnectTions ){

			stx_connection** pp;
			the->m_iMaxConnectTions += 128;
			
			pp = (stx_connection**)xmallocz(sizeof(stx_connection*)*(the->m_iMaxConnectTions));
			if( !pp ) {
				break;
			}

			if( the->m_ppConnectRect ) {
				for( i = 0; i < the->m_iAllConnectTions; i ++ ) {
					pp[i] = the->m_ppConnectRect[i];
				}
				stx_free(the->m_ppConnectRect);
			} // if( m_ppConnectRect ) {

			the->m_ppConnectRect = pp;

		}//if( m_iAllConnectTions >= m_iMaxConnectTions ){

		the->m_ppConnectRect[the->m_iAllConnectTions] = p_new;
		the->m_iAllConnectTions ++;

		i_err = STX_OK;

	}while(FALSE);

	if( STX_OK != i_err ) {
		if( p_new ) {
			stx_free(p_new);
		}
	}
	else{
		base_pin_wnd_set_connection(start,TRUE);
		base_pin_wnd_set_connection(end,TRUE);
	}

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT canvas_remove_connections
(base_canvas* the,base_pin_wnd* start,base_pin_wnd* end)
{

	s32				i,j;
	stx_gid			start_insid,end_insid;
	stx_connection* p_new;

	p_new = NULL;
	start_insid = base_pin_wnd_GetInsId(start);
	end_insid = base_pin_wnd_GetInsId(end);

	for( i = 0; i < the->m_iAllConnectTions; i ++ ) {

		stx_connection* p = the->m_ppConnectRect[i];

		if( IS_EQUAL_GID(p->start_pos.insid,start_insid) && IS_EQUAL_GID(p->end_pos.insid,end_insid)  ) {

			for( j = i; j < the->m_iAllConnectTions - 1; j ++ ) {
				the->m_ppConnectRect[j] = the->m_ppConnectRect[j+1];
			}
			the->m_ppConnectRect[j] = NULL;
			the->m_iAllConnectTions --;
			stx_free(p);
			base_pin_wnd_set_connection(start,FALSE);
			base_pin_wnd_set_connection(end,FALSE);
			return STX_OK;
		}//if( is_compatible_gid(p->sta

	} // for( i = 0; i < the->m_iAllConnectTions; i ++ ) {

	return STX_FAIL;

}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT canvas_remove_fltwnd_connections
(base_canvas* the,base_flt_wnd* fltwnd)
{

	STX_RESULT			i_err;
	s32					i,j,k,i_pin;
	base_pin_wnd*		pwnd;
	output_pin_wnd*		output_pwnd;
	stx_gid				start_insid,end_insid;

	do{

		i_err = STX_OK;
		i_pin = 0;
		i_err = fw_enum_output_pinwnd(fltwnd,&i_pin,NULL);

		for( i = 0; i < i_pin; i ++ ) {

			i_err = fw_enum_output_pinwnd(fltwnd,&i,&output_pwnd);
			if( STX_OK != i_err ) {
				break;
			}

			if( !base_pin_wnd_is_connection((base_pin_wnd*)output_pwnd) ){
				continue;
			}

			start_insid = base_pin_wnd_GetInsId((base_pin_wnd*)output_pwnd);

			for( j = 0; j < the->m_iAllConnectTions; j ++ ) {

				stx_connection* p = the->m_ppConnectRect[j];

				if( IS_EQUAL_GID(p->start_pos.insid,start_insid) ) {

					output_pin_wnd* pstart = NULL;
					base_pin_wnd* pend = NULL;

					i_err = canvas_find_connection_pin(the,p,&pstart,&pend);
					if( STX_OK != i_err ) {
						break;
					}

					base_pin_wnd_set_connection((base_pin_wnd*)pstart,FALSE);
					base_pin_wnd_set_connection(pend,FALSE);

					for( k = j; k < the->m_iAllConnectTions - 1; k ++ ) {
						the->m_ppConnectRect[k] = the->m_ppConnectRect[k+1];
					}
					the->m_ppConnectRect[k] = NULL;
					the->m_iAllConnectTions --;
					stx_free(p);
					break;

				}//if( IS_EQUAL_GID(p->start_pos.insid,start_insid) ) {

			}//for( j = 0; j < the->m_iAllConnectTions; j ++ ) {

			if( STX_OK != i_err ) {
				break;
			}
		}

		if( STX_OK != i_err ) {
			break;
		}

		i_pin = 0;
		i_err = fw_enum_input_pinwnd(fltwnd,&i_pin,NULL);

		for( i = 0; i < i_pin; i ++ ) {

			i_err = fw_enum_input_pinwnd(fltwnd,&i,&pwnd);
			if( STX_OK != i_err ) {
				break;
			}

			if( ! base_pin_wnd_is_connection(pwnd) ){
				continue;
			}

			end_insid = base_pin_wnd_GetInsId(pwnd);

			for( j = 0; j < the->m_iAllConnectTions; j ++ ) {

				stx_connection* p = the->m_ppConnectRect[j];

				if( IS_EQUAL_GID(p->end_pos.insid,end_insid)) {

					output_pin_wnd* pstart = NULL;
					base_pin_wnd* pend = NULL;

					i_err = canvas_find_connection_pin(the,p,&pstart,&pend);
					if( STX_OK != i_err ) {
						break;
					}

					base_pin_wnd_set_connection((base_pin_wnd*)pstart,FALSE);
					base_pin_wnd_set_connection(pend,FALSE);

					for( k = j; k < the->m_iAllConnectTions - 1; k ++ ) {
						the->m_ppConnectRect[k] = the->m_ppConnectRect[k+1];
					}
					the->m_ppConnectRect[k] = NULL;
					the->m_iAllConnectTions --;
					stx_free(p);
					break;

				}//if( IS_EQUAL_GID(p->end_pos.insid,end_insid)) {

			}//for( j = 0; j < the->m_iAllConnectTions; j ++ ) {

		}//for( i = 0; i < i_pin; i ++ ) {

	}while(FALSE);

	return i_err;


}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT canvas_update_fltwnd_connections
(base_canvas* the,base_flt_wnd* fltwnd)
{

	STX_RESULT			i_err;
	s32					i,j,i_pin;
	base_pin_wnd*		pwnd;
	output_pin_wnd*		output_pwnd;
	stx_gid				start_insid,end_insid;

	do{

		i_pin = 0;
		i_err = fw_enum_output_pinwnd(fltwnd,&i_pin,NULL);
		if( STX_OK != i_err ) {
			break;
		}

		for( i = 0; i < i_pin; i ++ ) {
			i_err = fw_enum_output_pinwnd(fltwnd,&i,&output_pwnd);
			if( STX_OK != i_err ) {
				break;
			}
			start_insid = base_pin_wnd_GetInsId((base_pin_wnd*)output_pwnd);
			for( j = 0; j < the->m_iAllConnectTions; j ++ ) {
				stx_connection* p = the->m_ppConnectRect[j];
				if( IS_EQUAL_GID(p->start_pos.insid,start_insid) ) {
					p->start_pos.i_filter = fw_get_zorder(fltwnd);
					p->start_pos.i_grade = fw_get_grade(fltwnd);
					break;
				}
			}
		}

		i_pin = 0;
		i_err = fw_enum_input_pinwnd(fltwnd,&i_pin,NULL);
		if( STX_OK != i_err ) {
			break;
		}

		for( i = 0; i < i_pin; i ++ ) {
			i_err = fw_enum_input_pinwnd(fltwnd,&i,&pwnd);
			if( STX_OK != i_err ) {
				break;
			}
			end_insid = base_pin_wnd_GetInsId(pwnd);
			for( j = 0; j < the->m_iAllConnectTions; j ++ ) {
				stx_connection* p = the->m_ppConnectRect[j];
				if( IS_EQUAL_GID(p->end_pos.insid,end_insid)) {
					p->end_pos.i_filter = fw_get_zorder(fltwnd);
					p->end_pos.i_grade = fw_get_grade(fltwnd);
					break;
				}
			}
		}

	}while(FALSE);

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT canvas_find_connection_pin
(base_canvas* the,stx_connection* pcon,output_pin_wnd** pp_start,base_pin_wnd** pp_end)
{

	stx_grade*		g;
	base_flt_wnd*	fltwnd;
	output_pin_wnd* pstart;
	base_pin_wnd*	pend;

	g = the->m_hhGrade[pcon->start_pos.i_grade];
	fltwnd = g->ppFilterWnd[pcon->start_pos.i_filter];

	pstart = fw_find_outputpin(fltwnd,pcon->start_pos.insid);
	if( !pstart ) {
		return STX_FAIL;
	}

	g = the->m_hhGrade[pcon->end_pos.i_grade];
	fltwnd = g->ppFilterWnd[pcon->end_pos.i_filter];
	pend = fw_find_inputpin(fltwnd,pcon->end_pos.insid);
	if( !pend) {
		return STX_FAIL;
	}

	*pp_start = pstart;
	*pp_end = pend;

	return STX_OK;

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT canvas_check_fltwnd_pos(base_canvas* the,base_flt_wnd* fltwnd)
{
	STX_RESULT	i_err;
	s32			i;
	s32			i_tg;
	s32			i_grade;
	RECT		rec;
	POINT       pbr;

	rec = fw_get_pos(fltwnd);

	pbr.x = rec.right-1;
	pbr.y = rec.bottom-1;
	if( PtInRect(&the->m_dustbin,pbr) ) {

		canvas_remove_fltwnd(the,fltwnd,TRUE);

		fw_close(fltwnd);
		return STX_RET_DELETE;
	}

	// align grade;
	for( i = 0; i < the->m_iGrades; i ++ ) {

		i_grade = the->m_pos.left + GRADE_WIDTH*i;

		if( rec.left >= i_grade && rec.left < i_grade + GRADE_WIDTH ) {

			rec.left = i_grade + GRADE_EDGE;
			rec.right = rec.left + FLTWND_WIDTH;
			fw_set_pos(fltwnd,rec);

			i_tg = fw_get_grade(fltwnd);

			if( i_tg != i ) {
				// remove;
				i_err = canvas_remove_fltwnd(the,fltwnd,FALSE);
				if( STX_OK != i_err ) {
					return i_err;
				}
				// insert;
				i_err = canvas_insert_fltwnd(the,fltwnd,i);
				if( STX_OK != i_err ) {
					return i_err;
				}
			}//if( i_tg != i ) {

			break;

		}//if( rec.left >= i_grade && rec.left < i_grade + GRADE_WIDTH ) {

	} // for( i = 0; i < the->m_iGrades; i ++ ) {


	if( i == the->m_iGrades ) {

		s32 w;

		// remove;
		i_err = canvas_remove_fltwnd(the,fltwnd,FALSE);
		if( STX_OK != i_err ) {
			return i_err;
		}

		// add grade;
		i_err = canvas_add_grade(the);
		if( STX_OK != i_err ) {
			return i_err;
		}
		i = the->m_iGrades-1;

		// check canvas width;
		w = the->m_iGrades * GRADE_WIDTH;

		if( w > ( the->m_pos.right - the->m_pos.left )  ) {

			the->m_pos.right = the->m_pos.left + w;

			if( the->m_pos.right - the->m_pos.left > CANVAS_MAX_WIDTH ) {
				the->m_pos.right = the->m_pos.left + CANVAS_MAX_WIDTH;
			}
		}//if( w > (the->m_pos.right - the->m_pos.left )  ) {

		// set position;
		i_grade = the->m_pos.left + GRADE_WIDTH*i;
		rec.left = i_grade + GRADE_EDGE;
		rec.right = rec.left + FLTWND_WIDTH;
		fw_set_pos(fltwnd,rec);

		// insert;
		i_err = canvas_insert_fltwnd(the,fltwnd,i);
		if( STX_OK != i_err ) {
			return i_err;
		}

	}//if( i == the->m_iGrades ) {

	// sort grade;
	i_err = canvas_sort_grade(the,the->m_hhGrade[i]);
	if( STX_OK != i_err ) {
		return i_err;
	}

	return STX_OK;

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT canvas_remove_fltwnd
(base_canvas* the,base_flt_wnd* fltwnd,b32 b_delete)
{

	s32 i,j;

	if( b_delete ) {
		// update connections;
		canvas_remove_fltwnd_connections(the,fltwnd);
	}

	{



		s32 i_pos = fw_get_grade(fltwnd);

		stx_grade* g = the->m_hhGrade[i_pos];

		for( i = 0; i < g->i_filter; i ++ ) {
			if( g->ppFilterWnd[i] == fltwnd ) {
				for(j = i; j < g->i_filter - 1; j ++ ) {
					g->ppFilterWnd[j] = g->ppFilterWnd[j+1];
					fw_set_zorder(g->ppFilterWnd[j],j);
				}
				g->ppFilterWnd[g->i_filter-1] = NULL;
				g->i_filter --;
				if( !g->i_filter && g->i_grade != 0 && g->i_grade == the->m_iGrades - 1) {
					return canvas_remove_grade(the,g);
				}
				return STX_OK;
			}
		}

		return STX_OK;


	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT canvas_insert_fltwnd
(base_canvas* the,base_flt_wnd* fltwnd,s32 i_grade)
{
	s32			i;
	stx_grade*	g = the->m_hhGrade[i_grade];

	if( g->i_filter == g->i_max_filter ) {
		base_flt_wnd** ff;
		
		ff = (base_flt_wnd**)xmallocz(sizeof(base_flt_wnd*)*(g->i_max_filter + MAX_GRADE));
		if( !ff ) {
			return STX_FAIL;
		}

		if( g->ppFilterWnd ) {
			for( i = 0; i < g->i_filter; i ++ ) {
				ff[i] = g->ppFilterWnd[i];
			}
			stx_free(g->ppFilterWnd);
		}
		g->ppFilterWnd = ff;
		g->i_max_filter += MAX_GRADE;
	}//if( g->i_filter == g->i_max_filter ) {

	g->ppFilterWnd[g->i_filter] = fltwnd;
	fw_set_grade(fltwnd,i_grade);
	fw_set_zorder(fltwnd,g->i_filter);
	g->i_filter ++;

	canvas_update_fltwnd_connections(the,fltwnd);

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT canvas_add_grade(base_canvas* the)
{
	s32			j;
	stx_grade** pp;

	pp = (stx_grade**)xmallocz(sizeof(stx_grade*)*(the->m_iGrades + 1));
	if( !pp ) {
		return STX_FAIL;
	}

	if( the->m_hhGrade ) {
		for( j = 0; j < the->m_iGrades; j ++ ) {
			pp[j] = the->m_hhGrade[j];
		}
		stx_free( the->m_hhGrade );
	}
	the->m_hhGrade = pp;

	the->m_hhGrade[the->m_iGrades] = (stx_grade*)xmallocz(sizeof(stx_grade));
	if( !the->m_hhGrade[the->m_iGrades] ) {
		return STX_FAIL;
	}

	the->m_hhGrade[the->m_iGrades]->i_grade = the->m_iGrades;
	the->m_hhGrade[the->m_iGrades]->i_filter = 0;
	the->m_hhGrade[the->m_iGrades]->i_max_filter = 0;
	the->m_hhGrade[the->m_iGrades]->ppFilterWnd = NULL;
	the->m_iGrades ++;

	// check width;
	if( the->m_pos.right - the->m_pos.left < the->m_iGrades * GRADE_WIDTH ) {
		the->m_pos.right = the->m_pos.left + the->m_iGrades * GRADE_WIDTH;
	}

	if( the->m_pos.right - the->m_pos.left > CANVAS_MAX_WIDTH ) {
		the->m_pos.right = the->m_pos.left + CANVAS_MAX_WIDTH;
	}

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT canvas_remove_grade(base_canvas* the,stx_grade* g)
{
	s32 i,j,k;

	for( i = 0; i < the->m_iGrades; i ++ ) {

		if( the->m_hhGrade[i] == g ) {

			for( j = i; j < the->m_iGrades - 1; j ++ ) {

				stx_grade* gg = the->m_hhGrade[j+1];

				the->m_hhGrade[j] = gg;

				gg->i_grade = j;

				for( k = 0; k < gg->i_filter; k ++ ) {
					base_flt_wnd* f = gg->ppFilterWnd[k];
					// reset pos;
					RECT rc = fw_get_pos(f);
					rc.left -= GRADE_WIDTH;
					rc.right -= GRADE_WIDTH;
					fw_set_pos(f,rc);
					// reset i_grade;
					fw_set_grade(f,j);					
				}

			} // for( j = i; j < m_iGrades - 1; j ++ ) {

			the->m_hhGrade[the->m_iGrades - 1] = NULL;
			the->m_iGrades --;
			// delete it;
			canvas_release_grade(g);

			return STX_OK;

		}//if( the->m_hhGrade[i] == g ) {
	}//for( i = 0; i < the->m_iGrades; i ++ ) {
	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT canvas_sort_grade(base_canvas* the,stx_grade* g )
{
	s32			i,j,k;
	s32         i_order;
	s32			h;
	RECT		tr;

	base_flt_wnd* f;

	// use bubble sort;

	k = 0;

	for( i = 0; i < g->i_filter; i ++ ) {

		h = CANVAS_MAX_HEIGHT;
		i_order = -1;

		for( j = k; j < g->i_filter; j ++ ) {

			tr = fw_get_pos(g->ppFilterWnd[j]);

			if( tr.top <= h ) {
				h = tr.top;
				i_order = j;
			}
		}//for( j = k; j < g->i_filter; j ++ ) {

		if( i_order == -1 ) {
			break;
		}

		if( i_order == k ) {
			k ++;
			continue;
		}

		f = g->ppFilterWnd[i_order];
		g->ppFilterWnd[i_order] = g->ppFilterWnd[k];
		g->ppFilterWnd[k] = f;
		fw_set_zorder(f,k);
		fw_set_zorder(g->ppFilterWnd[i_order],i_order);

		k ++;

	} // for( i = 0; i < g->i_filter; i ++ ) {

#if 0
	canvas_info(the);
#endif

#if 0
	top = the->m_pos.top + GRADE_EDGE;
	for( i = 0; i < g->i_filter; i ++ ) {
		f = g->ppFilterWnd[i];
		tr = fw_get_pos(f);
		h = tr.bottom - tr.top;
		tr.top = top;
		tr.bottom = tr.top + h;
		fw_set_pos(f,tr);
		top += h + GRADE_EDGE;
	}//for( i = 0; i < g->i_filter; i ++ ) {
#else
	f = g->ppFilterWnd[0];
	tr = fw_get_pos(f);
	for( i = 1; i < g->i_filter; i ++ ) {
		base_flt_wnd* f1 = g->ppFilterWnd[i];
		RECT tr1 = fw_get_pos(f1);
		if( tr1.top <= tr.bottom ) {
			h = tr1.bottom - tr1.top;
			tr1.top = tr.bottom + GRADE_EDGE;
			tr1.bottom = tr1.top + h;
			fw_set_pos(f1,tr1);
		}
		tr = tr1;
	}//for( i = 0; i < g->i_filter; i ++ ) {
#endif

	for( i = 0; i < g->i_filter; i ++ ) {
		canvas_update_fltwnd_connections(the,g->ppFilterWnd[i]);
	}


#if 0
	canvas_info(the);
#endif

	// check canvas height;

	tr = fw_get_pos(g->ppFilterWnd[g->i_filter-1]);

	if( tr.bottom > the->m_pos.bottom ) {
		the->m_pos.bottom = tr.bottom;
	}// if( tr.bottom > m_pos.bottom ) {

	if( the->m_pos.bottom - the->m_pos.top > CANVAS_MAX_HEIGHT ) {
		the->m_pos.bottom = the->m_pos.top + CANVAS_MAX_HEIGHT;
	}

	//
	h = 0;
	for( i = 0; i < the->m_iGrades; i ++ ) {
		if( the->m_hhGrade[i]->i_filter ) {
			tr = fw_get_pos(the->m_hhGrade[i]->ppFilterWnd[the->m_hhGrade[i]->i_filter-1]);
			if( tr.bottom > h ) {
				h = tr.bottom;
			}
		}
	}

	if( h - the->m_pos.top < CANVAS_MIN_HEIGHT ) {
		the->m_pos.bottom = the->m_pos.top + CANVAS_MIN_HEIGHT;
	}

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT canvas_initialize_fltwnd
(base_canvas* the,base_flt_wnd* fltwnd,stx_base_com* p)
{
	STX_RESULT			i_err;
	stx_base_filter*	pflt;


	i_err = STX_FAIL;
	pflt = NULL;


	do{

		i_err = p->query_interf(p,STX_IID_BaseFilter,(void**)&pflt);
		if( STX_OK != i_err ){
			break;
		}

		// default position;
		canvas_fltwnd_default_pos(the,fltwnd,0);

		// set to grade 0;
		i_err = canvas_insert_fltwnd(the,fltwnd,0);
		if( STX_OK != i_err ) {
			break;
		}

		// sort grade;
		i_err = canvas_sort_grade(the,the->m_hhGrade[0]);
		if( STX_OK != i_err ) {
			break;
		}

		// attach filter;
		fw_set_filter(fltwnd,pflt);

		i_err = STX_OK;

	}while(FALSE);

	if( STX_OK != i_err ) {
		SAFE_XDELETE(pflt);
	}

	return i_err;

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT canvas_initialize_connection_point
(base_canvas* the,stx_xini* h_xini,STX_HANDLE h_parent,stx_connection_point* p)
{
	STX_RESULT	i_err;
	char*		sz_val;
	STX_HANDLE	h_id;
	STX_HANDLE	h_indx;

	sz_val = NULL;

	do{

		// grade index;
		i_err = h_xini->create_key(h_xini,h_parent,g_szGradeIndex,"0",&h_indx);
		if( STX_INI_OK != i_err ) {
			break;
		}
		i_err = h_xini->read_int32(h_xini,h_indx,&p->i_grade);
		if( STX_INI_OK != i_err ) {
			break;
		}

		// filter index;
		i_err = h_xini->create_key(h_xini,h_parent,g_szFilterIndex,"0",&h_indx);
		if( STX_INI_OK != i_err ) {
			break;
		}
		i_err = h_xini->read_int32(h_xini,h_indx,&p->i_filter);
		if( STX_INI_OK != i_err ) {
			break;
		}

		// pin index;
		i_err = h_xini->create_key(h_xini,h_parent,g_szPinIndex,"0",&h_indx);
		if( STX_INI_OK != i_err ) {
			break;
		}
		i_err = h_xini->read_int32(h_xini,h_indx,&p->i_pin);
		if( STX_INI_OK != i_err ) {
			break;
		}

		// major type;
		i_err = h_xini->create_key(h_xini,h_parent,g_szStreamX_MajorDataType,NULL,&h_id);
		if( STX_INI_OK != i_err ) {
			break;
		}
		i_err = h_xini->read_string(h_xini,h_id,&sz_val);
		if( STX_INI_OK != i_err ) {
			break;
		}
		p->major_type = stx_gid_from_string(sz_val);

		// sub type;
		i_err = h_xini->create_key(h_xini,h_parent,g_szStreamX_SubDataType,NULL,&h_id);
		if( STX_INI_OK != i_err ) {
			break;
		}
		i_err = h_xini->read_string(h_xini,h_id,&sz_val);
		if( STX_INI_OK != i_err ) {
			break;
		}
		p->sub_type = stx_gid_from_string(sz_val);

		// instance id;
		i_err = h_xini->create_key(h_xini,h_parent,g_szInstanceId,NULL,&h_id);
		if( STX_INI_OK != i_err ) {
			break;
		}
		i_err = h_xini->read_string(h_xini,h_id,&sz_val);
		if( STX_INI_OK != i_err ) {
			break;
		}
		p->insid = stx_gid_from_string(sz_val);

		{
			stx_grade*		g;
			base_flt_wnd*	fw;

			if( p->i_grade < 0 || p->i_grade >= the->m_iGrades ) {
				i_err = STX_FAIL;
				break;
			}

			g = the->m_hhGrade[p->i_grade];

			if( p->i_filter < 0  || p->i_filter >= g->i_filter ) {
				i_err = STX_FAIL;
				break;
			}

			fw = g->ppFilterWnd[p->i_filter];

			if( STX_OK != fw_check_connection_point(fw,p) ) {
				i_err = STX_FAIL;
				break;
			}

		} // blank;

		i_err = STX_OK;

	}while(FALSE);

	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT canvas_serialize_connection_point
(base_canvas* the,stx_xini* h_xini,STX_HANDLE h_parent,stx_connection_point* p)
{
	STX_RESULT	i_err;
	char		sz_val[64];
	STX_HANDLE	h_id;
	STX_HANDLE	h_indx;


	do{

		// grade index;
		i_err = h_xini->create_key(h_xini,h_parent,g_szGradeIndex,"0",&h_indx);
		if( STX_INI_OK != i_err ) {
			break;
		}
		i_err = h_xini->write_int32(h_xini,h_indx,p->i_grade);
		if( STX_INI_OK != i_err ) {
			break;
		}

		// filter index;
		i_err = h_xini->create_key(h_xini,h_parent,g_szFilterIndex,"0",&h_indx);
		if( STX_INI_OK != i_err ) {
			break;
		}
		i_err = h_xini->write_int32(h_xini,h_indx,p->i_filter);
		if( STX_INI_OK != i_err ) {
			break;
		}

		// pin index;
		i_err = h_xini->create_key(h_xini,h_parent,g_szPinIndex,"0",&h_indx);
		if( STX_INI_OK != i_err ) {
			break;
		}
		i_err = h_xini->write_int32(h_xini,h_indx,p->i_pin);
		if( STX_INI_OK != i_err ) {
			break;
		}

		// major type;
		i_err = h_xini->create_key(h_xini,h_parent,g_szStreamX_MajorDataType,NULL,&h_id);
		if( STX_INI_OK != i_err ) {
			break;
		}
		binary_to_string(sizeof(stx_gid),(u8*)&p->major_type,sz_val);
		i_err = h_xini->write_string(h_xini,h_id,sz_val);
		if( STX_INI_OK != i_err ) {
			break;
		}

		// sub type;
		i_err = h_xini->create_key(h_xini,h_parent,g_szStreamX_SubDataType,NULL,&h_id);
		if( STX_INI_OK != i_err ) {
			break;
		}
		binary_to_string(sizeof(stx_gid),(u8*)&p->sub_type,sz_val);
		i_err = h_xini->write_string(h_xini,h_id,sz_val);
		if( STX_INI_OK != i_err ) {
			break;
		}

		// instance id;
		i_err = h_xini->create_key(h_xini,h_parent,g_szInstanceId,NULL,&h_id);
		if( STX_INI_OK != i_err ) {
			break;
		}
		binary_to_string(sizeof(stx_gid),(u8*)&p->insid,sz_val);
		i_err = h_xini->write_string(h_xini,h_id,sz_val);
		if( STX_INI_OK != i_err ) {
			break;
		}

		i_err = STX_OK;

	}while(FALSE);

	return i_err;

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void canvas_fltwnd_default_pos(base_canvas* the,base_flt_wnd* fltwnd,s32 i_grade)
{
	RECT rec;
	rec.left = the->m_pos.left + i_grade*GRADE_WIDTH + GRADE_EDGE;
	rec.top = the->m_pos.top + GRADE_EDGE;
	rec.right = rec.left + FLTWND_WIDTH;
	rec.bottom = rec.top + FLTWND_HEIGHT;
	fw_set_pos(fltwnd,rec);

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void canvas_info(base_canvas* the)
{
	s32 i,j;

	char sz_inf[1024];

	for( i = 0; i < the->m_iGrades; i ++ ) {

		stx_grade* g = the->m_hhGrade[i];

		stx_sprintf(sz_inf,sizeof( sz_inf),"grade = %d\r\n",i);
		stx_log(sz_inf);

		for( j = 0; j < g->i_filter; j ++ ) {

			base_flt_wnd* f = g->ppFilterWnd[j];
			stx_base_filter* flt = fw_get_filter(f);
			RECT rc = fw_get_pos(f);

			stx_sprintf(sz_inf,sizeof( sz_inf),
				"%s,i_grade = %d,index = %d, zorder = %d, {left=%d,top=%d,right=%d,bottom=%d}\r\n",
				flt->get_clsid_name(flt),
				fw_get_grade(f),
				j,
				fw_get_zorder(f),
				rc.left,rc.top,rc.right,rc.bottom );

			stx_log(sz_inf);

		}//for( j = 0; j < g->i_filter; j ++ ) {

	}//for( i = 0; i < the->m_iGrades; i ++ ) {

}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void canvas_set_dst_rect(base_canvas* the,RECT dst_rect)
{
	STX_RESULT			i_err;
	size_t				i;
	size_t				i_plugin;

	stx_base_plugin*	p;
	stx_video_render*   pvrnd;


	p = NULL;
	i_err = STX_FAIL;
	i_plugin = 0;


	do{
		// enum plugins; get MediaControl interface;
		i_err = the->m_hGph->enum_plugin(the->m_hGph,&i_plugin,NULL);
		if( STX_OK != i_err ){
			break;
		}

		if( i_plugin == 0 ) {
			break;
		}

		pvrnd = NULL;

		for( i = 0; i < i_plugin; i ++ ) {
			i_err =  the->m_hGph->enum_plugin(the->m_hGph,&i,&p);
			if( STX_OK != i_err ){
				break;
			}
			i_err = p->query_interf(p,STX_IID_VideoRender,(void**)&pvrnd);
			if( STX_OK == i_err ) {
				break;
			}
			SAFE_XDELETE(p);
			p = NULL;
		} // for( i = 0; i < i_plugin; i ++ ) {

		if( i == i_plugin ) {
			i_err = STX_FAIL;
		}

	}while(FALSE);

	SAFE_XDELETE(p);

	if( STX_OK != i_err ) {
		return ;
	}

	pvrnd->set_dst_rect(pvrnd,dst_rect);

	//XDELETE(pvrnd);
	i_err = pvrnd->release(pvrnd);

	//stx_log("canvas_set_dst_rect::video render i_ref = %d\r\n",i_err);

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void canvas_set_color_key(base_canvas* the,u32 i_color_key)
{
	STX_RESULT			i_err;
	size_t				i;
	size_t				i_plugin;

	stx_base_plugin*	p;
	stx_video_render*   pvrnd;


	p = NULL;
	i_err = STX_FAIL;
	i_plugin = 0;


	do{
		// enum plugins; get MediaControl interface;
		i_err = the->m_hGph->enum_plugin(the->m_hGph,&i_plugin,NULL);
		if( STX_OK != i_err ){
			break;
		}

		if( i_plugin == 0 ) {
			break;
		}

		pvrnd = NULL;

		for( i = 0; i < i_plugin; i ++ ) {
			i_err =  the->m_hGph->enum_plugin(the->m_hGph,&i,&p);
			if( STX_OK != i_err ){
				break;
			}
			i_err = p->query_interf(p,STX_IID_VideoRender,(void**)&pvrnd);
			if( STX_OK == i_err ) {
				break;
			}
			SAFE_XDELETE(p);
			p = NULL;
		} // for( i = 0; i < i_plugin; i ++ ) {

		if( i == i_plugin ) {
			i_err = STX_FAIL;
		}

	}while(FALSE);

	SAFE_XDELETE(p);

	if( STX_OK != i_err ) {
		return ;
	}

	pvrnd->set_color_key(pvrnd,i_color_key);

	//XDELETE(pvrnd);
	i_err = pvrnd->release(pvrnd);

	//stx_log("canvas_set_dst_rect::video render i_ref = %d\r\n",i_err);

}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void canvas_show_render(base_canvas* the, b32 bShow)
{
	STX_RESULT			i_err;
	size_t				i;
	size_t				i_plugin;

	stx_base_plugin*	p;
	stx_video_render*   pvrnd;


	p = NULL;
	i_err = STX_FAIL;
	i_plugin = 0;


	do{
		// enum plugins; get MediaControl interface;
		i_err = the->m_hGph->enum_plugin(the->m_hGph,&i_plugin,NULL);
		if( STX_OK != i_err ){
			break;
		}

		if( i_plugin == 0 ) {
			break;
		}

		pvrnd = NULL;

		for( i = 0; i < i_plugin; i ++ ) {
			i_err =  the->m_hGph->enum_plugin(the->m_hGph,&i,&p);
			if( STX_OK != i_err ){
				break;
			}
			i_err = p->query_interf(p,STX_IID_VideoRender,(void**)&pvrnd);
			if( STX_OK == i_err ) {
				break;
			}
			SAFE_XDELETE(p);
			p = NULL;
		} // for( i = 0; i < i_plugin; i ++ ) {

		if( i == i_plugin ) {
			i_err = STX_FAIL;
		}

	}while(FALSE);

	SAFE_XDELETE(p);

	if( STX_OK != i_err ) {
		return ;
	}

	if( bShow ) {
		pvrnd->show(pvrnd);
	}
	else {
		pvrnd->hide(pvrnd);
	}

	SAFE_XDELETE(pvrnd);

}