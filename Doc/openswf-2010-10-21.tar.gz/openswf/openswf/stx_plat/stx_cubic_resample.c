/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/
#include "stdio.h"
#include "stdlib.h"
#include "fcntl.h"
#include "malloc.h"
#include "memory.h"
#include "string.h"

#include "stx_mem.h"
#include "stx_debug.h"
#include "stx_gid.h"


#include "stx_all_codec.h"
#include "stx_direct_pin.h"
#include "stx_output_pin.h"

#include "cubic_resizer.h"

#include "stx_media_type_base.h"
#include "stx_malloc_lxvideoframe.h"
#include "stx_mdat_lxvideoframe.h"

#include "stx_io_stream.h"
#include "stx_prop_def.h"
#include "stx_module_reg.h"

#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif

char* g_szStreamX_CubicResample = "StreamX CubicResample filter";

DEFINE_XGUID( STX_CLSID_CubicResample,
0xcf7e80ff, 0x982c, 0x4126, 0x82, 0x0, 0x59, 0x7, 0x89, 0x47, 0xf3, 0xbf );


STX_INPUT_MEDIA_TYPE_MAP_BEGIN(CubicResample)
/**/MEDIA_TYPE_MAP_ITEM(MEDIATYPE_Video,MEDIASUBTYPE_LxVideoFrame)
STX_INPUT_MEDIA_TYPE_MAP_END()

STX_OUTPUT_MEDIA_TYPE_MAP_BEGIN(CubicResample)
/**/MEDIA_TYPE_MAP_ITEM(MEDIATYPE_Video,MEDIASUBTYPE_LxVideoFrame)
STX_OUTPUT_MEDIA_TYPE_MAP_END()

STX_COM_BEGIN(CubicResample);
/**/
/**/STX_PUBLIC(stx_base_filter)
/**/STX_COM_DATA_DEFAULT(stx_base_filter)
/**/
/**/stx_base_pin*       p_input_pin;
/**/stx_output_pin*     p_output_pin;
/**/stx_media_data*		h_mdat;
/**/STX_HANDLE          h_cubic;
/**/s32                 i_output_width;
/**/s32                 i_output_height;
/**/
STX_COM_END();

STX_COM_FUNC_DECL_DEFAULT(stx_base_filter,stx_base_filter_vt);
STX_COM_FUNCIMP_DEFAULT(CubicResample,stx_base_filter,stx_base_filter_vt);


/*{{{STX_MSG_PROC_DECLARE***************************************************/
STX_MSG_PROC_DECLARE(dispatch_msg)
STX_MSG_PROC_DECLARE(response_msg)
// STX_MSG_PROC_DECLARE(up_stream_msg)
// STX_MSG_PROC_DECLARE(down_stream_msg)
/*}}}***********************************************************************/


/*{{{STX_MSG_ENTRY_DECLARE**************************************************/
STX_MSG_ENTRY_DECLARE(on_play)
STX_MSG_ENTRY_DECLARE(at_BreakPin)
// STX_MSG_ENTRY_DECLARE(on_resume)
// STX_MSG_ENTRY_DECLARE(on_stop)
// STX_MSG_ENTRY_DECLARE(at_play)
// STX_MSG_ENTRY_DECLARE(at_pause)
// STX_MSG_ENTRY_DECLARE(at_resume)
// STX_MSG_ENTRY_DECLARE(at_stop)
/*}}}***********************************************************************/


/*{{{STX_BEGIN_MSG_MAP******************************************************/
STX_BEGIN_MSG_MAP(the_msg_data)

/* to do : add msg process entry here; */
ON_STX_MSG(STX_MSG_Play,on_play)
// ON_STX_MSG(STX_MSG_Resume,on_resume)
// ON_STX_MSG(STX_MSG_Stop,on_stop)

STX_END_MSG_MAP
/*}}}***********************************************************************/

/*{{{STX_DISPATCH_MSG_PROC**************************************************/
STX_DISPATCH_MSG_PROC( dispatch_msg,the_msg_data )
/*}}}***********************************************************************/


/*{{{STX_BEGIN_MSG_RESPONSE_MAP*********************************************/
STX_BEGIN_MSG_RESPONSE_MAP(the_msg_response)

/* to do : add msg process entry here; */
ON_STX_MSG(STX_MSG_BreakPin,at_BreakPin)
// ON_STX_MSG(STX_MSG_Play,at_play)
// ON_STX_MSG(STX_MSG_Pause,at_pause)
// ON_STX_MSG(STX_MSG_Resume,at_resume)
// ON_STX_MSG(STX_MSG_Stop,at_stop)

STX_END_MSG_RESPONSE_MAP
/*}}}***********************************************************************/


/*{{{STX_RESPONSE_MSG_PROC**************************************************/
STX_RESPONSE_MSG_PROC( response_msg, the_msg_response )
/*}}}***********************************************************************/

STX_PRIVATE STX_RESULT do_transform(CubicResample* the,VideoFrame* p_in,VideoFrame* p_out);

STX_PRIVATE STX_RESULT initialize_inputpin(CubicResample* the);
STX_PRIVATE STX_RESULT initialize_outputpin(CubicResample* the);

STX_COM_MAP_BEGIN(CubicResample)
/**/STX_COM_MAP_ITEM(STX_IID_BaseFilter)
STX_COM_MAP_END()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_NEW_BEGIN(CubicResample)
{
	STX_RESULT i_err;

	STX_SET_THE(stx_base_filter);
	STX_COM_NEW_DEFAULT(stx_base_filter,the->stx_base_filter_vt,stx_base_filter_vt,
		STX_CLSID_CubicResample,STX_CATEGORY_IntermediateFilter,g_szStreamX_CubicResample);

	// default property;
	the->i_output_width = 720;
	the->i_output_height = 480;

	the->h_cubic = open_bicubic_resize();
	if( !the->h_cubic ) {
		break;
	}

	// create input pin;
	i_err = initialize_inputpin(the);
	if( STX_OK != i_err ) {
		break;
	}

	// create output pin;
	i_err = initialize_outputpin(the);
	if( STX_OK != i_err ) {
		break;
	}

}
STX_NEW_END()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API_IMP	
STX_QUERY_BEGIN(CubicResample)
{
	STX_COM_QUERY_DEFAULT(stx_base_filter,the->stx_base_filter_vt);
}
STX_QUERY_END()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API_IMP	
STX_DELETE_BEGIN(CubicResample)
{
	// pin;
	SAFE_XDELETE(the->p_output_pin);
	SAFE_XDELETE(the->p_input_pin);

	// resizer api handle;
	if( the->h_cubic ) {
		close_bicubic_resize(the->h_cubic);
	}

	STX_COM_DELETE_DEFAULT(stx_base_filter);
}
STX_DELETE_END
(
	STX_COM_DELETE_BEGIN(stx_base_filter)
	,
	STX_COM_DELETE_END(stx_base_filter)
)




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT initialize_inputpin(CubicResample* the)
{
	STX_RESULT					i_err;
	stx_media_type*             h_type;
	STX_VIDEOINFOHEADER2        vd2;
	s32                         i_len;

	i_err = STX_FAIL;
	h_type = NULL;

	do{
		the->p_input_pin = XCREATE(stx_input_pin,NULL);
		if( !the->p_input_pin ) {
			break;
		}
		XCALL(set_parent,the->p_input_pin,(stx_base_plugin *)&the->stx_base_filter_vt);
		
		i_err = STX_FAIL;

		h_type = XCREATE(base_media_type,NULL,NULL);
		if( !h_type ) {
			break;
		}

		h_type->set_type(h_type,MEDIATYPE_Video);
		h_type->set_subtype(h_type,MEDIASUBTYPE_LxVideoFrame);

		vd2.bmiHeader.biWidth = the->i_output_width;
		vd2.bmiHeader.biHeight = the->i_output_height;
		i_len = sizeof( vd2 );
		i_err = h_type->set_header(h_type,&vd2,i_len);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = XCALL(set_media_type,the->p_input_pin,h_type);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = STX_OK;

	}while(FALSE);

	SAFE_XDELETE(h_type);

	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT initialize_outputpin(CubicResample* the)
{
	STX_RESULT					i_err;
	stx_media_data_allocator*	p_alloc;
	stx_mda_alloc_base_param	prop;
	stx_media_type*             h_type;
	STX_VIDEOINFOHEADER2        vd2;
	s32                         i_len;

	i_err = STX_FAIL;
	p_alloc = NULL;
	h_type = NULL;

	do{
		p_alloc = XCREATE(vfrm_alloc,NULL);
		if( !p_alloc ) {
			break;
		}
		prop.i_mda_num = 1;
		prop.i_mda_size = 0;
		i_err = p_alloc->set_param(p_alloc,&prop,sizeof(prop));
		if( STX_OK != i_err ) {
			break;
		}

		the->p_output_pin = XCREATE(output_pin,NULL);
		if( !the->p_output_pin ) {
			break;
		}
		the->p_output_pin->set_parent(
			the->p_output_pin,(stx_base_plugin*)&the->stx_base_filter_vt);
		i_err = the->p_output_pin->set_mem_allocator(the->p_output_pin,p_alloc);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = STX_FAIL;

		h_type = XCREATE(base_media_type,NULL,NULL);
		if( !h_type ) {
			break;
		}

		h_type->set_type(h_type,MEDIATYPE_Video);
		h_type->set_subtype(h_type,MEDIASUBTYPE_LxVideoFrame);

		vd2.bmiHeader.biWidth = the->i_output_width;
		vd2.bmiHeader.biHeight = the->i_output_height;
		i_len = sizeof( vd2 );
		i_err = h_type->set_header(h_type,&vd2,i_len);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = XCALL(set_media_type,the->p_output_pin,h_type);
		if( STX_OK != i_err ) {
			break;
		}

	}while(FALSE);

	SAFE_XDELETE(p_alloc);
	SAFE_XDELETE(h_type);

	return i_err;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_enum_input_pin
(STX_HANDLE h,sint32* i_index,stx_base_pin** pp_pin)
{
	STX_MAP_THE(CubicResample);

	if( !i_index ) {
		return STX_ERR_INVALID_PARAM;
	}
	if( !pp_pin ) {
		*i_index = 1;
		return STX_OK;
	}
	if( *i_index != 0 ) {
		return STX_ERR_INVALID_PARAM;
	}

	*pp_pin = the->p_input_pin;
	the->p_input_pin->add_ref(the->p_input_pin);
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_send_msg
(STX_HANDLE h,stx_base_message * p_msg)
{
	STX_RESULT	i_err;

	u32			i_msg_type;

	stx_gid		clsid;

	STX_MAP_THE(CubicResample);

	i_err = dispatch_msg(h,p_msg);
	if( i_err < 0 || p_msg->is_msg_closed(p_msg) ){
		return i_err;
	}
	clsid = p_msg->get_msg_dest(p_msg);
	if( IS_EQUAL_GID( clsid, the->cls_gid ) ) {
		return i_err;
	}

	i_msg_type = p_msg->get_msg_type(p_msg);

	if( STX_MSG_TYPE_UPSTREAM & i_msg_type && the->p_input_pin ) {

		i_err = the->p_input_pin->send_msg( the->p_input_pin, p_msg );
	}
	else if( STX_MSG_TYPE_DOWNSTREAM & i_msg_type && the->p_output_pin ){

		i_err = the->p_output_pin->send_msg( the->p_output_pin, p_msg );
	}

	if( i_err < 0 || p_msg->is_msg_closed(p_msg) ) {
		return i_err;
	}

	return response_msg(h,p_msg);
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_enum_output_pin
(STX_HANDLE h,sint32* i_index,stx_base_pin** pp_pin)
{
	STX_MAP_THE(CubicResample);

	if( !i_index ){
		return STX_ERR_INVALID_PARAM;
	}

	if( !pp_pin ) {
		*i_index = 1;
		return STX_OK;
	}

	if( *i_index != 0 ) {
		return STX_ERR_INVALID_PARAM;
	}

	{
		stx_output_pin* p = the->p_output_pin;
		return p->query_interf(p,STX_IID_BasePlugin,(void**)pp_pin);
	}

	return STX_ERR_NOT_IMP;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT	stx_base_filter_vt_xxx_check_input_media_type
(STX_HANDLE h,stx_media_type* p_mtyp)
{
	STX_MAP_THE(CubicResample);
	{
		stx_gid					major_type,sub_type;
		STX_VIDEOINFOHEADER2*	vdr;
		s32						i_len;
		STX_RESULT				i_err;

		major_type = p_mtyp->get_type(p_mtyp);

		if( !is_compatible_gid(MEDIATYPE_Video,major_type)) {
			return STX_ERR_NOT_SUPPORT;
		}

		sub_type = p_mtyp->get_subtype(p_mtyp);

		if( !is_compatible_gid(sub_type,MEDIASUBTYPE_LxVideoFrame)) {
			return STX_ERR_NOT_SUPPORT;
		}

		i_len = 0;

		i_err = p_mtyp->get_header(p_mtyp,&vdr,&i_len);
		if( STX_OK != i_err ) {
			return i_err;
		}

		if( i_len < sizeof(STX_VIDEOINFOHEADER2) ) {
			return STX_ERR_NOT_SUPPORT;
		}

		// check if the video header is initialized;
		if( vdr->bmiHeader.biWidth == 0  || vdr->bmiHeader.biHeight == 0 ) {
			return STX_ERR_INVALID_PARAM;
		}

		return STX_OK;
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT	stx_base_filter_vt_xxx_check_output_media_type
(STX_HANDLE h,stx_media_type* p_mtyp)
{
	STX_MAP_THE(CubicResample);
	{
		stx_gid major_type,sub_type;

		major_type = p_mtyp->get_type(p_mtyp);

		if( !is_compatible_gid(MEDIATYPE_Video,major_type)) {
			return STX_ERR_NOT_SUPPORT;
		}

		sub_type = p_mtyp->get_subtype(p_mtyp);

		if( !is_compatible_gid(sub_type,MEDIASUBTYPE_LxVideoFrame)) {
			return STX_ERR_NOT_SUPPORT;
		}

		return STX_OK;
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_set_input_media_type
( STX_HANDLE h,stx_media_type * p_mtype)
{
	STX_MAP_THE(CubicResample);
	{
		STX_RESULT i_err;

		stx_base_filter* flt = &the->stx_base_filter_vt;

		i_err = flt->check_input_media_type(flt,p_mtype);
		if( STX_OK != i_err ) {
			return i_err;
		}

		i_err = the->p_input_pin->set_media_type(the->p_input_pin,p_mtype);
		if( STX_OK != i_err ) {
			return i_err;
		}

		return STX_OK;
	}

	return STX_ERR_NOT_IMP;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_set_output_media_type
( STX_HANDLE h,stx_media_type * p_media_type)
{
	STX_MAP_THE(CubicResample);
	{
		STX_RESULT				i_err;
		STX_VIDEOINFOHEADER2*	hdr;
		s32						i_size;

		stx_media_type*			p_mtype = NULL;
		stx_media_type*			p_mtype_in = NULL;
		stx_base_filter*		flt = &the->stx_base_filter_vt;

		i_err = flt->check_output_media_type(flt,p_media_type);
		if( STX_OK != i_err ) {
			return i_err;
		}


		i_err = STX_FAIL;

		do{
			p_mtype_in = the->p_input_pin->get_media_type(the->p_input_pin);
			if( !p_mtype_in ) {
				break;
			}

			p_mtype = XCREATE(base_media_type,NULL,p_media_type);
			if( !p_mtype ) {
				break;
			}

			i_err = p_mtype_in->get_header(p_mtype_in,&hdr,&i_size);
			if( STX_OK != i_err ) {
				break;
			}

			hdr->bmiHeader.biWidth = the->i_output_width;
			hdr->bmiHeader.biHeight = the->i_output_height;

			i_err = p_mtype->set_header(p_mtype,hdr,i_size);
			if( STX_OK != i_err ) {
				break;
			}

			i_err = XCALL(set_media_type,the->p_output_pin,p_mtype);

		}while(FALSE);

		SAFE_XDELETE(p_mtype);
		SAFE_XDELETE(p_mtype_in);

		return i_err;
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT	stx_base_filter_vt_xxx_new_segment( STX_HANDLE h)
{
	STX_MAP_THE(CubicResample);

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT	stx_base_filter_vt_plug_xxx_flush
(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	STX_MAP_THE(CubicResample);

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT	stx_base_filter_vt_plug_xxx_start
(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	STX_MAP_THE(CubicResample);

	if( the->p_output_pin ) {
		return XCALL(start,the->p_output_pin,i_flag,h_sync);
	}

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT	stx_base_filter_vt_plug_xxx_stop
(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	STX_MAP_THE(CubicResample);

	if( the->p_output_pin ) {
		return XCALL(stop,the->p_output_pin,i_flag,h_sync);
	}

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_receive
(
	STX_HANDLE			h,
	stx_base_pin*		h_pin, // which input pin;
	stx_media_data**	pp_mdat, // output media data;
	stx_sync_inf*		h_sync
)
{
	STX_MAP_THE(CubicResample);

	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT do_transform
(CubicResample* the,VideoFrame* p_in,VideoFrame* p_out)
{
	STX_RESULT				i_err;
	CUBIC_RESIZE_PARAM		param;
	STX_VIDEOINFOHEADER2*	vdr;
	stx_output_pin*         p_outpin;
	stx_media_type*         p_type;
	s32                     i_len;

	i_err = STX_FAIL;
	INIT_MEMBER(param);
	p_type = STX_NULL;
	p_outpin = the->p_output_pin;


	do{

		p_type = p_outpin->get_media_type(p_outpin);
		if( !p_type ) {
			break;
		}

		i_err = p_type->get_header(p_type,&vdr,&i_len);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = STX_FAIL;// fill parameters;
		{
			s32 i,i_result;

			for( i = 0; i < 3; i ++ ) {
				param.lpSrc[i] = (u8*)p_in->lpData[i];
				param.SrcPitch[i] = p_in->nPitch[i];
				param.lpDst[i] = (u8*)p_out->lpData[i];
				param.DstPitch[i] = p_out->nPitch[i];
			}

			param.SrcWidth[0] = p_in->nCodedPictureWidth;
			param.SrcWidth[1] = p_in->nCodedPictureWidth >> 1;
			param.SrcWidth[2] = p_in->nCodedPictureWidth >> 1;
			param.SrcHeight[0] = p_in->nCodedPictureHeight;
			param.SrcHeight[1] = p_in->nCodedPictureHeight >> 1;
			param.SrcHeight[2] = p_in->nCodedPictureHeight >> 1;
			param.DstWidth[0] = p_out->nCodedPictureWidth;
			param.DstWidth[1] = p_out->nCodedPictureWidth >> 1;
			param.DstWidth[2] = p_out->nCodedPictureWidth >> 1;
			param.DstHeight[0] = p_out->nCodedPictureHeight;
			param.DstHeight[1] = p_out->nCodedPictureHeight >> 1;
			param.DstHeight[2] = p_out->nCodedPictureHeight >> 1;
			//]]


			//[[ make the transform flags;
			param.dwFlags = 0;
			STX_PUT_RESIZE_CODE((param.dwFlags),STX_RESIZE_TRUE);
			STX_PUT_ALG_CODE((param.dwFlags),STX_RESIZE_ALG_BICUB);
			STX_PUT_SIZE_CODE((param.dwFlags),STX_NOT_FAST_SIZE);
			STX_PUT_INPUT_FORMAT((param.dwFlags),STX_FORMAT_YV12);
			STX_PUT_OUTPUT_FORMAT((param.dwFlags),STX_FORMAT_YV12);
			//]]

			if( p_in->DctType ) {
				for( i = 0; i < 3; i ++ ) {
					param.DstHeight[i] >>= 1;
					param.SrcHeight[i] >>= 1;
					param.DstPitch[i] <<= 1;
					param.SrcPitch[i] <<= 1;
				}
				i_result = bicubic_resize(the->h_cubic,&param);
				if( STX_OK != i_result ) {
					break;
				}

				for( i = 0; i < 3; i ++ ) {
					param.lpSrc[i] += p_in->nPitch[i];
					param.lpDst[i] += p_out->nPitch[i];
				}
				i_result = bicubic_resize(the->h_cubic,&param);
				if( STX_OK != i_result ) {
					break;
				}
			}
			else {
				i_result = bicubic_resize(the->h_cubic,&param);
				if( STX_OK != i_result ) {
					break;
				}
			}
		}

		i_err = STX_OK;

	}while(FALSE);

	SAFE_XDELETE(p_type);

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT	stx_base_filter_vt_xxx_deliver
(
	THEE				h,
	stx_base_pin*		h_pin, // which input pin;
	stx_media_data*		p_mdat, // output media data;
	stx_sync_inf*		h_sync
)
{
	STX_MAP_THE(CubicResample);
	{
		the->h_mdat = p_mdat;
		RESET_XENTRY(h_sync,h);
		return STX_OK;
	}
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_ENTRY STX_RESULT at_BreakPin(STX_HANDLE h, stx_base_message* p_msg )
{
	STX_MAP_THE(CubicResample);

	if( the->p_input_pin ) {
		the->p_input_pin->break_connect(the->p_input_pin);
	}

	if( the->p_output_pin ) {
		the->p_output_pin->break_connect(the->p_output_pin);
	}

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT on_play(STX_HANDLE h,stx_base_message* p_msg)
{
	STX_RESULT				i_err;
	stx_media_type*			p_output_type;
	STX_VIDEOINFOHEADER2*	vd2;
	s32                     i_len;

	STX_MAP_THE(CubicResample);

	i_err = STX_FAIL;
	p_output_type = NULL;


	do{
		p_output_type = the->p_output_pin->get_media_type(the->p_output_pin);
		if( !p_output_type ) {
			break;
		}

		i_err = p_output_type->get_header(p_output_type,&vd2,&i_len);
		if( STX_OK != i_err ) {
			break;
		}

		vd2->bmiHeader.biHeight = the->i_output_height;
		vd2->bmiHeader.biWidth = the->i_output_width;

		i_err = STX_OK;

	}while(FALSE);

	SAFE_XDELETE(p_output_type);

	return i_err;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_run
(STX_HANDLE h,stx_sync_inf* h_sync )
{
	STX_MAP_THE(CubicResample);
	{
		STX_RESULT				i_err;

		stx_media_data*			p_mdat_out;
		VideoFrame*				p_frame_in;
		VideoFrame*				p_frame_out;

		stx_output_pin*			p_output_pin;
		stx_media_type*			p_output_type;
		s32						i_len;

		STX_VIDEOINFOHEADER2*	vdr;

		stx_media_data*			p_mdat = the->h_mdat;


		i_err = STX_FAIL;

		p_mdat_out = NULL;
		p_frame_in = STX_NULL;
		p_frame_out = STX_NULL;
		p_output_type = STX_NULL;

		p_output_pin = the->p_output_pin;

		do{

			p_output_type = XCALL(get_media_type,p_output_pin);
			if( !p_output_type ) {
				break;
			}

			i_err = XCALL(get_header,p_output_type,&vdr,&i_len);
			if( STX_OK != i_err ) {
				break;
			}

			i_err = XCALL(query_interf,p_mdat,STX_IID_LxVideoFrame,(void**)&p_frame_in);
			if( STX_OK != i_err ) {
				break;
			}
			SAFE_XDELETE(p_mdat);

			i_err = XCALL(get_media_data,p_output_pin,&p_mdat_out,INFINITE);
			if( STX_OK != i_err ) {
				break;
			}
			i_err = XCALL(query_interf,p_mdat_out,STX_IID_LxVideoFrame,(void**)&p_frame_out);
			if( STX_OK != i_err ) {
				break;
			}
			SAFE_XDELETE(p_mdat_out);


			i_err = STX_FAIL;

			// check video frame size;
			if( vdr->bmiHeader.biHeight != p_frame_out->nCodedPictureHeight ||
				vdr->bmiHeader.biWidth != p_frame_out->nCodedPictureWidth ) {

					s32 i_result = vfrmAjustSurfaceSize(
						p_frame_out,
						vdr->bmiHeader.biWidth,
						vdr->bmiHeader.biHeight, 
						CHROMA420 );

					if( STX_OK != i_result ) {
						break;
					}
			}


			i_err = do_transform(the,p_frame_in,p_frame_out);
			if( STX_OK != i_err ) {
				break;
			}

			// init frame attribute !!!!
			// decode flag, time code;
			p_frame_out->dwFlags = p_frame_in->dwFlags;
			p_frame_out->PresentTimeStamp = p_frame_in->PresentTimeStamp;
			p_frame_out->DecodeTimeStamp = p_frame_in->DecodeTimeStamp;

			{
				s64 pts,dts;
				pts = XCALL(get_time,p_mdat,&dts);
				XCALL(set_time,p_mdat_out,pts,dts);
				pts = XCALL(get_duration,p_mdat);
				XCALL(set_duration,p_mdat_out,pts);
			}

			XCALL(release_media_data,the->p_input_pin,p_mdat);

			i_err = XCALL(deliver,the->p_output_pin, p_mdat_out,h_sync);

		}while(FALSE);

		SAFE_XDELETE(p_output_type);

		if( i_err != STX_OK ) {
			if( p_mdat_out ){
				XCALL(release_media_data,p_output_pin,p_mdat_out);
			}
		}

		return i_err;
	}
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_get_property
(STX_HANDLE h,stx_xio* h_xio)
{
	STX_MAP_THE(CubicResample);
	{
		STX_RESULT i_err;
		stx_xini*  h_xini;
		STX_HANDLE h_prop;
		STX_HANDLE h_rule;
		STX_HANDLE h_sub_rule;
		STX_HANDLE h_group;
		STX_HANDLE h_val;
		b32        b_pin_exclusive = TRUE;
		char       sz_key[1024];

		i_err = STX_FAIL;
		h_xini = NULL;


		do{

			i_err = stx_ini_create(NULL,h_xio,STX_INI_READ_WRITE|STX_INI_NO_COMMENT,0,&h_xini );
			if( STX_INI_OK != i_err ) {
				break;
			}

			// property page = list;
			i_err = h_xini->create_key(h_xini,NULL,(char*)g_szPropertyPage,(char*)g_szControl_list,&h_prop);
			if(STX_INI_OK != i_err ) {
				break;
			}
			// stream rule = radio;
			i_err = h_xini->create_key(h_xini,h_prop,(char*)g_szStreamRule,(char*)g_szControl_radio,&h_rule);
			if(STX_INI_OK != i_err ) {
				break;
			}
			i_err = h_xini->create_key(h_xini,h_rule,(char*)g_szDefaultOption,"0",&h_sub_rule);
			if(STX_INI_OK != i_err ) {
				break;
			}
			i_err = h_xini->create_key(h_xini,h_rule,(char*)g_szCurrentOption,"0",&h_sub_rule);
			if(STX_INI_OK != i_err ) {
				break;
			}

			// 1 rule
			stx_sprintf(sz_key,sizeof(sz_key),"%s-%d",g_szStreamRule,0);
			i_err = h_xini->create_key(h_xini,h_rule,sz_key,(char*)g_szControl_list,&h_sub_rule);
			if(STX_INI_OK != i_err ) {
				break;
			}
			i_err = h_xini->create_key(h_xini,h_sub_rule,(char*)g_szDescription,(char*)g_szExclusive,&h_group);
			if(STX_INI_OK != i_err ) {
				break;
			}

			stx_sprintf(sz_key,sizeof(sz_key),"%s-%d",g_szGroup,0);
			i_err = h_xini->create_key(h_xini,h_sub_rule,sz_key,(char*)g_szControl_list,&h_group);
			if(STX_INI_OK != i_err ) {
				break;
			}

			// input format select = radio;
			i_err = create_stream_rule_exclusive(
				h_xini,
				h_group,
				(char*)g_szInputFormatSelect,
				"input format selection",
				0,
				0,
				1,
				& INPUT_MEDIA_TYPE_MAP_NAME(CubicResample)[1],
				& b_pin_exclusive );

			if(STX_OK != i_err ) {
				break;
			}

			// output format select = radio;
			i_err = create_stream_rule_exclusive(
				h_xini,
				h_group,
				(char*)g_szOutputFormatSelect,
				"output format selection",
				0,
				0,
				1,
				& OUTPUT_MEDIA_TYPE_MAP_NAME(CubicResample)[1],
				& b_pin_exclusive );

			if(STX_OK != i_err ) {
				break;
			}

			// width;
			i_err = h_xini->create_key(h_xini,h_prop,(char*)g_szOutputWidth,(char*)g_szType_s32,&h_rule);
			if(STX_INI_OK != i_err ) {
				break;
			}
			i_err = h_xini->create_key(h_xini,h_rule,(char*)g_szVal,NULL,&h_val);
			if(STX_INI_OK != i_err ) {
				break;
			}
			i_err = h_xini->write_int32(h_xini,h_val,the->i_output_width);
			if(STX_INI_OK != i_err ) {
				break;
			}

			// height;
			i_err = h_xini->create_key(h_xini,h_prop,(char*)g_szOutputHeight,(char*)g_szType_s32,&h_rule);
			if(STX_INI_OK != i_err ) {
				break;
			}
			i_err = h_xini->create_key(h_xini,h_rule,(char*)g_szVal,NULL,&h_val);
			if(STX_INI_OK != i_err ) {
				break;
			}
			i_err = h_xini->write_int32(h_xini,h_val,the->i_output_height);
			if(STX_INI_OK != i_err ) {
				break;
			}

			i_err = STX_OK;

		}while(FALSE);

		if( h_xini ) {
			h_xini->close(h_xini);
		}

		return i_err;
	}

	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_set_property
(STX_HANDLE h,stx_xio* h_xio)
{
	STX_MAP_THE(CubicResample);
	{
		STX_RESULT i_err;
		stx_xini*  h_xini;
		STX_HANDLE h_prop;
		STX_HANDLE h_rule;
		STX_HANDLE h_val;

		i_err = STX_FAIL;
		h_xini = NULL;


		do{
			i_err = stx_ini_create(NULL,h_xio,STX_INI_READ_ONLY|STX_INI_NO_COMMENT,0,&h_xini );
			if( STX_INI_OK != i_err ) {
				break;
			}

			// property page = property page;
			i_err = h_xini->create_key(h_xini,NULL,(char*)g_szPropertyPage,NULL,&h_prop);
			if(STX_INI_OK != i_err ) {
				break;
			}

			// in this version, input and output format have no choice;

			// width;
			i_err = h_xini->create_key(h_xini,h_prop,(char*)g_szOutputWidth,(char*)g_szType_s32,&h_rule);
			if(STX_INI_OK != i_err ) {
				break;
			}
			i_err = h_xini->create_key(h_xini,h_rule,(char*)g_szVal,NULL,&h_val);
			if(STX_INI_OK != i_err ) {
				break;
			}
			i_err = h_xini->read_int32(h_xini,h_val,&the->i_output_width);
			if(STX_INI_OK != i_err ) {
				break;
			}

			// height;
			i_err = h_xini->create_key(h_xini,h_prop,(char*)g_szOutputHeight,(char*)g_szType_s32,&h_rule);
			if(STX_INI_OK != i_err ) {
				break;
			}
			i_err = h_xini->create_key(h_xini,h_rule,(char*)g_szVal,NULL,&h_val);
			if(STX_INI_OK != i_err ) {
				break;
			}
			i_err = h_xini->read_int32(h_xini,h_val,&the->i_output_height);
			if(STX_INI_OK != i_err ) {
				break;
			}

			i_err = STX_OK;

		}while(FALSE);

		if( h_xini ) {
			h_xini->close(h_xini);
		}

		return i_err;
	}

	return STX_ERR_NOT_SUPPORT;
}
