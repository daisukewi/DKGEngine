/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
**********************************************************************************/
#include "stdio.h"
#include "stdlib.h"
#include "fcntl.h"
#include "malloc.h"
#include "memory.h"
#include "string.h"


#include "stx_io.h"
#include "stx_mem.h"
#include "stx_debug.h"
#include "stx_io_stream.h"


#include "stx_h264_preroll.h"
#include "h264data.h"

#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
#define H264_NAL_SEI     0x106
#define H264_NAL_SPS     0x107
#define H264_NAL_PPS     0x108
#define H264_NAL_DELIM   0x109

bool32 ff_avc_find_startcode(
                             uint8**      p, 
                             uint8*       end, 
                             uint32*      b_start,
                             uint32*      start_code )
{
    uint32 code,code1;

    uint8* pp;

    bool32 b_found;


    code = *start_code;

    pp = *p;

    b_found = FALSE;

    while( pp < end ) {

        code = code << 8 | *pp;

        code1 = code & 0xFFFFFF1F;

        if( code1 == 0x101 || code1 == 0x102 ||  code1 == 0x105 ) {	
            /* idr slice; */
            if( *b_start ) {
                b_found = TRUE;
                break;
            }

            *b_start = TRUE;
        }
        else if( (code1 & 0xFFFFFF00) == 0x100 ) {

            if( code1 == H264_NAL_SEI || code1 == H264_NAL_SPS || 
                code1 == H264_NAL_PPS || code1 == H264_NAL_DELIM) {

                    if( *b_start ) {
                        b_found = TRUE;
                        break;
                    }
            }			
        }

        pp ++ ;
    }

    *start_code = code;

    *p = pp;

    return b_found;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

bool32 ff_avc_parse_nal_units(
                              uint8*       buf_in, 
                              size_t       i_size, 
                              size_t*      i_used,
                              uint32*      b_start,
                              uint32*      start_code, 
                              stx_xio*     p_stream )
{
    ByteIOContext   _pb;
    uint8           pb_buf[128];
    ByteIOContext   *pb;

    uint8          *nal_start;
    uint8          *p;
    uint8          *end;

    bool32			b_found;
	size_t			i_write;

    p = buf_in;
    end = p + i_size;

    INIT_BYTEIO_W(_pb,sizeof(pb_buf),pb_buf,p_stream);
    pb = &_pb;

    nal_start = p;

    b_found = ff_avc_find_startcode( &nal_start, end, b_start, start_code );

    if( b_found ) {

        *b_start = FALSE;

        /*found;*/
        nal_start ++;

        if( nal_start > p + 4 ) {

            p_stream->write( p_stream,(void*)p, nal_start - p - 4, &i_write );
        }
    }
    else if(*b_start) {

        p_stream->write( p_stream,(void*)p, nal_start - p, &i_write );
    }

    *i_used = nal_start - p;

    return b_found ;
}




STX_INTERF(stx_h264_preroll_ctx);


struct stx_h264_preroll_ctx{

    H264Context         m_H264Ctx;

    SPS                m_H264Sps;

    ByteIOContext       m_VidStream;

    u8                 vid_buf[2048];

    ByteIOContext       m_RbspStream;

    u8*                m_pRbspBuf;

    s32                m_nRbspBufSize;

    s32                m_nRbspDataLen;


    u32                start_code;

    u32                b_start;

    stx_xio*           p_frame_io;
};


STX_PRIVATE s32 GetSeGolomb(ByteIOContext* pb);

STX_PRIVATE s32 GetUeGolomb(ByteIOContext* pb);

STX_PRIVATE s32 DecRbspTrailing(u8 *src);

STX_PRIVATE STX_RESULT DecodeNalRbsp( stx_h264_preroll_ctx* the );

STX_PRIVATE void       DecodeHRDPS(ByteIOContext* pb, HRDPS *hrdps );

STX_PRIVATE STX_RESULT DecodeVUIPS(ByteIOContext* pb,SPS* sps);

STX_PRIVATE STX_RESULT DecodeSPS(stx_h264_preroll_ctx* the);




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_API THEE stx_h264_preroll_create()
{
    STX_RESULT i_err;

    stx_h264_preroll_ctx* the;


    i_err = STX_FAIL;

    the = STX_NULL;


    do {

        the = (stx_h264_preroll_ctx*)xmallocz(sizeof(stx_h264_preroll_ctx));
        if( !the ) {
            break;
        }

        INIT_MEMBER(the->m_H264Ctx);

        INIT_MEMBER(the->m_H264Sps);


        the->p_frame_io = XCREATE(stx_io_stream,NULL);

        if( !the->p_frame_io ) {

            break;
        }


        the->m_nRbspBufSize = 2048;

        the->m_pRbspBuf = (u8*)xlivAlloc( the->m_nRbspBufSize + 8,TRUE,16 );

        if( ! the->m_pRbspBuf ) {

            break;
        }

        the->m_nRbspDataLen = 0;

        i_err = STX_OK;

    }while(FALSE);

    if( STX_OK != i_err ) {

        if( the ) {

           stx_h264_preroll_close( (THEE) the );
        }

        return STX_NULL;
    }

    return (THEE) the ;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_API void stx_h264_preroll_close(THEE h)
{
    STX_DIRECT_THE(stx_h264_preroll_ctx);

    if( the->m_pRbspBuf ) {

        stx_free(the->m_pRbspBuf );
    }

    stx_free( the );
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_API SPS* stx_h264_preroll_get_sps(THEE h)
{
    STX_DIRECT_THE(stx_h264_preroll_ctx);

    return &the->m_H264Sps;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_API STX_RESULT stx_h264_preroll_decode_pack(THEE h,u8* buf,size_t i_len )
{
    ByteIOContext* pRbspStream;

    ByteIOContext* pVidStream;

    u8*           pData;

    size_t        i_frame_len;

    u8*           buf_ptr;

    size_t        i_data_len,i_used;

    b32           b_found;

	stx_io_op_param set_inf;


    STX_DIRECT_THE(stx_h264_preroll_ctx);


    pRbspStream = &the->m_RbspStream;

    pVidStream = &the->m_VidStream;


    i_data_len = i_len;

    buf_ptr = buf;


    while( i_data_len ) {

        b_found = ff_avc_parse_nal_units(
            buf_ptr,
            i_data_len,
            &i_used,
            &the->b_start,
            &the->start_code,
            the->p_frame_io );

        i_data_len -= i_used;
        buf_ptr += i_used;

        if( ! b_found ) {

            continue;

        } /*if( ! b_found ) {*/


		the->p_frame_io->get(the->p_frame_io,STX_IO_READ_P,&set_inf);

		pData = set_inf.buf;

		i_frame_len = set_inf.i_buf_size;

        INIT_BYTEIO_R(the->m_VidStream,sizeof(the->vid_buf),the->vid_buf,the->p_frame_io);

        // init stream;
        init_get_bits(pVidStream);

        // decode nal unit;

        for( ; ; )	{

            s32      dst_length;

            s32      bit_length;

            u8*      ptr;

            // see annex B, Byte stream format
            while( 0x01 != show_bits(pVidStream,24) && 0x01 != show_bits32(pVidStream) ){
                
                if( pVidStream->nCurrentBit <= 0 ) {
                    
                    the->p_frame_io->clear(the->p_frame_io);
                    
                    return STX_IDLE;
                }

                get_bits(pVidStream,8);
            }

            if( 0x01 != show_bits(pVidStream,24 ) ) {
                
                get_bits(pVidStream,8);
            }

            get_bits(pVidStream,24);

            if( DecodeNalRbsp(the) < 0 ) {

                the->p_frame_io->clear(the->p_frame_io);

                return STX_FAIL;
            }

            // save rbsp stream;
            dst_length = the->m_nRbspDataLen;

            ptr = the->m_pRbspBuf;

            if( ptr[dst_length - 1] == 0 ) { 

                // trailing_zero_8bits /* equal to 0x00 */
                dst_length --;
            }

            bit_length = 8 * dst_length - DecRbspTrailing( ptr + dst_length - 1 );

            // if is sps, decode sps;
            if( NAL_SPS == the->m_H264Ctx.nal_unit_type ) {

                the->p_frame_io->clear(the->p_frame_io);

                INIT_BYTEIO_R(the->m_RbspStream,bit_length / 8,the->m_pRbspBuf,STX_NULL);

                init_get_bits(pRbspStream);

                return DecodeSPS(the);
            }

        }/*for( ; ; )	{*/

    }/*while( i_data_len ) {*/

    return STX_IDLE;
}





/*******************************************************************************************
STX_PRIVATE STX_RESULT DecodeNalRbsp( stx_h264_preroll_ctx* the )
* Decodes a network abstraction layer unit.
* @param consumed is the number of bytes used as input
* @param length is the length of the array
* @param dst_length is the number of decoded bytes FIXME here or a decode rbsp trailing?
* @returns decoded bytes, might be src+1 if no escapes 
*******************************************************************************************/
STX_PRIVATE STX_RESULT DecodeNalRbsp( stx_h264_preroll_ctx* the )
{	
    u8 *dst;

    u32 dwCode;

    ByteIOContext* const pStream = &the->m_RbspStream;

    s32  length = ( ( the->m_VidStream.nCurrentBit + 7 ) >> 3 ) + 
        (s32)( the->m_VidStream.pio->size(the->m_VidStream.pio) - 
        the->m_VidStream.pio->seek(the->m_VidStream.pio,0,SEEK_CUR) );

    the->m_nRbspDataLen = 0;

    if( the->m_nRbspBufSize < length ){

        // nSize is aligned to 2k , increase size by 2k;

        s32 nSize = ( ( length + 2047 ) & ~2047 ) + 2048; 

        u8* buf = (u8*)xlivAlloc( nSize ,TRUE, 16 );
        if( ! buf ) {
            return STX_FAIL;
        }

        if( the->m_pRbspBuf ){
            xlivFree(the->m_pRbspBuf);
        }

        the->m_pRbspBuf = buf;

        the->m_nRbspBufSize = nSize;
    }

    dst = the->m_pRbspBuf;

    get_bits(pStream,1); //  src[0] & 0x80;		//forbidden bit

    the->m_H264Ctx.nal_ref_idc   = get_bits(pStream,2);  //  src[0] >> 5;

    the->m_H264Ctx.nal_unit_type = get_bits(pStream,5);  //  src[0] & 0x1F;

    // get rbsp data;

    for( ; ; ) {

        if( the->m_VidStream.nCurrentBit <= 0 ) {

            break;  // packet end;
        }

        if( the->m_VidStream.nCurrentBit < 24 ) {

            *dst ++ = (u8)get_bits(pStream,8);

            continue;
        }

        dwCode = show_bits(pStream,24);

        if( dwCode == 0x03 ) {

            *dst ++ = 0; 
            *dst ++ = 0; 

            get_bits(pStream,24);  // 00 00 escape;

            continue;
        }

        if( dwCode < 0x03 ) { 

            break;  // found start code;
        }

        *dst ++ = (u8)get_bits(pStream,8);
    }

    the->m_nRbspDataLen = (s32)(dst - the->m_pRbspBuf);

    return STX_OK;
}



/*******************************************************************************************
STX_PRIVATE s32 GetSeGolomb(stx_h264_preroll_ctx* the)
* read signed exp golomb code.
*******************************************************************************************/
STX_PRIVATE s32 GetSeGolomb(ByteIOContext* pb)
{
    u32    dwCode;
    s32    log;

    dwCode = show_bits32(pb);

    if( dwCode >= (1<<27) )	{

        dwCode >>= 32-9;

        get_bits(pb,ff_golomb_vlc_len[dwCode]);

        return ff_se_golomb_vlc_code[dwCode];
    }

    log = ( av_log2(dwCode) << 1 ) - 31;

    dwCode >>= log;

    get_bits(pb,32 - log);

    return (dwCode & 1) ?  -(s32)(dwCode >> 1) : (dwCode >> 1);
}

/*******************************************************************************************
STX_PRIVATE s32 GetUeGolomb(stx_h264_preroll_ctx* the)
* read unsigned exp golomb code.
*******************************************************************************************/
STX_PRIVATE s32 GetUeGolomb(ByteIOContext* pb)
{
    u32    dwCode;
    s32    log;

    dwCode = show_bits32(pb);

    if( dwCode >= (1<<27) )	{

        dwCode >>= (32-9);

        get_bits(pb,ff_golomb_vlc_len[dwCode]);

        return ff_ue_golomb_vlc_code[dwCode];
    }

    log = ( av_log2(dwCode) << 1 ) - 31;

    dwCode >>= log;

    dwCode --;

    get_bits(pb,32 - log);

    return dwCode;
}


/*******************************************************************************************
STX_PRIVATE void DecodeHRDPS(stx_h264_preroll_ctx* the, HRDPS *hrdps )
*******************************************************************************************/
STX_PRIVATE void DecodeHRDPS(ByteIOContext* pb, HRDPS *hrdps )
{

    s32 i;

    hrdps->cpb_count = GetUeGolomb(pb) + 1;

    hrdps->cpb_count = hrdps->cpb_count > 32 ? 32 : hrdps->cpb_count;

    hrdps->bit_rate_scale = get_bits(pb,4); 
    /* bit_rate_scale */

    hrdps->cpb_size_scale = get_bits(pb,4); 
    /* cpb_size_scale */

    for( i = 0; i < hrdps->cpb_count; i ++ ){

        hrdps->bit_rate_value_minus1[i] = GetUeGolomb(pb); 
        /* bit_rate_value_minus1 */

        hrdps->cpb_size_value_minus1[i] = GetUeGolomb(pb); 
        /* cpb_size_value_minus1 */

        hrdps->cbr_flag[i] = get_bits(pb,1);     
        /* cbr_flag */
    }

    hrdps->initial_cpb_removal_delay_length_minus1 = get_bits(pb,5); 
    /* initial_cpb_removal_delay_length_minus1 */

    hrdps->cpb_removal_delay_length_minus1 = get_bits(pb,5); 
    /* cpb_removal_delay_length_minus1 */

    hrdps->dpb_output_delay_length_minus1 = get_bits(pb,5); 
    /* dpb_output_delay_length_minus1 */

    hrdps->time_offset_length = get_bits(pb,5); 
    /* time_offset_length */
}

/*******************************************************************************************
STX_PRIVATE STX_RESULT DecodeVUIPS(stx_h264_preroll_ctx *the)
*******************************************************************************************/
STX_PRIVATE STX_RESULT DecodeVUIPS(ByteIOContext* pb, SPS* sps)
{
    s32 aspect_ratio_info_present_flag,aspect_ratio_idc;

    s32 nal_hrd_parameters_present_flag,vcl_hrd_parameters_present_flag; 

    aspect_ratio_info_present_flag = get_bits(pb,1);

    if( aspect_ratio_info_present_flag ) {

        aspect_ratio_idc = get_bits(pb,8);

        if( aspect_ratio_idc == EXTENDED_SAR ) 	{

            sps->sar.num = get_bits(pb,16);

            sps->sar.den = get_bits(pb,16);
        }
        else if(aspect_ratio_idc < 16)	{

            sps->sar =  pixel_aspect[aspect_ratio_idc];
        }
        else	{
            return STX_FAIL;
        }

    }
    else{
        sps->sar.num = 
            sps->sar.den = 0;
    }

    if(sps->overscan_info_present_flag = get_bits(pb,1)){ 

        /* overscan_info_present_flag */

        sps->overscan_appropriate_flag = get_bits(pb,1);      
        /* overscan_appropriate_flag */
    }

    if(sps->video_signal_type_present_flag = get_bits(pb,1)){  

        /* video_signal_type_present_flag */

        sps->video_format = get_bits(pb,3);      
        /* video_format */

        sps->video_full_range_flag = get_bits(pb,1);      
        /* video_full_range_flag */

        if(sps->colour_description_present_flag = get_bits(pb,1)){  
            /* colour_description_present_flag */

            sps->colour_primaries = get_bits(pb,8);  
            /* colour_primaries */

            sps->transfer_characteristics = get_bits(pb,8);  
            /* transfer_characteristics */

            sps->matrix_coefficients = get_bits(pb,8);  
            /* matrix_coefficients */
        }
    }

    if(sps->chroma_location_info_present_flag = get_bits(pb,1)){  

        /* chroma_location_info_present_flag */

        /* chroma_sample_location_type_top_field */
        sps->chroma_sample_location_type_top_field = GetUeGolomb(pb);  

        /* chroma_sample_location_type_bottom_field */
        sps->chroma_sample_location_type_bottom_field = GetUeGolomb(pb);  

    }

    sps->timing_info_present_flag = get_bits(pb,1);

    if(sps->timing_info_present_flag){

        sps->num_units_in_tick = get_bits(pb,32);

        sps->time_scale = get_bits(pb,32);

        sps->fixed_frame_rate_flag = get_bits(pb,1);
    }


    if( nal_hrd_parameters_present_flag = get_bits(pb,1) ){

        DecodeHRDPS( pb, &sps->nal_hrdps);
    }

    if(vcl_hrd_parameters_present_flag = get_bits(pb,1) ){

        DecodeHRDPS( pb, &sps->vcl_hrdps );
    }

    if(nal_hrd_parameters_present_flag || vcl_hrd_parameters_present_flag){

        sps->low_delay_hrd_flag = get_bits(pb,1);     
        /* low_delay_hrd_flag */
    }

    sps->pic_struct_present_flag = get_bits(pb,1);         
    /* pic_struct_present_flag */

    sps->bitstream_restriction_flag = get_bits(pb,1);

    if(sps->bitstream_restriction_flag){

        sps->motion_vectors_over_pic_boundaries_flag = get_bits(pb,1);
        /* motion_vectors_over_pic_boundaries_flag */
        
        sps->max_bytes_per_pic_denom = GetUeGolomb(pb);   
        /* max_bytes_per_pic_denom */
        
        sps->max_bits_per_mb_denom = GetUeGolomb(pb);   
        /* max_bits_per_mb_denom */
        
        sps->log2_max_mv_length_horizontal = GetUeGolomb(pb);  
        /* log2_max_mv_length_horizontal */
        
        sps->log2_max_mv_length_vertical = GetUeGolomb(pb);   
        /* log2_max_mv_length_vertical */
        
        sps->num_reorder_frames = GetUeGolomb(pb);
        
        sps->max_dec_frame_buffering = GetUeGolomb(pb); 
        /* max_dec_frame_buffering */
    }	

    return STX_OK;
}


/*******************************************************************************************
STX_PRIVATE STX_RESULT DecodeSPS(stx_h264_preroll_ctx* the)
*******************************************************************************************/
STX_API s32 stx_h264_decode_sps(ByteIOContext* pb, SPS* sps)
{
	s32  profile_idc, level_idc;
	s32  sps_id, i;

	profile_idc = get_bits(pb,8);

	get_bits(pb,1);   // constraint_set0_flag
	get_bits(pb,1);   // constraint_set1_flag
	get_bits(pb,1);   // constraint_set2_flag
	get_bits(pb,5);   // reserved

	level_idc = get_bits(pb,8);

	sps_id = GetUeGolomb(pb);

	sps->profile_idc = profile_idc;
	sps->level_idc = level_idc;

	sps->log2_max_frame_num = GetUeGolomb(pb) + 4;

	sps->nPicOrderCntType = GetUeGolomb(pb);

	if(sps->nPicOrderCntType == 0){ //FIXME #define

		sps->log2_max_poc_lsb = GetUeGolomb(pb) + 4;

	} 
	else if(sps->nPicOrderCntType == 1){//FIXME #define

		sps->delta_pic_order_always_zero_flag = get_bits(pb,1);

		sps->offset_for_non_ref_pic = GetSeGolomb(pb);

		sps->offset_for_top_to_bottom_field = GetSeGolomb(pb);

		sps->poc_cycle_length = GetUeGolomb(pb);

		for(i=0; i<sps->poc_cycle_length; i++){

			sps->offset_for_ref_frame[i] = (s16)GetSeGolomb(pb);
		}
	}

	if(sps->nPicOrderCntType > 2){

		return STX_FAIL;
	}

	sps->ref_frame_count = GetUeGolomb(pb);

	sps->gaps_in_frame_num_allowed_flag = get_bits(pb,1);

	sps->mb_width = GetUeGolomb(pb) + 1;

	sps->mb_height = GetUeGolomb(pb) + 1;

	sps->frame_mbs_only_flag = get_bits(pb,1);

	if(!sps->frame_mbs_only_flag){

		sps->mb_aff = get_bits(pb,1);
	}
	else{
		sps->mb_aff = 0;
	}

	sps->direct_8x8_inference_flag = get_bits(pb,1);

	sps->crop = get_bits(pb,1);

	if(sps->crop){
		sps->crop_left  = GetUeGolomb(pb);
		sps->crop_right = GetUeGolomb(pb);
		sps->crop_top   = GetUeGolomb(pb);
		sps->crop_bottom= GetUeGolomb(pb);
	}
	else{
		sps->crop_left  = 
			sps->crop_right = 
			sps->crop_top   = 
			sps->crop_bottom= 0;
	}

	sps->vui_parameters_present_flag = get_bits(pb,1);

	if( sps->vui_parameters_present_flag ){
		DecodeVUIPS(pb,sps);
	}

	return sps_id | (sps->profile_idc<<8) | (sps->level_idc<<16);
}



STX_PRIVATE STX_RESULT DecodeSPS(stx_h264_preroll_ctx* the)
{
    s32  profile_idc, level_idc;

    s32  i;

    SPS* sps = &the->m_H264Sps;

    ByteIOContext* pRbspStream = &the->m_RbspStream;

    sps->profile_idc = get_bits(pRbspStream,8);

    get_bits(pRbspStream,1);   // constraint_set0_flag
    get_bits(pRbspStream,1);   // constraint_set1_flag
    get_bits(pRbspStream,1);   // constraint_set2_flag
    get_bits(pRbspStream,5);   // reserved

    sps->level_idc = get_bits(pRbspStream,8);

    sps->sps_id = GetUeGolomb(pRbspStream);

    sps->log2_max_frame_num = GetUeGolomb(pRbspStream) + 4;

    sps->nPicOrderCntType = GetUeGolomb(pRbspStream);

    if(sps->nPicOrderCntType == 0){ //FIXME #define

        sps->log2_max_poc_lsb = GetUeGolomb(pRbspStream) + 4;

    } 
    else if(sps->nPicOrderCntType == 1){//FIXME #define

        sps->delta_pic_order_always_zero_flag = get_bits(pRbspStream,1);

        sps->offset_for_non_ref_pic = GetSeGolomb(pRbspStream);

        sps->offset_for_top_to_bottom_field = GetSeGolomb(pRbspStream);

        sps->poc_cycle_length = GetUeGolomb(pRbspStream);

        for(i=0; i<sps->poc_cycle_length; i++){

            sps->offset_for_ref_frame[i] = (s16)GetSeGolomb(pRbspStream);
        }
    }

    if(sps->nPicOrderCntType > 2){

        return STX_FAIL;
    }

    sps->ref_frame_count = GetUeGolomb(pRbspStream);

    sps->gaps_in_frame_num_allowed_flag = get_bits(pRbspStream,1);

    sps->mb_width = GetUeGolomb(pRbspStream) + 1;

    sps->mb_height = GetUeGolomb(pRbspStream) + 1;

    sps->frame_mbs_only_flag = get_bits(pRbspStream,1);

    if(!sps->frame_mbs_only_flag){

        sps->mb_aff = get_bits(pRbspStream,1);
    }
    else{
        sps->mb_aff = 0;
    }

    sps->direct_8x8_inference_flag = get_bits(pRbspStream,1);

    sps->crop = get_bits(pRbspStream,1);

    if(sps->crop){

        sps->crop_left  = GetUeGolomb(pRbspStream);

        sps->crop_right = GetUeGolomb(pRbspStream);

        sps->crop_top   = GetUeGolomb(pRbspStream);

        sps->crop_bottom= GetUeGolomb(pRbspStream);
    }
    else{
        sps->crop_left  = 
            sps->crop_right = 
            sps->crop_top   = 
            sps->crop_bottom= 0;
    }

    sps->vui_parameters_present_flag = get_bits(pRbspStream,1);

    if( sps->vui_parameters_present_flag ){

        DecodeVUIPS(pRbspStream,sps);
    }

    return STX_OK;
}



/*******************************************************************************************
static s32 DecRbspTrailing(u8 *src)
* identifies the exact end of the bit stream
* @return the length of the trailing, or 0 if damaged
*******************************************************************************************/
STX_PRIVATE s32 DecRbspTrailing(u8 *src)
{
    s32 nRear;

    s32 nValue = *src;

    //  TRACE1("rbsp trailing %X\n", nValue);

    for( nRear = 1; nRear < 9; nRear ++ ) {

        if( nValue & 1 ) {

            return nRear;
        }

        nValue >>= 1;
    }

    return 0;
}