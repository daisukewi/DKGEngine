/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-10
***********************************************************************************/

#include "stx_all.h"

#ifndef __APP_WND_H__
#define __APP_WND_H__



#if defined( __cplusplus )
extern "C" {
#endif


	enum stx_app_cmd{
		STXM_WCMD,
		STXM_SET_DST_RECT,
		STXM_GET_CAPS,
		STXM_GET_STATUS,
		STXM_SHOW_RENDER,
		STXM_CLOSE,
	};




	STX_INTERF(stx_app_wnd_callback);

#define stx_app_wnd_callback_vtdef() \
	stx_base_com_vtdef()\
	_STX_PURE STX_RESULT (*cmd)(THEE h,size_t i_cmd,size_t i_wparam,size_t i_lparam);

	struct stx_app_wnd_callback{
		stx_app_wnd_callback_vtdef()
	};

#define stx_app_wnd_callback_funcdecl(PREFIX) \
	stx_base_com_funcdecl(PREFIX ## _ ## com);\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## cmd(THEE h,size_t i_cmd,size_t i_wparam,size_t i_lparam)

#define stx_app_wnd_callback_vtinit(vt,PREFIX) \
	STX_VT_INIT(vt,PREFIX,cmd)

#define stx_app_wnd_callback_data_default()			\
	stx_base_com_data_default()

#define stx_app_wnd_callback_funcimp_default(SCOM,PREFIX)			\
	stx_base_com_funcimp_default(SCOM,PREFIX ## _ ## com )\

#define stx_app_wnd_callback_create_default(vt,PREFIX,CLS,CAT,NAME)		\
	stx_base_com_create_default(vt,PREFIX ## _ ## com,CLS,CAT,NAME); \
	stx_app_wnd_callback_vtinit(vt,PREFIX)

#define stx_app_wnd_callback_release_default(SCOM)			\
	stx_base_com_release_default(SCOM)\

#define stx_app_wnd_callback_release_begin(SCOM)			\
	stx_base_plugin_release_begin(SCOM)\

#define stx_app_wnd_callback_release_end(SCOM)			\
	stx_base_com_release_end(SCOM)\

#define stx_app_wnd_callback_query_default(SCOM,vt)			\
	if( IS_EQUAL_GID(gid,STX_IID_AppWndCallback) ) {\
		the->i_ref ++;\
		*pp_interf = (void*)&vt;\
		return STX_OK;\
	}\
	stx_base_com_query_default(SCOM,vt)\

	DECLARE_XGUID(STX_IID_AppWndCallback,
	0x3e1bd264, 0xf1c, 0x4e99, 0x85, 0x9f, 0xda, 0x6b, 0x48, 0xd2, 0x6b, 0x3b)



#ifdef __WIN32_LIB

	#define WM_PLAY    		WM_USER + 1200
	#define WM_STOP    		WM_USER + 1210
	#define WM_PAUSE    	WM_USER + 1220
	#define WM_RESUME    	WM_USER + 1230

	b32					init_app_wnd_env();
	void				close_app_wnd_env();
	stx_base_plugin*	app_wnd_from_hwnd(HWND hWnd);
	STX_RESULT			add_app_wnd(stx_base_plugin* pVidWnd,HWND hWnd );
	void				rem_app_wnd(stx_base_plugin* pVidWnd);
	stx_base_plugin*	app_wnd_from_hwnd(HWND hWnd);


	STX_API	STX_COM(app_wnd);

	STX_API CREATE_STX_COM_DECL(stx_base_plugin,app_wnd);

#endif // __WIN32_LIB



#if defined( __cplusplus )
}
#endif


#endif // __APP_WND_H__