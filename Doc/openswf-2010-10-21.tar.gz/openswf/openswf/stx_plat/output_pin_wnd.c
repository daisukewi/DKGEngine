/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-10
***********************************************************************************/
#include "base_pin_wnd.h"
#include "output_pin_wnd.h"

#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif

extern STX_RESULT	base_pin_wnd_initialize
	(STX_HANDLE h,stx_xini* h_xini,STX_HANDLE h_parent);

extern STX_RESULT	base_pin_wnd_serialize
	(STX_HANDLE h,stx_xini* h_xini,STX_HANDLE h_parent);

extern void base_pin_wnd_SetPin(STX_HANDLE h,stx_base_pin* pin);
extern void base_pin_wnd_move(STX_HANDLE h,s32 x,s32 y);

extern stx_base_pin*	base_pin_wnd_GetPin(STX_HANDLE h);
extern void				base_pin_wnd_ReleasePin(STX_HANDLE h);
extern POINT			base_pin_wnd_GetPoint(STX_HANDLE h);




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

static stx_base_pin* output_pin_wnd_GetPin(STX_HANDLE h)
{
	STX_DIRECT_THE(output_pin_wnd);
	return (stx_base_pin*)the->m_hOutputPin;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

static void output_pin_wnd_SetPin(STX_HANDLE h,stx_base_pin* pin) 
{
	STX_DIRECT_THE(output_pin_wnd);
	the->m_hOutputPin = (stx_output_pin*)pin;
	pin->add_ref(pin);
	base_pin_wnd_SetPin(h,pin);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

static void output_pin_wnd_ReleasePin(STX_HANDLE h)
{
	STX_DIRECT_THE(output_pin_wnd);
	SAFE_XDELETE(the->m_hOutputPin);
	the->m_hOutputPin = NULL;
	base_pin_wnd_ReleasePin(h);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

static POINT output_pin_wnd_GetPoint(STX_HANDLE h)
{
	STX_DIRECT_THE(output_pin_wnd);
	{
		POINT p = { 
			the->m_pos.right,
			the->m_pos.top + (the->m_pos.bottom-the->m_pos.top) / 2 
		};
		return p;
	}
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

static void output_pin_wnd_Close(STX_HANDLE h)
{
	STX_DIRECT_THE(output_pin_wnd);

	SAFE_XDELETE0(the->m_hOutputPin);
	base_pin_wnd_close(the);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
output_pin_wnd* create_output_pin_wnd(HWND hwnd)
{
	output_pin_wnd* the = (output_pin_wnd*)create_base_pin_wnd(sizeof(output_pin_wnd),hwnd);
	if( !the ) {
		return NULL;
	}

	the->close = output_pin_wnd_Close;
	the->GetPin = output_pin_wnd_GetPin;
	the->SetPin = output_pin_wnd_SetPin;
	the->ReleasePin = output_pin_wnd_ReleasePin;
	the->GetPoint = output_pin_wnd_GetPoint;

	the->m_bOutput = TRUE;

	the->m_hOutputPin = NULL;

	return the;
}



