/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/
#include "stdio.h"
#include "stdlib.h"
#include "fcntl.h"
#include "memory.h"
#include "string.h"

#include "stx_mem.h"
#include "stx_debug.h"
#include "stx_mutex.h"
#include "stx_semaphore.h"
#include "stx_io_tcp.h"
#include "stx_io_stream.h"
#include "stx_io_file.h"
#include "stx_io_as.h"
#include "stx_module_reg.h"
#include "stx_direct_pin.h"
#include "stx_output_pin.h"
#include "stx_mem_alloc_base.h"
#include "stx_media_type_base.h"
#include "stx_message.h"
#include "stx_os.h"

#include "stx_filter_graph.h"
#include "stx_graph_builder.h"
#include "stx_sync_source.h"

#include "stx_async_loader.h"


#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif

static char* g_sz_AsyncLoader = "StreamX AsyncLoader";

// {FE46CC3A-BF6C-492e-9D26-F1575A1B924F}
DEFINE_XGUID( STX_CLSID_AsLoader,
	0xfe46cc3a, 0xbf6c, 0x492e, 0x9d, 0x26, 0xf1, 0x57, 0x5a, 0x1b, 0x92, 0x4f);

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API_IMP CREATE_STX_COM(stx_base_plugin,STX_IID_BasePlugin,async_loader);


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_COM_BEGIN(async_loader);

	STX_PUBLIC(stx_base_plugin)
	STX_COM_DATA_DEFAULT(stx_base_plugin)

	char*				sz_url;
	stx_base_source*	h_entry;

STX_COM_END();



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_COM_FUNC_DECL_DEFAULT(stx_base_plugin,stx_base_plugin_vt);

STX_COM_FUNCIMP_DEFAULT(async_loader,stx_base_plugin,stx_base_plugin_vt);


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_COM_MAP_BEGIN(async_loader)
/**/STX_COM_MAP_ITEM(STX_IID_BasePlugin)
STX_COM_MAP_END()

STX_NEW_BEGIN(async_loader)
{
	STX_COM_NEW_DEFAULT(stx_base_plugin,the->stx_base_plugin_vt,stx_base_plugin_vt,
		STX_CLSID_AsLoader,STX_CATEGORY_BaseIo,g_sz_AsyncLoader);


}
STX_NEW_END()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_QUERY_BEGIN(async_loader)
{
	STX_COM_QUERY_DEFAULT(stx_base_plugin,the->stx_base_plugin_vt);
}
STX_QUERY_END()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_DELETE_BEGIN(async_loader)
{

	if( the->sz_url ) {
		stx_free( the->sz_url);
	}
	SAFE_XDELETE(the->h_entry);

	STX_COM_DELETE_DEFAULT(stx_base_plugin);
}
STX_DELETE_END
(
STX_COM_DELETE_BEGIN(stx_base_plugin)
 ,
STX_COM_DELETE_END(stx_base_plugin)
)



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_plugin_vt_xxx_send_msg
(STX_HANDLE h,stx_base_message *p_msg)
{
	STX_MAP_THE(async_loader);

	// to do;
	{
		stx_msg_cnt* cnt = p_msg->get_msg_cnt(p_msg);

		if( IS_EQUAL_GID( cnt->msg_gid , STX_MSG_LoadSourceAs ) ) {

			stx_base_source* h_src;
			char* sz_url;

			h_src = (stx_base_source*)cnt->param.i_param[0];
			h_src->add_ref(h_src);
			the->h_entry = h_src;

			sz_url = (char*)cnt->param.i_param[1];
			the->sz_url = xstrdup(sz_url);
			if( !the->sz_url ) {
				return STX_FAIL;
			}

			p_msg->set_msg_close(p_msg);

			return STX_OK;
		}
	}

	return STX_ERR_NOT_SUPPORT;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_plugin_vt_xxx_run
(STX_HANDLE h,stx_sync_inf* h_sync)
{
	STX_MAP_THE(async_loader);

	return the->h_entry->load_stream(the->h_entry,the->sz_url,h_sync );
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_plugin_vt_xxx_flush
(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	STX_MAP_THE(async_loader);

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_plugin_vt_xxx_start
(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	STX_MAP_THE(async_loader);

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_plugin_vt_xxx_stop
(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	STX_MAP_THE(async_loader);

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_plugin_vt_xxx_get_property
(STX_HANDLE h,stx_xio* h_xio)
{
	STX_MAP_THE(async_loader);

	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_plugin_vt_xxx_set_property
(STX_HANDLE h,stx_xio* h_xio)
{
	STX_MAP_THE(async_loader);

	return STX_ERR_NOT_SUPPORT;
}