/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/
#include "stdio.h"
#include "stdlib.h"
#include "fcntl.h"
#include "malloc.h"
#include "memory.h"
#include "string.h"

#include "stx_os.h"
#include "stx_mem.h"
#include "stx_debug.h"
#include "stx_mutex.h"
#include "stx_semaphore.h"
#include "stx_module_reg.h"
#include "stx_message.h"
#include "stx_async_plugin.h"
#include "stx_direct_pin.h"
#include "stx_gid_def.h"

#include "stx_video_render_emu.h"

#include "stx_sync_source.h"


#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif

/* {90A1CF7A-AAC4-40da-9F6A-3B5B7EB59BDF} */
DEFINE_XGUID( STX_CLSID_VideoRenderEmulator,
0x90a1cf7a, 0xaac4, 0x40da, 0x9f, 0x6a, 0x3b, 0x5b, 0x7e, 0xb5, 0x9b, 0xdf);

char* g_szStreamX_VideoRenderEmulator = "StreamX video render emulator";

STX_INPUT_MEDIA_TYPE_MAP_BEGIN(video_render_emu)
	MEDIA_TYPE_MAP_ITEM(MEDIATYPE_Video,STX_GID_NULL)
STX_INPUT_MEDIA_TYPE_MAP_END()

STX_OUTPUT_MEDIA_TYPE_MAP_BEGIN(video_render_emu)
STX_OUTPUT_MEDIA_TYPE_MAP_END()

STX_COM_BEGIN(video_render_emu);

	/* imp stx_video_render vt; */
	STX_PUBLIC(stx_video_render )
	STX_COM_DATA_DEFAULT(stx_video_render)

	sint32               i_input_pin;
	stx_base_pin**		 pp_input_pin;

	int64_t              i_last_sample_time;
	int64_t              i_current_time;
	int64_t              i_start_time;
	int64_t              i_sync_time;
	int64_t              i_last_time;
	int64_t              i_adjust_time;

STX_COM_END();



STX_COM_FUNC_DECL_DEFAULT(stx_video_render,stx_video_render_vt);
STX_COM_FUNCIMP_DEFAULT(video_render_emu,stx_video_render,stx_video_render_vt);



/*{{{STX_MSG_ENTRY_DECLARE**************************************************/
/*}}}***********************************************************************/


/*{{{STX_BEGIN_MSG_MAP******************************************************/
STX_BEGIN_MSG_MAP(the_msg_data)

/* to do : add msg proc entry here; */

STX_END_MSG_MAP
/*}}}***********************************************************************/

/*{{{STX_BEGIN_MSG_RESPONSE_MAP*********************************************/
STX_BEGIN_MSG_RESPONSE_MAP(the_msg_response)

/* to do : add msg process entry here; */

STX_END_MSG_RESPONSE_MAP
/*}}}***********************************************************************/


/*{{{***********************************************************************/
STX_DISPATCH_MSG_PROC( dispatch_msg,the_msg_data )
/*}}}***********************************************************************/


/*{{{STX_RESPONSE_MSG_PROC**************************************************/
STX_RESPONSE_MSG_PROC( response_msg,the_msg_response)
/*}}}***********************************************************************/



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_COM_MAP_BEGIN(video_render_emu)
/**/STX_COM_MAP_ITEM(STX_IID_VideoRender)
STX_COM_MAP_END()

STX_API_IMP 
STX_NEW_BEGIN(video_render_emu)

	STX_RESULT i_err;

	i_err = STX_FAIL;

	STX_SET_THE(stx_video_render);
	STX_COM_NEW_DEFAULT(
		stx_video_render,
		the->stx_video_render_vt,
		stx_video_render_vt,
		STX_GID_NULL,
		STX_CATEGORY_Render,
		"StreamX video render emu");
	
STX_NEW_END()




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_PURE  
STX_QUERY_BEGIN(video_render_emu)
	STX_COM_QUERY_DEFAULT(stx_video_render,the->stx_video_render_vt);
STX_QUERY_END()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_PURE  
STX_DELETE_BEGIN(video_render_emu)

	if( the->i_input_pin && the->pp_input_pin ) {

		s32 i;
		for ( i = 0; i < the->i_input_pin; i ++ ) {
			( (stx_base_com*)the->pp_input_pin[i] )->release( the->pp_input_pin[i]);		
		}

		stx_free( the->pp_input_pin );

	}//if( the->i_input_pin && the->pp_input_pin ) {

	STX_COM_DELETE_DEFAULT(stx_video_render);

STX_DELETE_END(
STX_COM_DELETE_BEGIN(stx_video_render)
,
STX_COM_DELETE_END(stx_video_render)
)


/*}}}***********************************************************************/





/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_PURE STX_RESULT 
stx_video_render_vt_rnd_flt_plug_xxx_send_msg
( STX_HANDLE h, stx_base_message* p_msg )
{
	STX_MAP_THE(video_render_emu);

	return STX_OK;
}





/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_PURE STX_RESULT 
stx_video_render_vt_rnd_flt_xxx_enum_input_pin
(STX_HANDLE h,sint32* i_idx,stx_base_pin** pp_pin )
{
	STX_MAP_THE(video_render_emu);

	if( !i_idx ) {
		return STX_ERR_INVALID_PARAM;
	}

	if( !pp_pin) {
		*i_idx = the->i_input_pin;
		return STX_OK;
	}

	{
		s32 idx = *i_idx;

		if( idx < 0 || idx >= the->i_input_pin ) {
			return STX_ERR_INVALID_PARAM;
		}

		return the->pp_input_pin[idx]->query_interf( 
			the->pp_input_pin[idx],
			STX_IID_BasePin,
			pp_pin );

	}
}





/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_PURE STX_RESULT 
stx_video_render_vt_rnd_flt_xxx_enum_output_pin
(STX_HANDLE h,sint32* i_idx,stx_base_pin** pp_pin )
{
	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_video_render_vt_rnd_flt_xxx_check_input_media_type
( STX_HANDLE h, stx_media_type* p_mdt )
{
	stx_gid major_type;

	STX_MAP_THE(video_render_emu);

	/* it is a audio render; so check the major type; */

	major_type = p_mdt->get_type(p_mdt);

	if( ! IS_EQUAL_GID( major_type, MEDIATYPE_Video ) ) {

		return STX_ERR_NOT_SUPPORT;
	}

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_video_render_vt_rnd_flt_xxx_check_output_media_type
( STX_HANDLE h, stx_media_type* p_mdt )
{
	return STX_ERR_NOT_SUPPORT;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_video_render_vt_rnd_flt_xxx_set_input_media_type
( STX_HANDLE h, stx_media_type* p_mdt )
{
	STX_RESULT         i_err;

	stx_base_pin*     p_pin;

	stx_base_pin**    pp_pin;

	STX_MAP_THE(video_render_emu);

	i_err = STX_FAIL;

	p_pin = STX_NULL;

	pp_pin = STX_NULL;

	/* set up the input pin; */
	p_pin = XCREATE(stx_input_pin,NULL);
	if( ! p_pin ) {
		goto fail;
	}
	p_pin->set_parent(p_pin,(stx_base_plugin *)&the->stx_video_render_vt);

	i_err = p_pin->set_media_type(p_pin,p_mdt);
	if( STX_OK != i_err ) {
		goto fail;
	}

	/* realloc the->pp_input_pin; */
	pp_pin = (stx_base_pin**)xmallocz( sizeof(stx_base_pin*) * ( the->i_input_pin + 1 ));
	if( !pp_pin ){
		goto fail;
	}

	if( the->i_input_pin && the->pp_input_pin ) {

		memcpy( pp_pin, the->pp_input_pin, sizeof(stx_base_pin*) * the->i_input_pin );

		stx_free( the->pp_input_pin );
	}

	the->pp_input_pin = pp_pin;

	the->pp_input_pin[the->i_input_pin] = p_pin;

	the->i_input_pin ++;

	i_err = STX_OK;

fail:

	if( STX_OK != i_err ) {

		SAFE_XDELETE( p_pin );

		if( pp_pin ) {
			stx_free( pp_pin );
		}

	} /* if( STX_OK != i_err ) { */

	return i_err;

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_PURE STX_RESULT 
stx_video_render_vt_rnd_flt_xxx_set_output_media_type
(STX_HANDLE			h, 
 stx_media_type*		p_media_type )
{
	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_video_render_vt_rnd_flt_xxx_new_segment( STX_HANDLE h )
{
	STX_MAP_THE(video_render_emu);

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_video_render_vt_rnd_flt_plug_xxx_flush
(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	STX_MAP_THE(video_render_emu);

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_video_render_vt_rnd_flt_plug_xxx_start
(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	STX_MAP_THE(video_render_emu);

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_video_render_vt_rnd_flt_plug_xxx_stop
(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	STX_MAP_THE(video_render_emu);

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
async_plugin_vt_xxx_run
( STX_HANDLE h, u32 i_wait_time_milisec )
{
	STX_MAP_THE(video_render_emu);

	return STX_IDLE;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_video_render_vt_rnd_flt_xxx_receive
(
 STX_HANDLE			h,
 stx_base_pin*		h_pin, // which input pin;
 stx_media_data**	pp_mdat,stx_sync_inf* h_sync // output media data;
 )
{
	STX_MAP_THE(video_render_emu);

	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_video_render_vt_rnd_flt_xxx_deliver
(
 STX_HANDLE			h,
 stx_base_pin*		h_pin, // which input pin;
 stx_media_data*	p_mdat,stx_sync_inf* h_sync // output media data;
 )
{
	STX_MAP_THE(video_render_emu);
	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
**************************************************************************/
STX_PURE int64_t 
 stx_video_render_vt_rnd_xxx_get_current_time( STX_HANDLE h )
{
	STX_MAP_THE(video_render_emu);

	return the->i_current_time;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE void 
 stx_video_render_vt_rnd_xxx_set_start_time
 ( STX_HANDLE h, int64_t i_start )
{
	STX_MAP_THE(video_render_emu);

	the->i_start_time = i_start;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_video_render_vt_rnd_xxx_reset(STX_HANDLE h)
{
	STX_MAP_THE(video_render_emu);

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_video_render_vt_rnd_xxx_stop(STX_HANDLE h)
{
	STX_MAP_THE(video_render_emu);

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_video_render_vt_rnd_xxx_start(STX_HANDLE h)
{
	STX_MAP_THE(video_render_emu);

	return STX_OK;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_PURE STX_RESULT 
 stx_video_render_vt_rnd_xxx_get_device_num
 (STX_HANDLE h,sint32* i_num )
{
	STX_MAP_THE(video_render_emu);

	return STX_ERR_NOT_SUPPORT;

}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_PURE STX_RESULT 
stx_video_render_vt_rnd_xxx_enum_device
(STX_HANDLE h,sint32 i_idx, STX_HANDLE* pp_dev )
{
	STX_MAP_THE(video_render_emu);

	return STX_ERR_NOT_SUPPORT;

}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_PURE STX_RESULT 
 stx_video_render_vt_rnd_xxx_set_device(STX_HANDLE h,sint32 i_idx)
{
	STX_MAP_THE(video_render_emu);

	return STX_ERR_NOT_SUPPORT;

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT 
up_stream_msg(STX_HANDLE h, stx_base_message* p_msg )
{
	sint32		i;
	STX_RESULT	i_err;

	STX_MAP_THE(video_render_emu);

	for( i = 0; i < the->i_input_pin; i ++ ) {

		i_err = the->pp_input_pin[i]->send_msg(the->pp_input_pin[i],p_msg);

		if( STX_OK != i_err || p_msg->is_msg_closed(p_msg) ) {
			return i_err;
		}
	}

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT 
down_stream_msg(STX_HANDLE h, stx_base_message* p_msg)
{
	STX_MAP_THE(video_render_emu);

	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static STX_RESULT 
stx_video_render_vt_xxx_set_src_rect(STX_HANDLE h,STX_RECT rect )
{
	STX_MAP_THE(video_render_emu);

	return STX_OK;
}
static STX_RESULT 
stx_video_render_vt_xxx_set_dst_rect(STX_HANDLE h,STX_RECT rect )
{
	STX_MAP_THE(video_render_emu);

	return STX_OK;
}
static STX_RESULT 
stx_video_render_vt_xxx_set_color_key(STX_HANDLE h,u32 i_key)
{
	STX_MAP_THE(video_render_emu);

	return STX_OK;
}
static STX_RESULT 
stx_video_render_vt_xxx_hide(STX_HANDLE h)
{
	STX_MAP_THE(video_render_emu);

	return STX_OK;
}
static STX_RESULT 
stx_video_render_vt_xxx_show(STX_HANDLE h)
{
	STX_MAP_THE(video_render_emu);

	return STX_OK;
}

static STX_RESULT 
stx_video_render_vt_xxx_update(STX_HANDLE h)
{
	STX_MAP_THE(video_render_emu);

	return STX_OK;
}

static STX_RESULT 
stx_video_render_vt_xxx_set_video_window(STX_HANDLE h,stx_base_plugin * plug )
{
	STX_MAP_THE(video_render_emu);

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static STX_RESULT 
stx_video_render_vt_rnd_flt_plug_xxx_run
(STX_HANDLE h, stx_sync_inf* h_sync )
{
	STX_MAP_THE(video_render_emu);

	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_video_render_vt_rnd_flt_plug_xxx_get_property
(STX_HANDLE h,stx_xio* h_xio)
{
	STX_MAP_THE(video_render_emu);

	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_video_render_vt_rnd_flt_plug_xxx_set_property
(STX_HANDLE h,stx_xio* h_xio)
{
	STX_MAP_THE(video_render_emu);

	return STX_ERR_NOT_SUPPORT;
}