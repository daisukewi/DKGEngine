/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-11
***********************************************************************************/
#include "stdio.h"
#include "stdlib.h"
#include "fcntl.h"
#include "malloc.h"
#include "memory.h"
#include "string.h"

#include "stx_session.h"
#include "stx_listen_filter.h"
#include "stx_protocol.h"
#include "stx_listen_socket.h"

#include "stx_os.h"
#include "stx_mem.h"
#include "stx_debug.h"
#include "stx_module_reg.h"
#include "stx_io_as.h"
#include "stx_stack.h"
#include "stx_io_interleaved.h"
#include "stp_download.h"


#include "base_canvas.h"

#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif


#define ENABLE_LOG
#define LOG_AS_TRACE

#define LOG_TYPE_SEQ 0  // txt, items arranged by write sequence;
#define LOG_TYPE_SES 1  // ini, items arranged by session;


// {0E6A2048-1CF3-42b7-91C1-F90867800C50}
DEFINE_XGUID( STX_IID_BaseProtocol,
0xe6a2048, 0x1cf3, 0x42b7, 0x91, 0xc1, 0xf9, 0x8, 0x67, 0x80, 0xc, 0x50);

// {914759AF-3F97-41e7-93FE-364FA172FF23}
DEFINE_XGUID( STX_IID_StxProtCallback,
0x914759af, 0x3f97, 0x41e7, 0x93, 0xfe, 0x36, 0x4f, 0xa1, 0x72, 0xff, 0x23);

// {08EE4BD1-6EEE-49b6-8335-C45A3930D5F3}
DEFINE_XGUID( STX_CLSID_StxProtocol,
0x8ee4bd1, 0x6eee, 0x49b6, 0x83, 0x35, 0xc4, 0x5a, 0x39, 0x30, 0xd5, 0xf3);

char* g_sz_StreamX_StxProtocol = "StreamX stx protocol plugin";


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API_IMP CREATE_STX_COM(stx_base_filter,STX_IID_BaseFilter,stx_protocol);


enum {
	em_err_fail = 0x01,
	em_err_stop = 0x02,
	em_err_restart = 0x04,
};


STX_COM_BEGIN(stx_protocol);
/**/
/**/STX_PUBLIC(stx_base_plugin)
/**/STX_COM_DATA_DEFAULT(stx_base_plugin)
/**/STX_PUBLIC(stx_prot_callback)
/**/
/**/THEE				h_task;
/**/THEE				h_stack[2];
/**/THEE				h_stop;
/**/THEE				h_mutex;
/**/s32					i_max_socket;
/**/s32					i_socket;
/**/stx_base_plugin**	hh_socket;
/**/size_t				i_err;
/**/
/**/b32					b_log;
/**/u32					log_type;
/**/
STX_COM_END();

#define prot_lock()	stx_waitfor_mutex(the->h_mutex,INFINITE)
#define prot_unlock()	stx_release_mutex(the->h_mutex)


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_COM_FUNC_DECL_DEFAULT(stx_base_plugin,stx_base_plugin_vt);
STX_COM_FUNCIMP_DEFAULT(stx_protocol,stx_base_plugin,stx_base_plugin_vt);

STX_COM_FUNC_DECL_DEFAULT(stx_prot_callback,stx_prot_callback_vt);
STX_COM_FUNCIMP_DEFAULT(stx_protocol,stx_prot_callback,stx_prot_callback_vt);


STX_PRIVATE STX_RESULT	load_config(stx_protocol* the);


/*{{{STX_MSG_ENTRY_DECLARE**************************************************/
STX_MSG_ENTRY_DECLARE(on_auto_stop)
STX_MSG_ENTRY_DECLARE(on_app_stop)
/*}}}***********************************************************************/


/*{{{STX_BEGIN_MSG_MAP******************************************************/
STX_BEGIN_MSG_MAP(the_msg_data)
/* to do : add msg process entry here; */
/**/ON_STX_MSG(STX_MSG_AutoStop,on_auto_stop)
/**/ON_STX_MSG(STX_MSG_AppStop,on_app_stop)
STX_END_MSG_MAP
/*}}}***********************************************************************/


/*{{{STX_DISPATCH_MSG_PROC**************************************************/
STX_DISPATCH_MSG_PROC( dispatch_msg,the_msg_data )
/*}}}***********************************************************************/


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_COM_MAP_BEGIN(stx_protocol)
/**/STX_COM_MAP_ITEM(STX_IID_BasePlugin)
STX_COM_MAP_END()

STX_NEW_BEGIN(stx_protocol)
{
	//STX_RESULT i_err;

	STX_SET_THE(stx_base_plugin);
	STX_COM_NEW_DEFAULT(stx_base_plugin,the->stx_base_plugin_vt,stx_base_plugin_vt,
		STX_CLSID_StxProtocol,STX_CATEGORY_BaseProtocol,g_sz_StreamX_StxProtocol);

	STX_SET_THE(stx_prot_callback);
	STX_COM_NEW_DEFAULT(stx_prot_callback,the->stx_prot_callback_vt,stx_prot_callback_vt,
		STX_CLSID_StxProtocol,STX_CATEGORY_BaseProtocol,g_sz_StreamX_StxProtocol);

	the->h_mutex = stx_create_mutex(NULL,0,NULL);
	if( !the->h_mutex ) {
		break;
	}
	the->h_stop = stx_stack_create();
	if( !the->h_stop) {
		break;
	}
	{
		s32 i;
		for( i = 0; i < 2; i ++ ) {
			the->h_stack[i] = stx_stack_create();
			if( !the->h_stack[i] ) {
				break;
			}
		}
		if( i != 2 ) {
			break;
		}
	}
}
STX_NEW_END()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API_IMP	
STX_QUERY_BEGIN(stx_protocol)
{
	STX_COM_QUERY_DEFAULT(stx_base_plugin,the->stx_base_plugin_vt);
	STX_COM_QUERY_DEFAULT(stx_prot_callback,the->stx_prot_callback_vt);
}
STX_QUERY_END()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API_IMP	
STX_DELETE_BEGIN(stx_protocol)
{
	if( the->h_mutex) {
		stx_close_mutex(the->h_mutex);
	}

	{
		s32 i;
		for( i = 0; i < 2; i ++ ) {
			if( the->h_stack[i] ) {
				stx_stack_close(the->h_stack[i]);
			}
		}
	}
	if( the->h_stop ) {
		stx_stack_close(the->h_stop);
	}

	STX_COM_DELETE_DEFAULT(stx_base_plugin);
}
STX_DELETE_END
(
STX_COM_DELETE_BEGIN(stx_base_plugin)
,
STX_COM_DELETE_END(stx_base_plugin)
)



 

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT on_auto_stop(STX_HANDLE h,stx_base_message* p_msg)
{
	STX_MAP_THE(stx_protocol);
	{
		STX_HANDLE h_stack = p_msg->get_stack(p_msg);

		// push plugin interface pointer;
		stx_stack_push(h_stack,(size_t)&the->stx_base_plugin_vt);

		return STX_OK;
	}

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT on_app_stop(STX_HANDLE h,stx_base_message* p_msg)
{
	STX_MAP_THE(stx_protocol);
	{
		s32 i,j;

		stx_msg_cnt* p_cnt = p_msg->get_msg_cnt(p_msg);

		stx_base_plugin* plug = (stx_base_plugin*)p_cnt->param.i_param[1];

		prot_lock();

		for( i = 0; i < the->i_socket; i ++ ) {

			if( the->hh_socket[i] == plug ) {

				SAFE_XDELETE(plug);
				for( j = i; j < the->i_socket - 1; j ++ ) {
					the->hh_socket[j] = the->hh_socket[j+1];
				}//for( j = i; j < the->i_socket - 1; j ++ ) {
				the->hh_socket[the->i_socket - 1] = NULL;
				the->i_socket --;

				break;
			} // if( the->hh_socket[i] = h_plug ) {

		} // for( i = 0; i < the->i_socket; i ++ ) {

		prot_unlock();

		return STX_OK;
	}

}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_prot_callback_vt_xxx_enum_method
(STX_HANDLE h,s32 * i_idx,char ** method_name)
{
	STX_MAP_THE(stx_protocol);

	return STX_ERR_NOT_SUPPORT;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE void stx_prot_callback_vt_xxx_notify_ses_close
(THEE h,stx_base_plugin* ses)
{
	STX_MAP_THE(stx_protocol);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_prot_callback_vt_xxx_filter
(THEE h,stx_base_plugin* ses,stx_xini *h_xini,stx_xio* h_response)
{
	STX_MAP_THE(stx_protocol);
	{
		STX_RESULT	i_err;
		THEE		h_key;
		s32			i_request;

		do{


			i_err = h_xini->create_key(h_xini,NULL,g_sz_service_request,NULL,&h_key);
			if( STX_OK != i_err ) {
				break;
			}
			i_err = h_xini->read_int32(h_xini,h_key,&i_request);
			if( STX_OK != i_err ) {
				break;
			}

			// write log;

			// web admin features, need do authentication;
			switch( i_request ) {

				case STX_STP_ADMIN_STOP:
					i_err = STX_ERR_NOT_IMP;
					break;

				case STX_STP_ADMIN_RESTART:
					i_err = STX_ERR_NOT_IMP;
					break;

				case STX_STP_ADMIN_GET:
					i_err = STX_ERR_NOT_IMP;
					break;

				default:
					i_err = STX_OK;
			}

		}while(FALSE);

		return i_err;

	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE char* stx_prot_callback_vt_xxx_get_prot_name(THEE h)
{
	return g_sz_prot_stx;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_plugin_vt_xxx_send_msg
(STX_HANDLE h,stx_base_message * p_msg)
{
	STX_RESULT	i_err;

	STX_MAP_THE(stx_protocol);

	do{
		u32 i_type;

		i_err = dispatch_msg(h,p_msg);
		if( i_err < 0 || p_msg->is_msg_closed(p_msg)) {
			break;
		}

		i_type = p_msg->get_msg_type(p_msg);

		if( i_type & STX_MSG_TYPE_UPSTREAM ) {

			if( i_type & STX_MSG_TYPE_ASYNC ) {
				// upstream async message, should send to parent;
				i_err = the->h_ssrc->send_msg(the->h_ssrc,p_msg);
			}
			else {
				// upstream message, should send to parent;
				i_err = the->p_parent->send_msg(the->p_parent,p_msg);
			}
			if( i_err < 0 || p_msg->is_msg_closed(p_msg)) {
				break;
			}

		}// if( i_type & STX_MSG_TYPE_UPSTREAM ) {

		i_err = STX_OK;

	}while(FALSE);

	return i_err;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_base_plugin_vt_xxx_get_property(STX_HANDLE h,stx_xio* h_xio)
{
	STX_MAP_THE(stx_protocol);

	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_base_plugin_vt_xxx_set_property(STX_HANDLE h,stx_xio* h_xio)
{
	STX_MAP_THE(stx_protocol);

	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_base_plugin_vt_xxx_flush(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync )
{
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_base_plugin_vt_xxx_start(STX_HANDLE h,u32 i_flags,stx_sync_inf* h_sync )
{
	STX_RESULT i_err;

	STX_MAP_THE(stx_protocol);

	if( STX_OK != load_config(the) ) {
		return STX_FAIL;
	}

	// create task handle;

	i_err = the->h_gbd->alloc_ssrc(the->h_gbd,FALSE,NULL,1,&the->h_ssrc);
	if(STX_OK != i_err ){
		return i_err;
	}

	i_err = the->h_ssrc->reg_task(
		the->h_ssrc,&the->h_task,&the->stx_base_plugin_vt,TASK_IDLE);
	if(STX_OK != i_err ){
		return i_err;
	}

	the->em_status = emStxStatusPlay;
	// active ssrc handle;
	XCALL(reset_task,the->h_ssrc,the->h_task,0,0);

	return STX_OK;

}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
enum{
	em_stop_start,em_stop_socket,
};

STX_PURE STX_RESULT 
stx_base_plugin_vt_xxx_stop(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync )
{
	STX_MAP_THE(stx_protocol);
	{
		STX_RESULT	i_err;
		THEE		h_tmp;
		size_t*		h_status;
		size_t		i_status;
		s32			i;
		s64			i_idle;

		prot_lock();

		do{

			if( emStxStatusInit == the->em_status ){
				i_err = STX_OK;
				break;
			}

			h_status = (size_t*)stx_stack_pop(the->h_stop);
			if( !h_status ) {
				the->h_ssrc->set_task_events(the->h_ssrc,the->h_task,ev_stop);
				stx_stack_push(the->h_stop,em_stop_start);
				i_err = STX_WOUNLD_BLOCK;
				break;
			}

			i_status = *h_status;

			if( em_stop_start == i_status ) {
				if( emStxStatusStop != the->em_status ){
					stx_stack_push(the->h_stop,em_stop_start);
					i_err = STX_WOUNLD_BLOCK;
					break;
				}
				// task stopped;
				for( i = 0; i < the->i_socket; i ++ ) {
					stx_stack_push(the->h_stack[0],(size_t)the->hh_socket[i]);
				}
				i_status = em_stop_socket;
			}

			if( i_status == em_stop_socket ) {

				i_idle = MILISEC2REFTIME(100);

				while( h_status = stx_stack_pop(the->h_stack[0]) ) {

					stx_base_plugin*	plug;
					stx_sync_inf		inf;

					plug = (stx_base_plugin*)*h_status;
					do{
						INIT_MEMBER(inf);
						i_err = plug->stop(plug,0,&inf);
					}while(STX_AGAIN == i_err);

					if( STX_IDLE == i_err || STX_WOUNLD_BLOCK == i_err ) {
						stx_stack_push(the->h_stack[1],(size_t)plug);
						if( inf.i_idle < i_idle ) {
							i_idle = inf.i_idle;
						}
						continue;
					}

					if( i_err < 0 ) {
						break;
					}

					if( STX_OK == i_err ) {
						for( i = 0; i < the->i_socket; i ++ ) {
							if( the->hh_socket[i] == plug ) {
								SAFE_XDELETE(plug);
								the->hh_socket[i] = NULL;
								break;
							}
						}
					}

				} // while( h_status ) {

			} // if( i_status == em_stop_socket ) {

			// fatal;
			if( i_err < 0 ) {
				break;
			}

			if( stx_stack_top(the->h_stack[1] ) ) {

				// swap stack;
				h_tmp = the->h_stack[0];
				the->h_stack[0] = the->h_stack[1];
				the->h_stack[1] = h_tmp;

				stx_stack_push(the->h_stop,em_stop_socket);
				h_sync->i_idle = i_idle;
				i_err = STX_WOUNLD_BLOCK;
				break;
			}

			// all socket closed;
			// unreg task handle;
			the->h_ssrc->unreg_task(the->h_ssrc,the->h_task);
			the->h_task = NULL;
			the->em_status = emStxStatusInit;

			i_err = STX_OK;

		}while(FALSE);

		prot_unlock();

		return i_err;
	}

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_base_plugin_vt_xxx_run(STX_HANDLE h,stx_sync_inf* h_sync )
{
	STX_MAP_THE(stx_protocol);
	{
		STX_RESULT	i_err;

		i_err = STX_IDLE;

		prot_lock();

		do{

			// check restart or exit command;
			if( the->i_err ) {
				if( em_err_fail == the->i_err){ // fatal error;
					i_err = STX_FAIL;
					break;
				}
				if( em_err_stop == the->i_err){ // stop by web admin;
					i_err = STX_STOP;
					break;
				}
				if( em_err_restart == the->i_err ) { // restart by web admin;
					i_err = STX_RESTART;
					break;
				}
			} // if( the->i_err ) {

			// listen socket decreased, maybe fatal error;
			if( the->i_socket < the->i_max_socket ) {
				i_err = STX_FAIL;
				break;
			}

			h_sync->i_idle = MILISEC2REFTIME(10);
			i_err = STX_IDLE;

		}while(FALSE);

		prot_unlock();

		RESET_XENTRY(h_sync,h);

		return i_err;
	}
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
check request;
***************************************************************************/
STX_API s32		get_stx_server_ipport()
{
	STX_RESULT					i_err;
	stx_xini*					h_xini;
	STX_HANDLE					h_all;
	STX_HANDLE					h_clsid,h_ip,h_port;
	char						sz_cfg[1024];
	char						sz_key[1024];
	s32							i,i_val;

	i_err = STX_FAIL;
	h_xini = STX_NULL;

	do{

		stx_sprintf(sz_cfg, sizeof(sz_cfg),"%s\\%s",g_szStreamX_Path,g_sz_service_cfg);

		// open ini;		
		i_err = stx_ini_create( sz_cfg, STX_NULL, STX_INI_READ_WRITE|STX_INI_NO_COMMENT, 0, &h_xini );
		if( STX_INI_OK != i_err ) {
			i_err = stx_ini_create( sz_cfg, STX_NULL, STX_INI_CREATE_NEW|STX_INI_NO_COMMENT, 0, &h_xini );
			if( STX_INI_OK != i_err ) {
				break;
			}
		}

		// read key;
		i_err = h_xini->create_key( h_xini, NULL, g_szStreamX_AllModule,"1", &h_all );
		if( STX_INI_OK != i_err ) {
			break;
		}
		i_err = h_xini->read_int32(h_xini,h_all,&i_val);
		if( STX_INI_OK != i_err ) {
			break;
		}

	}while(FALSE);

	SAFE_CLOSEXIO(h_xini);

	if( STX_OK == i_err ){
		return i_val;
	}

	return -1;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
check request;
***************************************************************************/
STX_API char*	enum_stx_server_ipport(u16* port,s32 i_idx)
{
	STX_RESULT					i_err;
	stx_xini*					h_xini;
	STX_HANDLE					h_all;
	STX_HANDLE					h_clsid,h_ip,h_port;
	char						sz_cfg[1024];
	char						sz_key[1024];
	char						sz_ip[128];
	char*						sz_val;
	s32							i,i_val;

	char* sz_ip_ret;

	i_err = STX_FAIL;

	sz_val = STX_NULL;
	h_xini = STX_NULL;


	do{

		stx_sprintf(sz_cfg, sizeof(sz_cfg),"%s\\%s",g_szStreamX_Path,g_sz_service_cfg);

		// open ini;		
		i_err = stx_ini_create( sz_cfg, STX_NULL, STX_INI_READ_WRITE|STX_INI_NO_COMMENT, 0, &h_xini );
		if( STX_INI_OK != i_err ) {
			i_err = stx_ini_create( sz_cfg, STX_NULL, STX_INI_CREATE_NEW|STX_INI_NO_COMMENT, 0, &h_xini );
			if( STX_INI_OK != i_err ) {
				break;
			}
		}

		// read key;
		i_err = h_xini->create_key( h_xini, NULL, g_szStreamX_AllModule,"1", &h_all );
		if( STX_INI_OK != i_err ) {
			break;
		}
		i_err = h_xini->read_int32(h_xini,h_all,&i_val);
		if( STX_INI_OK != i_err ) {
			break;
		}

		{

			char		sz_param[128];
			u32 const	i_size = sizeof(sz_param);

			stx_sprintf(sz_key,sizeof(sz_key),"%s-%d",g_szStreamX_AllModule,i_idx);

			i_err = h_xini->create_key( h_xini, h_all, sz_key,NULL, &h_clsid );
			if( STX_INI_OK != i_err ) {
				break;
			}

			i_err = h_xini->create_key( h_xini, h_clsid, g_sz_ip4, g_sz_ip4_default, &h_ip );
			if( STX_INI_OK != i_err ) {
				break;
			}

			i_err = h_xini->read_string(h_xini,h_ip,&sz_val);
			if( STX_INI_OK != i_err ) {
				break;
			}

			i_err = h_xini->create_key( h_xini, h_clsid, g_sz_port, g_sz_port_default, &h_port );
			if( STX_INI_OK != i_err ) {
				break;
			}

			i_err = h_xini->read_int32(h_xini,h_port,&i_val);
			if( STX_INI_OK != i_err ) {
				break;
			}

		} //

	}while(FALSE);

	sz_ip_ret = NULL;

	if( STX_OK == i_err ) {
		sz_ip_ret = xstrdup(sz_val);
		*port = (u16)i_val;
	}

	SAFE_CLOSEXIO(h_xini);

	return sz_ip_ret;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
check request;
***************************************************************************/
STX_PRIVATE STX_RESULT load_config(stx_protocol* the)
{
	STX_RESULT					i_err;
	stx_xini*					h_xini;
	STX_HANDLE					h_all;
	STX_HANDLE					h_clsid,h_ip,h_port;
	char						sz_cfg[1024];
	char						sz_key[1024];
	char						sz_ip[128];
	char*						sz_val;
	s32							i,i_val;
	stx_xio*					h_tcp;

	stx_base_plugin*			h_plug;

	i_err = STX_FAIL;

	sz_val = STX_NULL;
	h_xini = STX_NULL;
	h_tcp = NULL;
	h_plug = NULL;


	do{

		stx_sprintf(sz_cfg, sizeof(sz_cfg),"%s\\%s",g_szStreamX_Path,g_sz_service_cfg);

		// open ini;		
		i_err = stx_ini_create( sz_cfg, STX_NULL, STX_INI_READ_WRITE|STX_INI_NO_COMMENT, 0, &h_xini );
		if( STX_INI_OK != i_err ) {
			i_err = stx_ini_create( sz_cfg, STX_NULL, STX_INI_CREATE_NEW|STX_INI_NO_COMMENT, 0, &h_xini );
			if( STX_INI_OK != i_err ) {
				break;
			}
		}

		// read key;
		i_err = h_xini->create_key( h_xini, NULL, g_szStreamX_AllModule,"1", &h_all );
		if( STX_INI_OK != i_err ) {
			break;
		}
		i_err = h_xini->read_int32(h_xini,h_all,&i_val);
		if( STX_INI_OK != i_err ) {
			break;
		}
		the->i_max_socket = i_val;		

		the->hh_socket = (stx_base_plugin **)xmallocz(sizeof(stx_base_plugin*)*i_val);
		if( !the->hh_socket ) {
			i_err = STX_FAIL;
			break;
		}
		
		for( i = 0 ; i < the->i_max_socket; i ++ ) {

			char		sz_param[128];
			u32 const	i_size = sizeof(sz_param);

			stx_sprintf(sz_key,sizeof(sz_key),"%s-%d",g_szStreamX_AllModule,i);

			i_err = h_xini->create_key( h_xini, h_all, sz_key,NULL, &h_clsid );
			if( STX_INI_OK != i_err ) {
				break;
			}

			i_err = h_xini->create_key( h_xini, h_clsid, g_sz_ip4, g_sz_ip4_default, &h_ip );
			if( STX_INI_OK != i_err ) {
				break;
			}

			i_err = h_xini->read_string(h_xini,h_ip,&sz_val);
			if( STX_INI_OK != i_err ) {
				break;
			}

			i_err = h_xini->create_key( h_xini, h_clsid, g_sz_port, g_sz_port_default, &h_port );
			if( STX_INI_OK != i_err ) {
				break;
			}

			i_err = h_xini->read_int32(h_xini,h_port,&i_val);
			if( STX_INI_OK != i_err ) {
				break;
			}

			memset(sz_ip,0,sizeof(sz_ip));

			stx_io_tcp_make_string( sz_val, i_val, sz_ip, sizeof(sz_ip) );

			i_err = stx_io_tcp_make_open_string(sz_ip,NULL,sz_param);
			if( STX_OK != i_err )  {
				break;
			}

			h_tcp = stx_create_io_tcp();
			if( !h_tcp ) {
				i_err = STX_FAIL;
				break;
			}

			i_err = h_tcp->open(h_tcp,sz_param,STX_XIO_TCP_OPEN_SVR | STX_XIO_TCP_OPEN_ASYNC);
			if( STX_OK != i_err ) {
				break;
			}

			the->hh_socket[i] = XCREATE(listen_socket,NULL);
			if( !the->hh_socket[i]) {
				i_err = STX_FAIL;
				break;
			}

			h_plug = the->hh_socket[i];
			h_plug->set_gbd(h_plug,the->h_gbd);
			h_plug->set_parent(h_plug,&the->stx_base_plugin_vt);

			// start listen socket;
			{
				stx_sync_inf inf = {0};

				inf.h_data = h_tcp;
				i_err = h_plug->start(h_plug,FLAG_SET_INPUTIO,&inf);
				if( STX_OK != i_err ) {
					break;
				}
				i_err = h_plug->start(h_plug,FLAG_START_TASK,&inf);
				if( STX_OK != i_err ) {
					break;
				}

				stx_log("stx protocol: listen socket <%s> started;\r\n",h_plug->get_name(h_plug));

			}

			the->i_socket ++;

		} // for( i = 0 ; i < the->i_max_socket; i ++ ) {

	}while(FALSE);

	if( STX_OK != i_err ) {
		SAFE_CLOSEXIO(h_tcp);
	}

	SAFE_CLOSEXIO(h_xini);

	return i_err;
}


