/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/
#include "stdio.h"
#include "stdlib.h"
#include "fcntl.h"
#include "malloc.h"
#include "memory.h"
#include "string.h"

#include "stx_mem.h"
#include "stx_debug.h"
#include "stx_gid_def.h"
#include "stx_module_reg.h"
#include "stx_media_data_base.h"
#include "stx_mdat_lxvideoframe.h"


#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT  vfrmSetPrivateData(VideoFrame* pFrame,s32 nSize)
{
	if(pFrame->lpPrivateData ){
		xlivFree( pFrame->lpPrivateData );
		pFrame->lpPrivateData = NULL;
	}
	if( nSize == 0 ) {
		return STX_OK;
	}

	pFrame->lpPrivateData = xlivAlloc(nSize,TRUE,64);
	if(!pFrame->lpPrivateData){
		return STX_FAIL;
	}
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
s32 vfrmAjustSurfaceSize(VideoFrame* pFrame,s32 Width,s32 Height,s32 nMemType)
{
	s32 nSize;
	s32 i ;

	vfrmReleaseBuffer(pFrame);

	vfrmSetBankSwitch(pFrame,FALSE);

	pFrame->lpMacroblockType = (u8*) xlivAlloc(Height,TRUE,64);
	if( !pFrame->lpMacroblockType ){
		return STX_FAIL;
	}
	memset(pFrame->lpMacroblockType,0, Height );

	pFrame->nCodedPictureWidth = Width;
	pFrame->nCodedPictureHeight = Height;

	pFrame->nFrameSize = Width * Height;

	pFrame->nPitch[0] = ( Width + 64 + 127 ) & ~127;
	nSize = pFrame->nPitch[0] * ( Height + 66 );
	pFrame->lpData0[0] =  (u8*)xlivAlloc(nSize,TRUE,64) ;
	pFrame->lpData[0] = pFrame->lpData0[0] + pFrame->nPitch[0] * 32;
	pFrame->nBufMin[0] = -(pFrame->nPitch[0] * 16);
	pFrame->nBufMax[0] = pFrame->nPitch[0] * (pFrame->nCodedPictureHeight + 16);

	if( nMemType == CHROMA420 ){
		for( i = 1; i < 3; i ++ ){
			pFrame->nPitch[i] = pFrame->nPitch[0] >> 1;
			nSize = pFrame->nPitch[i] * ((Height>>1) + 34);
			pFrame->lpData0[i] =  (u8*)xlivAlloc(nSize,TRUE,64) ;
			pFrame->lpData[i] = pFrame->lpData0[i] + pFrame->nPitch[i]  * 16  ;
			pFrame->nBufMin[i] = -(pFrame->nPitch[i] * 8);
			pFrame->nBufMax[i] = pFrame->nPitch[i] * ( 8 + (Height>>1) );
		}

	}
	else if( nMemType == CHROMA422 ){
		for( i = 1; i < 3; i ++ ){
			pFrame->nPitch[i] = pFrame->nPitch[0] >> 1;
			nSize = pFrame->nPitch[i] * ( Height + 66 ) ;
			pFrame->lpData0[i] =  (u8*)xlivAlloc(nSize,TRUE,64) ;
			pFrame->lpData[i] = pFrame->lpData0[i] + pFrame->nPitch[i]  * 32  ;
			pFrame->nBufMin[i] = -(pFrame->nPitch[i] * 16);
			pFrame->nBufMax[i] = pFrame->nPitch[i] * ( 16 + Height );
		}
	}
	else if( nMemType == CHROMA444 ){
		for( i = 1; i < 3; i ++ ){
			pFrame->nPitch[i] = pFrame->nPitch[0];
			nSize = pFrame->nPitch[0] * ( Height + 66 );
			pFrame->lpData0[i] =  (u8*)xlivAlloc(nSize,TRUE,64) ;
			pFrame->lpData[i] = pFrame->lpData0[i] + pFrame->nPitch[i]  * 32  ;
			pFrame->nBufMin[i] = -(pFrame->nPitch[i] * 16);
			pFrame->nBufMax[i] = pFrame->nPitch[i] * (Height + 16);
		}
	}

	pFrame->dwMemoryType = nMemType;

	return STX_OK;
}


typedef struct stx_mdat_lxvdf_ctx stx_mdat_lxvdf_ctx;

struct stx_mdat_lxvdf_ctx{
	stx_media_data				mda;
	s64							i_media_time;
	s64							i_decode_time;
	s64							i_duration;
	s32							i_ref;
	VideoFrame*					p_frame;
	size_t                      i_flags;
	s32							i_dref;
};



STX_PURE	STX_RESULT			query_interf( STX_HANDLE h, stx_gid gid, STX_HANDLE* p_interf);

STX_PURE	int			    	add_ref( STX_HANDLE h );

STX_PURE	int 				release( STX_HANDLE h );


STX_PURE	size_t				get_buf( STX_HANDLE h, void** pp_data); //

STX_PURE	STX_RESULT			resize( STX_HANDLE h, size_t i_new_size );

STX_PURE	STX_RESULT			get_data( STX_HANDLE h, void** pp_cur, size_t* i_data_size );//

STX_PURE	STX_RESULT			set_data( STX_HANDLE h, u8* p_cur,size_t i_len );//

STX_PURE	STX_RESULT			set_time( STX_HANDLE h, s64 i_pts, s64 i_dts );

STX_PURE	s64					get_time( STX_HANDLE h, s64* i_dts );

STX_PURE	STX_RESULT			set_duration( STX_HANDLE h, s64 i_duration );

STX_PURE	s64					get_duration( STX_HANDLE h  );

STX_PURE    STX_RESULT			set_flags( STX_HANDLE h, size_t i_flags );

STX_PURE    size_t			    get_flags( STX_HANDLE h );

STX_PURE s32			incr( THEE h );
STX_PURE s32			decr( THEE h );

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

stx_media_data* stx_mdat_lxvideoframe_create(stx_media_data* p_mda)
{
	STX_RESULT			i_err;

	stx_mdat_lxvdf_ctx*	the;


	i_err = STX_FAIL;

	the = STX_NULL;



	for( ; ; ) {

		the = (stx_mdat_lxvdf_ctx*)xmallocz(sizeof(stx_mdat_lxvdf_ctx));
		if( !the ){
			break;
		}

		/* fill the vtable; */
		the->i_ref = 1;

		the->mda.add_ref		= add_ref;
		the->mda.query_interf	= query_interf;
		the->mda.release		= release;

		the->mda.get_buf			= get_buf;
		the->mda.get_data			= get_data;
		the->mda.get_time			= get_time;
		the->mda.set_data			= set_data;
		the->mda.set_time			= set_time;
		the->mda.resize				= resize;
		the->mda.set_flags			= set_flags;
		the->mda.get_flags			= get_flags;
		the->mda.set_duration		= set_duration;
		the->mda.get_duration		= get_duration;
		the->mda.incr = incr;
		the->mda.decr = decr;

		the->p_frame = (VideoFrame*)xmallocz(sizeof(VideoFrame));
		if( !the->p_frame ) {
			break;
		}
		vfrmInitialize(the->p_frame);

		i_err = STX_OK;

		break;
	}

	if( STX_OK != i_err ) {

		SAFE_XDELETE(the);

		return STX_NULL;
	}

	return (stx_media_data*)the;

}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static	STX_RESULT query_interf( STX_HANDLE h, stx_gid gid, STX_HANDLE* p_interf)
{
	stx_mdat_lxvdf_ctx*		the;

	the = (stx_mdat_lxvdf_ctx*) h;

	if( IS_EQUAL_GID( gid, STX_IID_MediaData ) ) {

		add_ref(the);

		*p_interf = the;

		return STX_OK;
	}

	if( IS_EQUAL_GID( gid, STX_IID_LxVideoFrame ) ) {

		add_ref(the);

		*p_interf = the->p_frame;

		return STX_OK;
	}

	return STX_ERR_INVALID_PARAM;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE int add_ref( STX_HANDLE h )
{
	stx_mdat_lxvdf_ctx*		the;

	the = (stx_mdat_lxvdf_ctx*) h;

	the->i_ref ++;

	return the->i_ref;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE s32 release( STX_HANDLE h )
{
	stx_mdat_lxvdf_ctx*		the;

	the = (stx_mdat_lxvdf_ctx*) h;

	the->i_ref --;

	if( the->i_ref > 0 ) {
		return the->i_ref;
	}

	if( the->p_frame ) {
		vfrmRelease(the->p_frame);
		stx_free(the->p_frame);
	}

	stx_free( the );

	return 0;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

static	size_t get_buf( STX_HANDLE h,void** pp_data)
{
	return sizeof(VideoFrame*);
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static	STX_RESULT resize( STX_HANDLE h, size_t i_new_size )
{
	return STX_ERR_NOT_SUPPORT;
}





/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static	STX_RESULT get_data( STX_HANDLE h, void** pp_data, size_t* i_data_size )
{
	return STX_ERR_NOT_SUPPORT;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

static	STX_RESULT set_data( STX_HANDLE h, u8* p_cur,size_t i_len )
{
	return STX_ERR_NOT_SUPPORT;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static	STX_RESULT set_time( STX_HANDLE h, s64 i_pts, s64 i_dts )
{
	stx_mdat_lxvdf_ctx*		the;

	the = (stx_mdat_lxvdf_ctx*) h;

	the->i_media_time = i_pts;

	the->i_decode_time = i_dts;

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_PURE STX_RESULT set_duration( STX_HANDLE h, s64 i_duration )
{
	stx_mdat_lxvdf_ctx*		the;

	the = (stx_mdat_lxvdf_ctx*) h;

	the->i_duration = i_duration;

	return STX_OK;

}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_PURE s64 get_duration( STX_HANDLE h  )
{
	stx_mdat_lxvdf_ctx*		the;

	the = (stx_mdat_lxvdf_ctx*) h;

	return the->i_duration;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static	s64 get_time( STX_HANDLE h, s64* i_dts )
{
	stx_mdat_lxvdf_ctx*		the;

	the = (stx_mdat_lxvdf_ctx*) h;

	if(i_dts ) {
		*i_dts = the->i_decode_time;
	}

	return the->i_media_time;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_PURE STX_RESULT set_flags( STX_HANDLE h, size_t i_flags )
{
	stx_mdat_lxvdf_ctx*		the;

	the = (stx_mdat_lxvdf_ctx*) h;

	the->i_flags = i_flags;

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_PURE size_t get_flags( STX_HANDLE h )
{
	stx_mdat_lxvdf_ctx*		the;

	the = (stx_mdat_lxvdf_ctx*) h;

	return the->i_flags;

}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE s32 incr( THEE h )
{
	STX_DIRECT_THE(stx_mdat_lxvdf_ctx);
	the->i_dref ++;
	return the->i_dref;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE s32 decr( THEE h )
{
	STX_DIRECT_THE(stx_mdat_lxvdf_ctx);
	the->i_dref --;
	return the->i_dref;
}
