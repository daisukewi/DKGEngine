/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
**********************************************************************************/
#include "stdio.h"
#include "stdlib.h"
#include "fcntl.h"
#include "malloc.h"
#include "memory.h"
#include "string.h"
#include "ctype.h"

#include "base_interf.h"
#include "stx_thread.h"
#include "stx_ini.h"
#include "stx_mem.h"
#include "stx_io_tcp.h"
#include "stx_io_stream.h"
#include "stx_sock_err.h"
#include "stx_debug.h"
#include "stx_io_reg.h"
#include "stx_string.h"
#include "stx_stat.h"

#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif

/* used for protocol handling */

#define BUFFER_SIZE		1024
#define URL_SIZE		4096
#define MAX_REDIRECTS	8

enum stx_reg_status{
	em_reg_init,
	em_reg_open,
	em_reg_connect,
	em_reg_ready,
	em_reg_write,
	em_reg_parse,
	em_reg_read,
	em_reg_seek,
};
typedef enum stx_reg_status stx_reg_status;


typedef struct stx_io_reg stx_io_reg;

struct stx_io_reg{

	stx_xio			stx_xio_vt;
	stx_xio*		h_tcp;
	char*			sz_url;
	char*			sz_local_ip;

	char*			sz_rtsp; // RTSP url string;

	u32				i_local_port;

	b32				is_streamed;
	size_t          flags;
	char            location[URL_SIZE];
	u8				buffer[BUFFER_SIZE];
	u8				*buf_ptr;
	u8				*buf_end;
	s32             line_count;
	s32             http_code;
	offset_t        off;
	offset_t		start_off;
	offset_t        filesize;

	stx_reg_status  em_status;
	char            sz_param[1024];
	char			hoststr[1024];
	char			auth[1024];
	char			path[1024];

	char			line[1024];
	char			*q;

	char*			sz_bind;
	stx_xio*		h_old_tcp;
	offset_t		old_off;

	STX_HANDLE		h_stat;
	s32				redirects;
};


STX_COM_FUNC_DECL_DEFAULT(stx_xio,stx_xio_vt);


STX_PRIVATE void        http_err(stx_io_reg* the);

STX_PRIVATE STX_RESULT  http_connect(stx_io_reg	*h,	s32	*new_location);

STX_PRIVATE STX_RESULT  http_open_cnx(stx_io_reg *h);

STX_PRIVATE STX_RESULT  http_open_internal
(
stx_io_reg *h, 
const char *uri, 
s32 flags
);

STX_PRIVATE STX_RESULT  http_getc(stx_io_reg *h,s32* c);

STX_PRIVATE STX_RESULT  http_process_line
(
stx_io_reg 	*h, 
char		*line, 
s32			line_count,
s32			*new_location
);




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API char* make_register_string(char* server,char* url)
{
	char	buf[4096];
	char	url1[4096];
	char*	p = url;
	char*	q = url1;

	if( strlen(server) + strlen(url) > 2048 ) {
		return NULL;
	}

	for( ; ; ) {
		char t = *p++;
		if( !t ) {
			*q = '\0';
			break;
		}
		if( ':' == t || '/' == t || '=' == t || '&' == t) {
			char e[4];
			*q ++ = '%';
			stx_sprintf(e,sizeof(e),"%x",t);
			*q ++ = e[0];
			*q ++ = e[1];
		}
		else{
			*q ++ = t;
		}
	}// for( ; ; ) {

	stx_sprintf(buf,sizeof(buf),"POST %s?url=%s&msisdn=1234567",server,url1);

	return xstrdup(buf);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API_IMP stx_xio* create_stx_io_reg()
{
	STX_RESULT		i_err;
	stx_io_reg*		the;

	the = (stx_io_reg*) xmallocz( sizeof(stx_io_reg));
	if( !the ) {
		return STX_NULL;
	}

	STX_COM_NEW_DEFAULT(stx_xio,the->stx_xio_vt,stx_xio_vt,
		DEFAULT_CODE,DEFAULT_CODE,DEFAULT_CODE);


	do{
		i_err = STX_FAIL;

		the->h_stat = stx_stat_create();
		if( !the->h_stat ) {
			break;
		}

		i_err = STX_OK;

	}while(FALSE);

	if( STX_OK != i_err ) {
		stx_xio_vt_xxx_close((stx_xio*)the);
		return NULL;
	}

	the->em_status = em_reg_init;

	return (stx_xio*)the;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE void http_err(stx_io_reg* the)
{

}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_xio_vt_xxx_open(stx_xio* h,const char* httpname,s32 oflag)
{
	STX_DIRECT_THE(stx_io_reg);

	if( the->em_status == em_reg_init ) {
		return http_open_internal(the ,httpname,oflag );
	}
	else {
		return http_open_cnx(the);
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_xio_vt_xxx_close(stx_xio* h)
{
	STX_DIRECT_THE(stx_io_reg);

	if(the->h_old_tcp) {
		the->h_old_tcp->close(the->h_old_tcp);
	}

	if(the->h_tcp) {
		the->h_tcp->close(the->h_tcp);
	}

	if( the->sz_bind ) {
		stx_free(the->sz_bind);
	}

	if( the->h_stat ) {
		stx_stat_close(the->h_stat);
	}

	if( the->sz_rtsp ) {
		stx_free(the->sz_rtsp);
	}

	stx_free(the);

	return 0;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_xio_vt_xxx_clear(stx_xio* h)
{
	STX_DIRECT_THE(stx_io_reg);
	return 0;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_xio_vt_xxx_stop(stx_xio* h)
{
	STX_DIRECT_THE(stx_io_reg);

	return 0;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_xio_vt_xxx_read
(stx_xio* h,void* buffer,size_t cnt,size_t* i_read)
{
	STX_RESULT		i_err;
	size_t			len;
	size_t			i_data;

	STX_DIRECT_THE(stx_io_reg);

	/* read bytes from input buffer first */
	len = the->buf_end - the->buf_ptr;

	if ( len > 0 ) {
		if (len > cnt){
			len = cnt;
		}
		memcpy(buffer, the->buf_ptr, len);
		the->buf_ptr += len;
		i_data = len;
	} 
	else {
		i_err = the->h_tcp->read( the->h_tcp, buffer, cnt, &i_data );
		if( i_err != STX_OK ) {
			return i_err;
		}
	}

	the->off += i_data;

	stx_stat_add_val(the->h_stat,(s64)i_data); // update stat;

	*i_read = i_data;

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_xio_vt_xxx_write
(stx_xio* h, const void* buffer,size_t cnt,size_t* i_write)
{
	STX_DIRECT_THE(stx_io_reg);
	return XCALL(write,the->h_tcp,buffer,cnt,i_write);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE offset_t 
stx_xio_vt_xxx_seek( stx_xio* h, offset_t off, s32 whence )
{
	STX_RESULT		i_err;

	STX_DIRECT_THE(stx_io_reg);

	if (whence == SEEK_SIZE){
		return the->filesize;
	}
	else if ( (the->filesize == -1 && whence == SEEK_END) || the->is_streamed ) {
		return -1;
	}

	if( !the->h_old_tcp ) { // first time;

		/* we save the old context in case the seek fails */
		the->h_old_tcp = the->h_tcp;
		the->old_off = the->off;

		the->h_tcp = NULL;

		if (whence == SEEK_CUR){
			off += the->off;
		}
		else if (whence == SEEK_END){
			off += the->filesize;
		}

		the->off = off;

	} // if( !the->h_old_tcp ) {

	/* if it fails, continue on old connection */
	i_err = http_open_cnx(the);
	if ( i_err < 0 || STX_EOF == i_err ) {
		the->h_tcp = the->h_old_tcp;
		the->off = the->old_off;
		the->h_old_tcp = NULL;
		the->old_off = -1;
		return -1;
	}//if ( i_err < 0 || STX_EOF == i_err ) {

	if( STX_IDLE == i_err || STX_WOUNLD_BLOCK == i_err ) {
		return -2;
	}

	// success;
	the->h_old_tcp->close(the->h_old_tcp);
	the->h_old_tcp = NULL;
	the->old_off = -1;

	return the->off;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE offset_t stx_xio_vt_xxx_tell(stx_xio* h)
{
	STX_DIRECT_THE(stx_io_reg);

	return the->off;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE offset_t	stx_xio_vt_xxx_size(stx_xio* h)
{
	STX_DIRECT_THE(stx_io_reg);

	if( the->location ) {
		return strlen(the->location) + 1;
	}

	return the->filesize;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_PURE STX_RESULT   
stx_xio_vt_xxx_set( stx_xio* h, u32 flags, STX_HANDLE h_val )
{
	stx_io_op_param*	pinf;

	STX_DIRECT_THE(stx_io_reg);

	pinf = (stx_io_op_param*)h_val;

	if( STX_XIO_SET_BIND == flags ) {

		if( the->sz_bind ) {
			stx_free(the->sz_bind);
		}

		the->sz_bind = xstrdup(pinf->buf);
		if( !the->sz_bind ) {
			return STX_FAIL;
		}

		return STX_OK;
	}

	return the->h_tcp->set(the->h_tcp,flags,h_val);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_xio_vt_xxx_get( stx_xio* h, u32 flags, STX_HANDLE h_val )
{
	STX_DIRECT_THE(stx_io_reg);
	{
		if( 0 == flags ) {
			stx_io_op_param* param = (stx_io_op_param*)h_val;
			param->buf = the->location;
			return STX_OK;
		}

		return the->h_tcp->get(the->h_tcp,flags,h_val);
	}
}



/***************************************************************************
RETURN VALUE:return non zero if error
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT http_open_cnx(stx_io_reg *the)
{
	STX_RESULT	i_err;
	size_t		i_size;
	size_t		i_write;
	s32		    location_changed;
	s32         post;


	for( ; ; ) {

		switch( the->em_status ) {

		case em_reg_init:
			{
				stx_xio*	h_tcp;
				const char	*path;
				char*		host;
				char		hostname[1024];
				char		hostname1[1024];
				char		path1[1024];
				char		proxy_path[1024];
				char		proxy_path2[1024];

				s32		    port;
				s32		    use_proxy;
				bool32		bNoProxy;

				h_tcp = STX_NULL;
				location_changed = 0;
				the->redirects = 0;

				i_err = stx_getenv(&i_size,proxy_path,sizeof(proxy_path),"http_proxy");
				if( i_err < 0 ) {
					return i_err;
				}

				bNoProxy = ( STX_OK == stx_getenv(&i_size,proxy_path2,sizeof(proxy_path2),"no_proxy") );
				use_proxy = ( !bNoProxy && av_strstart(proxy_path, "http://", NULL) );

				/* fill the dest addr */
				/* needed in any case to build the host string */
				url_split(NULL, 0, the->auth, sizeof(the->auth), hostname, sizeof(hostname), &port,
					path1, sizeof(path1), the->location);

				if( isalpha(hostname[0]) ) {
					struct hostent remoteHost;
					struct in_addr addr;

					if( !stx_gethostbyname(hostname,&remoteHost)) {
						return STX_FAIL;
					}
					addr.s_addr = *(u32*) remoteHost.h_addr_list[0];
					stx_inet_ntoa(addr,hostname1,sizeof(hostname1));
					host = hostname1;
				}
				else{
					host = hostname;
				}

				if (port > 0) {
					stx_snprintf(the->hoststr, sizeof(the->hoststr), "%s:%d", host, port);
				} 
				else {
					av_strlcpy(the->hoststr, host, sizeof(the->hoststr));
				}


				if (use_proxy) {
					url_split(NULL, 0, the->auth, sizeof(the->auth), host, sizeof(hostname), &port,
						NULL, 0, proxy_path);
					path = the->location;
				} 
				else {
					if (path1[0] == '\0'){
						path = "/";
					}
					else{
						path = path1;
					}
				}
				stx_strcpy(the->path,sizeof(the->path),path);  // path is the url;

				if (port < 0){
					port = 80;
				}

				h_tcp = stx_create_io_tcp();
				if( !h_tcp ) {
					return STX_FAIL;
				}
				the->h_tcp = h_tcp;

				memset(the->sz_param,0,sizeof(the->sz_param));
				stx_io_tcp_make_string( host, port, the->sz_param, sizeof(the->sz_param) );
				i_err = stx_io_tcp_make_open_string(the->sz_bind,the->sz_param,the->sz_param);
				if( STX_OK != i_err )  {
					return STX_FAIL;
				}
				the->em_status = em_reg_open;
			}

		case em_reg_open:

			i_err = XCALL(open,the->h_tcp,the->sz_param, 
				STX_XIO_TCP_OPEN_CONNECT | STX_XIO_TCP_OPEN_ASYNC );

			if( STX_OK != i_err ) {
				return i_err;
			}


			//
			{

				char		*auth_b64;
				STX_RESULT	auth_b64_len;

				i_err = STX_FAIL;
				auth_b64_len = strlen(the->auth)* 4 / 3 + 12;
				the->start_off = the->off;

				/* send http header */
				post = (s32)( the->flags & URL_WRONLY );

				auth_b64 = xmallocz(auth_b64_len);
				if( !auth_b64 ) {
					return STX_FAIL;
				}

				av_base64_encode(auth_b64, (s32)auth_b64_len, (uint8*)the->auth, (s32)strlen(the->auth));

				stx_sprintf(
					(char*)the->buffer, 
					sizeof(the->buffer),
					"%s %s HTTP/1.1\r\n"
					"User-Agent: %s\r\n"
					"Accept: */*\r\n"
					"Host: %s\r\n"	"Content-Type: application/x-www-urlencoded\r\n"
					"Content-Length: %d\r\n" "Connection: Keep-Alive\r\n" "Cache-Control: no-cache\r\n"
					"Authorization: Basic %s\r\n" "\r\n"
					"%s" , // content
					post ? "POST" : "GET", "/REGISTER_RTSP",
					XLIV_AGENT,
					the->hoststr,
					(s32)strlen(the->path),
					auth_b64,
					the->path);

				av_freep(&auth_b64);

			}

			the->buf_ptr = the->buffer;
			the->buf_end = the->buffer + strlen(the->buffer);
			the->em_status = em_reg_write;

		case em_reg_write:
			i_err = XCALL(write,the->h_tcp,the->buf_ptr, the->buf_end - the->buf_ptr,&i_write );
			if( i_err != STX_OK ) {
				return i_err;
			}
			the->buf_ptr += i_write;
			if( the->buf_ptr < the->buf_end ) {
				break; // rewrite;
			}
			if (post) {
				//return STX_OK;
			}
			/* init input buffer */
			the->buf_ptr = the->buffer;
			the->buf_end = the->buffer;
			the->line_count = 0;
			the->off = 0;
			the->filesize = -1;
			/* wait for header */
			the->q = the->line;			
			the->em_status = em_reg_connect;

		case em_reg_connect:

			i_err = http_connect(the, &location_changed);
			if( i_err != STX_OK ){
				return i_err;
			}

			if( (the->http_code == 302 || the->http_code == 303) && location_changed == 1 ) {

				if (the->redirects++ >= MAX_REDIRECTS){
					return STX_FAIL;
				}

				/* url moved, get next */
				the->h_tcp->close(the->h_tcp);
				the->h_tcp = NULL;

				location_changed = 0;
				the->em_status = em_reg_init;
				continue;

			} //if ((h->http_code == 302 ||

		#if 0 // the offset maybe modified by service ??
			if( the->start_off != the->off ) { 
				return STX_FAIL;
			}
		#endif

			stx_stat_add_val(the->h_stat,0); // start stat;

			the->em_status = em_reg_ready;
			return STX_OK;

		default:
			break;

		} // switch(the->em_status){

		return STX_OK;

	}/* for( ; ; ) { */ 

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static STX_RESULT http_open_internal(stx_io_reg *h, const char *uri, s32 flags)
{
	h->flags = flags;
	h->is_streamed = 1;
	h->filesize = -1;
	h->off = 0;
	av_strlcpy(h->location, uri, URL_SIZE);
	return http_open_cnx(h);
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT http_getc(stx_io_reg *h,s32* c)
{
	STX_RESULT  i_err;
	size_t		i_read;

	if ( h->buf_ptr >= h->buf_end ) {

		i_err = h->h_tcp->read(h->h_tcp, h->buffer, BUFFER_SIZE,&i_read);
		if( i_err != STX_OK  ) { // FAIL, IDLE, EOF, WOUNLDBLOCK
			return i_err;
		}

		h->buf_ptr = h->buffer;
		h->buf_end = h->buffer + i_read;

	} /* if (h->buf_ptr >= h->buf_end) { */

	*c = *h->buf_ptr++;

	return STX_OK; 
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT http_process_line
( 
 stx_io_reg   	*h, 
 char         	*line, 
 s32          	line_count,
 s32          	*new_location 
 )
{
	char *tag, *p;

	/* end of header */
	if (line[0] == '\0'){
		return 0;
	}

	p = line;

	if (line_count == 0) {

		while (!isspace(*p) && *p != '\0'){
			p++;
		}

		while (isspace(*p)){
			p++;
		}

		h->http_code = strtol(p, NULL, 10);

		/* error codes are 4xx and 5xx */
		if (h->http_code >= 400 && h->http_code < 600){
			return -1;
		}

	} // if (line_count == 0) {
	else {

		while (*p != '\0' && *p != ':'){
			p++;
		}

		if (*p != ':') {
			return 1;
		}

		*p = '\0';
		tag = line;
		p++;

		while (isspace(*p)){
			p++;
		}

		if (!strcmp(tag, "Location")) {
			stx_strcpy( h->location, sizeof(h->location), p);
			*new_location = 1;
		} 
		else if (!strcmp (tag, "Content-Length") && h->filesize == -1) {
			h->filesize = _atoi64(p);
		} 
		else if (!strcmp (tag, "Content-Range")) {

			/* "bytes $from-$to/$document_size" */

			const char *slash;

			if (!strncmp (p, "bytes ", 6)) {

				p += 6;
				h->off = _atoi64(p);
				if ((slash = strchr(p, '/')) && strlen(slash) > 0){
					h->filesize = _atoi64(slash+1);
				} /* if ((slash = strchr(p, '/')) && strlen(slash) > 0){ */

			} /* if (!strncmp (p, "bytes ", 6)) { */

			h->is_streamed = 0; /* we _can_ in fact seek */

		} //else if (!strcmp (

	} // if (line_count == 0) {...}else{

	return 1;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT http_connect(stx_io_reg *h, s32	*new_location )
{

	STX_RESULT   i_err;
	s32          ch;

	i_err = STX_FAIL;

	for( ; ; ) {

		i_err = http_getc(h,&ch);
		if (i_err != STX_OK ){
			return i_err;
		}// if (ch < 0){

		if (ch == '\n') {

			/* process line */

			if ( h->q > h->line && h->q[-1] == '\r'){
				h->q--;
			}

			*h->q = '\0';

			i_err = http_process_line(h, h->line, h->line_count, new_location);
			if (i_err < 0){
				return STX_FAIL;
			}

			if (i_err == 0){
				return STX_OK;
			}

			h->line_count++;

			h->q = h->line;

		}
		else {

			if ((h->q - h->line) < sizeof(h->line) - 1){
				*h->q++ = ch;
			}

		} /* if (ch == '\n') { ... } else { */

	} /* for(;;) { */

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_xio_vt_xxx_flush( stx_xio* pio )
{
	return STX_OK;
}

