

#include "base_pin_wnd.h"


#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif

STX_RESULT	base_pin_wnd_initialize(STX_HANDLE h,stx_xini* h_xini,STX_HANDLE h_parent);
STX_RESULT	base_pin_wnd_serialize(STX_HANDLE h,stx_xini* h_xini,STX_HANDLE h_parent);
stx_base_pin* base_pin_wnd_GetPin(STX_HANDLE h);
void		base_pin_wnd_SetPin(STX_HANDLE h,stx_base_pin* pin);
void		base_pin_wnd_ReleasePin(STX_HANDLE h);
void		base_pin_wnd_move(STX_HANDLE h,s32 x,s32 y);
POINT		base_pin_wnd_GetPoint(STX_HANDLE h);




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

base_pin_wnd* create_base_pin_wnd(size_t i_size,HWND hWnd)
{
	base_pin_wnd* the;

	if( !i_size ) {
		i_size = sizeof(base_pin_wnd);
	}

	the = (base_pin_wnd*)smart_mallocz(i_size,
		"base_pin_wnd.c::create_base_pin_wnd::the");

	if( !the ) {
		return NULL;
	}

	//
	the->m_hWnd = hWnd;
	the->m_hPin = NULL;
	the->m_bFocus = FALSE;
	the->m_bConnection = FALSE;
	the->m_hPropStream = NULL;
	INIT_MEMBER(the->m_minf);
	the->m_insid = stx_gid_create();

	the->initialize = base_pin_wnd_initialize;
	the->serialize = base_pin_wnd_serialize;
	the->close = base_pin_wnd_close;
	the->GetPin = base_pin_wnd_GetPin;
	the->SetPin = base_pin_wnd_SetPin;
	the->ReleasePin = base_pin_wnd_ReleasePin;
	the->GetPoint = base_pin_wnd_GetPoint;

	return the;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void base_pin_wnd_close(STX_HANDLE h)
{
	STX_DIRECT_THE(base_pin_wnd);

	SAFE_XDELETE0(the->m_hPin);

	if( the->m_hPropStream ) {
		the->m_hPropStream->close(the->m_hPropStream);
	}

	stx_free( the );
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_RESULT	base_pin_wnd_initialize(STX_HANDLE h,stx_xini* h_xini,STX_HANDLE h_parent)
{
	STX_RESULT		i_err;
	STX_HANDLE		h_insid;

	char*           sz_val;

	STX_HANDLE		h_prop;
	STX_HANDLE      h_prop_data;
	s32             i_stream_size;
	u8*				p_prop_data;

	STX_DIRECT_THE(base_pin_wnd);


	i_err = STX_FAIL;

	p_prop_data = NULL;

	do{
		// instance id;
		i_err = h_xini->create_key(h_xini,h_parent,g_szInstanceId,NULL,&h_insid);
		if( STX_INI_OK != i_err ) {
			break;
		}
		i_err = h_xini->read_string(h_xini,h_insid,&sz_val);
		if( STX_INI_OK != i_err ) {
			break;
		}
		binary_from_string(the->m_insid.data,sz_val);

		// property page;
		i_err = h_xini->create_key(h_xini,h_parent,(char*)g_szPropertyPage,NULL,&h_prop);
		if( STX_INI_OK != i_err ) {
			break;
		}
		i_err = h_xini->read_string(h_xini,h_prop,&sz_val);
		if( STX_INI_OK != i_err ) {
			break;
		}
		if( strcmp(g_szTrue,sz_val ) ) {
			break;
		}
		i_err = h_xini->create_key(h_xini,h_prop,(char*)g_szPropertyData,NULL,&h_prop_data);
		if( STX_INI_OK != i_err ) {
			break;
		}
		i_stream_size = 0;
		i_err = h_xini->read_base64(h_xini,h_prop,&i_stream_size,NULL);
		if( STX_INI_OK != i_err ) {
			break;
		}

		if( i_stream_size ) {

			size_t i_data;

			STX_MAKE_TRACE
			p_prop_data = (u8*)smart_mallocz(i_stream_size,STX_MAP_TRACE);
			if( !p_prop_data ) {
				i_err = STX_FAIL;
				break;
			}

			i_err = h_xini->read_base64(h_xini,h_prop,&i_stream_size,p_prop_data);
			if( STX_INI_OK != i_err ) {
				break;
			}

			the->m_hPropStream = XCREATE(stx_io_stream,NULL);
			if( !the->m_hPropStream ) {
				i_err = STX_FAIL;
				break;
			}

			the->m_hPropStream->write(the->m_hPropStream,p_prop_data,i_stream_size,&i_data);

		} // if( i_stream_size ) {

		i_err = STX_OK;

	}while(FALSE);

	if( p_prop_data ) {
		stx_free(p_prop_data);
	}

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_RESULT	base_pin_wnd_serialize(STX_HANDLE h,stx_xini* h_xini,STX_HANDLE h_parent)
{

	STX_RESULT			i_err;
	char				sz_gid[64];

	STX_HANDLE			h_insid;
	STX_HANDLE			h_prop;
	STX_HANDLE			h_prop_data;
	stx_xio*			h_stream;
	stx_io_op_param		inf;
	s32					i_stream_size;

	STX_DIRECT_THE(base_pin_wnd);

	i_err = STX_FAIL;
	h_stream = NULL;
	INIT_MEMBER(inf);

	do{

		// instance id;
		i_err = h_xini->create_key(h_xini,h_parent,g_szInstanceId,NULL,&h_insid);
		if( STX_INI_OK != i_err ) {
			break;
		}
		binary_to_string(sizeof(stx_gid),the->m_insid.data,sz_gid);
		i_err = h_xini->write_string(h_xini,h_insid,sz_gid);
		if( STX_INI_OK != i_err ) {
			break;
		}


		// property page;

		// binary length will be updated when write in binary data;
		i_err = h_xini->create_key(h_xini,h_parent,(char*)g_szPropertyPage,(char*)g_szFalse,&h_prop);
		if( STX_INI_OK != i_err ) {
			break;
		}

		if( !the->m_hPin ) {
			break;
		}

		h_stream = XCREATE(stx_io_stream,NULL);
		if( !h_stream ) {
			i_err = STX_FAIL;
			break;
		}

		i_err = the->m_hPin->get_property(the->m_hPin,h_stream);
		if( STX_OK != i_err ) {
			i_err = STX_OK;
			break;
		}

		i_err = h_stream->get(h_stream,STX_IO_READ_P,&inf);
		if( STX_OK != i_err ) {
			break;
		}
		i_stream_size = (s32)h_stream->size(h_stream);

		i_err = h_xini->write_string(h_xini,h_prop,(char*)g_szTrue);
		if( STX_INI_OK != i_err ) {
			break;
		}

		i_err = h_xini->create_key(h_xini,h_prop,(char*)g_szPropertyData,(char*)g_szFalse,&h_prop_data);
		if( STX_INI_OK != i_err ) {
			break;
		}

		i_err = h_xini->write_base64(h_xini,h_prop_data,i_stream_size,(u8*)inf.buf);
		if( STX_INI_OK != i_err ) {
			break;
		}

		i_err = STX_OK;

	}while(FALSE);

	if( h_stream ){
		h_stream->close(h_stream);
	}

	return i_err;

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void base_pin_wnd_SetPin(STX_HANDLE h,stx_base_pin* pin)
{
	STX_DIRECT_THE(base_pin_wnd);

	the->m_hPin = pin;
	the->m_hPin->add_ref(the->m_hPin);
	the->m_hPin->set_insid(the->m_hPin,the->m_insid);

	if( the->m_hPropStream ) {
		the->m_hPin->set_property(the->m_hPin,the->m_hPropStream);
		the->m_hPropStream->close(the->m_hPropStream);
		the->m_hPropStream = NULL;
	}

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void base_pin_wnd_ReleasePin(STX_HANDLE h)
{
	STX_DIRECT_THE(base_pin_wnd);
	SAFE_XDELETE0(the->m_hPin);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

stx_base_pin* base_pin_wnd_GetPin(STX_HANDLE h)
{
	STX_DIRECT_THE(base_pin_wnd);
	return the->m_hPin;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

POINT base_pin_wnd_GetPoint(STX_HANDLE h)
{
	STX_DIRECT_THE(base_pin_wnd);
	{
		POINT p = { the->m_pos.left,
			the->m_pos.top + (the->m_pos.bottom-the->m_pos.top) / 2 
		};
		return p;
	}
}	

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void base_pin_wnd_move(STX_HANDLE h,s32 x,s32 y)
{
	STX_DIRECT_THE(base_pin_wnd);

	the->m_pos.left += x;
	the->m_pos.right += x;
	the->m_pos.top += y;
	the->m_pos.bottom += y;

}
