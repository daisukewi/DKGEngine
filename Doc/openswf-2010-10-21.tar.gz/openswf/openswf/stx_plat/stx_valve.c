/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/
#include "stx_valve.h"

#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif


#ifdef _MAP_THE	
#	undef _MAP_THE	
#endif	
#define _MAP_THE STX_MAP_THE(stx_valve)


// {9F2429A6-5F9D-40e4-AD0F-56A6E23BA64C}
DEFINE_XGUID(STX_IID_ValveCallback,
0x9f2429a6, 0x5f9d, 0x40e4, 0xad, 0xf, 0x56, 0xa6, 0xe2, 0x3b, 0xa6, 0x4c);


// {75859194-9BB0-4ea8-B2D3-2940B6A6AE33}
DEFINE_XGUID( STX_CLSID_Valve,
0x75859194, 0x9bb0, 0x4ea8, 0xb2, 0xd3, 0x29, 0x40, 0xb6, 0xa6, 0xae, 0x33 );

char* g_szStreamX_valve = STX_PLUGIN_STRING(valve);

STX_INPUT_MEDIA_TYPE_MAP_BEGIN(stx_valve)
/**/MEDIA_TYPE_MAP_ITEM(STX_GID_NULL,STX_GID_NULL)
STX_INPUT_MEDIA_TYPE_MAP_END()

STX_OUTPUT_MEDIA_TYPE_MAP_BEGIN(stx_valve)
/**/MEDIA_TYPE_MAP_ITEM(STX_GID_NULL,STX_GID_NULL)
STX_OUTPUT_MEDIA_TYPE_MAP_END()


STX_COM_BEGIN(stx_valve);
/**/
/**/STX_PUBLIC(stx_base_filter)
/**/STX_COM_DATA_DEFAULT(stx_base_filter)
/**/
/**/STX_PUBLIC(valve_callback)
/**/
/**/stx_base_pin*	 p_input_pin;
/**/stx_output_pin*	 p_output_pin;
/**/stx_media_data*	 h_mdat;
/**/
/**/s64              i_start_sample_time;
/**/s64              i_start_time;
/**/s64              i_last_sample_time;
/**/s64              i_last_time;
/**/s64				 i_rend_time;
/**/b32				 b_audio;
/**/
STX_COM_END();

STX_COM_FUNC_DECL_DEFAULT(stx_base_filter,stx_base_filter_vt);
STX_COM_FUNCIMP_DEFAULT(stx_valve,stx_base_filter,stx_base_filter_vt);

STX_COM_FUNC_DECL_DEFAULT(valve_callback,valve_callback_vt);
STX_COM_FUNCIMP_DEFAULT(stx_valve,valve_callback,valve_callback_vt);


/*{{{STX_MSG_PROC_DECLARE***************************************************/
/**/STX_MSG_PROC_DECLARE(dispatch_msg)
/**/STX_MSG_PROC_DECLARE(response_msg)
//STX_MSG_PROC_DECLARE(down_stream_msg)
/*}}}***********************************************************************/


/*{{{STX_MSG_ENTRY_DECLARE**************************************************/
/**/STX_MSG_ENTRY_DECLARE(on_Play)
/**/STX_MSG_ENTRY_DECLARE(on_Stop)
/**/STX_MSG_ENTRY_DECLARE(at_Stop)
/**/STX_MSG_ENTRY_DECLARE(at_BreakPin)
/*}}}***********************************************************************/


/*{{{STX_BEGIN_MSG_MAP******************************************************/
STX_BEGIN_MSG_MAP(the_msg_data)
/* to do : add msg process entry here; */
/**/ON_STX_MSG(STX_MSG_Play,on_Play)
/**/ON_STX_MSG(STX_MSG_Stop,on_Stop)
STX_END_MSG_MAP
/*}}}***********************************************************************/

/*{{{STX_DISPATCH_MSG_PROC**************************************************/
STX_DISPATCH_MSG_PROC( dispatch_msg,the_msg_data )
/*}}}***********************************************************************/


/*{{{STX_BEGIN_MSG_RESPONSE_MAP*********************************************/
STX_BEGIN_MSG_RESPONSE_MAP(the_msg_response)
/* to do : add msg process entry here; */
/**/ON_STX_MSG(STX_MSG_BreakPin,at_BreakPin)
/**/ON_STX_MSG(STX_MSG_Stop,at_Stop)
STX_END_MSG_RESPONSE_MAP
/*}}}***********************************************************************/


/*{{{STX_RESPONSE_MSG_PROC**************************************************/
STX_RESPONSE_MSG_PROC( response_msg,the_msg_response )
/*}}}***********************************************************************/



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_COM_MAP_BEGIN(stx_valve)
/**/STX_COM_MAP_ITEM(STX_IID_BaseFilter)
/**/STX_COM_MAP_ITEM(STX_IID_ValveCallback)
STX_COM_MAP_END()

STX_NEW_BEGIN(stx_valve)
{
	STX_SET_THE(stx_base_filter);
	STX_COM_NEW_DEFAULT(stx_base_filter,the->stx_base_filter_vt,stx_base_filter_vt,
		STX_CLSID_Valve,STX_CATEGORY_IntermediateFilter,g_szStreamX_valve);

	STX_SET_THE(valve_callback);
	STX_COM_NEW_DEFAULT(valve_callback,the->valve_callback_vt,valve_callback_vt,
		STX_CLSID_Valve,STX_CATEGORY_IntermediateFilter,g_szStreamX_valve);

	the->p_input_pin = XCREATE(stx_input_pin,NULL);
	if( !the->p_input_pin ) {
		break;
	}
	the->p_input_pin->set_parent(the->p_input_pin,(stx_base_plugin *)&the->stx_base_filter_vt);

	the->p_output_pin = XCREATE(valve_outpin,NULL,&the->valve_callback_vt);
	if( !the->p_output_pin ) {
		break;
	}
	the->p_output_pin->set_parent(the->p_output_pin,(stx_base_plugin *)&the->stx_base_filter_vt);

}
STX_NEW_END()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_PURE 
STX_QUERY_BEGIN(stx_valve)
{
	STX_COM_QUERY_DEFAULT(stx_base_filter,the->stx_base_filter_vt);
}
STX_QUERY_END()




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_DELETE_BEGIN(stx_valve)
{
	SAFE_XDELETE(the->p_input_pin);
	SAFE_XDELETE(the->p_output_pin);

	STX_COM_DELETE_DEFAULT(stx_base_filter);
}
STX_DELETE_END
(
/**/STX_COM_DELETE_BEGIN(stx_base_filter)
/**/,
/**/STX_COM_DELETE_END(stx_base_filter)
)



STX_PRIVATE STX_RESULT deliver_sample(THEE h,stx_sync_inf* h_sync);


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
valve_callback_vt_xxx_release_media_data(THEE h,stx_media_data* p_mdat)
{
	_MAP_THE;
	return XCALL(release_media_data,the->p_input_pin,p_mdat);
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_send_msg
( STX_HANDLE h, stx_base_message* p_msg )
{
	_MAP_THE;
	{
		STX_RESULT	i_err;
		u32			i_type;

		i_err = dispatch_msg(h,p_msg);
		if( i_err < 0 || p_msg->is_msg_closed(p_msg)) {
			return i_err;
		}

		i_type = p_msg->get_msg_type(p_msg);

		if( i_type & STX_MSG_TYPE_UPSTREAM && the->p_input_pin ) {
			i_err = the->p_input_pin->send_msg(the->p_input_pin,p_msg);
			if( i_err < 0 || p_msg->is_msg_closed(p_msg)) {
				return i_err;
			}
		}
		else if( i_type & STX_MSG_TYPE_DOWNSTREAM  && the->p_output_pin ) {
			i_err = the->p_output_pin->send_msg(the->p_output_pin,p_msg);
			if( i_err < 0 || p_msg->is_msg_closed(p_msg)) {
				return i_err;
			}
		}

		return response_msg(h,p_msg);
	}

	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
as for emulate filter, the initial state of this render have no input pin and 
any data type;
so the emulate filter could not be registered, must be load and unload at run time;
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_enum_input_pin
(STX_HANDLE h,sint32 *i_idx,stx_base_pin** pp_pin )
{
	_MAP_THE;

	if( !i_idx ) {
		return STX_ERR_INVALID_PARAM;
	}

	if( !pp_pin ) {
		*i_idx = 1;
		return STX_OK;
	}

	if( *i_idx != 0 ) {
		return STX_ERR_INVALID_PARAM;
	}

	the->p_input_pin->add_ref(the->p_input_pin);
	*pp_pin = the->p_input_pin;

	return STX_OK;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_enum_output_pin
(STX_HANDLE h,sint32* i_idx,stx_base_pin** pp_pin )
{
	_MAP_THE;

	if( !i_idx ) {
		return STX_ERR_INVALID_PARAM;
	}

	if( !pp_pin ) {
		*i_idx = 1;
		return STX_OK;
	}

	if( *i_idx != 0 ) {
		return STX_ERR_INVALID_PARAM;
	}

	the->p_output_pin->add_ref(the->p_output_pin);
	*pp_pin = (stx_base_pin*)the->p_output_pin;

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_check_input_media_type
( STX_HANDLE h, stx_media_type* p_mtyp )
{
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_check_output_media_type
( STX_HANDLE h, stx_media_type* p_mtyp )
{
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_set_input_media_type
( STX_HANDLE h, stx_media_type* p_mdt )
{
	stx_base_pin*		p_pin;
	stx_gid				major_type;

	_MAP_THE;

	major_type = p_mdt->get_type(p_mdt);
	the->b_audio = IS_EQUAL_GID(major_type,MEDIATYPE_Audio);

	p_pin = the->p_input_pin;
	return p_pin->set_media_type(p_pin,p_mdt);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_set_output_media_type
(STX_HANDLE	h,stx_media_type* p_mdt )
{
	STX_RESULT				i_err;
	stx_output_pin*			p_pin;
	void*					hdr;
	s32						i_size;
	stx_media_type*			p_mtype_in;

	_MAP_THE;

	i_err = STX_FAIL;
	p_pin = the->p_output_pin;
	p_mtype_in = NULL;

	do{
		p_mtype_in = the->p_input_pin->get_media_type(the->p_input_pin);
		if( !p_mtype_in ) {
			break;
		}

		p_mdt->set_type(p_mdt,p_mtype_in->get_type(p_mtype_in));
		p_mdt->set_subtype(p_mdt,p_mtype_in->get_subtype(p_mtype_in));
		p_mdt->set_type_name(p_mdt,p_mtype_in->get_type_name(p_mtype_in));
		p_mdt->set_subtype_name(p_mdt,p_mtype_in->get_subtype_name(p_mtype_in));

#if 0
		stx_log("valve %x subtype = %s\r\n",the,p_mtype_in->get_subtype_name(p_mtype_in));
#endif

		i_err = p_mtype_in->get_header(p_mtype_in,&hdr,&i_size);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = p_mdt->set_header(p_mdt,hdr,i_size);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = the->p_output_pin->set_media_type(the->p_output_pin,p_mdt);

	}while(FALSE);

	SAFE_XDELETE(p_mtype_in);

	return i_err;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_base_filter_vt_xxx_new_segment( STX_HANDLE h )
{
	_MAP_THE;

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_flush
(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	_MAP_THE;

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_start
(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	_MAP_THE;

	return the->p_output_pin->start(the->p_output_pin,i_flag,h_sync);
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_stop
(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	_MAP_THE;

	return the->p_output_pin->stop(the->p_output_pin,i_flag,h_sync);
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_receive
(
	STX_HANDLE			h,
	stx_base_pin*		h_pin,		// which input pin;
	stx_media_data**	pp_mdat,	// output media data;
	stx_sync_inf*		h_sync
)
{
	_MAP_THE;

	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_ENTRY STX_RESULT on_Play(STX_HANDLE h, stx_base_message* p_msg )
{
	_MAP_THE;


	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_ENTRY STX_RESULT at_BreakPin(STX_HANDLE h, stx_base_message* p_msg )
{
	_MAP_THE;

	if( the->p_input_pin ) {
		the->p_input_pin->break_connect(the->p_input_pin);
	}

	if( the->p_output_pin ) {
		the->p_output_pin->break_connect(the->p_output_pin);
	}

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_ENTRY STX_RESULT on_Stop(STX_HANDLE h, stx_base_message* p_msg )
{
	_MAP_THE;

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_ENTRY STX_RESULT at_Stop(STX_HANDLE h, stx_base_message* p_msg )
{
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT deliver_sample(STX_HANDLE h,stx_sync_inf* h_sync)
{
	_MAP_THE;
	{
		STX_RESULT		i_err;
		u64				ref_time;
		s64				i_rend_time;
		s64				i_time, i_sample_time, i_pts;

		stx_media_data* p_mdat = the->h_mdat;

		i_pts = p_mdat->get_time(p_mdat,NULL);

		if( the->h_ssrc ) {

			ref_time = REFTIME2MILISEC(i_pts);
			i_time = stx_get_milisec();
			if( !the->i_start_time) {
				the->i_start_time = i_time;
				the->i_start_sample_time = ref_time;
			}

			i_time -= the->i_start_time;
			i_rend_time = ref_time - the->i_start_sample_time;

			if( i_time < i_rend_time ) {
				s64 const i_idle_time = i_rend_time - i_time;
#if 0
				stx_log("valve idle time is %"PRId64"d ms;\r\n",i_idle_time);
#endif
				h_sync->i_idle = MILISEC2REFTIME(i_idle_time);
				RESET_XENTRY(h_sync,h);
				return STX_WOUNLD_BLOCK;
			}
		}//if( the->h_ssrc ) {

#if 0
		stx_log("valve %x deliver data\r\n",the);
#endif

		i_err = XCALL(deliver,the->p_output_pin,p_mdat,h_sync);

		i_time = stx_get_milisec();
		i_sample_time = REFTIME2MILISEC(p_mdat->get_time(p_mdat,NULL));
		//stx_log("sample time = %d,",i_sample_time);
		//stx_log("clock interval= %d,",i_time - the->i_last_time);
		//stx_log("frame interval= %d\r\n",i_sample_time - the->i_last_sample_time);
		the->i_last_time = i_time;
		the->i_last_sample_time = i_sample_time;

		XCALL(release_media_data,the->p_output_pin,p_mdat);

		if( the->b_audio && !the->i_rend_time ) {
			the->i_rend_time = i_pts;
			on_first_audio_data((stx_base_plugin*)the->p_input_pin,i_pts);
		}

		return i_err;
	}

}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_deliver
(
 STX_HANDLE			h,
 stx_base_pin*		h_pin, // which input pin;
 stx_media_data*	p_mdat, // output media data;
 stx_sync_inf*		h_sync
 )
{
	_MAP_THE;
	the->h_mdat = p_mdat;
	RESET_XENTRY(h_sync,h);
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_run
(STX_HANDLE h,stx_sync_inf* h_sync )
{
	_MAP_THE;
	{
		return deliver_sample(h,h_sync);
	}

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_get_property
(STX_HANDLE h,stx_xio* h_xio)
{
	_MAP_THE;

	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_set_property
(STX_HANDLE h,stx_xio* h_xio)
{
	_MAP_THE;

	return STX_OK;
}


