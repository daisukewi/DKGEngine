/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-10
***********************************************************************************/
#include "app_wnd.h"
#include "ActiveMovieWindow.h"
#include "base_canvas.h"

#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif

#ifdef __WIN32_LIB

#ifdef _MAP_THE	
#undef _MAP_THE	
#endif	
#define _MAP_THE STX_MAP_THE(app_wnd_ctx)	

#ifdef _DIRECT_THE	
#undef _DIRECT_THE	
#endif	
#define _DIRECT_THE STX_DIRECT_THE(app_wnd_ctx)	


typedef struct AppWndInf AppWndInf;

struct AppWndInf{
	stx_base_plugin*	pVidWnd;
	HWND				hWnd;
	AppWndInf*			next;
};


STX_API STX_COM(app_wnd_ctx);

STX_API_IMP 
CREATE_STX_COM(stx_base_plugin,STX_IID_BasePlugin,app_wnd_ctx);


STX_COM_BEGIN(app_wnd_ctx);
/**/
/**/STX_PUBLIC(stx_base_plugin)
/**/STX_COM_DATA_DEFAULT(stx_base_plugin)
/**/
/**/STX_HANDLE			h_mutex;
/**/AppWndInf*			p_first;
/**/THEE				h_task;
/**/
/**/
/**/
STX_COM_END();


static stx_base_plugin* g_h;

#define APPWND_MAP_THE() \
	app_wnd_ctx* the = * (  (app_wnd_ctx**) ( ( (u8*)g_h ) - sizeof(void*) ) )

#define lock_app_wnd()		stx_waitfor_mutex(the->h_mutex,INFINITE)
#define unlock_app_wnd()	stx_release_mutex(the->h_mutex)




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_COM_FUNC_DECL_DEFAULT(stx_base_plugin,stx_base_plugin_vt);
STX_COM_FUNCIMP_DEFAULT(app_wnd_ctx,stx_base_plugin,stx_base_plugin_vt);


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

static const char* g_szContorlModeActiveMovieWindow = "StreamX Service AppWindow context";

STX_COM_MAP_BEGIN(app_wnd_ctx)
/**/STX_COM_MAP_ITEM(STX_IID_BasePlugin)
STX_COM_MAP_END()

STX_NEW_BEGIN(app_wnd_ctx)
{
	STX_SET_THE(stx_base_plugin);
	STX_COM_NEW_DEFAULT(stx_base_plugin,the->stx_base_plugin_vt,stx_base_plugin_vt,
		STX_GID_NULL,STX_GID_NULL,g_szContorlModeActiveMovieWindow);

	the->h_mutex = stx_create_mutex(NULL,0,NULL);
	if( !the->h_mutex) {
		break;
	}
}
STX_NEW_END()



STX_PURE 
STX_QUERY_BEGIN(app_wnd_ctx)
{
	STX_COM_QUERY_DEFAULT(stx_base_plugin,the->stx_base_plugin_vt);
}
STX_QUERY_END()


/***********************************************************************
LxVidActMVW::~LxVidActMVW()
***********************************************************************/
STX_PURE 
STX_DELETE_BEGIN(app_wnd_ctx)
{
	stx_close_mutex(the->h_mutex);
	the->h_mutex = NULL;

	STX_COM_DELETE_DEFAULT(stx_base_plugin);
}
STX_DELETE_END
(
STX_COM_DELETE_BEGIN(stx_base_plugin)
,
STX_COM_DELETE_END(stx_base_plugin)
)





/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_plugin_vt_xxx_run
(STX_HANDLE h,stx_sync_inf* h_sync)
{
	_MAP_THE;
	{
		STX_RESULT	i_err;
		s32			i_work;

		i_err = STX_OK;
		i_work = 0;

		lock_app_wnd();

		do{

			AppWndInf* p = the->p_first;

			while( p ) {

				stx_sync_inf inf = {0};

				i_err = p->pVidWnd->run(p->pVidWnd,&inf);
				if( i_err < 0 ) {
					break;
				}

				if( STX_OK == i_err ) {
					i_work ++;
				}

				p = p->next;
			}

			if( i_err < 0 ) {
				break;
			}

			if( 0 == i_work ) {
				h_sync->i_idle = MILISEC2REFTIME(10);
				i_err = STX_WOUNLD_BLOCK;
				break;
			}

			i_err = STX_OK;

		}while(FALSE);

		unlock_app_wnd();

		return i_err;
	}

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_plugin_vt_xxx_flush
(STX_HANDLE h,u32 i_flag,stx_sync_inf *h_sync)
{
	_MAP_THE;
	{
	}

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_plugin_vt_xxx_start
(STX_HANDLE h,u32 i_flag,stx_sync_inf *h_sync)
{
	_MAP_THE;

	return STX_OK; // disable

	{
		STX_RESULT i_err;

		stx_base_graph_builder* gbd = (stx_base_graph_builder*)h_sync->h_data;

		i_err = gbd->alloc_ssrc(gbd,FALSE,NULL,1,&the->h_ssrc);
		if( STX_OK != i_err ) {
			return i_err;
		}

		i_err = XCALL(reg_task,the->h_ssrc,&the->h_task,(stx_base_plugin*)&the->stx_base_plugin_vt,TASK_NORMAL);
		if( STX_OK != i_err ) {
			return i_err;
		}

		the->em_status = emStxStatusPlay;
		// active ssrc handle;
		XCALL(reset_task,the->h_ssrc,the->h_task,0,0);

		return STX_OK;
	}

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT stop_proc( app_wnd_ctx* the)
{
	if( emStxStatusStop != the->em_status ){
		XCALL(set_task_events,the->h_ssrc,the->h_task,ev_stop);
		return STX_WOUNLD_BLOCK;
	}

	// unreg ssrc handle;
	XCALL(unreg_task,the->h_ssrc,the->h_task);
	the->em_status = emStxStatusInit;

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_plugin_vt_xxx_stop
(STX_HANDLE h,u32 i_flag,stx_sync_inf *h_sync)
{
	_MAP_THE;

	return STX_OK; // disable

	{
		STX_RESULT i_err;

		lock_app_wnd();

		i_err = stop_proc(the);

		unlock_app_wnd();

		return i_err;
	}
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_plugin_vt_xxx_send_msg
(STX_HANDLE h,stx_base_message *p_msg)
{
	_MAP_THE;
	{
	}
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_plugin_vt_xxx_set_property
(STX_HANDLE h,stx_xio *h_xio)
{
	_MAP_THE;
	{
		// back ground file path name ???
		// auto fix aspect raito ???
		// top most ???
	}

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_plugin_vt_xxx_get_property
(STX_HANDLE h,stx_xio *h_xio)
{
	_MAP_THE;
	{
	}

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
b32 init_app_wnd_env()
{
	if( !g_h ) {

		STX_RESULT i_err;

		g_h = XCREATE(app_wnd_ctx,NULL);

		for( ; ; ) {

			stx_sync_inf inf = {0};

			i_err = g_h->start(g_h,0,&inf);
			if( STX_OK == i_err ) {
				break;
			}

			if( i_err < 0 ) {
				return FALSE;
			}

			stx_sleep(10);

		} // for( ; ; ) {

	}

	return g_h != NULL ;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void close_app_wnd_env()
{
	STX_RESULT i_err;

	if( g_h ) {

		for( ; ; ) {

			stx_sync_inf inf = {0};

			i_err = g_h->stop(g_h,0,&inf);
			if( STX_OK == i_err ) {
				break;
			}

			if( i_err < 0 ) {
				return;
			}

			stx_sleep(10);

		} // for( ; ; ) {

		SAFE_XDELETE0(g_h);
	}

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT add_app_wnd(stx_base_plugin* pVidWnd,HWND hWnd )
{
	DECL_TRACE
	STX_RESULT i_err;
	AppWndInf* pInf;

	APPWND_MAP_THE();

	lock_app_wnd();

	do{

		i_err = STX_FAIL;

		MAKE_TRACE2
			pInf = (AppWndInf*)smart_mallocz(sizeof(AppWndInf),MAP_TRACE);
		if( !pInf ) {
			break;
		}
		pInf->pVidWnd = pVidWnd;
		pInf->hWnd = hWnd;
		pInf->next = NULL;
		if( !the->p_first ) {
			the->p_first = pInf;
			i_err = STX_OK;
			break;
		}

		{
			AppWndInf* p = the->p_first;
			while( p->next ) {
				p = p->next;
			}
			p->next = pInf;
		}

		i_err = STX_OK;

	}while(FALSE);

	unlock_app_wnd();

	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void rem_app_wnd(stx_base_plugin* pVidWnd)
{
	APPWND_MAP_THE();

	lock_app_wnd();
	{
		AppWndInf* p = the->p_first;
		AppWndInf* prev = NULL;

		while( p ) {
			if( p->pVidWnd == pVidWnd ) {
				if( prev ) {
					prev->next = p->next;
				}
				else {
					the->p_first = p->next;
				}

				stx_free(p);
				unlock_app_wnd();
				return;
			}
			p = p->next;
		}
		unlock_app_wnd();
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
stx_base_plugin* app_wnd_from_hwnd(HWND hWnd)
{	
	APPWND_MAP_THE();

	lock_app_wnd();
	{
		AppWndInf* p = the->p_first;
		AppWndInf* prev = NULL;

		while( p ) {
			if( p->hWnd == hWnd ) {
				unlock_app_wnd();
				return p->pVidWnd;
			}
			p = p->next;
		}
	}

	unlock_app_wnd();
	return NULL;
}


#endif // #ifdef __WIN32_LIB