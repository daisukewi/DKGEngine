/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-11
***********************************************************************************/
#include "stdio.h"
#include "stdlib.h"
#include "fcntl.h"
#include "malloc.h"
#include "memory.h"
#include "string.h"

#include "stx_session.h"
#include "stx_listen_filter.h"
#include "stx_protocol.h"
#include "stx_listen_socket.h"

#include "stx_os.h"
#include "stx_mem.h"
#include "stx_debug.h"
#include "stx_module_reg.h"
#include "stx_io_as.h"
#include "stx_stack.h"
#include "stx_hash.h"
#include "stx_io_interleaved.h"
#include "stp_download.h"


#include "base_canvas.h"



#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif


// {60DF5E98-5644-444f-90A6-56B472F062A7}
DEFINE_XGUID( STX_CLSID_ListenSocket,
0x60df5e98, 0x5644, 0x444f, 0x90, 0xa6, 0x56, 0xb4, 0x72, 0xf0, 0x62, 0xa7);

char* g_szStreamX_ListenSocket = "StreamX stx listen socket";


enum{
	em_session_start,
	em_session_stop,
};


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_INTERF(session_ctx);

struct session_ctx{
	stx_xio*			h_tcp;
	stx_base_session*	h_session;
	stx_base_plugin*	h_plugin;
};


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE void close_session_ctx(THEE h)
{
	session_ctx* ctx = (session_ctx*)h;
	{
		char szins[64];
		stx_gid insgid = ctx->h_plugin->get_insid(ctx->h_plugin);
		binary_to_string(16,insgid.data,szins);
		stx_log("close session <%s>\r\n",szins);
	}

	{
		stx_sync_inf inf = {0};
		ctx->h_plugin->stop(ctx->h_plugin,TRUE,&inf);
	}

	SAFE_XDELETE0(ctx->h_session);
	SAFE_XDELETE0(ctx->h_plugin);
	SAFE_CLOSEXIO(ctx->h_tcp);
	stx_free(ctx);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API_IMP CREATE_STX_COM(stx_base_plugin,STX_IID_BasePlugin,listen_socket);



STX_COM_BEGIN(listen_socket);
/**/
/**/STX_PUBLIC(stx_base_plugin)
/**/STX_COM_DATA_DEFAULT(stx_base_plugin)
/**/
/**/THEE				h_stack[2];
/**/THEE				h_task;
/**/THEE				h_mutex;
/**/THEE				h_hash;
/**/stx_xio*			h_socket;  // listen socket;
/**/THEE				h_stop;
/**/stx_prot_callback*	h_callback;
/**/
STX_COM_END();


#define socket_lock()	stx_waitfor_mutex(the->h_mutex,INFINITE)
#define socket_unlock()	stx_release_mutex(the->h_mutex)

STX_COM_FUNC_DECL_DEFAULT(stx_base_plugin,stx_base_plugin_vt);
STX_COM_FUNCIMP_DEFAULT(listen_socket,stx_base_plugin,stx_base_plugin_vt);

/*{{{STX_MSG_ENTRY_DECLARE**************************************************/
STX_MSG_ENTRY_DECLARE(on_auto_stop)
STX_MSG_ENTRY_DECLARE(on_app_stop)
/*}}}***********************************************************************/


/*{{{STX_BEGIN_MSG_MAP******************************************************/
STX_BEGIN_MSG_MAP(the_msg_data)
/* to do : add msg process entry here; */
/**/ON_STX_MSG(STX_MSG_AutoStop,on_auto_stop)
/**/ON_STX_MSG(STX_MSG_AppStop,on_app_stop)
STX_END_MSG_MAP
/*}}}***********************************************************************/


/*{{{STX_DISPATCH_MSG_PROC**************************************************/
STX_DISPATCH_MSG_PROC( dispatch_msg,the_msg_data )
/*}}}***********************************************************************/




STX_PRIVATE STX_RESULT	check_request(listen_socket* the);
STX_PRIVATE STX_RESULT  close_connection(listen_socket* the);

STX_PRIVATE void		
close_connection_context(listen_socket* the,session_ctx* prot);

STX_PRIVATE void 
close_connection_context_plug(listen_socket* the,STX_HANDLE h_plug);





/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_COM_MAP_BEGIN(listen_socket)
/**/STX_COM_MAP_ITEM(STX_IID_BasePlugin)
STX_COM_MAP_END()

STX_NEW_BEGIN(listen_socket)
{
	//STX_RESULT i_err;

	STX_SET_THE(stx_base_plugin);
	STX_COM_NEW_DEFAULT(stx_base_plugin,the->stx_base_plugin_vt,stx_base_plugin_vt,
		STX_GID_NULL,STX_CATEGORY_Service,g_szStreamX_ListenSocket);

	the->h_mutex = stx_create_mutex(NULL,0,NULL);
	if( !the->h_mutex ) {
		break;
	}

	the->h_hash = stx_hash_create(1024);
	if( !the->h_hash ) {
		break;
	}
	the->h_stop = stx_stack_create();
	if( !the->h_stop) {
		break;
	}

	{
		s32 i;
		for( i = 0; i < 2; i ++ ) {
			the->h_stack[i] = stx_stack_create();
			if( !the->h_stack[i] ) {
				break;
			}
		}
		if( i != 2 ) {
			break;
		}
	}

}
STX_NEW_END()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API_IMP	
STX_QUERY_BEGIN(listen_socket)
{
	STX_COM_QUERY_DEFAULT(stx_base_plugin,the->stx_base_plugin_vt);
}
STX_QUERY_END()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API_IMP	
STX_DELETE_BEGIN(listen_socket)
{
	if( the->h_hash ) {
		void* p = stx_hash_find_first(the->h_hash);
		while(p) {
			close_session_ctx(p);
			p = stx_hash_find_next(the->h_hash);
		}
		stx_hash_close(the->h_hash);
	}

	if( the->h_mutex) {
		stx_close_mutex(the->h_mutex);
	}

	{
		s32 i;
		for( i = 0; i < 2; i ++ ) {
			if( the->h_stack[i] ) {
				stx_stack_close(the->h_stack[i]);
			}
		}
	}
	if( the->h_stop ) {
		stx_stack_close(the->h_stop);
	}

	SAFE_XDELETE(the->h_callback);

	SAFE_CLOSEXIO(the->h_socket);

	STX_COM_DELETE_DEFAULT(stx_base_plugin);
}
STX_DELETE_END
(
STX_COM_DELETE_BEGIN(stx_base_plugin)
,
STX_COM_DELETE_END(stx_base_plugin)
)




 /***************************************************************************
 RETURN VALUE:
 INPUT:
 OUTPUT:
 NOTE:
 ***************************************************************************/
 STX_RESULT on_auto_stop(STX_HANDLE h,stx_base_message* p_msg)
{
	STX_MAP_THE(listen_socket);
	{
		STX_HANDLE h_stack = p_msg->get_stack(p_msg);

		// push plugin interface pointer;
		stx_stack_push(h_stack,(size_t)h);

		return STX_OK;
	}
}
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT on_app_stop(STX_HANDLE h,stx_base_message* p_msg)
{
	STX_MAP_THE(listen_socket);
	{
		session_ctx* ses;
		stx_msg_cnt* p_cnt = p_msg->get_msg_cnt(p_msg);

		socket_lock();

		ses = (session_ctx*) stx_hash_rem(the->h_hash,p_cnt->param.i_param[1]);

		if( ses ) {
			close_session_ctx(ses);
		}

		p_msg->set_msg_close(p_msg);

		socket_unlock();

		return STX_OK;
	}

}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_plugin_vt_xxx_send_msg
(STX_HANDLE h,stx_base_message * p_msg)
{
	STX_RESULT	i_err;

	STX_MAP_THE(listen_socket);

	do{
		u32 i_type;

		i_err = dispatch_msg(h,p_msg);
		if( i_err < 0 || p_msg->is_msg_closed(p_msg)) {
			break;
		}

		i_type = p_msg->get_msg_type(p_msg);

		if( i_type & STX_MSG_TYPE_ASYNC ) {
			i_err = the->h_ssrc->send_msg(the->h_ssrc,p_msg);
			break;
		}

		i_err = STX_OK;

	}while(FALSE);

	return i_err;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_base_plugin_vt_xxx_get_property(STX_HANDLE h,stx_xio* h_xio)
{
	STX_MAP_THE(listen_socket);

	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_base_plugin_vt_xxx_set_property(STX_HANDLE h,stx_xio* h_xio)
{
	STX_MAP_THE(listen_socket);

	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_base_plugin_vt_xxx_flush(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync )
{
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_base_plugin_vt_xxx_start(STX_HANDLE h,u32 i_flags,stx_sync_inf* h_sync )
{
	STX_RESULT i_err;

	STX_MAP_THE(listen_socket);

	if( FLAG_SET_INPUTIO == i_flags ) {		
		the->h_socket = (stx_xio*)h_sync->h_data;
		return STX_OK;
	}

	// FLAG_START_TASK
	assert(i_flags == FLAG_START_TASK);

	i_err = the->p_parent->query_interf(the->p_parent,STX_IID_StxProtCallback,&the->h_callback);
	if( STX_OK != i_err ) {
		return i_err;
	}

	i_err = the->h_gbd->alloc_ssrc(the->h_gbd,FALSE,NULL,1,&the->h_ssrc);
	if(STX_OK != i_err ){
		return i_err;
	}

	// active ssrc handle;
	{
		i_err = XCALL(reg_task,the->h_ssrc,&the->h_task,(stx_base_plugin*)h,TASK_NORMAL);
		if( STX_OK != i_err ) {
			return i_err;
		}
		the->em_status = emStxStatusPlay;
		XCALL(reset_task,the->h_ssrc,the->h_task,0,0);
	}

	return STX_OK;
}	

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
enum {
	em_sock_stop_start,
	em_sock_stop_session,
};

STX_PURE STX_RESULT 
stx_base_plugin_vt_xxx_stop(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync )
{
	STX_MAP_THE(listen_socket);
	{
		STX_RESULT		i_err;
		size_t*			h_status;
		size_t			i_status;
		session_ctx*	ses;
		s64				i_idle;
		THEE			h_tmp;

		socket_lock();

		do{
			if( emStxStatusInit == the->em_status ){
				i_err = STX_OK;
				break;
			}

			h_status = (size_t*)stx_stack_pop(the->h_stop);
			if( !h_status ) {
				the->h_ssrc->set_task_events(the->h_ssrc,the->h_task,ev_stop);
				stx_stack_push(the->h_stop,em_sock_stop_start);
				i_err = STX_WOUNLD_BLOCK;
				break;
			}

			i_status = *h_status;

			if( em_sock_stop_start == i_status ) {
				if( emStxStatusStop != the->em_status ){
					stx_stack_push(the->h_stop,em_sock_stop_start);
					i_err = STX_WOUNLD_BLOCK;
					break;
				}
				// task stopped;
				// check session num; push all the session to stack to be stopped;
				ses = (session_ctx*)stx_hash_find_first(the->h_hash);
				if( ses ) {
					do{
						stx_stack_push(the->h_stack[0],(size_t)ses);
						ses = stx_hash_find_next(the->h_hash);
					}while(ses);
					stx_hash_rem_all(the->h_hash);
				} //if( ses ) { 

				i_status = em_sock_stop_session;
			}

			if( em_sock_stop_session == i_status ) {

				i_idle = MILISEC2REFTIME(100);

				while( h_status = stx_stack_pop(the->h_stack[0]) ) {

					session_ctx* ses;
					stx_sync_inf inf;

					ses = (session_ctx*)*h_status;
					do{
						INIT_MEMBER(inf);
						i_err = ses->h_plugin->stop(ses->h_plugin,0,&inf);
					}while(STX_AGAIN == i_err);

					if( STX_IDLE == i_err || STX_WOUNLD_BLOCK == i_err ) {
						stx_stack_push(the->h_stack[1],(size_t)ses);
						stx_stack_push(the->h_stack[1],em_session_stop);
						if( inf.i_idle < i_idle ) {
							i_idle = inf.i_idle;
						}
						continue;
					}

					stx_hash_rem(the->h_hash,(size_t)ses->h_plugin);
					close_session_ctx(ses);

				} // while( h_status ) {

			} // if( em_sock_stop_session == i_status ) {

			// fatal;
			if( i_err < 0 ) {
				break;
			}

			if( stx_stack_top(the->h_stack[1] ) ) {

				// swap stack;
				h_tmp = the->h_stack[0];
				the->h_stack[0] = the->h_stack[1];
				the->h_stack[1] = h_tmp;

				stx_stack_push(the->h_stop,em_sock_stop_session);
				h_sync->i_idle = i_idle;
				i_err = STX_WOUNLD_BLOCK;
				break;
			} // if( stx_stack_top(the->h_stack[1] ) ) {

			// all session closed;
			// unreg task handle;
			the->h_ssrc->unreg_task(the->h_ssrc,the->h_task);
			the->h_task = NULL;
			the->em_status = emStxStatusInit;
			i_err = STX_OK;

		}while(FALSE);

		socket_unlock();

		return i_err;
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_base_plugin_vt_xxx_run(THEE h,stx_sync_inf* h_sync )
{

	STX_RESULT	i_err;
	size_t*		h_status;
	size_t		i_status;
	s64			i_idle;
	THEE		h_tmp;

	STX_MAP_THE(listen_socket);

	socket_lock();

	do{

		i_idle = MILISEC2REFTIME(100);

		while( h_status = stx_stack_pop(the->h_stack[0]) ) {

			session_ctx* ses;
			stx_sync_inf inf;

			i_status = *h_status;

			if( em_session_start == i_status ) {
				h_status = stx_stack_pop(the->h_stack[0]);
				if( !h_status ) {
					i_err = STX_FAIL;
					break;
				}
				ses = (session_ctx*)*h_status;
				do{
					INIT_MEMBER(inf);
					i_err = ses->h_plugin->start(ses->h_plugin,0,&inf);
				}while(STX_AGAIN == i_err);

				if( STX_IDLE == i_err || STX_WOUNLD_BLOCK == i_err ) {
					stx_stack_push(the->h_stack[1],(size_t)ses);
					stx_stack_push(the->h_stack[1],em_session_start);
					if( inf.i_idle < i_idle ) {
						i_idle = inf.i_idle;
					}
					continue;
				}

				i_err = stx_hash_add(the->h_hash,ses,(size_t)ses->h_plugin);
				if( STX_OK != i_err ) {
					break;
				}

				continue;

			} // if( em_session_start == i_status ) {

		} // while( h_status ) {

		// swap stack;
		h_tmp = the->h_stack[0];
		the->h_stack[0] = the->h_stack[1];
		the->h_stack[1] = h_tmp;

		i_err = check_request(the);
		if( STX_IDLE == i_err || STX_WOUNLD_BLOCK == i_err ) {
			h_sync->i_idle = MILISEC2REFTIME(10);
			if( i_idle < h_sync->i_idle ) {
				h_sync->i_idle = i_idle;
			}
		}

	}while(FALSE);

	socket_unlock();

	RESET_XENTRY(h_sync,h);

	return i_err;
}






/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT check_request(listen_socket* the)
{
	STX_RESULT				i_err;
	stx_xio*				h_new;
	session_ctx*			ses;
	size_t					i_read;

	i_err = STX_FAIL;
	h_new = NULL;
	ses = NULL;


	do{
		i_err = the->h_socket->read( the->h_socket, &h_new, sizeof(void*), &i_read );
	}while(STX_AGAIN == i_err );

	if( i_err != STX_OK ) {
		return i_err;
	}

	// add new task;
	ses = (session_ctx*) xmallocz( sizeof(session_ctx));
	if( !ses ) {
		return STX_FAIL;
	}

	ses->h_tcp = h_new;

	{
		stx_base_com* h_com = NULL;

		i_err = the->h_gbd->co_create_obj(the->h_gbd,STX_CLSID_StxSession,&h_com);
		if( STX_OK != i_err ) {
			return i_err;
		}

		i_err = h_com->query_interf(
			h_com,STX_IID_BasePlugin,(void**)&ses->h_plugin);

		if( STX_OK != i_err ) {
			SAFE_XDELETE(h_com);
			return i_err;
		}

		i_err = h_com->query_interf(
			h_com,STX_IID_BaseSession,(void**)&ses->h_session);

		SAFE_XDELETE(h_com);

		if( STX_OK != i_err ) {
			return i_err;
		}

	}

	// set gbd
	ses->h_plugin->set_gbd(ses->h_plugin,the->h_gbd);
	XCALL(add_ref,the->h_gbd);

	// set parent;
	ses->h_plugin->set_parent(ses->h_plugin,&the->stx_base_plugin_vt);

	i_err = ses->h_session->initialize(ses->h_session,ses->h_tcp,the->h_callback);
	if( STX_OK != i_err ) {
		return i_err;
	}

	// | success, then continue to start the task; 
	// V
	do{
		stx_sync_inf inf = {0};
		i_err = ses->h_plugin->start(ses->h_plugin,0,&inf);
	}while(STX_AGAIN == i_err);

	if( STX_IDLE == i_err || STX_WOUNLD_BLOCK == i_err ) {
		stx_stack_push(the->h_stack[0],(size_t)ses);
		stx_stack_push(the->h_stack[0],em_session_start);
		return STX_OK;
	}

	return stx_hash_add(the->h_hash,ses,(size_t)ses->h_plugin);
}

