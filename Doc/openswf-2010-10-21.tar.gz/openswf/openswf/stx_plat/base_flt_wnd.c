/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-10
***********************************************************************************/

#include "base_canvas.h"

#include "base_flt_wnd.h"

#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif

static char* g_szGrade = "Grade";
static char* g_szClassId = "ClassId";
static char* g_szParameters = "Parameters";
static char* g_szFltPos = "FltPos";
static char* g_szInputPins = "InputPins";
static char* g_szOutputPins = "OutputPins";

static char* g_szLastPath = "Last Path";
static char* g_szLastPathName = "Last Path Name";
static char* g_szStream = "Stream";
static char* g_szStreamPathName = "Stream Path Name";
static char* g_szLastStream = "Recent Stream";





/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
base_flt_wnd* fw_create(HWND hwnd,stx_base_graph_builder* h)
{
	base_flt_wnd* the;
	the = (base_flt_wnd*)xmallocz( sizeof(base_flt_wnd));
	if( !the ) {
		return NULL;
	}

	the->m_hWnd = hwnd;
	the->m_iMaxGraph = 10;

	the->h_gbd = h;

	return the;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void fw_close(base_flt_wnd* the)
{
	s32 i;

	//stx_log("hFilter->release = 0x%X\r\n",m_hFilter->release);

	SAFE_XDELETE(the->m_hFilter);

	if( the->m_hhInputPinWnd ) {
		for( i = 0; i < the->m_iInputPin; i ++ ) {
			if( the->m_hhInputPinWnd[i] ) {
				the->m_hhInputPinWnd[i]->close(the->m_hhInputPinWnd[i]);
			}
		}
		stx_free(the->m_hhInputPinWnd);
	}

	if( the->m_hhOutputPinWnd ) {
		for( i = 0; i < the->m_iOutputPin; i ++ ) {
			if( the->m_hhOutputPinWnd[i] ) {
				the->m_hhOutputPinWnd[i]->close(the->m_hhOutputPinWnd[i]);
			}
		}
		stx_free(the->m_hhOutputPinWnd);
	}

	if( the->m_szLastStream ) {
		for( i = 0; i < the->m_iLastStream; i ++ ) {
			if( the->m_szLastStream[i] ) {
				stx_free(the->m_szLastStream[i]);
			}
		}
		stx_free(the->m_szLastStream);
	}

	if( the->m_szLastPath ) {
		stx_free(the->m_szLastPath);
	}

	if( the->m_szStream ) {
		stx_free(the->m_szStream);
	}

	stx_free(the);

}





/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_RESULT fw_load_stream(base_flt_wnd* the,char* sz_stream)
{
	STX_RESULT			i_err;
	char*				sz_cur;
	stx_base_source*	h_source;

	if( !IS_EQUAL_GID(the->m_catid,STX_CATEGORY_FileSource) ) {
		return STX_ERR_INVALID_PARAM;
	}

	i_err = STX_FAIL;
	sz_cur = NULL;
	h_source = NULL;

	if( !sz_stream   ) {
		if( !the->m_szStream) {

			return STX_ERR_INVALID_PARAM;
		}
		sz_cur = the->m_szStream ;
	}
	else {

		if( !strcmp(sz_stream,the->m_szStream ) ) {
			return STX_OK; // need not reload;
		}

		sz_cur = sz_stream;

		if( the->m_szStream ) {
			fw_close_stream(the);
		}
	}

	do{
		stx_sync_inf sync_inf;

		i_err = the->m_hFilter->query_interf(the->m_hFilter,STX_IID_FileSource,(void**)&h_source);
		if( STX_OK != i_err ) {
			break;
		}

		// load stream;

		/* try to load stream;  */ 
		for(;;){
			INIT_MEMBER(sync_inf);
			i_err = h_source->load_stream(h_source,sz_cur,&sync_inf);
			if( STX_OK == i_err || i_err < 0 ){
				break;
			}
			if(STX_AGAIN == i_err || STX_IDLE == i_err ){
				stx_sleep(1);
				continue;
			}
			break;
		}// for(;;){
		if( STX_OK != i_err ) {
			break;
		}

		if( sz_stream ) {
			// create pinwnd;
			i_err = fw_attach_pinwnd(the);
			if( STX_OK != i_err ) {
				break;
			}

			// overwrite m_szStream;
			if( the->m_szStream ) {
				free(the->m_szStream);
			}
			the->m_szStream = stx_strdup(sz_cur);
			if( !the->m_szStream ){
				i_err = STX_FAIL;
				break;
			}

		} // if( sz_stream ) {
		else {
			// map pinwnd;
			i_err = fw_map_pinwnd(the);
			if( STX_OK != i_err ) {
				break;
			}

		} // else {

		i_err = STX_OK;

	}while(FALSE);

	SAFE_XDELETE(h_source);

	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_RESULT fw_update_stream_list(base_flt_wnd* the,char* sz_cur)
{
	s32 i;

	if( the->m_iLastStream < the->m_iMaxGraph ) {
		the->m_szLastStream[the->m_iLastStream] = stx_strdup(sz_cur);
		if( !the->m_szLastStream[the->m_iLastStream] ){
			return STX_FAIL;
		}
		the->m_iLastStream ++;
	}
	else {
		free(the->m_szLastStream[the->m_iLastStream-1]);
		for( i = 0; i < the->m_iLastStream - 1; i ++ ) {
			the->m_szLastStream[i] = the->m_szLastStream[i+1];
		}
		the->m_szLastStream[i-1] = stx_strdup(sz_cur);
		if( !the->m_szLastStream[i-1] ){
			return STX_FAIL;
		}
	}
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_RESULT fw_close_stream(base_flt_wnd* the)
{
	STX_RESULT			i_err;
	stx_base_source*	h_source;


	if( !the->m_szStream ) {
		return STX_ERR_INVALID_PARAM;
	}

	h_source = NULL;

	do{

		i_err = the->m_hFilter->query_interf(the->m_hFilter,STX_IID_FileSource,(void**)&h_source);
		if( STX_OK != i_err ){
			break;
		}
		h_source->close_stream(h_source);

		// update m_szLastStream;
		i_err = fw_update_stream_list(the,the->m_szStream);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = STX_OK;

	}while(FALSE);

	SAFE_XDELETE(h_source);

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
b32 fw_set_pos(base_flt_wnd* the,RECT rec)
{
	the->m_pos = rec;

	SetRect(&the->m_caption,
		the->m_pos.left,
		the->m_pos.top,
		the->m_pos.right,
		the->m_pos.top + CAPTION_HEIGHT);

	return fw_update_pin_pos(the);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT fw_map_pinwnd(base_flt_wnd* the)
{

	return STX_OK;
}
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT fw_attach_pinwnd(base_flt_wnd* the)
{

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT fw_initialize_pinwnd(base_flt_wnd* the)
{
	STX_RESULT			i_err;
	stx_media_type_inf	minf;

	s32					i,i_input,i_output;

	i_err = STX_FAIL;

	do{

		i_err = the->m_hFilter->enum_input_media_type(the->m_hFilter,&i_input,NULL);
		if( STX_OK != i_err ) {
			break;
		}

		the->m_iInputPin = i_input;

		if( i_input ) {
			STX_MAKE_TRACE
			the->m_hhInputPinWnd = (base_pin_wnd**)smart_mallocz( sizeof(void*)*i_input,
				STX_MAP_TRACE);
			if( !the->m_hhInputPinWnd ) {
				i_err = STX_FAIL;
				break;
			}
		}

		for( i = 0; i < i_input; i ++ ) {

			i_err = the->m_hFilter->enum_input_media_type(the->m_hFilter,&i,&minf);
			if( STX_OK != i_err ) {
				break;
			}

			the->m_hhInputPinWnd[i] = create_base_pin_wnd(0,the->m_hWnd);
			if( !the->m_hhInputPinWnd[i] ) {
				break;
			}

			base_pin_wnd_set_fltwnd(the->m_hhInputPinWnd[i],the);
			base_pin_wnd_set_pin_inf(the->m_hhInputPinWnd[i],i,&minf);

		}//for( i = 0; i < i_input; i ++ ) {
		if( STX_OK != i_err ) {
			break;
		}

		i_err = the->m_hFilter->enum_output_media_type(the->m_hFilter,&i_output,NULL);
		if( STX_OK != i_err ) {
			return i_err;
		}
		the->m_iOutputPin = i_output;

		if( i_output ) {
			STX_MAKE_TRACE
			the->m_hhOutputPinWnd = (output_pin_wnd**)smart_mallocz( sizeof(void*)*i_output,
				STX_MAP_TRACE);
			if( !the->m_hhOutputPinWnd ) {
				i_err = STX_FAIL;
				break;
			}
		}

		for( i = 0; i < i_output; i ++ ) {

			i_err = the->m_hFilter->enum_output_media_type(the->m_hFilter,&i,&minf);
			if( STX_OK != i_err ) {
				break;
			}

			the->m_hhOutputPinWnd[i] = create_output_pin_wnd(the->m_hWnd);
			if( !the->m_hhOutputPinWnd[i] ) {
				break;
			}

			base_pin_wnd_set_fltwnd((base_pin_wnd*)the->m_hhOutputPinWnd[i],the);

			base_pin_wnd_set_pin_inf((base_pin_wnd*)the->m_hhOutputPinWnd[i],i,&minf);

		}//for( i = 0; i < i_output; i ++ ) {

		if( STX_OK != i_err ) {
			break;
		}

		i_err = STX_OK;

	}while(FALSE);

	if( STX_OK == i_err ) {

		fw_update_pin_pos(the);
	}

	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

b32 fw_update_pin_pos(base_flt_wnd* the)
{
	s32		i;
	s32		h,hl,hr;
	b32		bReset;
	RECT	rc;


	bReset = FALSE;

	// left edge height;
	hl = the->m_iInputPin * ( PIN_HEIGHT + PIN_EDGE ) + PIN_EDGE;

	// right edge height;
	hr = the->m_iOutputPin * ( PIN_HEIGHT + PIN_EDGE ) + PIN_EDGE;

	// use the bigger;
	h = hl > hr ? hl : hr;

	// if have enough client rect to locate all pins;
	if( the->m_pos.bottom - the->m_caption.bottom < h ) {
		the->m_pos.bottom = the->m_caption.bottom + h;
		bReset = TRUE; // need to resize the flt-wnd;
	}

	SetRect(&rc,
		the->m_pos.left,
		the->m_caption.bottom + PIN_EDGE,
		the->m_pos.left + PIN_WIDTH,
		the->m_caption.bottom + PIN_EDGE + PIN_HEIGHT);

	for( i = 0 ; i < the->m_iInputPin; i ++ ) {
		base_pin_wnd_set_pos(the->m_hhInputPinWnd[i],rc);
		rc.top += PIN_HEIGHT + PIN_EDGE;
		rc.bottom += PIN_HEIGHT + PIN_EDGE;
	}

	SetRect(&rc,
		the->m_pos.right - PIN_WIDTH,
		the->m_caption.bottom + PIN_EDGE,
		the->m_pos.right,
		the->m_caption.bottom + PIN_EDGE + PIN_HEIGHT);

	for( i = 0 ; i < the->m_iOutputPin; i ++ ) {
		base_pin_wnd_set_pos((base_pin_wnd*)the->m_hhOutputPinWnd[i],rc);
		rc.top += PIN_HEIGHT + PIN_EDGE;
		rc.bottom += PIN_HEIGHT + PIN_EDGE;
	}

	return bReset;

 	//if( bReset ) {
 		//::PostMessage(m_hWnd,WM_RESIZE_FLTWND,(WPARAM)this,0);
		// 
 	//}
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_RESULT fw_initialize(base_flt_wnd*the,stx_xini* h_xini,STX_HANDLE h_parent)
{ 
	STX_RESULT		i_err;
	STX_HANDLE      h_grade;
	STX_HANDLE		h_clsid;
	STX_HANDLE		h_insid;
	STX_HANDLE		h_pos;
	STX_HANDLE      h_input;
	STX_HANDLE      h_subinput;
	STX_HANDLE      h_output;
	STX_HANDLE      h_suboutput;
	STX_HANDLE		h_path;
	STX_HANDLE		h_val;
	STX_HANDLE		h_stream;
	STX_HANDLE		h_substream;

	s32				i;
	char*			sz_val;

	stx_base_com*		h_com;
	stx_base_filter*	h_filter;
	RECT				rc;

	s32             i_pin;

	STX_HANDLE		h_prop;
	STX_HANDLE      h_prop_data;
	s32             i_prop_size;
	u8*				p_prop_data;

	stx_gid catgid;

	//stx_xio*        h_prop_xio;
	stx_xio_direct  prop_xio;
	ByteIOContext   pb;

	INIT_MEMBER(prop_xio);
	INIT_MEMBER(pb);


	h_com = NULL;
	sz_val = NULL;
	p_prop_data = NULL;

	// filter window initialize;

	do{

		// grade;
		i_err = h_xini->create_key(h_xini,h_parent,g_szGrade,"0",&h_grade);
		if( STX_INI_OK != i_err ) {
			break;
		}
		i_err = h_xini->read_int32(h_xini,h_grade,&the->m_iGrade);
		if( STX_INI_OK != i_err ) {
			break;
		}

		// class id;
		i_err = h_xini->create_key(h_xini,h_parent,g_szClassId,NULL,&h_clsid);
		if( STX_INI_OK != i_err ) {
			break;
		}
		i_err = h_xini->read_string(h_xini,h_clsid,&sz_val);
		if( STX_INI_OK != i_err ) {
			break;
		}
		the->m_clsid = stx_gid_from_string(sz_val);

		// instance id;
		i_err = h_xini->create_key(h_xini,h_parent,g_szInstanceId,NULL,&h_insid);
		if( STX_INI_OK != i_err ) {
			break;
		}
		i_err = h_xini->read_string(h_xini,h_insid,&sz_val);
		if( STX_INI_OK != i_err ) {
			break;
		}
		the->m_insid = stx_gid_from_string(sz_val);

		// create filters;
		h_com = NULL;
		i_err = the->h_gbd->co_create_obj(the->h_gbd,the->m_clsid,(stx_base_com**)&h_com);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = h_com->query_interf(h_com,STX_IID_BaseFilter,(void**)&h_filter);
		if( STX_OK != i_err ) {
			break;
		}
		fw_set_filter(the,h_filter);

		// replace instance gid;
		the->m_hFilter->set_insid(the->m_hFilter,the->m_insid);

		// position;
		i_err = h_xini->create_key(h_xini,h_parent,g_szFltPos,NULL,&h_pos);
		if( STX_INI_OK != i_err ) {
			break;
		}

		{
			size_t i_val[4];
			i_err = h_xini->read_array(h_xini,h_pos,4,i_val);
			if( STX_INI_OK != i_err ) {
				break;
			}
			SetRect(&rc,(s32)i_val[0],(s32)i_val[1],(s32)i_val[2],(s32)i_val[3]);
			fw_set_pos(the,rc);
		}


		// input pins;
		i_err = h_xini->create_key(h_xini,h_parent,g_szInputPins,"0",&h_input);
		if( STX_INI_OK != i_err ) {
			break;
		}
		i_err = h_xini->read_int32(h_xini,h_input,&i_pin);
		if( STX_INI_OK != i_err ) {
			break;
		}

		if(i_pin !=  the->m_iInputPin) {
			i_err = STX_FAIL;
			break;
		}

		for( i = 0; i < the->m_iInputPin; i ++ ) {

			char sz_key[2048];

			if( !the->m_hhInputPinWnd[i] ) {
				i_err = STX_FAIL;
				break;
			}

			stx_sprintf(sz_key,sizeof(sz_key),"%s-%d",g_szInputPins,i);
			i_err = h_xini->create_key(h_xini,h_input,sz_key,NULL,&h_subinput);
			if( STX_INI_OK != i_err ) {
				break;
			}

			// check type;
			i_err = the->m_hhInputPinWnd[i]->initialize(the->m_hhInputPinWnd[i],h_xini,h_subinput);
			if( STX_INI_OK != i_err ) {
				break;
			}

		} // for( i = 0; i < m_iInputPin; i ++ ) {

		if( STX_OK != i_err ) {
			break;
		}

		// output pins;
		i_err = h_xini->create_key(h_xini,h_parent,g_szOutputPins,"0",&h_output);
		if( STX_INI_OK != i_err ) {
			break;
		}
		i_err = h_xini->read_int32(h_xini,h_output,&i_pin);
		if( STX_INI_OK != i_err ) {
			break;
		}
		if( i_pin != the->m_iOutputPin ) {
			i_err = STX_FAIL;
			break;
		}

		for( i = 0; i < the->m_iOutputPin; i ++ ) {

			char sz_key[2048];

			if( !the->m_hhOutputPinWnd[i] ) {
				i_err = STX_FAIL;
				break;
			}

			stx_sprintf(sz_key,sizeof(sz_key),"%s-%d",g_szOutputPins,i);
			i_err = h_xini->create_key(h_xini,h_output,sz_key,NULL,&h_suboutput);
			if( STX_INI_OK != i_err ) {
				break;
			}

			i_err = the->m_hhOutputPinWnd[i]->initialize(the->m_hhOutputPinWnd[i],h_xini,h_suboutput);
			if( STX_INI_OK != i_err ) {
				break;
			}

		} // for( i = 0; i < m_iOutputPin; i ++ ) {


		if( STX_OK != i_err ) {
			break;
		}

		catgid = the->m_hFilter->get_catid(the->m_hFilter);

		if( IS_EQUAL_GID( catgid, STX_CATEGORY_FileSource ) ) {

			// stream;
			i_err = h_xini->create_key( h_xini, h_parent, g_szStream, NULL, &h_path );
			if( STX_INI_OK != i_err ) {
				break;
			}
			i_err = h_xini->read_string(h_xini,h_path,&sz_val);
			if( STX_INI_OK != i_err ) {
				break;
			}
			if( !strcmp(g_szTrue,sz_val)){
				i_err = h_xini->create_key( h_xini, h_path, g_szStreamPathName, NULL, &h_val );
				if( STX_INI_OK != i_err ) {
					break;
				}
				i_err = h_xini->read_string(h_xini,h_val,&sz_val);
				if( STX_INI_OK != i_err ) {
					break;
				}
				STX_MAKE_TRACE
				the->m_szStream = smart_strdup(sz_val,STX_MAP_TRACE);
				if( !the->m_szStream ) {
					break;
				}
			}// if( !strcmp(g_szTrue,sz_val)){

			// last path;
			i_err = h_xini->create_key( h_xini, h_parent, g_szLastPath,(char*)g_szFalse, &h_path );
			if( STX_INI_OK != i_err ) {
				break;
			}
			i_err = h_xini->read_string(h_xini,h_path,&sz_val);
			if( STX_INI_OK != i_err ) {
				break;
			}
			if( !strcmp(g_szTrue,sz_val)){
				i_err = h_xini->create_key( h_xini, h_path, g_szLastPathName, NULL, &h_val );
				if( STX_INI_OK != i_err ) {
					break;
				}
				i_err = h_xini->read_string(h_xini,h_val,&sz_val);
				if( STX_INI_OK != i_err ) {
					break;
				}
				STX_MAKE_TRACE
				the->m_szLastPath = smart_strdup(sz_val,STX_MAP_TRACE);
				if( !the->m_szLastPath ) {
					break;
				}
			}//if( !strcmp(g_szTrue,sz_val)){

			// last streams;
			i_err = h_xini->create_key( h_xini, h_parent, g_szLastStream, NULL, &h_stream);
			if( STX_INI_OK != i_err ) {
				break;
			}
			i_err = h_xini->get_sub_key_num(h_xini,h_stream,&the->m_iLastStream);
			if( STX_INI_OK != i_err ) {
				break;
			}

			if( the->m_iLastStream ) {

				STX_MAKE_TRACE
				the->m_szLastStream = (char**)smart_mallocz( sizeof(char*)*the->m_iLastStream,
					STX_MAP_TRACE);

				if( !the->m_szLastStream ) {
					i_err = STX_FAIL;
					break;
				}

				for( i = 0; i < the->m_iLastStream; i ++ ) {

					i_err = h_xini->get_sub_key( h_xini,h_stream,i,&h_substream );
					if( STX_INI_OK != i_err ) {
						break;
					}

					i_err = h_xini->read_string(h_xini,h_substream,&sz_val);
					if( STX_INI_OK != i_err ) {
						break;
					}

					STX_MAKE_TRACE
					the->m_szLastStream[i] = smart_strdup(sz_val,STX_MAP_TRACE);
					if( !the->m_szLastStream[i] ) {
						i_err = STX_FAIL;
						break;
					}

				} // for( i = 0; i < the->m_iLastStream; i ++ ) {

			} // if( the->m_iLastStream ) {

			if( STX_OK != i_err ) {
				break;
			}

		} // if( IS_EQUAL_GID( catgid, STX_CATEGORY_FileSource ) ) {


		// read filter property page;
		i_err = h_xini->create_key(h_xini,h_parent,(char*)g_szPropertyPage,NULL,&h_prop);
		if( STX_INI_OK != i_err ) {
			break;
		}
		i_err = h_xini->read_string(h_xini,h_prop,&sz_val);
		if( STX_INI_OK != i_err ) {
			break;
		}
		if( strcmp(g_szTrue,sz_val) ) {
			break;
		}
		i_err = h_xini->create_key(h_xini,h_prop,(char*)g_szPropertyData,NULL,&h_prop_data);
		if( STX_INI_OK != i_err ) {
			break;
		}
		i_prop_size = 0;
		i_err = h_xini->read_base64(h_xini,h_prop_data,&i_prop_size,NULL);
		if( STX_INI_OK != i_err ) {
			break;
		}

		if( i_prop_size ) {
			STX_MAKE_TRACE
			p_prop_data = (u8*)smart_mallocz(i_prop_size,STX_MAP_TRACE);
			if( !p_prop_data ) {
				i_err = STX_FAIL;
				break;
			}
			i_err = h_xini->read_base64(h_xini,h_prop_data,&i_prop_size,p_prop_data);
			if( STX_INI_OK != i_err ) {
				break;
			}
			INIT_BYTEIO_DIRECT(pb,i_prop_size,p_prop_data);
			stx_create_io_direct(&pb,&prop_xio);
#if 0
			{
				stx_xio* h_prop_xio = stx_create_io_file();
				h_prop_xio->open(h_prop_xio,"d:\\test.gph",O_CREAT);
				h_prop_xio->write(h_prop_xio,p_prop_data,i_prop_size);
				h_prop_xio->close(h_prop_xio);
			}
#endif
			i_err = the->m_hFilter->set_property(the->m_hFilter,&prop_xio.stx_xio_vt);
			if( STX_OK != i_err ){
				break;
			}
		} // if( i_prop_size ) {

		i_err = STX_OK;

	}while(FALSE);

	if( p_prop_data ) {
		stx_free(p_prop_data);
	}

	SAFE_XDELETE(h_com);

	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_RESULT fw_serialize(base_flt_wnd*the,stx_xini* h_xini,STX_HANDLE h_parent)
{
	STX_RESULT		i_err;
	STX_HANDLE      h_grade;
	STX_HANDLE		h_clsid;
	STX_HANDLE		h_insid;
	STX_HANDLE		h_pos;
	STX_HANDLE      h_input;
	STX_HANDLE      h_subinput;
	STX_HANDLE      h_output;
	STX_HANDLE      h_suboutput;
	STX_HANDLE		h_path;
	STX_HANDLE      h_val;
	STX_HANDLE		h_stream;
	STX_HANDLE		h_substream;
	s32				i;
	char*           sz_gid;
	stx_base_com*	h_com;

	stx_gid			catgid;

	STX_HANDLE		h_prop;
	STX_HANDLE      h_prop_data;
	stx_xio*        h_prop_xio;
	stx_io_op_param	inf;
	s32             i_prop_size;

	i_err = STX_FAIL;
	h_prop_xio = NULL;
	INIT_MEMBER(inf);

	h_com = NULL;
	sz_gid = NULL;

	// filter window initialize;

	do{

		// grade;
		i_err = h_xini->create_key(h_xini,h_parent,g_szGrade,"0",&h_grade);
		if( STX_INI_OK != i_err ) {
			break;
		}
		i_err = h_xini->write_int32(h_xini,h_grade,the->m_iGrade);
		if( STX_INI_OK != i_err ) {
			break;
		}

		// class id;
		i_err = h_xini->create_key(h_xini,h_parent,g_szClassId,NULL,&h_clsid);
		if( STX_INI_OK != i_err ) {
			break;
		}
		sz_gid = stx_gid_to_string(the->m_clsid);
		if( !sz_gid ) {
			i_err = STX_FAIL;
			break;
		}
		i_err = h_xini->write_string(h_xini,h_clsid,sz_gid);
		if( STX_INI_OK != i_err ) {
			break;
		}
		stx_gid_close_string(&sz_gid);

		// instance id;
		i_err = h_xini->create_key(h_xini,h_parent,g_szInstanceId,NULL,&h_insid);
		if( STX_INI_OK != i_err ) {
			break;
		}
		sz_gid = stx_gid_to_string(the->m_insid);
		if( !sz_gid ) {
			i_err = STX_FAIL;
			break;
		}
		i_err = h_xini->write_string(h_xini,h_insid,sz_gid);
		if( STX_INI_OK != i_err ) {
			break;
		}
		stx_gid_close_string(&sz_gid);

		// position;
		i_err = h_xini->create_key(h_xini,h_parent,g_szFltPos,NULL,&h_pos);
		if( STX_INI_OK != i_err ) {
			break;
		}

		{
			size_t i_val[4] = { the->m_pos.left,the->m_pos.top,the->m_pos.right,the->m_pos.bottom};
			i_err = h_xini->write_array(h_xini,h_pos,4,i_val);
			if( STX_INI_OK != i_err ) {
				break;
			}
		}

		// input pins;
		i_err = h_xini->create_key(h_xini,h_parent,g_szInputPins,"0",&h_input);
		if( STX_INI_OK != i_err ) {
			break;
		}
		i_err = h_xini->write_int32(h_xini,h_input,the->m_iInputPin);
		if( STX_INI_OK != i_err ) {
			break;
		}

		for( i = 0; i < the->m_iInputPin; i ++ ) {

			if( the->m_hhInputPinWnd[i] ) {

				char sz_key[2048];
				stx_sprintf(sz_key,sizeof(sz_key),"%s-%d",g_szInputPins,i);
				i_err = h_xini->create_key(h_xini,h_input,sz_key,NULL,&h_subinput);
				if( STX_INI_OK != i_err ) {
					break;
				}

				i_err = the->m_hhInputPinWnd[i]->serialize(the->m_hhInputPinWnd[i],h_xini,h_subinput);
				if( STX_INI_OK != i_err ) {
					break;
				}

			} // if( the->m_hhInputPinWnd[i] ) {

		} // for( i = 0; i < the->m_iInputPin; i ++ ) {

		if( STX_OK != i_err ) {
			break;
		}

		// output pins;
		i_err = h_xini->create_key(h_xini,h_parent,g_szOutputPins,"0",&h_output);
		if( STX_INI_OK != i_err ) {
			break;
		}
		i_err = h_xini->write_int32(h_xini,h_output,the->m_iOutputPin);
		if( STX_INI_OK != i_err ) {
			break;
		}

		for( i = 0; i < the->m_iOutputPin; i ++ ) {

			if( the->m_hhOutputPinWnd[i] ) {

				char sz_key[2048];
				stx_sprintf(sz_key,sizeof(sz_key),"%s-%d",g_szOutputPins,i);
				i_err = h_xini->create_key(h_xini,h_output,sz_key,NULL,&h_suboutput);
				if( STX_INI_OK != i_err ) {
					break;
				}

				i_err = the->m_hhOutputPinWnd[i]->serialize(the->m_hhOutputPinWnd[i],h_xini,h_suboutput);
				if( STX_INI_OK != i_err ) {
					break;
				}

			} // if( the->m_hhOutputPinWnd[i] ) {

		} // for( i = 0; i < the->m_iOutputPin; i ++ ) {

		if( STX_OK != i_err ) {
			break;
		}

		catgid = the->m_hFilter->get_catid(the->m_hFilter);

		if( IS_EQUAL_GID( catgid, STX_CATEGORY_FileSource ) ) {

			// stream;
			i_err = h_xini->create_key( h_xini, h_parent, g_szStream, (char*)g_szFalse, &h_path );
			if( STX_INI_OK != i_err ) {
				break;
			}
			if( the->m_szStream ) {
				i_err = h_xini->write_string(h_xini,h_path,(char*)g_szTrue);
				if( STX_INI_OK != i_err ) {
					break;
				}
				i_err = h_xini->create_key( h_xini, h_path, g_szStreamPathName, the->m_szStream, &h_val );
				if( STX_INI_OK != i_err ) {
					break;
				}
			} // if( m_szStream ) {

			// last path;
			i_err = h_xini->create_key( h_xini, h_parent, g_szLastPath, (char*)g_szFalse, &h_path );
			if( STX_INI_OK != i_err ) {
				break;
			}
			if( the->m_szLastPath ) {
				i_err = h_xini->write_string(h_xini,h_path,(char*)g_szTrue);
				if( STX_INI_OK != i_err ) {
					break;
				}
				i_err = h_xini->create_key( h_xini, h_path, g_szLastPathName, the->m_szLastPath, &h_val );
				if( STX_INI_OK != i_err ) {
					break;
				}
			} // if( m_szLastPath ) {

			// last streams;
			i_err = h_xini->create_key( h_xini, h_parent, g_szLastStream, "0", &h_stream);
			if( STX_INI_OK != i_err ) {
				break;
			}

			i_err = h_xini->write_int32(h_xini,h_stream,the->m_iLastStream);
			if( STX_INI_OK != i_err ) {
				break;
			}

			for( i = 0; i < the->m_iLastStream; i ++ ) {

				if( the->m_szLastStream[i] ) {

					char sz_key[2048];
					stx_sprintf(sz_key,sizeof(sz_key),"%s-%d",g_szLastStream,i);

					i_err = h_xini->create_key( h_xini,h_stream,sz_key,NULL,&h_substream );
					if( STX_INI_OK != i_err ) {
						break;
					}

					i_err = h_xini->write_string(h_xini,h_substream,the->m_szLastStream[i]);
					if( STX_INI_OK != i_err ) {
						break;
					}

				} // if( the->m_szLastStream[i] ) {

			} // for( i = 0; i < the->m_iLastStream; i ++ ) {

			if( STX_OK != i_err ) {
				break;
			}

		} // if( IS_EQUAL_GID( catgid, STX_CATEGORY_FileSource ) ) {

		// save filter property page;
		// binary length will be updated when write in binary data;
		i_err = h_xini->create_key(h_xini,h_parent,(char*)g_szPropertyPage,(char*)g_szFalse,&h_prop);
		if( STX_INI_OK != i_err ) {
			break;
		}

		h_prop_xio = XCREATE(stx_io_stream,NULL);
		if( !h_prop_xio ) {
			i_err = STX_FAIL;
			break;
		}

		i_err = the->m_hFilter->get_property(the->m_hFilter,h_prop_xio);
		if( STX_OK != i_err ) {
			i_err = STX_OK;
			break;
		}

		i_err = h_prop_xio->get(h_prop_xio,STX_IO_READ_P,&inf);
		if( STX_OK != i_err ) {
			break;
		}
		i_prop_size = (s32)h_prop_xio->size(h_prop_xio);

		i_err = h_xini->write_string(h_xini,h_prop,(char*)g_szTrue);
		if( STX_INI_OK != i_err ) {
			break;
		}

		i_err = h_xini->create_key(h_xini,h_prop,(char*)g_szPropertyData,"0",&h_prop_data);
		if( STX_INI_OK != i_err ) {
			break;
		}

		i_err = h_xini->write_base64(h_xini,h_prop_data,i_prop_size,(u8*)inf.buf);
		if( STX_INI_OK != i_err ) {
			break;
		}

		i_err = STX_OK;

	}while(FALSE);

	if( sz_gid ) {
		stx_gid_close_string(&sz_gid);
	}

	if( h_prop_xio ) {
		h_prop_xio->close(h_prop_xio);
	}

	return i_err;

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void  fw_set_filter(base_flt_wnd* the,stx_base_filter* hFilter)
{
	// 		stx_log("hFilter->release = 0x%X\r\n",hFilter->release);

	the->m_clsid = hFilter->get_clsid(hFilter);
	the->m_catid = hFilter->get_catid(hFilter);
	the->m_insid = hFilter->get_insid(hFilter);
	the->m_hFilter = hFilter;

	the->m_iTitleClip = 0;
	the->m_iTitleWidth = 0;

	fw_initialize_pinwnd(the);
}





/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

b32 fw_move(base_flt_wnd*the,s32 x,s32 y,RECT clip)
{
	s32 w,h,d;

	w = the->m_pos.right - the->m_pos.left;
	h = the->m_pos.bottom - the->m_pos.top;
	the->m_pos.left += x;
	the->m_pos.top += y;

	the->m_pos.left = the->m_pos.left < clip.left ? clip.left: the->m_pos.left;
	the->m_pos.top = the->m_pos.top < clip.top ? clip.top:the->m_pos.top;
	the->m_pos.left = the->m_pos.left > clip.right ? clip.right: the->m_pos.left;
	the->m_pos.top = the->m_pos.top > clip.bottom ? clip.bottom: the->m_pos.top;

	the->m_pos.right = the->m_pos.left + w;
	the->m_pos.bottom = the->m_pos.top + h;

	if( the->m_pos.right > clip.right ) {
		d = the->m_pos.right - clip.right;
		the->m_pos.left -= d;
		the->m_pos.right -= d;
	}

	if( the->m_pos.bottom > clip.bottom ) {
		d = the->m_pos.bottom - clip.bottom;
		the->m_pos.top -=d;
		the->m_pos.bottom -= d;
	}

	SetRect(&the->m_caption,
		the->m_pos.left,
		the->m_pos.top,
		the->m_pos.right,
		the->m_pos.top + CAPTION_HEIGHT);

	return fw_update_pin_pos(the);

}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_RESULT fw_check_connection_point(base_flt_wnd*the,stx_connection_point* p)
{
	s32			i_pin;
	stx_gid     insid;

	stx_media_type_inf minf;

	if( !p->b_start ) {

		if( p->i_pin < 0 || p->i_pin >= the->m_iInputPin ) {
			return STX_FAIL;
		}

		base_pin_wnd_get_pin_inf(the->m_hhInputPinWnd[p->i_pin],&i_pin,&minf);

		if( i_pin != p->i_pin ){
			return STX_FAIL;
		}
		if(!is_compatible_gid(minf.major_type,p->major_type)) {
			return STX_FAIL;
		}
		if(!is_compatible_gid(minf.sub_type,p->sub_type)) {
			return STX_FAIL;
		}
		insid = base_pin_wnd_GetInsId(the->m_hhInputPinWnd[p->i_pin]);
		if(!IS_EQUAL_GID(insid,p->insid)) {
			return STX_FAIL;
		}

		p->pwnd = the->m_hhInputPinWnd[p->i_pin];

		return STX_OK;

	}// if( p->b_start ) {

	if( p->i_pin < 0 || p->i_pin >= the->m_iOutputPin ) {
		return STX_FAIL;
	}

	base_pin_wnd_get_pin_inf((base_pin_wnd*)the->m_hhOutputPinWnd[p->i_pin],&i_pin,&minf);

	if( i_pin != p->i_pin ){
		return STX_FAIL;
	}
	if(!is_compatible_gid(minf.major_type,p->major_type)) {
		return STX_FAIL;
	}
	if(!is_compatible_gid(minf.sub_type,p->sub_type)) {
		return STX_FAIL;
	}
	insid = base_pin_wnd_GetInsId((base_pin_wnd*)the->m_hhOutputPinWnd[p->i_pin]);
	if(!IS_EQUAL_GID(insid,p->insid)) {
		return STX_FAIL;
	}

	p->pwnd = (base_pin_wnd*)the->m_hhOutputPinWnd[p->i_pin];

	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

b32 fw_PtInPin(base_flt_wnd* the,POINT pt, base_pin_wnd** pin)
{

	return FALSE;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT fw_enum_input_pinwnd
(base_flt_wnd*the,s32* i_idx, base_pin_wnd** pp_pinwnd)
{
	if( !i_idx ) {
		return STX_ERR_INVALID_PARAM;
	}

	if( !pp_pinwnd ) {
		*i_idx = the->m_iInputPin;
		return STX_OK;
	}

	{
		s32 idx = *i_idx;

		if( idx < 0 || idx >= the->m_iInputPin ) {
			return STX_ERR_INVALID_PARAM;
		}

		*pp_pinwnd = the->m_hhInputPinWnd[idx];

		return STX_OK;
	}
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT fw_enum_output_pinwnd
(base_flt_wnd*the,s32* i_idx,output_pin_wnd** pp_pinwnd)
{
	if( !i_idx ) {
		return STX_ERR_INVALID_PARAM;
	}

	if( !pp_pinwnd ) {
		*i_idx = the->m_iOutputPin;
		return STX_OK;
	}

	{
		s32 idx = *i_idx;

		if( idx < 0 || idx >= the->m_iOutputPin ) {
			return STX_ERR_INVALID_PARAM;
		}

		*pp_pinwnd = the->m_hhOutputPinWnd[idx];

		return STX_OK;
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
base_pin_wnd* fw_find_inputpin(base_flt_wnd*the,stx_gid insid)
{
	s32 i;

	for( i = 0; i < the->m_iInputPin; i ++ ) {
		stx_gid pinwnd_insid = base_pin_wnd_GetInsId(the->m_hhInputPinWnd[i]);
		if( IS_EQUAL_GID(pinwnd_insid,insid) ) {
			return the->m_hhInputPinWnd[i];
		}
	}

	return NULL;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
output_pin_wnd* fw_find_outputpin(base_flt_wnd*the,stx_gid insid)
{
	s32 i;

	for( i = 0; i < the->m_iOutputPin; i ++ ) {
		stx_gid pinwnd_insid = base_pin_wnd_GetInsId((base_pin_wnd*)the->m_hhOutputPinWnd[i]);
		if( IS_EQUAL_GID(pinwnd_insid,insid) ) {
			return the->m_hhOutputPinWnd[i];
		}
	}

	return NULL;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void fw_ReleasePinWndPin(base_flt_wnd* the)
{
	s32 i;

	for( i = 0; i < the->m_iInputPin; i ++ ) {
		the->m_hhInputPinWnd[i]->ReleasePin(the->m_hhInputPinWnd[i]);
	}

	for( i = 0; i < the->m_iOutputPin; i ++ ) {
		the->m_hhOutputPinWnd[i]->ReleasePin(the->m_hhOutputPinWnd[i]);
	}
}
