/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/
#include "stdio.h"
#include "stdlib.h"
#include "fcntl.h"
#include "malloc.h"
#include "memory.h"
#include "string.h"
#include "math.h"

#include "stx_os.h"
#include "stx_mem.h"
#include "stx_debug.h"
#include "stx_stat.h"

#include "cubic_resizer.h"
#include "stx_cpuid.h"
#include "stx_rgb_convert.h"
#include "blend_api.h"

#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif

//#define UNROLL_SCALE

typedef struct CubicTable
{
	short*			lpCkAlign;            // change to short* ???
	s32*			lpIndex;
	s32             nDstNormalPixels;     // 4 or 8 per loop
	s32             nDstEndPixels;        // right edge;
}CubicTable;


typedef struct ScaleTable{
	s32					i_accuracy;  // << 14;
	s32					i_scale;     // nScale<<i_accrracy
	b32*				b_cmpflag;
	s32*				nWeightX;
	s32*				naAccu;
}ScaleTable;



typedef struct BitmapResizer BitmapResizer;


struct BitmapResizer
{
	CubicTable			m_XTable[2];
	CubicTable			m_YTable[2];

	ScaleTable			m_ScaleTable[2][2];
	b32					b_xscale;
	b32					b_yscale;

	s64					i_time_acc;
	s64					i_times;

	u32                 m_dwAlg;
	s32                 m_iSampleNum[2];
	s32                 m_iStartPos[2];
	size_t              m_iTableSize[2];

	s32					m_dwCurSrcWidth  ;
	s32					m_dwCurSrcPitch[2];
	s32					m_dwCurSrcHeight ;
	s32					m_dwCurDstWidth  ;
	s32					m_dwCurDstPitch[2];
	s32					m_dwCurDstHeight ;

	s32					m_dwCurPitch;
	s32					m_dwCurPitchUV;
	void*				m_lpTemBuffer0;
	u8*					m_lpTemBufferAlign;

	void*				m_lpDeinterlaceBuf0;
	u8*					m_lpDeinterlaceBuf;

	u8*					m_pSrcRowBufPtr;
	u8*					m_pSrcRowBuf;
	u8*					m_pDstRowBuf;
	s32					m_dwSrcRowBufPit;
	s32					m_dwDstRowBufPit;

	void (*get_xtable)(s32 nSrc,s32 nDst,CubicTable* lpTable);
	void (*get_ytable)(s32 nSrc,s32 nDst,CubicTable* lpTable);

	void (*ResizeRowCh1)
		( 
		BitmapResizer*	pCtx,
		u8*				lpSrc,
		u8*				lpDst,
		CubicTable*		lptable
		);

	void (*ResizeRowCh4)
		( 
		BitmapResizer*	pCtx,
		u8*				lpSrc,
		u8*				lpDst,
		CubicTable*		lptable
		);

	void (*ResizeCol)
		( 
		BitmapResizer*	pCtx,
		s32             width,
		u8*				lpSrc[],
		u8*				lpDst,
		s16*			lpcoe
		);

	s32 (*ScaleRowCh1)
		( 
		BitmapResizer*	pCtx,
		s32				i_rear,
		u8*				lpSrc,
		s32				i_src_width,
		s32				i_src_pit,
		s32				i_src_height,
		u8*				lpDst,
		s32				i_dst_width,
		s32				i_dst_pit,
		ScaleTable*		lpScale
		);

	s32 (*ScaleRowCh3)
		( 
		BitmapResizer*	pCtx,
		s32				i_rear,
		u8*				lpSrc,
		s32				i_src_width,
		s32				i_src_pit,
		s32				i_src_height,
		u8*				lpDst,
		s32				i_dst_width,
		s32				i_dst_pit,
		ScaleTable*		lpScale
		);

	s32 (*ScaleRowCh4)
		( 
		BitmapResizer*	pCtx,
		s32				i_rear,
		u8*				lpSrc,
		s32				i_src_width,
		s32				i_src_pit,
		s32				i_src_height,
		u8*				lpDst,
		s32				i_dst_width,
		s32				i_dst_pit,
		ScaleTable*		lpScale
		);

	s32 (*ScaleCol)
		( 
		BitmapResizer*	pCtx,
		s32				i_rear,
		u8*				lpSrc,
		s32				i_src_height,
		s32				i_src_pit,
		u8*				lpDst,
		s32				i_dst_height,
		s32				i_dst_pit,
		s32				i_dst_width,
		ScaleTable*		lpScale
		);

	s32 (*Resize)
		(	
		BitmapResizer		*pCtx,
		CUBIC_RESIZE_PARAM	*lpara 
		);
};


static void (*CubicResizeRowCh1)
( 
	BitmapResizer*	pCtx,
	u8*				lpSrc,
	u8*				lpDst,
	CubicTable*		lptable
);


static void CubicResizeRowCh1_C
( 
	BitmapResizer*	pCtx,
	u8*				lpSrc,
	u8*				lpDst,
	CubicTable*		lptable
);

static void CubicResizeRowCh1_SSE2
( 
	BitmapResizer*	pCtx,
	u8*				lpSrc,
	u8*				lpDst,
	CubicTable*		lptable
);

static void CubicResizeRowCh1_SSSE3
( 
	BitmapResizer*	pCtx,
	u8*				lpSrc,
	u8*				lpDst,
	CubicTable*		lptable
);


static void (*CubicResizeRowCh4)
( 
	BitmapResizer*	pCtx,
	u8*				lpSrc,
	u8*				lpDst,
	CubicTable*		lptable
);


static void CubicResizeRowCh4_C
( 
	BitmapResizer*	pCtx,
	u8*				lpSrc,
	u8*				lpDst,
	CubicTable*		lptable
);

static void CubicResizeRowCh4_SSE2
( 
	BitmapResizer*	pCtx,
	u8*				lpSrc,
	u8*				lpDst,
	CubicTable*		lptable
);

static void CubicResizeRowCh4_SSSE3
( 
	BitmapResizer*	pCtx,
	u8*				lpSrc,
	u8*				lpDst,
	CubicTable*		lptable
);


static void (*CubicResizeColom)
(   
	BitmapResizer*	pCtx,
	s32				width,
	u8*				lpSrc[],
	u8*				lpDst,
	void			*lpTable
);


static void CubicResizeColom_C
(   
	BitmapResizer*	pCtx,
	s32				width,
	u8*				lpSrc[],
	u8*				lpDst,
	s16*			lpcoe
);

static void CubicResizeColom_SSE2
(   
	BitmapResizer*  pCtx,
	s32             width,
	u8*				lpSrc[],
	u8*				lpDst,
	s16*			lpcoe
);

static void CubicResizeColom_SSSE3
(   
	BitmapResizer*	pCtx,
	s32				width,
	u8*				lpSrc[],
	u8*				lpDst,
	s16*			lpcoe
);


//lan3 /////////////////////////////////////////////////////////////////
static void (*Lan3ResizeRowCh1)
( 
	BitmapResizer*	pCtx,
	u8*				lpSrc,
	u8*				lpDst,
	CubicTable*		lptable
);


static void Lan3ResizeRowCh1_C
( 
	BitmapResizer*	pCtx,
	u8*				lpSrc,
	u8*				lpDst,
	CubicTable*		lptable
);

// static void Lan3ResizeRowCh1_SSE2
//( 
// 								   BitmapResizer* pCtx,
// 								   u8* lpSrc,
// 								   u8* lpDst,
// 								   CubicTable*    lptable
//);

// 
// static void Lan3ResizeRowCh1_SSSE3
//( 
// 									BitmapResizer*	pCtx,
// 									u8*				lpSrc,
// 									u8*				lpDst,
// 									CubicTable*		lptable
//);



static void (*Lan3ResizeRowCh4)
( 
	BitmapResizer*	pCtx,
	u8*				lpSrc,
	u8*				lpDst,
	CubicTable*		lptable
);


static void Lan3ResizeRowCh4_C
( 
	BitmapResizer*	pCtx,
	u8*				lpSrc,
	u8*				lpDst,
	CubicTable*		lptable
);

// static void Lan3ResizeRowCh4_SSE2
//( 
// 								   BitmapResizer* pCtx,
// 								   u8* lpSrc,
// 								   u8* lpDst,
// 								   CubicTable*    lptable
//);
// 
// static void Lan3ResizeRowCh4_SSSE3
//( 
// 									BitmapResizer*	pCtx,
// 									u8*				lpSrc,
// 									u8*				lpDst,
// 									CubicTable*		lptable
//);


static void (*Lan3ResizeColom)
(   
	BitmapResizer*	pCtx,
	s32				width,
	u8*				lpSrc[],
	u8*				lpDst,
	s16*			lpcoe
);


static void Lan3ResizeColom_C
(   
	BitmapResizer*	pCtx,
	s32				width,
	u8*				lpSrc[],
	u8*				lpDst,
	s16*			lpcoe
);

// static void Lan3ResizeColom_SSE2
//(   
//BitmapResizer*	pCtx,
//s32				width,
//u8*				lpSrc[],
//u8*				lpDst,
//s16*				lpcoe
//);
// 
// static void Lan3ResizeColom_SSSE3
//(   
//BitmapResizer*	pCtx,
//s32				width,
//u8*				lpSrc[],
//u8*				lpDst,
//s16*				lpcoe
//);
// 



//Lan8 /////////////////////////////////////////////////////////////////
static void (*Lan8ResizeRowCh1)
( 
	BitmapResizer*	pCtx,
	u8*				lpSrc,
	u8*				lpDst,
	CubicTable*		lptable
);


static void Lan8ResizeRowCh1_C
( 
	BitmapResizer*	pCtx,
	u8*				lpSrc,
	u8*				lpDst,
	CubicTable*		lptable
);

// static void Lan8ResizeRowCh1_SSE2
//( 
//BitmapResizer*	pCtx,
//u8*				lpSrc,
//u8*				lpDst,
//CubicTable*		lptable
//);
// 
// static void Lan8ResizeRowCh1_SSSE3
//( 
//BitmapResizer*	pCtx,
//u8*				lpSrc,
//u8*				lpDst,
//CubicTable*		lptable
//);


static void (*Lan8ResizeRowCh4)
( 
	BitmapResizer*	pCtx,
	u8*				lpSrc,
	u8*				lpDst,
	CubicTable*		lptable
);


static void Lan8ResizeRowCh4_C
( 
	BitmapResizer*	pCtx,
	u8*				lpSrc,
	u8*				lpDst,
	CubicTable*		lptable
);

// static void Lan8ResizeRowCh4_SSE2
//( 
// BitmapResizer*	pCtx,
// u8*				lpSrc,
// u8*				lpDst,
// CubicTable*		lptable
//);
// 
// static void Lan8ResizeRowCh4_SSSE3
//( 
// BitmapResizer*	pCtx,
// u8*				lpSrc,
// u8*				lpDst,
// CubicTable*		lptable
//);


static void (*Lan8ResizeColom)
(   
	BitmapResizer*	pCtx,
	s32				width,
	u8*				lpSrc[],
	u8*				lpDst,
	s16*			lpcoe
);


static void Lan8ResizeColom_C
(   
	BitmapResizer*	pCtx,
	s32				width,
	u8*				lpSrc[],
	u8*				lpDst,
	s16*			lpcoe
);

// static void Lan8ResizeColom_SSE2
//(   
// BitmapResizer*	pCtx,
// s32				width,
// u8*				lpSrc[],
// u8*				lpDst,
// s16*				lpcoe
//);
// 
// static void Lan8ResizeColom_SSSE3
//(   
// BitmapResizer*	pCtx,
// s32				width,
// u8*				lpSrc[],
// u8*				lpDst,
// s16*				lpcoe
//);
// 

static void ResizeRowCh3
( 
	BitmapResizer		*pCtx,
	CUBIC_RESIZE_PARAM	*lpara,
	u8*					lpSrc,
	u8*					lpDst,
	CubicTable*			lptable
);

static s32 (*ScaleRowCh3)
( 
	BitmapResizer*	pCtx,
	s32				i_rear,
	u8*				lpSrc,
	s32				i_src_width,
	s32				i_src_pit,
	s32				i_src_height,
	u8*				lpDst,
	s32				i_dst_width,
	s32				i_dst_pit,
	ScaleTable*		lpScale
);

static s32 ScaleRowCh3_C
( 
	BitmapResizer*	pCtx,
	s32				i_rear,
	u8*				lpSrc,
	s32				i_src_width,
	s32				i_src_pit,
	s32				i_src_height,
	u8*				lpDst,
	s32				i_dst_width,
	s32				i_dst_pit,
	ScaleTable*		lpScale
);

static s32 ScaleRowCh3_SSE2
( 
	BitmapResizer*	pCtx,
	s32				i_rear,
	u8*				lpSrc,
	s32				i_src_width,
	s32				i_src_pit,
	s32				i_src_height,
	u8*				lpDst,
	s32				i_dst_width,
	s32				i_dst_pit,
	ScaleTable*		lpScale
);

static s32 (*ScaleRowCh4)
( 
	 BitmapResizer*		pCtx,
	 s32				i_rear,
	 u8*				lpSrc,
	 s32				i_src_width,
	 s32				i_src_pit,
	 s32				i_src_height,
	 u8*				lpDst,
	 s32				i_dst_width,
	 s32				i_dst_pit,
	 ScaleTable*		lpScale
);

static s32 ScaleRowCh4_C
( 
	 BitmapResizer*		pCtx,
	 s32				i_rear,
	 u8*				lpSrc,
	 s32				i_src_width,
	 s32				i_src_pit,
	 s32				i_src_height,
	 u8*				lpDst,
	 s32				i_dst_width,
	 s32				i_dst_pit,
	 ScaleTable*		lpScale
);

static s32 ScaleRowCh4_SSE2
( 
	BitmapResizer*	pCtx,
	s32				i_rear,
	u8*				lpSrc,
	s32				i_src_width,
	s32				i_src_pit,
	s32				i_src_height,
	u8*				lpDst,
	s32				i_dst_width,
	s32				i_dst_pit,
	ScaleTable*		lpScale
);

static s32 (*ScaleRowCh1)
( 
	 BitmapResizer*		pCtx,
	 s32				i_rear,
	 u8*				lpSrc,
	 s32				i_src_width,
	 s32				i_src_pit,
	 s32				i_src_height,
	 u8*				lpDst,
	 s32				i_dst_width,
	 s32				i_dst_pit,
	 ScaleTable*		lpScale
);

static s32 ScaleRowCh1_C
( 
	 BitmapResizer*		pCtx,
	 s32				i_rear,
	 u8*				lpSrc,
	 s32				i_src_width,
	 s32				i_src_pit,
	 s32				i_src_height,
	 u8*				lpDst,
	 s32				i_dst_width,
	 s32				i_dst_pit,
	 ScaleTable*		lpScale
);

static s32 ScaleRowCh1_SSE2
( 
	BitmapResizer*	pCtx,
	s32				i_rear,
	u8*				lpSrc,
	s32				i_src_width,
	s32				i_src_pit,
	s32				i_src_height,
	u8*				lpDst,
	s32				i_dst_width,
	s32				i_dst_pit,
	ScaleTable*		lpScale
);

static s32 (*ScaleColom)
(   
	BitmapResizer*	pCtx,
	s32				i_rear,
	u8*				lpSrc,
	s32				i_src_height,
	s32				i_src_pit,
	u8*				lpDst,
	s32				i_dst_height,
	s32				i_dst_pit,
	s32				i_dst_width,
	ScaleTable*		lpScale
);

static s32 ScaleColom_C
(   
	BitmapResizer*	pCtx,
	s32				i_rear,
	u8*				lpSrc,
	s32				i_src_height,
	s32				i_src_pit,
	u8*				lpDst,
	s32				i_dst_height,
	s32				i_dst_pit,
	s32				i_dst_width,
	ScaleTable*		lpScale
);

static s32 ScaleColom_SSE2
(   
	BitmapResizer*	pCtx,
	s32				i_rear,
	u8*				lpSrc,
	s32				i_src_height,
	s32				i_src_pit,
	u8*				lpDst,
	s32				i_dst_height,
	s32				i_dst_pit,
	s32				i_dst_width,
	ScaleTable*		lpScale
);

static void (*rgb_24to32)(u8* lpSrc,u8* lpDst,s32 nWidth);
static void (*rgb_32to24)(u8* lpSrc,u8* lpDst,s32 nWidth);

static __m128i round;

static s32  g_dwByte2Int32[256];
static u8*  g_pByAbs;
static u8*  clip_ptr;
static u8   g_byAbsVal[512];
static u8   clip[768];


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static void InitByte2Int32()
{
	s32 i;
	g_pByAbs = g_byAbsVal + 256;

	for( i = 0; i < 256; i ++ ) {
		g_dwByte2Int32[i] = i * 0x01010101;
		g_pByAbs[i] = g_pByAbs[-i] = i;
	}

	for(i=-256; i<512; i++){
		clip[i+256]=(i<0)?0:(i>255)?255:i;
	}	
	clip_ptr = clip + 256; 
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

static void InitBitmapResize(u32 dwOpt)
{

	InitByte2Int32();

	rgb_24to32  = RGB24_TO_RGB32_LINE_C;
	rgb_32to24  = RGB32_TO_RGB24_LINE_C;

    CubicResizeRowCh4 = CubicResizeRowCh4_C;
    CubicResizeRowCh1   = CubicResizeRowCh1_C;
	CubicResizeColom = CubicResizeColom_C;

	Lan3ResizeRowCh4 = Lan3ResizeRowCh4_C;
	Lan3ResizeRowCh1   = Lan3ResizeRowCh1_C;
	Lan3ResizeColom = Lan3ResizeColom_C;

	Lan8ResizeRowCh4 = Lan8ResizeRowCh4_C;
	Lan8ResizeRowCh1   = Lan8ResizeRowCh1_C;
	Lan8ResizeColom = Lan8ResizeColom_C;

	ScaleColom = ScaleColom_C;
	ScaleRowCh1 = ScaleRowCh1_C;
	ScaleRowCh3 = ScaleRowCh3_C;
	ScaleRowCh4 = ScaleRowCh4_C;

	//return;

	if( dwOpt & MM_SSE2 ) {

		round = _mm_set_epi32(2048,2048,2048,2048);

		//rgb_24to32  = RGB24_TO_RGB32_LINE_SSE2; //not fast;
		//rgb_32to24  = RGB32_TO_RGB24_LINE_SSE2; //not fast;

		CubicResizeRowCh4 = CubicResizeRowCh4_SSE2;
		CubicResizeRowCh1 = CubicResizeRowCh1_SSE2;
		CubicResizeColom  = CubicResizeColom_SSE2;

// 		Lan3ResizeRowCh4 = Lan3ResizeRowCh4_SSE2;
// 		Lan3ResizeRowCh1   = Lan3ResizeRowCh1_SSE2;
// 		Lan3ResizeColom = Lan3ResizeColom_SSE2;
// 
// 		Lan8ResizeRowCh4 = Lan8ResizeRowCh4_SSE2;
// 		Lan8ResizeRowCh1   = Lan8ResizeRowCh1_SSE2;
// 		Lan8ResizeColom = Lan8ResizeColom_SSE2;

		ScaleColom = ScaleColom_SSE2;
		ScaleRowCh1 = ScaleRowCh1_SSE2;
		ScaleRowCh3 = ScaleRowCh3_SSE2;
		ScaleRowCh4 = ScaleRowCh4_SSE2;

	}

	if( dwOpt & MM_SSSE3 ) {

		rgb_24to32  = RGB24_TO_RGB32_LINE_SSSE3;
		rgb_32to24  = RGB32_TO_RGB24_LINE_SSSE3;

		CubicResizeRowCh4 = CubicResizeRowCh4_SSSE3;
		CubicResizeRowCh1   = CubicResizeRowCh1_SSSE3;
		CubicResizeColom = CubicResizeColom_SSSE3;

// 		Lan3ResizeRowCh4 = Lan3ResizeRowCh4_SSSE3;
// 		Lan3ResizeRowCh1   = Lan3ResizeRowCh1_SSSE3;
// 		Lan3ResizeColom = Lan3ResizeColom_SSSE3;
// 
// 		Lan8ResizeRowCh4 = Lan8ResizeRowCh4_SSSE3;
// 		Lan8ResizeRowCh1   = Lan8ResizeRowCh1_SSSE3;
// 		Lan8ResizeColom = Lan8ResizeColom_SSSE3;
	}

}


static void InitializeResizer(BitmapResizer* pCtx );
static void ReleaseResizer(BitmapResizer* pCtx);

static s32 CheckSizeCh1(	
	BitmapResizer* pCtx,
	CUBIC_RESIZE_PARAM *lpTpa);

static s32 CheckSizeCh3Ch4(	
	BitmapResizer* pCtx,
	CUBIC_RESIZE_PARAM *lpTpa);

static s32 AllocTempMemoryDst(	
	s32 nDst,CubicTable (*XT)[2],s32 i_size);

static void ReleaseTempMemoryDst(
	CubicTable (*XT)[2]);

static 	double GetCk(double dt);
static 	void GetTable(s32 nSrc,s32 nDst,CubicTable* lpTable);

static 	void GetTableLan3(s32 nSrc,s32 nDst,CubicTable* lpTable);
static 	void GetTableLan8(s32 nSrc,s32 nDst,CubicTable* lpTable);

static s32 ResizeYV12(	
	BitmapResizer* pCtx,
	CUBIC_RESIZE_PARAM *lpara );

static s32 ResizeYV12_Width(	
	BitmapResizer* pCtx,
	CUBIC_RESIZE_PARAM *lpara );

static s32 ResizeYV12_Height(	
	BitmapResizer* pCtx,
	CUBIC_RESIZE_PARAM *lpara);

static s32 ResizeRGB24(	
	BitmapResizer* pCtx,
	CUBIC_RESIZE_PARAM *lpara);

static s32 ResizeRGB32(	
	BitmapResizer* pCtx,
	CUBIC_RESIZE_PARAM *lpara);


/***********************************************************************
STX_HANDLE  open_bicubic_resize()
***********************************************************************/
STX_HANDLE  open_bicubic_resize()
{
	DECL_TRACE
	BitmapResizer* pCtx;
	MAKE_TRACE2;
	pCtx = (BitmapResizer*)smart_mallocz(sizeof(BitmapResizer),MAP_TRACE);
	if( !pCtx ) {
		return NULL;
	}

	InitBitmapResize( mm_support() );

	return (STX_HANDLE)pCtx;
}

/***********************************************************************
void close_bicubic_resize(STX_HANDLE h)
***********************************************************************/
void close_bicubic_resize(STX_HANDLE h)
{
	BitmapResizer* p = (BitmapResizer*) h ;
	ReleaseResizer(p);
	stx_free(p);
}

/***********************************************************************
s32 bicubic_resize(STX_HANDLE h,CUBIC_RESIZE_PARAM *lpTpa)
***********************************************************************/
s32 bicubic_resize(STX_HANDLE h,CUBIC_RESIZE_PARAM *lpTpa)
{
	u32 dwInputFormat;
	u32 dwOutputFormat;


	BitmapResizer* pCtx = (BitmapResizer*) h ;

    dwInputFormat = STX_GET_INPUT_FORMAT((lpTpa->dwFlags));
	dwOutputFormat = STX_GET_OUTPUT_FORMAT((lpTpa->dwFlags));	

	switch(dwInputFormat)
	{
	case STX_FORMAT_YV12:
    case STX_FORMAT_YUVA422:
	case STX_FORMAT_YUV444:
		if( STX_OK != CheckSizeCh1(pCtx,lpTpa) )	{
			return STX_FAIL;
		}

		switch(dwOutputFormat)
		{
		case STX_FORMAT_YV12:
	    case STX_FORMAT_YUVA422:
			if( lpTpa->SrcHeight[0] == lpTpa->DstHeight[0] ){
				return ResizeYV12_Width(pCtx,lpTpa);
			}
			else if( lpTpa->SrcWidth[0] == lpTpa->DstWidth[0] ) {
				return ResizeYV12_Height(pCtx,lpTpa);
			}
			else{
				return ResizeYV12(pCtx,lpTpa);
			}

		case STX_FORMAT_YUV444:
			return ResizeYV12(pCtx,lpTpa);
		}
		break;

	case STX_FORMAT_RGB24:
		return	ResizeRGB24(pCtx,lpTpa);

	case STX_FORMAT_RGB32:
		return	ResizeRGB32(pCtx,lpTpa);

	}

	return STX_ERR_INVALID_PARAM;
}



/***********************************************************************
static s32 AllocTempMemoryDst(s32 nDst,CubicTable (*XT)[2])
***********************************************************************/
static s32 AllocTempMemoryDst(s32 nDst,CubicTable (*XT)[2],s32 i_size)
{
	s32 i;
	s32 s = nDst * i_size + 64;
	s32 is = nDst * sizeof(s32) * 2;

	for(i=0;i<2;i++)	{

		(*XT)[i].lpCkAlign  =  (s16*)xlivAlloc(s,TRUE,16);
		if( !(*XT)[i].lpCkAlign ) {
			return STX_FAIL;
		}

		(*XT)[i].lpIndex = (s32*) xlivAlloc(is,TRUE,16);
		if( !(*XT)[i].lpIndex) {
			return STX_FAIL;
		}
	}

	return STX_OK;
}

/***********************************************************************
static void ReleaseTempMemoryDst(CubicTable (*XT)[2])
***********************************************************************/
static void ReleaseTempMemoryDst(CubicTable (*XT)[2])
{
	s32 i;
	for(i=0;i<2;i++){
		if( (*XT)[i].lpCkAlign ) {
			xlivFree((*XT)[i].lpCkAlign);
			(*XT)[i].lpCkAlign = NULL;
		}
		if( (*XT)[i].lpIndex ) {
			xlivFree((*XT)[i].lpIndex);
			(*XT)[i].lpIndex = NULL;
		}
	}
}

/***********************************************************************
static void ReleaseResizer(BitmapResizer* pCtx)
***********************************************************************/
static void ReleaseResizer(BitmapResizer* pCtx)
{
	if( pCtx->i_times ) {
		u32 i_val = (u32)( pCtx->i_time_acc / pCtx->i_times );
		stx_log("cubic resize average time: %d usecond \r\n",i_val);
	}

	ReleaseTempMemoryDst(&pCtx->m_XTable);
	ReleaseTempMemoryDst(&pCtx->m_YTable);

	if( pCtx->m_lpDeinterlaceBuf0 ) {
		xlivFree(pCtx->m_lpDeinterlaceBuf0);
		pCtx->m_lpDeinterlaceBuf0 = NULL;
	}

	if( pCtx->m_lpTemBuffer0 ) {
		xlivFree(pCtx->m_lpTemBuffer0);
		pCtx->m_lpTemBuffer0 = NULL;
	}

	if( pCtx->m_pSrcRowBufPtr ) {
		xlivFree(pCtx->m_pSrcRowBufPtr);
		pCtx->m_pSrcRowBufPtr = NULL;
		pCtx->m_pSrcRowBuf = NULL;
	}

	if( pCtx->m_pDstRowBuf ) {
		xlivFree(pCtx->m_pDstRowBuf);
		pCtx->m_pDstRowBuf = NULL;
	}

	{
		s32 i,j;

		for( i = 0; i < 2; i ++ ) {

			for( j = 0; j < 2; j ++ ) {

				ScaleTable* lptab = &pCtx->m_ScaleTable[i][j];
				if( lptab->naAccu ) {
					xlivFree(lptab->naAccu);
					lptab->naAccu = NULL;
				}
				if( lptab->b_cmpflag ) {
					xlivFree(lptab->b_cmpflag);
					lptab->b_cmpflag = NULL;
				}
				if( lptab->nWeightX ) {
					xlivFree(lptab->nWeightX);
					lptab->nWeightX = NULL;
				}

			}
		}
	}
}

/***********************************************************************
static void InitializeResizer(BitmapResizer* pCtx)
***********************************************************************/
static void InitializeResizer(BitmapResizer* pCtx)
{
	pCtx->m_dwCurSrcWidth = 0;
	pCtx->m_dwCurSrcHeight = 0;
	pCtx->m_dwCurDstWidth = 0;
	pCtx->m_dwCurDstHeight = 0;

	pCtx->m_lpTemBuffer0  = NULL;
	pCtx->m_lpTemBufferAlign  = NULL;
	pCtx->m_lpDeinterlaceBuf0 = NULL;
	pCtx->m_lpDeinterlaceBuf = NULL;
	pCtx->m_pSrcRowBufPtr  = NULL;
	pCtx->m_pSrcRowBuf  = NULL;
	pCtx->m_pDstRowBuf  = NULL;

	memset(&pCtx->m_XTable,0,sizeof(pCtx->m_XTable));
	memset(&pCtx->m_YTable,0,sizeof(pCtx->m_YTable));

	memset(&pCtx->m_ScaleTable,0,sizeof(pCtx->m_ScaleTable));
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static STX_RESULT GetScaleTable(s32 i_src,s32 i_dst,s32 i_nacc,ScaleTable* lpTable,s32 i_pix)
{
	s32		x;
	s32		i_coe_size;
	b32*    b_cmpflag;
	s32*	nWeightX;

	double	fEndX,xScale,nScale;

	lpTable->i_accuracy = 12;
	nScale = (double)i_dst / (double)i_src;
	lpTable->i_scale = (s32) ( nScale * ( 1<< lpTable->i_accuracy ) );

	xScale =  (double)i_src / (double)i_dst;
	fEndX = xScale - 1.0f;

#ifdef UNROLL_SCALE
	i_coe_size = (i_nacc+4)*sizeof(s32)*4;
	if( lpTable->naAccu ) {
		xlivFree(lpTable->naAccu);
	}
	MAKE_TRACE2;
	lpTable->naAccu = (s32*)xlivAlloc(i_coe_size,TRUE,16,MAP_TRACE);
	if( !lpTable->naAccu ) {
		return STX_FAIL;
	}
#endif

	i_coe_size = (i_src + 4) * sizeof(s32);

	if( lpTable->nWeightX ) {
		xlivFree(lpTable->nWeightX);
	}
	lpTable->nWeightX = (s32*)xlivAlloc(i_coe_size,TRUE,16);
	if( !lpTable->nWeightX ) {
		return STX_FAIL;
	}

	if( lpTable->b_cmpflag ) {
		xlivFree(lpTable->b_cmpflag);
	}
	lpTable->b_cmpflag = (s32*)xlivAlloc(i_coe_size,TRUE,16);
	if( !lpTable->b_cmpflag ) {
		return STX_FAIL;
	}

	b_cmpflag = lpTable->b_cmpflag;
	nWeightX = lpTable->nWeightX;

	for( x = 0; x < i_src; x ++ ) {

		if( ( (double)x ) < fEndX ) {
			lpTable->b_cmpflag[x] = TRUE; 
		}
		else{
			*nWeightX++ = (s32)( ( ( (double)x - fEndX )  * nScale ) * (1<<lpTable->i_accuracy) );
			fEndX += xScale;
		}

	} // for( x = 0; x < i_src; x ++ ) {

	return STX_OK;
}


/* Lanczos8 filter, default radius 8
*/
double _Lanczos8(double x)
{
	const double R = 8.0;

	if ( x == 0.0) {
		return 1;
	}

	if ( x < R)	{
		x *= M_PI;
		return R * sin(x) * sin(x / R) / (x*x);
	}

	return 0.0;
}


/* Lanczos3 filter, default radius 3
*/
double _Lanczos3(double x)
{
	const double R = 3.0;

	if ( x == 0.0) {
		return 1;
	}

	if ( x < R){
		x *= M_PI;
		return R * sin(x) * sin(x / R) / (x*x);
	}

	return 0.0;
}


/***********************************************************************
static double _Cubic(double dt)
***********************************************************************/
static double _Cubic(double dt)
{
	double dt2,dt3,ck;

	dt2 = dt * dt;
	dt3 = dt2 * dt;

	if( dt <= 1.0 ) {
		ck = 1.0 - 2.0*dt2 + dt3;
	}
	else if(dt <= 2.0 ) {
		ck = 4.0 - 8.0*dt + 5.0*dt2 - dt3;
	}
	else {
		ck = 0;
	}

	return ck;
}

/***********************************************************************
void GetTableCubic(s32 nSrc,s32 nDst,CubicTable* lpTable)
  pixel locate in (0,1) and (nSrc-2,nSrc-1) should use border extend;
***********************************************************************/
static void GetTableCubic(s32 nSrc,s32 nDst,CubicTable* lpTable)
{
	s32     i,j;
	double  ft,fd;
	s16*    t;

	ft = 0;
	fd = ( (double)nSrc ) / ((double)nDst);
	i = 0;
	t = lpTable->lpCkAlign;

	for ( j = 0; j < nDst; j ++ ) {

		s32 k;

		while ( ft >= i + 1 ) { 
			i ++;               
			// ft must between i, i + 1;
			// ft >= i && ft < i+1
		} // while ( ft >= i + 1 ) { 

		lpTable->lpIndex[j] = i;

		for(k = 0; k < 4; k ++ ){
			double ddt = fabs( ft - (double)(i + k - 1) );
			ddt = _Cubic(ddt)*4096.0;
			t[k] = (short)( ddt + 0.5) ;
		}//for(k = 0; k < 4; k ++ ){

		t += 4;

		ft += fd;

	}//for ( j = 0; j < nDst; j ++ ) {

	lpTable->nDstNormalPixels = nDst & ~3;
	lpTable->nDstEndPixels = nDst & 3;
}


/***********************************************************************
void GetTableLan3(s32 nSrc,s32 nDst,CubicTable* lpTable)
pixel locate in (0,1) and (nSrc-2,nSrc-1) should use border extend;
***********************************************************************/
static void GetTableLan3(s32 nSrc,s32 nDst,CubicTable* lpTable)
{
	s32     i,j;
	double  ft,fd;
	s16*	t;

	ft = 0;
	fd = ( (double)nSrc ) / ((double)nDst);
	i = 0;
	t = (s16*)lpTable->lpCkAlign;

	for ( j = 0; j < nDst; j ++ ) {

		s32 k;

		while ( ft >= i + 1 ) { 
			i ++;               // ft must between i, i + 1;
		}

		lpTable->lpIndex[j] = i;

		for(k = 0; k < 6; k ++ ){
			double ddt = fabs( ft - (double)(i + k - 2) );
			t[k] = (short)( _Lanczos3(ddt)* 4096.0 + 0.5) ;
		}//for(k = 0; k < 4; k ++ ){

		t += 8;
		ft += fd;

	}//for ( j = 0; j < nDst; j ++ ) {

	lpTable->nDstNormalPixels = nDst & ~3;
	lpTable->nDstEndPixels = nDst & 3;
}


/***********************************************************************
void GetTableLan8(s32 nSrc,s32 nDst,CubicTable* lpTable)
pixel locate in (0,1) and (nSrc-2,nSrc-1) should use border extend;
***********************************************************************/
static void GetTableLan8(s32 nSrc,s32 nDst,CubicTable* lpTable)
{
	s32     i,j;
	double  ft,fd;
	s16*	t;

	ft = 0;
	fd = ( (double)nSrc ) / ((double)nDst);
	i = 0;
	t = (s16*)lpTable->lpCkAlign;

	for ( j = 0; j < nDst; j ++ ) {

		s32 k;

		while ( ft >= i + 1 ) { 
			i ++;               // ft must between i, i + 1;
		}

		lpTable->lpIndex[j] = i;

		for(k = 0; k < 16; k ++ ){
			double ddt = fabs( ft - (double)(i + k - 7) );
			t[k] = (short)( _Lanczos8(ddt)* 4096.0 +  0.5) ;
		}//for(k = 0; k < 16; k ++ ){

		t += 16;
		ft += fd;

	}//for ( j = 0; j < nDst; j ++ ) {

	lpTable->nDstNormalPixels = nDst & ~3;
	lpTable->nDstEndPixels = nDst & 3;
}


/***********************************************************************
static void UpdateAlg( BitmapResizer* pCtx,u32 dwAlg,u32 sw,u32 sh, u32 dw,u32 dh )
***********************************************************************/
static void UpdateAlg( BitmapResizer* pCtx,u32 dwAlg,u32 sw,u32 sh, u32 dw,u32 dh )
{
	u32 alg;

	pCtx->m_dwAlg = dwAlg;

#if 1
	pCtx->b_xscale = dw < sw;
	pCtx->b_yscale = dh < sh;
#else
	pCtx->b_xscale = FALSE;
	pCtx->b_yscale = FALSE;
#endif

	//dwAlg = STX_RESIZE_ALG_LAN3;
	//dwAlg = STX_RESIZE_ALG_LAN8;

	if( ! pCtx->b_xscale ) {  

		// stretch;

		// default table;
		alg = STX_RESIZE_ALG_BICUB;

		if( dwAlg == STX_RESIZE_ALG_AUTO ) {
			u32 x;
			x = (dw * 4096 ) / sw;
			if( x >= (3.5*4096) ) {
				alg = STX_RESIZE_ALG_LAN8;
			}
			else if ( x >= (2.5*4096) ) {
				alg = STX_RESIZE_ALG_LAN3;
			}
		}
		else if( dwAlg == STX_RESIZE_ALG_LAN3 ) {
			alg = STX_RESIZE_ALG_LAN3;
		}
		else if( dwAlg == STX_RESIZE_ALG_LAN8 ) {
			alg = STX_RESIZE_ALG_LAN8;
		}

		if( alg == STX_RESIZE_ALG_BICUB ) {
			pCtx->get_xtable = GetTableCubic;
			pCtx->m_iSampleNum[0] = 4;
			pCtx->m_iStartPos[0] = -1;
			pCtx->m_iTableSize[0] = 4*sizeof(s16);
			pCtx->ResizeRowCh1 = CubicResizeRowCh1;
			pCtx->ResizeRowCh4 = CubicResizeRowCh4;
		}
		else if( alg == STX_RESIZE_ALG_LAN3 ) {
			pCtx->get_xtable = GetTableLan3;
			pCtx->m_iSampleNum[0] = 6;
			pCtx->m_iStartPos[0] = -2;
			pCtx->m_iTableSize[0] = 8*sizeof(s16);
			pCtx->ResizeRowCh1 = Lan3ResizeRowCh1;
			pCtx->ResizeRowCh4 = Lan3ResizeRowCh4;
		}
		else if( alg == STX_RESIZE_ALG_LAN8 ) {
			pCtx->get_xtable = GetTableLan8;
			pCtx->m_iSampleNum[0] = 16;
			pCtx->m_iStartPos[0] = -7;
			pCtx->m_iTableSize[0] = 16*sizeof(s16);
			pCtx->ResizeRowCh1 = Lan8ResizeRowCh1;
			pCtx->ResizeRowCh4 = Lan8ResizeRowCh4;
		}

	}
	else {
		pCtx->ScaleRowCh1 = ScaleRowCh1;
		pCtx->ScaleRowCh3 = ScaleRowCh3;
		pCtx->ScaleRowCh4 = ScaleRowCh4;
	}


	if( !pCtx->b_yscale ) {

		// default table;
		alg = STX_RESIZE_ALG_BICUB;

		if( dwAlg == STX_RESIZE_ALG_AUTO ) {
			u32 x;
			x = (dh * 4096 ) / sh;
			if( x >= (3.5*4096) ) {
				alg = STX_RESIZE_ALG_LAN8;
			}
			else if ( x >= (2.5*4096) ) {
				alg = STX_RESIZE_ALG_LAN3;
			}
		}
		else if( dwAlg == STX_RESIZE_ALG_LAN3 ) {
			alg = STX_RESIZE_ALG_LAN3;
		}
		else if( dwAlg == STX_RESIZE_ALG_LAN8 ) {
			alg = STX_RESIZE_ALG_LAN8;
		}

		if( alg == STX_RESIZE_ALG_BICUB ) {
			pCtx->get_ytable = GetTableCubic;
			pCtx->m_iSampleNum[1] = 4;
			pCtx->m_iStartPos[1] = -1;
			pCtx->m_iTableSize[1] = 4*sizeof(s16);
			pCtx->ResizeCol = CubicResizeColom;
		}
		else if( alg == STX_RESIZE_ALG_LAN3 ) {
			pCtx->get_ytable = GetTableLan3;
			pCtx->m_iSampleNum[1] = 6;
			pCtx->m_iStartPos[1] = -2;
			pCtx->m_iTableSize[1] = 8*sizeof(s16);
			pCtx->ResizeCol = Lan3ResizeColom;
		}
		else if( alg == STX_RESIZE_ALG_LAN8 ) {
			pCtx->get_ytable = GetTableLan8;
			pCtx->m_iSampleNum[1] = 16;
			pCtx->m_iStartPos[1] = -7;
			pCtx->m_iTableSize[1] = 16*sizeof(s16);
			pCtx->ResizeCol = Lan8ResizeColom;
		}

	}
	else {
		pCtx->ScaleCol = ScaleColom;
	}

}




/***********************************************************************
static s32 CheckSizeCh3Ch4( BitmapResizer* pCtx,CUBIC_RESIZE_PARAM *lpara )
***********************************************************************/
static s32 CheckSizeCh3Ch4( BitmapResizer* pCtx,CUBIC_RESIZE_PARAM *lpara )
{
	s32 size,i;
	 
	s32 sw = lpara->SrcWidth[0];
	s32 sh = lpara->SrcHeight[0];
	s32 dw = lpara->DstWidth[0];
	s32 dh = lpara->DstHeight[0];

	// check alg;
	u32	  dwAlg = STX_GET_ALG_CODE((lpara->dwFlags));

	if( dw != pCtx->m_dwCurDstWidth || 
		sw != pCtx->m_dwCurSrcWidth ||  
		dh != pCtx->m_dwCurDstHeight || 
		sh != pCtx->m_dwCurSrcHeight ||
		dwAlg != pCtx->m_dwAlg )	{

		UpdateAlg(pCtx,dwAlg,sw,sh,dw,dh);

		if( sw != pCtx->m_dwCurSrcWidth ||  !pCtx->m_pSrcRowBufPtr ) {

			if( pCtx->m_pSrcRowBufPtr ) {
				xlivFree(pCtx->m_pSrcRowBufPtr);
				pCtx->m_pSrcRowBufPtr = NULL;
			}

			pCtx->m_dwSrcRowBufPit = ( (sw*8 + 31) & ~31 ) + 32*4;
			pCtx->m_pSrcRowBufPtr = (u8*)xlivAlloc(pCtx->m_dwSrcRowBufPit*4,TRUE,16);
			if( !pCtx->m_pSrcRowBufPtr ) {
				return STX_FAIL;
			}
			pCtx->m_pSrcRowBuf = pCtx->m_pSrcRowBufPtr + 16*4;

		}//if( sw != pCtx->m_dwCurSrcWidth ||  !pCtx->m_pSrcRowBufPtr ) {

		if( dw != pCtx->m_dwCurDstWidth ||  !pCtx->m_pDstRowBuf ) {
			if( pCtx->m_pDstRowBuf ) {
				xlivFree(pCtx->m_pDstRowBuf);
				pCtx->m_pDstRowBuf = NULL;
			}
			pCtx->m_dwDstRowBufPit = (dw*8 + 31) & ~31;
			pCtx->m_pDstRowBuf = (u8*)xlivAlloc(pCtx->m_dwDstRowBufPit*4,TRUE,16);
			if( !pCtx->m_pDstRowBuf ) {
				return STX_FAIL;
			}
		} //if( dw != pCtx->m_dwCurDstWidth ||  !pCtx->m_pDstRowBuf ) {

		if( pCtx->b_xscale ) {
			// scale
			if( sw != pCtx->m_dwCurSrcWidth || dw != pCtx->m_dwCurDstWidth ) {

				if( STX_OK != GetScaleTable(sw,dw,sh,&pCtx->m_ScaleTable[0][0],4) ) {
					return STX_FAIL;
				}
			}
		}

		ReleaseTempMemoryDst(&pCtx->m_XTable);

		if( STX_OK != (STX_RESULT)AllocTempMemoryDst(dw,&pCtx->m_XTable,(s32)pCtx->m_iTableSize[0]) ) {
			return STX_FAIL;
		}

		pCtx->m_dwCurDstWidth = dw;
		pCtx->m_dwCurPitch = (dw*4 + 31) & ~31;

		size = ( sh + 18 ) * pCtx->m_dwCurPitch;   

		if( pCtx->m_lpTemBuffer0 ) {
			xlivFree(pCtx->m_lpTemBuffer0);
			pCtx->m_lpTemBuffer0 = NULL;
		}
		pCtx->m_lpTemBuffer0 = xlivAlloc(size,TRUE,16);
		if( !pCtx->m_lpTemBuffer0 ) {
			return STX_FAIL;
		}

		pCtx->m_lpTemBufferAlign = (u8*)pCtx->m_lpTemBuffer0 + ( pCtx->m_dwCurPitch * 8 );

		if(!pCtx->b_xscale ) { 
			pCtx->get_xtable( sw, dw, &pCtx->m_XTable[0]);
		}

		pCtx->m_dwCurSrcWidth = sw;

		if( dh != pCtx->m_dwCurDstHeight || sh != pCtx->m_dwCurSrcHeight )	{

			if( pCtx->b_xscale ) {
				// scale;
				if( STX_OK != GetScaleTable(sh,dh,dw,&pCtx->m_ScaleTable[1][0],4) ) {
					return STX_FAIL;
				}
			}

			if( dh != pCtx->m_dwCurDstHeight )	{

				ReleaseTempMemoryDst(&pCtx->m_YTable);

				if( STX_OK != (STX_RESULT)AllocTempMemoryDst(dh,&pCtx->m_YTable,(s32)pCtx->m_iTableSize[1]) ) {
					return STX_FAIL;
				}

				pCtx->m_dwCurDstHeight = dh;
			}

			if(!pCtx->b_yscale ) {
				pCtx->get_ytable( sh, dh, &pCtx->m_YTable[0] );
			}

			pCtx->m_dwCurSrcHeight = sh;

		} //if( dh != pCtx->m_dwCurDstHeight || sh != pCtx->m_dwCurSrcHeight )	{
	}
	
	return STX_OK;
}



/***********************************************************************
static s32 CheckSizeCh1( BitmapResizer* pCtx,CUBIC_RESIZE_PARAM *lpTpa )
***********************************************************************/
static s32 CheckSizeCh1( BitmapResizer* pCtx,CUBIC_RESIZE_PARAM *lpTpa )
{
	s32   i,size;

	s32   sw = lpTpa->SrcWidth[0] ;
	s32   sh = lpTpa->SrcHeight[0];
	s32   dw = lpTpa->DstWidth[0];
	s32   dh = lpTpa->DstHeight[0];

	u32   dwFmt = STX_GET_INPUT_FORMAT((lpTpa->dwFlags));
	u32	  dwAlg = STX_GET_ALG_CODE((lpTpa->dwFlags));

	if( dw != pCtx->m_dwCurDstWidth || sw != pCtx->m_dwCurSrcWidth ||  
		dh != pCtx->m_dwCurDstHeight || sh != pCtx->m_dwCurSrcHeight ||
		dwAlg != pCtx->m_dwAlg )	{

		UpdateAlg(pCtx,dwAlg,sw,sh,dw,dh);

		ReleaseTempMemoryDst(&pCtx->m_XTable);

		if( STX_OK != (STX_RESULT)AllocTempMemoryDst(dw,&pCtx->m_XTable,(s32)pCtx->m_iTableSize[0]) ) {
			return STX_FAIL;
		}

		pCtx->m_dwCurDstWidth = dw;
		pCtx->m_dwCurPitch = (dw + 31) & ~31;

		size = ( sh + 18 ) * pCtx->m_dwCurPitch + 32;   
		if( pCtx->m_lpTemBuffer0 ) {
			xlivFree(pCtx->m_lpTemBuffer0);
			pCtx->m_lpTemBuffer0 = NULL;
		}
		pCtx->m_lpTemBuffer0 = xlivAlloc(size,TRUE,16);
		if( !pCtx->m_lpTemBuffer0 ) {
			return STX_FAIL;
		}
		pCtx->m_lpTemBufferAlign = (u8*)pCtx->m_lpTemBuffer0 + (pCtx->m_dwCurPitch*8);

		if( pCtx->m_lpDeinterlaceBuf0 ) {
			xlivFree(pCtx->m_lpDeinterlaceBuf0);
			pCtx->m_lpDeinterlaceBuf0 = NULL;
		}
		pCtx->m_lpDeinterlaceBuf0 = xlivAlloc(size,TRUE,16);
		if( !pCtx->m_lpDeinterlaceBuf0 ) {
			return STX_FAIL;
		}
		pCtx->m_lpDeinterlaceBuf = (u8*)pCtx->m_lpDeinterlaceBuf0 + (pCtx->m_dwCurPitch*4);

		if( sw != pCtx->m_dwCurSrcWidth ||  !pCtx->m_pSrcRowBufPtr ) {

			if( pCtx->m_pSrcRowBufPtr ) {
				xlivFree(pCtx->m_pSrcRowBufPtr);
				pCtx->m_pSrcRowBufPtr = NULL;
			}

			pCtx->m_dwSrcRowBufPit = ( (sw + 15 ) & ~15 ) + 32;
			pCtx->m_pSrcRowBufPtr = (u8*)xlivAlloc(pCtx->m_dwSrcRowBufPit*4,TRUE,16);
			if( !pCtx->m_pSrcRowBufPtr ) {
				return STX_FAIL;
			}
			pCtx->m_pSrcRowBuf = pCtx->m_pSrcRowBufPtr + 16;
		}


		for(i=0;i<2;i++)	{
			s32 ssw = i == 0 ? sw : sw >> 1;
			s32 ddw = i == 0 ? dw : dw >> 1;
			s32 ddh = i == 0 ? sh : sh >> 1;
			if( pCtx->b_xscale ) {
				// scale
				if( sw != pCtx->m_dwCurSrcWidth || dw != pCtx->m_dwCurDstWidth ) {

					if( STX_OK != GetScaleTable(ssw,ddw,ddh,&pCtx->m_ScaleTable[0][i],1) ) {
						return STX_FAIL;
					}
				}
			}
			else{
				pCtx->get_xtable( ssw, ddw, &pCtx->m_XTable[i] );
			}
		}
		pCtx->m_dwCurSrcWidth = sw;

		if( dh != pCtx->m_dwCurDstHeight || sh != pCtx->m_dwCurSrcHeight )	{
			if( dh != pCtx->m_dwCurDstHeight )	{
				ReleaseTempMemoryDst(&pCtx->m_YTable);
				if( STX_OK != (STX_RESULT)AllocTempMemoryDst(dh,&pCtx->m_YTable,(s32)pCtx->m_iTableSize[1]) ) {
					return STX_FAIL;
				}
				pCtx->m_dwCurDstHeight = dh;
			}

			for(i=0;i<2;i++)	{
				s32 ssh = i == 0 ? sh : sh >> 1;
				s32 ddh = i == 0 ? dh : dh >> 1;
				s32 ddw = i == 0 ? dw : dw >> 1;
				if( pCtx->b_yscale ) {
					if( STX_OK != GetScaleTable(ssh,ddh,ddw,&pCtx->m_ScaleTable[1][i],1) ) {
						return STX_FAIL;
					}
				}
				else {
					pCtx->get_xtable( ssh,ddh,&pCtx->m_YTable[i]);
				}
			}
			pCtx->m_dwCurSrcHeight = sh;
		}
	}

	return STX_OK;
}

/***********************************************************************
static void CubicResizeRowCh1_C
(
BitmapResizer*	pCtx,
u8*				lpSrc,
u8*				lpDst,
CubicTable*		lptable
)
***********************************************************************/
static void CubicResizeRowCh1_C
(
 BitmapResizer*		pCtx,
 u8*				lpSrc,
 u8*				lpDst,
 CubicTable*		lptable
 )
{
#define GET_CUBIC_PIX()\
	val = ( lps[0]*coe[0] + lps[1]*coe[1] + lps[2]*coe[2] + lps[3]*coe[3] + 2048 ) >> 12;\
	*lpDst = clip_ptr [ val ];

	s32 i;
	s32 val;
	u8* lps;
	s32 nWidth = lptable->nDstNormalPixels + lptable->nDstEndPixels;
	s16* coe = lptable->lpCkAlign;

	for( i = 0; i < nWidth; i ++ ) {
		lps = lpSrc + lptable->lpIndex[i] - 1;
		GET_CUBIC_PIX();
		coe += 4;
		lpDst ++;
	}

#undef  GET_CUBIC_PIX
}


/***********************************************************************
static void Lan3ResizeRowCh1_C(  
BitmapResizer* pCtx,
u8* lpSrc,
u8* lpDst,
CubicTable*    lptable )
***********************************************************************/
static void Lan3ResizeRowCh1_C
(  
	BitmapResizer*	pCtx,
	u8*				lpSrc,
	u8*				lpDst,
	CubicTable*		lptable
	)
{
#define GET_CUBIC_PIX()\
	val = ( lps[0]*coe[0] + lps[1]*coe[1] + lps[2]*coe[2] + lps[3]*coe[3] + lps[4]*coe[4] + lps[5]*coe[5]+ 2048 ) >> 12;\
	*lpDst = clip_ptr [ val ];

	s32 i;
	s32 nWidth = lptable->nDstNormalPixels + lptable->nDstEndPixels;
	s16* coe = lptable->lpCkAlign;

	for( i = 0; i < nWidth; i ++ ) {
		s32   val;
		u8* lps = lpSrc + lptable->lpIndex[i] - 2; 
		GET_CUBIC_PIX();
		coe += 8;
		lpDst ++;
	}
#undef  GET_CUBIC_PIX
}

/***********************************************************************
static void Lan8ResizeRowCh1_C(  
BitmapResizer* pCtx,
u8* lpSrc,
u8* lpDst,
CubicTable*    lptable )
***********************************************************************/
static void Lan8ResizeRowCh1_C
(  
 BitmapResizer*		pCtx,
 u8*				lpSrc,
 u8*				lpDst,
 CubicTable*		lptable
 )
{

#define GET_CUBIC_PIX()\
	val = ( lps[0]*coe[0] + lps[1]*coe[1] + lps[2]*coe[2] + lps[3]*coe[3] + \
		lps[4]*coe[4] + lps[5]*coe[5] + lps[6]*coe[6] + lps[7]*coe[7] + \
		lps[8]*coe[8] + lps[9]*coe[9] + lps[10]*coe[10] + lps[11]*coe[11] + \
		lps[12]*coe[12] + lps[13]*coe[13] + lps[14]*coe[14] + lps[15]*coe[15] + \
		2048 ) >> 12;\
	*lpDst = clip_ptr [ val ];

	s32		i;
	s32		nWidth = lptable->nDstNormalPixels + lptable->nDstEndPixels;
	s16*	coe = lptable->lpCkAlign;

	for( i = 0; i < nWidth; i ++ ) {
		s32   val;
		u8* lps = lpSrc + lptable->lpIndex[i] - 7;  //  ?
		GET_CUBIC_PIX();
		coe += 16;
		lpDst ++;
	}

#undef  GET_CUBIC_PIX
}





/***********************************************************************
static void CubicResizeRowCh1_SSE2
(
BitmapResizer*	pCtx,
u8*				lpSrc,
u8*				lpDst,
CubicTable*		lptable
)
***********************************************************************/
static void CubicResizeRowCh1_SSE2
(
 BitmapResizer*		pCtx,
 u8*				lpSrc,
 u8*				lpDst,
 CubicTable*		lptable
 )
{


	XMMI_DECLARE16;
	s16*			lpCkAlign;
	s32*            lpIndex;
	s32             nPixels;     // 4 or 8 per loop

													
	ixmm7 = _mm_setzero_si128();					
													
	ixmm6 = _mm_load_si128(CONV_PXMMI(&round));		
	lpIndex = lptable->lpIndex;						
	lpCkAlign = (s16*)lptable->lpCkAlign;			
	nPixels = lptable->nDstNormalPixels;	

	do{	
		ixmm0 = _mm_cvtsi32_si128( *(s32*)( lpSrc + lpIndex[0] - 1 ) );		
		ixmm1 = _mm_cvtsi32_si128( *(s32*)( lpSrc + lpIndex[1] - 1 ) );		
		ixmm0 = _mm_unpacklo_epi32(ixmm0,ixmm1);
		ixmm4 = _mm_load_si128(CONV_PXMMI(lpCkAlign));
		ixmm0 = _mm_unpacklo_epi8(ixmm0,ixmm7);								
		ixmm0 = _mm_madd_epi16(ixmm0,ixmm4);								
		ixmm2 = _mm_cvtsi32_si128( *(s32*)( lpSrc + lpIndex[2] - 1 ) );		
		ixmm3 = _mm_cvtsi32_si128( *(s32*)( lpSrc + lpIndex[3] - 1 ) );		
		ixmm2 = _mm_unpacklo_epi32(ixmm2,ixmm3);
		ixmm4 = _mm_load_si128(CONV_PXMMI(lpCkAlign+8));
		ixmm2 = _mm_unpacklo_epi8(ixmm2,ixmm7);								
		ixmm2 = _mm_madd_epi16(ixmm2,ixmm4);

		//ixmm0 = _mm_hadd_epi32(ixmm0,ixmm2);      // 3(h+l) 2(h+l) 1(h+l) 0(h+l)
		ixmm1 = ixmm0;							//
		ixmm0 = _mm_unpacklo_epi32(ixmm0,ixmm2);// 2H 0H 2L 0L
		ixmm1 = _mm_unpackhi_epi32(ixmm1,ixmm2);// 3H 1H 3L 1L
		ixmm2 = ixmm0;
		ixmm0 = _mm_unpacklo_epi32(ixmm0,ixmm1);// L 3210
		ixmm2 = _mm_unpackhi_epi32(ixmm2,ixmm1);// H 3210
		ixmm0 = _mm_add_epi32(ixmm0,ixmm2);     // 3210

		ixmm0 = _mm_add_epi32(ixmm0,ixmm6);
		ixmm0 = _mm_srai_epi32(ixmm0,12);
		ixmm0 = _mm_packs_epi32(ixmm0,ixmm7);
		ixmm0 = _mm_packus_epi16(ixmm0,ixmm7);
		*(s32*)lpDst = _mm_cvtsi128_si32(ixmm0);
		nPixels -= 4;
		lpCkAlign += 16;
		lpIndex += 4;
		lpDst += 4;
	}while(nPixels);

	if( (nPixels = lptable->nDstEndPixels) > 0 ) {

		do{
			ixmm0 = _mm_cvtsi32_si128( *(s32*)( lpSrc + *lpIndex - 1 ) );		
			ixmm0 = _mm_unpacklo_epi8(ixmm0,ixmm7);								
			ixmm4 = _mm_loadl_epi64(CONV_PXMMI(lpCkAlign));
			ixmm0 = _mm_madd_epi16(ixmm0,ixmm4);	

			//ixmm0 = _mm_hadd_epi32(ixmm0,ixmm7);  // 1(h+l) 0(h+l)
			ixmm1 = ixmm0;							//
			ixmm0 = _mm_unpacklo_epi32(ixmm0,ixmm7);// _ 0H _ 0L
			ixmm1 = _mm_unpackhi_epi32(ixmm1,ixmm7);// _ 1H _ 1L
			ixmm2 = ixmm0;
			ixmm0 = _mm_unpacklo_epi32(ixmm0,ixmm1);// L 10
			ixmm2 = _mm_unpackhi_epi32(ixmm2,ixmm1);// H 10
			ixmm0 = _mm_add_epi32(ixmm0,ixmm2);     // 10

			ixmm0 = _mm_add_epi32(ixmm0,ixmm6);
			ixmm0 = _mm_srai_epi32(ixmm0,12);
			ixmm0 = _mm_packs_epi32(ixmm0,ixmm7);
			ixmm0 = _mm_packus_epi16(ixmm0,ixmm7);
			*lpDst = (u8)_mm_cvtsi128_si32(ixmm0);
			nPixels --;
			lpCkAlign += 4;
			lpIndex ++;
			lpDst ++;
		}while( nPixels );

	} // if( (nPixels = lptable->nDstEndPixels) > 0 ) {
}

/***********************************************************************
static void CubicResizeRowCh1_SSSE3
(
BitmapResizer*	pCtx,
u8*				lpSrc,
u8*				lpDst,
CubicTable*		lptable,
ScaleTable*		lpScale
)
***********************************************************************/
static void CubicResizeRowCh1_SSSE3
(
 BitmapResizer*		pCtx,
 u8*				lpSrc,
 u8*				lpDst,
 CubicTable*		lptable
 )
{


	XMMI_DECLARE16;
	s16*			lpCkAlign;
	s32*            lpIndex;
	s32             nPixels;     // 4 or 8 per loop


	ixmm7 = _mm_setzero_si128();					

	ixmm6 = _mm_load_si128(CONV_PXMMI(&round));		
	lpIndex = lptable->lpIndex;						
	lpCkAlign = (s16*)lptable->lpCkAlign;			
	nPixels = lptable->nDstNormalPixels;	

	do{	
		ixmm0 = _mm_cvtsi32_si128( *(s32*)( lpSrc + lpIndex[0] - 1 ) );		
		ixmm1 = _mm_cvtsi32_si128( *(s32*)( lpSrc + lpIndex[1] - 1 ) );		
		ixmm0 = _mm_unpacklo_epi32(ixmm0,ixmm1);
		ixmm4 = _mm_load_si128(CONV_PXMMI(lpCkAlign));
		ixmm0 = _mm_unpacklo_epi8(ixmm0,ixmm7);								
		ixmm0 = _mm_madd_epi16(ixmm0,ixmm4);								
		ixmm2 = _mm_cvtsi32_si128( *(s32*)( lpSrc + lpIndex[2] - 1 ) );		
		ixmm3 = _mm_cvtsi32_si128( *(s32*)( lpSrc + lpIndex[3] - 1 ) );		
		ixmm2 = _mm_unpacklo_epi32(ixmm2,ixmm3);
		ixmm4 = _mm_load_si128(CONV_PXMMI(lpCkAlign+8));
		ixmm2 = _mm_unpacklo_epi8(ixmm2,ixmm7);								
		ixmm2 = _mm_madd_epi16(ixmm2,ixmm4);								
		ixmm0 = _mm_hadd_epi32(ixmm0,ixmm2);      // 3(h+l) 2(h+l) 1(h+l) 0(h+l)
		ixmm0 = _mm_add_epi32(ixmm0,ixmm6);
		ixmm0 = _mm_srai_epi32(ixmm0,12);
		ixmm0 = _mm_packs_epi32(ixmm0,ixmm7);
		ixmm0 = _mm_packus_epi16(ixmm0,ixmm7);
		*(s32*)lpDst = _mm_cvtsi128_si32(ixmm0);
		nPixels -= 4;
		lpCkAlign += 16;
		lpIndex += 4;
		lpDst += 4;
	}while(nPixels);

	if( (nPixels = lptable->nDstEndPixels) > 0 ) {

		do{
			ixmm0 = _mm_cvtsi32_si128( *(s32*)( lpSrc + *lpIndex - 1 ) );		
			ixmm0 = _mm_unpacklo_epi8(ixmm0,ixmm7);								
			ixmm4 = _mm_loadl_epi64(CONV_PXMMI(lpCkAlign));
			ixmm0 = _mm_madd_epi16(ixmm0,ixmm4);								
			ixmm0 = _mm_hadd_epi32(ixmm0,ixmm7);      // 1(h+l) 0(h+l)
			ixmm0 = _mm_add_epi32(ixmm0,ixmm6);
			ixmm0 = _mm_srai_epi32(ixmm0,12);
			ixmm0 = _mm_packs_epi32(ixmm0,ixmm7);
			ixmm0 = _mm_packus_epi16(ixmm0,ixmm7);
			*lpDst = (u8)_mm_cvtsi128_si32(ixmm0);
			nPixels --;
			lpCkAlign += 4;
			lpIndex ++;
			lpDst ++;
		}while( nPixels );

	} // if( (nPixels = lptable->nDstEndPixels) > 0 ) {
}


/***********************************************************************
static void  CubicResizeRowCh4_C(
	BitmapResizer* pCtx,
	u8* lpSrc,
	u8* lpDst,
	CubicTable*		lptable,
	ScaleTable*		lpScale
	)
***********************************************************************/
static void  CubicResizeRowCh4_C
(
	BitmapResizer*	pCtx,
	u8*				lpSrc,
	u8*				lpDst,
	CubicTable*		lptable
)
{
#define GET_CUBIC_PIX(k)\
	val = ( lps[k+0]*coe[0] + lps[k+4]*coe[1] + lps[k+8]*coe[2] + lps[k+12]*coe[3] + 2048 ) >> 12;\
	lpDst[k] = clip_ptr [ val ];

	s32 i;
	s32 nWidth = lptable->nDstNormalPixels + lptable->nDstEndPixels;
	s16* coe = lptable->lpCkAlign;

	for( i = 0; i < nWidth; i ++ ) {
	    s32   val;
		u8* lps = lpSrc + (lptable->lpIndex[i] - 1)*4;
		GET_CUBIC_PIX(0);
		GET_CUBIC_PIX(1);
		GET_CUBIC_PIX(2);
		GET_CUBIC_PIX(3);
		lpDst += 4;
		coe += 4;
	}

#undef  GET_CUBIC_PIX
}


/***********************************************************************
static void  Lan3ResizeRowCh4_C(
BitmapResizer* pCtx,
u8* lpSrc,
u8* lpDst,
CubicTable*    lptable)
***********************************************************************/
static void  Lan3ResizeRowCh4_C
(
	BitmapResizer*	pCtx,
	u8*				lpSrc,
	u8*				lpDst,
	CubicTable*		lptable
)
{
#define ___PIX(k,I) lps[I*4+k]*coe[I]
#define GET_CUBIC_PIX(k)\
	val = ( ___PIX(k,0) + ___PIX(k,1) + ___PIX(k,2) + ___PIX(k,3) + \
	___PIX(k,4)+ ___PIX(k,5) + 2048 ) >> 12;\
	lpDst[k] = clip_ptr [ val ];

	s32 i;
	s32 nWidth = lptable->nDstNormalPixels + lptable->nDstEndPixels;
	s16* coe = lptable->lpCkAlign;

	for( i = 0; i < nWidth; i ++ ) {
		s32   val;
		u8* lps = lpSrc + (lptable->lpIndex[i] - 2)*4;
		GET_CUBIC_PIX(0);
		GET_CUBIC_PIX(1);
		GET_CUBIC_PIX(2);
		GET_CUBIC_PIX(3);
		lpDst += 4;
		coe += 8;
	}

#undef  GET_CUBIC_PIX
#undef  ___PIX
}


/***********************************************************************
static void  Lan8ResizeRowCh4_C(
BitmapResizer*	pCtx,
u8*				lpSrc,
u8*				lpDst,
CubicTable*		lptable,
ScaleTable*		lpScale
)
***********************************************************************/
static void  Lan8ResizeRowCh4_C
(
 BitmapResizer*		pCtx,
 u8*				lpSrc,
 u8*				lpDst,
 CubicTable*		lptable
 )
{
#define ___PIX(k,I) (s32)lps[I*4+k]*coe[I]
#define GET_CUBIC_PIX(k)\
	val = ( ___PIX(k,0) + ___PIX(k,1) + ___PIX(k,2) + ___PIX(k,3) + \
	  ___PIX(k,4)+ ___PIX(k,5) + ___PIX(k,6) + ___PIX(k,7) + \
	  ___PIX(k,8)+ ___PIX(k,8) + ___PIX(k,10) + ___PIX(k,11) + \
	  ___PIX(k,12)+ ___PIX(k,13) + ___PIX(k,14) + ___PIX(k,15) + \
	  + 2048 ) >> 12;\
	lpDst[k] = clip_ptr [ val ];

	s32 i;
	s32 nWidth = lptable->nDstNormalPixels + lptable->nDstEndPixels;
	s16* coe = lptable->lpCkAlign;

	for( i = 0; i < nWidth; i ++ ) {
		s32   val;
		u8* lps = lpSrc + (lptable->lpIndex[i] - 7)*4;
		GET_CUBIC_PIX(0);
		GET_CUBIC_PIX(1);
		GET_CUBIC_PIX(2);
		GET_CUBIC_PIX(3);
		lpDst += 4;
		coe += 16;
	}
#undef  GET_CUBIC_PIX
#undef  ___PIX
}

/***********************************************************************
static void  CubicResizeRowCh4_SSE2(
	BitmapResizer* pCtx,
	u8* lpSrc,
	u8* lpDst,
	CubicTable*    lptable)
***********************************************************************/
static void  CubicResizeRowCh4_SSE2
(
	BitmapResizer*	pCtx,
	u8*				lpSrc,
	u8*				lpDst,
	CubicTable*		lptable
	)
{
	XMMI_DECLARE16;
	s16*			lpCkAlign;
	s32*            lpIndex;
	s32             nPixels;     // 4 or 8 per loop

	lpIndex = lptable->lpIndex;						
	lpCkAlign = (s16*)lptable->lpCkAlign;			
	nPixels = lptable->nDstNormalPixels + lptable->nDstEndPixels;	

	ixmm7 = _mm_setzero_si128();
	ixmm6 = _mm_load_si128(CONV_PXMMI(&round));

	do{
		ixmm0 = _mm_loadu_si128( CONV_PXMMI(lpSrc + *lpIndex * 4 - 4) ); 
		ixmm4 = _mm_loadl_epi64(CONV_PXMMI(lpCkAlign));
		ixmm1 = ixmm0;								// p1(3210) p0(3210)
		ixmm1 = _mm_unpackhi_epi64(ixmm1,ixmm1);    // p3(3210) p2(3210)
		ixmm0 = _mm_unpacklo_epi8(ixmm0,ixmm1); 
		// p3(3)p1(3) p3(2)p1(2) p3(1)p1(1) p3(0)p1(0) p2(3)p0(3) p2(2)p0(2)p2(1)p0(1) p2(0)p0(0)
		ixmm4 = _mm_unpacklo_epi64(ixmm4,ixmm4);
		ixmm1 = ixmm0;
		ixmm1 = _mm_unpackhi_epi64(ixmm1,ixmm1);
		ixmm0 = _mm_unpacklo_epi8(ixmm0,ixmm1);
		// p3(3)p2(3)p1(3)p0(3) p3(2)p2(2)p1(2)p0(2) p3(1)p2(1)p1(1)p0(1) p3(0)p2(0)p1(0)p0(0)
		ixmm1 = ixmm0;
		ixmm0 = _mm_unpacklo_epi8(ixmm0,ixmm7); //p3(1)p2(1)p1(1)p0(1) p3(0)p2(0)p1(0)p0(0)
		ixmm1 = _mm_unpackhi_epi8(ixmm1,ixmm7); //p3(3)p2(3)p1(3)p0(3) p3(2)p2(2)p1(2)p0(2)
		ixmm0 = _mm_madd_epi16(ixmm0,ixmm4);
		ixmm1 = _mm_madd_epi16(ixmm1,ixmm4);

		//ixmm0 = _mm_hadd_epi32(ixmm0,ixmm1);    // p3 p2 p1 p0;
		ixmm2 = ixmm0;							//
		ixmm0 = _mm_unpacklo_epi32(ixmm0,ixmm1);// 2H 0H 2L 0L
		ixmm2 = _mm_unpackhi_epi32(ixmm2,ixmm1);// 3H 1H 3L 1L
		ixmm1 = ixmm0;
		ixmm0 = _mm_unpacklo_epi32(ixmm0,ixmm2);// L 3210
		ixmm1 = _mm_unpackhi_epi32(ixmm1,ixmm2);// H 3210
		ixmm0 = _mm_add_epi32(ixmm0,ixmm1);     // 3210

		ixmm0 = _mm_add_epi32(ixmm0,ixmm6);
		ixmm0 = _mm_srai_epi32(ixmm0,12);
		ixmm0 = _mm_packs_epi32(ixmm0,ixmm7);
		ixmm0 = _mm_packus_epi16(ixmm0,ixmm7);
		*(s32*)lpDst = _mm_cvtsi128_si32(ixmm0);
		lpCkAlign += 4;
		lpIndex ++;
		lpDst += 4;
	}while( nPixels -- );
}

/***********************************************************************
static void  CubicResizeRowCh4_SSSE3(
BitmapResizer* pCtx,
u8* lpSrc,
u8* lpDst,
CubicTable*    lptable)
***********************************************************************/
static void  CubicResizeRowCh4_SSSE3
(
	BitmapResizer*	pCtx,
	u8*				lpSrc,
	u8*				lpDst,
	CubicTable*		lptable
	)
{
	XMMI_DECLARE16;
	s16*			lpCkAlign;
	s32*            lpIndex;
	s32             nPixels;     // 4 or 8 per loop

	lpIndex = lptable->lpIndex;						
	lpCkAlign = (s16*)lptable->lpCkAlign;			
	nPixels = lptable->nDstNormalPixels + lptable->nDstEndPixels;	

	ixmm7 = _mm_setzero_si128();
	ixmm6 = _mm_load_si128(CONV_PXMMI(&round));

	do{
		ixmm0 = _mm_loadu_si128( CONV_PXMMI(lpSrc + *lpIndex * 4 - 4) ); 
		ixmm4 = _mm_loadl_epi64(CONV_PXMMI(lpCkAlign));
		ixmm1 = ixmm0;								// p1(3210) p0(3210)
		ixmm1 = _mm_unpackhi_epi64(ixmm1,ixmm1);    // p3(3210) p2(3210)
		ixmm0 = _mm_unpacklo_epi8(ixmm0,ixmm1); 
		// p3(3)p1(3) p3(2)p1(2) p3(1)p1(1) p3(0)p1(0) p2(3)p0(3) p2(2)p0(2)p2(1)p0(1) p2(0)p0(0)
		ixmm4 = _mm_unpacklo_epi64(ixmm4,ixmm4);
		ixmm1 = ixmm0;
		ixmm1 = _mm_unpackhi_epi64(ixmm1,ixmm1);
		ixmm0 = _mm_unpacklo_epi8(ixmm0,ixmm1);
		// p3(3)p2(3)p1(3)p0(3) p3(2)p2(2)p1(2)p0(2) p3(1)p2(1)p1(1)p0(1) p3(0)p2(0)p1(0)p0(0)
		ixmm1 = ixmm0;
		ixmm0 = _mm_unpacklo_epi8(ixmm0,ixmm7); //p3(1)p2(1)p1(1)p0(1) p3(0)p2(0)p1(0)p0(0)
		ixmm1 = _mm_unpackhi_epi8(ixmm1,ixmm7); //p3(3)p2(3)p1(3)p0(3) p3(2)p2(2)p1(2)p0(2)
		ixmm0 = _mm_madd_epi16(ixmm0,ixmm4);
		ixmm1 = _mm_madd_epi16(ixmm1,ixmm4);
		ixmm0 = _mm_hadd_epi32(ixmm0,ixmm1);    // p3 p2 p1 p0;
		ixmm0 = _mm_add_epi32(ixmm0,ixmm6);
		ixmm0 = _mm_srai_epi32(ixmm0,12);
		ixmm0 = _mm_packs_epi32(ixmm0,ixmm7);
		ixmm0 = _mm_packus_epi16(ixmm0,ixmm7);
		*(s32*)lpDst = _mm_cvtsi128_si32(ixmm0);
		lpCkAlign += 4;
		lpIndex ++;
		lpDst += 4;
	}while( nPixels -- );
}

/***********************************************************************
static void ResizeRowCh3( 
	BitmapResizer* pCtx,
	u8* lpSrc,
	u8* lpDst,
	CubicTable*		lptable,
	ScaleTable*		lpScale
	)
***********************************************************************/
static void ResizeRowCh3
( 
	BitmapResizer		*pCtx,
	CUBIC_RESIZE_PARAM	*lpara,
	u8*					lpSrc,
	u8*					lpDst,
	CubicTable*			lptable
)
{
	u32* p;
	u32  val;

	rgb_24to32( lpSrc,pCtx->m_pSrcRowBuf,pCtx->m_dwCurSrcWidth);

	p = (u32*)pCtx->m_pSrcRowBuf;
	val = ((u32*)pCtx->m_pSrcRowBuf)[0];
	p[-1] = p[-2] = p[-3] =	p[-4] = p[-5] = p[-6] = p[-7] = p[-8] = val;

	p = ((u32*)pCtx->m_pSrcRowBuf) + pCtx->m_dwCurSrcWidth;
	val = ((u32*)pCtx->m_pSrcRowBuf)[pCtx->m_dwCurSrcWidth-1];
	p[0] = p[1] = p[2] = p[3] = p[4] = p[5] = p[6] = p[7] = val;

	pCtx->ResizeRowCh4(pCtx,pCtx->m_pSrcRowBuf,pCtx->m_pDstRowBuf,lptable);

	rgb_32to24( pCtx->m_pDstRowBuf,lpDst,pCtx->m_dwCurDstWidth);
}

/***********************************************************************
static void CubicResizeColom_C
(
BitmapResizer*		pCtx,
s32					width,
u8*					lpSrc[],
u8*					lpDst,
CubicTable*			lptable
)
***********************************************************************/
static void CubicResizeColom_C
(
	BitmapResizer*	pCtx,
	s32				width,
	u8*				lpSrc[],
	u8*				lpDst,
	s16*			lpcoe
)
{
#define ___PIX(k,I) (s32)lpSrc[I][k]*lpcoe[I]
#define GET_CUBIC_PIX(k)\
	val = ( ___PIX(k,0) + ___PIX(k,1) + ___PIX(k,2) + ___PIX(k,3) + 2048 ) >> 12;\
	*lpDst = clip_ptr [ val ];

	s32 i;

	for( i = 0; i < width; i ++ ) {
	    s32   val;
		GET_CUBIC_PIX(i);
		lpDst ++;
	}

#undef  GET_CUBIC_PIX
#undef ___PIX
}



/***********************************************************************
static void Lan3ResizeColom_C
(
BitmapResizer*		pCtx,
s32					width,
u8*					lpSrc[],
u8*					lpDst,
CubicTable*		lptable,
ScaleTable*		lpScale
)
***********************************************************************/
static void Lan3ResizeColom_C
(
	BitmapResizer*		pCtx,
	s32					width,
	u8*					lpSrc[],
	u8*					lpDst,
	s16*				lpcoe
)
{
#define ___PIX(k,I) (s32)lpSrc[I][k]*lpcoe[I]
#define GET_CUBIC_PIX(k)\
	val = ( ___PIX(k,0) + ___PIX(k,1) + ___PIX(k,2) + ___PIX(k,3) + ___PIX(k,4) + ___PIX(k,5) + 2048 ) >> 12;\
	*lpDst = clip_ptr [ val ];

	s32		i;
	s32		val;

	for( i = 0; i < width; i ++ ) {
		GET_CUBIC_PIX(i);
		lpDst ++;
	}

#undef  GET_CUBIC_PIX
#undef ___PIX
}


/***********************************************************************
static void Lan8ResizeColom_C
(
BitmapResizer*		pCtx,
s32					width,
u8*					lpSrc[],
u8*					lpDst,
CubicTable*		lptable,
ScaleTable*		lpScale
)
***********************************************************************/
static void Lan8ResizeColom_C
(
	BitmapResizer*	pCtx,
	s32				width,
	u8*				lpSrc[],
	u8*				lpDst,
	s16*			lpcoe
)
{
#define ___PIX(k,I) (s32)lpSrc[I][k]*lpcoe[I]
#define GET_CUBIC_PIX(k)\
	val = ( ___PIX(k,0) + ___PIX(k,1) + ___PIX(k,2) + ___PIX(k,3) + \
	___PIX(k,4) + ___PIX(k,5) + ___PIX(k,6) + ___PIX(k,7) +\
	___PIX(k,8) + ___PIX(k,9) + ___PIX(k,10) + ___PIX(k,11) + \
	___PIX(k,12) + ___PIX(k,13) + ___PIX(k,14) + ___PIX(k,15) +	\
	2048 ) >> 12;\
	*lpDst = clip_ptr [ val ];

	s32		i;
	s32		val;

	for( i = 0; i < width; i ++ ) {
		GET_CUBIC_PIX(i);
		lpDst ++;
	}

#undef  GET_CUBIC_PIX
#undef ___PIX
}


/***********************************************************************
static void CubicResizeColom_SSSE3
(
	BitmapResizer*	pCtx,
	s32				width,
	u8*				lpSrc[],
	u8*				lpDst,
	s16*			lpcoe
)
***********************************************************************/
static void CubicResizeColom_SSE2
(
	BitmapResizer*	pCtx,
	s32				width,
	u8*				lpSrc[],
	u8*				lpDst,
	s16*			lpcoe
)
{

	XMMI_DECLARE16;

	u8*				lpSrc0=lpSrc[0];
	u8*				lpSrc1=lpSrc[1];
	u8*				lpSrc2=lpSrc[2];
	u8*				lpSrc3=lpSrc[3];

	ixmm7 = _mm_setzero_si128();
	ixmm6 = _mm_load_si128(CONV_PXMMI(&round));

	for( ; ; ) {

		do{
			width -= 4;
			ixmm0 = _mm_cvtsi32_si128(*(s32*)lpSrc0);
			ixmm1 = _mm_cvtsi32_si128(*(s32*)lpSrc1);
			lpSrc0 += 4;
			lpSrc1 += 4;
			ixmm2 = _mm_cvtsi32_si128(*(s32*)lpSrc2);
			ixmm3 = _mm_cvtsi32_si128(*(s32*)lpSrc3);
			lpSrc2 += 4;
			lpSrc3 += 4;
			ixmm0 = _mm_unpacklo_epi8(ixmm0,ixmm1);// 10 10 10 10
			ixmm2 = _mm_unpacklo_epi8(ixmm2,ixmm3);// 32 32 32 32
			ixmm4 = _mm_loadl_epi64(CONV_PXMMI(lpcoe));
			ixmm0 = _mm_unpacklo_epi16(ixmm0,ixmm2); // 3210 3210 (32) 3210 3210  (10)
			ixmm4 = _mm_unpacklo_epi64(ixmm4,ixmm4);
			ixmm1 = ixmm0;
			ixmm0 = _mm_unpacklo_epi8(ixmm0,ixmm7);
			ixmm1 = _mm_unpackhi_epi8(ixmm1,ixmm7);
			ixmm0 = _mm_madd_epi16(ixmm0,ixmm4);    // H1 L1  H0 L0 
			ixmm1 = _mm_madd_epi16(ixmm1,ixmm4);    // H3 L3  H2 L2;

			//ixmm0 = _mm_hadd_epi32(ixmm0,ixmm1);    // 3210;
			ixmm2 = ixmm0;							//
			ixmm0 = _mm_unpacklo_epi32(ixmm0,ixmm1);// 2H 0H 2L 0L
			ixmm2 = _mm_unpackhi_epi32(ixmm2,ixmm1);// 3H 1H 3L 1L
			ixmm1 = ixmm0;
			ixmm0 = _mm_unpacklo_epi32(ixmm0,ixmm2);// L 3210
			ixmm1 = _mm_unpackhi_epi32(ixmm1,ixmm2);// H 3210
			ixmm0 = _mm_add_epi32(ixmm0,ixmm1);     // 3210

			ixmm0 = _mm_add_epi32(ixmm0,ixmm6);
			ixmm0 = _mm_srai_epi32(ixmm0,12);
			ixmm0 = _mm_packs_epi32(ixmm0,ixmm7);
			ixmm0 = _mm_packus_epi16(ixmm0,ixmm7);
			*(s32*)lpDst = _mm_cvtsi128_si32(ixmm0);
			lpDst += 4;
		}while(width>=4);

		if( !width ) {
			break;
		}

		{
			const s32 dit = 4 - width;
			lpSrc0 -= dit;
			lpSrc1 -= dit;
			lpSrc2 -= dit;
			lpSrc3 -= dit;
			lpDst -= dit;
			width = 4;
		}
	}
}

/***********************************************************************
static void CubicResizeColom_SSSE3
(
	BitmapResizer*		pCtx,
	s32					width,
	u8*					lpSrc[],
	u8*					lpDst,
	void*				lptable,
	s16*				lpcoe
)
***********************************************************************/
static void CubicResizeColom_SSSE3
(
	BitmapResizer*		pCtx,
	s32					width,
	u8*					lpSrc[],
	u8*					lpDst,
	s16*				lpcoe
)
{
 
	XMMI_DECLARE16;

	u8*				lpSrc0=lpSrc[0];
	u8*				lpSrc1=lpSrc[1];
	u8*				lpSrc2=lpSrc[2];
	u8*				lpSrc3=lpSrc[3];

	ixmm7 = _mm_setzero_si128();
	ixmm6 = _mm_load_si128(CONV_PXMMI(&round));

	for( ; ; ) {

		do{
			width -= 4;
			ixmm0 = _mm_cvtsi32_si128(*(s32*)lpSrc0);
			ixmm1 = _mm_cvtsi32_si128(*(s32*)lpSrc1);
			lpSrc0 += 4;
			lpSrc1 += 4;
			ixmm2 = _mm_cvtsi32_si128(*(s32*)lpSrc2);
			ixmm3 = _mm_cvtsi32_si128(*(s32*)lpSrc3);
			lpSrc2 += 4;
			lpSrc3 += 4;
			ixmm0 = _mm_unpacklo_epi8(ixmm0,ixmm1);// 10 10 10 10
			ixmm2 = _mm_unpacklo_epi8(ixmm2,ixmm3);// 32 32 32 32
			ixmm4 = _mm_loadl_epi64(CONV_PXMMI(lpcoe));
			ixmm0 = _mm_unpacklo_epi16(ixmm0,ixmm2); // 3210 3210 (32) 3210 3210  (10)
			ixmm4 = _mm_unpacklo_epi64(ixmm4,ixmm4);
			ixmm1 = ixmm0;
			ixmm0 = _mm_unpacklo_epi8(ixmm0,ixmm7);
			ixmm1 = _mm_unpackhi_epi8(ixmm1,ixmm7);
			ixmm0 = _mm_madd_epi16(ixmm0,ixmm4);    // H1 L1  H0 L0 
			ixmm1 = _mm_madd_epi16(ixmm1,ixmm4);    // H3 L3  H2 L2;
			ixmm0 = _mm_hadd_epi32(ixmm0,ixmm1);    // 3210;
			ixmm0 = _mm_add_epi32(ixmm0,ixmm6);
			ixmm0 = _mm_srai_epi32(ixmm0,12);
			ixmm0 = _mm_packs_epi32(ixmm0,ixmm7);
			ixmm0 = _mm_packus_epi16(ixmm0,ixmm7);
			*(s32*)lpDst = _mm_cvtsi128_si32(ixmm0);
			lpDst += 4;
		}while(width>=4);

		if( !width ) {
			break;
		}

		{
			const s32 dit = 4 - width;
			lpSrc0 -= dit;
			lpSrc1 -= dit;
			lpSrc2 -= dit;
			lpSrc3 -= dit;
			lpDst -= dit;
			width = 4;
		}
	}
}


/***********************************************************************
static s32 ResizeYV12(BitmapResizer* pCtx,CUBIC_RESIZE_PARAM *lpara)
***********************************************************************/
static s32 ResizeYV12(BitmapResizer* pCtx,CUBIC_RESIZE_PARAM *lpara)
{

	u8* lps[16];

	u8* lpst;
	u8* lpdst;
	s32 i,j,h,kx,ky,wd,sp,dp,iy0;

	s32 nSurface;
	s32 nChangeX,nChangeY;

	u32 dwInputFormat = STX_GET_INPUT_FORMAT((lpara->dwFlags));

	s64 t0 = stx_get_microsec();

	if( dwInputFormat == STX_FORMAT_YUVA422 ){
		nSurface = 4;
		nChangeX = 2;   // the horizontal direction use different table;
		nChangeY = 4;
	}
	else if( dwInputFormat == STX_FORMAT_YUV444 ){
		nSurface = 3;
		nChangeX = 4;  // all the surface use the same table; 
		nChangeY = 4;  //
	}
	else if( dwInputFormat == STX_FORMAT_YV12){
		nSurface = 3;
		nChangeX = 1; 
		nChangeY = 1;
	}
	else {
		nSurface = 1;
		nChangeX = 1; 
		nChangeY = 1;
	}

	for( j = 0;j < nSurface;j ++ )	{

		h  = lpara->DstHeight[j];
		wd = lpara->DstWidth[j];
		sp = lpara->SrcPitch[j];
		dp = lpara->DstPitch[j];
		
		kx = j<nChangeX ? 0 : 1;
		ky = j<nChangeY ? 0 : 1;

		lpst  = lpara->lpSrc[j];
		lpdst = pCtx->m_lpTemBufferAlign;

		if( pCtx->b_xscale ) {

			for( i = 0; i < lpara->SrcHeight[j];) {

				s32 i_row = pCtx->ScaleRowCh1(pCtx,lpara->SrcHeight[j] - i,
					lpst,
					lpara->SrcWidth[j],
					sp,
					lpara->SrcHeight[j],
					lpdst,
					wd,
					pCtx->m_dwCurPitch,
					&pCtx->m_ScaleTable[0][kx]);
				lpst += i_row * sp;
				lpdst += i_row * pCtx->m_dwCurPitch;
				i += i_row;
			}
		}
		else {
			for( i = 0; i < lpara->SrcHeight[j]; i ++ ) {
				memcpy(pCtx->m_pSrcRowBuf,lpst,lpara->SrcWidth[j]);
				*(u32*)(pCtx->m_pSrcRowBuf-4) = g_dwByte2Int32[pCtx->m_pSrcRowBuf[0]];
				*(u32*)(pCtx->m_pSrcRowBuf + lpara->SrcWidth[j]) = 
					g_dwByte2Int32[ pCtx->m_pSrcRowBuf[lpara->SrcWidth[j]-1] ];
				pCtx->ResizeRowCh1(pCtx,pCtx->m_pSrcRowBuf,lpdst,&pCtx->m_XTable[kx]);
				lpst += sp;
				lpdst += pCtx->m_dwCurPitch;
			}
		}

		lpdst = (u8*)lpara->lpDst[j];

		if( pCtx->b_yscale ) {

			u8* lpsss = pCtx->m_lpTemBufferAlign;
			u8* lpddd = lpdst;

			for( i = 0; i < wd; )  {

				s32 i_col = pCtx->ScaleCol(pCtx,wd - i,
					lpsss,
					lpara->SrcHeight[j],
					pCtx->m_dwCurPitch,
					lpddd,
					h,
					dp,
					wd,
					&pCtx->m_ScaleTable[1][ky]);

				lpsss += i_col;
				lpddd += i_col;
				i += i_col;
			}

		}
		else {

			u8* pTmpBufMax = pCtx->m_lpTemBufferAlign + (lpara->SrcHeight[j]-1)*pCtx->m_dwCurPitch;

			iy0 = -64;

			for( i = 0 ; i < h ; i ++ ) {

				s32 iy1;
				u8* lpck;

				iy1 = pCtx->m_YTable[ky].lpIndex[i];

				if( iy0 != iy1 ) {
					s32 kk;
					lpst = pCtx->m_lpTemBufferAlign + (iy1+pCtx->m_iStartPos[1])*pCtx->m_dwCurPitch;
					for( kk = 0; kk < pCtx->m_iSampleNum[1]; kk ++ )	{
						lps[kk] = lpst;
						if( lps[kk] < pCtx->m_lpTemBufferAlign ) {
							lps[kk] = pCtx->m_lpTemBufferAlign;
						}
						if( lps[kk] > pTmpBufMax ) {
							lps[kk] = pTmpBufMax;
						}
						lpst += pCtx->m_dwCurPitch;
					}
				}

				iy0 = iy1;

				lpck = (u8*)pCtx->m_YTable[ky].lpCkAlign + i*pCtx->m_iTableSize[1];

				pCtx->ResizeCol(pCtx,wd,lps,lpdst,(void*)lpck);

				lpdst += dp;

			} // for( i = 0 ; i < h ; i ++ ) {

		} // block;

	} // for( j = 0;j < nSurface;j ++ )	{

	t0 = stx_get_microsec() - t0;
	pCtx->i_time_acc += t0;
	pCtx->i_times ++;

	return STX_OK;
}

/***********************************************************************
static s32 ResizeYV12_Width(BitmapResizer* pCtx,CUBIC_RESIZE_PARAM *lpara)
***********************************************************************/
static s32 ResizeYV12_Width(BitmapResizer* pCtx,CUBIC_RESIZE_PARAM *lpara)
{
	u8* lpst;
	u8* lpdst;
	s32 i,j,h,kx,ky,wd,sp,dp;

	s32 nSurface;
	s32 nChangeX,nChangeY;

	u32 dwInputFormat = STX_GET_INPUT_FORMAT((lpara->dwFlags));

	if( dwInputFormat == STX_FORMAT_YUVA422 ){
		nSurface = 4;
		nChangeX = 2;   // the horizontal direction use different table;
		nChangeY = 4;
	}
	else if( dwInputFormat == STX_FORMAT_YUV444 ){
		nSurface = 3;
		nChangeX = 4;  // all the surface use the same table; 
		nChangeY = 4;  //
	}
	else {
		// if( dwInputFormat == STX_FORMAT_YV12)
		nSurface = 3;
		nChangeX = 1; 
		nChangeY = 1;
	}

	for( j=0;j<nSurface;j++)	{

		h = lpara->DstHeight[j];
		wd = lpara->DstWidth[j];
		sp = lpara->SrcPitch[j];
		dp = lpara->DstPitch[j];
		
		kx = j<nChangeX ? 0 : 1;
		ky = j<nChangeY ? 0 : 1;


		lpst = (u8*)lpara->lpSrc[j];
		lpdst = (u8*)lpara->lpDst[j];

		if( lpara->SrcWidth[0] == lpara->DstWidth[0] ){
			for( i = 0; i < lpara->SrcHeight[j]; i ++ ) {
				memcpy(lpdst,lpst,lpara->SrcWidth[j]);
				lpst += sp;
				lpdst += dp;
			}
		}
		else{
			if( pCtx->b_xscale ) {

				for( i = 0; i < lpara->SrcHeight[j];  ) {

					s32 i_row;

					memcpy(pCtx->m_pSrcRowBuf,lpst,lpara->SrcWidth[j]);

					i_row = pCtx->ScaleRowCh1(pCtx,lpara->SrcHeight[j] - i,
						pCtx->m_pSrcRowBuf,
						lpara->SrcWidth[j],
						sp,
						lpara->SrcHeight[j],
						lpdst,
						wd,
						pCtx->m_dwCurPitch,
						&pCtx->m_ScaleTable[0][kx]);

					lpst += i_row*sp;
					lpdst += i_row*dp;
					i += i_row;
				}
			}
			else {
				for( i = 0; i < lpara->SrcHeight[j]; i ++ ) {

					memcpy(pCtx->m_pSrcRowBuf,lpst,lpara->SrcWidth[j]);

					*(u32*)(pCtx->m_pSrcRowBuf-8) =
						*(u32*)(pCtx->m_pSrcRowBuf-4) = 
						g_dwByte2Int32[pCtx->m_pSrcRowBuf[0]];

					*(u32*)(pCtx->m_pSrcRowBuf + lpara->SrcWidth[j]) = 
						*(u32*)(pCtx->m_pSrcRowBuf + lpara->SrcWidth[j] + 4) = 
						g_dwByte2Int32[ pCtx->m_pSrcRowBuf[lpara->SrcWidth[j]-1] ];

					pCtx->ResizeRowCh1(pCtx,pCtx->m_pSrcRowBuf,lpdst,&pCtx->m_XTable[kx]);
					
					lpst += sp;
					lpdst += dp;
				}
			}
		}
	}

	return STX_OK;
}


/***********************************************************************
static s32 ResizeYV12_Height(BitmapResizer* pCtx,CUBIC_RESIZE_PARAM *lpara)
***********************************************************************/
static s32 ResizeYV12_Height(BitmapResizer* pCtx,CUBIC_RESIZE_PARAM *lpara)
{
	u8* lps[16];

	u8* lpst;
	u8* lpdst;
	s32 i,j,h,kx,ky,wd,sp,dp,iy0;

	s32 nSurface;
	s32 nChangeX,nChangeY;

	u32 dwInputFormat = STX_GET_INPUT_FORMAT((lpara->dwFlags));
	BOOL bDeinterlace = STX_GET_EFFECT((lpara->dwFlags)) & STX_EFFECT_DEINTERLACE;

	if( dwInputFormat == STX_FORMAT_YUVA422 ){
		nSurface = 4;
		nChangeX = 2;   // the horizontal direction use different table;
		nChangeY = 4;
	}
	else if( dwInputFormat == STX_FORMAT_YUV444 ){
		nSurface = 3;
		nChangeX = 4;  // all the surface use the same table; 
		nChangeY = 4;  //
	}
	else {
		// if( dwInputFormat == STX_FORMAT_YV12)
		nSurface = 3;
		nChangeX = 1; 
		nChangeY = 1;
	}

	for( j = 0; j < nSurface; j ++ )	{

		if( lpara->SrcHeight[0] == lpara->DstHeight[0] ){
			lpdst = (u8*)lpara->lpDst[j];
			lpst = (u8*)lpara->lpSrc[j];
			for( i = 0; i < lpara->SrcHeight[j]; i ++ ) {
				memcpy(lpdst,lpst,lpara->SrcWidth[j]);
				lpst += sp;
				lpdst += dp;
			}
			continue;
		}

		h = lpara->DstHeight[j];
		wd = lpara->DstWidth[j];
		sp = lpara->SrcPitch[j];
		dp = lpara->DstPitch[j];

		kx = j<nChangeX ? 0 : 1;
		ky = j<nChangeY ? 0 : 1;

		if( ! bDeinterlace ) {

			if( pCtx->b_yscale ) {

				u8* lpsss = lpara->lpSrc[j];
				u8* lpddd = (u8*)lpara->lpDst[j];

				for( i = 0; i < wd; )  {

					s32 i_col = pCtx->ScaleCol(pCtx,wd-i,
						lpsss,
						lpara->SrcHeight[j],
						lpara->SrcPitch[j],
						lpddd,
						h,
						dp,
						wd,
						&pCtx->m_ScaleTable[1][ky]);

					lpsss += i_col;
					lpddd += i_col;
					i += i_col;
				}

			}
			else{

				u8* pTmpBufMax;

				lpdst = (u8*)lpara->lpDst[j];
				pTmpBufMax = lpara->lpSrc[j] + (lpara->SrcHeight[j]-1)*lpara->SrcPitch[j];
				iy0 = -64;

				for(i=0;i<h;i++) {

					s32 iy1;
					u8* lpck;

					iy1 = pCtx->m_YTable[ky].lpIndex[i];

					if(iy0!=iy1) {
						s32 kk;
						lpst = lpara->lpSrc[j] + (iy1+pCtx->m_iStartPos[1])*lpara->SrcPitch[j];
						for(kk=0;kk<pCtx->m_iSampleNum[1];kk++)	{
							lps[kk] = lpst;
							if( lps[kk] < lpara->lpSrc[j] ) {
								lps[kk] = lpara->lpSrc[j];
							}
							if( lps[kk] > pTmpBufMax ) {
								lps[kk] = pTmpBufMax;
							}
							lpst += lpara->SrcPitch[j];
						}
					}

					iy0 = iy1;

					lpck = (u8*)pCtx->m_YTable[ky].lpCkAlign + i*pCtx->m_iTableSize[1];

					pCtx->ResizeCol(pCtx,wd,lps,lpdst,(void*)lpck);

					lpdst += dp;

				}//for(i=0;i<h;i++) {

			} // if( pCtx->b_yscale ) {...}else{

		}
		else{
		//<< do deinterlace;

			s32 len;

			lpst = (u8*)lpara->lpSrc[j];
			lpdst = pCtx->m_lpTemBufferAlign;

			for( i = 0; i < lpara->SrcHeight[j]; i ++ ) {
				memcpy(lpdst,lpst,lpara->SrcWidth[j]);
				lpst += sp;
				lpdst += pCtx->m_dwCurPitch;
			}

			lpst = pCtx->m_lpTemBufferAlign;
			for( i = 0; i < 3; i ++ ) {
				lps[i] = lpst;
				lpst += pCtx->m_dwCurPitch;
			}

			len = lpara->SrcHeight[j] * pCtx->m_dwCurPitch;

			memcpy( pCtx->m_lpTemBufferAlign +  len , pCtx->m_lpTemBufferAlign + len - pCtx->m_dwCurPitch, wd );
			memcpy( pCtx->m_lpTemBufferAlign +  len + pCtx->m_dwCurPitch , pCtx->m_lpTemBufferAlign + len - pCtx->m_dwCurPitch, wd );

			for( i = 0; i < lpara->SrcHeight[j]; i ++ ) {
				blend_field(lps,lps[0],pCtx->m_dwCurPitch);
				lps[0] += pCtx->m_dwCurPitch;
				lps[1] += pCtx->m_dwCurPitch;
				lps[2] += pCtx->m_dwCurPitch;
			}
			//>>


			if( pCtx->b_yscale ) {

				u8* lpsss = pCtx->m_lpTemBufferAlign;
				u8* lpddd = (u8*)lpara->lpDst[j];

				for( i = 0; i < wd; i ++ )  {

					pCtx->ScaleCol(pCtx,wd - i,
						lpsss,
						lpara->SrcHeight[j],
						pCtx->m_dwCurPitch,
						lpddd,
						h,
						dp,
						wd,
						&pCtx->m_ScaleTable[1][ky]);

					lpsss ++;
					lpddd ++;
				} // for( i = 0; i < wd; i ++ )  {
			}
			else {

				u8* pTmpBufMax = pCtx->m_lpTemBufferAlign + (lpara->SrcHeight[j]-1)*pCtx->m_dwCurPitch;

				lpdst = (u8*)lpara->lpDst[j];
				iy0 = -64;

				for(i=0;i<h;i++) {

					s32 iy1;
					u8* lpck;

					iy1 = pCtx->m_YTable[ky].lpIndex[i];

					if(iy0!=iy1) {
						s32 kk;
						lpst = pCtx->m_lpTemBufferAlign + (iy1+pCtx->m_iStartPos[1])*pCtx->m_dwCurPitch;
						for(kk=0;kk<pCtx->m_iSampleNum[1];kk++)	{
							lps[kk] = lpst;
							if( lps[kk] < pCtx->m_lpTemBufferAlign ) {
								lps[kk] = pCtx->m_lpTemBufferAlign;
							}
							if( lps[kk] > pTmpBufMax ) {
								lps[kk] = pTmpBufMax;
							}
							lpst += pCtx->m_dwCurPitch;
						}
					}

					iy0 = iy1;

					lpck = (u8*)pCtx->m_YTable[ky].lpCkAlign + i*pCtx->m_iTableSize[1];

					pCtx->ResizeCol(pCtx,wd,lps,lpdst,(void*)lpck);

					lpdst += dp;

				} // for(i=0;i<h;i++) {

			} //if( pCtx->b_yscale ) {..}else{

		} //if( ! bDeinterlace ) {...}else{

	} // for( j = 0; j < nSurface; j ++ )	{

	return STX_OK;
}




/***********************************************************************
static s32 ResizeRGB24(BitmapResizer* pCtx,CUBIC_RESIZE_PARAM *lpara)
***********************************************************************/
static s32 ResizeRGB24(BitmapResizer* pCtx,CUBIC_RESIZE_PARAM *lpara)
{
	s32 i;
	u8* lps[16];

	s32 wd;

	u8* lpsrc;
	u8* lpdst;

	if( STX_OK != CheckSizeCh3Ch4(pCtx,lpara) )	{
		return STX_FAIL;
	}

	wd = lpara->DstWidth[0] * 3;
	
	lpsrc = lpara->lpSrc[0];
	lpdst = pCtx->m_lpTemBufferAlign;

	if( pCtx->b_xscale ){
		for( i = 0; i < lpara->SrcHeight[0];  ) {
			s32 i_row = pCtx->ScaleRowCh3(pCtx,lpara->SrcHeight[0] - i,
				lpsrc,
				lpara->SrcWidth[0],
				lpara->SrcPitch[0],
				lpara->SrcHeight[0],
				lpdst,
				lpara->DstWidth[0],
				pCtx->m_dwCurPitch,
				&pCtx->m_ScaleTable[0][0]);
			lpsrc += i_row*lpara->SrcPitch[0];
			lpdst += i_row*pCtx->m_dwCurPitch;
			i += i_row;
		}
	}
	else {
		for( i = 0; i < lpara->SrcHeight[0]; i ++ ) {
			ResizeRowCh3(pCtx,lpara,lpsrc,lpdst,&pCtx->m_XTable[0]);
			lpsrc += lpara->SrcPitch[0];
			lpdst += pCtx->m_dwCurPitch;
		}
	}

	lpdst = lpara->lpDst[0];

	if( pCtx->b_yscale ) {

		u8* lpsss = pCtx->m_lpTemBufferAlign;
		u8* lpddd = lpdst;
#if 1
		for( i = 0; i < wd; )  {

			s32 i_col = pCtx->ScaleCol(pCtx,wd - i,
				lpsss,
				lpara->SrcHeight[0],
				pCtx->m_dwCurPitch,
				lpddd,
				lpara->DstHeight[0],
				lpara->DstPitch[0],
				lpara->DstWidth[0],
				&pCtx->m_ScaleTable[1][0]);

			lpsss += i_col;
			lpddd += i_col;
			i += i_col;
		}
#else
		for( i = 0; i < lpara->DstHeight[0]; i ++ )  {

			memcpy(lpddd,lpsss,wd);
			lpsss += pCtx->m_dwCurPitch;
			lpddd += lpara->DstPitch[0];

		}
#endif
	}
	else{

		s32 iy0 = -64;

		u8* pTmpBufMax = pCtx->m_lpTemBufferAlign + (lpara->SrcHeight[0]-1)*pCtx->m_dwCurPitch;

		for( i = 0; i < lpara->DstHeight[0]; i ++ )  {
			s32 iy1;
			u8* lpck;

			iy1 = pCtx->m_YTable[0].lpIndex[i];

			if(iy0!=iy1) {
				s32 kk;
				lpsrc = pCtx->m_lpTemBufferAlign + (iy1+pCtx->m_iStartPos[1])*pCtx->m_dwCurPitch;
				for(kk=0;kk<pCtx->m_iSampleNum[1];kk++)	{
					lps[kk] = lpsrc;
					if( lps[kk] < pCtx->m_lpTemBufferAlign ) {
						lps[kk] = pCtx->m_lpTemBufferAlign;
					}
					if( lps[kk] > pTmpBufMax ) {
						lps[kk] = pTmpBufMax;
					}
					lpsrc += pCtx->m_dwCurPitch;
				}
			}

			iy0 = iy1;

			lpck = (u8*)pCtx->m_YTable[0].lpCkAlign + i*pCtx->m_iTableSize[1];

			pCtx->ResizeCol(pCtx,wd,lps,lpdst,(void*)lpck);

			lpdst += lpara->DstPitch[0];
		}
	}

	return STX_OK;
}

/***********************************************************************
static s32 ResizeRGB32(BitmapResizer* pCtx,CUBIC_RESIZE_PARAM *lpara)
***********************************************************************/
static s32 ResizeRGB32(BitmapResizer* pCtx,CUBIC_RESIZE_PARAM *lpara)
{

	s32 i;
	u8* lps[16];

	s32 wd = lpara->DstWidth[0] * 4;
	
	u8* lpsrc = lpara->lpSrc[0];
	u8* lpdst = pCtx->m_lpTemBufferAlign;

	if( STX_OK != CheckSizeCh3Ch4(pCtx,lpara) )	{
		return STX_FAIL;
	}


	if( pCtx->b_xscale ) {

		for( i = 0; i < lpara->SrcHeight[0]; ) {

			s32 i_row = pCtx->ScaleRowCh4(pCtx, lpara->SrcHeight[0] - i,
				lpsrc,
				lpara->SrcWidth[0],
				lpara->SrcPitch[0],
				lpara->SrcHeight[0],
				lpdst,
				lpara->DstWidth[0],
				pCtx->m_dwCurPitch,
				&pCtx->m_ScaleTable[0][0]);

			lpsrc += i_row * lpara->SrcPitch[0];
			lpdst += i_row * pCtx->m_dwCurPitch;
			i += i_row;
		}

	}
	else{

		for( i = 0; i < lpara->SrcHeight[0]; i ++ ) {

			u32* p;
			u32  val;

			memcpy(pCtx->m_pSrcRowBuf,lpsrc,wd);

			p = (u32*)pCtx->m_pSrcRowBuf;
			val = ((u32*)pCtx->m_pSrcRowBuf)[0];
			p[-1] = p[-2] = p[-3] =	p[-4] = p[-5] = p[-6] = p[-7] = p[-8] = val;

			p = ((u32*)pCtx->m_pSrcRowBuf) + pCtx->m_dwCurSrcWidth;
			val = ((u32*)pCtx->m_pSrcRowBuf)[pCtx->m_dwCurSrcWidth-1];
			p[0] = p[1] = p[2] = p[3] = p[4] = p[5] = p[6] = p[7] = val;

			pCtx->ResizeRowCh4(pCtx,pCtx->m_pSrcRowBuf,lpdst,&pCtx->m_XTable[0]);

			lpsrc += lpara->SrcPitch[0];
			lpdst += pCtx->m_dwCurPitch;
		}

	}

	lpdst = lpara->lpDst[0];

	if( pCtx->b_yscale ) {

		u8* lpsss = pCtx->m_lpTemBufferAlign;
		u8* lpddd = lpdst;

		for( i = 0; i < wd; )  {

			s32 i_col = pCtx->ScaleCol(pCtx,wd - i,
				lpsss,
				lpara->SrcHeight[0],
				pCtx->m_dwCurPitch,
				lpddd,
				lpara->DstHeight[0],
				lpara->DstPitch[0],
				lpara->DstWidth[0],
				&pCtx->m_ScaleTable[1][0]);

			lpsss += i_col;
			lpddd += i_col;
			i += i_col;
		}

	}
	else{

		s32 iy0 = -64;

		u8* pTmpBufMax = pCtx->m_lpTemBufferAlign + (lpara->SrcHeight[0]-1)*pCtx->m_dwCurPitch;

		for( i = 0; i < lpara->DstHeight[0]; i ++ )  {

			s32 iy1;
			u8* lpck;

			iy1 = pCtx->m_YTable[0].lpIndex[i];

			if(iy0!=iy1) {
				s32 kk;
				lpsrc = pCtx->m_lpTemBufferAlign + (iy1+pCtx->m_iStartPos[1])*pCtx->m_dwCurPitch;
				for(kk=0;kk<pCtx->m_iSampleNum[1];kk++)	{
					lps[kk] = lpsrc;
					if( lps[kk] < pCtx->m_lpTemBufferAlign ) {
						lps[kk] = pCtx->m_lpTemBufferAlign;
					}
					if( lps[kk] > pTmpBufMax ) {
						lps[kk] = pTmpBufMax;
					}
					lpsrc += pCtx->m_dwCurPitch;
				}
			}

			iy0 = iy1;

			lpck = (u8*)pCtx->m_YTable[0].lpCkAlign + i*pCtx->m_iTableSize[1];

			pCtx->ResizeCol(pCtx,wd,lps,lpdst,(void*)lpck);

			lpdst += lpara->DstPitch[0];
		}

	}

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static s32 ScaleRowCh3_C
( 
	BitmapResizer*	pCtx,
	s32				i_rear,
	u8*				lpSrc,
	s32				i_src_width,
	s32				i_src_pit,
	s32				i_src_height,
	u8*				lpDst,
	s32				i_dst_width,
	s32				i_dst_pit,
	ScaleTable*		lpScale
)
{
#ifdef UNROLL_SCALE

	s32 x,u,i,y;

	s32 const i_accuracy = lpScale->i_accuracy;
	s32 const i_round = 1<<(lpScale->i_accuracy-1);
	s32 const i_scale = lpScale->i_scale;

	s32*		nWeightX = 	lpScale->nWeightX;

	memset(lpScale->naAccu,0,i_src_height*sizeof(s32)*4);

	u = i = 0;

	for( x = 0; x < i_src_width; x ++ ) {

		if( lpScale->b_cmpflag[x] ) {

			u8* lpsss = lpSrc;
			
			s32* naAccu =  lpScale->naAccu;

			for( y = 0; y < i_src_height; y ++ ) {
				naAccu[0] += lpsss[0] * i_scale;
				naAccu[1] += lpsss[1] * i_scale;
				naAccu[2] += lpsss[2] * i_scale;
				naAccu += 4;
				lpsss += i_src_pit;
			}

			lpSrc += 3;
		}
		else {

			s32 const nWeightX0 = i_scale - *nWeightX;
			s32 const nWeightX1 = *nWeightX++;

			u8* lpsss = lpSrc;
			u8* lpddd = lpDst + i;

			s32* naAccu =  lpScale->naAccu;

			for( y = 0; y < i_src_height; y ++ ) {

				naAccu[0] += lpsss[0] * nWeightX0 ;
				lpddd[0] = clip_ptr [( naAccu[0] + i_round ) >> i_accuracy];
				naAccu[0] = lpsss[0] * nWeightX1 ;

				naAccu[1] += lpsss[1] * nWeightX0 ;
				lpddd[1] = clip_ptr [( naAccu[1] + i_round ) >> i_accuracy];
				naAccu[1] = lpsss[1] * nWeightX1 ;

				naAccu[2] += lpsss[2] * nWeightX0 ;
				lpddd[2] = clip_ptr [( naAccu[2] + i_round ) >> i_accuracy];
				naAccu[2] = lpsss[2] * nWeightX1 ;

				lpsss += i_src_pit;
				lpddd += i_dst_pit;
				naAccu += 4;
			}

			lpSrc += 3;
			i += 3;
			u ++;
		}

	} // for( x = 0; i < width; x ++ ) {

	if( u < i_dst_width ) {
		u8* lpddd = lpDst + i;
		s32* naAccu =  lpScale->naAccu;
		for( y = 0; y < i_src_height; y ++ ) {

			lpddd[0] = clip_ptr [( naAccu[0] + i_round ) >> i_accuracy];
			lpddd[1] = clip_ptr [( naAccu[1] + i_round ) >> i_accuracy];
			lpddd[2] = clip_ptr [( naAccu[2] + i_round ) >> i_accuracy];
			lpddd += i_dst_pit;
			naAccu += 4;
		}
	}

	return i_src_height;

#else

	s32 x,u,i;

	s32 const i_accuracy = lpScale->i_accuracy;
	s32 const i_round = 1<<(lpScale->i_accuracy-1);
	s32 const i_scale = lpScale->i_scale;

	s32*		nWeightX = 	lpScale->nWeightX;

	s32			naAccu[4] = {0};

	u = i = 0;

	for( x = 0; x < i_src_width; x ++ ) {

		if( lpScale->b_cmpflag[x] ) {
			naAccu[0] += ( *lpSrc ++ ) * i_scale ;
			naAccu[1] += ( *lpSrc ++ ) * i_scale ;
			naAccu[2] += ( *lpSrc ++ ) * i_scale ;
		}
		else {
			s32 const nWeightX0 = i_scale - *nWeightX;
			s32 const nWeightX1 = *nWeightX++;

			naAccu[0] += ( *lpSrc ) * nWeightX0 ;
			lpDst[i+0] = clip_ptr [( naAccu[0] + i_round ) >> i_accuracy];
			naAccu[0] = ( *lpSrc ++ ) * nWeightX1 ;

			naAccu[1] += ( *lpSrc ) * nWeightX0 ;
			lpDst[i+1] = clip_ptr [( naAccu[1] + i_round ) >> i_accuracy];
			naAccu[1] = ( *lpSrc ++ ) * nWeightX1 ;

			naAccu[2] += ( *lpSrc ) * nWeightX0 ;
			lpDst[i+2] = clip_ptr [( naAccu[2] + i_round ) >> i_accuracy];
			naAccu[2] = ( *lpSrc ++ ) * nWeightX1 ;

			i += 3;
			u ++;
		}

	} // for( x = 0; i < width; x ++ ) {

	if( u < i_dst_width ) {
		lpDst[i+0] = clip_ptr [( naAccu[0] + i_round ) >> i_accuracy];
		lpDst[i+1] = clip_ptr [( naAccu[1] + i_round ) >> i_accuracy];
		lpDst[i+2] = clip_ptr [( naAccu[2] + i_round ) >> i_accuracy];
	}

	return 1;

#endif

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static s32 ScaleRowCh4_C
( 
	BitmapResizer*	pCtx,
	s32				i_rear,
	u8*				lpSrc,
	s32				i_src_width,
	s32				i_src_pit,
	s32				i_src_height,
	u8*				lpDst,
	s32				i_dst_width,
	s32				i_dst_pit,
	ScaleTable*		lpScale
)
{
	s32 x,u,i;

	s32 const i_accuracy = lpScale->i_accuracy;
	s32 const i_round = 1<<(lpScale->i_accuracy-1);
	s32 const i_scale = lpScale->i_scale;

	s32*	nWeightX = 	lpScale->nWeightX;

	s32 naAccu[4] = {0};

	u = i = 0;

	for( x = 0; x < i_src_width; x ++ ) {

		if( lpScale->b_cmpflag[x] ) {
			naAccu[0] += ( *lpSrc ++ ) * i_scale ;
			naAccu[1] += ( *lpSrc ++ ) * i_scale ;
			naAccu[2] += ( *lpSrc ++ ) * i_scale ;
			naAccu[3] += ( *lpSrc ++ ) * i_scale ;
		}
		else {
			s32 const nWeightX0 = i_scale - *nWeightX;
			s32 const nWeightX1 = *nWeightX++;

			naAccu[0] += ( *lpSrc ) * nWeightX0 ;
			lpDst[i+0] = clip_ptr [( naAccu[0] + i_round ) >> i_accuracy];
			naAccu[0] = ( *lpSrc ++ ) * nWeightX1 ;

			naAccu[1] += ( *lpSrc ) * nWeightX0 ;
			lpDst[i+1] = clip_ptr [( naAccu[1] + i_round ) >> i_accuracy];
			naAccu[1] = ( *lpSrc ++ ) * nWeightX1 ;

			naAccu[2] += ( *lpSrc ) * nWeightX0 ;
			lpDst[i+2] = clip_ptr [( naAccu[2] + i_round ) >> i_accuracy];
			naAccu[2] = ( *lpSrc ++ ) * nWeightX1 ;

			naAccu[3] += ( *lpSrc ) * nWeightX0 ;
			lpDst[i+3] = clip_ptr [( naAccu[3] + i_round ) >> i_accuracy];
			naAccu[3] = ( *lpSrc ++ ) * nWeightX1 ;

			i += 4;
			u ++;
		}

	} // for( x = 0; i < width; x ++ ) {

	if( u < i_dst_width ) {
		lpDst[i+0] = clip_ptr [( naAccu[0] + i_round ) >> i_accuracy];
		lpDst[i+1] = clip_ptr [( naAccu[1] + i_round ) >> i_accuracy];
		lpDst[i+2] = clip_ptr [( naAccu[2] + i_round ) >> i_accuracy];
		lpDst[i+3] = clip_ptr [( naAccu[3] + i_round ) >> i_accuracy];
	}

	return 1;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

static s32 ScaleRowCh1_C
( 
	BitmapResizer*	pCtx,
	s32				i_rear,
	u8*				lpSrc,
	s32				i_src_width,
	s32				i_src_pit,
	s32				i_src_height,
	u8*				lpDst,
	s32				i_dst_width,
	s32				i_dst_pit,
	ScaleTable*		lpScale
)
{
	s32 x,u,i;

	s32 const i_accuracy = lpScale->i_accuracy;
	s32 const i_round = 1<<(lpScale->i_accuracy-1);
	s32 const i_scale = lpScale->i_scale;

	s32*	nWeightX = 	lpScale->nWeightX;

	s32 naAccu = 0;

	u = i = 0;

	for( x = 0; x < i_src_width; x ++ ) {

		if( lpScale->b_cmpflag[x] ) {
			naAccu += ( *lpSrc ++ ) * i_scale ;
		}
		else {
			s32 const nWeightX0 = i_scale - *nWeightX;
			s32 const nWeightX1 = *nWeightX++;
			naAccu += ( *lpSrc ) * nWeightX0 ;
			lpDst[i] = clip_ptr [( naAccu + i_round ) >> i_accuracy];
			naAccu = ( *lpSrc ++ ) * nWeightX1 ;
			i ++;
			u ++;
		}
	}

	if( u < i_dst_width ) {
		lpDst[i] = clip_ptr [( naAccu + i_round ) >> i_accuracy];
	}

	return 1;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static s32 ScaleColom_C
(   
	BitmapResizer*	pCtx,
	s32				i_rear,
	u8*				lpSrc,
	s32				i_src_height,
	s32				i_src_pit,
	u8*				lpDst,
	s32				i_dst_height,
	s32				i_dst_pit,
	s32				i_dst_width,
	ScaleTable*		lpScale
)
{
	s32 x,u,i;

	s32 const i_accuracy = lpScale->i_accuracy;
	s32 const i_round = 1<<(lpScale->i_accuracy-1);
	s32 const i_scale = lpScale->i_scale;

	s32*	nWeightX = 	lpScale->nWeightX;

	s32 naAccu;

	u = i = 0;

	naAccu = 0;

	for( x = 0; x < i_src_height; x ++ ) {

		if( lpScale->b_cmpflag[x] ) {
			naAccu += ( *lpSrc ) * i_scale ;
			lpSrc += i_src_pit;
		}
		else {
			s32 const nWeightX0 = i_scale - *nWeightX;
			s32 const nWeightX1 = *nWeightX++;
			naAccu += ( *lpSrc ) * nWeightX0 ;
			*lpDst = clip_ptr [( naAccu + i_round ) >> i_accuracy];
			naAccu = ( *lpSrc ) * nWeightX1 ;
			lpSrc += i_src_pit;
			lpDst += i_dst_pit;
			i ++;
			u ++;
		}

	} // for( i = 0, k = 0; i < i_src_height; i ++ ) {


	if( u < i_dst_height ) {

		*lpDst = clip_ptr [( naAccu + i_round ) >> i_accuracy];
	}

	return 1;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static s32 ScaleRowCh3_SSE2
( 
	BitmapResizer*	pCtx,
	s32				i_rear,
	u8*				lpSrc,
	s32				i_src_width,
	s32				i_src_pit,
	s32				i_src_height,
	u8*				lpDst,
	s32				i_dst_width,
	s32				i_dst_pit,
	ScaleTable*		lpScale
)
{
	XMMI_DECLARE8;

	s32			x,u,i,i_pix;

	s32 const	i_accuracy = lpScale->i_accuracy;
	s32 const	i_round = 1<<(lpScale->i_accuracy-1);
	s32 const	i_scale = lpScale->i_scale;

	s32*		nWeightX = 	lpScale->nWeightX;

	u = i = 0;

	ixmm3 = _mm_cvtsi32_si128(i_accuracy);
	ixmm4 = _mm_cvtsi32_si128(i_round);
	ixmm5 = _mm_cvtsi32_si128(i_scale);
	ixmm4 = _mm_shuffle_epi32(ixmm4,0);
	ixmm5 = _mm_shuffle_epi32(ixmm5,0);
	ixmm6 = _mm_setzero_si128();
	ixmm7 = _mm_setzero_si128();

	for( x = 0; x < i_src_width; x ++ ) {

		if( lpScale->b_cmpflag[x] ) {
			i_pix = lpSrc[0] + (lpSrc[1]<<8) + (lpSrc[2]<<16);
			ixmm0 = _mm_cvtsi32_si128(i_pix);
			ixmm0 = _mm_unpacklo_epi8(ixmm0,ixmm6);
			ixmm0 = _mm_unpacklo_epi16(ixmm0,ixmm6);
			ixmm0 = _mm_madd_epi16(ixmm0,ixmm5);
			ixmm7 = _mm_add_epi32(ixmm7,ixmm0);
			lpSrc += 3;
		}
		else {
			s32 const nWeightX0 = i_scale - *nWeightX;
			s32 const nWeightX1 = *nWeightX++;
			ixmm0 = _mm_cvtsi32_si128(nWeightX0);
			ixmm0 = _mm_shuffle_epi32(ixmm0,0);
			i_pix = lpSrc[0] + (lpSrc[1]<<8) + (lpSrc[2]<<16);
			ixmm1 = _mm_cvtsi32_si128(i_pix);
			ixmm1 = _mm_unpacklo_epi8(ixmm1,ixmm6);
			ixmm1 = _mm_unpacklo_epi16(ixmm1,ixmm6);
			ixmm0 = _mm_madd_epi16(ixmm0,ixmm1);  //( *lpSrc ) * nWeightX0
			ixmm0 = _mm_add_epi32(ixmm0,ixmm7);   // naAccu[0] += ( *lpSrc ) * nWeightX0
			ixmm0 = _mm_add_epi32(ixmm0,ixmm4);
			ixmm0 = _mm_sra_epi32(ixmm0,ixmm3);
			ixmm0 = _mm_packs_epi32(ixmm0,ixmm6);
			ixmm0 = _mm_packus_epi16(ixmm0,ixmm6);
			i_pix = _mm_cvtsi128_si32(ixmm0);
			lpDst[i] = (u8)i_pix;
			lpDst[i+1] = (u8)(i_pix>>8);
			lpDst[i+2] = (u8)(i_pix>>16);
			ixmm7 = _mm_cvtsi32_si128(nWeightX1);
			ixmm7 = _mm_shuffle_epi32(ixmm7,0);
			ixmm7 = _mm_madd_epi16(ixmm7,ixmm1);
			lpSrc += 3;
			i += 3;
			u ++;
		}

	} // for( x = 0; i < width; x ++ ) {

	if( u < i_dst_width ) {
		ixmm7 = _mm_add_epi32(ixmm7,ixmm4);
		ixmm7 = _mm_sra_epi32(ixmm7,ixmm3);
		ixmm7 = _mm_packs_epi32(ixmm7,ixmm6);
		ixmm7 = _mm_packus_epi16(ixmm7,ixmm6);
		i_pix = _mm_cvtsi128_si32(ixmm7);
		lpDst[i] = (u8)i_pix;
		lpDst[i+1] = (u8)(i_pix>>8);
		lpDst[i+2] = (u8)(i_pix>>16);
	}

	return 1;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static s32 ScaleRowCh4_SSE2
( 
	BitmapResizer*	pCtx,
	s32				i_rear,
	u8*				lpSrc,
	s32				i_src_width,
	s32				i_src_pit,
	s32				i_src_height,
	u8*				lpDst,
	s32				i_dst_width,
	s32				i_dst_pit,
	ScaleTable*		lpScale
)
{

	XMMI_DECLARE8;

	s32			x,u,i;

	s32 const	i_accuracy = lpScale->i_accuracy;
	s32 const	i_round = 1<<(lpScale->i_accuracy-1);
	s32 const	i_scale = lpScale->i_scale;

	s32*		nWeightX = 	lpScale->nWeightX;

	u = i = 0;

	ixmm3 = _mm_cvtsi32_si128(i_accuracy);
	ixmm4 = _mm_cvtsi32_si128(i_round);
	ixmm5 = _mm_cvtsi32_si128(i_scale);
	ixmm4 = _mm_shuffle_epi32(ixmm4,0);
	ixmm5 = _mm_shuffle_epi32(ixmm5,0);
	ixmm6 = _mm_setzero_si128();
	ixmm7 = _mm_setzero_si128();

	for( x = 0; x < i_src_width; x ++ ) {

		if( lpScale->b_cmpflag[x] ) {
			ixmm0 = _mm_cvtsi32_si128(*(s32*)lpSrc);
			ixmm0 = _mm_unpacklo_epi8(ixmm0,ixmm6);
			ixmm0 = _mm_unpacklo_epi16(ixmm0,ixmm6);
			ixmm0 = _mm_madd_epi16(ixmm0,ixmm5);
			ixmm7 = _mm_add_epi32(ixmm7,ixmm0);
			lpSrc += 4;
		}
		else {
			s32 const nWeightX0 = i_scale - *nWeightX;
			s32 const nWeightX1 = *nWeightX++;
			ixmm0 = _mm_cvtsi32_si128(nWeightX0);
			ixmm0 = _mm_shuffle_epi32(ixmm0,0);
			ixmm1 = _mm_cvtsi32_si128(*(s32*)lpSrc);
			ixmm1 = _mm_unpacklo_epi8(ixmm1,ixmm6);
			ixmm1 = _mm_unpacklo_epi16(ixmm1,ixmm6);
			ixmm0 = _mm_madd_epi16(ixmm0,ixmm1);  //( *lpSrc ) * nWeightX0
			ixmm0 = _mm_add_epi32(ixmm0,ixmm7);   // naAccu[0] += ( *lpSrc ) * nWeightX0
			ixmm0 = _mm_add_epi32(ixmm0,ixmm4);
			ixmm0 = _mm_sra_epi32(ixmm0,ixmm3);
			ixmm0 = _mm_packs_epi32(ixmm0,ixmm6);
			ixmm0 = _mm_packus_epi16(ixmm0,ixmm6);
			*(s32*)(lpDst+i) = _mm_cvtsi128_si32(ixmm0);
			ixmm7 = _mm_cvtsi32_si128(nWeightX1);
			ixmm7 = _mm_shuffle_epi32(ixmm7,0);
			ixmm7 = _mm_madd_epi16(ixmm7,ixmm1);
			lpSrc += 4;
			i += 4;
			u ++;
		}

	} // for( x = 0; i < width; x ++ ) {

	if( u < i_dst_width ) {
		ixmm7 = _mm_add_epi32(ixmm7,ixmm4);
		ixmm7 = _mm_sra_epi32(ixmm7,ixmm3);
		ixmm7 = _mm_packs_epi32(ixmm7,ixmm6);
		ixmm7 = _mm_packus_epi16(ixmm7,ixmm6);
		*(s32*)(lpDst+i) = _mm_cvtsi128_si32(ixmm7);
	}

	return 1;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
c		1 rows, 1 col,fast divide,	average time: 2370 u second 
c		1 rows, 1 col,no divide,	average time: 1365 u second
sse2	4 rows, 4 col,no divide,	average time: 570 u second 
sse2	4 rows, 8 col,no divide,	average time: 508 u second 
sse2	8 rows, 8 col,no divide,	average time: 413 u second 
***************************************************************************/
static s32 ScaleRowCh1_SSE2
( 
	BitmapResizer*	pCtx,
	s32				i_rear,
	u8*				lpSrc,
	s32				i_src_width,
	s32				i_src_pit,
	s32				i_src_height,
	u8*				lpDst,
	s32				i_dst_width,
	s32				i_dst_pit,
	ScaleTable*		lpScale
)
{
	if( i_rear < 8 ) {
		return ScaleRowCh1_C(pCtx,i_rear,lpSrc,i_src_width,i_src_pit,i_src_height,lpDst,i_dst_width,i_dst_pit,lpScale);
	}
	else{
		XMMI_DECLARE8;

		s32			x,u,i,i_pix;

		s32 const	i_accuracy = lpScale->i_accuracy;
		s32 const	i_round = 1<<(lpScale->i_accuracy-1);
		s32 const	i_scale = lpScale->i_scale;

		s32 const   i_src_pit2 = i_src_pit*2;
		s32 const   i_src_pit3 = i_src_pit*3;
		s32 const   i_src_pit4 = i_src_pit*4;
		s32 const   i_dst_pit2 = i_dst_pit*2;
		s32 const   i_dst_pit3 = i_dst_pit*3;
		s32 const   i_dst_pit4 = i_dst_pit*4;

		s32*		nWeightX = 	lpScale->nWeightX;

		u = i = 0;

		ixmm4 = _mm_cvtsi32_si128(i_round);
		ixmm4 = _mm_shuffle_epi32(ixmm4,0);

		ixmm6 = _mm_setzero_si128();
		ixmm3 = _mm_setzero_si128();
		ixmm7 = _mm_setzero_si128();

		for( x = 0; x < i_src_width; x ++ ) {

			if( lpScale->b_cmpflag[x] ) {
				ixmm5 = _mm_cvtsi32_si128(i_scale);
				ixmm5 = _mm_shuffle_epi32(ixmm5,0);
				i_pix = *lpSrc + (*(lpSrc+i_src_pit)<<8) + (*(lpSrc+i_src_pit2)<<16) + (*(lpSrc+i_src_pit3)<<24);
				lpSrc += i_src_pit4;
				ixmm0 = _mm_cvtsi32_si128(i_pix);
				ixmm0 = _mm_unpacklo_epi8(ixmm0,ixmm6);
				ixmm0 = _mm_unpacklo_epi16(ixmm0,ixmm6);
				ixmm0 = _mm_madd_epi16(ixmm0,ixmm5);
				ixmm7 = _mm_add_epi32(ixmm7,ixmm0);
				i_pix = *lpSrc + (*(lpSrc+i_src_pit)<<8) + (*(lpSrc+i_src_pit2)<<16) + (*(lpSrc+i_src_pit3)<<24);
				lpSrc -= i_src_pit4;
				ixmm0 = _mm_cvtsi32_si128(i_pix);
				ixmm0 = _mm_unpacklo_epi8(ixmm0,ixmm6);
				ixmm0 = _mm_unpacklo_epi16(ixmm0,ixmm6);
				ixmm0 = _mm_madd_epi16(ixmm0,ixmm5);
				ixmm3 = _mm_add_epi32(ixmm3,ixmm0);
				lpSrc ++;
			}
			else {
				s32 const nWeightX0 = i_scale - *nWeightX;
				s32 const nWeightX1 = *nWeightX++;
				ixmm5 = _mm_cvtsi32_si128(i_accuracy);

				ixmm0 = _mm_cvtsi32_si128(nWeightX0);
				ixmm0 = _mm_shuffle_epi32(ixmm0,0);
				i_pix = *lpSrc + (*(lpSrc+i_src_pit)<<8) + (*(lpSrc+i_src_pit2)<<16) + (*(lpSrc+i_src_pit3)<<24);
				lpSrc += i_src_pit4;
				ixmm1 = _mm_cvtsi32_si128(i_pix);
				ixmm1 = _mm_unpacklo_epi8(ixmm1,ixmm6);
				ixmm1 = _mm_unpacklo_epi16(ixmm1,ixmm6);
				ixmm0 = _mm_madd_epi16(ixmm0,ixmm1);  //( *lpSrc ) * nWeightX0
				ixmm0 = _mm_add_epi32(ixmm0,ixmm7);   // naAccu[0] += ( *lpSrc ) * nWeightX0
				ixmm0 = _mm_add_epi32(ixmm0,ixmm4);
				ixmm0 = _mm_sra_epi32(ixmm0,ixmm5);
				ixmm0 = _mm_packs_epi32(ixmm0,ixmm6);
				ixmm0 = _mm_packus_epi16(ixmm0,ixmm6);
				i_pix = _mm_cvtsi128_si32(ixmm0);
				lpDst[0] = (u8)i_pix;
				lpDst[i_dst_pit] = (u8)(i_pix>>8);
				lpDst[i_dst_pit2] = (u8)(i_pix>>16);
				lpDst[i_dst_pit3] = (u8)(i_pix>>24);
				lpDst += i_dst_pit4;
				ixmm7 = _mm_cvtsi32_si128(nWeightX1);
				ixmm7 = _mm_shuffle_epi32(ixmm7,0);
				ixmm7 = _mm_madd_epi16(ixmm7,ixmm1);

				ixmm0 = _mm_cvtsi32_si128(nWeightX0);
				ixmm0 = _mm_shuffle_epi32(ixmm0,0);
				i_pix = *lpSrc + (*(lpSrc+i_src_pit)<<8) + (*(lpSrc+i_src_pit2)<<16) + (*(lpSrc+i_src_pit3)<<24);
				lpSrc -= i_src_pit4;
				ixmm1 = _mm_cvtsi32_si128(i_pix);
				ixmm1 = _mm_unpacklo_epi8(ixmm1,ixmm6);
				ixmm1 = _mm_unpacklo_epi16(ixmm1,ixmm6);
				ixmm0 = _mm_madd_epi16(ixmm0,ixmm1);  //( *lpSrc ) * nWeightX0
				ixmm0 = _mm_add_epi32(ixmm0,ixmm3);   // naAccu[0] += ( *lpSrc ) * nWeightX0
				ixmm0 = _mm_add_epi32(ixmm0,ixmm4);
				ixmm0 = _mm_sra_epi32(ixmm0,ixmm5);
				ixmm0 = _mm_packs_epi32(ixmm0,ixmm6);
				ixmm0 = _mm_packus_epi16(ixmm0,ixmm6);
				i_pix = _mm_cvtsi128_si32(ixmm0);
				lpDst[0] = (u8)i_pix;
				lpDst[i_dst_pit] = (u8)(i_pix>>8);
				lpDst[i_dst_pit2] = (u8)(i_pix>>16);
				lpDst[i_dst_pit3] = (u8)(i_pix>>24);
				lpDst -= i_dst_pit4;
				ixmm3 = _mm_cvtsi32_si128(nWeightX1);
				ixmm3 = _mm_shuffle_epi32(ixmm3,0);
				ixmm3 = _mm_madd_epi16(ixmm3,ixmm1);

				lpSrc ++;
				lpDst ++;
				i ++;
				u ++;
			}

		} // for( x = 0; i < i_src_width; x ++ ) {

		if( u < i_dst_width ) {
			ixmm5 = _mm_cvtsi32_si128(i_accuracy);
			ixmm7 = _mm_add_epi32(ixmm7,ixmm4);
			ixmm7 = _mm_sra_epi32(ixmm7,ixmm5);
			ixmm7 = _mm_packs_epi32(ixmm7,ixmm6);
			ixmm7 = _mm_packus_epi16(ixmm7,ixmm6);
			i_pix = _mm_cvtsi128_si32(ixmm7);
			lpDst[0] = (u8)i_pix;
			lpDst[i_dst_pit] = (u8)(i_pix>>8);
			lpDst[i_dst_pit2] = (u8)(i_pix>>16);
			lpDst[i_dst_pit3] = (u8)(i_pix>>24);
			lpDst += i_dst_pit4;
			ixmm3 = _mm_add_epi32(ixmm3,ixmm4);
			ixmm3 = _mm_sra_epi32(ixmm3,ixmm5);
			ixmm3 = _mm_packs_epi32(ixmm3,ixmm6);
			ixmm3 = _mm_packus_epi16(ixmm3,ixmm6);
			i_pix = _mm_cvtsi128_si32(ixmm3);
			lpDst[0] = (u8)i_pix;
			lpDst[i_dst_pit] = (u8)(i_pix>>8);
			lpDst[i_dst_pit2] = (u8)(i_pix>>16);
			lpDst[i_dst_pit3] = (u8)(i_pix>>24);
		}

		return 8;
	}
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static s32 ScaleColom_SSE2
(   
	BitmapResizer*	pCtx,
	s32				i_rear,
	u8*				lpSrc,
	s32				i_src_height,
	s32				i_src_pit,
	u8*				lpDst,
	s32				i_dst_height,
	s32				i_dst_pit,
	s32				i_dst_width,
	ScaleTable*		lpScale
)
{
	if( i_rear < 4 ) {

		return ScaleColom_C(pCtx,i_rear,lpSrc,i_src_height,i_src_pit,lpDst,i_dst_height,i_dst_pit,i_dst_width,lpScale);
	}
	else {
		
		XMMI_DECLARE8;

		s32			x,u,i;

		s32 const	i_accuracy = lpScale->i_accuracy;
		s32 const	i_round = 1<<(lpScale->i_accuracy-1);
		s32 const	i_scale = lpScale->i_scale;

		s32*		nWeightX = 	lpScale->nWeightX;

		u = i = 0;

		if( i_rear < 8){

			ixmm3 = _mm_cvtsi32_si128(i_accuracy);
			ixmm4 = _mm_cvtsi32_si128(i_round);
			ixmm5 = _mm_cvtsi32_si128(i_scale);
			ixmm4 = _mm_shuffle_epi32(ixmm4,0);
			ixmm5 = _mm_shuffle_epi32(ixmm5,0);
			ixmm6 = _mm_setzero_si128();
			ixmm7 = _mm_setzero_si128();

			for( x = 0; x < i_src_height; x ++ ) {

				if( lpScale->b_cmpflag[x] ) {
					ixmm0 = _mm_cvtsi32_si128(*(s32*)lpSrc);
					ixmm0 = _mm_unpacklo_epi8(ixmm0,ixmm6);
					ixmm0 = _mm_unpacklo_epi16(ixmm0,ixmm6);
					ixmm0 = _mm_madd_epi16(ixmm0,ixmm5);
					ixmm7 = _mm_add_epi32(ixmm7,ixmm0);
					lpSrc += i_src_pit;
				}
				else {
					s32 const nWeightX0 = i_scale - *nWeightX;
					s32 const nWeightX1 = *nWeightX++;
					ixmm0 = _mm_cvtsi32_si128(nWeightX0);
					ixmm0 = _mm_shuffle_epi32(ixmm0,0);
					ixmm1 = _mm_cvtsi32_si128(*(s32*)lpSrc);
					ixmm1 = _mm_unpacklo_epi8(ixmm1,ixmm6);
					ixmm1 = _mm_unpacklo_epi16(ixmm1,ixmm6);
					ixmm0 = _mm_madd_epi16(ixmm0,ixmm1);  //( *lpSrc ) * nWeightX0
					ixmm0 = _mm_add_epi32(ixmm0,ixmm7);   // naAccu[0] += ( *lpSrc ) * nWeightX0
					ixmm0 = _mm_add_epi32(ixmm0,ixmm4);
					ixmm0 = _mm_sra_epi32(ixmm0,ixmm3);
					ixmm0 = _mm_packs_epi32(ixmm0,ixmm6);
					ixmm0 = _mm_packus_epi16(ixmm0,ixmm6);
					*(s32*)(lpDst) = _mm_cvtsi128_si32(ixmm0);
					ixmm7 = _mm_cvtsi32_si128(nWeightX1);
					ixmm7 = _mm_shuffle_epi32(ixmm7,0);
					ixmm7 = _mm_madd_epi16(ixmm7,ixmm1);
					lpSrc += i_src_pit;
					lpDst += i_dst_pit;
					i ++;
					u ++;
				}

			} // for( x = 0; i < i_src_height; x ++ ) {

			if( u < i_dst_height ) {
				ixmm7 = _mm_add_epi32(ixmm7,ixmm4);
				ixmm7 = _mm_sra_epi32(ixmm7,ixmm3);
				ixmm7 = _mm_packs_epi32(ixmm7,ixmm6);
				ixmm7 = _mm_packus_epi16(ixmm7,ixmm6);
				*(s32*)(lpDst) = _mm_cvtsi128_si32(ixmm7);
			}

			return 4;

		} // if( i_rear < 8){
		else{

			ixmm6 = _mm_setzero_si128();
			ixmm3 = _mm_setzero_si128();
			ixmm7 = _mm_setzero_si128();

			for( x = 0; x < i_src_height; x ++ ) {

				if( lpScale->b_cmpflag[x] ) {
					ixmm0 = _mm_loadl_epi64(CONV_PXMMI(lpSrc));
					ixmm0 = _mm_unpacklo_epi8(ixmm0,ixmm6);
					ixmm1 = ixmm0;
					ixmm0 = _mm_unpacklo_epi16(ixmm0,ixmm6);
					ixmm1 = _mm_unpackhi_epi16(ixmm1,ixmm6);
					ixmm5 = _mm_cvtsi32_si128(i_scale);
					ixmm5 = _mm_shuffle_epi32(ixmm5,0);
					ixmm0 = _mm_madd_epi16(ixmm0,ixmm5);
					ixmm1 = _mm_madd_epi16(ixmm1,ixmm5);
					ixmm7 = _mm_add_epi32(ixmm7,ixmm0);
					ixmm3 = _mm_add_epi32(ixmm3,ixmm1);
					lpSrc += i_src_pit;
				}
				else {
					s32 const nWeightX0 = i_scale - *nWeightX;
					s32 const nWeightX1 = *nWeightX++;
					ixmm0 = _mm_cvtsi32_si128(nWeightX0);
					ixmm0 = _mm_shuffle_epi32(ixmm0,0);
					ixmm1 = _mm_loadl_epi64(CONV_PXMMI(lpSrc));
					ixmm1 = _mm_unpacklo_epi8(ixmm1,ixmm6);
					ixmm2 = ixmm1;
					ixmm1 = _mm_unpacklo_epi16(ixmm1,ixmm6);
					ixmm2 = _mm_unpackhi_epi16(ixmm2,ixmm6);
					ixmm5 = ixmm0;
					ixmm0 = _mm_madd_epi16(ixmm0,ixmm1);  //( *lpSrc ) * nWeightX0
					ixmm5 = _mm_madd_epi16(ixmm5,ixmm2);  //( *lpSrc ) * nWeightX0
					ixmm0 = _mm_add_epi32(ixmm0,ixmm7);   // naAccu[0] += ( *lpSrc ) * nWeightX0
					ixmm5 = _mm_add_epi32(ixmm5,ixmm3);   // naAccu[0] += ( *lpSrc ) * nWeightX0
					ixmm4 = _mm_cvtsi32_si128(i_round);
					ixmm4 = _mm_shuffle_epi32(ixmm4,0);
					ixmm0 = _mm_add_epi32(ixmm0,ixmm4);
					ixmm5 = _mm_add_epi32(ixmm5,ixmm4);
					ixmm4 = _mm_cvtsi32_si128(i_accuracy);
					ixmm0 = _mm_sra_epi32(ixmm0,ixmm4);
					ixmm5 = _mm_sra_epi32(ixmm5,ixmm4);
					ixmm0 = _mm_packs_epi32(ixmm0,ixmm5);
					ixmm0 = _mm_packus_epi16(ixmm0,ixmm6);
					_mm_storel_epi64(CONV_PXMMI(lpDst),ixmm0);
					ixmm7 = _mm_cvtsi32_si128(nWeightX1);
					ixmm7 = _mm_shuffle_epi32(ixmm7,0);
					ixmm3 = ixmm7;
					ixmm7 = _mm_madd_epi16(ixmm7,ixmm1);
					ixmm3 = _mm_madd_epi16(ixmm3,ixmm2);
					lpSrc += i_src_pit;
					lpDst += i_dst_pit;
					i ++;
					u ++;
				}

			} // for( x = 0; i < i_src_height; x ++ ) {

			if( u < i_dst_height ) {
				ixmm4 = _mm_cvtsi32_si128(i_round);
				ixmm4 = _mm_shuffle_epi32(ixmm4,0);
				ixmm7 = _mm_add_epi32(ixmm7,ixmm4);
				ixmm3 = _mm_add_epi32(ixmm3,ixmm4);
				ixmm4 = _mm_cvtsi32_si128(i_accuracy);
				ixmm7 = _mm_sra_epi32(ixmm7,ixmm4);
				ixmm3 = _mm_sra_epi32(ixmm3,ixmm4);
				ixmm7 = _mm_packs_epi32(ixmm7,ixmm3);
				ixmm7 = _mm_packus_epi16(ixmm7,ixmm6);
				_mm_storel_epi64(CONV_PXMMI(lpDst),ixmm7);
			}

			return 8;

		} // if( i_rear < 8){ ...} else {

	} // if( i_rear < 4 ){...}else{

}

