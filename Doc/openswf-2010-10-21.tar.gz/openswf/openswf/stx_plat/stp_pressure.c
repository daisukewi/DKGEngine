/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/
#include "stdio.h"
#include "stdlib.h"
#include "fcntl.h"
#include "malloc.h"
#include "memory.h"
#include "string.h"


#include "stx_mutex.h"
#include "stx_mem.h"
#include "stx_debug.h"
#include "stx_io_stream.h"
#include "stx_io_interleaved.h"


#include "stx_all.h"
#include "stx_stack.h"
#include "stx_sync_source.h"

#include "stp_client.h"
#include "stp_pressure.h"

#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif

#define PRS_KEY_IP				"IP"
#define PRS_KEY_PORT			"port"
#define PRS_KEY_GRAPH			"graph"
#define PRS_KEY_CONNECTION		"connection"
#define PRS_KEY_URL				"URL"




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT	set_prs_server(stx_xini* h_xini,char* sz_ip,u16 i_port)
{
	STX_RESULT i_err;

	STX_HANDLE h_key;

	i_err =  h_xini->create_key(h_xini,NULL,PRS_KEY_IP,sz_ip,&h_key);
	if( STX_OK != i_err ) {
		return i_err;
	}

	i_err = h_xini->create_key(h_xini,NULL,PRS_KEY_PORT,"0",&h_key);
	if( STX_OK != i_err ) {
		return i_err;
	}

	return h_xini->write_int32(h_xini,h_key,i_port);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT set_prs_graph(stx_xini* h_xini,char* sz_graph)
{
	STX_HANDLE h_key;

	return h_xini->create_key(h_xini,NULL,PRS_KEY_GRAPH,sz_graph,&h_key);
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT set_prs_connection(stx_xini* h_xini,s32 i_connum)
{
	STX_RESULT i_err;

	STX_HANDLE h_key;

	i_err = h_xini->create_key(h_xini,NULL,PRS_KEY_CONNECTION,"0",&h_key);
	if( STX_OK != i_err ) {
		return i_err;
	}
	
	return h_xini->write_int32(h_xini,h_key,i_connum);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT add_prs_url(stx_xini* h_xini,char* sz_url)
{
	STX_RESULT	i_err;
	s32			i_subkey;
	STX_HANDLE	h_key,h_subkey;
	char		sz_key[128];

	i_err = h_xini->create_key(h_xini,NULL,PRS_KEY_URL,"0",&h_key);
	if( STX_OK != i_err ) {
		return i_err;
	}

	i_err = h_xini->get_sub_key_num(h_xini,h_key,&i_subkey);
	if( STX_OK != i_err ) {
		return i_err;
	}

	stx_sprintf(sz_key,sizeof(sz_key),"%s-%d",PRS_KEY_URL,i_subkey);

	i_err = h_xini->create_key(h_xini,h_key,sz_key,"0",&h_subkey);
	if( STX_OK != i_err ) {
		return i_err;
	}

	return h_xini->write_base64(h_xini,h_subkey,(s32)strlen(sz_url) + 1, (u8*)sz_url);
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT  get_prs_server(stx_xini* h_xini,char** sz_ip,u16* i_port)
{
	STX_RESULT	i_err;
	STX_HANDLE	h_key;
	s32			i_p32;

	i_err = h_xini->create_key(h_xini,NULL,PRS_KEY_IP,NULL,&h_key);
	if( STX_OK != i_err ) {
		return i_err;
	}

	i_err = h_xini->read_string(h_xini,h_key,sz_ip);
	if( STX_OK != i_err ) {
		return i_err;
	}

	i_err = h_xini->create_key(h_xini,NULL,PRS_KEY_PORT,"0",&h_key);
	if( STX_OK != i_err ) {
		return i_err;
	}

	i_err = h_xini->read_int32(h_xini,h_key,&i_p32);
	if( STX_OK != i_err ) {
		return i_err;
	}

	*i_port = (u16)i_p32;

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
char* get_prs_graph(stx_xini* h_xini)
{
	STX_RESULT	i_err;
	STX_HANDLE	h_key;
	char*		sz_graph;

	i_err = h_xini->create_key(h_xini,NULL,PRS_KEY_GRAPH,NULL,&h_key);
	if( STX_OK != i_err ) {
		return NULL;
	}

	i_err = h_xini->read_string(h_xini,h_key,&sz_graph);
	if( STX_OK != i_err ) {
		return NULL;
	}

	return sz_graph;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
s32 get_prs_connection(stx_xini* h_xini)
{
	STX_RESULT	i_err;
	STX_HANDLE	h_key;
	s32			i_connum;

	i_err = h_xini->create_key(h_xini,NULL,PRS_KEY_CONNECTION,NULL,&h_key);
	if( STX_OK != i_err ) {
		return -1;
	}

	i_err = h_xini->read_int32(h_xini,h_key,&i_connum);
	if( STX_OK != i_err ) {
		return -1;
	}

	return i_connum;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
s32 get_prs_url_num(stx_xini* h_xini)
{
	STX_RESULT	i_err;
	STX_HANDLE	h_key;
	s32			i_num;

	i_err = h_xini->create_key(h_xini,NULL,PRS_KEY_URL,NULL,&h_key);
	if( STX_OK != i_err ) {
		return -1;
	}

	i_err = h_xini->get_sub_key_num(h_xini,h_key,&i_num);
	if( STX_OK != i_err ) {
		return -1;
	}

	return i_num;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
char* get_prs_url(stx_xini* h_xini, s32 i_index)
{
	STX_RESULT	i_err;
	STX_HANDLE	h_key,h_subkey;
	s32			i_size;
	char*		sz_url;

	i_err = h_xini->create_key(h_xini,NULL,PRS_KEY_URL,NULL,&h_key);
	if( STX_OK != i_err ) {
		return NULL;
	}

	i_err = h_xini->get_sub_key(h_xini,h_key,i_index,&h_subkey);
	if( STX_OK != i_err ) {
		return NULL;
	}

	i_err = h_xini->read_base64(h_xini,h_subkey,&i_size,NULL);
	if( STX_OK != i_err ) {
		return NULL;
	}

	sz_url = xmallocz(i_size);
	if( !sz_url ) {
		return NULL;
	}

	i_err = h_xini->read_base64(h_xini,h_subkey,&i_size,sz_url);
	if( STX_OK != i_err ) {
		stx_free(sz_url);
		return NULL;
	}

	return sz_url;
}




// {40D91D98-280F-4559-8056-9C1CAC3FC42E}
DEFINE_XGUID( STX_CLSID_StpPressure,
0x40d91d98, 0x280f, 0x4559, 0x80, 0x56, 0x9c, 0x1c, 0xac, 0x3f, 0xc4, 0x2e);

char* g_szStreamX_StpPressure = "StreamX Stp Pressure Test Plugin";




STX_INPUT_MEDIA_TYPE_MAP_BEGIN(stp_pressure)
/**/MEDIA_TYPE_MAP_ITEM(STX_GID_NULL,STX_GID_NULL)
STX_INPUT_MEDIA_TYPE_MAP_END()


STX_OUTPUT_MEDIA_TYPE_MAP_BEGIN(stp_pressure)
/**/MEDIA_TYPE_MAP_ITEM(STX_GID_NULL,STX_GID_NULL)
STX_OUTPUT_MEDIA_TYPE_MAP_END()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API_IMP 
CREATE_STX_COM(stx_stream_writer,STX_IID_FileWriter,stp_pressure);


STX_INTERF(stp_client_ctx);
struct stp_client_ctx{
	stx_xio*			h_stp;
	s64					i_file_time;
	s64					i_file_size;
	s64					i_download_size;
	s32					i_bit_rate;
	s32					i_cur_rate;
	s32					i_status;
	THEE				h_stat;
	s64					i_last_time;
};

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_COM_BEGIN(stp_pressure);
/**/
/* base source; */
/**/STX_PUBLIC( stx_base_source )
/**/
/* base filter; */
/**/STX_PUBLIC( stx_stream_writer)
/**/STX_COM_DATA_DEFAULT(stx_stream_writer)
/**/
/* base graph control;*/
/**/STX_PUBLIC( stx_base_control)
/**/
/* base media information; */
/**/STX_PUBLIC( stx_media_info)
/**/
/**/THEE				h_mutex;
/**/THEE				h_stack;
/**/THEE				h_stop[2];
/**/THEE				h_task;
/**/char*				sz_ip;		//
/**/u16					i_port;		//
/**/char*				sz_graph;	// graph file;
/**/s32					i_instance;
/**/s32					i_url;
/**/char**				sz_url;		// stream file url;
/**/b32					b_stop;
/**/stp_client_ctx*		h_client;
/**/s64					i_last_time;
/**/
STX_COM_END();


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_COM_FUNC_DECL_DEFAULT(stx_media_info,stx_media_info_vt);
STX_COM_FUNC_DECL_DEFAULT(stx_base_control,stx_base_control_vt);
STX_COM_FUNC_DECL_DEFAULT(stx_stream_writer,stx_stream_writer_vt);
STX_COM_FUNC_DECL_DEFAULT(stx_base_source,stx_base_source_vt);

STX_COM_FUNCIMP_DEFAULT(stp_pressure,stx_media_info,stx_media_info_vt);
STX_COM_FUNCIMP_DEFAULT(stp_pressure,stx_base_control,stx_base_control_vt);
STX_COM_FUNCIMP_DEFAULT(stp_pressure,stx_stream_writer,stx_stream_writer_vt);
STX_COM_FUNCIMP_DEFAULT(stp_pressure,stx_base_source,stx_base_source_vt);



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

/*{{{STX_MSG_ENTRY_DECLARE**************************************************/
/* to do : add msg proc entry  declaration here; */
/**/STX_MSG_ENTRY_DECLARE(on_play)
/**/STX_MSG_ENTRY_DECLARE(on_pause)
/**/STX_MSG_ENTRY_DECLARE(on_resume)
/**/STX_MSG_ENTRY_DECLARE(on_stop)
/**/STX_MSG_ENTRY_DECLARE(at_BreakPin)
/**/STX_MSG_ENTRY_DECLARE(at_play)
/**/STX_MSG_ENTRY_DECLARE(at_pause)
/**/STX_MSG_ENTRY_DECLARE(at_resume)
/**/STX_MSG_ENTRY_DECLARE(at_stop)
/**/STX_MSG_ENTRY_DECLARE(on_auto_stop)
/**/STX_MSG_ENTRY_DECLARE(on_app_stop)
/*}}}***********************************************************************/



/*{{{STX_BEGIN_MSG_MAP******************************************************/
STX_BEGIN_MSG_MAP(the_msg_data)
/* to do : add msg proc entry name here; */
/**/ON_STX_MSG(STX_MSG_Play,on_play)
/**/ON_STX_MSG(STX_MSG_Pause,on_pause)
/**/ON_STX_MSG(STX_MSG_Resume,on_resume)
/**/ON_STX_MSG(STX_MSG_Stop,on_stop)
/**/ON_STX_MSG(STX_MSG_AutoStop,on_auto_stop)
/**/ON_STX_MSG(STX_MSG_AppStop,on_app_stop)
STX_END_MSG_MAP
/*}}}***********************************************************************/


/*{{{STX_BEGIN_MSG_RESPONSE_MAP*********************************************/
STX_BEGIN_MSG_RESPONSE_MAP(the_msg_response)
/**//* to do : add msg process entry name here; */
/**/ON_STX_MSG(STX_MSG_Play,at_play)
/**/ON_STX_MSG(STX_MSG_Pause,at_pause)
/**/ON_STX_MSG(STX_MSG_Resume,at_resume)
/**/ON_STX_MSG(STX_MSG_Stop,at_stop)
/**/ON_STX_MSG(STX_MSG_BreakPin,at_BreakPin)
STX_END_MSG_RESPONSE_MAP
/*}}}***********************************************************************/


/*{{{STX_DISPATHCH_MSG_PROC*************************************************/
STX_DISPATCH_MSG_PROC( dispatch_msg,the_msg_data )
/*}}}***********************************************************************/


/*{{{STX_RESPONSE_MSG_PROC**************************************************/
STX_RESPONSE_MSG_PROC( response_msg,the_msg_response )
/*}}}***********************************************************************/


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT run_proc ( stp_pressure* the , stx_sync_inf* h_sync );
STX_PRIVATE STX_RESULT stop_proc ( stp_pressure* the);



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_COM_MAP_BEGIN(stp_pressure)
/**/STX_COM_MAP_ITEM(STX_IID_FileSource)
/**/STX_COM_MAP_ITEM(STX_IID_FileWriter)
/**/STX_COM_MAP_ITEM(STX_IID_BaseControl)
/**/STX_COM_MAP_ITEM(STX_IID_MediaInfo)
STX_COM_MAP_END()


STX_API_IMP	STX_NEW_BEGIN(stp_pressure)
{
	STX_SET_THE(stx_base_source);
	STX_COM_NEW_DEFAULT(stx_base_source,the->stx_base_source_vt,stx_base_source_vt,
		STX_CLSID_StpPressure,STX_CATEGORY_FileSource,g_szStreamX_StpPressure);

	STX_SET_THE(stx_stream_writer);
	STX_COM_NEW_DEFAULT(stx_stream_writer,the->stx_stream_writer_vt,stx_stream_writer_vt,
		STX_CLSID_StpPressure,STX_CATEGORY_FileWriter,g_szStreamX_StpPressure);

	STX_SET_THE(stx_base_control);
	STX_COM_NEW_DEFAULT(stx_base_control,the->stx_base_control_vt,stx_base_control_vt,
		STX_CLSID_StpPressure,STX_CATEGORY_FileSource,g_szStreamX_StpPressure);

	STX_SET_THE(stx_media_info);
	STX_COM_NEW_DEFAULT(stx_media_info,the->stx_media_info_vt,stx_media_info_vt,
		STX_CLSID_StpPressure,STX_CATEGORY_FileSource,g_szStreamX_StpPressure);

	the->h_stack = stx_stack_create();
	if( !the->h_stack ) {
		break;
	}
	the->h_mutex = stx_create_mutex(NULL,0,NULL);
	if( !the->h_mutex ) {
		break;
	}

}
STX_NEW_END()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_QUERY_BEGIN(stp_pressure)
{
	STX_COM_QUERY_DEFAULT(stx_base_source,the->stx_base_source_vt);
	STX_COM_QUERY_DEFAULT(stx_stream_writer,the->stx_stream_writer_vt);
	STX_COM_QUERY_DEFAULT(stx_base_control,the->stx_base_control_vt);
	STX_COM_QUERY_DEFAULT(stx_media_info,the->stx_media_info_vt);
}
STX_QUERY_END()



/***************************************************************************
STX_PURE sint32 flv_release(STX_HANDLE h)
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_DELETE_BEGIN(stp_pressure)
{
	/* todo : release object; */
	{
		stx_base_source* const src = &the->stx_base_source_vt;
		src->close_stream(src);
	}
	{
		s32 i;
		for( i = 0; i < 2; i ++ ) {
			if( the->h_stop[i] ) {
				stx_stack_close(the->h_stop[i]);
			}
		}
	}

	if( the->h_stack ) {
		stx_stack_close(the->h_stack);
	}

	if( the->h_mutex ) {
		stx_close_mutex(the->h_mutex);
	}

	STX_COM_DELETE_DEFAULT(stx_stream_writer);
}
STX_DELETE_END
(
STX_COM_DELETE_BEGIN(stx_stream_writer)
,
STX_COM_DELETE_END(stx_stream_writer)
)




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE void stx_base_source_vt_xxx_close_stream(STX_HANDLE h)
{
	STX_MAP_THE(stp_pressure);
	{
		if( the->sz_graph ) {
			stx_free(the->sz_graph);
			the->sz_graph = NULL;
		}

		if( the->sz_ip ) {
			stx_free(the->sz_ip);
			the->sz_ip = NULL;
		}

		if( the->sz_url ) {
			s32 i;
			for( i = 0; i < the->i_url; i ++ ) {
				if( the->sz_url[i] ) {
					stx_free(the->sz_url[i]);
				}
			}
			stx_free(the->sz_url);
			the->sz_url = NULL;
		}
	}
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_source_vt_xxx_load_stream
(THEE h, const char* sz_stream,stx_sync_inf* h_sync )
{
	STX_MAP_THE(stp_pressure);
	{
		STX_RESULT	i_err;
		s32			i;
		stx_xini*	h_xini;
		char*		sz_ip;


		do{

			// parse .prs file;
			h_xini = NULL;

			i_err = stx_ini_create((char*)sz_stream,NULL,STX_INI_READ_ONLY,0,&h_xini);
			if( STX_OK != i_err ) {
				break;
			}

			// server ip, port;
			i_err = get_prs_server(h_xini,&sz_ip,&the->i_port);
			if( STX_OK != i_err ) {
				break;
			}

			the->sz_ip = xstrdup(sz_ip);
			if( !the->sz_ip) {
				i_err = STX_FAIL;
				break;
			}

			// graph;
			sz_ip = get_prs_graph(h_xini);
			if( !sz_ip) {
				i_err = STX_FAIL;
				break;
			}

			the->sz_graph = xstrdup(sz_ip);
			if( !the->sz_graph) {
				i_err = STX_FAIL;
				break;
			}

			// connection;
			the->i_instance = get_prs_connection(h_xini);
			if( the->i_instance < 1 ) {
				the->i_instance = 1;
			}
			else if( the->i_instance > 1024 ) {
				the->i_instance = 1024;
			}

			// url;
			the->i_url = get_prs_url_num(h_xini);
			if( the->i_url < 1 ) {
				i_err = STX_ERR_INVALID_PARAM;
				break;
			}

			the->sz_url = (char**)xmallocz( sizeof(char*)*the->i_url );
			if( !the->sz_url){
				i_err = STX_FAIL;
				break;
			}

			for( i = 0; i < the->i_url; i ++ ) {

				the->sz_url[i] = get_prs_url(h_xini,i);
				if( !the->sz_url[i] ) {
					break;
				}
			}
			if( i < the->i_url ) {
				i_err = STX_FAIL;
				break;
			}

			i_err = STX_OK;

		}while(FALSE);

		SAFE_CLOSEXIO(h_xini);

		return i_err;

	}
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_stream_writer_vt_flt_plug_xxx_run
( THEE h , stx_sync_inf* h_sync )
{
	STX_RESULT i_err;

	STX_MAP_THE(stp_pressure);

	stx_waitfor_mutex(the->h_mutex,INFINITE);

	i_err = run_proc(the,h_sync);

	stx_release_mutex(the->h_mutex);

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT run_proc ( stp_pressure* the , stx_sync_inf* h_sync )
{
	STX_RESULT		i_err;
	s32				i;
	s32				i_status;
	stx_xio*		h_stp;
	s64				i_next_time;
	s64				i_time,i_rate;
	s32				i_idle,i_stop;
	char			buf[2048];

	i_idle = 0;
	i_next_time = 2;

	for( i = 0; i < the->i_instance; i ++ ) {

		i_status = the->h_client[i].i_status;
		h_stp = the->h_client[i].h_stp;

		if( em_stp_open == i_status ) {

			do{
				i_err = h_stp->open(h_stp,NULL,STX_SERVICE_REQUEST_CONVERT);
			}while(STX_AGAIN == i_err);

			if( i_err < 0 ) {
				return i_err;
			}
			else if( STX_OK == i_err ) {
				the->h_client[i].i_status = em_stp_open_play;
			}
			else if( STX_WOUNLD_BLOCK == i_err ) {
				i_idle ++;
			}
		}
		else if( em_stp_open_play == i_status ) {

			do{
				i_err = h_stp->open(h_stp,NULL,STX_SERVICE_REQUEST_PLAY);
			}while(STX_AGAIN == i_err);

			if( i_err < 0 ) {
				return i_err;
			}
			else if( STX_OK == i_err ) {
				the->h_client[i].i_status = em_stp_read;
			}
			else if( STX_WOUNLD_BLOCK == i_err ) {
				i_idle ++;
			}

		}
		else if( em_stp_read == i_status ) {

			size_t i_read;

			do{
				i_read = 0; // file stream mode graph,only have one data channel;
				i_err = h_stp->read(h_stp,buf,sizeof(buf),&i_read);
			}while(STX_AGAIN == i_err);

			if( STX_OK == i_err ){

				//stx_log("connection %d %"PRIdPTR"x: read = %d\r\n",i,h_stp,i_read);

				stx_stat_add_val(the->h_client[i].h_stat,i_read);

				if( i_read < sizeof(buf) ) {
					i_rate = stx_stat_get_speed(the->h_client[i].h_stat);
					if( i_rate ){
						i_time = 32*1024 / i_rate;
						if( i_time < i_next_time ) {
							i_next_time = i_time;
						}
					}
				}
			}
			else if( STX_WOUNLD_BLOCK == i_err ) {
				i_idle ++;
				i_rate = stx_stat_get_speed(the->h_client[i].h_stat);
				if( i_rate ){
					i_time = 32*1024 / i_rate;
					if( i_time < i_next_time ) {
						i_next_time = i_time;
					}
				}
			}
			else if( STX_EOF == i_err ){
				the->h_client[i].i_status = em_stp_stop;
			}
			else{
				return i_err;
			}

		}
		else if( em_stp_stop == i_status ) {

			do{
				i_err = h_stp->stop(h_stp);
			}while(STX_AGAIN == i_err);

			if( i_err < 0 ) {
				return i_err;
			}
			else if( STX_WOUNLD_BLOCK == i_err ) {
				i_idle ++;
			}
			else if( STX_OK == i_err || STX_EOF == i_err ){
				stx_log("conection %d stopped\r\n",i);
				the->h_client[i].i_status = em_stp_close;
			}

		} // else if( em_stp_stop == i_status ) {

	} // for( i = 0; i < the->i_instance; i ++ ) {

	if( i_idle == the->i_instance ) {
		h_sync->i_idle = MILISEC2REFTIME(i_next_time);
		RESET_XENTRY(h_sync,&the->stx_stream_writer_vt);
		return STX_WOUNLD_BLOCK;
	}

	i_stop = 0;

	for( i = 0; i < the->i_instance; i ++ ) {
		if( em_stp_close == the->h_client[i].i_status ) {
			i_stop ++;
		}
	} // for( i = 0; i < the->i_instance; i ++ ) {

	if( i_stop == the->i_instance ) {
		// STX_EOF will trigger a auto-stop message;
		return STX_EOF;
	}

	{
		s64 i_time = stx_get_milisec();

		if( i_time - the->i_last_time > 3000 ) {

			stx_sync_source*	h_ssrc;
			s32					i_ssrc;

			the->i_last_time = i_time;

			for( i = 0; i < the->i_instance; i ++ ) {
				if( em_stp_read == the->h_client[i].i_status ) {
					i_rate = stx_stat_get_speed(the->h_client[i].h_stat);
					stx_log("conection %d speed = %d\r\n",i,i_rate);
				}
			} // for( i = 0; i < the->i_instance; i ++ ) {

			i_ssrc = 0;
			the->h_gbd->enum_ssrc(the->h_gbd,&i_ssrc,NULL);
			for( i = 0; i < i_ssrc; i ++ ) {
				h_ssrc = NULL;
				the->h_gbd->enum_ssrc(the->h_gbd,&i,&h_ssrc);
				i_time = h_ssrc->get_last_task_time(h_ssrc);
				stx_log("ssrc %"PRIdPTR"X last task time = %"PRIdPTR"d\r\n",h_ssrc,i_time);
				SAFE_XDELETE(h_ssrc);
			}

			i_time = the->h_gbd->get_occupy(the->h_gbd);
			stx_log("system occupy = %d\r\n",i_time);

		}
	}

	h_sync->i_idle = MILISEC2REFTIME(i_next_time);
	RESET_XENTRY(h_sync,&the->stx_stream_writer_vt);
	return STX_WOUNLD_BLOCK;

}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_stream_writer_vt_flt_plug_xxx_send_msg
( THEE h, stx_base_message* p_msg )
{
	STX_RESULT	i_err;

	STX_MAP_THE(stp_pressure);

	do{
		u32			i_type;
		s32			i = 0;

		i_err = dispatch_msg(h,p_msg);
		if( i_err < 0 || p_msg->is_msg_closed(p_msg)) {
			break;
		}

		i_type = p_msg->get_msg_type(p_msg);

		if( i_type & STX_MSG_TYPE_UPSTREAM ) {
			i_err = XCALL(send_msg,the->p_parent,p_msg);
		}

		if( i_err < 0 || p_msg->is_msg_closed(p_msg)) {
			break;
		}

		i_err = response_msg(h,p_msg);
		if( i_err < 0 || p_msg->is_msg_closed(p_msg)) {
			break;
		}

		i_err = STX_OK;

	}while(FALSE);

	return i_err;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_source_vt_xxx_set_pos(THEE h,sint64 i_pos)
{
	STX_RESULT i_err;

	STX_MAP_THE(stp_pressure);

	i_err = STX_FAIL;


	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_source_vt_xxx_get_pos(THEE h,sint64 *i_pos)
{
	STX_RESULT i_err;

	STX_MAP_THE(stp_pressure);

	i_err = STX_FAIL;


	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_base_source_vt_xxx_get_size(THEE h,sint64 *i_size)
{
	STX_MAP_THE(stp_pressure);

	return STX_ERR_OBJ_UNINIT;
}



/* control; */
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_get_caps
(THEE h,stx_xio* h_xio)
{
	STX_MAP_THE(stp_pressure);
	{

		STX_RESULT i_err;
		stx_xini*  h_xini;
		STX_HANDLE h_key;

		i_err = STX_FAIL;
		h_xini = NULL;

		do{

			i_err = stx_ini_create(NULL,h_xio,STX_INI_READ_WRITE|STX_INI_NO_COMMENT,0,&h_xini);
			if(STX_INI_OK != i_err ) {
				break;
			}

			i_err = h_xini->create_key(h_xini,NULL,(char*)g_szCtlCaps_play_stop,(char*)g_szTrue,&h_key);
			if(STX_INI_OK != i_err ) {
				break;
			}

			i_err = h_xini->create_key(h_xini,NULL,(char*)g_szCtlCaps_pause_resume,(char*)g_szTrue,&h_key);
			if(STX_INI_OK != i_err ) {
				break;
			}

			i_err = STX_OK;

		}while(FALSE);

		if( h_xini ) {
			h_xini->close(h_xini);
		}

		return i_err;
	}
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_get_status
(THEE h,u32* i_status)
{
	STX_MAP_THE(stp_pressure);

	*i_status = the->em_status;

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_play(THEE h)
{
	STX_RESULT			i_err;
	stx_base_plugin*    plug;

	STX_MAP_THE(stp_pressure);

	plug = (stx_base_plugin*)&the->stx_stream_writer_vt;

	// first send play message;
	{
		stx_base_message*	p_msg;
		stx_msg_cnt*		cnt;


		p_msg = XCREATE(base_msg,NULL,NULL);
		if( !p_msg) {
			return STX_FAIL;
		}

		p_msg->set_msg_type(p_msg,STX_MSG_TYPE_DOWNSTREAM);

		do{

			cnt = p_msg->get_msg_cnt(p_msg);
			cnt->msg_gid = STX_MSG_Play;
			i_err = plug->send_msg(plug,p_msg);
			if( i_err < 0 ) {
				break;
			}
			i_err = STX_OK;

		}while(FALSE);

		SAFE_XDELETE(p_msg);

		if( STX_OK != i_err ) {
			return i_err;
		}

	} //

	i_err = XCALL(reg_task,the->h_ssrc,&the->h_task,plug,TASK_NORMAL);
	if( STX_OK != i_err ) {
		return i_err;
	}

	the->em_status = emStxStatusPlay;
	// active ssrc handle;
	XCALL(reset_task,the->h_ssrc,the->h_task,0,0);

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_pause(THEE h)
{
	// first send pause message;
	STX_RESULT			i_err;
	stx_base_plugin*    p_flt;

	STX_MAP_THE(stp_pressure);

	stx_waitfor_mutex(the->h_mutex,INFINITE);

	do{
		i_err = STX_OK;

		if( emStxStatusPause != the->em_status ){
			XCALL(set_task_events,the->h_ssrc,the->h_task,ev_pause);
			i_err = STX_WOUNLD_BLOCK;
			break;
		}

		// send stop message;
		{
			stx_base_message*	p_msg;
			stx_msg_cnt*		cnt;

			p_msg= XCREATE(base_msg,NULL,NULL);
			if( !p_msg) {
				i_err = STX_FAIL;
				break;
			}

			p_msg->set_msg_type(p_msg,STX_MSG_TYPE_DOWNSTREAM);

			cnt = p_msg->get_msg_cnt(p_msg);
			cnt->msg_gid = STX_MSG_Pause;
			p_flt = (stx_base_plugin*)&the->stx_stream_writer_vt;
			i_err = p_flt->send_msg(p_flt,p_msg);
			if( i_err < 0 ) {
				break;
			}

			SAFE_XDELETE(p_msg);

			i_err = STX_OK;

		} // block;

	}while(FALSE);

	stx_release_mutex(the->h_mutex);

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_resume(THEE h)
{
	// first send pause message;
	STX_RESULT			i_err;
	stx_base_plugin*    p_flt;

	STX_MAP_THE(stp_pressure);

	stx_waitfor_mutex(the->h_mutex,INFINITE);

	do{

		if( emStxStatusPause != the->em_status ){
			i_err = STX_ERR_OBJ_STATUS;
			break;
		}

		// send resume message;
		{
			stx_base_message*	p_msg;
			stx_msg_cnt*		cnt;

			p_msg= XCREATE(base_msg,NULL,NULL);
			if( !p_msg) {
				i_err = STX_FAIL;
				break;
			}

			p_msg->set_msg_type(p_msg,STX_MSG_TYPE_DOWNSTREAM);

			cnt = p_msg->get_msg_cnt(p_msg);
			cnt->msg_gid = STX_MSG_Resume;
			p_flt = (stx_base_plugin*)&the->stx_stream_writer_vt;
			i_err = p_flt->send_msg(p_flt,p_msg);
			if( i_err < 0 ) {
				break;
			}

			SAFE_XDELETE(p_msg);

			XCALL(reset_task,the->h_ssrc,the->h_task,0,0);

			i_err = STX_OK;

		} // block;


	}while(FALSE);

	stx_release_mutex(the->h_mutex);

	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_set
(THEE h,u32 i_flag,size_t i_set)
{
	STX_MAP_THE(stp_pressure);
	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
enum {
	em_prs_stop_begin,em_prs_stop_stp,
};

STX_PURE STX_RESULT stx_base_control_vt_xxx_stop(THEE h)
{
	STX_RESULT	i_err;
	size_t*		h_status;
	size_t		i_status;

	STX_MAP_THE(stp_pressure);

	stx_waitfor_mutex(the->h_mutex,INFINITE);

	i_err = STX_OK;

	do{

		if( emStxStatusInit == the->em_status) {
			break;
		}

		if( !the->b_stop ){
			stx_stack_reset(the->h_stack);
			stx_stack_push(the->h_stack,em_prs_stop_begin);
			the->h_ssrc->set_task_events(the->h_ssrc,the->h_task,ev_stop);
			the->b_stop = TRUE;
			i_err = STX_WOUNLD_BLOCK;
			break;
		}

		if( emStxStatusStop != the->em_status ){
			i_err = STX_WOUNLD_BLOCK;
			break;
		}

		h_status = stx_stack_pop(the->h_stack);
		if( !h_status ) {
			i_err = STX_FAIL;
			break;
		}
		i_status = *h_status;

		if( em_prs_stop_begin == i_status ) {
			s32 i;
			for( i = 0; i < 2; i ++ ) {
				the->h_stop[i] = stx_stack_create();
				if( !the->h_stop[i] ) {
					i_err = STX_FAIL;
					break;
				}
			}
			for( i = 0; i < (s32)the->i_instance; i ++ ){
				if( the->h_client[i].i_status < em_stp_close ) {
					stx_stack_push(the->h_stop[0],(size_t)i);
				}
			}
			i_status = em_prs_stop_stp;
		}

		if( em_prs_stop_stp == i_status ) {

			while( h_status = stx_stack_pop(the->h_stop[0] ) ) {
				s32 idx = (s32)*h_status;
				i_err = the->h_client[idx].h_stp->stop(the->h_client[idx].h_stp);
				if( i_err < 0 ) {
					break;
				}
				if( STX_OK != i_err ) {
					stx_stack_push(the->h_stop[1],idx);
					continue;
				}
				the->h_client[idx].i_status = em_stp_close;
				stx_log("stp client %d closed\r\n",idx);
			}

			if( i_err < 0 ) {
				break;
			}

			if( stx_stack_top(the->h_stop[1]) ) {
				THEE tmp;
				tmp = the->h_stop[0];
				the->h_stop[0] = the->h_stop[1];
				the->h_stop[1] = tmp;
				stx_stack_push(the->h_stack,em_prs_stop_stp);
				i_err = STX_WOUNLD_BLOCK;
				break;
			}
		}

		// thread task stopped, next , send stop message to downstream filters;
		{
			stx_base_message*	p_msg;
			stx_msg_cnt*		cnt;

			stx_base_plugin* const plug = (stx_base_plugin*)&the->stx_stream_writer_vt;

			p_msg= XCREATE(base_msg,NULL,NULL);
			if( !p_msg) {
				i_err = STX_FAIL;
				break;
			}

			p_msg->set_msg_type(p_msg,STX_MSG_TYPE_DOWNSTREAM);

			cnt = p_msg->get_msg_cnt(p_msg);
			cnt->msg_gid = STX_MSG_Stop;
			i_err = plug->send_msg(plug,p_msg);
			if( i_err < 0 ) {
				break;
			}

			SAFE_XDELETE(p_msg);

			i_err = STX_OK;

		} // block

		// unreg ssrc handle;
		the->h_ssrc->unreg_task(the->h_ssrc,the->h_task);

		// return to do final cleanup;
		the->em_status = emStxStatusInit;

	}while(FALSE);

	stx_release_mutex(the->h_mutex);

	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_next(THEE h)
{
	STX_RESULT i_err;

	STX_MAP_THE(stp_pressure);

	i_err = STX_FAIL;


	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_prev(THEE h)
{
	STX_RESULT i_err;

	STX_MAP_THE(stp_pressure);

	i_err = STX_FAIL;


	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_step(THEE h)
{
	STX_RESULT i_err;

	STX_MAP_THE(stp_pressure);

	i_err = STX_FAIL;

	return i_err;
}

/* media info; */
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_media_info_vt_xxx_get_desc
(THEE h, sint32* i_len, char** sz_desc )
{
	STX_RESULT i_err;

	STX_MAP_THE(stp_pressure);

	i_err = STX_FAIL;


	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_media_info_vt_xxx_get_total_time
(THEE h,sint64 *i_time)
{
	STX_MAP_THE(stp_pressure);

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_media_info_vt_xxx_get_statistic
(THEE h,s32 * i_size,char ** pp_sz )
{
	return STX_ERR_NOT_IMP;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_media_info_vt_xxx_get_current_time
(THEE h,sint64 *i_time)
{
	STX_RESULT i_err;

	STX_MAP_THE(stp_pressure);

	i_err = STX_FAIL;


	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_media_info_vt_xxx_time_to_pos
(THEE h,sint64 i_time,offset_t * pos )
{
	STX_RESULT i_err;

	STX_MAP_THE(stp_pressure);

	i_err = STX_FAIL;


	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_media_info_vt_xxx_pos_to_time
(THEE h, offset_t pos ,sint64* i_time )
{
	STX_RESULT i_err;

	STX_MAP_THE(stp_pressure);

	i_err = STX_FAIL;


	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT on_play(THEE h, stx_base_message* p_msg )
{
	s32 i,j;

	STX_MAP_THE(stp_pressure);

	// create stp ctx;

	if( !the->i_instance ) {
		return STX_FAIL;
	}

	the->h_client = (stp_client_ctx*)xmallocz( sizeof(stp_client_ctx)*the->i_instance);
	if(!the->h_client ) {
		return STX_FAIL;
	}

	for( i = 0,j = 0; i < the->i_instance; i ++,j++ ) {

		if( j == the->i_url ) {
			j = 0;
		}

		the->h_client[i].h_stp = stx_create_io_stp(
			the->sz_ip,the->i_port,the->sz_url[j],the->sz_graph,NULL);
		if( !the->h_client[i].h_stp) {
			return STX_FAIL;
		}

		the->h_client[i].h_stat = stx_stat_create();
		if( !the->h_client[i].h_stat) {
			return STX_FAIL;
		}

		the->h_client[i].i_status = em_stp_open;

	} //for( i = 0; i < the->i_instance; i ++ ) {

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT on_stop(THEE h,stx_base_message* p_msg)
{	
	s32 i;

	STX_MAP_THE(stp_pressure);

	if( the->h_client ){

		for( i = 0; i < the->i_instance; i ++ ) {

			SAFE_CLOSEXIO(the->h_client[i].h_stp);

			if( the->h_client[i].h_stat ) {
				stx_stat_close(the->h_client[i].h_stat);
				the->h_client[i].h_stat = NULL;
			}

		} // for( i = 0; i < the->i_instance; i ++ ) {

		stx_free(the->h_client);

		the->h_client = NULL;

	} // if( the->h_client ){

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_ENTRY STX_RESULT at_BreakPin(THEE h, stx_base_message* p_msg )
{
	STX_MAP_THE(stp_pressure);
	{
	}

	return STX_OK;
}


/***************************************************************************
STX_MSG_PROC STX_RESULT on_pause(THEE h, stx_base_message* p_msg )
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT on_pause(THEE h, stx_base_message* p_msg)
{
	STX_MAP_THE(stp_pressure);

	return STX_OK;
}

/***************************************************************************
STX_MSG_PROC STX_RESULT on_resume( THEE h, stx_base_message* p_msg )
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT on_resume( THEE h, stx_base_message* p_msg )
{
	STX_MAP_THE(stp_pressure);

	return STX_OK;
}


/***************************************************************************
STX_MSG_PROC STX_RESULT at_play(THEE h, stx_base_message* p_msg )
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT at_play(THEE h, stx_base_message* p_msg )
{
	STX_MAP_THE(stp_pressure);

	// source filter status is not correct ;
	return STX_OK;
}

/***************************************************************************
STX_MSG_PROC STX_RESULT at_stop(THEE h,stx_base_message* p_msg)
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT at_stop(THEE h,stx_base_message* p_msg )
{
	STX_MAP_THE(stp_pressure);
	{
		return STX_OK;
	}
}



/***************************************************************************
STX_MSG_PROC STX_RESULT at_pause(THEE h, stx_base_message* p_msg )
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT at_pause(THEE h, stx_base_message* p_msg )
{
	STX_MAP_THE(stp_pressure);

	// source filter status is not correct ;
	return STX_OK;
}


/***************************************************************************
STX_MSG_PROC STX_RESULT at_resume( STX_HANDLE h, stx_base_message* p_msg )
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT at_resume( THEE h, stx_base_message* p_msg )
{
	STX_MAP_THE(stp_pressure);

	return STX_OK;
}




/***************************************************************************
RETURN VALUE:
INPUT: 
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT 
on_auto_stop(THEE h,stx_base_message* p_msg )
{
	STX_MAP_THE(stp_pressure);
	{
		THEE h_stack = p_msg->get_stack(p_msg);

		// push plugin interface pointer;
		stx_stack_push(h_stack,(size_t)&the->stx_stream_writer_vt);

		return STX_OK;
	}
}



/***************************************************************************
RETURN VALUE:
INPUT: 
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT 
on_app_stop(THEE h,stx_base_message* p_msg )
{
	STX_MAP_THE(stp_pressure);
	{
		stx_msg_cnt* p_cnt = p_msg->get_msg_cnt(p_msg);

		p_msg->set_msg_close(p_msg);

		// must be as io; send stop message to app handler;
		return stx_base_plugin_stop(
			(stx_base_plugin*)&the->stx_stream_writer_vt,
			(STX_RESULT)p_cnt->param.i_param[0],
			FALSE);

	}
}




/***************************************************************************
RETURN VALUE:
INPUT: 
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_stream_writer_vt_flt_xxx_set_input_media_type
(THEE h,stx_media_type * p_mtype)
{
	return STX_ERR_NOT_SUPPORT;
}



/***************************************************************************
RETURN VALUE:
INPUT: 
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_stream_writer_vt_flt_xxx_set_output_media_type
(THEE h,stx_media_type * p_mtype)
{
	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_stream_writer_vt_flt_plug_xxx_start
(THEE h,u32 i_flag,stx_sync_inf* h_sync)
{
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT: 
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_stream_writer_vt_flt_plug_xxx_stop
(THEE h,u32 i_flag,stx_sync_inf *h_sync)
{
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_stream_writer_vt_flt_plug_xxx_flush
(THEE h,u32 i_flag,stx_sync_inf* h_sync)
{
	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_stream_writer_vt_flt_xxx_enum_input_pin
(THEE h,sint32* i_idx,stx_base_pin** pp_pin )
{
	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_stream_writer_vt_flt_xxx_enum_output_pin
(THEE h,sint32 *i_idx,stx_base_pin** pp_pin )
{
	return STX_ERR_NOT_SUPPORT;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_stream_writer_vt_flt_xxx_check_input_media_type
( THEE h, stx_media_type* p_mdt )
{
	return STX_ERR_NOT_SUPPORT;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_stream_writer_vt_flt_xxx_check_output_media_type
( THEE h, stx_media_type* p_mdt )
{
	return STX_ERR_NOT_SUPPORT;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_stream_writer_vt_xxx_set_stream
( THEE h, stx_xio* p_output )
{
	STX_MAP_THE(stp_pressure);

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_stream_writer_vt_xxx_set_stream_name(THEE h,const char * sz_name)
{
	STX_MAP_THE(stp_pressure);

	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_stream_writer_vt_flt_xxx_deliver
(
 STX_HANDLE			h,
 stx_base_pin*		h_pin, // which input pin;
 stx_media_data*	p_mdat, // output media data;
 stx_sync_inf*		h_sync
 )
{
	return STX_ERR_NOT_SUPPORT;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_stream_writer_vt_flt_xxx_new_segment( THEE h )
{
	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_stream_writer_vt_flt_xxx_receive
(
 STX_HANDLE			h,
 stx_base_pin*		h_pin, // which input pin;
 stx_media_data**	pp_mdat,// output media data;
 stx_sync_inf*		h_sync 
 )
{
	return STX_ERR_NOT_SUPPORT;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT  
stx_stream_writer_vt_flt_plug_xxx_get_property(THEE h,stx_xio* h_xio)
{
	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_stream_writer_vt_flt_plug_xxx_set_property(THEE h,stx_xio* h_xio)
{
	return STX_ERR_NOT_SUPPORT;
}
