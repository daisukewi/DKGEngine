/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/


#include "stdio.h"

#include "stdlib.h"

#include "fcntl.h"

#include "malloc.h"

#include "memory.h"

#include "string.h"


#include "stx_mem.h"

#include "stx_debug.h"


#include "stx_gid_def.h"

#include "stx_module_reg.h"


#include "stx_server_graph.h"



typedef struct stx_server_graph_ctx stx_server_graph_ctx;

struct stx_server_graph_ctx {

	STX_PUBLIC(async_plugin)

	STX_PUBLIC(stx_base_graph)

	//STX_PUBLIC(stx_server_graph)


	size_t				i_plugins;

	size_t				i_max_plugins;
               
	stx_base_com**		pp_plugin;


	size_t				i_src;

	size_t              i_max_src;

	stx_base_com**		pp_src;


	size_t              i_max_stream_map;

	size_t              i_stream_map;

	STX_HANDLE*         pp_stream;

};








STX_API_IMP stx_server_graph*		stx_server_graph_create( )
{



	return STX_NULL;
}