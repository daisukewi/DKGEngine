/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/
#include "stdio.h"
#include "stdlib.h"
#include "fcntl.h"
#include "malloc.h"
#include "memory.h"
#include "string.h"

#include "stx_mem.h"
#include "stx_debug.h"
#include "stx_gid.h"
#include "stx_os.h"
#include "stx_message.h"

#include "stx_direct_pin.h"
#include "stx_output_pin.h"


#include "stx_media_type_base.h"
#include "stx_malloc_lxvideoframe.h"
#include "stx_mdat_lxvideoframe.h"

#include "stx_io_file.h"
#include "stx_io_stream.h"
#include "stx_io_udp.h"
#include "stx_io_tcp.h"

#include "stx_prop_def.h"
#include "stx_module_reg.h"

#include "stx_async_plugin.h"
#include "stx_listen_filter.h"

#include "stx_protocol.h"
#include "stx_heap.h"


#define __STX_SERVICE_API_C__
#include "stx_service_api.c"

#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif


char* g_szStreamX_ListenFilter = "StreamX socket listen plugin";

DEFINE_XGUID( STX_CLSID_ListenFilter,
	0x73463c4e, 0x7c11, 0x4edd, 0xa7, 0x46, 0x3b, 0x5f, 0x6d, 0x8c, 0xa2, 0xf5);


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API_IMP 
CREATE_STX_COM(stx_base_plugin,STX_IID_BasePlugin,ListenFilter);

STX_INTERF(service_ctx);
struct service_ctx{
	stx_base_plugin*	h_svr;
	STX_RESULT			i_ret;
	// statistic callback ???
};

STX_COM_BEGIN(ListenFilter);
/**/
/**/STX_PUBLIC(stx_base_plugin)
/**/STX_COM_DATA_DEFAULT(stx_base_plugin)
/**/
/**/b32					b_fatal;
/**/s32					i_err;
/**/s64					i_last_time;
/**/s64					i_last;
/**/char*				sz_log;
/**/STX_RESULT			(*write_log)(STX_RESULT i_err,char* sz_file);
/**/
/**/s32					i_service;
/**/service_ctx**		hh_service;
/**/THEE				h_mutex;
/**/THEE				h_stack;
/**/
STX_COM_END();


#define listen_lock()	stx_waitfor_mutex(the->h_mutex,INFINITE)
#define listen_unlock() stx_release_mutex(the->h_mutex)



STX_COM_FUNC_DECL_DEFAULT(stx_base_plugin,stx_base_plugin_vt);
STX_COM_FUNCIMP_DEFAULT(ListenFilter,stx_base_plugin,stx_base_plugin_vt);


STX_PRIVATE STX_RESULT	load_config(ListenFilter* the);
STX_PRIVATE void		close_all_service(ListenFilter* the);

/*{{{STX_MSG_ENTRY_DECLARE**************************************************/
STX_MSG_ENTRY_DECLARE(on_auto_stop)
STX_MSG_ENTRY_DECLARE(on_app_stop)
/*}}}***********************************************************************/


/*{{{STX_BEGIN_MSG_MAP******************************************************/
STX_BEGIN_MSG_MAP(the_msg_data)
/* to do : add msg process entry here; */
/**/ON_STX_MSG(STX_MSG_AutoStop,on_auto_stop)
/**/ON_STX_MSG(STX_MSG_AppStop,on_app_stop)
STX_END_MSG_MAP
/*}}}***********************************************************************/


/*{{{STX_DISPATCH_MSG_PROC**************************************************/
STX_DISPATCH_MSG_PROC( dispatch_msg,the_msg_data )
/*}}}***********************************************************************/


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_COM_MAP_BEGIN(ListenFilter)
/**/STX_COM_MAP_ITEM(STX_IID_BasePlugin)
STX_COM_MAP_END()

STX_NEW_BEGIN(ListenFilter)
{
	//STX_RESULT i_err;

	STX_SET_THE(stx_base_plugin);
	STX_COM_NEW_DEFAULT(stx_base_plugin,the->stx_base_plugin_vt,stx_base_plugin_vt,
		STX_CLSID_ListenFilter,STX_CATEGORY_Service,g_szStreamX_ListenFilter);

	the->h_mutex = stx_create_mutex(NULL,0,NULL);
	if( !the->h_mutex ) {
		break;
	}

	the->b_fatal = TRUE;
	the->i_err = STX_FAIL;

	the->sz_log = (char*)xmallocz(1024);
	if( !the->sz_log ) {
		break;
	}
	get_service_ha_file_name(the->sz_log,1024);

	the->b_fatal = FALSE;
	the->i_err = STX_OK;
	the->i_last_time = stx_get_milisec();

}
STX_NEW_END()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API_IMP	
STX_QUERY_BEGIN(ListenFilter)
{
	STX_COM_QUERY_DEFAULT(stx_base_plugin,the->stx_base_plugin_vt);
}
STX_QUERY_END()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API_IMP	
STX_DELETE_BEGIN(ListenFilter)
{
	//write log;
	if( the->write_log && the->sz_log ){
		the->write_log(the->i_err,the->sz_log);
	}

	if( the->sz_log ) {
		stx_free(the->sz_log);
	}

	close_all_service(the);

	if( the->h_mutex) {
		stx_close_mutex(the->h_mutex);
	}

	STX_COM_DELETE_DEFAULT(stx_base_plugin);
}
STX_DELETE_END
(
STX_COM_DELETE_BEGIN(stx_base_plugin)
,
STX_COM_DELETE_END(stx_base_plugin)
)




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT on_auto_stop(STX_HANDLE h,stx_base_message* p_msg)
{
	STX_MAP_THE(ListenFilter);
	{
		STX_HANDLE h_stack = p_msg->get_stack(p_msg);

		// push plugin interface pointer;
		stx_stack_push(h_stack,(size_t)h);

		return STX_OK;
	}
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT on_app_stop(STX_HANDLE h,stx_base_message* p_msg)
{
	STX_MAP_THE(ListenFilter);
	{
		s32 i;

		stx_msg_cnt* p_cnt = p_msg->get_msg_cnt(p_msg);

		stx_base_plugin* const plug = (stx_base_plugin*)p_cnt->param.i_param[1];

		listen_lock();

		for( i = 0; i < the->i_service; i ++ ) {

			if( !the->hh_service[i] ) {
				continue;
			}

			if( the->hh_service[i]->h_svr == plug ) {

				STX_RESULT i_err = (STX_RESULT)p_cnt->param.i_param[0];

				if( STX_RESTART == i_err ) { // only restart protocol;


				}

				SAFE_XDELETE0(the->hh_service[i]->h_svr);
				the->hh_service[i]->i_ret = i_err;
				p_msg->set_msg_close(p_msg);

				listen_unlock();

				return STX_OK;
				
			} // if( the->hh_service[i] == h_plug ) {

		} // for( i = 0; i < the->i_protocol; i ++ ) {

		listen_unlock();

		return STX_OK;
	}

}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_plugin_vt_xxx_send_msg
(STX_HANDLE h,stx_base_message * p_msg)
{
	STX_RESULT	i_err;

	STX_MAP_THE(ListenFilter);

	do{
		u32 i_type;

		i_err = dispatch_msg(h,p_msg);
		if( i_err < 0 || p_msg->is_msg_closed(p_msg)) {
			break;
		}

		i_type = p_msg->get_msg_type(p_msg);

		if( i_type & STX_MSG_TYPE_ASYNC ) {
			i_err = the->h_ssrc->send_msg(the->h_ssrc,p_msg);
		}

		i_err = STX_OK;

	}while(FALSE);

	return i_err;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_base_plugin_vt_xxx_get_property(STX_HANDLE h,stx_xio* h_xio)
{
	STX_MAP_THE(ListenFilter);

	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_base_plugin_vt_xxx_set_property(STX_HANDLE h,stx_xio* h_xio)
{
	STX_MAP_THE(ListenFilter);

	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_base_plugin_vt_xxx_flush(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync )
{
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_base_plugin_vt_xxx_start(STX_HANDLE h,u32 i_flags,stx_sync_inf* h_sync )
{
	STX_RESULT i_err;

	STX_MAP_THE(ListenFilter);

	if( i_flags == FLAG_SET_CALLBACK ) {

		stx_log("service manager: start: set callack\r\n");

		the->write_log = ( STX_RESULT (*)(STX_RESULT,char*) ) h_sync->h_data;
		return STX_OK;
	}

	// create task handle;
	if( i_flags == FLAG_START_TASK ) {

		stx_log("service manager: start: start task \r\n");

		i_err = the->h_gbd->alloc_ssrc(the->h_gbd,FALSE,NULL,1,&the->h_ssrc);
		if(STX_OK != i_err ){
			return i_err;
		}

		return load_config(the);

	} // if( i_flags == FLAG_START_TASK ) {

	return STX_ERR_INVALID_PARAM;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_base_plugin_vt_xxx_stop(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync )
{
	STX_MAP_THE(ListenFilter);
	{
		s32			i;
		STX_RESULT	i_err;

		i_err = STX_OK;

		for( i = 0; i < the->i_service; i ++ ) {

			stx_base_plugin* p;

			if( ! the->hh_service[i] ) {
				continue;
			}

			p = the->hh_service[i]->h_svr;

			for( ; ; ) {
				stx_sync_inf inf = {0};
				do{
					i_err = p->stop(p,0,&inf);
				}while( STX_AGAIN == i_err );
				if( STX_OK == i_err ) {
					break;
				}
				if( i_err < 0 ) {
					break;
				}
				stx_sleep(10);
			}
			if( i_err < 0 ) {
				break;
			}
		}
		return i_err;
	}

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_base_plugin_vt_xxx_run(STX_HANDLE h,stx_sync_inf* h_sync )
{

	STX_RESULT	i_err;

	s64			i_cur_time;

	STX_MAP_THE(ListenFilter);

	i_err = STX_FAIL;


	for( ; ; ) {

		s32 i;

		if( stx_interrupted() ) {
			// gdb thread failed;
			// write log;
			the->write_log(STX_FAIL,the->sz_log);
			return STX_FAIL;
		}

		i_cur_time = stx_get_milisec();
		if( i_cur_time - the->i_last_time > 1000 ) {
			i_err = the->write_log(STX_OK,the->sz_log);
			if( STX_OK != i_err ) {
				return STX_FAIL;
			}
			the->i_last_time = i_cur_time;
		}// if( i_cur_time - the->i_last_time > 1000 ) {

		// check if have protocol need to be start;

		// check all protocol running status;

		listen_lock();
		for( i = 0; i < the->i_service; i ++ ) {
			if( !the->hh_service[i]) {
				continue;
			}
			i_err = the->hh_service[i]->i_ret;
			if( i_err != STX_OK ) {
				if( STX_RESTART == i_err || i_err < 0 ) {
					listen_unlock();					
					return i_err;
				}
			}
		}
		listen_unlock();

#if 0
		{
			s64 i_time = stx_get_milisec();

			if( i_time - the->i_last > 3000 ) {

				stx_sync_source*	h_ssrc;
				s32					i_ssrc,i_so;
				char*				sz_name;

				the->i_last = i_time;

				i_ssrc = 0;
				the->h_gbd->enum_ssrc(the->h_gbd,&i_ssrc,NULL);
				for( i = 0; i < i_ssrc; i ++ ) {
					h_ssrc = NULL;
					the->h_gbd->enum_ssrc(the->h_gbd,&i,&h_ssrc);
					i_time = h_ssrc->get_last_task_time(h_ssrc);
					sz_name = h_ssrc->get_last_task_name(h_ssrc);
					i_so = h_ssrc->get_occupy(h_ssrc);
					stx_log("ssrc 0x%"PRIdPTR"X last task<%s> time = %"PRId64"d,occupy = %d/1000\r\n",
						h_ssrc,sz_name,i_time,i_so);
					SAFE_XDELETE(h_ssrc);
				}

				i_time = the->h_gbd->get_occupy(the->h_gbd);
				stx_log("system occupy = %d/1000\r\n",i_time);
			}
		}
#endif // thread monitor;

		stx_sleep(500);

	} // for( ; ; ) {

	return i_err;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT load_config(ListenFilter* the)
{
	STX_RESULT					i_err;
	stx_xini*					h_xini;
	STX_HANDLE					h_all;
	STX_HANDLE					h_clsid,h_svr;
	char						sz_cfg[1024];
	char						sz_key[1024];
	char						sz_gid[64];
	char*						sz_val;
	s32							i,i_val;

	i_err = STX_FAIL;

	sz_val = STX_NULL;
	h_xini = STX_NULL;

	INIT_MEMBER(sz_cfg);
	INIT_MEMBER(sz_key);
	INIT_MEMBER(sz_gid);

	listen_lock();

	do{

		stx_sprintf(sz_cfg, sizeof(sz_cfg),"%s"STX_SEP"%s",g_szStreamX_Root,"gbd.xini");

		// open ini;		
		i_err = stx_ini_create( sz_cfg, STX_NULL, STX_INI_READ_ONLY|STX_INI_NO_COMMENT, 0, &h_xini );
		if( STX_INI_OK != i_err ) {
			break;
		}

		// read key;

		/*all Service ; */

		i_err = h_xini->create_key( h_xini, STX_NULL, g_szStreamX_AllService, "1", &h_all );
		if( STX_INI_OK != i_err ) {
			break;
		}

		i_val = 0;
		i_err = h_xini->get_sub_key_num(h_xini,h_all,&i_val);
		if( STX_INI_OK != i_err ) {
			break;
		}

		if( !i_val ) {
			i_err = STX_FAIL; // no protocol to load;
			break;
		}

		the->i_service = i_val;

		the->hh_service = (service_ctx**)xmallocz(sizeof(service_ctx*)*i_val);
		if( !the->hh_service ) {
			i_err = STX_FAIL;
			break;
		}

		for( i = 0; i < i_val; i ++ ) {

			stx_gid cls_gid;
			s32		b_enable;

			i_err = h_xini->get_sub_key( h_xini, h_all, i, &h_clsid );
			if( STX_INI_OK != i_err ) {
				continue;
			}

			i_err = h_xini->read_key(h_xini,h_clsid,&sz_val);
			if( STX_INI_OK != i_err ) {
				break;
			}

			i_err = h_xini->create_key( h_xini, h_clsid, g_szStreamX_enable, "1", &h_svr );
			if( STX_INI_OK != i_err ) {
				continue;
			}

			b_enable = FALSE;
			i_err = h_xini->read_int32(h_xini,h_svr,&b_enable);
			if( STX_INI_OK != i_err ) {
				break;
			}

			if( !b_enable ) {
				continue;
			}

			the->hh_service[i] = (service_ctx*)xmallocz(sizeof(service_ctx));
			if( !the->hh_service[i] ) {
				i_err = STX_FAIL;
				break;
			}

			binary_from_string(cls_gid.data,sz_val);

			{
				stx_base_com*	h_com = NULL;

				i_err = XCALL(co_create_obj,the->h_gbd,cls_gid,&h_com);
				if( STX_OK != i_err ) {
					break;
				}
				i_err = XCALL(query_interf,h_com,STX_IID_BasePlugin,(void**)&the->hh_service[i]->h_svr);
				SAFE_XDELETE(h_com);
				if( STX_OK != i_err ) {
					break;
				}
				{
					stx_sync_inf inf = {0};
					stx_base_plugin* p = the->hh_service[i]->h_svr;
					p->set_parent(p,&the->stx_base_plugin_vt);
					p->set_gbd(p,the->h_gbd);
					XCALL(add_ref,the->h_gbd);

					stx_log("\r\nstarting service <%s> ...\r\n",p->get_name(p));

					for( ; ; ) {
						do{
							i_err = p->start(p,0,&inf);
						}while( STX_AGAIN == i_err );
						if( STX_OK == i_err ) {
							stx_log("service <%s> started;\r\n\r\n",p->get_name(p));
							break;
						}
						if( i_err < 0 ) {
							stx_log("service <%s> start fail;\r\n\r\n",p->get_name(p));
							break;
						}
						stx_sleep(10);
					}
					if( i_err < 0 ) {
						break;
					}
				} // block

			} // block

		} //for( i = 0; i < i_val; i ++ ) {

	}while(FALSE);

	SAFE_CLOSEXIO(h_xini);

	listen_unlock();

	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE void close_all_service(ListenFilter* the)
{
	if(the->hh_service){
		s32 i;
		for( i = 0; i < the->i_service; i ++ ) {
			if( the->hh_service[i] ) {
				SAFE_XDELETE0( the->hh_service[i]->h_svr ) ;
				stx_free(the->hh_service[i]);
			}
		}
		stx_free(the->hh_service);
		the->hh_service = NULL;
		the->i_service = 0;
	}
}
