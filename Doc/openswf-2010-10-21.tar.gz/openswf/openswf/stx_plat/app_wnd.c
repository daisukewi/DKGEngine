/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-10
***********************************************************************************/
#include "app_wnd.h"
#include "ActiveMovieWindow.h"
#include "base_canvas.h"

#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif


#ifdef __WIN32_LIB

#ifdef _MAP_THE	
#undef _MAP_THE	
#endif	
#define _MAP_THE STX_MAP_THE(app_wnd)	

#ifdef _DIRECT_THE	
#undef _DIRECT_THE	
#endif	
#define _DIRECT_THE STX_DIRECT_THE(app_wnd)	



DEFINE_XGUID(STX_IID_AppWndCallback,
			 0x3e1bd264, 0xf1c, 0x4e99, 0x85, 0x9f, 0xda, 0x6b, 0x48, 0xd2, 0x6b, 0x3b)


#define WM_ASPECT_RATIO		WM_USER + 700
#define WM_PLAY    			WM_USER + 1200
#define WM_STOP    			WM_USER + 1210
#define WM_PAUSE    		WM_USER + 1220
#define WM_RESUME    		WM_USER + 1230



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static BOOL GetCurrentPath(LPTSTR szPath, DWORD nSize) //nSize: n TCHARs
{
	DWORD dwRet =
		GetModuleFileName(GetModuleHandle(NULL), szPath, nSize);

	if(0 == dwRet)
	{
		return FALSE;
	}
	else
	{
		TCHAR* p = szPath;
		while(*p)++p;// let p point to '\0'
		while('\\' != *p)--p;// let p point to '\\'
		*p = '\0';// get the path

		return TRUE;
	}
}


#define WND_MIN_WIDTH   352
#define WND_MIN_HEIGHT  288

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static void GetFullScreenSize(SIZE *size, BOOL bWorkArea)
{
	int nSX = GetSystemMetrics(SM_CXSCREEN);
	int nSY = GetSystemMetrics(SM_CYSCREEN);
	RECT rWorkArea;
	BOOL bResult = SystemParametersInfo(SPI_GETWORKAREA, sizeof(RECT), &rWorkArea, 0);    
	if(!bResult || !bWorkArea)
	{
		size->cx = nSX;
		size->cy = nSY;
	}
	else
	{
		size->cx = rWorkArea.right - rWorkArea.left;
		size->cy = rWorkArea.bottom - rWorkArea.top;
	}
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static void ClientRectToScreen(HWND hWnd, RECT* lpRect)
{
	POINT top;
	POINT bottom;
	top.x = lpRect->left;
	top.y = lpRect->top;
	bottom.x = lpRect->right;
	bottom.y = lpRect->bottom;
	ClientToScreen(hWnd, &top);
	ClientToScreen(hWnd, &bottom);
	SetRect(lpRect, top.x,top.y, bottom.x,bottom.y);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_API_IMP 
CREATE_STX_COM(stx_base_plugin,STX_IID_BasePlugin,app_wnd);


STX_COM_BEGIN(app_wnd);
/**/
/**/STX_PUBLIC(stx_base_plugin)
/**/STX_COM_DATA_DEFAULT(stx_base_plugin)
/**/STX_PUBLIC(stx_active_movie_wnd)
/**/HWND					m_hWnd;
/**/HINSTANCE				m_hInstance;
/**/CRITICAL_SECTION		m_Critic;
/**/WNDCLASSEX				m_wc;
/**/s32						m_width;
/**/s32						m_height;
/**/s32						m_aspect_ratio;
/**/s32						m_force_aspect_ratio;
/**/b32						m_bFixAspectRatio;
/**/b32						m_bFullScreen;
/**/b32						m_bMaximizeScreen;
/**/b32						m_bTopMost;
/**/u32						m_dwColorKey;
/**/stx_base_plugin*		m_hChildWndPlugin;
/**/stx_active_movie_wnd*	m_hChildActiveWnd;
/**/RECT					m_rt;
/**/RECT					m_dst_rect;
/**/stx_app_wnd_callback*   theGraphEdit;
/**/
STX_COM_END();


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_COM_FUNC_DECL_DEFAULT(stx_base_plugin,stx_base_plugin_vt);
STX_COM_FUNCIMP_DEFAULT(app_wnd,stx_base_plugin,stx_base_plugin_vt);

STX_COM_FUNC_DECL_DEFAULT(stx_active_movie_wnd,stx_active_movie_wnd_vt);
STX_COM_FUNCIMP_DEFAULT(app_wnd,stx_active_movie_wnd,stx_active_movie_wnd_vt);


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE void set_parent( STX_HANDLE h, stx_base_plugin* p_parent )
{
	STX_MAP_THE(app_wnd);
	p_parent->query_interf(p_parent,STX_IID_AppWndCallback,(void**)&the->theGraphEdit);
	SAFE_XDELETE(p_parent); // parent should be release at once;
	stx_base_plugin_vt_xxx_set_parent(h,p_parent);
}



/*{{{STX_MSG_PROC_DECLARE***************************************************/
STX_MSG_PROC_DECLARE(dispatch_msg)
/*}}}***********************************************************************/

/*{{{STX_MSG_ENTRY_DECLARE**************************************************/
/**/STX_MSG_ENTRY_DECLARE(on_play)
/**/STX_MSG_ENTRY_DECLARE(on_stop)
/**/STX_MSG_ENTRY_DECLARE(on_query_obj)
/**/STX_MSG_ENTRY_DECLARE(at_BreakPin)
/*}}}***********************************************************************/

/*{{{STX_BEGIN_MSG_MAP******************************************************/
STX_BEGIN_MSG_MAP(the_msg_data)
/* to do : add msg process entry here; */
/**/ON_STX_MSG(STX_MSG_Play,on_play)
/**/ON_STX_MSG(STX_MSG_Stop,on_stop)
/**/ON_STX_MSG(STX_MSG_QueryObject,on_query_obj)
/**/ON_STX_MSG(STX_MSG_BreakPin,at_BreakPin)
STX_END_MSG_MAP
/*}}}***********************************************************************/

/*{{{STX_DISPATCH_MSG_PROC**************************************************/
STX_DISPATCH_MSG_PROC( dispatch_msg,the_msg_data )
/*}}}***********************************************************************/


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

static const char* g_szGraphEditPlayWindow = "StreamX Service AppWindow";

STX_COM_MAP_BEGIN(app_wnd)
/**/STX_COM_MAP_ITEM(STX_IID_BasePlugin)
/**/STX_COM_MAP_ITEM(STX_IID_ActiveMovieWindow)
STX_COM_MAP_END()

STX_NEW_BEGIN(app_wnd)
{
	STX_SET_THE(stx_base_plugin);
	STX_COM_NEW_DEFAULT(stx_base_plugin,the->stx_base_plugin_vt,stx_base_plugin_vt,
		STX_CLSID_ActiveMovieWindow,STX_CATEGORY_ActiveMovieWindow,g_szGraphEditPlayWindow);

	STX_SET_THE(stx_active_movie_wnd);
	STX_COM_NEW_DEFAULT(stx_active_movie_wnd,the->stx_active_movie_wnd_vt,stx_active_movie_wnd_vt,
		DEFAULT_CODE,DEFAULT_CODE,DEFAULT_CODE);

	// overload;
	the->stx_base_plugin_vt.set_parent = set_parent;

	the->m_hWnd = NULL;
	the->m_hInstance = NULL;
	the->m_dwColorKey = RGB(19,19,19);
	the->m_bFixAspectRatio = TRUE;
	InitializeCriticalSection(&the->m_Critic);

}
STX_NEW_END()



STX_PURE 
STX_QUERY_BEGIN(app_wnd)
{
	STX_COM_QUERY_DEFAULT(stx_base_plugin,the->stx_base_plugin_vt);
	STX_COM_QUERY_DEFAULT(stx_active_movie_wnd,the->stx_active_movie_wnd_vt);
}
STX_QUERY_END()


/***********************************************************************
LxVidActMVW::~LxVidActMVW()
***********************************************************************/
STX_PURE 
STX_DELETE_BEGIN(app_wnd)
{
	SAFE_XDELETE(the->m_hChildWndPlugin);
	SAFE_XDELETE(the->m_hChildActiveWnd);

	if( the->m_hWnd ) {
		DestroyWindow(the->m_hWnd);
	}

	DeleteCriticalSection(&the->m_Critic);

	rem_app_wnd(&the->stx_base_plugin_vt);

	STX_COM_DELETE_DEFAULT(stx_base_plugin);
	STX_COM_DELETE_DEFAULT(stx_active_movie_wnd);
}
STX_DELETE_END
(
 STX_COM_DELETE_BEGIN(stx_base_plugin)
 ,
 STX_COM_DELETE_END(stx_base_plugin)
 )


STX_PRIVATE LRESULT WINAPI		ClientWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
STX_PRIVATE	LRESULT LxWindowProc(app_wnd*the,HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);


STX_PRIVATE __inline	void lock_play_window(app_wnd* the)	{EnterCriticalSection(&the->m_Critic);}
STX_PRIVATE __inline	void unlock_play_window(app_wnd* the){LeaveCriticalSection(&the->m_Critic);}

//STX_PRIVATE STX_RESULT on_paint_window(app_wnd* the);
STX_PRIVATE STX_RESULT on_close_window(app_wnd* the);
STX_PRIVATE STX_RESULT on_lbtn_dbclick(app_wnd* the,size_t i_wparam,size_t i_lparam);
STX_PRIVATE STX_RESULT on_rbtn_down(app_wnd* the,size_t i_wparam,size_t i_lparam);
STX_PRIVATE STX_RESULT on_size(app_wnd* the,size_t i_wparam,size_t i_lparam);
STX_PRIVATE STX_RESULT on_sizing(app_wnd* the,size_t i_wparam,size_t i_lparam);
STX_PRIVATE STX_RESULT on_move(app_wnd* the,size_t i_wparam,size_t i_lparam);

STX_PRIVATE STX_RESULT on_aspect_ratio(app_wnd* the,stx_base_message* p_msg);

STX_PRIVATE void AdjustPlayWnd(app_wnd* the,u32 i_aspect);
STX_PRIVATE void FixRectScale( RECT* lpDrect, DWORD dwWhratio);
STX_PRIVATE BOOL FullScreenModeOn(app_wnd* the);
STX_PRIVATE BOOL FullScreenModeOff(app_wnd* the);
STX_PRIVATE void ControlFullScreenMode(app_wnd* the);
STX_PRIVATE void update_dst_rect(app_wnd* the);

STX_PRIVATE void decide_window_rect
(app_wnd* the,u32 i_aspect, b32 b_width_prefer,RECT* p_rect);


/***************************************************************************************
LRESULT WINAPI ClientWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
***************************************************************************************/
LRESULT WINAPI ClientWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	stx_base_plugin* h = app_wnd_from_hwnd(hwnd);

	if( !h ) {// maybe WM_CREATE msg;
		return DefWindowProc( hwnd, msg, wParam, lParam) ;
	}
	{
		LRESULT i_err;

		_MAP_THE;

		i_err = LxWindowProc(the,hwnd,msg, wParam, lParam);

		return i_err;
	}
}

/***************************************************************************************
LRESULT LxWindowProc(
HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
***************************************************************************************/
LRESULT LxWindowProc
( app_wnd* the,HWND hwnd, UINT msg, WPARAM i_wParam, LPARAM i_lParam)
{
	STX_RESULT i_err;


	stx_log("app_wnd:LxWindowProc\r\n");


	switch(msg) {

		// 	case WM_ERASEBKGND:
		// 		return 1L;

	//case WM_PAINT:
		//return 1L;

		// 	case WM_LBUTTONDOWN:
		// 	case WM_LBUTTONUP:
		// 	case WM_RBUTTONUP:
		// 	case WM_RBUTTONDBLCLK:
		// 	case WM_MOUSEMOVE:
		// 		break;

	case WM_LBUTTONDBLCLK:
		i_err = on_lbtn_dbclick(the,i_wParam,i_lParam);
		return 0L;

	case WM_RBUTTONDOWN:
		i_err = on_rbtn_down(the,i_wParam,i_lParam);
		return 0L;

	case WM_CLOSE:
		i_err = on_close_window(the);
		return 0L;

	case WM_MOVE:
		i_err = on_move(the,i_wParam,i_lParam);
		return 0L;

	case WM_SIZE:
		i_err = on_size(the,i_wParam,i_lParam);
		return 0L;

	case WM_SIZING:
		i_err = on_sizing(the,i_wParam,i_lParam);
		return 1L;

	case WM_ASPECT_RATIO:
		i_err = on_aspect_ratio(the,(stx_base_message*)i_wParam);
		return 0L;
	}

	return DefWindowProc(hwnd, msg, i_wParam,i_lParam);
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT on_close_window(app_wnd* the)
{
	the->theGraphEdit->cmd(the->theGraphEdit,STXM_CLOSE,(size_t)&the->stx_base_plugin_vt,0); 
	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_active_movie_wnd_vt_xxx_create
(STX_HANDLE h,stx_base_plugin *p_parent)
{
	_MAP_THE;
	{
		STX_RESULT		i_err;
		char			class_name[64];
		stx_gid			class_gid;
		RECT			dst_rect;
		HWND			h_child_wnd;
		stx_base_com*	p;

		do{

			i_err = STX_FAIL;
			p = NULL;

			// default value;
			the->m_width = 800;
			the->m_height = 500;
			the->m_aspect_ratio = MAKE_LXRATIO( 16 , 10);

			class_gid = stx_gid_create();
			binary_to_string(sizeof(stx_gid),(u8*)&class_gid,class_name);

			INIT_MEMBER(the->m_wc);

			the->m_wc.cbSize = sizeof( WNDCLASSEX);
			the->m_wc.style = CS_VREDRAW | CS_HREDRAW |CS_DBLCLKS;
			the->m_wc.lpfnWndProc = ClientWndProc;
			the->m_wc.cbClsExtra = 0;
			the->m_wc.cbWndExtra = 0;
			the->m_wc.hInstance = GetModuleHandle(NULL);
			//the->m_wc.hIcon = LoadIcon(the->m_wc.hInstance, MAKEINTRESOURCE(IDR_MAINFRAME));
			//the->m_wc.hIconSm = LoadIcon(the->m_wc.hInstance, MAKEINTRESOURCE(IDR_MAINFRAME));
			//the->m_wc.hCursor = LoadCursor(NULL, IDC_ARROW);
			//the->m_wc.hbrBackground = (HBRUSH__ *)(GetStockObject(WHITE_BRUSH));
			the->m_wc.lpszMenuName = NULL;
			the->m_wc.lpszClassName = class_name;

			if(!RegisterClassEx(&the->m_wc))	{
				MessageBeep(0);
				break;
			}

			the->m_hWnd = CreateWindowEx(	WS_EX_ACCEPTFILES,
				class_name,
				"Active Movie Window",

				WS_POPUP 
				| WS_CAPTION
				| WS_THICKFRAME
				| WS_MINIMIZEBOX 
				| WS_MAXIMIZEBOX
				| WS_SYSMENU 
				| SC_CLOSE 
				| WS_SIZEBOX 
				| WS_CLIPCHILDREN | WS_CLIPSIBLINGS
				,

				//WS_MINIMIZEBOX | WS_MAXIMIZEBOX
				//| WS_SYSMENU | WS_POPUP | WS_THICKFRAME
				//| WS_CLIPCHILDREN | WS_CLIPSIBLINGS,

				GetSystemMetrics(SM_CXSCREEN) / 2 - the->m_width / 2 , 
				GetSystemMetrics(SM_CYSCREEN) / 8,
				the->m_width,
				the->m_height,
				NULL,
				NULL,
				the->m_wc.hInstance,
				NULL);

			if( !the->m_hWnd ) {

				break;
			}

			ShowWindow(the->m_hWnd,SW_SHOW);

			add_app_wnd(&the->stx_base_plugin_vt,the->m_hWnd);

			i_err = the->h_gbd->co_create_obj(the->h_gbd,STX_CLSID_ActiveMovieWindow,&p);
			if( STX_OK != i_err ){
				break;
			}

			i_err = p->query_interf(p,STX_IID_BasePlugin,(void**)&the->m_hChildWndPlugin);
			if( STX_OK != i_err ){
				break;
			}

			i_err = the->m_hChildWndPlugin->query_interf(the->m_hChildWndPlugin,
				STX_IID_ActiveMovieWindow,(void**)&the->m_hChildActiveWnd );
			if( STX_OK != i_err ){
				break;
			}

			i_err = the->m_hChildActiveWnd->create(the->m_hChildActiveWnd,&the->stx_base_plugin_vt);
			if( STX_OK != i_err ) {
				break;
			}

			GetClientRect(the->m_hWnd,&dst_rect);
			ClientRectToScreen(the->m_hWnd,&dst_rect);

			the->m_hChildActiveWnd->set_dst_rect(the->m_hChildActiveWnd,*(STX_RECT*)&dst_rect);

			// under vista, color key will not be used by video render;
			the->m_hChildActiveWnd->set_color_key(the->m_hChildActiveWnd,the->m_dwColorKey);

			h_child_wnd = (HWND)the->m_hChildActiveWnd->get_hwnd(the->m_hChildActiveWnd);

			ShowWindow(h_child_wnd,SW_HIDE);

			i_err = STX_OK;

		}while(FALSE);

		SAFE_XDELETE(p);

		return i_err;

	}

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT on_lbtn_dbclick
(app_wnd* the,size_t i_wparam,size_t i_lparam)
{
	// maximize / restore window;
	ControlFullScreenMode(the);

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT on_rbtn_down
(app_wnd* the,size_t i_wparam,size_t i_lparam)
{
	STX_RESULT		i_err;
	s32				i_caps;
	s32             i_status;
	POINT			pot;
	HMENU			hMain;

	i_err = STX_FAIL;
	hMain = NULL;

	GetCursorPos(&pot);

	i_caps = (s32)the->theGraphEdit->cmd(the->theGraphEdit,STXM_GET_CAPS,0,0);
	i_status = (s32)the->theGraphEdit->cmd(the->theGraphEdit,STXM_GET_STATUS,0,0);

	// create/tack main menu;

	do{
		hMain = CreatePopupMenu();
		if( !hMain ) {
			break;
		}

		InsertMenu(hMain, 0, MF_BYPOSITION, WM_PLAY,"play");
		InsertMenu(hMain, 1, MF_BYPOSITION, WM_PAUSE,"pause");
		InsertMenu(hMain, 2, MF_BYPOSITION, WM_RESUME,"resume");
		InsertMenu(hMain, 3, MF_BYPOSITION, WM_STOP,"stop");

		if( i_caps & CTL_CAPS_PLAY_STOP ) {
			EnableMenuItem(hMain , WM_PLAY , MF_ENABLED);
			EnableMenuItem(hMain , WM_STOP , MF_ENABLED);
		}
		else{
			EnableMenuItem(hMain , WM_PLAY , MF_DISABLED);
			EnableMenuItem(hMain , WM_STOP , MF_DISABLED);
		}

		if( i_status == emStxStatusInit || i_status == emStxStatusStop ) {
			EnableMenuItem(hMain , WM_PLAY , MF_ENABLED);
			EnableMenuItem(hMain , WM_STOP , MF_DISABLED);
		}
		else{
			EnableMenuItem(hMain , WM_PLAY , MF_DISABLED);
			EnableMenuItem(hMain , WM_STOP , MF_ENABLED);
		}

		if( i_status == emStxStatusPause ) {
			EnableMenuItem(hMain , WM_RESUME , MF_ENABLED);
			EnableMenuItem(hMain , WM_PAUSE , MF_DISABLED);
		}
		else{
			EnableMenuItem(hMain , WM_RESUME , MF_DISABLED);
			EnableMenuItem(hMain , WM_PAUSE , MF_ENABLED);
		}

		{

			UINT wCmd = TrackPopupMenu(hMain, TPM_RETURNCMD|TPM_NONOTIFY, 
				pot.x, pot.y, 0, the->m_hWnd, NULL);

			the->theGraphEdit->cmd(the->theGraphEdit,STXM_WCMD,wCmd,0);
		}

		i_err = STX_OK;

	}while(FALSE);

	DestroyMenu(hMain);

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT on_move
(app_wnd* the,size_t i_wparam,size_t i_lparam)
{
	RECT dst_rect;

	GetClientRect(the->m_hWnd,&dst_rect);
	ClientRectToScreen(the->m_hWnd,&dst_rect);

	the->theGraphEdit->cmd(the->theGraphEdit,STXM_SET_DST_RECT,(size_t)&dst_rect,0);

	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE void decide_window_rect
(app_wnd* the,u32 i_aspect, b32 b_width_prefer,RECT* p_rect)
{
	int nx;
	int ny;
	int nc;

	RECT rect_scr;
	RECT rect_client;

	RECT rc = *p_rect;

	int nWidth = rc.right - rc.left;
	int nHeight = rc.bottom - rc.top;

	SIZE size = {0};

	GetClientRect(the->m_hWnd,&rect_client);
	ClientRectToScreen(the->m_hWnd, &rect_client);
	GetWindowRect(the->m_hWnd,&rect_scr);

	nx = rect_client.left - rect_scr.left;
	ny = rect_scr.bottom - rect_client.bottom;
	nc = rect_client.top - rect_scr.top;

	nWidth -= nx + nx;
	nHeight -= nc + ny;

	if( b_width_prefer ) {
		nHeight = GetHeightFromRatio(nWidth,i_aspect);
		if( nHeight < WND_MIN_HEIGHT ) {
			nHeight = WND_MIN_HEIGHT;
			nWidth = GetWidthFromRatio(nHeight,i_aspect);
		}
	}
	else {
		nWidth = GetWidthFromRatio(nHeight,i_aspect);
		if( nWidth < WND_MIN_WIDTH ) {
			nWidth = WND_MIN_WIDTH;
			nHeight = GetHeightFromRatio(nWidth,i_aspect);
		}
	}

	nWidth += nx + nx;
	nHeight += nc + ny;

	GetFullScreenSize(&size,FALSE);

	if( nWidth > size.cx ) {
		nWidth = size.cx - nx - nx;
		nHeight = GetHeightFromRatio(nWidth,i_aspect);
		nWidth += nx + nx;
		nHeight += nc + ny;
	}

	if( nHeight > size.cy ) {
		nHeight = size.cy - nc - ny;
		nWidth = GetWidthFromRatio(nHeight,i_aspect);
		nWidth += nx + nx;
		nHeight += nc + ny;
	}

	rc.right = rc.left + nWidth;
	rc.bottom = rc.top + nHeight;

	*p_rect = rc;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT on_sizing
(app_wnd* the,size_t i_wparam,size_t i_lparam)
{
	// check aspect ratio 
	RECT  wrect;
	DWORD dwSrcRatio;
	u32   nType = (u32)i_wparam;
	RECT* prect = (RECT*)i_lparam;


	dwSrcRatio = the->m_aspect_ratio;

	{
		BOOL bWidthPrefer = ( nType == WMSZ_RIGHT || nType == WMSZ_LEFT  ) ? TRUE:FALSE;

		RECT rc = *prect;

		decide_window_rect(the,dwSrcRatio,bWidthPrefer,&rc);

		*prect = rc;

		GetClientRect(the->m_hWnd,&wrect);
		InvalidateRect(the->m_hWnd,&wrect,TRUE);

		update_dst_rect(the);
	}

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT on_size
(app_wnd* the,size_t i_wparam,size_t i_lparam)
{
	switch(i_wparam){

	case SIZE_MAXIMIZED:
		the->m_bMaximizeScreen = TRUE;
		update_dst_rect(the);
		break;

	case SIZE_RESTORED:
		the->m_bMaximizeScreen = FALSE;
		update_dst_rect(the);
		the->theGraphEdit->cmd(the->theGraphEdit,STXM_SHOW_RENDER,TRUE,0);
		break;

	case SIZE_MINIMIZED:
		the->m_bMaximizeScreen = FALSE;
		the->theGraphEdit->cmd(the->theGraphEdit,STXM_SHOW_RENDER,FALSE,0);
		break;
	}

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE void  AdjustPlayWnd(app_wnd* the,u32 i_aspect)
{
	RECT WindowRect;

	GetClientRect(the->m_hWnd,&WindowRect);
	ClientRectToScreen(the->m_hWnd,&WindowRect);
	WindowRect.right = WindowRect.left + the->m_width;
	WindowRect.bottom = WindowRect.top + the->m_height;

	decide_window_rect(the,i_aspect,TRUE,&WindowRect);

	MoveWindow(the->m_hWnd,
		WindowRect.left,
		WindowRect.top,
		WindowRect.right - WindowRect.left,
		WindowRect.bottom - WindowRect.top,
		TRUE);

	GetClientRect(the->m_hWnd,&WindowRect);
	InvalidateRect(the->m_hWnd,&WindowRect,TRUE);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT on_aspect_ratio
(app_wnd* the,stx_base_message* p_msg)
{
	// 
	stx_msg_cnt* cnt;

	cnt = p_msg->get_msg_cnt(p_msg);

	the->m_width = (s32)cnt->param.i_param[0];
	the->m_height = (s32)cnt->param.i_param[1];
	the->m_aspect_ratio = (s32)cnt->param.i_param[2];

	if( the->m_bFullScreen || the->m_bMaximizeScreen ) {
		if( the->m_bFixAspectRatio && !the->m_force_aspect_ratio ) {
			update_dst_rect(the);
		}
	}
	else if( the->m_bFixAspectRatio && !the->m_force_aspect_ratio){
		AdjustPlayWnd(the,the->m_aspect_ratio);
		update_dst_rect(the);
	}

	p_msg->signal(p_msg);

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
this function calling from kernel thread -> video render task;
so wait for winthread adjust the aspect raio, and return;
***************************************************************************/
STX_PURE STX_RESULT stx_active_movie_wnd_vt_xxx_set_aspect_ratio
(STX_HANDLE h,u32 i_width,u32 i_height,u32 i_aspect)
{
	_MAP_THE;
	{
		STX_RESULT			i_err;
		stx_base_message*	p_msg;
		stx_msg_cnt*		p_cnt;

		do{

			p_msg = XCREATE(base_msg,NULL,NULL);
			if( !p_msg ) {
				break;
			}
			p_msg->set_msg_type(p_msg,STX_MSG_TYPE_ASYNC );
			p_cnt = p_msg->get_msg_cnt(p_msg);
			p_cnt->msg_gid = STX_MSG_AspectRatio;
			p_cnt->param.i_param[0] = i_width;
			p_cnt->param.i_param[1] = i_height;
			p_cnt->param.i_param[2] = i_aspect;

			PostMessage(the->m_hWnd,WM_ASPECT_RATIO,(WPARAM)p_msg,0);

			//p_msg->wait(p_msg);

			i_err = STX_OK;

		}while(FALSE);

		SAFE_XDELETE(p_msg);

		return i_err;

	}

	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE void stx_active_movie_wnd_vt_xxx_set_dst_rect
(STX_HANDLE h,STX_RECT dst_rect)
{
	_MAP_THE;
	{

	}
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RECT 
stx_active_movie_wnd_vt_xxx_get_dst_rect(STX_HANDLE h)
{
	_MAP_THE;
	{
		RECT rec;
		GetClientRect(the->m_hWnd,&rec);
		ClientRectToScreen(the->m_hWnd,&rec);
		return *(STX_RECT*)&rec;
	}
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE void stx_active_movie_wnd_vt_xxx_set_color_key
(STX_HANDLE h,u32 i_color_key)
{
	_MAP_THE;
	{
		the->m_dwColorKey = i_color_key;
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE u32 
stx_active_movie_wnd_vt_xxx_get_color_key(STX_HANDLE h)
{
	_MAP_THE;
	{
		return the->m_dwColorKey;
	}
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_HANDLE 
stx_active_movie_wnd_vt_xxx_get_hwnd(STX_HANDLE h)
{
	_MAP_THE;
	return (STX_HANDLE)the->m_hWnd;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE  STX_HANDLE 
stx_active_movie_wnd_vt_xxx_get_active_hwnd(STX_HANDLE h)
{
	_MAP_THE;
	return the->m_hChildActiveWnd->get_hwnd(the->m_hChildActiveWnd);
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_HANDLE 
stx_active_movie_wnd_vt_xxx_get_hinstance(STX_HANDLE h)
{
	_MAP_THE;
	{
		return the->m_hInstance;
	}
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_plugin_vt_xxx_run
(STX_HANDLE h,stx_sync_inf* h_sync)
{
	_MAP_THE;
	{
		s32 i_msg = 0;
		MSG message = {0};

		while(  PeekMessage (&message,the->m_hWnd,0,0,PM_REMOVE) ) {
		//while(  GetMessage (&message,the->m_hWnd,0,0) ) {
			TranslateMessage(&message); 
			DispatchMessage(&message);
			i_msg ++;
		}

		return i_msg ? STX_OK : STX_WOUNLD_BLOCK;
	}

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_plugin_vt_xxx_flush
(STX_HANDLE h,u32 i_flag,stx_sync_inf *h_sync)
{
	_MAP_THE;
	{
	}

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_plugin_vt_xxx_start
(STX_HANDLE h,u32 i_flag,stx_sync_inf *h_sync)
{
	_MAP_THE;
	{
		the->h_gbd = (stx_base_graph_builder*)h_sync->h_data;
		return STX_OK;
	}

}
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_plugin_vt_xxx_stop
(STX_HANDLE h,u32 i_flag,stx_sync_inf *h_sync)
{
	_MAP_THE;
	{
	}

	return STX_OK;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_plugin_vt_xxx_send_msg
(STX_HANDLE h,stx_base_message *p_msg)
{
	_MAP_THE;
	{
		return dispatch_msg(h,p_msg);
	}
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_plugin_vt_xxx_set_property
(STX_HANDLE h,stx_xio *h_xio)
{
	_MAP_THE;
	{
		// back ground file path name ???
		// auto fix aspect raito ???
		// top most ???
	}

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_plugin_vt_xxx_get_property
(STX_HANDLE h,stx_xio *h_xio)
{
	_MAP_THE;
	{
	}

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE void FixRectScale( RECT* lpDrect, DWORD dwWhratio)
{
	DWORD dheight = (lpDrect->bottom - lpDrect->top);
	DWORD dwidth = (lpDrect->right - lpDrect->left);
	DWORD dhwcoe = MAKE_LXRATIO(dwidth,dheight);

	if( dwWhratio < dhwcoe ) {
		// wide
		int ddw = dwidth - GetWidthFromRatio(dheight , dwWhratio) + 1;
		ddw >>= 1;
		lpDrect->left += ddw;
		lpDrect->right -= ddw;
	}
	else if( dwWhratio > dhwcoe ) {
		// narrow
		int ddh = dheight - GetHeightFromRatio(dwidth,dwWhratio)  + 1;
		ddh >>= 1;
		lpDrect->top += ddh;
		lpDrect->bottom -= ddh;
	}

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG STX_RESULT on_query_obj(STX_HANDLE h,stx_base_message* p_msg)
{
	_MAP_THE;
	{
		stx_gid			buf_iid;
		stx_msg_cnt*	cnt;
		s32				i_len;

		buf_iid = *(stx_gid*)p_msg->get_msg_buf(p_msg,&i_len);

		// ActiveMovieWindow
		if( IS_EQUAL_GID(STX_IID_ActiveMovieWindow,buf_iid) ) {

			the->m_hChildActiveWnd->add_ref(the->m_hChildActiveWnd);

			cnt = p_msg->get_msg_cnt(p_msg);

			cnt->param.i_param[0] = (size_t)the->m_hChildActiveWnd;

			p_msg->set_msg_close(p_msg);

			return STX_OK;

		} // if( IS_EQUAL_GID(STX_IID_ActiveMovieWindow,buf_iid) ) {

		return STX_OK;
	}
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG STX_RESULT on_play(STX_HANDLE h,stx_base_message* p_msg)
{
	_MAP_THE;
	{
		HWND h_child_wnd = (HWND)the->m_hChildActiveWnd->get_hwnd(the->m_hChildActiveWnd);
		ShowWindow(h_child_wnd,SW_SHOW);
	}
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG STX_RESULT on_stop(STX_HANDLE h,stx_base_message* p_msg)
{
	_MAP_THE;
	{
		HWND h_child_wnd = (HWND)the->m_hChildActiveWnd->get_hwnd(the->m_hChildActiveWnd);
		ShowWindow(h_child_wnd,SW_HIDE);
	}

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_ENTRY STX_RESULT 
at_BreakPin(STX_HANDLE h, stx_base_message* p_msg )
{
	_MAP_THE;
	{
		HWND h_child_wnd = (HWND)the->m_hChildActiveWnd->get_hwnd(the->m_hChildActiveWnd);
		ShowWindow(h_child_wnd,SW_HIDE);
	}
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE void ControlFullScreenMode(app_wnd* the)
{
	if(IsIconic(the->m_hWnd))	{
		ShowWindow(the->m_hWnd, SW_NORMAL);
		BringWindowToTop(the->m_hWnd);
		SetForegroundWindow(the->m_hWnd);
	}

	if(!the->m_bFullScreen ){
		FullScreenModeOn(the);
	}
	else{
		FullScreenModeOff(the);	
	}

	update_dst_rect(the);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE BOOL FullScreenModeOff(app_wnd* the)
{
	LONG style;

	if( the->m_bFullScreen)	{

		the->m_bFullScreen = FALSE;

		style = GetWindowLong(the->m_hWnd, GWL_STYLE);
		style |= WS_CAPTION ;
		style |= WS_BORDER ;
		style |= WS_THICKFRAME;

		SetWindowLong(the->m_hWnd, GWL_STYLE,style);

		MoveWindow(the->m_hWnd, the->m_rt.left, the->m_rt.top, 
			the->m_rt.right - the->m_rt.left, 
			the->m_rt.bottom - the->m_rt.top,
			TRUE);

		if( the->m_bTopMost ){
			SetWindowPos(the->m_hWnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE);
		}
		else{
			SetWindowPos(the->m_hWnd, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE);
		}

	}

	return TRUE;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE BOOL FullScreenModeOn(app_wnd* the)
{	
	LONG style;
	int nScreenCX = GetSystemMetrics(SM_CXSCREEN);
	int nScreenCY = GetSystemMetrics(SM_CYSCREEN);

	if(!the->m_bFullScreen){

		the->m_bFullScreen = TRUE;

		GetWindowRect(the->m_hWnd, &the->m_rt);

		//��ȥ���ڵı�����
		style = GetWindowLong(the->m_hWnd, GWL_STYLE);
		style &= ~WS_CAPTION ;
		style &= ~WS_BORDER ;
		style &= ~WS_THICKFRAME;
		SetWindowLong(the->m_hWnd, GWL_STYLE,style);

		SetWindowPos(the->m_hWnd, 
			HWND_NOTOPMOST, 
			0, 
			0,
			nScreenCX, 
			nScreenCY, 
			0);

		SetForegroundWindow(the->m_hWnd);
	}

	return TRUE;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE void update_dst_rect(app_wnd* the)
{
	HWND hnd;

	GetClientRect(the->m_hWnd,&the->m_dst_rect);

	if( the->m_bFixAspectRatio ) {
		if( the->m_force_aspect_ratio ) {
			FixRectScale(&the->m_dst_rect,the->m_force_aspect_ratio);
		}
		else{
			FixRectScale(&the->m_dst_rect,the->m_aspect_ratio);
		}
	}

	the->m_hChildActiveWnd->set_dst_rect(the->m_hChildActiveWnd,the->m_dst_rect);

	hnd = (HWND)the->m_hChildActiveWnd->get_hwnd(the->m_hChildActiveWnd);

	// 	{
	// 		RECT rc;
	// 		::GetWindowRect(hnd,&rc);
	// 		stx_log("left =%d, top = %d, right = %d, bottom =%d\r\n",
	// 			rc.left,rc.top,rc.right,rc.bottom);
	// 	}

	ClientRectToScreen(hnd,&the->m_dst_rect);

	the->theGraphEdit->cmd(the->theGraphEdit,STXM_SET_DST_RECT,(size_t)&the->m_dst_rect,0);
}










#endif // __WIN32_LIB