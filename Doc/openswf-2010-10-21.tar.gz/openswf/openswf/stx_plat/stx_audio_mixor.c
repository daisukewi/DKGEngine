
/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-11
***********************************************************************************/
#include "stdio.h"
#include "stdlib.h"
#include "fcntl.h"
#include "memory.h"
#include "string.h"
#include "assert.h"

#include "stx_os.h"
#include "stx_mem.h"
#include "stx_debug.h"

#include "stx_audio_mixor.h"

#include "stx_cpuid.h"



#define DM_PAR_COE_SHIFT  13
#define DM_PAR_COE        (1<<DM_PAR_COE_SHIFT)

DECLARE_ALIGNED_16(static s32,  mm_par_round[4]) =
{
	1<<(DM_PAR_COE_SHIFT-1),
	1<<(DM_PAR_COE_SHIFT-1),
	1<<(DM_PAR_COE_SHIFT-1),
	1<<(DM_PAR_COE_SHIFT-1)
};

DECLARE_ALIGNED_16(static s16, coe_2p2[4] ) = 
{ 
	(s16)(0.707*(1<<DM_PAR_COE_SHIFT)),
	0,
	(s16)(0.707*(1<<DM_PAR_COE_SHIFT)),
	0
};


DECLARE_ALIGNED_16(static s64, lx_msk_23t00[2])
={ 0x0000000000ffffff,0x0000000000ffffff };

DECLARE_ALIGNED_16(static s64, lx_msk_55t32[2])
={ 0x00ffffff00000000,0x00ffffff00000000 };

DECLARE_ALIGNED_16(static s64, msk_pcm_left) = 0x0000ffff0000ffff;


#define STX_ZOOM_SCALE		12
#define STX_ZOOM_SCALE24	(12-8)
#define STX_ZOOM_ROUND		(1<<(STX_ZOOM_SCALE-1))
#define STX_ZOOM_ROUND24	(1<<(STX_ZOOM_SCALE-1-8))

DECLARE_ALIGNED_16(static u32, lx_zoom_round[4])
={ STX_ZOOM_ROUND,STX_ZOOM_ROUND, STX_ZOOM_ROUND,STX_ZOOM_ROUND};

DECLARE_ALIGNED_16(static u32, lx_zoom_round24[4])
={ STX_ZOOM_ROUND24,STX_ZOOM_ROUND24, STX_ZOOM_ROUND24,STX_ZOOM_ROUND24};



// MM0 = ABS(MM0);
#define MM_PABSW(mm0,mm1,mm2,mm3) \
	__asm{\
	__asm movq   mm1,mm0      \
	__asm psraw  mm0,15       \
	__asm movq   mm2,mm1      \
	__asm pand   mm1,mm0      \
	__asm pxor   mm3,mm3      \
	__asm psubsw mm3,mm1      \
	__asm pandn  mm0,mm2      \
	__asm por    mm0,mm3      \
}

#define MM_MIN_SW(mm0,mm1,mm2,mm3) \
	__asm{\
	__asm movq       mm2,mm0                 \
	__asm pcmpgtw    mm0,mm1   /* mm0 max */ \
	__asm movq       mm3,mm0                 \
	__asm pand       mm3,mm1   /* mm1,min */ \
	__asm pandn      mm0,mm2   /* mm0,min */ \
	__asm por        mm0,mm3                 \
}

#define MM_MAX_SW(mm0,mm1,mm2,mm3) \
	__asm{\
	__asm movq       mm2,mm0                 \
	__asm pcmpgtw    mm0,mm1   /* mm0 max */ \
	__asm movq       mm3,mm0                 \
	__asm pandn      mm3,mm1   /* mm1,min */ \
	__asm pand       mm0,mm2   /* mm0,min */ \
	__asm por        mm0,mm3                 \
}

STX_PURE void      convert_6p1_to_7p1	(STX_HANDLE h,void* src,void* dst,s32 nLen,s32 nFlags );
STX_PURE void      convert_5p1_to_7p1	(STX_HANDLE h,void* src,void* dst,s32 nLen,s32 nFlags );
STX_PURE void      convert_5p1_to_6p1	(STX_HANDLE h,void* src,void* dst,s32 nLen,s32 nFlags );
STX_PURE s32       MaximizeAbsPcmCh		(STX_HANDLE h,void* lpSrc,s32 nLen); 
STX_PURE void	   OutputPcm1T2			(STX_HANDLE h,void *lpSrc, void *lpDst, s32 nLen,StxAudMixFx* pfx);
STX_PURE void      OutputPcm2T2			(STX_HANDLE h,void* lpSrc[2], void* lpDst, s32 nLen,StxAudMixFx* pfx);
STX_PURE void      OutputPcm2T4			(STX_HANDLE h,void* lpSrc[2], void* lpDst, s32 nLen,StxAudMixFx* pfx);
STX_PURE void      OutputPcm2T6			(STX_HANDLE h,void* lpSrc[2], void* lpDst, s32 nLen,StxAudMixFx* pfx);
STX_PURE void      OutputPcm2p1T2		(STX_HANDLE h,void* lpSrc[3], void* lpDst, s32 nLen,StxAudMixFx* pfx);
STX_PURE void      OutputPcm2p1T4		(STX_HANDLE h,void* lpSrc[3], void* lpDst, s32 nLen,StxAudMixFx* pfx);
STX_PURE void      OutputPcm2p1T5p1		(STX_HANDLE h,void* lpSrc[3], void* lpDst, s32 nLen,StxAudMixFx* pfx);
STX_PURE void      OutputPcm3p0T2		(STX_HANDLE h,void* lpSrc[3], void* lpDst, s32 nLen,StxAudMixFx* pfx);
STX_PURE void      OutputPcm3p0T4		(STX_HANDLE h,void* lpSrc[3], void* lpDst, s32 nLen,StxAudMixFx* pfx);
STX_PURE void      OutputPcm3p0T5p1		(STX_HANDLE h,void* lpSrc[3], void* lpDst, s32 nLen,StxAudMixFx* pfx);
STX_PURE void      OutputPcm2p2T2		(STX_HANDLE h,void* lpSrc[4], void* lpDst, s32 nLen,StxAudMixFx* pfx);
STX_PURE void      OutputPcm2p2T4		(STX_HANDLE h,void* lpSrc[4], void* lpDst, s32 nLen,StxAudMixFx* pfx);
STX_PURE void      OutputPcm2p2T5p1		(STX_HANDLE h,void* lpSrc[4], void* lpDst, s32 nLen,StxAudMixFx* pfx);
STX_PURE void      OutputPcm3p1T2		(STX_HANDLE h,void* lpSrc[4], void* lpDst, s32 nLen,StxAudMixFx* pfx);
STX_PURE void      OutputPcm3p1T4		(STX_HANDLE h,void* lpSrc[4], void* lpDst, s32 nLen,StxAudMixFx* pfx);
STX_PURE void      OutputPcm3p1T5p1		(STX_HANDLE h,void* lpSrc[4], void* lpDst, s32 nLen,StxAudMixFx* pfx);
STX_PURE void      OutputPcm5p1T2		(STX_HANDLE h,void* lpSrc[6], void *lpDst, s32 nLen,StxAudMixFx* pfx);
STX_PURE void      OutputPcm5p1T4		(STX_HANDLE h,void* lpSrc[6], void *lpDst, s32 nLen,StxAudMixFx* pfx);
STX_PURE void      OutputPcm5p1T5p1		(STX_HANDLE h,void* lpSrc[6], void* lpDst, s32 nLen,StxAudMixFx* pfx);
STX_PURE void      OutputPcmCh5p1T6p1	(STX_HANDLE h,void* lpSrc, void* lpDst, s32 nLen,StxAudMixFx* pfx);
STX_PURE void      OutputPcmCh5p1T7p1	(STX_HANDLE h,void* lpSrc, void* lpDst, s32 nLen,StxAudMixFx* pfx);
STX_PURE void      OutputPcmCh6p1T7p1	(STX_HANDLE h,void* lpSrc, void* lpDst, s32 nLen,StxAudMixFx* pfx);
STX_PURE void      OutputPcm24			(STX_HANDLE h,void* lpSrc, void* lpDst, s32 nLen,StxAudMixFx* pfx);
STX_PURE void      OutputPcmPlain		(STX_HANDLE h,void* lpSrc, void* lpDst, s32 nLen,StxAudMixFx* pfx);
STX_PURE void      OutputPcmLeft		(STX_HANDLE h,void* lpSrc, void* lpDst, s32 nLen,StxAudMixFx* pfx);
STX_PURE void      OutputPcmRight		(STX_HANDLE h,void* lpSrc, void* lpDst, s32 nLen,StxAudMixFx* pfx);
STX_PURE void      audiomixor_close		(STX_HANDLE h);
STX_PURE void      audiomixor_reset		(STX_HANDLE h);

STX_PURE STX_RESULT audiomixor_transform
(
	STX_HANDLE			h,
	u8					*src,
	size_t				i_src_size,
	stx_media_data*		lpDst,
	StxAudMixFx*		pFx 
);


STX_PRIVATE 	void GetAllChannelsZoomRatio
(STX_HANDLE h,void** lpSrc,s32 nChannels,s32 nLen,StxAudMixFx* pFx);

typedef struct LxAudioMixorHnd{
	StxAudioMixor_vtdef()
	s32 m_nMaxVolume;
}LxAudioMixorHnd;


/***************************************************************************************
***************************************************************************************/
StxAudioMixor* CreateStxAudioMixor(u32 mmflags)
{
	DECL_TRACE
	LxAudioMixorHnd* the;

	MAKE_TRACE2
	the = (LxAudioMixorHnd*)smart_mallocz(sizeof(LxAudioMixorHnd),MAP_TRACE);
	if(!the) {
		return NULL;
	}

#define LOAD_VTBL(A) the->A = A
	LOAD_VTBL(convert_6p1_to_7p1);
	LOAD_VTBL(convert_5p1_to_7p1);
	LOAD_VTBL(convert_5p1_to_6p1);
	LOAD_VTBL(MaximizeAbsPcmCh		);
	LOAD_VTBL(OutputPcm1T2			);
	LOAD_VTBL(OutputPcm2T2			);
	LOAD_VTBL(OutputPcm2T4			);
	LOAD_VTBL(OutputPcm2T6			);
	LOAD_VTBL(OutputPcm2p1T2		);
	LOAD_VTBL(OutputPcm2p1T4		);
	LOAD_VTBL(OutputPcm2p1T5p1		);
	LOAD_VTBL(OutputPcm3p0T2		);
	LOAD_VTBL(OutputPcm3p0T4		);
	LOAD_VTBL(OutputPcm3p0T5p1		);
	LOAD_VTBL(OutputPcm2p2T2		);
	LOAD_VTBL(OutputPcm2p2T4		);
	LOAD_VTBL(OutputPcm2p2T5p1		);
	LOAD_VTBL(OutputPcm3p1T2		);
	LOAD_VTBL(OutputPcm3p1T4		);
	LOAD_VTBL(OutputPcm3p1T5p1		);
	LOAD_VTBL(OutputPcm5p1T2		);
	LOAD_VTBL(OutputPcm5p1T4		);
	LOAD_VTBL(OutputPcm5p1T5p1		);
	LOAD_VTBL(OutputPcmCh5p1T6p1	);
	LOAD_VTBL(OutputPcmCh5p1T7p1	);
	LOAD_VTBL(OutputPcmCh6p1T7p1	);
	LOAD_VTBL(OutputPcm24			);
	LOAD_VTBL(OutputPcmPlain		);
	LOAD_VTBL(OutputPcmLeft			);
	LOAD_VTBL(OutputPcmRight		);
	LOAD_VTBL(audiomixor_close		);
	LOAD_VTBL(audiomixor_reset		);
	LOAD_VTBL(audiomixor_transform);
#undef LOAD_VTBL

	return (StxAudioMixor*)the;
}



/***************************************************************************************
***************************************************************************************/
void audiomixor_close(STX_HANDLE h)
{
	stx_free(h);
}


/***************************************************************************************
***************************************************************************************/
void audiomixor_reset  (STX_HANDLE h)
{
	((LxAudioMixorHnd*)h)->m_nMaxVolume = 0;
}



/***************************************************************************************
***************************************************************************************/
STX_RESULT audiomixor_transform
(
	STX_HANDLE			h,
	u8					*src,
	size_t				i_src_size,
	stx_media_data*		lpDst,
	StxAudMixFx*		pFx 
)
{
	STX_RESULT i_err;

	STX_DIRECT_THE(LxAudioMixorHnd);
	{
		u8		*dst;
		void**  ppsrc;

		size_t  i_dst_size;
		size_t  i_sample;

		i_sample = i_src_size / (pFx->wex.Format.nChannels*pFx->wex.Format.nBlockAlign);

		// get data pointer;
		switch(pFx->dwOutput)
		{

		case aout_dtype_8ch_7point1_16bit_pcm:
			if( pFx->dwInput == aout_dtype_6ch_5point1_16bit_pcm ) 	{       // dvd;	
				i_dst_size = i_src_size*8/6;
			}
			else if( pFx->dwInput == aout_dtype_7ch_6point1_16bit_pcm )	{   // have not example;	
				i_dst_size = i_src_size*8/7;
			}
			else if( pFx->dwInput == pFx->dwOutput ){ 
				i_dst_size = i_src_size;
			}
			else{
				return STX_FAIL;
			}
			break;

		case aout_dtype_7ch_6point1_16bit_pcm:
			if( pFx->dwInput == aout_dtype_6ch_5point1_16bit_pcm ){
				i_dst_size = i_src_size*7/6;
			}
			else if( pFx->dwInput == pFx->dwOutput ){
				i_dst_size = i_src_size;
			}
			else{
				return STX_FAIL;
			}
			break;

		case aout_dtype_2ch_stereo_16bit_pcm_left:
			if( pFx->dwInput == pFx->dwOutput ){
				i_dst_size = i_src_size;
			}
			else{
				return STX_FAIL;
			}
			break;

		case aout_dtype_2ch_stereo_16bit_pcm_right:
			if( pFx->dwInput == pFx->dwOutput ){
				i_dst_size = i_src_size;
			}
			else{
				return STX_FAIL;
			}
			break;

		case aout_dtype_2ch_stereo_16bit_pcm:
			if( pFx->dwInput == pFx->dwOutput ){
				i_dst_size = i_src_size;
			}
			else if( pFx->dwInput == STX_CT ) {
				i_dst_size = i_src_size * 2;
			}
			else{
				return STX_FAIL;
			}
			break;

		case aout_dtype_4ch_quad_16bit_pcm:
		case aout_dtype_6ch_5point1_16bit_pcm:
		default:
			if( pFx->dwInput == pFx->dwOutput ){
				i_dst_size = i_src_size;
			}
			else{
				return STX_FAIL;
			}
			break;

		}

		// check dst size;
		if( lpDst->get_buf(lpDst,&dst) < i_dst_size ) {
			i_err = lpDst->resize(lpDst,i_dst_size);
			if( STX_OK != i_err ) {
				return i_err;
			}
		}

		lpDst->set_data(lpDst,dst,i_dst_size);

		i_err = lpDst->get_data(lpDst,&dst,&i_dst_size);
		if( STX_OK != i_err ) {
			return i_err;
		}

		ppsrc = &src;
		GetAllChannelsZoomRatio(h,ppsrc,1,(s32)i_sample,pFx);

		switch(pFx->dwOutput)
		{

		case aout_dtype_8ch_7point1_16bit_pcm:
			if( pFx->dwInput == aout_dtype_6ch_5point1_16bit_pcm ) 	{       // dvd;	
				the->convert_5p1_to_7p1(h,src,dst,(s32)i_sample, (s32) pFx->nZoomRatio[0] ); 
			}
			else if( pFx->dwInput == aout_dtype_7ch_6point1_16bit_pcm )	{   // have not example;	
				the->convert_6p1_to_7p1(h,src,dst,(s32)i_sample, (s32) pFx->nZoomRatio[0] );
			}
			else if( pFx->dwInput == pFx->dwOutput ){ 
				the->OutputPcmPlain(h,src,dst,(s32)i_sample,pFx);                  // evd;
			}
			break;

		case aout_dtype_7ch_6point1_16bit_pcm:
			if( pFx->dwInput == aout_dtype_6ch_5point1_16bit_pcm ){
				the->convert_5p1_to_6p1(h,src,dst,(s32)i_sample, (s32) pFx->nZoomRatio[0] );
			}
			else if( pFx->dwInput == pFx->dwOutput ){
				the->OutputPcmPlain(h,src,dst,(s32)i_sample,pFx);                  // evd;
			}
			break;

		case aout_dtype_2ch_stereo_16bit_pcm_left:
			if( pFx->dwInput == pFx->dwOutput ){
				the->OutputPcmLeft(h,src,dst,(s32)i_sample,pFx);
			}
			break;

		case aout_dtype_2ch_stereo_16bit_pcm_right:
			if( pFx->dwInput == pFx->dwOutput ){
				the->OutputPcmRight(h,src,dst,(s32)i_sample,pFx);
			}
			break;

		case aout_dtype_2ch_stereo_16bit_pcm:
			if( pFx->dwInput == pFx->dwOutput ){
				the->OutputPcmPlain(h,src,dst,(s32)i_sample,pFx);
			}
			else if( pFx->dwInput == STX_CT ) {
				the->OutputPcm1T2(h,src,dst,(s32)i_sample,pFx);
			}
			break;

		case aout_dtype_4ch_quad_16bit_pcm:
		case aout_dtype_6ch_5point1_16bit_pcm:
		default:
			if( pFx->dwInput == pFx->dwOutput ){
				the->OutputPcmPlain(h,src,dst,(s32)i_sample,pFx);
			}
			break;

		}

		return STX_OK;

	}

}



/***************************************************************************************
***************************************************************************************/
static void GetAllChannelsZoomRatio
(STX_HANDLE h,void** lpSrc,s32 nChannels,s32 nLen,StxAudMixFx* pFx)
{
	s32 i;

	s32 nMax;

	LxAudioMixorHnd* const hnd = (LxAudioMixorHnd*)h;

	pFx->nZoomRatio[0] = pFx->nZoomRatio[1] = 
		pFx->nZoomRatio[2] = pFx->nZoomRatio[3] = STX_ZOOM_ROUND*2 ;

	if( pFx->dwEffects & LX_AUDMIXFX_ZOOM ) {

		// nZoomRatio not exist;
		nMax = 0;

		for( i = 0; i < nChannels; i ++ ){
			s32 nTemp = hnd->MaximizeAbsPcmCh( hnd,lpSrc[i],nLen );

			if ( nTemp > nMax ){
				nMax = nTemp;
			}
		}

		hnd->m_nMaxVolume = nMax > hnd->m_nMaxVolume ? nMax : hnd->m_nMaxVolume;
#if 0
		if( hnd->m_nMaxVolume < 8192){
			pFx->nZoomRatio[0] = pFx->nZoomRatio[1] = 
				pFx->nZoomRatio[2] = pFx->nZoomRatio[3] = 2;
		}
		else if( hnd->m_nMaxVolume < 16384 ){
			pFx->nZoomRatio[0] = pFx->nZoomRatio[1] = 
				pFx->nZoomRatio[2] = pFx->nZoomRatio[3] = 1;
		}
#else
		if( hnd->m_nMaxVolume < 8192){
			pFx->nZoomRatio[0] = pFx->nZoomRatio[1] = 
				pFx->nZoomRatio[2] = pFx->nZoomRatio[3] = 32767;  // max ~4 times;
		}
		else {
			pFx->nZoomRatio[0] = pFx->nZoomRatio[1] = 
				pFx->nZoomRatio[2] = pFx->nZoomRatio[3] = 32767*8192 / hnd->m_nMaxVolume ;
		}
#endif

	}

}



/***************************************************************************************
***************************************************************************************/
void OutputPcm24
(	
	STX_HANDLE		h,
	void*			lpSrc, 
	void*			lpDst, 
	s32				nLen,
	StxAudMixFx*	pfx
)
{
#if !defined(STX64) && defined(__WIN32_LIB)
	__asm
	{
		mov         eax,[pfx]
		mov         esi,[lpSrc]
		mov         edi,[lpDst]
		mov         ecx,[nLen]
		movq        mm7,[eax]StxAudMixFx.nZoomRatio  //

next_group_data:

		movq        mm0,[esi]      // sw0 ct0 rf0 lf0;
		movq        mm6,[lx_zoom_round24]
		pxor        mm4,mm4        // zero;
		movq        mm1,mm0        // dup;
		punpcklwd   mm0,mm4        // rf0 lf0;
		punpckhwd   mm1,mm4        // sw0 ct0;
		pmaddwd     mm0,mm7
		pmaddwd     mm1,mm7			// zoom;
		paddd       mm0,mm6
		paddd       mm1,mm6
		psrad       mm0,STX_ZOOM_SCALE24
		psrad       mm1,STX_ZOOM_SCALE24			// 12-8 ; 24 bits expand;

		movq        mm6,[lx_msk_23t00]
		movq        mm5,[lx_msk_55t32]

		movq        mm2,mm0        // dup;
		pand        mm0,mm6        // 24bit lf0;
		pand        mm2,mm5        // 24bit rf0;
		movq        mm3,mm1        // dup;
		pand        mm1,mm6        // 24bit ct0;
		pand        mm3,mm5        // 24bit sw0;
		psrlq       mm2,8          // rf0 -- 0000 bbbb bb00 0000;
		psrlq       mm3,8          // sw0 -- 0000 dddd dd00 0000;
		por         mm0,mm2        // 0000 bbbb bbaa aaaa;
		por         mm1,mm3        // 0000 dddd ddcc cccc;

		movq        mm5,mm0        // save;
		movq        mm6,mm1        // save;

		movq        mm0,[esi+8]    // rf1 lf1 rs0 ls0;
		psllw       mm0,mm7        // zoom;
		pxor        mm4,mm4        // zero;
		movq        mm1,mm0        // dup;
		punpcklwd   mm0,mm4        // rs0 ls0;
		punpckhwd   mm1,mm4        // rf1 lf1;
		pslld       mm0,8          // 24 bits expand;
		pslld       mm1,8          // 24 bits expand;
		movq        mm2,mm0        // dup;
		pand        mm0,[lx_msk_23t00 ]      // 24bit ls0;
		pand        mm2,[lx_msk_55t32 ]      // 24bit rs0;
		movq        mm3,mm1        // dup;
		pand        mm1,[lx_msk_23t00 ]      // 24bit lf1;
		pand        mm3,[lx_msk_55t32 ]      // 24bit rf1;
		psrlq       mm2,8          // rs0 -- 0000 ffff ff00 0000;
		psrlq       mm3,8          // rf1 -- 0000 BBBB BB00 0000;
		por         mm0,mm2        // 0000 ffff ffee eeee;
		por         mm1,mm3        // 0000 BBBB BBAA AAAA;

		movq        mm4,mm6        // dup 0000 dddd ddcc cccc;
		psllq       mm6,48         // cccc 0000 0000 0000;
		psllq       mm1,16         // BBBB BBAA AAAA 0000;
		por         mm5,mm6        // cccc bbbb bbaa aaaa; p0;
		psrlq       mm4,16         // 0000 0000 dddd ddcc
		movq        [edi],mm5      // output p0;
		movq        mm5,mm0        // dup 0000 ffff ffee eeee;
		psllq       mm0,32         // ffee eeee 0000 0000;
		add         esi,16
		por         mm4,mm0        // ffee eeee ddcc cccc ; p1;
		psrlq       mm5,32         // 0000 0000 0000 ffff;
		movq        [edi+8],mm4    // output p1;
		por         mm5,mm1        // BBBB BBAA AAAA ffff; p2;
		add         edi,24
		sub         ecx,16
		movq        [edi-8],mm5    // output p2;

		ja          next_group_data

		emms
	}
#endif // #ifndef STX64
}


/***************************************************************************************
***************************************************************************************/
void OutputPcmCh5p1T6p1
(
	STX_HANDLE		h,
	void*			lpSrc, 
	void*			lpDst, 
	s32				nLen,
	StxAudMixFx*	pfx
)
{
#if !defined(STX64) && defined(__WIN32_LIB)
	s32 temp[32];

	__asm
	{
		mov         eax,[pfx]
		mov         esi,[lpSrc]
		mov         edi,[lpDst]
		mov         ecx,[nLen]
		movq        mm7,[eax]StxAudMixFx.nZoomRatio  //

		lea         edx,[temp]
		add         edx,15
		and         edx,~0x0f

next_group_data:

		movq        mm0,[esi]      // sw0 ct0 rf0 lf0;
		movq        mm6,[lx_zoom_round24]
		pxor        mm4,mm4        // zero;
		movq        mm1,mm0        // dup;
		punpcklwd   mm0,mm4        // rf0 lf0;
		punpckhwd   mm1,mm4        // sw0 ct0;
		pmaddwd     mm0,mm7
		pmaddwd     mm1,mm7			// zoom;
		paddd       mm0,mm6
		paddd       mm1,mm6
		psrad       mm0,4
		psrad       mm1,4			// 12-8 ; 24 bits expand;

		movq        mm5,[lx_msk_55t32]
		movq        mm6,[lx_msk_23t00]

		movq        mm2,mm0        // dup;
		pand        mm0,mm6        // 24bit lf0;
		pand        mm2,mm5        // 24bit rf0;
		movq        mm3,mm1        // dup;
		pand        mm1,mm6        // 24bit ct0;
		pand        mm3,mm5        // 24bit sw0;
		psrlq       mm2,8          // rf0 -- 0000 bbbb bb00 0000;
		psrlq       mm3,8          // sw0 -- 0000 dddd dd00 0000;
		por         mm0,mm2        // 0000 bbbb bbaa aaaa;
		por         mm1,mm3        // 0000 dddd ddcc cccc;

		movq        [edx],mm0      // save;
		movq        [edx+8],mm1    // save;

		movq        mm0,[esi+8]    // sw0 ct0 rf0 lf0;
		psllw       mm0,mm7        // zoom;
		pxor        mm4,mm4        // zero;
		movq        mm1,mm0        // dup;
		punpcklwd   mm0,mm4        // rs0 ls0;
		punpckhwd   mm1,mm4        // rf1 lf1;

		movq        [edx+48],mm0   // save rs0,ls0;

		pslld       mm0,8          // 24 bits expand;
		pslld       mm1,8          // 24 bits expand;
		movq        mm2,mm0        // dup;
		pand        mm0,mm6        // 24bit lf0;
		pand        mm2,mm5        // 24bit rf0;
		movq        mm3,mm1        // dup;
		pand        mm1,mm6        // 24bit ct0;
		pand        mm3,mm5        // 24bit sw0;
		psrlq       mm2,8          // rf0 -- 0000 bbbb bb00 0000;
		psrlq       mm3,8          // sw0 -- 0000 dddd dd00 0000;
		por         mm0,mm2        // 0000 ffff ffee eeee;
		por         mm1,mm3        // 0000 BBBB BBAA AAAA;

		movq        [edx+16],mm0      // save;
		movq        [edx+24],mm1      // save;

		movq        mm0,[esi+16]   // sw0 ct0 rf0 lf0;
		psllw       mm0,mm7        // zoom;
		pxor        mm4,mm4        // zero;
		movq        mm1,mm0        // dup;
		punpcklwd   mm0,mm4        // sw1 ct1;
		punpckhwd   mm1,mm4        // rs1 ls1;
		pslld       mm0,8          // 24 bits expand;

		movq        [edx+56],mm1   // save rs1 ls1;

		pslld       mm1,8          // 24 bits expand;
		movq        mm2,mm0        // dup;
		pand        mm0,mm6        // 24bit lf0;
		pand        mm2,mm5        // 24bit rf0;
		movq        mm3,mm1        // dup;
		pand        mm1,mm6        // 24bit ct0;
		pand        mm3,mm5        // 24bit sw0;
		psrlq       mm2,8          // rf0 -- 0000 bbbb bb00 0000;
		psrlq       mm3,8          // sw0 -- 0000 dddd dd00 0000;
		por         mm0,mm2        // 0000 bbbb bbaa aaaa;
		por         mm1,mm3        // 0000 dddd ddcc cccc;

		movq        [edx+32],mm0      // save;
		movq        [edx+40],mm1      // save;

		movq        mm0,[edx+48]  // rs0 ls0;
		movq        mm1,[edx+56]  // rs1 ls1;
		movq        mm2,mm0
		punpckldq   mm0,mm1       // ls1 ls0;
		punpckhdq   mm2,mm1       // rs1 rs0;

		// sign expand;
		pslld       mm0,16
		pslld       mm2,16
		psrad       mm0,16
		psrad       mm2,16

		paddd       mm0,mm2       // 
		psrad       mm0,1         // cs1 cs0;
		pslld       mm0,8         // 24bits ex;
		movq        mm1,mm0
		pand        mm0,mm6       // 0000 0000 00gg gggg;
		pand        mm1,mm5       // 00GG GGGG 0000 0000;

		//		movq        [edx+48],mm0      // save;
		//		movq        [edx+56],mm1      // save;

		movq        mm5,[edx]      // 0000 bbbb bbaa aaaa;
		movq        mm6,[edx+8]    // 0000 dddd ddcc cccc;
		movq        mm2,[edx+16]   // 0000 ffff ffee eeee;

		psllq       mm0,16         // 0000 00gg gggg 0000;
		movq        mm4,mm6        // dup 0000 dddd ddcc cccc;
		psllq       mm6,48         // cccc 0000 0000 0000;
		movq        mm3,mm2        // dup 0000 ffff ffee eeee;
		por         mm5,mm6        // cccc bbbb bbaa aaaa; p0;
		psrlq       mm4,16         // 0000 0000 dddd ddcc
		movq        [edi],mm5      // output p0;
		psllq       mm2,32         // ffee eeee 0000 0000;
		psrlq       mm3,32         // 0000 0000 0000 ffff;
		por         mm2,mm4        // ffee eeee dddd ddcc  p1;
		por         mm0,mm3        // 0000 00gg gggg ffff;
		movq        [edi+8],mm2    // out p1;

		movq        mm3,[edx+24]   // 0000 BBBB BBAA AAAA;
		movq        mm4,[edx+32]   // 0000 DDDD DDCC CCCC;
		movq        mm5,mm3        // dup;
		psllq       mm3,40         // AAAA AA00 0000 0000;
		movq        mm6,mm4
		por         mm0,mm3        // AAAA AAgg gggg ffff; p2; 
		psrlq       mm5,24         // 0000 0000 00BB BBBB;
		movq        [edi+16],mm0   // out p2;
		psllq       mm4,24         // DDDD CCCC CC00 0000;
		psrlq       mm6,40         // 0000 0000 0000 00DD;
		por         mm4,mm5        // DDDD CCCC CCBB BBBB; p3;
		movq        mm0,[edx+40]   // 0000 FFFF FFEE EEEE;
		movq        [edi+24],mm4   // out p3;
		psllq       mm0,8          // 00FF FFFF EEEE EE00;
		movq        mm2,mm1        // 00GG GGGG 0000 0000
		psllq       mm1,24         // GG00 0000 0000 0000;
		psrlq       mm2,40         // 0000 0000 0000 GGGG;
		por         mm0,mm6        // 00FF FFFF EEEE EEDD;
		por         mm0,mm1        // GGFF FFFF EEEE EEDD; p4;

		movq        [edx+64],mm2   // save r0;

		movq        [edi+32],mm0   // out p4;

		movq        mm6,[lx_msk_23t00]
		movq        mm5,[lx_msk_55t32]

		movq        mm0,[esi+24]      // sw0 ct0 rf0 lf0;
		psllw       mm0,mm7        // zoom;
		pxor        mm4,mm4        // zero;
		movq        mm1,mm0        // dup;
		punpcklwd   mm0,mm4        // rf0 lf0;
		punpckhwd   mm1,mm4        // sw0 ct0;
		pslld       mm0,8          // 24 bits expand;
		pslld       mm1,8          // 24 bits expand;
		movq        mm2,mm0        // dup;
		pand        mm0,mm6        // 24bit lf0;
		pand        mm2,mm5        // 24bit rf0;
		movq        mm3,mm1        // dup;
		pand        mm1,mm6        // 24bit ct0;
		pand        mm3,mm5        // 24bit sw0;
		psrlq       mm2,8          // rf0 -- 0000 bbbb bb00 0000;
		psrlq       mm3,8          // sw0 -- 0000 dddd dd00 0000;
		por         mm0,mm2        // 0000 bbbb bbaa aaaa;
		por         mm1,mm3        // 0000 dddd ddcc cccc;

		movq        [edx],mm0      // save;
		movq        [edx+8],mm1    // save;

		movq        mm0,[esi+32]    // sw0 ct0 rf0 lf0;
		psllw       mm0,mm7        // zoom;
		pxor        mm4,mm4        // zero;
		movq        mm1,mm0        // dup;
		punpcklwd   mm0,mm4        // rs0 ls0;
		punpckhwd   mm1,mm4        // rf1 lf1;

		movq        [edx+48],mm0   // save rs0,ls0;

		pslld       mm0,8          // 24 bits expand;
		pslld       mm1,8          // 24 bits expand;
		movq        mm2,mm0        // dup;
		pand        mm0,mm6        // 24bit lf0;
		pand        mm2,mm5        // 24bit rf0;
		movq        mm3,mm1        // dup;
		pand        mm1,mm6        // 24bit ct0;
		pand        mm3,mm5        // 24bit sw0;
		psrlq       mm2,8          // rf0 -- 0000 bbbb bb00 0000;
		psrlq       mm3,8          // sw0 -- 0000 dddd dd00 0000;
		por         mm0,mm2        // 0000 ffff ffee eeee;
		por         mm1,mm3        // 0000 BBBB BBAA AAAA;

		movq        [edx+16],mm0      // save;
		movq        [edx+24],mm1      // save;

		movq        mm0,[esi+40]   // sw0 ct0 rf0 lf0;
		psllw       mm0,mm7        // zoom;
		pxor        mm4,mm4        // zero;
		movq        mm1,mm0        // dup;
		punpcklwd   mm0,mm4        // sw1 ct1;
		punpckhwd   mm1,mm4        // rs1 ls1;
		pslld       mm0,8          // 24 bits expand;

		movq        [edx+56],mm1   // save rs1 ls1;

		pslld       mm1,8          // 24 bits expand;
		movq        mm2,mm0        // dup;
		pand        mm0,mm6        // 24bit lf0;
		pand        mm2,mm5        // 24bit rf0;
		movq        mm3,mm1        // dup;
		pand        mm1,mm6        // 24bit ct0;
		pand        mm3,mm5        // 24bit sw0;
		psrlq       mm2,8          // rf0 -- 0000 bbbb bb00 0000;
		psrlq       mm3,8          // sw0 -- 0000 dddd dd00 0000;
		por         mm0,mm2        // 0000 bbbb bbaa aaaa;
		por         mm1,mm3        // 0000 dddd ddcc cccc;

		movq        [edx+32],mm0      // save;
		movq        [edx+40],mm1      // save;

		movq        mm0,[edx+48]  // rs0 ls0;
		movq        mm1,[edx+56]  // rs1 ls1;
		movq        mm2,mm0
		punpckldq   mm0,mm1       // ls1 ls0;
		punpckhdq   mm2,mm1       // rs1 rs0;

		// sign expand;
		pslld       mm0,16
		pslld       mm2,16
		psrad       mm0,16
		psrad       mm2,16

		paddd       mm0,mm2       // 
		psrad       mm0,1         // cs1 cs0;
		pslld       mm0,8         // 24bits ex;
		movq        mm1,mm0
		pand        mm0,mm6       // 0000 0000 00gg gggg;
		pand        mm1,mm5       // 00GG GGGG 0000 0000;

		movq        mm2,[edx+64]    // r0;  0000 0000 0000 GGGG;

		movq        mm3,[edx]       // 0000 bbbb bbaa aaaa;
		movq        mm4,[edx+16]    // 0000 ffff ffee eeee;
		psllq       mm3,16          // bbbb bbaa aaaa 0000;
		movq        mm5,mm4         // 0000 ffff ffee eeee;
		por         mm2,mm3         // bbbb bbaa aaaa GGGG; p5;
		psllq       mm4,48          // eeee 0000 0000 0000;
		movq        [edi+40],mm2    // out p5;
		psrlq       mm5,16          // 0000 0000 ffff ffee;
		por         mm4,[edx+8]     // eeee dddd ddcc cccc; p6;
		psllq       mm0,32          // 00gg gggg 0000 0000;
		movq        [edi+48],mm4    // out p6;
		por         mm0,mm5         // 00gg gggg ffff ffee;
		movq        mm2,[edx+24]    // 0000 BBBB BBAA AAAA;
		movq        mm3,[edx+32]    // 0000 DDDD DDCC CCCC;
		movq        mm4,mm2
		psllq       mm2,56          // AA00 0000 0000 0000;
		psrlq       mm4,8           // 0000 00BB BBBB AAAA;
		por         mm0,mm2         // AAgg gggg ffff ffee; p7;
		movq        mm5,mm3
		movq        [edi+56],mm0    // out p7;
		psllq       mm3,40          // CCCC CC00 0000 0000;
		psrlq       mm5,24          // 0000 0000 00DD DDDD;
		por         mm4,mm3         // CCCC CCBB BBBB AAAA; p8;
		movq        mm0,[edx+40]    // 0000 FFFF FFEE EEEE;
		movq        [edi+64],mm4    // out p8;
		movq        mm2,mm0
		psllq       mm0,24          // FFFF EEEE EE00 0000;
		psrlq       mm2,40          // 0000 0000 0000 00FF;
		por         mm0,mm5         // FFFF EEEE EEDD DDDD; p9;
		psrlq       mm1,24          // 0000 0000 GGGG GG00;
		movq        [edi+72],mm0    // out p9;
		por         mm1,mm2         // 0000 0000 GGGG GGFF; p9.5;
		add         esi,48
		add         edi,84          // 48 * 1.5 * (7/6);
		sub         ecx,48
		movd        [edi-4],mm1     // out 9.5;

		ja          next_group_data

		emms
	}
#endif
}


/***************************************************************************************
***************************************************************************************/
void OutputPcmCh6p1T7p1
(
	STX_HANDLE		h,
	void*			lpSrc, 
	void*			lpDst, 
	s32				nLen,
	StxAudMixFx*	pfx
)
{
#if !defined(STX64) && defined(__WIN32_LIB)
	// 12 - 16 - 24;
	s32 temp[32];

	__asm
	{
		push        ebx

		mov         eax,[pfx]
		mov         esi,[lpSrc]
		mov         edi,[lpDst]
		mov         ecx,[nLen]

		lea         edx,[temp]
		add         edx,0x0f
		and         edx,~0x0f

next_group_data:

		movq        mm0,[esi]        // sw0  ct0  rf0  lf0
		movq        mm1,[esi+8]      // lf1 ,ss0  rs0  ls0
		movq        mm2,[esi+16]     // ls1  sw1  ct1  rf1
		movq        mm3,[esi+24]     // rf2  lf2 ,ss1  rs1
		movq        mm4,[esi+32]     // rs2  ls2  sw2  ct2
		movq        mm5,[esi+40]     // ct3  rf3  lf3 ,ss2
		movq        mm6,[esi+48]     // ss3  rs3  ls3  sw3
		movq        mm7,mm1
		psllq       mm1,16
		movq        [edx],mm0      // sw   ct   rf   lf;         group 1a;
		psrlq       mm1,16         // 0000 ss   rs   ls;
		psrlq       mm7,48         // 0000 0000 0000 lf1
		movq        [edx+8],mm1    //                            group 1b;
		movq        mm1,mm2        // dup  ls1 sw1 ct1 rf1
		psllq       mm2,16         // sw1 ct1 rf1 0000
		por         mm2,mm7        // sw1 ct1 rf1 lf1   
		movq        mm0,mm3        // dup rf2 lf2 ss1 rs1
		psrlq       mm3,32         //     000 000 rf2 lf2;
		movq        [edx+16],mm2   //                            group 2a;
		psllq       mm0,32
		psrlq       mm1,48         //     000 000 000 ls1;
		psrlq       mm0,16         //     000 ss1 rs1 000;
		por         mm0,mm1        //     000 ss1 rs1 ls1;
		movq        mm2,mm4        // dup rs2 ls2 sw2 ct2;
		movq        [edx+24],mm0   //                            group 2b;
		psrlq       mm4,32         //     000 000 rs2 ls2;
		psllq       mm2,32         //     sw2 ct2 000 000;
		por         mm2,mm3        //     sw2 ct2 rf2 lf2;
		movq        mm0,mm5        // dup ct3 rf3 lf3 ss2;
		movq        [edx+32],mm2   //                            group 3a;
		psllq       mm0,48         //     ss2 000 000 000
		psrlq       mm5,16         //     000 ct3 rf3 lf3
		psrlq       mm0,16         //     000 ss2 000 000
		por         mm0,mm4        //     000 ss2 rs2 ls2;
		movq        mm1,mm6        // dup ss3 rs3 ls3 sw3;
		movq        [edx+40],mm0   //                            group 3b;
		psllq       mm6,48         //     sw3 000 000 000
		por         mm6,mm5        //     sw3 ct3 rf3 lf3;
		psrlq       mm1,16         //     000 ss3 rs3 ls3;
		movq        [edx+48],mm6   //                            group 4a;
		movq        [edx+56],mm1   //                            group 4b;

		xor         ebx,ebx

next_block_data:

		movq        mm0,[edx+ebx]      // sw0 ct0 rf0 lf0;

		movq        mm6,[lx_zoom_round]
		movq        mm7,[eax]StxAudMixFx.nZoomRatio  //
		pxor        mm4,mm4        // zero;
		movq        mm1,mm0        // dup;
		punpcklwd   mm0,mm4        // rf0 lf0;
		punpckhwd   mm1,mm4        // sw0 ct0;
		pmaddwd     mm0,mm7
		pmaddwd     mm1,mm7			// zoom;
		paddd       mm0,mm6
		paddd       mm1,mm6
		psrad       mm0,STX_ZOOM_SCALE
		psrad       mm1,STX_ZOOM_SCALE			// 
		packssdw    mm0,mm1

		movq        mm6,[lx_msk_23t00]
		movq        mm1,mm0        // dup;
		movq        mm5,[lx_msk_55t32]
		punpcklwd   mm0,mm4        // rf0 lf0;
		punpckhwd   mm1,mm4        // sw0 ct0;

		pslld       mm0,8          // 24 bits expand;
		pslld       mm1,8          // 24 bits expand;
		movq        mm2,mm0        // dup;
		pand        mm0,mm6        // 24bit lf0;
		pand        mm2,mm5        // 24bit rf0;
		movq        mm3,mm1        // dup;
		pand        mm1,mm6        // 24bit ct0;
		pand        mm3,mm5        // 24bit sw0;
		psrlq       mm2,8          // rf0 -- 0000 bbbb bb00 0000;
		psrlq       mm3,8          // sw0 -- 0000 dddd dd00 0000;

		por         mm0,mm2        // 0000 bbbb bbaa aaaa; mm0
		por         mm1,mm3        // 0000 dddd ddcc cccc; mm1;

		movq        mm3,[edx+ebx+8]    // 0000 gggg ffff eeee; s0 rs ls;

		//psllw       mm3,mm7         // zoom;
		pxor        mm7,mm7        // zero;
		movq        mm2,mm3        // dup;
		punpcklwd   mm3,mm7        // rf0 lf0;
		punpckhwd   mm2,mm7        // sw0 ct0;
		movq        mm7,[eax]StxAudMixFx.nZoomRatio  //
		pmaddwd     mm3,mm7
		pmaddwd     mm2,mm7			// zoom;
		movq        mm7,[lx_zoom_round]
		paddd       mm3,mm7
		paddd       mm2,mm7
		psrad       mm3,STX_ZOOM_SCALE
		psrad       mm2,STX_ZOOM_SCALE			// 
		packssdw    mm3,mm2

		pxor        mm2,mm2
		punpckhwd   mm2,mm3        // gggg 0000
		psrad       mm2,16         // signed, gggg gggg 0000 0000;
		pslld       mm2,8          // 24 bits expand;  00gg gg00 0000 0000;

		punpckhdq   mm2,mm2        // 00hh hh00 00gg gg00;
		movq        mm4,mm2
		pand        mm2,mm5        // 00hh hhhh 0000 0000;
		pand        mm4,mm6        // 0000 0000 00gg gggg;
		psrlq       mm2,8
		por         mm2,mm4        // 0000 hhhh hhgg gggg; mm2;

		pxor        mm4,mm4
		punpcklwd   mm3,mm4        // 0000 ffff 0000 eeee
		pslld       mm3,8          // 24 bit expand;
		movq        mm4,mm3        // dup;
		pand        mm3,mm6        // 0000 0000 00ee eeee;
		pand        mm4,mm5        // 00ff ffff 0000 0000;
		psrlq       mm4,8          // 0000 ffff ff00 0000;
		por         mm4,mm3        // 0000 ffff ffee eeee; mm4;

		movq        mm5,mm1        // 0000 dddd ddcc cccc;
		psllq       mm1,48         // cccc 0000 0000 0000;
		psrlq       mm5,16         // 0000 0000 dddd ddcc;
		por         mm0,mm1        // cccc bbbb bbaa aaaa; p0;
		movq        mm3,mm4
		movq        [edi],mm0      // out p0;
		psllq       mm4,32         // ffee eeee 0000 0000;
		por         mm4,mm5        // ffee eeee dddd ddcc; p1;
		psrlq       mm3,32         // 0000 0000 0000 ffff;
		movq        [edi+8],mm4    // out p1;
		psllq       mm2,16         // hhhh hhgg gggg 0000;
		add         edi,24
		add         ebx,16
		por         mm2,mm3        // hhhh hhgg gggg ffff; p2;
		cmp         ebx,64
		movq        [edi-8],mm2    // out p2;
		jl          next_block_data

		add         esi,56
		sub         ecx,56

		ja          next_group_data

		pop         ebx
		emms
	}
#endif 
}


/***************************************************************************************
***************************************************************************************/
void OutputPcmCh5p1T7p1
(
	STX_HANDLE		h,
	void*			lpSrc, 
	void*			lpDst, 
	s32				nLen,
	StxAudMixFx*	pfx
)
{
#if !defined(STX64) && defined(__WIN32_LIB)
	// 12 - 16 - 24;
	s32 temp[32];

	__asm
	{
		mov         eax,[pfx]
		mov         esi,[lpSrc]
		mov         edi,[lpDst]
		mov         ecx,[nLen]
		movq        mm7,[eax]StxAudMixFx.nZoomRatio  //

		lea         edx,[temp]
		add         edx,0x0f
		and         edx,~0x0f

next_group_data:

		movq        mm0,[esi]      // sw0 ct0 rf0 lf0;
		pxor        mm4,mm4        // zero;
		movq        mm1,mm0        // dup;
		punpcklwd   mm0,mm4        // rf0 lf0;
		punpckhwd   mm1,mm4        // sw0 ct0;
		pmaddwd     mm0,mm7
		pmaddwd     mm1,mm7			// zoom;
		movq        mm6,[lx_zoom_round]
		paddd       mm0,mm6
		paddd       mm1,mm6
		psrad       mm0,STX_ZOOM_SCALE
		psrad       mm1,STX_ZOOM_SCALE			// 
		packssdw    mm0,mm1

		movq        mm6,[lx_msk_23t00]
		movq        mm1,mm0        // dup;
		movq        mm5,[lx_msk_55t32]
		punpcklwd   mm0,mm4        // rf0 lf0;
		punpckhwd   mm1,mm4        // sw0 ct0;

		movq        [edx],mm0      // save;

		pslld       mm0,8          // 24 bits expand;
		pslld       mm1,8          // 24 bits expand;
		movq        mm2,mm0        // dup;
		pand        mm0,mm6        // 24bit lf0;
		pand        mm2,mm5        // 24bit rf0;
		movq        mm3,mm1        // dup;
		pand        mm1,mm6        // 24bit ct0;
		pand        mm3,mm5        // 24bit sw0;
		psrlq       mm2,8          // rf0 -- 0000 bbbb bb00 0000;
		psrlq       mm3,8          // sw0 -- 0000 dddd dd00 0000;

		por         mm0,mm2        // 0000 bbbb bbaa aaaa; mm0
		por         mm1,mm3        // 0000 dddd ddcc cccc; mm1;

		movq        mm2,[edx]      // 0000 bbbb 0000 aaaa;

		movd        mm3,[esi+8]    // 0000 0000 ffff eeee;
		pslld       mm2,16
		psllw       mm3,mm7        // zoom;
		psrad       mm2,16
		punpcklwd   mm4,mm3        // ffff 0000 eeee 0000;
		psrad       mm4,16         // signed,0000 ffff 0000 eeee ;
		paddd       mm4,mm2
		psrad       mm4,1          // hhhhhhhh gggggggg;
		pslld       mm4,8          // 24 bits expand;
		movq        mm2,mm4        // dup;
		pand        mm4,mm6        // 0000 0000 00gg gggg;
		pand        mm2,mm5        // 00hh hhhh 0000 0000;
		psrlq       mm2,8
		por         mm2,mm4        // 0000 hhhh hhgg gggg; mm2;

		pxor        mm4,mm4
		punpcklwd   mm3,mm4        // 0000 ffff 0000 eeee
		pslld       mm3,8          // 24 bit expand;
		movq        mm4,mm3        // dup;
		pand        mm3,mm6        // 0000 0000 00ee eeee;
		pand        mm4,mm5        // 00ff ffff 0000 0000;
		psrlq       mm4,8          // 0000 ffff ff00 0000;
		por         mm4,mm3        // 0000 ffff ffee eeee; mm4;

		movq        mm5,mm1        // 0000 dddd ddcc cccc;
		psllq       mm1,48         // cccc 0000 0000 0000;
		psrlq       mm5,16         // 0000 0000 dddd ddcc;
		por         mm0,mm1        // cccc bbbb bbaa aaaa; p0;
		movq        mm3,mm4
		movq        [edi],mm0      // out p0;
		psllq       mm4,32         // ffee eeee 0000 0000;
		por         mm4,mm5        // ffee eeee dddd ddcc; p1;
		psrlq       mm3,32         // 0000 0000 0000 ffff;
		movq        [edi+8],mm4    // out p1;
		psllq       mm2,16         // hhhh hhgg gggg 0000;
		add         edi,24
		por         mm2,mm3        // hhhh hhgg gggg ffff; p2;
		add         esi,12
		sub         ecx,12
		movq        [edi-8],mm2    // out p2;

		ja          next_group_data

		emms
	}
#endif
}

/***************************************************************************************
***************************************************************************************/
void OutputPcmRight
(STX_HANDLE h,void* lpSrc, void* lpDst, s32 nLen,StxAudMixFx* pfx)
{
#if !defined(STX64) && defined(__WIN32_LIB)
	__asm
	{
		mov         esi,[lpSrc]
		mov         edi,[lpDst]
		mov         eax,[pfx]
		mov         ecx,[nLen]
		movq        mm6,[lx_zoom_round]
		movd        mm7,[eax]StxAudMixFx.nZoomRatio  //

ccc:
		movq        mm0,[esi]
		movq        mm1,[esi+8]
		movq        mm2,[esi+16]
		movq        mm3,[esi+24]
		psrad       mm0,16
		psrad       mm1,16
		psrad       mm2,16
		psrad       mm3,16
		pmaddwd     mm0,mm7
		pmaddwd     mm1,mm7			// zoom;
		pmaddwd     mm2,mm7
		pmaddwd     mm3,mm7			// zoom;
		paddd       mm0,mm6
		paddd       mm1,mm6
		paddd       mm2,mm6
		paddd       mm3,mm6
		psrad       mm0,STX_ZOOM_SCALE
		psrad       mm1,STX_ZOOM_SCALE			// 
		psrad       mm2,STX_ZOOM_SCALE
		psrad       mm3,STX_ZOOM_SCALE			// 
		packssdw    mm0,mm1
		packssdw    mm2,mm3
		movq        mm1,mm0
		movq        mm3,mm2
		punpcklwd   mm0,mm0
		punpckhwd   mm1,mm1
		punpcklwd   mm2,mm2
		punpckhwd   mm3,mm3

		movq        [edi],mm0
		movq        [edi+8],mm1
		movq        [edi+16],mm2
		movq        [edi+24],mm3
		add         esi,32
		add         edi,32
		sub         ecx,32
		ja          ccc

		emms
	}
#endif
}



/***************************************************************************************
***************************************************************************************/
void OutputPcmLeft
(STX_HANDLE h,void* lpSrc, void* lpDst, s32 nLen,StxAudMixFx* pfx)
{
#if !defined(STX64) && defined(__WIN32_LIB)

	__asm
	{
		mov         esi,[lpSrc]
		mov         edi,[lpDst]
		mov         eax,[pfx]
		mov         ecx,[nLen]
		movq        mm5,[lx_zoom_round]
		movq        mm6,[msk_pcm_left]
		movd        mm7,[eax]StxAudMixFx.nZoomRatio  //

ccc:
		movq        mm0,[esi]
		movq        mm1,[esi+8]
		movq        mm2,[esi+16]
		movq        mm3,[esi+24]
		pmaddwd     mm0,mm7
		pmaddwd     mm1,mm7			// zoom;
		pmaddwd     mm2,mm7
		pmaddwd     mm3,mm7			// zoom;
		paddd       mm0,mm5
		paddd       mm1,mm5
		paddd       mm2,mm5
		paddd       mm3,mm5
		psrad       mm0,STX_ZOOM_SCALE
		psrad       mm1,STX_ZOOM_SCALE			// 
		psrad       mm2,STX_ZOOM_SCALE
		psrad       mm3,STX_ZOOM_SCALE			// 
		packssdw    mm0,mm1
		packssdw    mm2,mm3
		movq        mm1,mm0
		movq        mm3,mm2
		punpcklwd   mm0,mm0
		punpckhwd   mm1,mm1
		punpcklwd   mm2,mm2
		punpckhwd   mm3,mm3

		movq        [edi],mm0
		movq        [edi+8],mm1
		movq        [edi+16],mm2
		movq        [edi+24],mm3
		add         esi,32
		add         edi,32
		sub         ecx,32
		ja          ccc

		emms
	}
#endif
}


/***************************************************************************************
***************************************************************************************/
void OutputPcmPlain
(STX_HANDLE h,void* lpSrc, void* lpDst, s32 nLen,StxAudMixFx* pfx)
{
#if !defined(STX64) && defined(__WIN32_LIB)

	__asm
	{
		mov         esi,[lpSrc]
		mov         edi,[lpDst]
		mov         eax,[pfx]
		mov         ecx,[nLen]
		movq        mm5,[lx_zoom_round]
		movq        mm7,[eax]StxAudMixFx.nZoomRatio  //

ccc:
		pxor        mm4,mm4        // zero;
		movq        mm0,[esi]
		movq        mm2,[esi+8]
		movq        mm1,mm0        // dup;
		movq        mm3,mm2        // dup;
		punpcklwd   mm0,mm4        // rf0 lf0;
		punpckhwd   mm1,mm4        // sw0 ct0;
		punpcklwd   mm2,mm4        // rf0 lf0;
		punpckhwd   mm3,mm4        // sw0 ct0;
		pmaddwd     mm0,mm7
		pmaddwd     mm1,mm7			// zoom;
		pmaddwd     mm2,mm7
		pmaddwd     mm3,mm7			// zoom;
		paddd       mm0,mm5
		paddd       mm1,mm5
		paddd       mm2,mm5
		paddd       mm3,mm5
		psrad       mm0,STX_ZOOM_SCALE
		psrad       mm1,STX_ZOOM_SCALE			// 
		psrad       mm2,STX_ZOOM_SCALE
		psrad       mm3,STX_ZOOM_SCALE			// 
		packssdw    mm0,mm1
		packssdw    mm2,mm3
		movq        [edi],mm0
		movq        [edi+8],mm2

		movq        mm0,[esi+16]
		movq        mm2,[esi+24]
		movq        mm1,mm0        // dup;
		movq        mm3,mm2        // dup;
		punpcklwd   mm0,mm4        // rf0 lf0;
		punpckhwd   mm1,mm4        // sw0 ct0;
		punpcklwd   mm2,mm4        // rf0 lf0;
		punpckhwd   mm3,mm4        // sw0 ct0;
		pmaddwd     mm0,mm7
		pmaddwd     mm1,mm7			// zoom;
		pmaddwd     mm2,mm7
		pmaddwd     mm3,mm7			// zoom;
		paddd       mm0,mm5
		paddd       mm1,mm5
		paddd       mm2,mm5
		paddd       mm3,mm5
		psrad       mm0,STX_ZOOM_SCALE
		psrad       mm1,STX_ZOOM_SCALE			// 
		psrad       mm2,STX_ZOOM_SCALE
		psrad       mm3,STX_ZOOM_SCALE			// 
		packssdw    mm0,mm1
		packssdw    mm2,mm3
		movq        [edi+16],mm0
		movq        [edi+24],mm2
		add         esi,32
		add         edi,32
		sub         ecx,32
		ja          ccc

		emms
	}
#endif
}


/***************************************************************************************
***************************************************************************************/
s32  MaximizeAbsPcmCh(STX_HANDLE h,void* lpSrc,s32 nLen)
{
#if !defined(STX64) && defined(__WIN32_LIB)	
	
	__asm
	{
		mov         esi,[lpSrc]
		mov         ecx,[nLen]
		pxor        mm6,mm6
		pxor        mm7,mm7
ccc:
		movq        mm0,[esi]
		movq        mm1,[esi+8]
		MM_PABSW(mm0,mm3,mm4,mm5)
		MM_PABSW(mm1,mm3,mm4,mm5)
		movq        mm4,mm0
		add         esi,16
		MM_MIN_SW(mm0,mm1,mm2,mm3)
		MM_MAX_SW(mm1,mm4,mm2,mm3)
		MM_MIN_SW(mm6,mm0,mm2,mm3)
		MM_MAX_SW(mm7,mm1,mm2,mm3)
		movq        mm0,[esi]
		movq        mm1,[esi+8]
		MM_PABSW(mm0,mm3,mm4,mm5)
		MM_PABSW(mm1,mm3,mm4,mm5)
		movq        mm4,mm0
		add         esi,16
		MM_MIN_SW(mm0,mm1,mm2,mm3)
		MM_MAX_SW(mm1,mm4,mm2,mm3)
		MM_MIN_SW(mm6,mm0,mm2,mm3)
		MM_MAX_SW(mm7,mm1,mm2,mm3)
		sub         ecx,16
		ja          ccc

		//		MM_PABSW(mm6,mm0,mm1,mm2)
		//		MM_PABSW(mm7,mm0,mm1,mm2)
		MM_MAX_SW(mm6,mm7,mm0,mm1)

		movq        mm0,mm6
		movq        mm1,mm6
		movq        mm2,mm6
		psrlq       mm0,48
		psrlq       mm1,32
		psrlq       mm2,16
		MM_MAX_SW(mm0,mm1,mm4,mm5)
		MM_MAX_SW(mm2,mm6,mm4,mm5)
		pxor        mm7,mm7
		MM_MAX_SW(mm0,mm2,mm0,mm1)
		punpcklwd   mm0,mm7         // low32, must be +;
		movd        eax,mm0
		emms
	}
#else
	return 0;
#endif
}


/***************************************************************************************
***************************************************************************************/
void OutputPcm1T2(STX_HANDLE h,void *lpSrc, void *lpDst, s32 nLen,StxAudMixFx* pfx)
{
#if !defined(STX64) && defined(__WIN32_LIB)
	__asm
	{
		mov         eax,[pfx]
		mov         esi,[lpSrc]
		movq        mm5,[lx_zoom_round]
		movq        mm6,[eax]StxAudMixFx.nZoomRatio
		mov         edi,[lpDst]
		mov         ecx,[nLen]
		pxor        mm7,mm7

get_next_8p:

		movq        mm0,[esi]
		movq        mm1,mm0
		punpcklwd   mm0,mm7
		punpckhwd   mm1,mm7
		pmaddwd     mm0,mm6
		pmaddwd     mm1,mm6
		paddd       mm0,mm5
		paddd       mm1,mm5
		psrad       mm0,STX_ZOOM_SCALE
		psrad       mm1,STX_ZOOM_SCALE			// 
		packssdw    mm0,mm1

		movq        mm1,mm0
		punpcklwd   mm0,mm0
		punpckhwd   mm1,mm1

		movq        [edi],mm0
		add         esi,8
		add         eax,8
		add         edi,16
		movq        [edi-8],mm1

		movq        mm0,[esi]
		movq        mm1,mm0
		punpcklwd   mm0,mm7
		punpckhwd   mm1,mm7
		pmaddwd     mm0,mm6
		pmaddwd     mm1,mm6
		paddd       mm0,mm5
		paddd       mm1,mm5
		psrad       mm0,STX_ZOOM_SCALE
		psrad       mm1,STX_ZOOM_SCALE			// 
		packssdw    mm0,mm1

		movq        mm1,mm0
		punpcklwd   mm0,mm0
		punpckhwd   mm1,mm1

		movq        [edi],mm0
		add         esi,8
		add         edi,16
		sub         ecx,8
		movq        [edi-8],mm1
		ja          get_next_8p

		emms
	}
#endif
}


/***************************************************************************************
***************************************************************************************/
void OutputPcm2T2(STX_HANDLE h,void *lpSrc[2], void *lpDst, s32 nLen,StxAudMixFx* pfx)
{
#if !defined(STX64) && defined(__WIN32_LIB)
	__asm
	{
		mov         eax,[pfx]
		mov         esi,[lpSrc]
		movq        mm5,[lx_zoom_round]
		movq        mm6,[eax]StxAudMixFx.nZoomRatio
		mov         edi,[lpDst]
		mov         eax,[esi+4]  // second; right;
		mov         esi,[esi]    // first; left;
		mov         ecx,[nLen]
		pxor        mm7,mm7

get_next_8p:

		movq        mm0,[esi]
		movq        mm2,[eax]
		movq        mm1,mm0
		movq        mm3,mm2
		punpcklwd   mm0,mm7
		punpckhwd   mm1,mm7
		punpcklwd   mm2,mm7
		punpckhwd   mm3,mm7
		pmaddwd     mm0,mm6
		pmaddwd     mm1,mm6
		pmaddwd     mm2,mm6
		pmaddwd     mm3,mm6
		paddd       mm0,mm5
		paddd       mm1,mm5
		paddd       mm2,mm5
		paddd       mm3,mm5
		psrad       mm0,STX_ZOOM_SCALE
		psrad       mm1,STX_ZOOM_SCALE			// 
		psrad       mm2,STX_ZOOM_SCALE
		psrad       mm3,STX_ZOOM_SCALE			// 
		packssdw    mm0,mm1
		packssdw    mm2,mm3

		movq        mm1,mm0
		punpcklwd   mm0,mm2
		punpckhwd   mm1,mm2
		movq        [edi],mm0
		add         esi,8
		add         eax,8
		add         edi,16
		movq        [edi-8],mm1
		movq        mm0,[esi]
		movq        mm2,[eax]

		movq        mm1,mm0
		movq        mm3,mm2
		punpcklwd   mm0,mm7
		punpckhwd   mm1,mm7
		punpcklwd   mm2,mm7
		punpckhwd   mm3,mm7
		pmaddwd     mm0,mm6
		pmaddwd     mm1,mm6
		pmaddwd     mm2,mm6
		pmaddwd     mm3,mm6
		paddd       mm0,mm5
		paddd       mm1,mm5
		paddd       mm2,mm5
		paddd       mm3,mm5
		psrad       mm0,STX_ZOOM_SCALE
		psrad       mm1,STX_ZOOM_SCALE			// 
		psrad       mm2,STX_ZOOM_SCALE
		psrad       mm3,STX_ZOOM_SCALE			// 
		packssdw    mm0,mm1
		packssdw    mm2,mm3

		movq        mm1,mm0
		punpcklwd   mm0,mm2
		punpckhwd   mm1,mm2
		movq        [edi],mm0
		add         esi,8
		add         eax,8
		add         edi,16
		sub         ecx,8
		movq        [edi-8],mm1
		ja          get_next_8p

		emms
	}
#endif
}

/***************************************************************************************
***************************************************************************************/
void OutputPcm2T4(STX_HANDLE h,void *lpSrc[2], void *lpDst, s32 nLen,StxAudMixFx* pfx)
{
#if !defined(STX64) && defined(__WIN32_LIB)

	__asm
	{
		mov         eax,[pfx]
		mov         esi,[lpSrc]
		movq        mm6,[eax]StxAudMixFx.nZoomRatio
		pxor        mm7,mm7
		mov         ecx,[nLen]
		mov         eax,[esi+4]
		mov         esi,[esi]
		mov         edi,[lpDst]

next_8p:
		movq        mm0,[esi]  // lf
		movq        mm2,[eax]  // rf

		movq        mm1,mm0
		movq        mm3,mm2
		punpcklwd   mm0,mm7
		punpckhwd   mm1,mm7
		punpcklwd   mm2,mm7
		punpckhwd   mm3,mm7
		pmaddwd     mm0,mm6
		pmaddwd     mm1,mm6
		pmaddwd     mm2,mm6
		pmaddwd     mm3,mm6
		movq        mm5,[lx_zoom_round]
		paddd       mm0,mm5
		paddd       mm1,mm5
		paddd       mm2,mm5
		paddd       mm3,mm5
		psrad       mm0,STX_ZOOM_SCALE
		psrad       mm1,STX_ZOOM_SCALE			// 
		psrad       mm2,STX_ZOOM_SCALE
		psrad       mm3,STX_ZOOM_SCALE			// 

		packssdw    mm0,mm1
		packssdw    mm2,mm3

		pxor        mm4,mm4                
		pxor        mm5,mm5                    // rf;
		psubsw      mm4,mm0                    // ls = -lf;
		psubsw      mm5,mm2                    // rs = -rf;
		packssdw    mm0,mm4   // ls10 lf10;
		packssdw    mm2,mm5   // rs10 rf10;
		movq        mm1,mm0
		punpcklwd   mm0,mm2   // rf1 lf1 rf0 lf0;
		punpckhwd   mm1,mm2   // rs1 ls1 rs0 ls0;
		movq        mm3,mm0
		punpckldq   mm0,mm1   // rs0 ls0 rf0 lf0;
		punpckhdq   mm3,mm1   // rs1 ls1 rf1 lf1;

		movq        [edi],mm0    // output 0;
		add         esi,8
		add         eax,8
		add         edi,16
		sub         ecx,4
		movq        [edi - 8],mm3     // output 1;
		// unlooping;

		movq        mm0,[esi]  // lf
		movq        mm2,[eax]  // rf

		movq        mm1,mm0
		movq        mm3,mm2
		punpcklwd   mm0,mm7
		punpckhwd   mm1,mm7
		punpcklwd   mm2,mm7
		punpckhwd   mm3,mm7
		pmaddwd     mm0,mm6
		pmaddwd     mm1,mm6
		pmaddwd     mm2,mm6
		pmaddwd     mm3,mm6
		movq        mm5,[lx_zoom_round]
		paddd       mm0,mm5
		paddd       mm1,mm5
		paddd       mm2,mm5
		paddd       mm3,mm5
		psrad       mm0,STX_ZOOM_SCALE
		psrad       mm1,STX_ZOOM_SCALE			// 
		psrad       mm2,STX_ZOOM_SCALE
		psrad       mm3,STX_ZOOM_SCALE			// 
		packssdw    mm0,mm1
		packssdw    mm2,mm3

		pxor        mm4,mm4                
		pxor        mm5,mm5                    // rf;
		psubsw      mm4,mm0                    // ls = -lf;
		psubsw      mm5,mm2                    // rs = -rf;
		packssdw    mm0,mm4   // ls10 lf10;
		packssdw    mm2,mm5   // rs10 rf10;
		movq        mm1,mm0
		punpcklwd   mm0,mm2   // rf1 lf1 rf0 lf0;
		punpckhwd   mm1,mm2   // rs1 ls1 rs0 ls0;
		movq        mm3,mm0
		punpckldq   mm0,mm1   // rs0 ls0 rf0 lf0;
		punpckhdq   mm3,mm1   // rs1 ls1 rf1 lf1;

		movq        [edi],mm0    // output 0;
		add         esi,8
		add         eax,8
		add         edi,16
		sub         ecx,4
		movq        [edi - 8],mm3     // output 1;
		ja          next_8p

		emms
	}
#endif
}

/***************************************************************************************
***************************************************************************************/
void OutputPcm2T6
(STX_HANDLE h,void *lpSrc[2], void *lpDst, s32 nLen,StxAudMixFx* pfx)
{
#if !defined(STX64) && defined(__WIN32_LIB)
	__asm
	{
		mov         eax,[pfx]
		mov         esi,[lpSrc]
		movq        mm6,[eax]StxAudMixFx.nZoomRatio
		mov         ecx,[nLen]
		mov         eax,[esi+4]
		mov         esi,[esi]
		mov         edi,[lpDst]
		pxor        mm7,mm7

next_4p:
		movd        mm0,[esi]      // left;   LF;
		movd        mm2,[eax]      // right;  RF;
		punpcklwd   mm0,mm7
		punpcklwd   mm2,mm7
		pmaddwd     mm0,mm6
		pmaddwd     mm2,mm6
		movq        mm5,[lx_zoom_round]
		paddd       mm0,mm5
		paddd       mm2,mm5
		psrad       mm0,STX_ZOOM_SCALE
		psrad       mm2,STX_ZOOM_SCALE

		movq        mm5,mm0
		pxor        mm3,mm3
		pxor        mm4,mm4
		paddd       mm5,mm2    // lf + rf;
		psubd       mm3,mm0    // ls = -lf;
		psubd       mm4,mm2    // rs = -rf;
		psrad       mm5,1      // ct = sw = (lf+rf)/2;
		packssdw    mm0,mm3                  // ls ls  lf lf   mm0
		packssdw    mm2,mm4                  // rs rs  rf rf   mm2;
		packssdw    mm5,mm5                  // sw sw ct ct;   mm5
		movq        mm4,mm0
		punpcklwd   mm1,mm5                  // sw1 ct1 sw0 ct0;  mm1
		punpcklwd   mm0,mm2                  // rf1 lf1 rf0 lf0;  mm0
		punpckhwd   mm4,mm2                  // rs1 ls1 rs0 ls0;  mm4
		movq        mm3,mm0
		punpckldq   mm0,mm4                  // rs0 ls0 rf0 lf0  mm0;
		punpckhdq   mm3,mm4                  // rs1 ls1 rf1 lf1  mm3;
		movq        [edi],mm0                // d0;
		movq        mm5,mm1
		punpckldq   mm1,mm3                  // rf1 lf1 sw0 ct0  mm1;
		punpckhdq   mm3,mm5                  // sw1 ct1 rs1 ls1  mm5;
		movq        [edi+8],mm1
		add         esi,4
		add         eax,4
		add         edi,24
		sub         ecx,2                   // for each channel, do 2 points per loop;
		movq        [edi-8],mm3

		ja          next_4p

		emms
	}
#endif
}

/***************************************************************************************
***************************************************************************************/
void OutputPcm2p1T5p1(STX_HANDLE h,void *lpSrc[3], void *lpDst, s32 nLen,StxAudMixFx* pfx)
{
	/*
	lf = (s16)*left++;
	rf = (s16)*right++;
	ls = (s16)*left_sur++;
	rs = -ls;
	ct = (lf + rf) / 2;
	sw = ct;	
	*/
#if !defined(STX64) && defined(__WIN32_LIB)
	__asm
	{
		push		ebx
			mov           ebx,[pfx]
		mov           esi,[lpSrc]
		mov           edi,[lpDst]
		mov           edx,[nLen]
		mov           eax,[esi+4]  // rf;
		mov           ecx,[esi+8]  // ls;
		mov           esi,[esi]    // lf;

next_4p:
		movq          mm0,[esi]      // left;   LF;
		movq          mm2,[eax]      // right;  RF;
		movq          mm3,[edx]      // left_sur LS;

		pxor		mm7,mm7
		movq        mm1,mm0
		movq        mm4,mm2
		movq        mm5,mm3
		punpcklwd   mm0,mm7
		punpckhwd   mm1,mm7
		punpcklwd   mm2,mm7
		punpckhwd   mm4,mm7
		punpcklwd   mm3,mm7
		punpckhwd   mm5,mm7
		movq        mm6,[ebx]StxAudMixFx.nZoomRatio
		pmaddwd     mm0,mm6
		pmaddwd     mm1,mm6
		pmaddwd     mm2,mm6
		pmaddwd     mm4,mm6
		pmaddwd     mm3,mm6
		pmaddwd     mm5,mm6
		movq        mm7,[lx_zoom_round]
		paddd       mm0,mm7
		paddd       mm1,mm7
		paddd       mm2,mm7
		paddd       mm4,mm7
		paddd       mm3,mm7
		paddd       mm5,mm7
		psrad       mm0,STX_ZOOM_SCALE
		psrad       mm1,STX_ZOOM_SCALE			// 
		psrad       mm2,STX_ZOOM_SCALE
		psrad       mm4,STX_ZOOM_SCALE			// 
		psrad       mm3,STX_ZOOM_SCALE
		psrad       mm5,STX_ZOOM_SCALE			// 
		packssdw    mm0,mm1
		packssdw    mm2,mm4
		packssdw    mm3,mm5

		movq          mm1,mm0
		movq          mm5,mm2
		pxor          mm4,mm4
		psraw         mm1,1
		psraw         mm5,1
		psubsw        mm4,mm3    // rs = -ls;       mm4;
		paddsw        mm1,mm5    // ct = (lf+rf)/2; mm5;

		movq          mm6,mm0
		punpcklwd     mm0,mm2    // rf1 lf1 rf0 lf0 mm0
		punpckhwd     mm6,mm2    // rf3 lf3 rf2 lf2 mm6;

		movq          mm5,mm1              // sw = ct;		

		movq          mm2,mm3              // dup ls;
		punpcklwd     mm3,mm4              // rs1 ls1 rs0 ls0
		punpckhwd     mm2,mm4              // rs3 ls3 rs2 ls2

		movq          mm4,mm0
		punpckldq     mm0,mm3              //  rs0 ls0 rf0 lf0  mm0;
		punpckhdq     mm4,mm3              //  rs1 ls1 rf1 lf1  mm4;

		movq          [edi],mm0            // output d0;

		movq          mm3,mm1              // dup ct;
		punpcklwd     mm1,mm5              // sw1 ct1 sw0 ct0 mm1;
		punpckhwd     mm3,mm5              // sw3 ct3 sw2 ct2 mm3;

		movq          mm0,mm1              // dup;
		punpckldq     mm1,mm4              // rf1 lf1 sw0 ct0 mm1, d1;
		punpckhdq     mm4,mm0              // sw1 ct1 rs1 ls1      d2;   

		movq          [edi+8],mm1          // output d1;

		movq          mm0,mm6              // dup rf3 lf3 rf2 lf2
		add           esi,8
		add           eax,8

		movq          [edi+16],mm4         // output d2;

		punpckldq     mm6,mm2              // rs2 ls2 rf2 lf2      d3;

		psrlq         mm0,32               //             rf3 lf3
		movq          mm1,mm3              // dup sw3 ct3 sw2 ct2;

		movq          [edi+24],mm6         // output d3;

		punpckldq     mm3,mm0              //     rf3 lf3 sw2 ct2  d4;
		punpckhdq     mm2,mm1              //     sw3 ct3 rs3 ls3  d5;
		add           ecx,8

		movq          [edi+32],mm3         // output d4;

		add           edi,48
		sub           edx,4                // for each channel, do 4 points per loop;

		movq          [edi-8],mm2          // output d5;

		ja            next_4p

		pop			ebx
		emms
	}
#endif
}

/***************************************************************************************
***************************************************************************************/
void OutputPcm2p1T4(STX_HANDLE h,void *lpSrc[3], void *lpDst, s32 nLen,StxAudMixFx* pfx)
{
	/*
	lf = (s16)*left++;
	rf = (s16)*right++;
	ls = (s16)*left_sur++;
	rs = -ls;
	*/
#if !defined(STX64) && defined(__WIN32_LIB)

	__asm
	{
		push          ebx
		mov           ebx,[pfx]
		mov           esi,[lpSrc]
		mov           edi,[lpDst]
		mov           edx,[nLen]
		mov           eax,[esi+4]  // rf;
		mov           ecx,[esi+8]  // ls;
		mov           esi,[esi]    // lf;

next_16p:

		movq          mm0,[esi]      // left;   LF;
		movq          mm2,[eax]      // right;  RF;
		movq          mm3,[edx]      // left_sur LS;

		pxor		mm7,mm7
		movq        mm1,mm0
		movq        mm4,mm2
		movq        mm5,mm3
		punpcklwd   mm0,mm7
		punpckhwd   mm1,mm7
		punpcklwd   mm2,mm7
		punpckhwd   mm4,mm7
		punpcklwd   mm3,mm7
		punpckhwd   mm5,mm7
		movq        mm6,[ebx]StxAudMixFx.nZoomRatio
		pmaddwd     mm0,mm6
		pmaddwd     mm1,mm6
		pmaddwd     mm2,mm6
		pmaddwd     mm4,mm6
		pmaddwd     mm3,mm6
		pmaddwd     mm5,mm6
		movq        mm7,[lx_zoom_round]
		paddd       mm0,mm7
		paddd       mm1,mm7
		paddd       mm2,mm7
		paddd       mm4,mm7
		paddd       mm3,mm7
		paddd       mm5,mm7
		psrad       mm0,STX_ZOOM_SCALE
		psrad       mm1,STX_ZOOM_SCALE			// 
		psrad       mm2,STX_ZOOM_SCALE
		psrad       mm4,STX_ZOOM_SCALE			// 
		psrad       mm3,STX_ZOOM_SCALE
		psrad       mm5,STX_ZOOM_SCALE			// 
		packssdw    mm0,mm1
		packssdw    mm2,mm4
		packssdw    mm3,mm5

		pxor          mm4,mm4
		psubsw        mm4,mm3        // rs = -ls;
		movq          mm1,mm0
		punpcklwd     mm0,mm2        // rf1 lf1 rf0 lf0;
		punpckhwd     mm1,mm2        // rf3 lf3 rf2 lf2;
		movq          mm5,mm3
		punpcklwd     mm3,mm4        // rs1 ls1 rs0 ls0;
		punpckhwd     mm5,mm4        // rs3 ls3 rs2 ls2;
		movq          mm2,mm0
		punpckldq     mm0,mm3        // rs0 ls0 rf0 lf0; d0;
		punpckhdq     mm2,mm3        //                  d1;
		movq          [edi],mm0      // output lf;
		movq          mm4,mm1
		punpckldq     mm1,mm5        // d2;
		punpckhdq     mm4,mm5        // d3;
		movq          [edi+8],mm2    // output d1;
		add           esi,8
		add           eax,8
		movq          [edi+16],mm1   // output d2;
		add           edx,8
		add           edi,32
		sub           ecx,4
		movq          [edi - 8],mm4     // output d3;
		ja            next_16p

		pop			  ebx
		emms
	}
#endif
}

/***************************************************************************************
***************************************************************************************/
void OutputPcm2p1T2(STX_HANDLE h,void *lpSrc[3], void *lpDst, s32 nLen,StxAudMixFx* pfx)
{
	/*
	l = (s16)(dm_par->unit * *left++ + dm_par->slev * *left_sur);
	r = (s16)(dm_par->unit * *right++ - dm_par->slev * *left_sur++);
	*/
#if !defined(STX64) && defined(__WIN32_LIB)
	__asm
	{
		push          ebx
		mov           ebx,[pfx]
		mov           esi,[lpSrc]
		movq          mm6,[ebx]StxAudMixFx.unDm   //  pad slev clev unit;
		mov           ecx,[nLen]
		pslld         mm6,16             //  slev     unit;
		mov           edi,[lpDst]
		psrld         mm6,16              //  slev     unit;
		packssdw      mm6,mm6             //  slev unit slev unit;
		mov           eax,[esi+4] // rf;
		mov           edx,[esi+8] // ls;
		mov           esi,[esi]   // lf;

next_4p:
		movq          mm0,[esi]      // left;   LF;
		movq          mm2,[eax]      // right;  RF;
		movq          mm3,[edx]      // left_sur LS;

		pxor		mm7,mm7
			movq        mm1,mm0
			movq        mm4,mm2
			movq        mm5,mm3
			punpcklwd   mm0,mm7
			punpckhwd   mm1,mm7
			punpcklwd   mm2,mm7
			punpckhwd   mm4,mm7
			punpcklwd   mm3,mm7
			punpckhwd   mm5,mm7
			movq        mm7,[ebx]StxAudMixFx.nZoomRatio
			pmaddwd     mm0,mm7
			pmaddwd     mm1,mm7
			pmaddwd     mm2,mm7
			pmaddwd     mm4,mm7
			pmaddwd     mm3,mm7
			pmaddwd     mm5,mm7
			movq        mm7,[lx_zoom_round]
		paddd       mm0,mm7
			paddd       mm1,mm7
			paddd       mm2,mm7
			paddd       mm4,mm7
			paddd       mm3,mm7
			paddd       mm5,mm7
			psrad       mm0,STX_ZOOM_SCALE
			psrad       mm1,STX_ZOOM_SCALE			// 
			psrad       mm2,STX_ZOOM_SCALE
			psrad       mm4,STX_ZOOM_SCALE			// 
			psrad       mm3,STX_ZOOM_SCALE
			psrad       mm5,STX_ZOOM_SCALE			// 
			packssdw    mm0,mm1
			packssdw    mm2,mm4
			packssdw    mm3,mm5


			movq          mm5,[mm_par_round]
		movq          mm1,mm0
			movq          mm4,mm2
			punpcklwd     mm0,mm3
			punpckhwd     mm1,mm3
			punpcklwd     mm2,mm3
			punpckhwd     mm4,mm3
			pmaddwd       mm0,mm6
			pmaddwd       mm1,mm6
			paddd         mm0,mm5
			paddd         mm1,mm5
			psrad         mm0,DM_PAR_COE_SHIFT
			psrad         mm1,DM_PAR_COE_SHIFT
			pmaddwd       mm2,mm6
			pmaddwd       mm4,mm6
			paddd         mm2,mm5
			paddd         mm4,mm5
			psrad         mm2,DM_PAR_COE_SHIFT
			psrad         mm4,DM_PAR_COE_SHIFT
			packssdw      mm0,mm1
			packssdw      mm2,mm4
			movq          mm1,mm0
			punpcklwd     mm0,mm2 // d0;
			punpckhwd     mm1,mm2 // d1;
			movq          [edi],mm0
			add           esi,8
			add           eax,8
			add           edx,8
			add           edi,16
			sub           ecx,4
			movq          [edi-8],mm1
			ja            next_4p

			pop			ebx
			emms
	}
#endif
}


/***************************************************************************************
***************************************************************************************/
void OutputPcm3p0T5p1(STX_HANDLE h,void *lpSrc[3], void *lpDst, s32 nLen,StxAudMixFx* pfx)
{
	/*
	lf = (s16)*left++;
	ct = (s16)*center++;
	rf = (s16)*right++;
	ls = -lf;
	rs = -rf;
	sw = (lf + rf) / 2;
	*/
#if !defined(STX64) && defined(__WIN32_LIB)
	__asm
	{
		push		 ebx
			mov           ebx,[pfx]
		mov           esi,[lpSrc]
		mov           ecx,[nLen]
		mov           eax,[esi+4] // ct;
		mov           edx,[esi+8] // rf;
		mov           esi,[esi]   // lf;
		mov           edi,[lpDst]

next_4p:
		movq          mm0,[esi]      // left;    LF;
		movq          mm2,[eax]      // right;   ct;
		movq          mm3,[edx]      // left_sur rf;

		pxor		mm7,mm7
			movq        mm1,mm0
			movq        mm4,mm2
			movq        mm5,mm3
			punpcklwd   mm0,mm7
			punpckhwd   mm1,mm7
			punpcklwd   mm2,mm7
			punpckhwd   mm4,mm7
			punpcklwd   mm3,mm7
			punpckhwd   mm5,mm7
			movq        mm7,[ebx]StxAudMixFx.nZoomRatio
			pmaddwd     mm0,mm7
			pmaddwd     mm1,mm7
			pmaddwd     mm2,mm7
			pmaddwd     mm4,mm7
			pmaddwd     mm3,mm7
			pmaddwd     mm5,mm7
			movq        mm7,[lx_zoom_round]
		paddd       mm0,mm7
			paddd       mm1,mm7
			paddd       mm2,mm7
			paddd       mm4,mm7
			paddd       mm3,mm7
			paddd       mm5,mm7
			psrad       mm0,STX_ZOOM_SCALE
			psrad       mm1,STX_ZOOM_SCALE			// 
			psrad       mm2,STX_ZOOM_SCALE
			psrad       mm4,STX_ZOOM_SCALE			// 
			psrad       mm3,STX_ZOOM_SCALE
			psrad       mm5,STX_ZOOM_SCALE			// 
			packssdw    mm0,mm1
			packssdw    mm2,mm4
			packssdw    mm3,mm5

			movq          mm5,mm0
			movq          mm6,mm3
			pxor          mm1,mm1
			pxor          mm4,mm4
			psraw         mm5,1
			psraw         mm6,1
			psubsw        mm1,mm0     // ls = - lf;
			psubsw        mm4,mm3     // rs = - rf;
			paddsw        mm5,mm6     // sw = (lf+rf)/2;

			movq          mm6,mm0
			punpcklwd     mm0,mm3              // rf1 lf1 rf0 lf0
			punpckhwd     mm6,mm3              // rf3 lf3 rf2 lf2

			movq          mm3,mm1              // dup ls;
			punpcklwd     mm1,mm4              // rs1 ls1 rs0 ls0
			punpckhwd     mm3,mm4              // rs3 ls3 rs2 ls2

			movq          mm4,mm0
			punpckldq     mm0,mm1              //  rs0 ls0 rf0 lf0  mm0;
			punpckhdq     mm4,mm1              //  rs1 ls1 rf1 lf1  mm4;

			movq          [edi],mm0            // output d0;

			movq          mm1,mm2              // dup ct;
			punpcklwd     mm2,mm5              // sw1 ct1 sw0 ct0 mm2;
			punpckhwd     mm1,mm5              // sw3 ct3 sw2 ct2 mm1;

			movq          mm0,mm2              // dup;
			punpckldq     mm2,mm4              // rf1 lf1 sw0 ct0 mm2, d1;
			punpckhdq     mm4,mm0              // sw1 ct1 rs1 ls1      d2;   

			movq          [edi+8],mm2          // output d1;

			movq          mm0,mm6              // dup rf3 lf3 rf2 lf2

			movq          [edi+16],mm4         // output d2;

			punpckldq     mm6,mm3              // rs2 ls2 rf2 lf2      d3;

			psrlq         mm0,32               //             rf3 lf3
			movq          mm2,mm1              // dup sw3 ct3 sw2 ct2;

			movq          [edi+24],mm6         // output d3;

			punpckldq     mm1,mm0              //     rf3 lf3 sw2 ct2  d4;
			punpckhdq     mm3,mm2              //     sw3 ct3 rs3 ls3  d5;

			movq          [edi+32],mm1         // output d4;

			add           edi,48
			sub           edx,4                // for each channel, do 4 points per loop;

			movq          [edi-8],mm3          // output d5;

			ja            next_4p

			pop			ebx
			emms
	}
#endif
}


/***************************************************************************************
***************************************************************************************/
void OutputPcm3p0T4(STX_HANDLE h,void* lpSrc[4], void* lpDst, s32 nLen,StxAudMixFx* pfx)
{
	/*
	ls = -((s16)*left);
	rs = -((s16)*right);
	lf = (s16)(dm_par->unit * *left++  + dm_par->clev * *center);
	rf = (s16)(dm_par->unit * *right++  + dm_par->clev * *center++);
	*/
#if !defined(STX64) && defined(__WIN32_LIB)
	__asm
	{
		push		ebx
			mov           ebx,[pfx]
		mov           esi,[lpSrc]
		movd          mm6,[ebx]StxAudMixFx.unDm
			mov           ecx,[esi+4] // ct;
		punpckldq     mm6,mm6     // cu cu;
			mov           edx,[esi+8] // rf;
		mov           esi,[esi]   // lf;
		mov           edi,[lpDst]

next_4p:
		movq          mm0,[esi]      // left;    LF;
		movq          mm2,[ecx]      // right;   ct;
		movq          mm3,[edx]      // left_sur rf;

		pxor		mm7,mm7
			movq        mm1,mm0
			movq        mm4,mm2
			movq        mm5,mm3
			punpcklwd   mm0,mm7
			punpckhwd   mm1,mm7
			punpcklwd   mm2,mm7
			punpckhwd   mm4,mm7
			punpcklwd   mm3,mm7
			punpckhwd   mm5,mm7
			movq        mm7,[ebx]StxAudMixFx.nZoomRatio
			pmaddwd     mm0,mm7
			pmaddwd     mm1,mm7
			pmaddwd     mm2,mm7
			pmaddwd     mm4,mm7
			pmaddwd     mm3,mm7
			pmaddwd     mm5,mm7
			movq        mm7,[lx_zoom_round]
		paddd       mm0,mm7
			paddd       mm1,mm7
			paddd       mm2,mm7
			paddd       mm4,mm7
			paddd       mm3,mm7
			paddd       mm5,mm7
			psrad       mm0,STX_ZOOM_SCALE
			psrad       mm1,STX_ZOOM_SCALE			// 
			psrad       mm2,STX_ZOOM_SCALE
			psrad       mm4,STX_ZOOM_SCALE			// 
			psrad       mm3,STX_ZOOM_SCALE
			psrad       mm5,STX_ZOOM_SCALE			// 
			packssdw    mm0,mm1
			packssdw    mm2,mm4
			packssdw    mm3,mm5

			pxor          mm5,mm5
			pxor          mm7,mm7
			movq          mm1,mm0         // dup lf;
			movq          mm4,mm3         // dup rf;
			psubsw        mm5,mm0         // ls = - lf;
			psubsw        mm7,mm3         // rs = - rf;
			punpcklwd     mm0,mm2         // ct1 lf1 ct0 lf0         lf 10;
			punpckhwd     mm1,mm2         // ct3 lf3 ct2 lf2         lf 32;
			punpcklwd     mm3,mm2         // ct1 rf1 ct0 rf0;        rf 10;
			punpckhwd     mm4,mm2         // ct3 rf3 ct2 rf2         rf 32;
			pmaddwd       mm0,mm6
			pmaddwd       mm1,mm6
			movq          mm2,[mm_par_round]
		pmaddwd       mm3,mm6
			pmaddwd       mm4,mm6
			paddd         mm0,mm2   // lf1 lf0
			paddd         mm1,mm2   // rf1 rf0
			psrad         mm0,DM_PAR_COE_SHIFT
			psrad         mm1,DM_PAR_COE_SHIFT
			paddd         mm3,mm2   // lf1 lf0
			paddd         mm4,mm2   // rf1 rf0
			psrad         mm3,DM_PAR_COE_SHIFT
			psrad         mm4,DM_PAR_COE_SHIFT		
			packssdw      mm0,mm1   // lf3210;
			packssdw      mm3,mm4   // rf3210;
			movq          mm1,mm0
			movq          mm2,mm5
			punpcklwd     mm0,mm3   //  rf1 lf1 rf0 lf0;
			punpckhwd     mm1,mm3   //  rf3 lf3 rf2 lf2
			punpcklwd     mm5,mm7   //  rs1 ls1 rs0 ls0
			punpckhwd     mm2,mm7   //  rs3 ls3 rs2 ls2
			movq          mm3,mm0
			movq          mm7,mm1
			punpckldq     mm0,mm5   //  rs0 ls0 rf0 lf0;
			punpckhdq     mm3,mm5   //  rs1 ls1 rf1 lf1;
			movq          [edi],mm0    // output d0;
			punpckldq     mm1,mm2   //  rs2 ls2 rf2 lf2;
			punpckhdq     mm7,mm2   //  rs3 ls3 rf3 lf3;
			add           esi,8
			movq          [edi+8],mm3    // output d1;
			add           ecx,8
			movq          [edi+16],mm1   // output d2;
			add           edx,8
			add           edi,32
			sub           [nLen],4
			movq          [edi - 8],mm7     // output d3;
			ja            next_4p

			pop			ebx
			emms
	}
#endif
}


/***************************************************************************************
***************************************************************************************/
void OutputPcm3p0T2(STX_HANDLE h,void* lpSrc[4], void* lpDst, s32 nLen,StxAudMixFx* pfx)
{
	/*
	l = (s16)(dm_par->unit * *left++  + dm_par->clev * *center);
	r = (s16)(dm_par->unit * *right++ + dm_par->clev * *center++);
	*/
#if !defined(STX64) && defined(__WIN32_LIB)
	__asm
	{
		push		ebx
			mov           ebx,[pfx]
		mov           esi,[lpSrc]
		movd          mm6,[ebx]StxAudMixFx.unDm
			mov           ecx,[nLen]
		punpckldq     mm6,mm6     // cu cu;
			mov           eax,[esi+4] // ct;
		mov           edx,[esi+8] // rf;
		mov           esi,[esi]   // lf;
		mov           edi,[lpDst]

next_4p:
		movq          mm0,[esi]      // left;    LF;
		movq          mm2,[eax]      // right;   ct;
		movq          mm3,[edx]      // left_sur rf;
		pxor		mm7,mm7
			movq        mm1,mm0
			movq        mm4,mm2
			movq        mm5,mm3
			punpcklwd   mm0,mm7
			punpckhwd   mm1,mm7
			punpcklwd   mm2,mm7
			punpckhwd   mm4,mm7
			punpcklwd   mm3,mm7
			punpckhwd   mm5,mm7
			movq        mm7,[ebx]StxAudMixFx.nZoomRatio
			pmaddwd     mm0,mm7
			pmaddwd     mm1,mm7
			pmaddwd     mm2,mm7
			pmaddwd     mm4,mm7
			pmaddwd     mm3,mm7
			pmaddwd     mm5,mm7
			movq        mm7,[lx_zoom_round]
		paddd       mm0,mm7
			paddd       mm1,mm7
			paddd       mm2,mm7
			paddd       mm4,mm7
			paddd       mm3,mm7
			paddd       mm5,mm7
			psrad       mm0,STX_ZOOM_SCALE
			psrad       mm1,STX_ZOOM_SCALE			// 
			psrad       mm2,STX_ZOOM_SCALE
			psrad       mm4,STX_ZOOM_SCALE			// 
			psrad       mm3,STX_ZOOM_SCALE
			psrad       mm5,STX_ZOOM_SCALE			// 
			packssdw    mm0,mm1
			packssdw    mm2,mm4
			packssdw    mm3,mm5

			movq          mm5,[mm_par_round]
		movq          mm1,mm0         // dup lf;
			movq          mm4,mm3         // dup rf;
			punpcklwd     mm0,mm2         // ct1 lf1 ct0 lf0         lf 10;
			punpckhwd     mm1,mm2         // ct3 lf3 ct2 lf2         lf 32;
			punpcklwd     mm3,mm2         // ct1 rf1 ct0 rf0;        rf 10;
			punpckhwd     mm4,mm2         // ct3 rf3 ct2 rf2         rf 32;
			pmaddwd       mm0,mm6
			pmaddwd       mm1,mm6
			paddd         mm0,mm5   // lf1 lf0
			paddd         mm1,mm5   // rf1 rf0
			pmaddwd       mm3,mm6
			pmaddwd       mm4,mm6
			psrad         mm0,DM_PAR_COE_SHIFT
			psrad         mm1,DM_PAR_COE_SHIFT
			paddd         mm3,mm5   // lf1 lf0
			paddd         mm4,mm5   // rf1 rf0
			psrad         mm3,DM_PAR_COE_SHIFT
			psrad         mm4,DM_PAR_COE_SHIFT		
			packssdw      mm0,mm1   // lf3210;
			packssdw      mm3,mm4   // rf3210;
			movq          mm1,mm0
			punpcklwd     mm0,mm3   //  rf1 lf1 rf0 lf0;
			punpckhwd     mm1,mm3   //  rf3 lf3 rf2 lf2
			movq          [edi],mm0    // output d0;
			add           esi,8
			add           eax,8
			add           edx,8
			add           edi,16
			sub           ecx,4
			movq          [edi - 8],mm1     // output d1;
			ja            next_4p

			pop			ebx
			emms
	}
#endif
}


/***************************************************************************************
***************************************************************************************/
void OutputPcm2p2T2(STX_HANDLE h,void* lpSrc[4], void* lpDst, s32 nLen,StxAudMixFx* pfx)
{
	/*
	l = (s16)(dm_par->unit * *left++  + dm_par->slev * *left_sur++);
	r = (s16)(dm_par->unit * *right++ + dm_par->slev * *right_sur++);
	*/
#if !defined(STX64) && defined(__WIN32_LIB)
	__asm
	{
		push			ebx
			mov             esi,[lpSrc]
		mov             ebx,[pfx]
		mov             edi,[lpDst]
		movq            mm6,[ebx]StxAudMixFx.unDm  // pad slev clev unit
			mov             edx,[nLen]
		pslld           mm6,16                    // slev     unit;
			psrld           mm6,16
			packssdw        mm6,mm6                   // slev unit slev unit;

next4p:
		mov             eax,[esi]   // lf;
		mov             ecx,[esi+4] // rf;
		movq            mm0,[eax]         // lf
		movq            mm1,[ecx]         // rf

		pxor		mm7,mm7
			movq        mm2,mm0
			movq        mm3,mm1
			punpcklwd   mm0,mm7
			punpckhwd   mm2,mm7
			punpcklwd   mm1,mm7
			punpckhwd   mm3,mm7
			movq        mm7,[ebx]StxAudMixFx.nZoomRatio
			pmaddwd     mm0,mm7
			pmaddwd     mm2,mm7
			pmaddwd     mm1,mm7
			pmaddwd     mm3,mm7
			movq        mm7,[lx_zoom_round]
		paddd       mm0,mm7
			paddd       mm2,mm7
			paddd       mm1,mm7
			paddd       mm3,mm7
			psrad       mm0,STX_ZOOM_SCALE
			psrad       mm2,STX_ZOOM_SCALE
			psrad       mm1,STX_ZOOM_SCALE			// 
			psrad       mm3,STX_ZOOM_SCALE
			packssdw    mm0,mm2
			packssdw    mm1,mm3

			mov             eax,[esi+8]   // ls;
		mov             ecx,[esi+12]  // rs;
		movq            mm2,[eax]         // ls
		movq            mm3,[ecx]         // rs

		pxor		mm7,mm7
			movq        mm4,mm2
			movq        mm5,mm3
			punpcklwd   mm2,mm7
			punpckhwd   mm4,mm7
			punpcklwd   mm3,mm7
			punpckhwd   mm5,mm7
			movq        mm7,[ebx]StxAudMixFx.nZoomRatio
			pmaddwd     mm2,mm7
			pmaddwd     mm4,mm7
			pmaddwd     mm3,mm7
			pmaddwd     mm5,mm7
			movq        mm7,[lx_zoom_round]
		paddd       mm2,mm7
			paddd       mm4,mm7
			paddd       mm3,mm7
			paddd       mm5,mm7
			psrad       mm2,STX_ZOOM_SCALE
			psrad       mm4,STX_ZOOM_SCALE
			psrad       mm3,STX_ZOOM_SCALE			// 
			psrad       mm5,STX_ZOOM_SCALE
			packssdw    mm2,mm4
			packssdw    mm3,mm5

			movq            mm5,[mm_par_round]

		movq            mm4,mm0       // dup lf;
			add             [esi],8
			punpcklwd       mm0,mm2       // ls1 lf1 ls0 lf0;
			punpckhwd       mm4,mm2       // ls3 lf3 ls2 lf2;
			pmaddwd         mm0,mm6       // lo 10;
			movq            mm2,mm1       // rf;
			pmaddwd         mm4,mm6       // lo 32;
			punpcklwd       mm1,mm3       // rs1 rf1 rs0 rf0;
			punpckhwd       mm2,mm3       // rs3 rf3 rs2 rf2;
			add             [esi+4],8
			pmaddwd         mm1,mm6
			paddd           mm0,mm5
			pmaddwd         mm2,mm6
			psrad           mm0,DM_PAR_COE_SHIFT
			paddd           mm4,mm5
			paddd           mm1,mm5
			psrad           mm4,DM_PAR_COE_SHIFT
			add             [esi+8],8
			paddd           mm2,mm5
			psrad           mm1,DM_PAR_COE_SHIFT
			psrad           mm2,DM_PAR_COE_SHIFT
			packssdw        mm0,mm4
			packssdw        mm1,mm2
			movq            mm3,mm0  // dup lo;
			punpcklwd       mm0,mm1  // ro1 lo1 ro0 lo0;
			punpckhwd       mm3,mm1  // ro3 lo3 ro2 lo2;
			movq            [edi],mm0
			add             edi,16
			add             [esi+12],8
			sub             edx,4                 // 4pixels each loop;
			movq            [edi-8],mm3
			ja              next4p

			pop				ebx
			emms
	}
#endif
}


/***************************************************************************************
***************************************************************************************/
void OutputPcm2p2T4(STX_HANDLE h,void* lpSrc[4], void* lpDst, s32 nLen,StxAudMixFx* pfx)
{

#if !defined(STX64) && defined(__WIN32_LIB)
	__asm
	{
		push		ebx
			mov           esi,[lpSrc]
		mov           ebx,[pfx]
		mov           edi,[lpDst]
		mov           edx,[nLen]

ccc:
		mov           eax,[esi]   // lf;
		mov           ecx,[esi+4] // rf;
		movq          mm0,[eax]   // lf
		movq          mm1,[ecx]   // rf

		pxor		mm7,mm7
			movq        mm2,mm0
			movq        mm3,mm1
			punpcklwd   mm0,mm7
			punpckhwd   mm2,mm7
			punpcklwd   mm1,mm7
			punpckhwd   mm3,mm7
			movq        mm7,[ebx]StxAudMixFx.nZoomRatio
			pmaddwd     mm0,mm7
			pmaddwd     mm2,mm7
			pmaddwd     mm1,mm7
			pmaddwd     mm3,mm7
			movq        mm7,[lx_zoom_round]
		paddd       mm0,mm7
			paddd       mm2,mm7
			paddd       mm1,mm7
			paddd       mm3,mm7
			psrad       mm0,STX_ZOOM_SCALE
			psrad       mm2,STX_ZOOM_SCALE
			psrad       mm1,STX_ZOOM_SCALE			// 
			psrad       mm3,STX_ZOOM_SCALE
			packssdw    mm0,mm2
			packssdw    mm1,mm3

			mov           eax,[esi+8]   // ls;
		mov           ecx,[esi+12]  // rs;
		movq          mm2,[eax]     // ls
		movq          mm3,[ecx]     // rs

		pxor		mm7,mm7
			movq        mm4,mm2
			movq        mm5,mm3
			punpcklwd   mm2,mm7
			punpckhwd   mm4,mm7
			punpcklwd   mm3,mm7
			punpckhwd   mm5,mm7
			movq        mm7,[ebx]StxAudMixFx.nZoomRatio
			pmaddwd     mm2,mm7
			pmaddwd     mm4,mm7
			pmaddwd     mm3,mm7
			pmaddwd     mm5,mm7
			movq        mm7,[lx_zoom_round]
		paddd       mm2,mm7
			paddd       mm4,mm7
			paddd       mm3,mm7
			paddd       mm5,mm7
			psrad       mm2,STX_ZOOM_SCALE
			psrad       mm4,STX_ZOOM_SCALE
			psrad       mm3,STX_ZOOM_SCALE			// 
			psrad       mm5,STX_ZOOM_SCALE
			packssdw    mm2,mm4
			packssdw    mm3,mm5

			add           [esi],4
			movq          mm4,mm0
			movq          mm5,mm2
			punpcklwd     mm0,mm1  // rf1 lf1 rf0 lf0;
			punpckhwd     mm4,mm1  // rf3 lf3 rf2 lf2;
			add           [esi+4],4
			punpcklwd     mm2,mm3  // rs1 ls1 rs0 ls0;
			punpckhwd     mm5,mm3  // rs3 ls3 rs2 ls2;
			movq          mm1,mm0
			movq          mm3,mm4
			punpckldq     mm0,mm2  //  rs0 ls0  rf0 lf0
			punpckhdq     mm1,mm2  //  rs1 ls1  rf1 lf1
			movq          [edi],mm0
			punpckldq     mm3,mm5  //  rs2 ls2  rf2 lf2
			add           [esi+8],4
			punpckhdq     mm4,mm5  //  rs3 ls3  rf3 lf3
			movq          [edi+8],mm1
			add           esi,8
			movq          [edi+16],mm3
			add           edi,32
			add           [esi+12],4
			sub           edx,4
			movq          [edi-8],mm4
			ja            ccc
			pop			ebx
			emms
	}
#endif
}

/***************************************************************************************
***************************************************************************************/
void OutputPcm2p2T5p1(STX_HANDLE h,void* lpSrc[4], void* lpDst, s32 nLen,StxAudMixFx* pfx)
{
	/*
	lf = (s16)*left++;
	rf = (s16)*right++;
	ls = (s16)*left_sur++;
	rs = (s16)*right_sur++;
	ct = (lf + rf) / 2;
	sw = ct;
	*/
#if !defined(STX64) && defined(__WIN32_LIB)
	__asm
	{
		push		ebx
			mov           esi,[lpSrc]
		mov           ebx,[pfx]
		mov           edi,[lpDst]
		mov           edx,[nLen]

next_4p:

		mov           eax,[esi]   // lf;
		mov           ecx,[esi+4] // rf;
		movq          mm0,[eax]
		movq          mm2,[ecx]

		pxor		mm7,mm7
			movq        mm1,mm0
			movq        mm3,mm2
			punpcklwd   mm0,mm7
			punpckhwd   mm1,mm7
			punpcklwd   mm2,mm7
			punpckhwd   mm3,mm7
			movq        mm7,[ebx]StxAudMixFx.nZoomRatio
			pmaddwd     mm0,mm7
			pmaddwd     mm1,mm7
			pmaddwd     mm2,mm7
			pmaddwd     mm3,mm7
			movq        mm7,[lx_zoom_round]
		paddd       mm0,mm7 
			paddd       mm1,mm7
			paddd       mm2,mm7
			paddd       mm3,mm7
			psrad       mm0,STX_ZOOM_SCALE
			psrad       mm1,STX_ZOOM_SCALE
			psrad       mm2,STX_ZOOM_SCALE			// 
			psrad       mm3,STX_ZOOM_SCALE
			packssdw    mm0,mm1
			packssdw    mm2,mm3

			mov           eax,[esi+8]   // ls;
		mov           ecx,[esi+12]  // rs;
		movq          mm3,[eax]       // ls3210;
		movq          mm4,[ecx]       // rs3210;

		pxor		mm7,mm7
			movq        mm1,mm3
			movq        mm5,mm4
			punpcklwd   mm3,mm7
			punpckhwd   mm1,mm7
			punpcklwd   mm4,mm7
			punpckhwd   mm5,mm7
			movq        mm7,[ebx]StxAudMixFx.nZoomRatio
			pmaddwd     mm3,mm7
			pmaddwd     mm1,mm7
			pmaddwd     mm4,mm7
			pmaddwd     mm5,mm7
			movq        mm7,[lx_zoom_round]
		paddd       mm3,mm7
			paddd       mm1,mm7
			paddd       mm4,mm7
			paddd       mm5,mm7
			psrad       mm3,STX_ZOOM_SCALE
			psrad       mm1,STX_ZOOM_SCALE
			psrad       mm4,STX_ZOOM_SCALE			// 
			psrad       mm5,STX_ZOOM_SCALE
			packssdw    mm3,mm1
			packssdw    mm4,mm5


			add           [esi],8
			movq          mm1,mm0
			movq          mm5,mm2
			add           [esi+4],8
			psraw         mm1,1
			psraw         mm5,1
			add           [esi+8],8
			movq          mm6,mm0
			paddsw        mm1,mm5              // ct 3210;
			add           [esi+12],8
			punpcklwd     mm0,mm2              // rf1 lf1 rf0 lf0
			punpckhwd     mm6,mm2              // rf3 lf3 rf2 lf2

			movq          mm5,mm1              // sw = ct;

			// the code below is same as 5p1T5p1;

			movq          mm2,mm3              // dup ls;
			punpcklwd     mm3,mm4              // rs1 ls1 rs0 ls0
			punpckhwd     mm2,mm4              // rs3 ls3 rs2 ls2

			movq          mm4,mm0
			punpckldq     mm0,mm3              //  rs0 ls0 rf0 lf0  mm0;
			punpckhdq     mm4,mm3              //  rs1 ls1 rf1 lf1  mm4;

			movq          [edi],mm0            // output d0;

			movq          mm3,mm1              // dup ct;
			punpcklwd     mm1,mm5              // sw1 ct1 sw0 ct0 mm1;
			punpckhwd     mm3,mm5              // sw3 ct3 sw2 ct2 mm3;

			movq          mm0,mm1              // dup;
			punpckldq     mm1,mm4              // rf1 lf1 sw0 ct0 mm1, d1;
			punpckhdq     mm4,mm0              // sw1 ct1 rs1 ls1      d2;   

			movq          [edi+8],mm1          // output d1;

			movq          mm0,mm6              // dup rf3 lf3 rf2 lf2

			movq          [edi+16],mm4         // output d2;

			punpckldq     mm6,mm2              // rs2 ls2 rf2 lf2      d3;

			psrlq         mm0,32               //             rf3 lf3
			movq          mm1,mm3              // dup sw3 ct3 sw2 ct2;

			movq          [edi+24],mm6         // output d3;

			punpckldq     mm3,mm0              //     rf3 lf3 sw2 ct2  d4;
			punpckhdq     mm2,mm1              //     sw3 ct3 rs3 ls3  d5;

			movq          [edi+32],mm3         // output d4;

			add           edi,48
			sub           edx,4                // for each channel, do 4 points per loop;

			movq          [edi-8],mm2          // output d5;

			ja            next_4p

			pop			ebx
			emms
	}
#endif
}



/***************************************************************************************
***************************************************************************************/
void OutputPcm3p1T2(STX_HANDLE h,void *lpSrc[4], void *lpDst, s32 nLen,StxAudMixFx* pfx)
{
	/*
	l = (s16)(dm_par->unit * *left++  + dm_par->clev * *center  - dm_par->slev * *left_sur);
	r = (s16)(dm_par->unit * *right++ + dm_par->clev * *center++ + dm_par->slev * *left_sur++);
	*/
#if !defined(STX64) && defined(__WIN32_LIB)
	__asm
	{
		push		ebx
			mov          ebx,[pfx]
		mov          edi,[lpDst]
		mov          esi,[lpSrc]
		movq         mm6,[ebx]StxAudMixFx.unDm
			mov          eax,[esi+4]   // ct;
		mov          ecx,[esi+8]   // rf;
		mov          edx,[esi+12]  // ls;
		mov          esi,[esi]     // lf;
		movq         mm5,[mm_par_round]

next_2p:
		movd         mm0,[esi]   // lf
		movd         mm1,[eax]   // ct
		movd         mm2,[ecx]   // rf
		movd         mm4,[edx]	 // ls
		punpcklwd    mm0,mm1          // ct1 lf1 ct0 lf0
			punpcklwd    mm2,mm1          // ct1 rf1 ct0 rf0

			pxor		mm7,mm7
			movq        mm1,mm0
			movq        mm3,mm2
			punpcklwd   mm0,mm7
			punpckhwd   mm1,mm7
			punpcklwd   mm2,mm7
			punpckhwd   mm3,mm7
			punpcklwd   mm4,mm7
			movq        mm7,[ebx]StxAudMixFx.nZoomRatio
			pmaddwd     mm0,mm7
			pmaddwd     mm1,mm7
			pmaddwd     mm2,mm7
			pmaddwd     mm3,mm7
			pmaddwd     mm4,mm7
			movq        mm7,[lx_zoom_round]
		paddd       mm0,mm7 
			paddd       mm1,mm7
			paddd       mm2,mm7
			paddd       mm3,mm7
			paddd       mm4,mm7
			psrad       mm0,STX_ZOOM_SCALE
			psrad       mm1,STX_ZOOM_SCALE
			psrad       mm2,STX_ZOOM_SCALE			// 
			psrad       mm3,STX_ZOOM_SCALE
			psrad       mm4,STX_ZOOM_SCALE
			packssdw    mm0,mm1
			packssdw    mm2,mm3
			packssdw    mm4,mm4

			movq         mm3,mm6   // x s c u;
			pxor         mm1,mm1
			punpckldq    mm6,mm6         //  c u c u;
			punpckhdq    mm3,mm3         //  x s x s;
			punpcklwd    mm4,mm1         // 0   ls1 0   ls0;
			pmaddwd      mm0,mm6
			pmaddwd      mm2,mm6         //
			pmaddwd      mm4,mm3         //
			psubd        mm0,mm4
			paddd        mm2,mm4
			paddd        mm0,mm5
			paddd        mm2,mm5
			add          esi,4
			psrad        mm0,DM_PAR_COE_SHIFT
			psrad        mm2,DM_PAR_COE_SHIFT
			packssdw     mm0,mm0
			packssdw     mm2,mm2
			add          eax,4
			punpcklwd    mm0,mm2
			add          ecx,4
			add          edx,4
			add          edi,8
			sub          ecx,2
			movq         [edi-8],mm0
			ja           next_2p

			pop			ebx
			emms
	}
#endif
}

/***************************************************************************************
***************************************************************************************/
void OutputPcm3p1T4(STX_HANDLE h,void *lpSrc[4], void *lpDst, s32 nLen,StxAudMixFx* pfx)
{
	/*
	lf = (s16)(dm_par->unit * *left++  + dm_par->clev * *center);
	rf = (s16)(dm_par->unit * *right++  + dm_par->clev * *center++);
	ls = (s16)*left_sur++;
	rs = -ls;
	*/
#if !defined(STX64) && defined(__WIN32_LIB)
	__asm
	{
		push		ebx
			mov          ebx,[pfx]
		mov          edi,[lpDst]
		mov          esi,[lpSrc]
		movd         mm6,[ebx]StxAudMixFx.unDm           // __cu
			mov          eax,[esi+4]   // ct;
		mov          ecx,[esi+8]   // rf;
		mov          edx,[esi+12]  // ls;
		mov          esi,[esi]     // lf;

		punpckldq    mm6,mm6       // c u c u;

next_2p:
		movd         mm0,[esi]  // lf
		movd         mm1,[eax]  // ct
		movd         mm2,[ecx]  // rf
		punpcklwd    mm0,mm1    // ct1 lf1 ct0 lf0         lf 10;
			punpcklwd    mm2,mm1    // ct1 rf1 ct0 rf0         rf 10;  
			movd         mm4,[edx]  // ls

		pxor		mm7,mm7
			movq        mm1,mm0
			movq        mm3,mm2
			punpcklwd   mm0,mm7
			punpckhwd   mm1,mm7
			punpcklwd   mm2,mm7
			punpckhwd   mm3,mm7
			punpcklwd   mm4,mm7
			movq        mm7,[ebx]StxAudMixFx.nZoomRatio
			pmaddwd     mm0,mm7
			pmaddwd     mm1,mm7
			pmaddwd     mm2,mm7
			pmaddwd     mm3,mm7
			pmaddwd     mm4,mm7
			movq        mm7,[lx_zoom_round]
		paddd       mm0,mm7 
			paddd       mm1,mm7
			paddd       mm2,mm7
			paddd       mm3,mm7
			paddd       mm4,mm7
			psrad       mm0,STX_ZOOM_SCALE
			psrad       mm1,STX_ZOOM_SCALE
			psrad       mm2,STX_ZOOM_SCALE			// 
			psrad       mm3,STX_ZOOM_SCALE
			psrad       mm4,STX_ZOOM_SCALE
			packssdw    mm0,mm1
			packssdw    mm2,mm3
			packssdw    mm4,mm4

			movq         mm7,[mm_par_round]
		pmaddwd      mm0,mm6    // lf;
			pmaddwd      mm2,mm6    // rf;
			paddd        mm0,mm7
			paddd        mm2,mm7
			pxor         mm3,mm3
			psrad        mm0,DM_PAR_COE_SHIFT   // lf
			psrad        mm2,DM_PAR_COE_SHIFT   // rf;
			punpcklwd    mm4,mm3                // rs1 ls1 rs0 ls0;
			packssdw     mm0,mm2                // rf1 lf1 rf0 lf0
			psubsw       mm3,mm4                // rs = - ls;
			movq         mm2,mm0                // dup mm0;
			punpckldq    mm0,mm3                // rs0 ls0 rf0 lf0
			punpckhdq    mm2,mm3                // rs1 ls1 rf1 lf1
			movq         [edi],mm0              // output lf;
			add          esi,4
			add          eax,4
			add          ecx,4
			add          edx,4
			add          edi,16
			sub          ecx,2
			movq         [edi - 8],mm2     // output rf;
			ja           next_2p           // 30 ins each loop;

			pop			ebx
			emms
	}
#endif
}



/***************************************************************************************
***************************************************************************************/
void OutputPcm3p1T5p1(STX_HANDLE h,void *lpSrc[4], void *lpDst, s32 nLen,StxAudMixFx* pfx)
{
	/*
	left = samples[0];
	center = samples[1];
	right = samples[2];
	left_sur = samples[3];
	lf = (s16)*left++;
	ct = (s16)*center++;
	rf = (s16)*right++;
	ls = (s16)*left_sur++;
	rs = -ls;
	sw = (lf + rf) / 2;
	*/
#if !defined(STX64) && defined(__WIN32_LIB)
	__asm
	{
		mov          eax,[pfx]
		mov          edi,[lpDst]
		mov          esi,[lpSrc]
		movq         mm7,[eax]StxAudMixFx.nZoomRatio
			mov          eax,[esi+4]   // ct;
		mov          ecx,[esi+8]   // rf;
		mov          edx,[esi+12]  // ls;
		mov          esi,[esi]     // lf;
		pxor         mm6,mm6
			movq         mm5,[lx_zoom_round]

next_2p:
		movd         mm0,[esi]      // left;   LF;
		movd         mm1,[ecx]      // right;  RF;

		punpcklwd    mm0,mm6
			punpcklwd    mm1,mm6
			pmaddwd      mm0,mm7
			pmaddwd      mm1,mm7
			paddd        mm0,mm5
			paddd        mm1,mm5
			psrad        mm0,STX_ZOOM_SCALE
			psrad        mm1,STX_ZOOM_SCALE
			movq         mm4,mm0        // dup lf;
			movq         mm2,mm1        // dup rf

			packssdw     mm0,mm0
			packssdw     mm2,mm2
			punpcklwd    mm0,mm2        // rf lf rf lf;  --> mm0; 

			movd         mm2,[eax]      // center; CT;
		movd         mm3,[edx]      // left_sur LS;

		punpcklwd    mm2,mm6
			punpcklwd    mm3,mm6
			pmaddwd      mm2,mm7
			pmaddwd      mm3,mm7
			paddd        mm2,mm5
			paddd        mm3,mm5
			psrad        mm2,STX_ZOOM_SCALE
			psrad        mm3,STX_ZOOM_SCALE
			packssdw     mm2,mm2
			packssdw     mm3,mm3

			paddd        mm1,mm4        // sw10 = (lf+rf)/2; s32[2];
			pxor         mm4,mm4
			psrad        mm1,1          // sw = (lf+rf)/2;
			psubsw       mm4,mm3        // rs = -ls;
			packssdw     mm1,mm7        // sw10, s16[2];
			punpcklwd    mm3,mm4        // rs ls rs ls;  --> mm3
			punpcklwd    mm1,mm2        // sw ct sw ct;  --> mm1;
			movq         mm4,mm0
			punpckldq    mm0,mm3        // rs0 ls0 rf0 lf0;
			punpckhdq    mm4,mm3        // rs1 ls1 rf1 lf1;
			movq         [edi],mm0                // d0;
			movq         mm2,mm1
			punpckldq    mm1,mm4        // rf1 lf1 sw0 ct0; // d1;
			punpckhdq    mm4,mm2        // sw1 ct1 rs1 ls1  // d2;
			movq         [edi+8],mm1
			add          esi,4
			add          eax,4
			add          ecx,4
			add          edx,4
			add          edi,24
			sub          ecx,2          // for each channel, do 2 points per loop;
			movq         [edi-8],mm4

			ja           next_2p        // 33 instructions each loop;
			emms
	}
#endif
}


/***************************************************************************************
***************************************************************************************/
void OutputPcm5p1T5p1(STX_HANDLE h,void *lpSrc[6], void *lpDst, s32 nLen,StxAudMixFx* pfx)
{
#if !defined(STX64) && defined(__WIN32_LIB)
	__asm
	{
		push		  ebx
		mov           esi,[lpSrc]
		mov           ebx,[pfx]
		mov           edi,[lpDst]
		mov           ecx,[nLen]

next_4p:
		mov           eax,[esi]
		mov           edx,[esi + 4 ]           // ct;
		movq          mm0,[eax]      // left;   LF;
		movq          mm1,[ecx]      // center; CT;
		add           [esi],8
		add           [esi+4],8

		pxor		mm7,mm7
		movq        mm2,mm0
		movq        mm3,mm1
		punpcklwd   mm0,mm7
		punpckhwd   mm2,mm7
		punpcklwd   mm1,mm7
		punpckhwd   mm3,mm7
		movq        mm7,[ebx]StxAudMixFx.nZoomRatio
		pmaddwd     mm0,mm7
		pmaddwd     mm2,mm7
		pmaddwd     mm1,mm7
		pmaddwd     mm3,mm7
		movq        mm7,[lx_zoom_round]
		paddd       mm0,mm7
		paddd       mm2,mm7
		paddd       mm1,mm7
		paddd       mm3,mm7
		psrad       mm0,STX_ZOOM_SCALE
		psrad       mm2,STX_ZOOM_SCALE
		psrad       mm1,STX_ZOOM_SCALE			// 
		psrad       mm3,STX_ZOOM_SCALE
		packssdw    mm0,mm2
		packssdw    mm1,mm3
		movq        [ebx]StxAudMixFx.tmp,mm0
		movq        [ebx+8]StxAudMixFx.tmp,mm1


		mov           eax,[esi+8]              // rf;
		mov           edx,[esi+12]             // ls;
		movq          mm0,[eax]      // right;  RF;
		movq          mm1,[edx]      // left_sur LS;
		add           [esi+8],8
		add           [esi+12],8

		pxor		mm7,mm7
		movq        mm2,mm0
		movq        mm3,mm1
		punpcklwd   mm0,mm7
		punpckhwd   mm2,mm7
		punpcklwd   mm1,mm7
		punpckhwd   mm3,mm7
		movq        mm7,[ebx]StxAudMixFx.nZoomRatio
		pmaddwd     mm0,mm7
		pmaddwd     mm2,mm7
		pmaddwd     mm1,mm7
		pmaddwd     mm3,mm7
		movq        mm7,[lx_zoom_round]
		paddd       mm0,mm7
		paddd       mm2,mm7
		paddd       mm1,mm7
		paddd       mm3,mm7
		psrad       mm0,STX_ZOOM_SCALE
		psrad       mm2,STX_ZOOM_SCALE
		psrad       mm1,STX_ZOOM_SCALE			// 
		psrad       mm3,STX_ZOOM_SCALE
		packssdw    mm0,mm2
		packssdw    mm1,mm3
		movq        [ebx+16]StxAudMixFx.tmp,mm0
		movq        [ebx+24]StxAudMixFx.tmp,mm1

		mov           eax,[esi+16]              // rs;
		mov           edx,[esi+20]              // sw;
		movq          mm0,[eax]                 // right_sur   rs;
		movq          mm1,[edx]                 // sub_woofer  sw;
		add           [esi+16],8
		add           [esi+20],8

		pxor		mm7,mm7
		movq        mm2,mm0
		movq        mm3,mm1
		punpcklwd   mm0,mm7
		punpckhwd   mm2,mm7
		punpcklwd   mm1,mm7
		punpckhwd   mm3,mm7
		movq        mm7,[ebx]StxAudMixFx.nZoomRatio
		pmaddwd     mm0,mm7
		pmaddwd     mm2,mm7
		pmaddwd     mm1,mm7
		pmaddwd     mm3,mm7
		movq        mm7,[lx_zoom_round]
		paddd       mm0,mm7
		paddd       mm2,mm7
		paddd       mm1,mm7
		paddd       mm3,mm7
		psrad       mm0,STX_ZOOM_SCALE
		psrad       mm2,STX_ZOOM_SCALE
		psrad       mm1,STX_ZOOM_SCALE			// 
		psrad       mm3,STX_ZOOM_SCALE
		packssdw    mm0,mm2
		packssdw    mm1,mm3
		movq        mm4,mm0
		movq        mm5,mm1
		movq        mm0,[ebx]StxAudMixFx.tmp
		movq        mm1,[ebx+8]StxAudMixFx.tmp
		movq        mm2,[ebx+16]StxAudMixFx.tmp
		movq        mm3,[ebx+24]StxAudMixFx.tmp

		movq          mm6,mm0
		punpcklwd     mm0,mm2              // rf1 lf1 rf0 lf0
		punpckhwd     mm6,mm2              // rf3 lf3 rf2 lf2

		movq          mm2,mm3              // dup ls;
		punpcklwd     mm3,mm4              // rs1 ls1 rs0 ls0
		punpckhwd     mm2,mm4              // rs3 ls3 rs2 ls2

		movq          mm4,mm0
		punpckldq     mm0,mm3              //  rs0 ls0 rf0 lf0  mm0;
		punpckhdq     mm4,mm3              //  rs1 ls1 rf1 lf1  mm4;

		movq          [edi],mm0            // output d0;

		movq          mm3,mm1              // dup ct;
		punpcklwd     mm1,mm5              // sw1 ct1 sw0 ct0 mm1;
		punpckhwd     mm3,mm5              // sw3 ct3 sw2 ct2 mm3;
		movq          mm0,mm1              // dup;
		punpckldq     mm1,mm4              // rf1 lf1 sw0 ct0 mm1, d1;
		punpckhdq     mm4,mm0              // sw1 ct1 rs1 ls1      d2;   
		movq          [edi+8],mm1          // output d1;
		movq          mm0,mm6              // dup rf3 lf3 rf2 lf2
		movq          [edi+16],mm4         // output d2;
		punpckldq     mm6,mm2              // rs2 ls2 rf2 lf2      d3;
		psrlq         mm0,32               //             rf3 lf3
		movq          mm1,mm3              // dup sw3 ct3 sw2 ct2;
		movq          [edi+24],mm6         // output d3;
		punpckldq     mm3,mm0              //     rf3 lf3 sw2 ct2  d4;
		punpckhdq     mm2,mm1              //     sw3 ct3 rs3 ls3  d5;
		movq          [edi+32],mm3         // output d4;
		add           edi,48
		sub           ecx,4                // for each channel, do 4 points per loop;
		movq          [edi-8],mm2          // output d5;

		ja            next_4p

		pop			ebx
		emms
	}
#endif
}

/***************************************************************************************
***************************************************************************************/
void OutputPcm5p1T4(STX_HANDLE h,void *lpSrc[6], void *lpDst, s32 nLen,StxAudMixFx* pfx)
{
	/*
	lf = (s16)(dm_par->unit * *left++ + dm_par->clev * *center +  0.500 * *sub_woofer);
	rf = (s16)(dm_par->unit * *right++ + dm_par->clev * *center++ + 0.500 * *sub_woofer);
	ls = (s16)(*left_sur++ + 0.500 * *sub_woofer);
	rs = (s16)(*right_sur++ + 0.500 * *sub_woofer++);
	*/
#if !defined(STX64) && defined(__WIN32_LIB)
	__asm
	{
		mov          eax,[pfx]
		mov          edi,[lpDst]
		mov          esi,[lpSrc]
		movq         mm5,[eax]StxAudMixFx.nZoomRatio
		movd         mm6,[eax]StxAudMixFx.unDm           // __cu
		punpckldq    mm6,mm6       // c u c u;

next_2p:
		mov          eax,[esi]         // lf;
		mov          ecx,[esi+4]       // ct;
		mov          edx,[esi+8]       // rf;
		movd         mm0,[eax]
		movd         mm1,[ecx]
		movd         mm2,[edx]
		punpcklwd    mm0,mm1           // ct1 lf1 ct0 lf0
		add          [esi],4
		punpcklwd    mm2,mm1           // ct1 rf1 ct0 rf0
		add          [esi+4],4

		pxor		mm7,mm7
		movq        mm1,mm0
		movq        mm3,mm2
		punpcklwd   mm0,mm7
		punpckhwd   mm1,mm7
		punpcklwd   mm2,mm7
		punpckhwd   mm3,mm7
		pmaddwd     mm0,mm5
		pmaddwd     mm1,mm5
		pmaddwd     mm2,mm5
		pmaddwd     mm3,mm5
		movq        mm7,[lx_zoom_round]
		paddd       mm0,mm7
		paddd       mm1,mm7
		paddd       mm2,mm7
		paddd       mm3,mm7
		psrad       mm0,STX_ZOOM_SCALE
		psrad       mm1,STX_ZOOM_SCALE
		psrad       mm2,STX_ZOOM_SCALE			// 
		psrad       mm3,STX_ZOOM_SCALE
		packssdw    mm0,mm1
		packssdw    mm2,mm3

		movq         mm7,[mm_par_round]
		add          [esi+8],4
		pmaddwd      mm0,mm6           // lf10;
		pmaddwd      mm2,mm6           // rf10;
		mov          eax,[esi+12]      // ls;
		paddd        mm0,mm7
		paddd        mm2,mm7
		mov          ecx,[esi+16]      // rs;
		psrad        mm0,DM_PAR_COE_SHIFT
		psrad        mm2,DM_PAR_COE_SHIFT
		mov          edx,[esi+20]      // sw;
		packssdw     mm0,mm2           // rf1 lf1 rf0 lf0;
		movd         mm3,[edx]  // sw;
		movd         mm1,[eax]  // ls;

		pxor		mm7,mm7
		punpcklwd   mm3,mm7
		movq        mm7,[lx_zoom_round]
		pmaddwd     mm3,mm5
		paddd       mm3,mm7
		psrad       mm3,STX_ZOOM_SCALE
		packssdw    mm3,mm3

		movd         mm2,[ecx]  // rs;
		punpcklwd    mm3,mm3           // sw1 sw1 sw0 sw0;
		add          [esi+12],4
		psraw        mm3,1
		punpcklwd    mm1,mm2           // rs1 ls1 rs0 ls0;
		add          [esi+16],4

		pxor		mm7,mm7
		punpcklwd   mm1,mm7
		movq        mm7,[lx_zoom_round]
		pmaddwd     mm1,mm5
		paddd       mm1,mm7
		psrad       mm1,STX_ZOOM_SCALE
		packssdw    mm1,mm1

		psubsw       mm0,mm3
		psubsw       mm1,mm3
		movq         [edi],mm0
		add          edi,16
		add          [esi+16],4
		sub          [nLen],2
		movq         [edi - 8],mm1     // output rf;
		ja           next_2p

		emms
	}
#endif
}


/***************************************************************************************
***************************************************************************************/
void OutputPcm5p1T2(STX_HANDLE h,void* lpSrc[6], void *lpDst, s32 nLen,StxAudMixFx* pfx)
{
	/*
	left = samples[0];
	center = samples[1];
	right = samples[2];
	left_sur = samples[3];
	right_sur = samples[4];
	sub_woofer = samples[5];

	l = (s16)(dm_par->unit * *left++  + dm_par->clev * *center  +
	dm_par->slev * *left_sur++ + 0.500 * *sub_woofer);

	r= (s16)(dm_par->unit * *right++ + dm_par->clev * *center++ +
	dm_par->slev * *right_sur++ + 0.500 * *sub_woofer++);
	*/
#if !defined(STX64) && defined(__WIN32_LIB)
	__asm
	{
		push         ebx
		mov          ebx,[pfx]
		mov          edi,[lpDst]
		mov          esi,[lpSrc]
		mov          eax,[esi]    // lf;
		mov          ebx,[esi+8]  // rf;

next_2p:
		movd         mm0,[eax]           // lf
		movd         mm1,[ebx]           // rf

		mov          ecx,[esi+4]  // ct;
		mov          edx,[esi+12] // ls;
		movd         mm2,[ecx]    // ct;
		movd         mm3,[edx]    // ls;
		add          [esi+4],4    // ct++;
		add          [esi+12],4   // ls++;
		punpcklwd    mm0,mm2             // ct1 lf1 ct0 lf0 
		punpcklwd    mm1,mm2             // ct1 rf1 ct0 rf0

		pxor		mm7,mm7
		movq        mm2,mm0
		movq        mm3,mm1
		punpcklwd   mm0,mm7
		punpckhwd   mm2,mm7
		punpcklwd   mm1,mm7
		punpckhwd   mm3,mm7
		movq        mm7,[ebx]StxAudMixFx.nZoomRatio
		pmaddwd     mm0,mm7
		pmaddwd     mm2,mm7
		pmaddwd     mm1,mm7
		pmaddwd     mm3,mm7
		movq        mm7,[lx_zoom_round]
		paddd       mm0,mm7
		paddd       mm2,mm7
		paddd       mm1,mm7
		paddd       mm3,mm7
		psrad       mm0,STX_ZOOM_SCALE
		psrad       mm2,STX_ZOOM_SCALE
		psrad       mm1,STX_ZOOM_SCALE			// 
		psrad       mm3,STX_ZOOM_SCALE
		packssdw    mm0,mm2
		packssdw    mm1,mm3

		movq         mm6,[ebx]StxAudMixFx.unDm           // __cu
		punpckldq    mm6,mm6       // c u c u;
		pmaddwd      mm0,mm6              // l10 = ct*clev + lf*unit; ;
		pmaddwd      mm1,mm6              // r10 = ct*clev + rf*unit; ;

		mov          ecx,[esi+16]  // rs;
		mov          edx,[esi+20]  // sw;
		movd         mm2,[ecx]     // rs;
		movd         mm7,[edx]     // sw;
		add          [esi+16],4    // rs++;
		add          [esi+20],4

		punpcklwd    mm3,mm7       // sw1 ls1 sw0 ls0;
		punpcklwd    mm2,mm7       // sw1 rs1 sw0 rs0;

		pxor		mm7,mm7
		movq        mm4,mm3
		movq        mm6,mm2
		punpcklwd   mm3,mm7
		punpckhwd   mm4,mm7
		punpcklwd   mm2,mm7
		punpckhwd   mm6,mm7
		movq        mm7,[ebx]StxAudMixFx.nZoomRatio
		pmaddwd     mm3,mm7
		pmaddwd     mm4,mm7
		pmaddwd     mm2,mm7
		pmaddwd     mm6,mm7
		movq        mm7,[lx_zoom_round]
		paddd       mm3,mm7
		paddd       mm4,mm7
		paddd       mm2,mm7
		paddd       mm6,mm7
		psrad       mm3,STX_ZOOM_SCALE
		psrad       mm4,STX_ZOOM_SCALE
		psrad       mm2,STX_ZOOM_SCALE			// 
		psrad       mm6,STX_ZOOM_SCALE
		packssdw    mm3,mm4
		packssdw    mm2,mm6

		movq         mm4,[ebx]StxAudMixFx.unDm           // __cu
		punpckldq    mm4,mm4       // c u c u;
		pmaddwd      mm3,mm4       // sw*pad + ls*slev; l10,second;
		pmaddwd      mm2,mm4       // sw*pad + rs*slev; r10,second;

		movq         mm7,[mm_par_round]
		paddd        mm0,mm3
		paddd        mm1,mm2
		paddd        mm0,mm7
		paddd        mm1,mm7
		psrad        mm0,DM_PAR_COE_SHIFT
		psrad        mm1,DM_PAR_COE_SHIFT
		movq         mm2,mm0
		punpckldq    mm0,mm1
		punpckhdq    mm2,mm1
		add          edi,8
		packssdw     mm0,mm2              // r 1 0 second;
		add          eax,4
		add          ebx,4
		sub          [nLen],2
		movq         [edi-8],mm0
		ja           next_2p

		pop          ebx
		emms
	}
#endif
}


/***************************************************************************************
***************************************************************************************/
#define LX_ZOOM_PCM(A,Z) ( (A*Z+STX_ZOOM_ROUND) >> STX_ZOOM_SCALE )

void convert_5p1_to_6p1  (STX_HANDLE h,void* src,void* dst,s32 nLen,s32 nFlags )
{
	s32 i, L,R,C,SW,Ls1,Rs1;

	s16* ps = (s16*) src;
	s16* pd = (s16*) dst;

	for( i = 0; i < nLen; i += 12 )	{

		L = LX_ZOOM_PCM(ps[0] , nFlags); 
		R = LX_ZOOM_PCM(ps[1] , nFlags); 
		C = LX_ZOOM_PCM(ps[2] , nFlags); 
		SW = LX_ZOOM_PCM(ps[3] , nFlags); 
		Ls1 = LX_ZOOM_PCM(ps[4] , nFlags); 
		Rs1 = LX_ZOOM_PCM(ps[5] , nFlags); 

		pd[0] = L; 
		pd[1] = R; 
		pd[2] = C; 
		pd[3] = SW;
		pd[4] = Ls1;
		pd[5] = Rs1;
		pd[6] = ( Ls1 + Rs1 + 1 ) >> 1;
		ps += 6;
		pd += 7;
	}
}

/***************************************************************************************
***************************************************************************************/

void convert_5p1_to_7p1(STX_HANDLE h,void* src,void* dst,s32 nLen,s32 nFlags )
{
	s32 i,L,R,C,SW,Ls1,Rs1;

	s16* ps = (s16*) src;
	s16* pd = (s16*) dst;

	for( i = 0; i < nLen; i += 12 )	{

		L = LX_ZOOM_PCM(ps[0] , nFlags); 
		R = LX_ZOOM_PCM(ps[1] , nFlags); 
		C = LX_ZOOM_PCM(ps[2] , nFlags); 
		SW = LX_ZOOM_PCM(ps[3] , nFlags); 
		Ls1 = LX_ZOOM_PCM(ps[4] , nFlags); 
		Rs1 = LX_ZOOM_PCM(ps[5] , nFlags); 

		pd[0] = L; 
		pd[1] = R; 
		pd[2] = C; 
		pd[3] = SW;
		pd[4] = Ls1;
		pd[5] = Rs1;
		pd[7] = pd[6] = ( Ls1 + Rs1 + 1 ) >> 1;
		ps += 6;
		pd += 8;
	}
}

/***************************************************************************************
***************************************************************************************/

void convert_6p1_to_7p1(STX_HANDLE h,void* src,void* dst,s32 nLen,s32 nFlags )
{
	s32 i;

	s16* ps = (s16*) src;
	s16* pd = (s16*) dst;

	for(i = 0; i < nLen; i += 14 ){

		s32 Lf = LX_ZOOM_PCM(ps[0] , nFlags);
		s32 Rf = LX_ZOOM_PCM(ps[1] , nFlags); 
		s32 Ls = LX_ZOOM_PCM(ps[4] , nFlags); 
		s32 Rs = LX_ZOOM_PCM(ps[5] , nFlags);

		pd[0] = Lf; 
		pd[1] = Rf; 
		pd[2] = LX_ZOOM_PCM(ps[2] , nFlags);
		pd[3] = LX_ZOOM_PCM(ps[3] , nFlags);
		pd[4] = Ls; 
		pd[5] = Rs; 
		pd[7] = pd[6] = LX_ZOOM_PCM(ps[6] , nFlags);
		ps += 7;
		pd += 8;
	}
}
