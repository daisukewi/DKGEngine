/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/
#include "stdio.h"
#include "stdlib.h"
#include "fcntl.h"
#include "malloc.h"
#include "memory.h"
#include "string.h"

#include "stx_os.h"
#include "stx_mem.h"
#include "stx_debug.h"
#include "stx_mutex.h"
#include "stx_semaphore.h"
#include "stx_module_reg.h"
#include "stx_message.h"
#include "stx_gid_def.h"

#include "stx_async_plugin.h"
#include "stx_sync_source.h"
#include "stx_module_reg.h"
#include "stx_heap.h"
#include "stx_hash.h"
#include "stx_cpuid.h"


#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif


#define DEFAULT_XT_STACK_SIZE 2*1024*1024
#define XT_STACK_RESERVED     16*1024


#define lock_ 	stx_sync_source_vt_asy_xxx_lock(the)
#define unlock_ stx_sync_source_vt_asy_xxx_unlock(the)


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API_IMP STX_RESULT stx_base_plugin_stop
(stx_base_plugin* plug,STX_RESULT i_err_ext,b32 b_stopped)
{
	STX_RESULT			i_err;
	stx_msg_cnt*		p_cnt;
	stx_base_message*	p_msg;
	stx_base_plugin*	p;

	if( b_stopped ) {
		plug->set_status(plug,emStxStatusStop);
	}

	p = plug->get_parent(plug);

	if( p ){

		do{
			i_err = STX_FAIL;

			p_msg = XCREATE(base_msg,NULL,NULL);
			if( !p_msg){
				break;
			}
			i_err = p_msg->set_stack(p_msg);
			if( STX_OK != i_err ) {
				break;
			}
			p_msg->set_msg_type(p_msg,STX_MSG_TYPE_UPSTREAM | STX_MSG_TYPE_ASYNC);
			p_cnt = p_msg->get_msg_cnt(p_msg);
			p_cnt->msg_gid = STX_MSG_AutoStop;
			p_cnt->param.i_param[0] = (size_t)i_err_ext;
			p_cnt->param.i_param[1] = (size_t)plug;

			i_err = p->send_msg(p,p_msg);

		}while(FALSE);

		SAFE_XDELETE(p_msg);
		SAFE_XDELETE(p);

		return i_err;
	}

	return STX_OK;
}




#define TASK_TYPE_MAIN			(TASK_IDLE<<1)
#define TASK_TYPE_GROUP			(TASK_IDLE<<2)
#define TASK_TYPE_SUB			(TASK_IDLE<<3)
#define TASK_TYPE_IDLE          (TASK_IDLE<<4)
#define TASK_TYPE_AS			(TASK_IDLE<<5)
#define TASK_FIBER				(TASK_IDLE<<6)


#define TCTX_SLEEP		0x01
#define TCTX_SUSPEND	0x02


STX_INTERF(task_context);
struct task_context{
	size_t						i_flag;
	u8*							p_stack;
	size_t						i_stack_size;
	u8*							p_stack_buf;
	stx_base_plugin*			plug;
	THEE						h_sem;
	u64							i_start_time;
	u64							i_max_time;
};


STX_INTERF(stx_task);


struct stx_task{
	s32                         i_type;
	s64							i_start_time;
	s64							i_last_time;
	s64							i_report_time;
	s64							i_next_time;
	stx_base_plugin*			plug;			// callback entry filter ;
	stx_sync_source*            the;            // ssrc;
	stxHeapElem					fTimerHeapElem;
	stxHeap*					h_heap;
	stx_sync_inf				sync;
	u32							i_events;
	THEE						h_stat;			// run occupy;
	task_context				tctx;

	stx_task*					hprev;
	stx_task*					hnext;
	s32							i_subtask;
	stx_task**					hh_subtask;
};



STX_COM_BEGIN(sync_source);
/**/
/**/STX_PUBLIC(stx_sync_source)
/**/STX_COM_DATA_DEFAULT(stx_sync_source)
/**/
/**/THEE				h_hash;
/**/stxHeap*			h_task_heap;
/**/stxHeap*			h_idle_heap;
/**/s64					i_last_time;
/**/char				sz_last_task[32];
/**/stx_task*			phead;
/**/stx_task*			ptail;
/**/
STX_COM_END();



STX_PRIVATE STX_RESULT 
reg_task(THEE h,THEE* hh_main,stx_base_plugin* plug,u32 i_flag,u32 i_stack_size);

STX_PRIVATE STX_RESULT 
call_task_ex(sync_source* the,stx_base_plugin* plug,stx_task* h_task);

STX_PRIVATE void close_task(stx_task* h);

STX_PRIVATE stx_task* 
waitfor_task(sync_source* the,stx_sync_inf* h_sync);


STX_COM_FUNC_DECL_DEFAULT(stx_sync_source,stx_sync_source_vt);

STX_COM_FUNCIMP_DEFAULT(sync_source,stx_sync_source,stx_sync_source_vt);


/*{{{STX_MSG_ENTRY_DECLARE**************************************************/
/**/STX_MSG_ENTRY_DECLARE(on_unregister_module)
/**/STX_MSG_ENTRY_DECLARE(on_auto_stop)
/*}}}***********************************************************************/


/*{{{STX_BEGIN_MSG_MAP******************************************************/
STX_BEGIN_MSG_MAP(the_msg_data)
/* to do : add msg process entry here; */
/**/ON_STX_MSG(STX_MSG_UnregModule,on_unregister_module)
/**/ON_STX_MSG(STX_MSG_AutoStop,on_auto_stop)
STX_END_MSG_MAP
/*}}}***********************************************************************/

/*{{{STX_DISPATCH_MSG_PROC**************************************************/
STX_DISPATCH_MSG_PROC( stx_sync_source_vt_asy_xxx_dispatch_msg,the_msg_data )
/*}}}***********************************************************************/


/*{{{STX_BEGIN_MSG_RESPONSE_MAP*********************************************/
STX_BEGIN_MSG_RESPONSE_MAP(the_msg_response)
/* to do : add msg process entry here; */
STX_END_MSG_RESPONSE_MAP
/*}}}***********************************************************************/

/*{{{STX_RESPONSE_MSG_PROC**************************************************/
STX_RESPONSE_MSG_PROC( stx_sync_source_vt_asy_xxx_response_msg,the_msg_response )
/*}}}***********************************************************************/




/***************************************************************************
stx_sync_source_create
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_COM_MAP_BEGIN(sync_source)
/**/STX_COM_MAP_ITEM(STX_IID_SyncSource)
STX_COM_MAP_END()

STX_API_IMP STX_NEW_BEGIN(sync_source)
{
	/* fill vt; */
	STX_SET_THE(stx_sync_source);
	STX_COM_NEW_DEFAULT(
		stx_sync_source,
		the->stx_sync_source_vt,
		stx_sync_source_vt,
		STX_CLSID_SyncSource,
		STX_CATEGORY_SyncSource,
		"StreamX SyncSource" );

	the->h_hash = stx_hash_create(2048);
	if( !the->h_hash ) {
		break;
	}

	the->h_task_heap = stxHeapCreate(2048);
	if( !the->h_task_heap ) {
		break;
	}
	the->h_idle_heap = stxHeapCreate(2048);
	if( !the->h_idle_heap ) {
		break;
	}

	stx_strcpy(the->sz_last_task,sizeof(the->sz_last_task),"not set");

}
STX_NEW_END()




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_QUERY_BEGIN(sync_source)
{
	STX_COM_QUERY_DEFAULT(stx_sync_source,the->stx_sync_source_vt);
}
STX_QUERY_END()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE  STX_DELETE_BEGIN(sync_source)
{
	if( the->h_hash ) {
		void* p = stx_hash_find_first(the->h_hash);
		while(p) {
			close_task((stx_task*)p);
			p = stx_hash_find_next(the->h_hash);
		}
		stx_hash_close(the->h_hash);
	}

	if( the->h_task_heap ) {
		stxHeapClose(the->h_task_heap);
	}
	if( the->h_idle_heap ) {
		stxHeapClose(the->h_idle_heap);
	}

	STX_COM_DELETE_DEFAULT(stx_sync_source);
}
STX_DELETE_END
(
	STX_COM_DELETE_BEGIN(stx_sync_source)
	,
	STX_COM_DELETE_END(stx_sync_source)
)



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE stx_task* waitfor_task(sync_source* the,stx_sync_inf* h_sync )
{
	s64				i_idle;
	s64				theCurrentTime;
	stxHeapElem*	elem;
	stx_task*		h_task;


	theCurrentTime = stx_get_microsec(); // usec

	// first, we check the suspended task;
	h_task = the->phead;
	while( h_task ) {
		u32 i_wait = stx_semaphore_wait(h_task->tctx.h_sem,0);
		if( WAIT_TIMEOUT != i_wait ||
			( 
			INFINITE64 != h_task->tctx.i_max_time &&
			theCurrentTime - h_task->tctx.i_start_time >= h_task->tctx.i_max_time
			)
		){
			lock_;
			// remove from list;
			if( h_task->hprev ) {
				h_task->hprev->hnext = h_task->hnext;
			}
			if( h_task->hnext ) {
				h_task->hnext->hprev = h_task->hprev;
			}
			if( h_task == the->phead ) {
				the->phead = h_task->hnext;
			}
			if( h_task == the->ptail ) {
				the->ptail = h_task->hprev;
			}
			h_task->hprev = NULL;
			h_task->hnext = NULL;
			// reset task;
			unlock_;
			return h_task;
		}
		h_task = h_task->hnext;
	}// while( h_task ) {


	// if no task resumed, check the normal task heap;
	elem = stxHeapPeekMin(the->h_task_heap);
	if ( elem ){   
		s64 const i_val = stxHeapElemGetValue(elem);
		if( i_val <= theCurrentTime ){
			elem = stxHeapExtractMin(the->h_task_heap);
			return (stx_task*)stxHeapElemGetEnclosingObject(elem);
		}
		i_idle = i_val - theCurrentTime;
		if( h_sync->i_idle < 200 ) {
			h_sync->i_idle = 200;
		}
		h_sync->i_idle = USEC2REFTIME(i_idle);
	} // if ( elem ){

	// starving:
	// if system is override, the idle heap task maybe have no chance to run;
	elem = stxHeapPeekMin(the->h_idle_heap);
	if ( elem ){   
		s64 const i_val = stxHeapElemGetValue(elem);
		if( i_val <= theCurrentTime ){
			elem = stxHeapExtractMin(the->h_idle_heap);
			return (stx_task*)stxHeapElemGetEnclosingObject(elem);
		}
		i_idle = i_val - theCurrentTime ;
		if( i_idle < 200 ) {
			i_idle = 200;
		}
		if( h_sync->i_idle > i_idle ) {
			h_sync->i_idle =  USEC2REFTIME( i_idle);
		}
	} // if ( elem ){

	if( h_sync->i_idle <= 0 ) {
		h_sync->i_idle = USEC2REFTIME(200);
	}

	return NULL;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE s32 stx_sync_source_vt_xxx_get_task_num(THEE h)
{
	STX_MAP_THE(sync_source);
	return stx_hash_size(the->h_hash);
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE void stx_sync_source_vt_xxx_set_task_events
(THEE h,THEE h_task,u32 i_events)
{
	STX_MAP_THE(sync_source);
	lock_;
	{
		stx_task*	h_main = (stx_task*)h_task;
		h_main->i_events = i_events;
	}
	unlock_;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE u32 stx_sync_source_vt_xxx_get_task_events
(THEE h,THEE h_task)
{
	STX_MAP_THE(sync_source);
	{
		stx_task*	h_main = (stx_task*)h_task;
		return h_main->i_events;
	}
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT reg_task
(THEE h,THEE* hh_main,stx_base_plugin* plug,u32 i_flag,u32 i_stack_size)
{
	STX_RESULT		i_err;
	stx_task*		h_task;

	STX_MAP_THE(sync_source);

	i_err = STX_FAIL;
	h_task = STX_NULL;

	lock_;

	do{

		h_task = (stx_task*)xmallocz(sizeof(stx_task));
		if( !h_task ) {
			break;
		}

		if( ! ( i_flag & (TASK_NORMAL|TASK_IDLE) ) ) {
			i_flag |= TASK_NORMAL;
		}

		// set parameters;
		if( i_flag & TASK_NORMAL ) {
			h_task->i_type |= TASK_TYPE_MAIN;
			h_task->h_heap = the->h_task_heap;
		}
		else if( i_flag & TASK_IDLE ) {
			h_task->i_type |= TASK_TYPE_IDLE;
			h_task->h_heap = the->h_idle_heap;
		}

		if( i_flag & TASK_TYPE_SUB ) {
			h_task->i_type |= TASK_TYPE_SUB;
		}

		if( i_flag & TASK_FIBER ){

			h_task->i_type |= TASK_TYPE_AS;

			h_task->tctx.h_sem = stx_semaphore_create(NULL,0,1,NULL);
			if( !h_task->tctx.h_sem ) {
				break;
			}

			if( !i_stack_size ) {
				i_stack_size = DEFAULT_XT_STACK_SIZE;
			}
			else {
				i_stack_size += XT_STACK_RESERVED;
			}

			h_task->tctx.i_stack_size = i_stack_size;
			h_task->tctx.p_stack_buf = (u8*)stx_valloc(&h_task->tctx.i_stack_size);
			if( !h_task->tctx.p_stack_buf ) {
				i_err = STX_FAIL;
				break;
			}

			h_task->tctx.p_stack = h_task->tctx.p_stack_buf + h_task->tctx.i_stack_size - XT_STACK_RESERVED;

		} // if( i_flag & TASK_FIBER ){

		h_task->h_stat = stx_stat_create();
		if( !h_task->h_stat ) {
			i_err = STX_FAIL;
			break;
		}

		h_task->plug = plug; 
		plug->add_ref(plug);
		h_task->the = (stx_sync_source*)h;
		h_task->i_events = ev_run;

		h_task->sync.h_stack = stx_stack_create();
		if( !h_task->sync.h_stack){
			i_err = STX_FAIL;
			break;
		}
		// push first run entry;
		stx_stack_push(h_task->sync.h_stack,(size_t)plug);

		if( !(i_flag & TASK_TYPE_SUB) ) {
			i_err = stx_hash_add(the->h_hash,h_task,(size_t)plug);
			if( STX_OK != i_err ) {
				break;
			}
		}

		*hh_main = h_task;
		i_err = STX_OK;

	}while(FALSE);

	if( i_err != STX_OK ) {
		if( h_task ) {
			stx_free(h_task);
		}
	}

	unlock_;

	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_sync_source_vt_xxx_reg_task
(STX_HANDLE h,STX_HANDLE* hh_main,stx_base_plugin* plug,u32 i_flag)
{
	return reg_task(h,hh_main,plug,i_flag,0);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_sync_source_vt_xxx_reg_task_ex
(STX_HANDLE h,STX_HANDLE* hh_main,stx_base_plugin* plug,u32 i_flag,u32 i_stack_size)
{
	return reg_task(h,hh_main,plug,i_flag|TASK_FIBER,i_stack_size);
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_sync_source_vt_xxx_xsleep
(THEE h, THEE h_task,u64 usec)
{
	stx_task* p_task = (stx_task*)h_task;
	if( !(p_task->i_type & TASK_TYPE_AS) ) {
		return STX_FAIL;
	}

	p_task->tctx.i_flag |= TCTX_SLEEP;
	p_task->sync.i_idle = USEC2REFTIME(usec);
	stx_stack_push(p_task->sync.h_stack,(size_t)p_task->tctx.plug);

	xtswap((void**)(p_task->tctx.p_stack-sizeof(void*)),*(void**)(p_task->tctx.p_stack-sizeof(void*)*2)); 

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_sync_source_vt_xxx_xwait
(THEE h, THEE h_task,u64 usec)
{
	stx_task* p_task = (stx_task*)h_task;
	if( !(p_task->i_type & TASK_TYPE_AS) ) {
		return STX_FAIL;
	}

	p_task->tctx.i_flag |= TCTX_SUSPEND;
	p_task->tctx.i_start_time = stx_get_microsec();
	p_task->tctx.i_max_time = usec;
	p_task->sync.i_idle = 0;
	stx_stack_push(p_task->sync.h_stack,(size_t)p_task->tctx.plug);

	xtswap((void**)(p_task->tctx.p_stack-sizeof(void*)),*(void**)(p_task->tctx.p_stack-sizeof(void*)*2)); 

	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE void stx_sync_source_vt_xxx_unreg_task
(STX_HANDLE h,STX_HANDLE h_task)
{
	STX_MAP_THE(sync_source);
	lock_;
	{
		stx_task* h_main = (stx_task*)h_task;
		if( (h_main->i_type & TASK_TYPE_SUB)  || (h_main == stx_hash_rem(the->h_hash,(size_t)h_main->plug)) ) {
			close_task(h_task);
		}
	}
	unlock_;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_sync_source_vt_xxx_reg_subtask
(
	THEE			h,
	THEE			h_main,
	s32				i_sub,
	THEE			h_subtask[],
	u32				i_stack_size 
)
{
	s32						i;
	STX_RESULT				i_err;
	stx_task*				h_task;

	stx_sync_source*		the3;
	stx_base_graph_builder* the2;
	sync_source*			the;

	the3 = (stx_sync_source*)h;						// stx_sync_source interface;
	STX_PEEK_THE(sync_source,the,h);				// instance;
	STX_PEEK_THE(stx_base_graph_builder,the2,the);	// gbd interface;

	i_err = the2->alloc_ssrc(the2,TRUE,NULL,i_sub,(stx_sync_source**)h_subtask );
	if( STX_OK != i_err ) {
		return i_err;
	}
	for( i = 0; i < i_sub; i ++ ) {
		SAFE_XDELETE(h_subtask[i]);
	}

	do{
		h_task = (stx_task*)h_main;

		lock_;
		if( !stx_hash_find(the->h_hash,(size_t)h_task->plug) ) {
			unlock_;
			i_err = STX_ERR_FILE_NOT_FOUND;
			break;
		}
		unlock_;

		h_task->i_subtask = i_sub;
		h_task->hh_subtask = (stx_task**)xmallocz(sizeof(void*)*i_sub);
		if( !h_task->hh_subtask ) {
			break;
		}

		i_err = STX_OK;
		for( i = 0; i < i_sub; i ++ ) {
			stx_task*			h_sub = NULL;
			stx_sync_source*	h_sync = (stx_sync_source*)h_subtask[i];
			i_err = h_sync->reg_task_ex(h_sync,&h_sub,h_task->plug,TASK_TYPE_SUB | TASK_NORMAL,i_stack_size);
			if( STX_OK != i_err ) {
				break;
			}
			h_sub->i_type |= TASK_TYPE_SUB;
			h_sub->the = h_sync;
			h_task->hh_subtask[i] = h_subtask[i] = h_sub;
		}
		if( STX_OK != i_err ) {
			break;
		}

	}while(FALSE);

	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE void stx_sync_source_vt_xxx_unreg_subtask(THEE h,THEE h_main)
{
	s32						i;
	stx_task*				h_task;
	stx_sync_source*		the3;

	STX_DECLARE_THE2(stx_base_graph_builder); // the2;
	STX_MAP_THE(sync_source); // get the;
	STX_MAP_THE2(stx_base_graph_builder); // get the2;

	the3 = &the->stx_sync_source_vt; // the3;

	h_task = (stx_task*)h_main;

	lock_;
	if( !stx_hash_find(the->h_hash,(size_t)h_task->plug) ) {
		unlock_;
		return;
	}
	unlock_;

	if( h_task->hh_subtask ) {
		for( i = 0 ; i < h_task->i_subtask; i ++ ) {
			stx_sync_source* h_sync = h_task->hh_subtask[i]->the;
			h_sync->unreg_task(h_sync,h_task->hh_subtask[i]);
		}
		stx_free(h_task->hh_subtask);
	}

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE stx_sync_source* stx_sync_source_vt_xxx_task2ssrc(THEE h, THEE h_task)
{
	STX_MAP_THE(sync_source);
	{
		stx_task* htk = (stx_task*)h_task;
		return htk->the;
	}
}	

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_sync_source_vt_xxx_xresume(THEE h, THEE h_task)
{
	STX_MAP_THE(sync_source);
	{
		stx_task* htk= (stx_task*)h_task;
		if( (THEE)htk->the != h ) {
			return htk->the->xresume(htk->the,htk);
		}
		stx_semaphore_release(htk->tctx.h_sem,1,NULL);
		the->i_idle = 0;
		if( the->b_sleep ) {
			stx_semaphore_release(the->h_sync,1,NULL);
		}
		return STX_OK;
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE void stx_sync_source_vt_xxx_reset_task
( THEE h, THEE h_main,u32 i_flags, s64 i_start_time )
{
	stx_task*		h_task;
	stxHeapElem*	elem;

	STX_MAP_THE(sync_source);

	h_task = (stx_task*)h_main;

	if( (THEE)h_task->the != h ) {
		h_task->the->reset_task(h_task->the,h_task,i_flags,i_start_time);
		return;
	}

	lock_;

	elem = &h_task->fTimerHeapElem;

	if( elem->fCurrentHeap ) {
		// remove it;
		stxHeapRemove(the->h_task_heap,elem);
	} //if( h_task->task.fTimerHeapElem.fCurrentHeap ) {

	// insert it again;
	elem->fValue = REFTIME2USEC(i_start_time); 
	if( elem->fValue < the->i_idle ) {
		the->i_idle = elem->fValue;
	}
	elem->fValue += stx_get_microsec();
	elem->fEnclosingObject = h_task;

	stxHeapInsert(h_task->h_heap,elem);

	if( the->b_sleep ) {
		stx_semaphore_release(the->h_sync,1,NULL);
	}

	unlock_;
}



/***************************************************************************
							up_stream_msg
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT stx_sync_source_vt_asy_xxx_up_stream_msg
(STX_HANDLE h, stx_base_message* p_msg)
{
	STX_MAP_THE(sync_source);

	return STX_OK;
}

/***************************************************************************
							down_stream_msg
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT stx_sync_source_vt_asy_xxx_down_stream_msg
(STX_HANDLE h, stx_base_message* p_msg)
{
	STX_MAP_THE(sync_source);

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
**************************************************************************/
STX_PRIVATE void close_task(stx_task* h)
{
	if( h->h_stat ) {
		stx_stat_close(h->h_stat);
		h->h_stat = NULL;
	}

	if( h->sync.h_stack ) {
		stx_stack_close(h->sync.h_stack);
		h->sync.h_stack = NULL;
	}

	SAFE_XDELETE(h->plug);

	if( h->tctx.p_stack_buf ) {
		stx_vfree(h->tctx.p_stack_buf,h->tctx.i_stack_size);
		h->tctx.p_stack_buf = NULL;
	}

	if( h->tctx.h_sem ) {
		stx_semaphore_destory(h->tctx.h_sem);
		h->tctx.h_sem = NULL;
	}

	stx_free(h);
}





/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
param h_sync is NULL, calling from come from other ssrc;
***************************************************************************/
#define CHECK_XWAIT \
if( h_task->tctx.i_flag & TCTX_SUSPEND ) {\
	lock_;\
	/*add to suspend list;*/ \
	if( !the->ptail ) {\
		the->ptail = the->phead = h_task;\
	}\
	else {\
		h_task->hprev = the->ptail;\
		the->ptail->hnext = h_task;\
		the->ptail = h_task;\
	}\
	unlock_;\
	h_task->sync.i_result |= STX_SUBTASK;\
	return STX_OK;\
}


STX_PRIVATE STX_RESULT call_task_ex
(sync_source* the,stx_base_plugin* plug,stx_task* h_task)
{
	STX_RESULT i_err;

	// save last time plug;
	h_task->tctx.plug = plug;

	if( h_task->tctx.i_flag & TCTX_SLEEP ) {

		h_task->tctx.i_flag &= ~TCTX_SLEEP;

		// return to h_ssrc->xsleep;
		i_err = xtswap((void**)(h_task->tctx.p_stack-sizeof(void*)*2),
			*(void**)(h_task->tctx.p_stack-sizeof(void*))); 

		if( h_task->tctx.i_flag & TCTX_SLEEP ) {
			// return from xsleep;
			return STX_WOUNLD_BLOCK;
		}

		CHECK_XWAIT

		// return from task;
		h_task->tctx.plug = NULL;
		return i_err;

	} // if( h_task->tctx.i_flag & TCTX_SLEEP ) {


	if( h_task->tctx.i_flag & TCTX_SUSPEND ) {

		h_task->tctx.i_flag &= ~TCTX_SUSPEND;

		// return to h_ssrc->xsleep;
		i_err = xtswap((void**)(h_task->tctx.p_stack-sizeof(void*)*2),
			*(void**)(h_task->tctx.p_stack-sizeof(void*))); 

		if( h_task->tctx.i_flag & TCTX_SLEEP ) {
			// return from xsleep;
			return STX_WOUNLD_BLOCK;
		}

		CHECK_XWAIT

		// return from task;
		h_task->tctx.plug = NULL;
		return i_err;

	} // if( h_task->tctx.i_flag & TCTX_SLEEP ) {


	i_err = xtcall(h_task->tctx.p_stack,plug->run,plug,&h_task->sync);

	if( h_task->tctx.i_flag & TCTX_SLEEP ) {
		// return from xsleep;
		return STX_WOUNLD_BLOCK;
	}

	CHECK_XWAIT

	// return from task;
	h_task->tctx.plug = NULL;

	return i_err;
}

/***************************************************************************
stx_sync_source_vt_asy_plug_xxx_run
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
param h_sync is NULL, calling from come from other ssrc;
***************************************************************************/
//__declspec( thread ) int g_thread_test = 0;

STX_PURE STX_RESULT 
stx_sync_source_vt_asy_plug_xxx_run( THEE h,stx_sync_inf* h_sync)
{
	STX_RESULT					i_err;
	stx_task*					h_task;
	stx_base_plugin*			plug;
	s32							i;

	STX_MAP_THE(sync_source);

	//*(s32*)0 = 0;

#if 0
	if(!g_thread_test ) {
		g_thread_test = 1;
		stx_log("g_thread_test = 0x%x\r\n",&g_thread_test);
	}
#endif

	i_err = STX_OK;

	h_sync->i_idle =  MILISEC2REFTIME(1); // 1 ms;	
	h_task = waitfor_task(the,h_sync);
	if( !h_task ) {
		if( h_sync->i_idle >  MILISEC2REFTIME(10) ){
			h_sync->i_idle =  MILISEC2REFTIME(10); // 10 ms;	
		}
		return STX_IDLE;
	}

	// reset value;
	h_sync->i_idle = 0;

	the->i_last_time = h_task->i_last_time = stx_get_milisec();

	plug = (stx_base_plugin*)stx_stack_top(h_task->sync.h_stack);

 	//stx_log("run task\r\n");

	h_task->sync.i_result = 0;
	h_task->sync.h_task = h_task;
	h_task->sync.h_ssrc = (stx_sync_source*)h;
	
	for( ; ; ) {

		plug = (stx_base_plugin*)stx_stack_pop(h_task->sync.h_stack);

		if( !plug) {
			plug = h_task->plug;
			if(g_i_debug & GBD_DEBUG_LAST_PLUG ) {
				stx_log("last plug: <%s> invalid task entry \r\n", the->sz_last_task);
			}
			else if( g_i_debug & GBD_DEBUG_TASK_STATUS ) {
				stx_log("task: <%s> invalid task entry \r\n", XCALL(get_name,h_task->plug) );
			}
			return stx_base_plugin_stop(plug,STX_FAIL,TRUE);
		} // if( !plug) {

		plug = *(stx_base_plugin**)plug;

		if( plug == h_task->plug ) {

			if( !(h_task->tctx.i_flag & TCTX_SLEEP) ) {

				if( h_task->i_events & ev_pause ) {
					if(g_i_debug & GBD_DEBUG_TASK_STATUS ) {
						char szins[64];
						stx_gid insgid = plug->get_insid(plug);
						binary_to_string(16,insgid.data,szins);
						stx_log("task: <%s><%s> paused \r\n", plug->get_name(plug),szins);
					}
					plug->set_status(plug,emStxStatusPause);
					return STX_OK;	
				}
				else if( h_task->i_events & ev_stop ) {
					if(g_i_debug & GBD_DEBUG_TASK_STATUS ) {
						char szins[64];
						stx_gid insgid = plug->get_insid(plug);
						binary_to_string(16,insgid.data,szins);
						stx_log("kill task: <%s><%s>  \r\n", plug->get_name(plug),szins);
					}
					plug->set_status(plug,emStxStatusStop);
					return STX_OK;	
				}

			} //if( !(h_task->tctx.i_flag & TCTX_SLEEP) ) {

		} // ONLY permit to kill/pause task when the root plugin on turn;


		if( g_i_debug & (GBD_DEBUG_PLUG_MONITOR|GBD_DEBUG_TASK_MONITOR) ) {

			STX_RESULT	re;
			u8*			h_data;
			s32			i_len;
			s64			i_cur_time;
			s64			i_last_time;
			s64			i_toccupy,i_occupy;

			i_cur_time = stx_get_microsec();

			if( h_task->i_type & TASK_TYPE_AS ) {
				i_err = call_task_ex(the,plug,h_task);
			}
			else{
				do{
					h_task->sync.i_flags = CALL_TYPE_NOT_USED;
					h_task->sync.i_idle = 0;
					i_err = plug->run(plug,&h_task->sync);
				}while(STX_AGAIN == i_err);
			}

			i_toccupy = stx_get_microsec() - i_cur_time;

			if( g_i_debug & GBD_DEBUG_TASK_MONITOR ){
				stx_stat_add_val(h_task->h_stat,i_toccupy);
				i_occupy = stx_stat_get_occupy(h_task->h_stat);
				if( i_occupy ) {
					i_occupy = 1000 - i_occupy;
					if( i_cur_time -  h_task->i_report_time > 6000000 /*&& i_occupy > 100 */) {
						h_task->i_report_time = i_cur_time;
						stx_log("task %s occupy is %d/1000\r\n",XCALL(get_name,h_task->plug),(s32)i_occupy);
					}
				}
			}
			
			if( g_i_debug & GBD_DEBUG_PLUG_MONITOR ){
				stx_plug_monitor* h_mor;
				h_data = plug->read_key(plug,STX_REG_MONITOR,&i_len);
				if( h_data ) {
					h_mor = *(stx_plug_monitor**)h_data;
					// add the val to this plug;
					stx_stat_add_val(h_mor->h_stat,i_toccupy);
					h_mor->i_last_time = i_cur_time;
					i_occupy = stx_stat_get_occupy(h_mor->h_stat);
					if( i_occupy ) {
						i_occupy = 1000 - i_occupy;
						if( i_cur_time - h_mor->i_report_time  > 6000000 /*&& i_occupy > 100*/) {
							stx_log("%s occupy is %d/1000\r\n",plug->get_name(plug),(s32)i_occupy);
							h_mor->i_report_time = i_cur_time;
						}
					}
				}

#if 0
				if( STX_WOUNLD_BLOCK == i_err || STX_IDLE == i_err ) {
					if( h_task->sync.i_idle < USEC2REFTIME(100) ) {
						stx_log("<%s> retry time is too small:%d\r\n",plug->get_name(plug),
							(s32)REFTIME2USEC(h_task->sync.i_idle));
					}
				}
#endif

			} // if( g_i_debug & GBD_DEBUG_PLUG_MONITOR ){
		}
		else{
			if( h_task->i_type & TASK_TYPE_AS ) {
				i_err = call_task_ex(the,plug,h_task);
			}
			else{
				do{
					h_task->sync.i_flags = CALL_TYPE_NOT_USED;
					h_task->sync.i_idle = 0;
					i_err = plug->run(plug,&h_task->sync);
				}while(STX_AGAIN == i_err);
			}
		}

		if( g_i_debug & GBD_DEBUG_TASK_STATUS ) {
			stx_strcpyn(the->sz_last_task,sizeof(the->sz_last_task),plug->get_name(plug));
		}

		if( STX_OK == i_err ) {
			if( plug == h_task->plug ) {
				break;
			}
			if( h_task->sync.i_result & STX_SUBTASK ) { 
				break;
			}
			continue;
		} // if( STX_OK == i_err ) {

		break;
 
	} // for( ; ; ) {


	h_task->i_next_time = h_task->sync.i_idle;

 	//stx_log("task return: %d \r\n", i_err );

	// error or finished;
	if( i_err < 0 || STX_EOF == i_err ) {

		if( g_i_debug & GBD_DEBUG_TASK_STATUS ) {
			char szins[64];
			stx_gid insgid = plug->get_insid(plug);
			binary_to_string(16,insgid.data,szins);
			stx_log("task: <%s><%s> exit code = %s \r\n", 
				plug->get_name(plug),szins,stx_err_string(i_err) );
		}

		return stx_base_plugin_stop(plug,i_err,TRUE);
	} // if( i_err < 0 || STX_EOF == i_err ) {

	// STX_OK;
	if( STX_OK == i_err ) { 

		if( h_task->sync.i_result & STX_SUBTASK ) { 
			h_task->sync.i_result &= ~STX_SUBTASK;
			return STX_OK;
		} // if( sync_inf.i_result & STX_SUBTASK ) {

		// set execute time to 0;
		h_task->i_next_time = 0;

	} // if( STX_OK == i_err ) {
	

	// STX_IDLE OR STX_WOUNLD_BLOCK	
	if(  STX_OK == i_err || STX_IDLE == i_err || STX_WOUNLD_BLOCK == i_err ) { 
		
		// reinsert it to task heap;

		lock_;

		if( !h_task->fTimerHeapElem.fCurrentHeap ) {

			s64 i_idle = REFTIME2USEC( h_task->i_next_time);
#if 0
			stx_log("task <%s> idle time is %"PRId64"d us;\r\n",XCALL(get_name,h_task->plug),i_idle);
#endif
			h_task->fTimerHeapElem.fValue = stx_get_microsec() + i_idle;

			h_task->fTimerHeapElem.fEnclosingObject = h_task;

			stxHeapInsert(h_task->h_heap,&h_task->fTimerHeapElem);

		}//if( !h_task->fTimerHeapElem.fCurrentHeap ) {

		unlock_;

		return STX_OK;

	} //if( STX_IDLE == i_err || ST	  

	// OTHER
	return i_err;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT on_auto_stop(STX_HANDLE h,stx_base_message* p_msg)
{
	STX_MAP_THE(sync_source);
	{
		STX_HANDLE h_stack = p_msg->get_stack(p_msg);

		stx_base_plugin* const plug = (stx_base_plugin*)*stx_stack_pop(h_stack);

		stx_msg_cnt* p_cnt = p_msg->get_msg_cnt(p_msg);

		p_cnt->msg_gid = STX_MSG_AppStop; // change msg id;

		p_msg->set_msg_type(p_msg,STX_MSG_TYPE_DOWNSTREAM); // change msg type;

		return plug->send_msg(plug,p_msg);
	}
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_sync_source_vt_asy_plug_xxx_get_property
(STX_HANDLE h,stx_xio* h_xio)
{
	STX_MAP_THE(sync_source);

	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_sync_source_vt_asy_plug_xxx_set_property
(STX_HANDLE h,stx_xio* h_xio)
{
	STX_MAP_THE(sync_source);

	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT on_unregister_module(STX_HANDLE h,stx_base_message* p_msg)
{
	STX_MAP_THE(sync_source);
	{
		stx_base_graph_builder* h_gbd;
		stx_msg_cnt* cnt = p_msg->get_msg_cnt(p_msg);
		STX_PEEK_THE(stx_base_graph_builder,h_gbd,the);
		h_gbd->unregister_module_as(h_gbd,(THEE)cnt->param.i_param[0]);
		p_msg->set_msg_close(p_msg);
	}
	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT stx_sync_source_vt_asy_plug_xxx_flush
(STX_HANDLE h,u32 i_flag,stx_sync_inf *h_sync)
{
	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT stx_sync_source_vt_asy_plug_xxx_start
(STX_HANDLE h,u32 i_flag,stx_sync_inf *h_sync)
{	
	STX_MAP_THE(sync_source);
	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT stx_sync_source_vt_asy_plug_xxx_stop
(STX_HANDLE h,u32 i_flag,stx_sync_inf *h_sync)
{
	STX_MAP_THE(sync_source);
	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE b32 stx_sync_source_vt_xxx_is_started(STX_HANDLE h)
{
	STX_MAP_THE(sync_source);
	return the->thread_param.b_started;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE s64 stx_sync_source_vt_xxx_get_last_task_time(THEE h)
{
	STX_MAP_THE(sync_source);
	return the->i_last_time;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE char* stx_sync_source_vt_xxx_get_last_task_name(THEE h)
{
	STX_MAP_THE(sync_source);
	return the->sz_last_task;
}




#undef lock_
#undef unlock_
