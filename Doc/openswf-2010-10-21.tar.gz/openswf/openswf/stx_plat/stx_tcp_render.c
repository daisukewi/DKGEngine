/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#include "stx_all.h"
#include "stp_client.h"
#include "stp_pressure.h"
#include "stx_prop_def.h"
#include "stx_protocol.h"

#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif

#ifdef _MAP_THE	
#	undef _MAP_THE	
#endif	
#define _MAP_THE STX_MAP_THE(stx_tcp_render)


DEFINE_XGUID( STX_CLSID_tcp_render,
0x7b9706f0, 0xd4c1, 0x4f72, 0x80, 0xf, 0xd8, 0x45, 0x7d, 0x53, 0x4d, 0x4b );

char* g_szStreamX_tcp_render = STX_PLUGIN_STRING(tcp_render);

STX_INPUT_MEDIA_TYPE_MAP_BEGIN(stx_tcp_render)
/**/MEDIA_TYPE_MAP_ITEM(STX_GID_NULL,STX_GID_NULL)
STX_INPUT_MEDIA_TYPE_MAP_END()

STX_OUTPUT_MEDIA_TYPE_MAP_BEGIN(stx_tcp_render)
STX_OUTPUT_MEDIA_TYPE_MAP_END()


STX_COM_BEGIN(stx_tcp_render);
/**/
/**/STX_PUBLIC(stx_base_render)
/**/STX_COM_DATA_DEFAULT(stx_base_render)
/**/
/**/stx_base_pin*	 p_input_pin;
/**/
/**/s64              i_start_sample_time;
/**/s64              i_start_time;
/**/s64              i_last_sample_time;
/**/s64              i_last_time;
/**/
/**/b32				 b_push_mode;   // default true;
/**/stx_xio*		 h_client;
/**/stx_xio*		 h_tcp;			// tcp handle get from client;
/**/char			 sz_ip[128];	// prop
/**/u16				 i_port;		// prop
/**/char*			 sz_graph;		// prop
/**/STX_HANDLE		 h_stack;
/**/STX_HANDLE		 h_stat;
/**/size_t			 i_status;
/**/
/**/stx_xio*		 h_output;
/**/u8*				 p_data;
/**/size_t			 i_data_size;
/**/stx_gid			 major_type;
/**/stx_gid			 sub_type;
/**/stx_media_data*  h_mdat;
/**/
STX_COM_END();


STX_COM_FUNC_DECL_DEFAULT(stx_base_render,stx_base_render_vt);
STX_COM_FUNCIMP_DEFAULT(stx_tcp_render,stx_base_render,stx_base_render_vt);



/*{{{STX_MSG_PROC_DECLARE***************************************************/
/**/STX_MSG_PROC_DECLARE(dispatch_msg)
/**/STX_MSG_PROC_DECLARE(response_msg)
//STX_MSG_PROC_DECLARE(down_stream_msg)
/*}}}***********************************************************************/


/*{{{STX_MSG_ENTRY_DECLARE**************************************************/
/**/STX_MSG_ENTRY_DECLARE(on_Play)
/**/STX_MSG_ENTRY_DECLARE(on_Stop)
/**/STX_MSG_ENTRY_DECLARE(at_Stop)
/**/STX_MSG_ENTRY_DECLARE(at_BreakPin)
/*}}}***********************************************************************/


/*{{{STX_BEGIN_MSG_MAP******************************************************/
STX_BEGIN_MSG_MAP(the_msg_data)
/* to do : add msg process entry here; */
/**/ON_STX_MSG(STX_MSG_Play,on_Play)
/**/ON_STX_MSG(STX_MSG_Stop,on_Stop)
STX_END_MSG_MAP
/*}}}***********************************************************************/

/*{{{STX_DISPATCH_MSG_PROC**************************************************/
STX_DISPATCH_MSG_PROC( dispatch_msg,the_msg_data )
/*}}}***********************************************************************/


/*{{{STX_BEGIN_MSG_RESPONSE_MAP*********************************************/
STX_BEGIN_MSG_RESPONSE_MAP(the_msg_response)
/* to do : add msg process entry here; */
/**/ON_STX_MSG(STX_MSG_BreakPin,at_BreakPin)
/**/ON_STX_MSG(STX_MSG_Stop,at_Stop)
STX_END_MSG_RESPONSE_MAP
/*}}}***********************************************************************/


/*{{{STX_RESPONSE_MSG_PROC**************************************************/
STX_RESPONSE_MSG_PROC( response_msg,the_msg_response )
/*}}}***********************************************************************/


STX_PRIVATE STX_RESULT make_media_stream_header(stx_tcp_render* the);
STX_PRIVATE STX_RESULT make_media_stream(stx_tcp_render* the,stx_media_data* p_mdat);
STX_PRIVATE STX_RESULT write_media_stream(stx_tcp_render* the,stx_sync_inf* h_sync );



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_COM_MAP_BEGIN(stx_tcp_render)
/**/STX_COM_MAP_ITEM(STX_IID_BaseRender)
STX_COM_MAP_END()

STX_NEW_BEGIN(stx_tcp_render)
{
	STX_SET_THE(stx_base_render);
	STX_COM_NEW_DEFAULT(stx_base_render,the->stx_base_render_vt,stx_base_render_vt,
		STX_CLSID_tcp_render,STX_CATEGORY_Render,g_szStreamX_tcp_render);

	the->p_input_pin = XCREATE(stx_input_pin,NULL);
	if( !the->p_input_pin ) {
		break;
	}
	XCALL(set_parent,the->p_input_pin,(stx_base_plugin *)&the->stx_base_render_vt);

	the->h_stat = stx_stat_create();
	if( !the->h_stat) {
		break;
	}

	the->h_output = XCREATE(stx_io_stream,NULL);
	if( !the->h_output ) {
		break;
	}

	// service ip/port;
	stx_strcpy(the->sz_ip,sizeof(the->sz_ip),g_sz_ip4_default);
	the->i_port = atoi(g_sz_port_default);

	// graph
	the->sz_graph = xstrdup("@input valid graph file");
	if( !the->sz_graph ) {
		break;
	}

	the->b_push_mode = TRUE;
}
STX_NEW_END()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_PURE 
STX_QUERY_BEGIN(stx_tcp_render)
{
	STX_COM_QUERY_DEFAULT(stx_base_render,the->stx_base_render_vt);
}
STX_QUERY_END()




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_DELETE_BEGIN(stx_tcp_render)
{
	if( the->sz_graph ) {
		stx_free(the->sz_graph);
		the->sz_graph = NULL;
	}

	if( the->h_stack ) {
		stx_stack_close(the->h_stack);
		the->h_stack = NULL;
	}

	if( the->h_stat ) {
		stx_stat_close(the->h_stat);
		the->h_stat = NULL;
	}

	SAFE_CLOSEXIO(the->h_output);
	SAFE_CLOSEXIO(the->h_client);

	SAFE_XDELETE0(the->p_input_pin);

	STX_COM_DELETE_DEFAULT(stx_base_render);
}
STX_DELETE_END
(
/**/STX_COM_DELETE_BEGIN(stx_base_render)
/**/,
/**/STX_COM_DELETE_END(stx_base_render)
)





 /***************************************************************************
 RETURN VALUE:
 INPUT:
 OUTPUT:
 NOTE:
 ***************************************************************************/
 STX_PURE STX_RESULT stx_base_render_vt_flt_plug_xxx_send_msg
 ( STX_HANDLE h, stx_base_message* p_msg )
{
	_MAP_THE;
	{
		STX_RESULT	i_err;
		u32			i_type;

		i_err = dispatch_msg(h,p_msg);
		if( i_err < 0 || p_msg->is_msg_closed(p_msg)) {
			return i_err;
		}

		i_type = p_msg->get_msg_type(p_msg);

		if( i_type & STX_MSG_TYPE_UPSTREAM && the->p_input_pin ) {
			i_err = the->p_input_pin->send_msg(the->p_input_pin,p_msg);
			if( i_err < 0 || p_msg->is_msg_closed(p_msg)) {
				return i_err;
			}
		}

		return response_msg(h,p_msg);
	}

	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
as for emulate filter, the initial state of this render have no input pin and 
any data type;
so the emulate filter could not be registered, must be load and unload at run time;
***************************************************************************/
STX_PURE STX_RESULT stx_base_render_vt_flt_xxx_enum_input_pin
(STX_HANDLE h,sint32 *i_idx,stx_base_pin** pp_pin )
{
	_MAP_THE;

	if( !i_idx ) {
		return STX_ERR_INVALID_PARAM;
	}

	if( !pp_pin ) {
		*i_idx = 1;
		return STX_OK;
	}

	if( *i_idx != 0 ) {
		return STX_ERR_INVALID_PARAM;
	}

	the->p_input_pin->add_ref(the->p_input_pin);
	*pp_pin = the->p_input_pin;

	return STX_OK;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_render_vt_flt_xxx_enum_output_pin
(STX_HANDLE h,sint32* i_idx,stx_base_pin** pp_pin )
{
	_MAP_THE;

	if( !i_idx ) {
		return STX_ERR_INVALID_PARAM;
	}

	if( !pp_pin ) {
		*i_idx = 0;
		return STX_OK;
	}

	return STX_ERR_INVALID_PARAM;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_render_vt_flt_xxx_check_input_media_type
( STX_HANDLE h, stx_media_type* p_mtyp )
{
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_render_vt_flt_xxx_check_output_media_type
( STX_HANDLE h, stx_media_type* p_mtyp )
{
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_render_vt_flt_xxx_set_input_media_type
( STX_HANDLE h, stx_media_type* p_mdt )
{
	_MAP_THE;

	the->major_type = p_mdt->get_type(p_mdt);
	the->sub_type = p_mdt->get_subtype(p_mdt);

	return XCALL(set_media_type,the->p_input_pin,p_mdt);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_render_vt_flt_xxx_set_output_media_type
(STX_HANDLE	h,stx_media_type* p_mdt )
{
	return STX_ERR_NOT_SUPPORT;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_base_render_vt_flt_xxx_new_segment( STX_HANDLE h )
{
	_MAP_THE;

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_render_vt_flt_plug_xxx_flush
(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	_MAP_THE;

	return STX_OK;
}


enum tcp_render_status{
	tcp_render_open,
	tcp_render_write,
};




/***************************************************************************
stx_base_render_vt_flt_plug_xxx_start
RETURN VALUE:
INPUT:
OUTPUT:

NOTE:	push and pull

	push, the socket is created outside of filter;
	pull, the filter create the stp_client itself;

	as for tcp render filter,

	push mode, the graph and the tcp render must created by a service protocol;
	start is calling from the protocol->canvas_onLoadStream->,and the pin connection
	is already created by canvas_confirmconnection;
	so the input io socket handle could be query from the protocol;

	pull mode, the graph and the tcp render at editor, 
	and the other pear: tcp source, is at service;
	so only one output pin, one socket data channel allowed;

	to test the encode graph filter, 
	the tcp source work at graph editor+pull mode,
	and the tcp render work at service+push mode;

	rtsp_protocol, should create stp_client itself,and the client create connection to 
	encode service;
		the encode service then create the graph and the tcp render, 
		so it is work at push mode;
		when the render query output channel from the stx_protocol,
		it create audio/video channel;
		when the graph load stream success, the stx_protocol write response to
		the stp_client through control channel;
		the the stp_client(in rtsp_protocol) create the data sub channel;
		then stp_client open success;

	the rtsp_protocol should enum the data sub channel, and create tcp source + 
	rtp render graph for each channel;

	each tcp source work at push mode, when load_stream calling, it query the input
	io handle from rtsp_protocol; then initialize the mediatype;

	then the rtsp_protocol should query the mediatype from each tcp source,
	and create the sdp stream;

	download and http mode encode task, do not need tcp source and render;


***************************************************************************/
STX_PURE STX_RESULT stx_base_render_vt_flt_plug_xxx_start
(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	STX_RESULT	i_err;
	size_t*		h_status;
	size_t		i_status;

	_MAP_THE;

	if( the->b_push_mode ) {

		if( !the->h_stack ) {

			the->h_stack = stx_stack_create();
			if( !the->h_stack) {
				return STX_FAIL;
			}

			// open stx_client; push mode, the input string is of no use,
			// because the tcp source receive data from input socket;
			the->h_client = stx_create_io_stp(
				the->sz_ip,the->i_port,the->sz_graph,the->sz_graph,the->h_output);
			if( !the->h_client) {
				return STX_FAIL;
			}

			// because the header data not send by tcp render,so must reset the i_data_size;
			the->i_data_size = 0;

			i_status = tcp_render_open;
			
		}
		else {
			h_status = stx_stack_pop(the->h_stack);
			if( !h_status ) {
				return STX_FAIL;
			}
			i_status = *h_status;
		}

		if( tcp_render_open == i_status ) {

			do{
				i_err = XCALL(open,the->h_client,NULL,0);
			}while(STX_AGAIN == i_err);

			if( STX_IDLE == i_err || STX_WOUNLD_BLOCK == i_err ) {
				stx_stack_push(the->h_stack,tcp_render_open);
				h_sync->i_idle = MILISEC2REFTIME(10);
				return STX_WOUNLD_BLOCK;
			}

			if( i_err < 0 ) {
				stx_stack_close(the->h_stack);
				the->h_stack = NULL;
				return i_err;
			}

			{
				stx_io_op_param	inf;

				i_err = XCALL(get,the->h_client,STX_IO_READ_HND,&inf);
				if( STX_OK != i_err ) {
					return i_err;
				}
				// the push mode not used; or the logic is not correct;
				the->h_tcp = (stx_xio*)inf.h_obj;
				if(!the->h_tcp) {
					return STX_FAIL;
				}
			}

			// push mode, the media header send by stp client open;
			stx_stack_close(the->h_stack);
			the->h_stack = NULL;
			return STX_OK;
		}

	}
	else { 
		
		// pull mode, the tcp source at editor, 
		// current graph and the tcp render at service;

		if( !the->h_stack ) {

			stx_media_type* p_mtype = NULL;

			the->h_stack = stx_stack_create();
			if( !the->h_stack) {
				return STX_FAIL;
			}

			// media type 
			p_mtype = XCALL(get_media_type,the->p_input_pin);
			if(!p_mtype ) {
				return STX_FAIL;
			}
			the->major_type = p_mtype->get_type(p_mtype);
			the->sub_type = p_mtype->get_subtype(p_mtype);

			// query output socket xio;
			{
				// send upstream message, try to get a xio interface;
				stx_base_message*       p_msg_internal;
				stx_msg_cnt*			p_cnt;

				i_err = STX_FAIL;
				p_msg_internal = NULL;

				do{
					p_msg_internal = XCREATE(base_msg,NULL,NULL);
					if( !p_msg_internal ) {
						break;
					}
					XCALL(set_msg_type,p_msg_internal,STX_MSG_TYPE_UPSTREAM);
					i_err = XCALL(set_msg_buf,p_msg_internal,(u8*)&STX_IID_OutputIo,sizeof(STX_IID_OutputIo));
					if( STX_OK != i_err ) {
						break;
					}
					p_cnt = XCALL(get_msg_cnt,p_msg_internal);
					p_cnt->msg_gid = STX_MSG_QueryObject;
					p_cnt->param.i_param[0] = (size_t)p_mtype;

					i_err = XCALL(send_msg,the->p_input_pin,p_msg_internal);
					if( STX_OK != i_err ) {
						break;
					}

					if( !XCALL(is_msg_closed,p_msg_internal) ) {
						i_err = STX_FAIL;
						break;
					}

					the->h_tcp = (stx_xio*)p_cnt->param.i_param[0];
					if( !the->h_tcp ) {
						i_err = STX_FAIL;
						break;
					}

					i_err = STX_OK;

				}while(FALSE); // do{

				SAFE_XDELETE(p_mtype);
				SAFE_XDELETE(p_msg_internal);

				if( STX_OK != i_err ) {
					return i_err;
				}

			} // block

		}
		else {
			h_status = stx_stack_pop(the->h_stack);
			if( !h_status ) {
				return STX_FAIL;
			}
			i_status = *h_status;
		}
	}

	return i_err;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_render_vt_flt_plug_xxx_stop
(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	_MAP_THE;

	// stop stx_client;
	return STX_OK; 
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_render_vt_flt_xxx_receive
(
STX_HANDLE			h,
stx_base_pin*		h_pin, // which input pin;
stx_media_data**	pp_mdat, // output media data;
stx_sync_inf*		h_sync
)
{
	_MAP_THE;

	return STX_ERR_NOT_SUPPORT;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT make_media_stream_header(stx_tcp_render* the)
{
	STX_RESULT		i_err;
	stx_xini*		h_xini;
	stx_xio*		h_cmd_stream;
	stx_xio*		h_hdr_stream;
	STX_HANDLE		h_key;
	ByteIOContext	pb;
	char            buf[STX_DEFAULT_PATH];

	u8*				p_hdr;
	s32				i_hdr_size;

	stx_media_type* p_mtype;
	stx_io_op_param param;
	size_t			i_write;

	const char* sz_name;


	h_xini = NULL;
	h_cmd_stream = NULL;
	h_hdr_stream = NULL;
	p_mtype = NULL;


	do{

		i_err = STX_FAIL;

		h_cmd_stream = XCREATE(stx_io_stream,NULL);
		if( !h_cmd_stream ) {
			break;
		}

		i_err = stx_ini_create(NULL,h_cmd_stream,STX_INI_CREATE_NEW|STX_INI_NO_COMMENT,0,&h_xini);
		if( STX_OK != i_err ) {
			break;
		}

		// write deliver request,
		i_err = XCALL(create_key,h_xini,NULL,g_sz_service_request,NULL,&h_key);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = XCALL(write_int32,h_xini,h_key,(s32)STX_SERVICE_REQUEST_CONNECT);
		if( STX_OK != i_err ) {
			break;
		}


		// media type 
		p_mtype = XCALL(get_media_type,the->p_input_pin);
		if(!p_mtype ) {
			i_err = STX_FAIL;
			break;
		}
		the->major_type = p_mtype->get_type(p_mtype);
		the->sub_type = p_mtype->get_subtype(p_mtype);

		i_err = XCALL(create_key,h_xini,NULL,g_szStreamX_MajorDataType,NULL,&h_key);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = XCALL(write_binary,h_xini,h_key,sizeof(the->major_type),the->major_type.data);
		if( STX_OK != i_err ) {
			break;
		}
		sz_name = XCALL(get_subtype_name,p_mtype);
		i_err = XCALL(create_key,h_xini,NULL,g_szStreamX_MajorDataTypeName,sz_name,&h_key);
		if( STX_OK != i_err ) {
			break;
		}


		i_err = XCALL(create_key,h_xini,NULL,g_szStreamX_SubDataType,NULL,&h_key);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = XCALL(write_binary,h_xini,h_key,sizeof(the->sub_type),the->sub_type.data);
		if( STX_OK != i_err ) {
			break;
		}
		sz_name = XCALL(get_subtype_name,p_mtype);
		i_err = XCALL(create_key,h_xini,NULL,g_szStreamX_SubDataTypeName,sz_name,&h_key);
		if( STX_OK != i_err ) {
			break;
		}

		// header;
		i_err = XCALL(get_header,p_mtype,&p_hdr,&i_hdr_size);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = XCALL(create_key,h_xini,NULL,g_szStreamX_header,NULL,&h_key);
		if( STX_OK != i_err ) {
			break;
		}

		h_hdr_stream = XCREATE(stx_io_stream,NULL);
		if( !h_hdr_stream ) {
			i_err = STX_FAIL;
			break;
		}

		if( IS_EQUAL_GID(the->major_type,MEDIATYPE_Video)) {
			i_err = encode_vd2((STX_VIDEOINFOHEADER2*)p_hdr,i_hdr_size,h_hdr_stream);
			if( STX_OK != i_err ) {
				break;
			}
		}
		else if( IS_EQUAL_GID(the->major_type,MEDIATYPE_Audio) ) {
			i_err = encode_wex((STX_WAVEFORMATEXTENSIBLE*)p_hdr,i_hdr_size,h_hdr_stream);
			if( STX_OK != i_err ) {
				break;
			}
		}
		else {
			i_err = STX_FAIL;
			break;
		}

		INIT_MEMBER(param);
		i_err = XCALL(get,h_hdr_stream,STX_IO_READ_P,&param);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = XCALL(write_base64,h_xini,h_key,(u32)param.i_available_data,param.buf);
		if( STX_OK != i_err ) {
			break;
		}

		// close it, save xini body to h_cmd_stream;
		h_xini->close(h_xini);
		h_xini = NULL;

		// get xini body data pointer and length;
		INIT_MEMBER(param);
		i_err = XCALL(get,h_cmd_stream,STX_IO_READ_P,&param);
		if( STX_OK != i_err ) {
			break;
		}

		// third, send media data; the size is decsripted at xini;
		XCALL(clear,the->h_output);

		INIT_BYTEIO_W(pb,STX_DEFAULT_PATH,(uint8*)buf,the->h_output);

		// write header;
		// STX: FLAG LEN XINI DATA		
		put_tag(&pb,g_sz_prot_stx);
		put_be32(&pb,STX_PROTOCOL_XINI);
		put_be32(&pb,(u32)param.i_available_data);

		// write xini body;
		i_err = xio_fwrite(&pb,(const u8*)param.buf,(size_t)param.i_available_data,&i_write);
		if( STX_OK != i_err ) {
			break;
		}

		// flush out data;
		xio_flush(&pb);

		// set the output data value;
		INIT_MEMBER(param);
		i_err = XCALL(get,the->h_output,STX_IO_READ_P,&param);
		if( STX_OK != i_err ) {
			break;
		}
		the->p_data = param.buf;
		the->i_data_size = (size_t)param.i_available_data;

/*
		{
			char sz_data[32];
			binary_to_string(12,the->p_data,sz_data);
			stx_log("tcp_render:make_media_stream_header:%s\r\n",sz_data);
		}
*/

		i_err = STX_OK;

	}while(FALSE);

	SAFE_XDELETE(p_mtype);
	SAFE_CLOSEXIO(h_xini);
	SAFE_CLOSEXIO(h_cmd_stream);
	SAFE_CLOSEXIO(h_hdr_stream);

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT make_media_stream(stx_tcp_render* the,stx_media_data* p_mdat)
{
	STX_RESULT		i_err;
	stx_xini*		h_xini;
	stx_xio*		h_cmd_stream;
	STX_HANDLE		h_key;
	ByteIOContext	pb;
	char            buf[STX_DEFAULT_PATH];
	char			sz_key[STX_DEFAULT_PATH];

	VideoFrame*		p_frame;
	s32				i;
	u8*				p_data;
	size_t			i_data_size;

	stx_io_op_param param;
	size_t			i_write;

	s64				dts,pts,dura;


	h_xini = NULL;
	h_cmd_stream = NULL;


	do{

		i_err = STX_FAIL;

		h_cmd_stream = XCREATE(stx_io_stream,NULL);
		if( !h_cmd_stream ) {
			break;
		}

		i_err = stx_ini_create(NULL,h_cmd_stream,STX_INI_CREATE_NEW|STX_INI_NO_COMMENT,0,&h_xini);
		if( STX_OK != i_err ) {
			break;
		}

		// deliver media data 
		i_err = XCALL(create_key,h_xini,NULL,g_sz_service_request,NULL,&h_key);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = XCALL(write_int32,h_xini,h_key,(s32)STX_SERVICE_REQUEST_DELIVER);
		if( STX_OK != i_err ) {
			break;
		}

		if( IS_EQUAL_GID(MEDIATYPE_Video,the->major_type) 
			&& IS_EQUAL_GID(MEDIASUBTYPE_LxVideoFrame,the->sub_type) ) {
				i_data_size = 0;
		}
		else {
			// length;
			i_err = XCALL(get_data,p_mdat,&p_data,&i_data_size);
			if( STX_OK != i_err ) {
				break;
			}
		}

		i_err = XCALL(create_key,h_xini,NULL,g_szStreamX_length,NULL,&h_key);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = XCALL(write_int32,h_xini,h_key,(s32)i_data_size);
		if( STX_OK != i_err ) {
			break;
		}

		// dts; pts;
		pts = dts = -1;
		pts = XCALL(get_time,p_mdat,&dts);
		i_err = XCALL(create_key,h_xini,NULL,g_szStreamX_pts,NULL,&h_key);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = XCALL(write_int64,h_xini,h_key,pts);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = XCALL(create_key,h_xini,NULL,g_szStreamX_dts,NULL,&h_key);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = XCALL(write_int64,h_xini,h_key,dts);
		if( STX_OK != i_err ) {
			break;
		}

		// duration;
		dura = p_mdat->get_duration(p_mdat);
		i_err = XCALL(create_key,h_xini,NULL,g_szStreamX_duration,NULL,&h_key);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = XCALL(write_int64,h_xini,h_key,dura);
		if( STX_OK != i_err ) {
			break;
		}

		if( IS_EQUAL_GID(MEDIATYPE_Video,the->major_type) 
			&& IS_EQUAL_GID(MEDIASUBTYPE_LxVideoFrame,the->sub_type) ) {

				i_err = XCALL(query_interf,p_mdat,STX_IID_LxVideoFrame,&p_frame);
				if( STX_OK != i_err ) {
					break;
				}
				SAFE_XDELETE(p_mdat);

				// width
				i_err = XCALL(create_key,h_xini,NULL,g_szStreamX_width,NULL,&h_key);
				if( STX_OK != i_err ) {
					break;
				}
				i_err = XCALL(write_int32,h_xini,h_key,p_frame->nCodedPictureWidth);
				if( STX_OK != i_err ) {
					break;
				}
				// height
				i_err = XCALL(create_key,h_xini,NULL,g_szStreamX_height,NULL,&h_key);
				if( STX_OK != i_err ) {
					break;
				}
				i_err = XCALL(write_int32,h_xini,h_key,p_frame->nCodedPictureHeight);
				if( STX_OK != i_err ) {
					break;
				}

				// pitch
				for( i = 0; i < 3; i++ ) {

					stx_sprintf(sz_key,sizeof(sz_key),"%s-%d",g_szStreamX_pitch,i);

					i_err = XCALL(create_key,h_xini,NULL,sz_key,NULL,&h_key);
					if( STX_OK != i_err ) {
						break;
					}
					i_err = XCALL(write_int32,h_xini,h_key,p_frame->nPitch[i]);
					if( STX_OK != i_err ) {
						break;
					}
				}

				if( STX_OK != i_err ) {
					break;
				}

		}


		// close it, save xini body to h_cmd_stream;
		h_xini->close(h_xini);
		h_xini = NULL;

		// get xini body data pointer and length;
		INIT_MEMBER(param);
		i_err = XCALL(get,h_cmd_stream,STX_IO_READ_P,&param);
		if( STX_OK != i_err ) {
			break;
		}

		// third, send media data; the size is decsripted at xini;
		XCALL(clear,the->h_output);

		INIT_BYTEIO_W(pb,STX_DEFAULT_PATH,(uint8*)buf,the->h_output);

		// write header;
		// STX: FLAG LEN XINI DATA		
		put_tag(&pb,g_sz_prot_stx);
		put_be32(&pb,STX_PROTOCOL_XINI);
		put_be32(&pb,(u32)param.i_available_data);


		// write xini body;
		i_err = xio_fwrite(&pb,(const u8*)param.buf,(size_t)param.i_available_data,&i_write);
		if( STX_OK != i_err ) {
			break;
		}

		// flush out data;
		xio_flush(&pb);

		// write video frame or media data;
		if( IS_EQUAL_GID(MEDIATYPE_Video,the->major_type) 
			&& IS_EQUAL_GID(MEDIASUBTYPE_LxVideoFrame,the->sub_type) ) {

				for( i = 0; i < 3; i ++ ) {

					s32 j,h;

					h = i ? p_frame->nCodedPictureHeight/2 :  p_frame->nCodedPictureHeight;

					p_data = p_frame->lpData[i];

					for( j = 0; j < h; j ++ ) {

						i_err = XCALL(write,the->h_output,p_data,p_frame->nPitch[i],&i_write);
						if( STX_OK != i_err ) {
							break;
						}

						p_data += p_frame->nPitch[i];
					}

				} // for( i = 0; i < 3; i ++ ) {

				if( STX_OK != i_err ) {
					break;
				}
		}
		else {

			i_err = XCALL(write,the->h_output,p_data,i_data_size,&i_write);
			if( STX_OK != i_err ) {
				break;
			}
		}



		// set the output data value;
		INIT_MEMBER(param);
		i_err = XCALL(get,the->h_output,STX_IO_READ_P,&param);
		if( STX_OK != i_err ) {
			break;
		}
		the->p_data = param.buf;
		the->i_data_size = (size_t)param.i_available_data;

/*
		{
			char sz_data[32];
			binary_to_string(12,the->p_data,sz_data);
			stx_log("tcp_render:make_media_stream:%s\r\n",sz_data);
		}
*/

		i_err = STX_OK;

	}while(FALSE);

	if( h_xini ) {
		h_xini->close(h_xini);
	}

	if( h_cmd_stream ) {
		h_cmd_stream->close(h_cmd_stream);
	}

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT write_media_stream(stx_tcp_render* the,stx_sync_inf* h_sync )
{

	STX_RESULT i_err;

	while( the->i_data_size ){

		size_t i_write;

		size_t i_data  = (size_t)(  the->i_data_size > 32*1024 ? 32*1024:  the->i_data_size );

		do{
			i_err = XCALL(write,the->h_tcp,the->p_data,i_data,&i_write);
		}while(STX_AGAIN ==i_err);

		if( STX_OK != i_err ) {
			if( STX_IDLE == i_err || STX_WOUNLD_BLOCK == i_err ) {
				h_sync->i_idle = MILISEC2REFTIME(1);
			}
			return i_err;
		}


/*		if( i_data >= STX_PROT_HDR_SIZE ) {
			char sz_data[32];
			binary_to_string(12,the->p_data,sz_data);
			stx_log("tcp_render:write_media_stream:%s\r\n",sz_data);
		}
*/

		the->p_data += i_write;
		the->i_data_size -= i_write;

		//stx_stat_add_val(the->h_stat,(s64)i_write);

	} //while( the->i_data_size ){

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_render_vt_flt_xxx_deliver
(
	STX_HANDLE			h,
	stx_base_pin*		h_pin,		// which input pin;
	stx_media_data*		p_mdat,		// output media data;
	stx_sync_inf*		h_sync
)
{
	_MAP_THE;
	{
		the->h_mdat = p_mdat;
		RESET_XENTRY(h_sync,h);
		return STX_OK;
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_ENTRY STX_RESULT on_Play(STX_HANDLE h, stx_base_message* p_msg )
{
	_MAP_THE;


	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_ENTRY STX_RESULT at_BreakPin(STX_HANDLE h, stx_base_message* p_msg )
{
	_MAP_THE;

	if( the->p_input_pin ) {
		XCALL(break_connect,the->p_input_pin);
	}

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_ENTRY STX_RESULT on_Stop(STX_HANDLE h, stx_base_message* p_msg )
{
	_MAP_THE;

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_ENTRY STX_RESULT at_Stop(STX_HANDLE h, stx_base_message* p_msg )
{
	_MAP_THE;

	return STX_OK;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_render_vt_flt_plug_xxx_run
(STX_HANDLE h,stx_sync_inf* h_sync )
{
	_MAP_THE;
	{
		STX_RESULT		i_err;

		if( the->h_mdat ) {
			i_err = make_media_stream(the,the->h_mdat);
			XCALL(release_media_data,the->p_input_pin,the->h_mdat);
			if( i_err != STX_OK ) {
				return i_err;
			}
			the->h_mdat = NULL;
		}

		i_err = write_media_stream(the,h_sync);
		if( STX_IDLE == i_err || STX_WOUNLD_BLOCK == i_err ) {
			RESET_XENTRY(h_sync,h);
		}
		return i_err;
	}

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_render_vt_flt_plug_xxx_get_property
(STX_HANDLE h,stx_xio* h_xio)
{
	_MAP_THE;

	{
		STX_RESULT i_err;
		stx_xini*  h_xini;
		STX_HANDLE h_prop;

		i_err = STX_FAIL;
		h_xini = NULL;


		do{

			i_err = stx_ini_create(NULL,h_xio,STX_INI_READ_WRITE|STX_INI_NO_COMMENT,0,&h_xini);
			if(STX_INI_OK != i_err ) {
				break;
			}

			// push mode;
			i_err = XCALL(create_key,h_xini,NULL,g_szStreamX_pushmode,NULL,&h_prop);
			if(STX_INI_OK != i_err ) {
				break;
			}
			i_err = XCALL(write_int32,h_xini,h_prop,the->b_push_mode);
			if(STX_OK != i_err ) {
				break;
			}

			// service ip
			i_err = XCALL(create_key,h_xini,NULL,g_sz_ip4,(char*)the->sz_ip,&h_prop);
			if(STX_INI_OK != i_err ) {
				break;
			}

			// service port
			i_err = XCALL(create_key,h_xini,NULL,g_sz_port,NULL,&h_prop);
			if(STX_INI_OK != i_err ) {
				break;
			}
			i_err = XCALL(write_int32,h_xini,h_prop,the->i_port);
			if(STX_OK != i_err ) {
				break;
			}

			// graph file;
			i_err = XCALL(create_key,h_xini,NULL,g_sz_GRAPH,the->sz_graph,&h_prop);
			if(STX_INI_OK != i_err ) {
				break;
			}

			i_err = STX_OK;

		}while(FALSE);

		if( h_xini ) {
			h_xini->close(h_xini);
		}

		return i_err;
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_render_vt_flt_plug_xxx_set_property
(STX_HANDLE h,stx_xio* h_xio)
{
	_MAP_THE;
	{
		STX_RESULT	i_err;
		stx_xini*	h_xini;
		STX_HANDLE	h_prop;
		char*		sz_val;
		s32			i_val;

		i_err = STX_FAIL;
		h_xini = NULL;


		do{
			i_err = stx_ini_create(NULL,h_xio,STX_INI_READ_ONLY|STX_INI_NO_COMMENT,0,&h_xini );
			if( STX_INI_OK != i_err ) {
				break;
			}

			// push mode;
			i_err = XCALL(create_key,h_xini,NULL,g_szStreamX_pushmode,NULL,&h_prop);
			if(STX_INI_OK == i_err ) {
				i_err = XCALL(read_int32,h_xini,h_prop,&i_val);
				if(STX_OK != i_err ) {
					break;
				}
				the->b_push_mode = (b32)i_val;
			}

			// service ip
			i_err = XCALL(create_key,h_xini,NULL,g_sz_ip4,(char*)the->sz_ip,&h_prop);
			if(STX_INI_OK == i_err ) {
				i_err = XCALL(read_string,h_xini,h_prop,&sz_val);
				if(STX_INI_OK != i_err ) {
					break;
				}
				stx_strcpy(the->sz_ip,sizeof(the->sz_ip),sz_val);
			}

			// service port
			i_err = XCALL(create_key,h_xini,NULL,g_sz_port,NULL,&h_prop);
			if(STX_INI_OK != i_err ) {
				i_err = XCALL(read_int32,h_xini,h_prop,&i_val);
				if(STX_OK != i_err ) {
					break;
				}
				the->i_port = (u16)i_val;
			}

			// graph file;
			i_err = XCALL(create_key,h_xini,NULL,g_sz_GRAPH,NULL,&h_prop);
			if(STX_INI_OK == i_err ) {
				i_err = XCALL(read_string,h_xini,h_prop,&sz_val);
				if(STX_INI_OK != i_err ) {
					break;
				}
				if( the->sz_graph ) {
					stx_free(the->sz_graph);
				}

				the->sz_graph = xstrdup(sz_val);
				if( !the->sz_graph) {
					break;
				}
			}

			i_err = STX_OK;

		}while(FALSE);

		if( h_xini ) {
			h_xini->close(h_xini);
		}

		return i_err;
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_render_vt_xxx_enum_device
(STX_HANDLE h,s32 i_idx,STX_HANDLE * h_dev)
{
	_MAP_THE;

	return STX_OK;

}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_render_vt_xxx_reset(STX_HANDLE h)
{
	_MAP_THE;

	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_base_render_vt_xxx_get_device_num(STX_HANDLE h,s32 *i_idx)
{
	_MAP_THE;

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_render_vt_xxx_set_device(STX_HANDLE h,s32 i_idx)
{
	_MAP_THE;

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE s64 stx_base_render_vt_xxx_get_current_time(STX_HANDLE h)
{
	_MAP_THE;

	return 0;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE void stx_base_render_vt_xxx_set_start_time(STX_HANDLE h,s64 i_time)
{
	_MAP_THE;
}

