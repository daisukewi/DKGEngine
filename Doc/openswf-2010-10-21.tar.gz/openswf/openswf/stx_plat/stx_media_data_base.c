
/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#include "stdio.h"
#include "stdlib.h"
#include "fcntl.h"
#include "malloc.h"
#include "memory.h"
#include "string.h"

#include "stx_mem.h"
#include "stx_debug.h"

#include "stx_gid_def.h"
#include "stx_module_reg.h"

#include "stx_media_data_base.h"


#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif


typedef struct stx_media_data_base_ctx stx_media_data_base_ctx;


struct stx_media_data_base_ctx{

	stx_media_data				mda;

	s64							i_media_time;
	s64							i_decode_time;
	s64                         i_duration;

	s32							i_ref;
	
	STX_BYTE*					p_buf;
	STX_BYTE*					p_cur_buf;
	size_t						i_buf_len;
	size_t						i_data_len;

	size_t                      i_flags;

	s32							i_dref;
};



STX_PURE	STX_RESULT			query_interf( STX_HANDLE h, stx_gid gid, STX_HANDLE* p_interf);

STX_PURE	int			    	add_ref( STX_HANDLE h );

STX_PURE	int 				release( STX_HANDLE h );


STX_PURE	size_t				get_buf( STX_HANDLE h, void** pp_data);

STX_PURE	STX_RESULT			resize( STX_HANDLE h, size_t i_new_size );

STX_PURE	STX_RESULT			get_data( STX_HANDLE h, void** pp_cur,size_t* i_data_size );

STX_PURE	STX_RESULT			set_data( STX_HANDLE h, u8* p_cur, size_t i_len );

STX_PURE	STX_RESULT			set_time( STX_HANDLE h, s64 i_pts,s64 i_dts );

STX_PURE	s64					get_time( STX_HANDLE h, s64* i_dts );

STX_PURE	STX_RESULT			set_duration( STX_HANDLE h, s64 i_duration);

STX_PURE	s64					get_duration( STX_HANDLE h );

STX_PURE    STX_RESULT			set_flags( STX_HANDLE h, size_t i_flags );

STX_PURE    size_t			    get_flags( STX_HANDLE h );

STX_PURE s32			incr( THEE h );
STX_PURE s32			decr( THEE h );



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

stx_media_data* stx_media_data_base_create(stx_media_data* p_mda)
{
	STX_RESULT					i_err;

	stx_media_data_base_ctx*	p_ctx;


	i_err = STX_FAIL;

	p_ctx = STX_NULL;


	for( ; ; ) {

		p_ctx = (stx_media_data_base_ctx*)xmallocz(sizeof(stx_media_data_base_ctx));
		if( !p_ctx ){
			break;
		}

		/* fill the vtable; */

		p_ctx->i_ref = 1;

		p_ctx->mda.add_ref		= add_ref;
		p_ctx->mda.query_interf = query_interf;
		p_ctx->mda.release		= release;

		p_ctx->mda.get_buf			= get_buf;
		p_ctx->mda.get_data			= get_data;
		p_ctx->mda.get_time			= get_time;
		p_ctx->mda.set_data			= set_data;
		p_ctx->mda.set_time			= set_time;
		p_ctx->mda.resize			= resize;
		p_ctx->mda.set_flags        = set_flags;
		p_ctx->mda.get_flags        = get_flags;
		p_ctx->mda.set_duration     = set_duration;
		p_ctx->mda.get_duration     = get_duration;
		p_ctx->mda.incr = incr;
		p_ctx->mda.decr = decr;

		i_err = STX_OK;

		break;
	}

	if( STX_OK != i_err ) {
		if( p_ctx ) {
			p_ctx->mda.release(p_ctx);
		}
		return STX_NULL;
	}

	return (stx_media_data*)p_ctx;

}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static	STX_RESULT query_interf( STX_HANDLE h, stx_gid gid, STX_HANDLE* p_interf)
{
	stx_media_data_base_ctx*		p_ctx;

	p_ctx = (stx_media_data_base_ctx*) h;

	if( IS_EQUAL_GID( gid, STX_IID_MediaData ) ) {

		p_ctx->i_ref ++;

		*p_interf = p_ctx;

		return STX_OK;
	}

	return STX_ERR_INVALID_PARAM;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE int add_ref( STX_HANDLE h )
{
	stx_media_data_base_ctx*		p_ctx;

	p_ctx = (stx_media_data_base_ctx*) h;

	p_ctx->i_ref ++;

	return p_ctx->i_ref;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE	int release( STX_HANDLE h )
{
	stx_media_data_base_ctx*		p_ctx;

	p_ctx = (stx_media_data_base_ctx*) h;

	p_ctx->i_ref --;

	if( p_ctx->i_ref > 0 ) {

		return p_ctx->i_ref;
	}

	if( p_ctx->p_buf ) {

		stx_free( p_ctx->p_buf );
	}

	stx_free( p_ctx );

	return 0;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static	size_t get_buf( STX_HANDLE h, void** pp_data)
{
	stx_media_data_base_ctx*		p_ctx;

	p_ctx = (stx_media_data_base_ctx*) h;

	*pp_data = p_ctx->p_buf;

	return p_ctx->i_buf_len;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static	STX_RESULT resize( STX_HANDLE h, size_t i_new_size )
{
	stx_media_data_base_ctx*		the;

	STX_BYTE*						p_buf;

	STX_RESULT						i_err;


	i_err = STX_FAIL;

	the = (stx_media_data_base_ctx*) h;

	p_buf = STX_NULL;

	if( i_new_size < the->i_buf_len ) {

		return STX_OK;
	}

	for ( ; ; ) {

		p_buf = (STX_BYTE*)xmallocz( i_new_size);

		if(!p_buf ) {
			break;
		}

		if( the->p_buf ) {

			if( the->i_data_len ) {

				memcpy( p_buf, the->p_buf, the->i_data_len);
			}
			
			stx_free( the->p_buf );
		}

		the->p_cur_buf = p_buf + ( the->p_buf - the->p_cur_buf );

		the->p_buf = p_buf;

		the->i_buf_len = i_new_size;

		i_err = STX_OK;

		break;
	}

	if( STX_OK != i_err ) {

		if( p_buf ) {

			stx_free( p_buf );
		}

		return STX_FAIL;
	}

	return STX_OK;
}





/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static	STX_RESULT get_data( STX_HANDLE h, void** pp_data, size_t* i_data_size )
{
	stx_media_data_base_ctx*		p_ctx;

	p_ctx = (stx_media_data_base_ctx*) h;

	if( !pp_data ) {

		*i_data_size = p_ctx->i_data_len;

		return STX_OK;
	}

	*pp_data = p_ctx->p_cur_buf;

	*i_data_size = p_ctx->i_data_len;

	return STX_OK;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

static	STX_RESULT set_data( STX_HANDLE h, u8* p_cur, size_t i_len )
{
	stx_media_data_base_ctx*		p_ctx;

	p_ctx = (stx_media_data_base_ctx*) h;

	if( p_cur ) {

		p_ctx->p_cur_buf = p_cur;
	}

	p_ctx->i_data_len = i_len;

	return STX_OK;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static	STX_RESULT set_time( STX_HANDLE h, s64 i_pts,s64 i_dts )
{
	stx_media_data_base_ctx*		p_ctx;

	p_ctx = (stx_media_data_base_ctx*) h;

	p_ctx->i_media_time = i_pts;
	p_ctx->i_decode_time = i_dts;

	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static	s64 get_time( STX_HANDLE h, s64* i_dts )
{
	stx_media_data_base_ctx* p_ctx;

	p_ctx = (stx_media_data_base_ctx*) h;

	if( i_dts ) {
		*i_dts = p_ctx->i_decode_time;
	}

	return p_ctx->i_media_time;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_PURE STX_RESULT set_flags( STX_HANDLE h, size_t i_flags )
{
	stx_media_data_base_ctx*		p_ctx;

	p_ctx = (stx_media_data_base_ctx*) h;

	p_ctx->i_flags = i_flags;

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_PURE size_t get_flags( STX_HANDLE h )
{
	stx_media_data_base_ctx*		p_ctx;

	p_ctx = (stx_media_data_base_ctx*) h;

	return p_ctx->i_flags;

}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static	STX_RESULT set_duration( STX_HANDLE h, s64 i_duration )
{
	stx_media_data_base_ctx*		p_ctx;

	p_ctx = (stx_media_data_base_ctx*) h;

	p_ctx->i_duration = i_duration;

	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static	s64 get_duration( STX_HANDLE h )
{
	stx_media_data_base_ctx* p_ctx;

	p_ctx = (stx_media_data_base_ctx*) h;

	return p_ctx->i_duration;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE s32 incr( THEE h )
{
	STX_DIRECT_THE(stx_media_data_base_ctx);
	the->i_dref ++;
	return the->i_dref;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE s32 decr( THEE h )
{
	STX_DIRECT_THE(stx_media_data_base_ctx);
	the->i_dref --;
	return the->i_dref;
}
