
/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#include "stdio.h"
#include "stdlib.h"
#include "fcntl.h"
#include "malloc.h"
#include "memory.h"
#include "string.h"


#include "stx_os.h"
#include "stx_mem.h"
#include "stx_debug.h"
#include "stx_mutex.h"
#include "stx_semaphore.h"
#include "stx_module_reg.h"
#include "stx_message.h"
#include "stx_async_plugin.h"
#include "stx_direct_pin.h"
#include "stx_audio_render_emu.h"



#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif

/* {285C50FB-A4DA-4e90-A91C-F5DBD2C7CF40} */
DEFINE_XGUID( STX_CLSID_AudioRenderEmulator,
             0x285c50fb, 0xa4da, 0x4e90,0xa9, 0x1c, 0xf5, 0xdb, 0xd2, 0xc7, 0xcf, 0x40 );

char* g_szStreamX_AudioRenderEmulator = "StreamX audio render emulator";

STX_INPUT_MEDIA_TYPE_MAP_BEGIN(audio_render_emu)
/**/MEDIA_TYPE_MAP_ITEM(MEDIATYPE_Audio,STX_GID_NULL)
STX_INPUT_MEDIA_TYPE_MAP_END()

// no output types;
STX_OUTPUT_MEDIA_TYPE_MAP_BEGIN(audio_render_emu)
STX_OUTPUT_MEDIA_TYPE_MAP_END()

#define AUDIO_RENDER_BUFFER_DURATION   1000



STX_COM_BEGIN(audio_render_emu);

    /* imp stx_base_render vt; */
    STX_PUBLIC(stx_audio_render)
	STX_COM_DATA_DEFAULT(stx_audio_render)

    stx_base_pin*		p_input_pin;

	STX_HANDLE          h_default_task;
	stx_sync_source*    h_sync_ssrc;
	STX_HANDLE          h_sync_task;
	stx_media_data*		h_mdat;

    sint64              i_last_sample_time;
    sint64              i_current_time;
    sint64              i_start_time;
    sint64              i_sync_time;
    sint64              i_last_time;
    sint64              i_adjust_time;

    /* WAVEFORMATEX, input format, sample rate, channels, etc; */
    STX_WAVEFORMATEXTENSIBLE     output_fmt;

    /* output format; */

    sint32              i_output_channels;
    sint32              i_bits_per_sample;


    /* assume we use a loop buffer to play the PCM audio data; */

    sint64			    i_buffer_time;   /**/
    sint32              i_max_buffer;
    sint32              i_write_pos;
    sint32              i_play_pos;
    sint32              i_valid_data;

STX_COM_END();


STX_COM_FUNC_DECL_DEFAULT(stx_audio_render,stx_audio_render_vt);
STX_COM_FUNCIMP_DEFAULT(audio_render_emu,stx_audio_render,stx_audio_render_vt)


	/*{{{STX_MSG_ENTRY_DECLARE**************************************************/

	/* to do : add msg proc entry  declaration here; */

	/*}}}***********************************************************************/


	/*{{{STX_BEGIN_MSG_MAP******************************************************/
	STX_BEGIN_MSG_MAP(the_msg_data)

	/* to do : add msg proc entry name here; */

	STX_END_MSG_MAP
	/*}}}***********************************************************************/


	/*{{{STX_BEGIN_MSG_RESPONSE_MAP*********************************************/
	STX_BEGIN_MSG_RESPONSE_MAP(the_msg_response)

	/* to do : add msg process entry name here; */

	STX_END_MSG_RESPONSE_MAP
	/*}}}***********************************************************************/


	/*{{{STX_DISPATHCH_MSG_PROC*************************************************/
	STX_DISPATCH_MSG_PROC( dispatch_msg,the_msg_data )
	/*}}}***********************************************************************/


	/*{{{STX_RESPONSE_MSG_PROC**************************************************/
	STX_RESPONSE_MSG_PROC( response_msg,the_msg_response )
	/*}}}***********************************************************************/


/*}}}async_plugin inherit block; ***********************************************/




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_COM_MAP_BEGIN(audio_render_emu)
/**/STX_COM_MAP_ITEM(STX_IID_AudioRender)
STX_COM_MAP_END()

STX_NEW_BEGIN(audio_render_emu)
{
    STX_SET_THE(stx_audio_render);
	STX_COM_NEW_DEFAULT(
		stx_audio_render,
		the->stx_audio_render_vt,
		stx_audio_render_vt,
		STX_CLSID_AudioRenderEmulator,
		STX_CATEGORY_Render,
		g_szStreamX_AudioRenderEmulator);
}
STX_NEW_END()




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API_IMP
STX_QUERY_BEGIN(audio_render_emu)
{
	STX_COM_QUERY_DEFAULT(stx_audio_render,the->stx_audio_render_vt);
}
STX_QUERY_END()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API_IMP
STX_DELETE_BEGIN(audio_render_emu)
{
	SAFE_XDELETE(the->p_input_pin);

	if( the->h_sync_ssrc) {
		the->h_sync_ssrc->unreg_task(the->h_sync_ssrc,the->h_sync_task);
		XDELETE(the->h_sync_ssrc);
	}

	STX_COM_DELETE_DEFAULT(stx_audio_render);
}
STX_DELETE_END(STX_COM_DELETE_BEGIN(stx_audio_render),STX_COM_DELETE_END(stx_audio_render))

/*}}}***********************************************************************/





/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_PURE STX_RESULT 
stx_audio_render_vt_rnd_flt_plug_xxx_send_msg
( STX_HANDLE h, stx_base_message* p_msg )
{
    STX_MAP_THE(audio_render_emu);

    return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
as for emulate filter, the initial state of this render have no input pin and 
any data type;
so the emulate filter could not be registered, must be load and unload at run time;
***************************************************************************/

STX_PURE sint32 
stx_audio_render_vt_rnd_flt_xxx_get_input_pin_num
(STX_HANDLE h)
{
    STX_MAP_THE(audio_render_emu);

    return 1;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_PURE STX_RESULT 
stx_audio_render_vt_rnd_flt_xxx_enum_input_pin
(STX_HANDLE h,sint32* i_idx,stx_base_pin** pp_pin )
{
	s32 idx;

    STX_MAP_THE(audio_render_emu);

	if( !i_idx ) {
		return STX_ERR_INVALID_PARAM;
	}

	if( !pp_pin ) {
		*i_idx = 0;
	}

	idx = *i_idx;
    if( idx != 0 ) {
        return STX_ERR_INVALID_PARAM;
    }

	*pp_pin = the->p_input_pin;
	the->p_input_pin->add_ref(the->p_input_pin);
	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_PURE STX_RESULT 
stx_audio_render_vt_rnd_flt_xxx_enum_output_pin
(STX_HANDLE h,sint32* i_idx,stx_base_pin** pp_pin )
{
	return STX_ERR_NOT_SUPPORT;
}





/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_audio_render_vt_rnd_flt_xxx_check_input_media_type
( STX_HANDLE h, stx_media_type* p_mdt )
{
    stx_gid major_type;

    STX_MAP_THE(audio_render_emu);

    /* it is a audio render; so check the major type; */

    major_type = p_mdt->get_type(p_mdt);

    if( ! IS_EQUAL_GID( major_type, MEDIATYPE_Audio ) ) {
        return STX_ERR_NOT_SUPPORT;
    }

    return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_audio_render_vt_rnd_flt_xxx_check_output_media_type
( STX_HANDLE h, stx_media_type* p_mdt )
{
	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
/* add input type; */
STX_PURE STX_RESULT 
stx_audio_render_vt_rnd_flt_xxx_set_input_media_type
(STX_HANDLE h, stx_media_type*	p_media_type )
{
    STX_RESULT          i_err;
    stx_base_pin*       p_pin;
    stx_base_pin**      pp_pin;

    STX_MAP_THE(audio_render_emu);

    p_pin = STX_NULL;
    pp_pin = STX_NULL;


    i_err = stx_audio_render_vt_rnd_flt_xxx_check_input_media_type(h,p_media_type);
    if( STX_OK != i_err ) {
        goto fail;
    }

    /* reset the default return value; */
    i_err = STX_FAIL;

    /* set up the input pin; */
	p_pin = XCREATE(stx_input_pin,NULL);
    if( ! p_pin ) {
        goto fail;
    }
	p_pin->set_parent(p_pin,(stx_base_plugin *)&the->stx_audio_render_vt);

    i_err = p_pin->set_media_type(p_pin,p_media_type);
    if( STX_OK != i_err ) {
        goto fail;
    }

	the->p_input_pin = p_pin;

	i_err = STX_OK;

fail:

    if( STX_OK != i_err ) {
		SAFE_XDELETE(p_pin);
    } /* if( STX_OK != i_err ) { */

    return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_audio_render_vt_rnd_flt_xxx_set_output_media_type
(THEE h,stx_media_type*	p_media_type )
{
	return STX_ERR_NOT_SUPPORT;
}





/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_audio_render_vt_rnd_flt_xxx_new_segment( THEE h )
{
    STX_MAP_THE(audio_render_emu);

	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT stx_audio_render_vt_rnd_flt_plug_xxx_start
(THEE h,u32 i_flag,stx_sync_inf* h_sync)
{
	STX_MAP_THE(audio_render_emu);

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_audio_render_vt_rnd_flt_plug_xxx_flush
(THEE h,u32 i_flag,stx_sync_inf* h_sync)
{
    STX_MAP_THE(audio_render_emu);

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_audio_render_vt_rnd_flt_plug_xxx_stop
(THEE h,u32 i_flag,stx_sync_inf* h_sync)
{
	STX_MAP_THE(audio_render_emu);

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT update_play_buffer( audio_render_emu* the ) 
{
    sint32         i_data_played;

    sint64         i_time;

    sint64         i_time_dlt;


    if( ! the->i_valid_data ) {

        goto skip;  /* not start yet; */
    }


    i_time = stx_get_milisec();

    i_time_dlt = i_time - the->i_last_time;

    the->i_last_time = i_time;

    i_data_played = (sint32)( the->output_fmt.Format.nAvgBytesPerSec * i_time_dlt ) / 1000;

    if( !i_data_played ) {

        goto skip;
    }

    if( i_time_dlt >= the->i_buffer_time || i_data_played >= the->i_valid_data ) {

        /* do reset; */

        the->i_valid_data = 0;

        the->i_write_pos = 0;

        the->i_play_pos = 0;

        goto skip;
    }

    the->i_valid_data -= i_data_played;

    the->i_play_pos += i_data_played;

    if( the->i_play_pos >= the->i_max_buffer ) {

        the->i_play_pos -= the->i_max_buffer;
    }

skip:

    return STX_IDLE; /* */
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_audio_render_vt_rnd_flt_xxx_receive
(
 STX_HANDLE			h,
 stx_base_pin*		h_pin, // which input pin;
 stx_media_data**	pp_mdat, // output media data;
 stx_sync_inf*		h_sync
 )
{
	STX_MAP_THE(audio_render_emu);

	return STX_ERR_NOT_SUPPORT;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_audio_render_vt_rnd_flt_xxx_deliver
(
 STX_HANDLE			h,
 stx_base_pin*		h_pin, // which input pin;
 stx_media_data*	p_mdat, // output media data;
 stx_sync_inf*		h_sync
 )
{
	STX_MAP_THE(audio_render_emu);
	the->h_mdat = p_mdat;
	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE sint64 
stx_audio_render_vt_rnd_xxx_get_current_time( THEE h )
{
    STX_MAP_THE(audio_render_emu);

    return the->i_current_time;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE void 
stx_audio_render_vt_rnd_xxx_set_start_time( THEE h, sint64 i_start )
{
    STX_MAP_THE(audio_render_emu);

    the->i_start_time = i_start;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_audio_render_vt_rnd_xxx_reset(THEE h)
{
    STX_MAP_THE(audio_render_emu);

    return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_audio_render_vt_rnd_xxx_stop(THEE h)
{
    STX_MAP_THE(audio_render_emu);

    return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_audio_render_vt_rnd_xxx_start(THEE h)
{
    STX_MAP_THE(audio_render_emu);

    return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_PURE STX_RESULT 
stx_audio_render_vt_rnd_xxx_get_device_num(THEE h,sint32* i_num )
{
    STX_MAP_THE(audio_render_emu);

    return STX_ERR_NOT_SUPPORT;

}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_audio_render_vt_rnd_xxx_enum_device
(THEE h,sint32 i_idx, THEE* pp_dev )
{
    STX_MAP_THE(audio_render_emu);

    return STX_ERR_NOT_SUPPORT;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_audio_render_vt_rnd_xxx_set_device(THEE h,sint32 i_idx)
{
    STX_MAP_THE(audio_render_emu);

    return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT 
up_stream_msg(THEE h, stx_base_message* p_msg )
{
    STX_MAP_THE(audio_render_emu);
    return the->p_input_pin->send_msg(the->p_input_pin,p_msg);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
render have no output stream pin , so return pass value;
***************************************************************************/
STX_MSG_PROC STX_RESULT 
down_stream_msg(THEE h, stx_base_message* p_msg)
{
    return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT stx_audio_render_vt_xxx_get_volume(STX_HANDLE h,s32 * i_vol)
{
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT stx_audio_render_vt_xxx_set_channels(STX_HANDLE h,s32 i_ch)
{
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT stx_audio_render_vt_xxx_set_volume(STX_HANDLE h,s32 i_vol)
{
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT stx_audio_render_vt_xxx_get_channels(STX_HANDLE h,s32* i_ch)
{
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_audio_render_vt_rnd_flt_plug_xxx_run
(STX_HANDLE h,stx_sync_inf* h_sync )
{
	STX_RESULT i_err;

	STX_MAP_THE(audio_render_emu);

	if( !the->h_default_task ) {

		stx_sync_source* h_ssrc = NULL;

		// first time run;
		i_err = the->h_gbd->alloc_ssrc(the->h_gbd,the->h_ssrc,1,&h_ssrc);
		if( STX_OK != i_err ) {
			return i_err;
		}
		i_err = h_ssrc->reg_task(
			h_ssrc,&the->h_sync_task,(stx_base_plugin*)&the->stx_audio_render_vt,TASK_NORMAL);
		if( STX_OK != i_err ) {
			SAFE_XDELETE(h_ssrc);
			return i_err;
		}
		the->h_sync_ssrc = h_ssrc;
	}
		
	if( h_sync->h_task == the->h_sync_task ){

		// lock;

		i_err = update_play_buffer(the);

		// unlock;

		if( STX_OK != i_err ) {
			return i_err;
		}

		RESET_XENTRY(h_sync,h);
		h_sync->i_idle = MILISEC2REFTIME(10);
		return STX_IDLE;
	}

	{
		size_t			i_data_len;
		sint32			i_buf;
		sint64			i_sample_time;

		u8*				buf;

		i_sample_time = the->h_mdat->get_time(the->h_mdat,NULL) / 10000;

		the->h_mdat->get_data(the->h_mdat,&buf,&i_data_len);

		for( ; ; ) {

			update_play_buffer(the);

			if( !the->i_valid_data ) {

				i_buf = the->i_max_buffer;
			}
			else if( the->i_write_pos > the->i_play_pos ) {

				i_buf = the->i_max_buffer - ( the->i_write_pos - the->i_play_pos );
			}
			else {

				i_buf = the->i_write_pos - the->i_play_pos ;
			}

			if( i_buf >= (s32)i_data_len ) {

				/* copy data; */

				the->i_valid_data += (s32)i_data_len;

				the->i_write_pos += (s32)i_data_len;

				if( the->i_write_pos >= the->i_max_buffer ) {

					the->i_write_pos -= the->i_max_buffer;
				}

				break;
			}

			i_data_len -= i_buf;

			the->i_valid_data = the->i_max_buffer;

			the->i_write_pos = the->i_play_pos;

			if( i_data_len >= (size_t)the->i_max_buffer ) {

				//stx_sleep( (uint32_t)the->i_buffer_time );
				h_sync->i_idle = MILISEC2REFTIME(the->i_buffer_time);
			}
			else {

				//stx_sleep( i_data_len * 1000 / the->output_fmt.Format.nAvgBytesPerSec );
				u32 const i_time = (u32)( i_data_len * 1000 / the->output_fmt.Format.nAvgBytesPerSec ) ;
				h_sync->i_idle = MILISEC2REFTIME(i_time);
			}

			RESET_XENTRY(h_sync,h);
			return STX_WOUNLD_BLOCK;

		} /* for( ; ; ) { */

		// do not update entry;
		return STX_OK;
	}

}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_audio_render_vt_rnd_flt_plug_xxx_get_property
(STX_HANDLE h,stx_xio* h_xio)
{
	STX_MAP_THE(audio_render_emu);

	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_audio_render_vt_rnd_flt_plug_xxx_set_property
(STX_HANDLE h,stx_xio* h_xio)
{
	STX_MAP_THE(audio_render_emu);

	return STX_ERR_NOT_SUPPORT;
}