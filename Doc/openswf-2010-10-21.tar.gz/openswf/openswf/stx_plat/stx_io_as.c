/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#include "stdio.h"
#include "stdlib.h"
#include "fcntl.h"
#include "malloc.h"
#include "memory.h"
#include "string.h"

#include "stx_thread.h"
#include "stx_ini.h"
#include "stx_mem.h"
#include "stx_os.h"
#include "stx_io_tcp.h"
#include "stx_io_udp.h"
#include "stx_io_stream.h"
#include "stx_sock_err.h"
#include "stx_debug.h"
#include "stx_mutex.h"
#include "stx_io_http.h"
#include "stx_io_as.h"
#include "stx_sync_source.h"

#include "xdisk_loop.h"


#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif

#define AS_IO_BUF_SIZE		1500
#define AS_IO_MAX_SLOT      256		// 256*1500



char* g_szAsIo = "StreamX async io plugin";

// {16F5F71F-0C10-45e0-AF6A-41BA8F507D48}
DEFINE_XGUID( STX_CLSID_AsIo,
			 0x8b82bc74, 0x98ea, 0x472f, 0x9d, 0x9f, 0xcc, 0x13, 0xa0, 0x39, 0x1c, 0x95)


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API_IMP 
CREATE_STX_COM(stx_base_plugin,STX_IID_BasePlugin,stx_io_as);




#define PROTOCOL_TCP	1
#define PROTOCOL_UDP	2
#define PROTOCOL_HTTP	3


STX_COM_BEGIN(stx_io_as);
/**/
/**/STX_PUBLIC(stx_base_plugin)
/**/STX_COM_DATA_DEFAULT(stx_base_plugin)
/**/
/**/STX_PUBLIC(stx_xio)
/**/
/**/u32				oflag;
/**/b32				b_stopped;
/**/u32				i_protocol;
/**/char*			sz_url;
/**/char*			sz_bind;
/**/stx_xio*		h_prot;
/**/b32				h_prot_connected;
/**/offset_t		i_file_size;
/**/	
/**/s64				i_plug_total;	
/**/STX_HANDLE		h_plug_stat;
/**/	
/**/s64				i_io_total;	
/**/STX_HANDLE		h_io_stat;
/**/	
/**/STX_HANDLE		h_task;
/**/STX_HANDLE		h_mutex;
/**/
/**/s32				i_id;   // channel id;
/**/s32				i_flag;
/**/s32				i_slot;
/**/u8*				buf;
/**/xloop*			h_free;
/**/xloop*			h_used;
/**/
/**/ssize_t			i_min_data_size;
/**/ssize_t			i_total_buf_size;
/**/
/**/ssize_t			i_buf_size;
/**/ssize_t			i_buf_data;
/**/u8*				p_buf_ptr;
/**/u8				p_buf[AS_IO_BUF_SIZE];
/**/
/**/
STX_COM_END();


STX_COM_FUNC_DECL_DEFAULT(stx_base_plugin,stx_base_plugin_vt);

STX_COM_FUNC_DECL_DEFAULT(stx_xio,stx_xio_vt);


STX_PRIVATE STX_RESULT read_proc(stx_io_as* the,stx_sync_inf* h_sync);
STX_PRIVATE STX_RESULT write_proc(stx_io_as* the,stx_sync_inf* h_sync);
STX_PRIVATE STX_RESULT parse_prot(stx_io_as* the,const char* prot_name,s32 oflag );
STX_PRIVATE STX_RESULT http_stream_read(stx_io_as* the, s64 *i_idle_time);
STX_PRIVATE STX_RESULT http_stream_write(stx_io_as* the, s64 *i_idle_time);


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_COM_MAP_BEGIN(stx_io_as)
/**/STX_COM_MAP_ITEM(STX_IID_BasePlugin)
/**/STX_COM_MAP_ITEM(STX_IID_BaseIo)
STX_COM_MAP_END()

STX_API_IMP 
STX_NEW_BEGIN(stx_io_as)
{
	STX_SET_THE(stx_base_plugin);
	STX_COM_NEW_DEFAULT(
		stx_base_plugin,
		the->stx_base_plugin_vt,
		stx_base_plugin_vt,
		STX_CLSID_AsIo,
		STX_CATEGORY_BaseIo,
		g_szAsIo);

	STX_SET_THE(stx_xio);
	STX_COM_NEW_DEFAULT(stx_xio,the->stx_xio_vt,stx_xio_vt,DEFAULT_CODE,DEFAULT_CODE,DEFAULT_CODE);


	the->h_mutex = stx_create_mutex(NULL,0,NULL);
	if( !the->h_mutex ) {
		break;
	}

	the->h_io_stat = stx_stat_create();
	if( !the->h_io_stat ) {
		break;
	}

	the->h_plug_stat = stx_stat_create();
	if( !the->h_plug_stat ) {
		break;
	}

	the->i_buf_size = AS_IO_BUF_SIZE;
	the->i_buf_data = 0;
	the->p_buf_ptr = the->p_buf;

	the->i_slot = AS_IO_MAX_SLOT;

	the->buf = (u8*)xmallocz( the->i_slot*(AS_IO_BUF_SIZE + 4 +sizeof(size_t)));
	if( !the->buf ) {
		break;
	}

	the->h_free = xloopCreate(the->i_slot);
	if( !the->h_free) {
		break;
	}
	the->h_used = xloopCreate(the->i_slot);
	if( !the->h_used) {
		break;
	}
	{
		s32 i;
		u8* buf = the->buf + sizeof(size_t);
		for( i = 0; i < the->i_slot; i ++ ) {
			*(u8**)( buf - sizeof(size_t)) = buf + 4;
			*(u16*)buf = (u16)i;
			xloopPush(the->h_free,buf);
			buf += AS_IO_BUF_SIZE + 4 + sizeof(size_t);
		}
	}

	the->i_total_buf_size = AS_IO_BUF_SIZE * AS_IO_MAX_SLOT;

}
STX_NEW_END()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE 
STX_QUERY_BEGIN(stx_io_as)
{
	STX_COM_QUERY_DEFAULT(stx_base_plugin,the->stx_base_plugin_vt);

	if( IS_EQUAL_GID(gid,STX_IID_BaseIo) ) {
		the->i_ref ++;
		*pp_interf = &the->stx_xio_vt;
		return STX_OK;
	}

}
STX_QUERY_END()


/***************************************************************************
STX_PURE sint32 flv_release(STX_HANDLE h)
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE 
STX_DELETE_BEGIN(stx_io_as)
{
	/* todo : release object; */

	if( the->h_task ) {
		the->h_ssrc->unreg_task(the->h_ssrc,the->h_task);
	}

	if( the->oflag == O_RDONLY && the->h_prot) {
		the->h_prot->close(the->h_prot);
	}

	if( the->h_io_stat ) {
		stx_stat_close(the->h_io_stat);
	}

	if( the->h_plug_stat ) {
		stx_stat_close(the->h_plug_stat);
	}

	if( the->h_mutex ) {
		stx_close_mutex(the->h_mutex);
	}

	if( the->sz_url ) {
		stx_free(the->sz_url);
	}

	if( the->sz_bind ) {
		stx_free(the->sz_bind);
	}

	if( the->buf ) {
		stx_free(the->buf);
	}
	if( the->h_free ) {
		xloopRelease(the->h_free);
	}
	if( the->h_used ) {
		xloopRelease(the->h_used);
	}

	STX_COM_DELETE_DEFAULT(stx_base_plugin);

}
STX_DELETE_END
(
 STX_COM_DELETE_BEGIN(stx_base_plugin)
 ,
 STX_COM_DELETE_END(stx_base_plugin)
 )


 /***************************************************************************
 RETURN VALUE:
 INPUT:
 OUTPUT:
 NOTE:
 ***************************************************************************/
 STX_COM_FUNCIMP_DEFAULT(stx_io_as,stx_base_plugin,stx_base_plugin_vt);


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_plugin_vt_xxx_send_msg
(STX_HANDLE h,stx_base_message *p_msg)
{
	STX_MAP_THE(stx_io_as);
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT http_stream_read(stx_io_as* the, s64 *i_idle_time)
{
	STX_RESULT	i_err;
	size_t		i_readed;

	for( ; ; ){

		// read some data ;

		while( the->i_buf_data <  the->i_buf_size) {

			size_t i_read = the->i_buf_size - the->i_buf_data;

			do{
				i_err = the->h_prot->read(the->h_prot,
					the->p_buf + the->i_buf_data,i_read,&i_readed );
			}while( STX_AGAIN == i_err );

			if( STX_OK != i_err ) {
				if( i_err < 0 ) {
					the->b_stopped = TRUE;
					i_err = STX_STOP;
				}
				else if( STX_EOF == i_err){
					if( the->i_buf_data ) {
						break;  // break to copy data to xloop;
					}
					else {
						the->b_stopped = TRUE;
						i_err = STX_STOP;
					}
				}
				else if( STX_IDLE == i_err || STX_WOUNLD_BLOCK == i_err ) {
					s64 i_time = 10;
					s64 i_stat = stx_stat_get_speed(the->h_plug_stat);
					if( i_stat ) {
						i_time = ((s64)i_read * 1000)/ i_stat;
						if( i_time > 100 ) {
							i_time = 100;
						}
						else if( i_time < 10 ) {
							i_time = 10;
						}
					}
					*i_idle_time = MILISEC2REFTIME(i_time);
					i_err = STX_WOUNLD_BLOCK;
				}
				return i_err;
			}//if( STX_OK != i_err ) {

			stx_stat_add_val(the->h_io_stat,i_readed);

			the->i_buf_data += i_readed;

		} // while( the->i_buf_data <  the->i_buf_size) {


		// copy data to the read buf;
		for( ; ; ){

			// dispatch packet;
			s32			i_free;
			u8*			buf;

			i_free = xloopGetUsed(the->h_free);
			if( !i_free ) {
				s64 i_time= 10; // 10 ms
				s64 i_speed = stx_stat_get_speed(the->h_io_stat);
				if( i_speed ) {
					i_time =  the->i_buf_data * 1000 / i_speed ;
					if( i_time > 100 ) {
						i_time = 100;
					}
					else if( i_time < 10 ) {
						i_time = 10;
					}
				}
				*i_idle_time = MILISEC2REFTIME(i_time);
				return STX_WOUNLD_BLOCK;
			}// if( !i_free ) {

			// write data;			
			buf = (u8*)xloopPull(the->h_free);
			// write size;
			*(u16*)( buf + 2 ) = (u16)the->i_buf_data;
			// copy
			memcpy( buf + 4, the->p_buf,the->i_buf_data);
			// set start pointer
			*(u8**)( buf - sizeof(size_t) ) = buf + 4; 
			// send 
			xloopPush(the->h_used,buf);

			the->i_plug_total += the->i_buf_data;
			// reset buf data;
			the->i_buf_data  = 0;
			// read data again;
			break;

		} // for( ; ; ) {

	} // for( ; ; ){

	return i_err;

}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT read_proc(stx_io_as* the,stx_sync_inf* h_sync)
{
	STX_RESULT i_err;

	i_err = STX_OK;

	stx_waitfor_mutex(the->h_mutex,INFINITE);

	do{

		if( !the->h_prot_connected ) {
			i_err = the->h_prot->open(the->h_prot,the->sz_url,0);
			if( STX_OK != i_err ) {
				if( STX_AGAIN == i_err ) {
					h_sync->i_idle = MILISEC2REFTIME( 10 );
				}
				break;
			}
			the->h_prot_connected = TRUE;
			the->i_file_size = the->h_prot->size(the->h_prot);
		}

		i_err = http_stream_read(the,&h_sync->i_idle);
		if( STX_OK != i_err ) {
			break;
		}

		//

		i_err = STX_OK;
		break;

	}while(FALSE);

	stx_release_mutex(the->h_mutex);

	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT http_stream_write(stx_io_as* the, s64 *i_idle_time)
{
	STX_RESULT	i_err;
	size_t		i_write;

	for( ; ; ){

		// write out data;

		while( the->i_buf_data ) {

			do{
				i_err = XCALL(write,the->h_prot,the->p_buf_ptr,the->i_buf_data,&i_write);
			}while( i_err == STX_AGAIN);


			if( STX_OK != i_err ) {

				if( i_err < 0 ||  STX_EOF == i_err ) {
					the->b_stopped = TRUE;
				}
				else if( STX_IDLE == i_err || STX_WOUNLD_BLOCK == i_err ) {
					s64 i_time = 10;
					s64 i_stat = stx_stat_get_speed(the->h_plug_stat);
					if( i_stat ) {
						i_time = ((s64)the->i_buf_data * 1000)/ i_stat;
						if( i_time > 100 ) {
							i_time = 100;
						}
						else if( i_time < 10 ) {
							i_time = 10;
						}
					}
					*i_idle_time = MILISEC2REFTIME(i_time);
					i_err = STX_WOUNLD_BLOCK;
				}

				return i_err;

			}//if( STX_OK != i_err ) {

			stx_stat_add_val(the->h_plug_stat,(s64)i_write);
			the->i_plug_total += i_write;
			the->p_buf_ptr += i_write;
			the->i_buf_data -= i_write;

		} // while( the->i_buf_data ) {


		// get data from loop;
		for( ; ; ){

			u8*		buf;
			u16		i_size;

			buf = (u8*)xloopPull(the->h_used);

			if( !buf ) {
				// all the data write out;
				s64 i_time = 10;
				s64 i_speed = stx_stat_get_speed(the->h_io_stat);
				if( i_speed ) {
					i_time =  AS_IO_BUF_SIZE * 1000 / i_speed ;
					if( i_time > 100 ) {
						i_time = 100;
					}
					else if( i_time < 10 ) {
						i_time = 10;
					}
				}

				*i_idle_time = MILISEC2REFTIME(i_time);

				return STX_WOUNLD_BLOCK;
			}

			i_size = *(u16*)( buf + 2);
			if( !i_size ) {
				continue;
			}

			// clear;
			*(u16*)( buf + 2) = 0; 
			// copy
			memcpy( the->p_buf, buf + 4, i_size );
			// free slot;
			xloopPush(the->h_free,buf);
			// write size;
			the->i_buf_data = i_size;
			// set buffer pointer;
			the->p_buf_ptr = the->p_buf;
			// write socket again;
			break;

		} // for( ; ; ){

	} // for( ; ; ){

	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT write_proc(stx_io_as* the,stx_sync_inf* h_sync)
{
	STX_RESULT i_err;

	stx_waitfor_mutex(the->h_mutex,INFINITE);

	i_err = http_stream_write(the,&h_sync->i_idle);

	stx_release_mutex(the->h_mutex);

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_base_plugin_vt_xxx_run(STX_HANDLE h,stx_sync_inf* h_sync)
{
	STX_RESULT i_err;

	STX_MAP_THE(stx_io_as);

	if( the->oflag == O_RDONLY ) {
		i_err = read_proc(the,h_sync);
		RESET_XENTRY(h_sync,h);
		return i_err;
	}

	if( the->oflag == O_WRONLY ) {
		i_err =  write_proc(the,h_sync);
		RESET_XENTRY(h_sync,h);
		return i_err;
	}

	return STX_FAIL;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_base_plugin_vt_xxx_start(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_base_plugin_vt_xxx_stop(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_base_plugin_vt_xxx_flush(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT	
parse_prot(stx_io_as* the,const char* prot_name,s32 oflag )
{
	STX_RESULT i_err;

	the->oflag = oflag;

	if( oflag == O_RDONLY )	{

		char	sz_hdr[8];
		size_t	i_len;

		if( the->sz_url ) {
			stx_free( the->sz_url);
			the->sz_url = NULL;
		}

		i_len = strlen(prot_name);
		if( i_len < 6 ) {
			return STX_ERR_INVALID_PARAM;
		}

		INIT_MEMBER(sz_hdr);
		*(u32*)sz_hdr = *(u32*)prot_name;
		stx_strupr(sz_hdr,5);

		if( !strcmp(sz_hdr,"HTTP") ) {
			the->i_protocol = PROTOCOL_HTTP;
			the->sz_url = xstrdup(prot_name);
			if( !the->sz_url) {
				return STX_FAIL;
			}
			the->h_prot = stx_create_io_http();
			if( !the->h_prot ) {
				return STX_FAIL;
			}

			if( the->sz_bind ) {
				// should set http io bind string;
				stx_io_op_param param;
				INIT_MEMBER(param);
				param.buf = the->sz_bind;
				i_err = the->h_prot->set(the->h_prot,STX_XIO_SET_BIND,&param);
				if( STX_OK != i_err ) {
					return i_err;
				}
			}

			return STX_OK;

		}
		else {

			char	sz_url[1024];
			char	sz_ip[128];
			u32		i_port;
			char	sz_param[1024];

			sz_hdr[3] = 0;

			if( ! strcmp( sz_hdr,"TCP") ) {

				stx_strcpy(sz_url,sizeof(sz_url),prot_name+4);

				if( STX_OK != stx_io_tcp_string_parse(sz_url,sz_ip,sizeof(sz_ip),&i_port) ) {
					return STX_ERR_INVALID_PARAM;
				}

				stx_io_tcp_make_string(sz_ip,i_port,sz_param,sizeof(sz_param));
				if( STX_OK != stx_io_tcp_make_open_string(the->sz_bind,sz_param,sz_param) )  {
					return STX_FAIL;
				}

				the->sz_url = xstrdup(sz_param);
				if( !the->sz_url) {
					return STX_FAIL;
				}
				the->h_prot = stx_create_io_tcp();
				if( !the->h_prot ) {
					return STX_FAIL;
				}

				the->i_protocol = PROTOCOL_TCP;

				return STX_OK;
			}
			else if( !strcmp(sz_hdr, "UDP") ) {

				stx_strcpy(sz_url,sizeof(sz_url),prot_name+4);

				if( STX_OK != stx_io_tcp_string_parse(sz_url,sz_ip,sizeof(sz_ip),&i_port) ) {
					return STX_ERR_INVALID_PARAM;
				}

				stx_io_tcp_make_string(sz_ip,i_port,sz_param,sizeof(sz_param));

				the->sz_url = xstrdup(sz_param);
				if( !the->sz_url) {
					return STX_FAIL;
				}

				the->h_prot = XCREATE(stx_io_udp,NULL);
				if( !the->h_prot ) {
					return STX_FAIL;
				}

				the->i_protocol = PROTOCOL_UDP;

				return STX_OK;
			}
			else{
				return STX_ERR_INVALID_PARAM;
			}//

		} // if ( is http ) {...} else { 

	} // if( oflag = O_RDONLY ) 
	else if( oflag == O_WRONLY ) {

		// write io, should set the io interface outside by set method;

		return STX_OK;
	}

	return STX_ERR_INVALID_PARAM;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
write stream, the io interface must be set before <open> by <set>;
***************************************************************************/
STX_PURE STX_RESULT	
stx_xio_vt_xxx_open(stx_xio* h,const char* prot_name,s32 oflag )
{
	STX_RESULT i_err;

	STX_MAP_THE(stx_io_as);

	if( !the->h_prot ) {

		i_err = parse_prot(the,prot_name,oflag);
		if( STX_OK != i_err ) {
			return i_err;
		}

		stx_stat_add_val(the->h_plug_stat,0);
		stx_stat_add_val(the->h_io_stat,0);

		i_err = XCALL(reg_task,the->h_ssrc,&the->h_task,&the->stx_base_plugin_vt,TASK_NORMAL);
		if( STX_OK != i_err ) {
			return i_err;
		}

		the->em_status = emStxStatusPlay;
		// active ssrc handle;
		XCALL(reset_task,the->h_ssrc,the->h_task,0,0);

		return STX_WOUNLD_BLOCK;

	} // if( !the->h_prot ) {

	if( !the->h_prot_connected ) {
		return STX_WOUNLD_BLOCK;
	}

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT	stx_xio_vt_xxx_close(stx_xio* h)
{
	STX_MAP_THE(stx_io_as);
	SAFE_XDELETE(the);
	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT	stx_xio_vt_xxx_clear(stx_xio* h)
{
	STX_MAP_THE(stx_io_as);

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT	stx_xio_vt_xxx_stop(stx_xio* h)
{
	STX_MAP_THE(stx_io_as);

	if( the->h_task ) {
		the->h_ssrc->unreg_task(the->h_ssrc,the->h_task);
		the->h_task = NULL;
	}

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT	
stx_xio_vt_xxx_read(stx_xio* h,void* buffer,size_t cnt,size_t* i_read)
{

	STX_RESULT			i_err;

	STX_MAP_THE(stx_io_as);

	if( the->oflag != O_RDONLY ) {
		return STX_FAIL;
	}

	stx_waitfor_mutex(the->h_mutex,INFINITE);

	*i_read = 0;
	{
		u8					*buf,*src;
		size_t				i_data,i_need;
		s32         		i_slot;


		i_slot = xloopGetUsed(the->h_used);
		if( !i_slot ) {
			if( the->b_stopped ) {
				i_err = STX_EOF;
			}
			else{
				i_err = STX_WOUNLD_BLOCK;
			}
			goto fail;
		} // if( !i_slot ) {

		buf = (u8*)buffer;
		i_data = 0;
		i_need = cnt;

		for( ; ; ){

			u16		i_size;
			u8*		dptr;

			src = (u8*)xloopTryPull(the->h_used);

			if( !src ) {
				*i_read = i_data;
				i_err = STX_OK;
				break;
			}

			i_size = *(u16*)(src + 2);

			// get the data ptr;
			dptr = *(u8**)( src - sizeof(size_t));

			if( i_need < i_size ) {
				// update size;
				i_size -= (u16)i_need;
				*(u16*)(src + 2) = i_size;
				// copy
				memcpy(buf,dptr,i_need);
				// increase data ptr;
				*(u8**)( src - sizeof(size_t)) = dptr + i_need; 
				// increase data count;
				i_data += i_need;
				the->i_io_total += i_data;
				*i_read = i_data;
				stx_stat_add_val(the->h_io_stat,(s64)i_data);
				i_err = STX_OK;
				break;
			} // if( i_need < i_size ) {

			// free src packet 
			xloopPull(the->h_used);
			*(u8**)( src - sizeof(size_t) ) = src + 4;  // reset;
			xloopPush(the->h_free,src);
			memcpy(buf,dptr,i_size);

			buf += i_size;
			i_data += i_size;
			i_need -= i_size;

			if( !i_need ) {
				*i_read = i_data;
				the->i_io_total += i_data;
				stx_stat_add_val(the->h_io_stat,(s64)i_data);
				i_err = STX_OK;
				break;
			}// if( !i_need ) {

		} // for( ; ; ){

	}// block
	
fail:
	stx_release_mutex(the->h_mutex);

	return i_err;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_xio_vt_xxx_write
(stx_xio* h, const void* buffer, size_t cnt, size_t* i_write)
{
	STX_RESULT	i_err;
	u8*			buf;
	size_t		i_need;

	STX_MAP_THE(stx_io_as);

	if( the->oflag != O_WRONLY ) {
		return STX_FAIL;
	}

	stx_waitfor_mutex(the->h_mutex,INFINITE);

	*i_write = 0;

	i_need = cnt;
	buf = (u8*)buffer;


	for( ; ; ) {

		u8*			dst;
		size_t		i_cpy;
		s32			i_free;


		i_free = xloopGetUsed(the->h_free);

		if( i_free * AS_IO_BUF_SIZE < (s32)cnt ) {
			i_err = STX_WOUNLD_BLOCK;
			break;
		}

		dst = xloopPull(the->h_free);
		i_cpy = i_need > AS_IO_BUF_SIZE ? AS_IO_BUF_SIZE : i_need;
		*(u16*)(dst + 2) = (u16)i_cpy;
		memcpy( dst + 4, buf, i_cpy );
		xloopPush(the->h_used,dst);
		buf += i_cpy;
		i_need -= i_cpy;

		if( !i_need ) { // write over;
			*i_write = cnt;
			the->i_io_total += cnt;
			stx_stat_add_val(the->h_io_stat,(s64)cnt);
			i_err = STX_OK;
			break;
		}// if( !i_need ) {

	} //for( ; ; ) {

	stx_release_mutex(the->h_mutex);

	return i_err;	
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE offset_t stx_xio_vt_xxx_seek(stx_xio* h,offset_t off, s32 whence)
{
	STX_MAP_THE(stx_io_as);

	// ???

	return 0;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE offset_t stx_xio_vt_xxx_tell(stx_xio* h)
{
	STX_MAP_THE(stx_io_as);

	return (offset_t)the->i_io_total;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE offset_t stx_xio_vt_xxx_size(stx_xio* h)
{
	STX_MAP_THE(stx_io_as);

	return the->h_prot->size(the->h_prot);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_xio_vt_xxx_set
( stx_xio* h, u32 flags, STX_HANDLE h_val )
{
	STX_RESULT i_err;

	STX_MAP_THE(stx_io_as);

	i_err = STX_ERR_INVALID_PARAM;

	stx_waitfor_mutex(the->h_mutex,INFINITE);

	do{
		stx_io_op_param*	pinf = (stx_io_op_param*)h_val;

		if( STX_XIO_SET_BUF_SIZE == flags ) {

			if( the->i_total_buf_size < pinf->i_buf_size ) {

				s32				i_slot;
				u16				i_idx;
				u8*				buf;
				xloop*	h_free;
				xloop*	h_used;

				buf = NULL;
				h_free = NULL;
				h_used = NULL;

				do{

					u8*			pslot;
					u8*			pstart;
					s32			i;

					s32 const	i_slot_size = AS_IO_BUF_SIZE + 4 +sizeof(size_t);

					i_err = STX_FAIL;

					i_slot = (s32)( pinf->i_buf_size + AS_IO_BUF_SIZE - 1 ) / AS_IO_BUF_SIZE ;

					buf = (u8*)xmallocz( i_slot*i_slot_size);
					if( !buf ) {
						break;
					}

					h_free = xloopCreate(i_slot);
					if( !h_free ) {
						break;
					}
					h_used = xloopCreate(i_slot);
					if( !h_used ) {
						break;
					}

					memcpy( buf, the->buf, the->i_slot * i_slot_size );

					pstart = buf + sizeof(size_t) + 4;

					while( pslot = (u8*)xloopPull(the->h_free ) ) {
						i_idx = *(u16*)pslot;
						xloopPush(h_free, pstart  + i_idx * i_slot_size );
					}

					while( pslot = (u8*)xloopPull(the->h_used ) ) {
						i_idx = *(u16*)pslot;
						xloopPush(h_used, pstart + i_idx * i_slot_size );
					}

					// add additional buffer pointer to free loop;
					for( i = the->i_slot; i < i_slot; i ++ ) {
						xloopPush(h_free, pstart + i * i_slot_size );
					}

					xloopRelease(the->h_free);
					the->h_free = h_free;
					xloopRelease(the->h_used);
					the->h_used = h_used;
					stx_free(the->buf);
					the->buf = buf;
					the->i_slot = i_slot;
					the->i_total_buf_size = i_slot * AS_IO_BUF_SIZE;

					i_err = STX_OK;

				}while(FALSE);

				if( STX_OK != i_err ) {
					if( h_free ) {
						xloopRelease(h_free);
					}
					if( h_used ) {
						xloopRelease(h_used);
					}
					if( buf ) {
						stx_free(buf);
					}
				}

				break;
			}

			i_err = STX_OK;
			break;

		}

		if( STX_XIO_SET_HND == flags ) {
			if( !pinf->h_obj ) {
				i_err = STX_ERR_INVALID_PARAM;
				break;
			}
			the->h_prot = (stx_xio*)pinf->h_obj;
			i_err = STX_OK;
			break;
		}

		if( STX_XIO_SET_BIND == flags ) {
			if( the->sz_bind ) {
				stx_free(the->sz_bind);
			}
			the->sz_bind = xstrdup(pinf->buf);
			if( !the->sz_bind ) {
				i_err = STX_FAIL;
				break;
			}
			i_err = STX_OK;
			break;
		}

		if( the->h_prot ) {
			i_err = the->h_prot->set(the->h_prot,flags,h_val);
		}
		else {
			i_err = STX_ERR_INVALID_PARAM;
		}

	}while(FALSE);

	stx_release_mutex(the->h_mutex);

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_xio_vt_xxx_get( stx_xio* h, u32 flags, STX_HANDLE h_val )
{
	STX_RESULT i_err;

	STX_MAP_THE(stx_io_as);

	i_err = STX_ERR_INVALID_PARAM;

	stx_waitfor_mutex(the->h_mutex,INFINITE);

	do{

		if( STX_IO_PREFETCH == flags ) {
			stx_io_op_fetch* pfetch = (stx_io_op_fetch*)h_val;
			pfetch->i_data = (u32)(the->i_plug_total - the->i_io_total);
			pfetch->i_pos = the->i_io_total;
			pfetch->i_size = the->i_file_size;
			pfetch->i_rate = (u32)stx_stat_get_speed(the->h_io_stat); //  
			i_err = STX_OK;
			break;
		}

		if( STX_IO_READ_COM == flags || STX_IO_READ_PLUGIN == flags ) {
			stx_io_op_param* pinf = (stx_io_op_param*)h_val;
			stx_base_plugin* plug = &the->stx_base_plugin_vt;
			pinf->h_obj = plug;
			plug->add_ref(plug);
			i_err = STX_OK;
			break;
		}

		if( the->h_prot ) {
			i_err = the->h_prot->get(the->h_prot,flags,h_val);
			break;
		}

		i_err = STX_ERR_INVALID_PARAM;

	}while(FALSE);

	stx_release_mutex(the->h_mutex);

	return i_err;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_plugin_vt_xxx_get_property
(STX_HANDLE h,stx_xio* h_xio)
{
	STX_MAP_THE(stx_io_as);

	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_plugin_vt_xxx_set_property
(STX_HANDLE h,stx_xio* h_xio)
{
	STX_MAP_THE(stx_io_as);

	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_xio_vt_xxx_flush( stx_xio* pio )
{
	return STX_OK;
}