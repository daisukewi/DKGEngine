/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/
#include "stdio.h"
#include "stdlib.h"
#include "fcntl.h"
#include "malloc.h"
#include "memory.h"
#include "string.h"


#include "stx_mutex.h"
#include "stx_mem.h"
#include "stx_debug.h"
#include "stx_io_stream.h"
#include "stx_io_interleaved.h"


#include "stx_all.h"
#include "stp_download.h"
#include "stx_stack.h"
#include "stx_sync_source.h"

#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif

// {47ECAC06-57C0-42f4-A00D-346D08235EDE}
DEFINE_XGUID( STX_CLSID_StpDownload,
0x47ecac06, 0x57c0, 0x42f4, 0xa0, 0xd, 0x34, 0x6d, 0x8, 0x23, 0x5e, 0xde);

char* g_szStreamX_StpDownload = "StreamX StpDownload Plugin";


enum stp_dnl_status{
	dnl_read,dnl_write,dnl_auto_stop,
};


STX_INPUT_MEDIA_TYPE_MAP_BEGIN(stp_download)
/**/MEDIA_TYPE_MAP_ITEM(STX_GID_NULL,STX_GID_NULL)
STX_INPUT_MEDIA_TYPE_MAP_END()


STX_OUTPUT_MEDIA_TYPE_MAP_BEGIN(stp_download)
/**/MEDIA_TYPE_MAP_ITEM(STX_GID_NULL,STX_GID_NULL)
STX_OUTPUT_MEDIA_TYPE_MAP_END()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API_IMP 
CREATE_STX_COM(stx_stream_writer,STX_IID_FileWriter,stp_download);



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_COM_BEGIN(stp_download);
/**/
/* base source; */
/**/STX_PUBLIC( stx_base_source )
/**/
/* base filter; */
/**/STX_PUBLIC( stx_stream_writer)
/**/STX_COM_DATA_DEFAULT(stx_stream_writer)
/**/
/* base graph control;*/
/**/STX_PUBLIC( stx_base_control)
/**/
/* base media information; */
/**/STX_PUBLIC( stx_media_info)
/**/
/**/STX_HANDLE			h_task;
/**/b32					b_opened;
/**/b32					b_end;
/**/stx_base_plugin*	h_as_plugin;
/**/stx_xio*			p_file_io;
/**/char*				sz_file_name;
/**/s64					i_file_size;
/**/s64					i_file_time;
/**/stx_xio*			h_output_stream;
/**/char*				sz_output_file_name;
/**/STX_HANDLE			h_stack;
/**/s32					i_data;
/**/s32					i_rear;
/**/u8					buf[2048];
/**/
/**/STX_HANDLE			h_mutex;
/**/
STX_COM_END();


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_COM_FUNC_DECL_DEFAULT(stx_media_info,stx_media_info_vt);
STX_COM_FUNC_DECL_DEFAULT(stx_base_control,stx_base_control_vt);
STX_COM_FUNC_DECL_DEFAULT(stx_stream_writer,stx_stream_writer_vt);
STX_COM_FUNC_DECL_DEFAULT(stx_base_source,stx_base_source_vt);

STX_COM_FUNCIMP_DEFAULT(stp_download,stx_media_info,stx_media_info_vt);
STX_COM_FUNCIMP_DEFAULT(stp_download,stx_base_control,stx_base_control_vt);
STX_COM_FUNCIMP_DEFAULT(stp_download,stx_stream_writer,stx_stream_writer_vt);
STX_COM_FUNCIMP_DEFAULT(stp_download,stx_base_source,stx_base_source_vt);



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

/*{{{STX_MSG_ENTRY_DECLARE**************************************************/
/* to do : add msg proc entry  declaration here; */
/**/STX_MSG_ENTRY_DECLARE(on_play)
/**/STX_MSG_ENTRY_DECLARE(on_pause)
/**/STX_MSG_ENTRY_DECLARE(on_resume)
/**/STX_MSG_ENTRY_DECLARE(on_stop)
/**/STX_MSG_ENTRY_DECLARE(at_BreakPin)
/**/STX_MSG_ENTRY_DECLARE(at_play)
/**/STX_MSG_ENTRY_DECLARE(at_pause)
/**/STX_MSG_ENTRY_DECLARE(at_resume)
/**/STX_MSG_ENTRY_DECLARE(at_stop)
/**/STX_MSG_ENTRY_DECLARE(on_auto_stop)
/**/STX_MSG_ENTRY_DECLARE(on_app_stop)
/*}}}***********************************************************************/



/*{{{STX_BEGIN_MSG_MAP******************************************************/
STX_BEGIN_MSG_MAP(the_msg_data)
/* to do : add msg proc entry name here; */
/**/ON_STX_MSG(STX_MSG_Play,on_play)
/**/ON_STX_MSG(STX_MSG_Pause,on_pause)
/**/ON_STX_MSG(STX_MSG_Resume,on_resume)
/**/ON_STX_MSG(STX_MSG_Stop,on_stop)
/**/ON_STX_MSG(STX_MSG_AutoStop,on_auto_stop)
/**/ON_STX_MSG(STX_MSG_AppStop,on_app_stop)
STX_END_MSG_MAP
/*}}}***********************************************************************/


/*{{{STX_BEGIN_MSG_RESPONSE_MAP*********************************************/
STX_BEGIN_MSG_RESPONSE_MAP(the_msg_response)
/**//* to do : add msg process entry name here; */
/**/ON_STX_MSG(STX_MSG_Play,at_play)
/**/ON_STX_MSG(STX_MSG_Pause,at_pause)
/**/ON_STX_MSG(STX_MSG_Resume,at_resume)
/**/ON_STX_MSG(STX_MSG_Stop,at_stop)
/**/ON_STX_MSG(STX_MSG_BreakPin,at_BreakPin)
STX_END_MSG_RESPONSE_MAP
/*}}}***********************************************************************/


/*{{{STX_DISPATHCH_MSG_PROC*************************************************/
STX_DISPATCH_MSG_PROC( dispatch_msg,the_msg_data )
/*}}}***********************************************************************/


/*{{{STX_RESPONSE_MSG_PROC**************************************************/
STX_RESPONSE_MSG_PROC( response_msg,the_msg_response )
/*}}}***********************************************************************/


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT run_proc ( stp_download* the , stx_sync_inf* h_sync );
STX_PRIVATE STX_RESULT stop_proc ( stp_download* the);



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_COM_MAP_BEGIN(stp_download)
/**/STX_COM_MAP_ITEM(STX_IID_FileSource)
/**/STX_COM_MAP_ITEM(STX_IID_FileWriter)
/**/STX_COM_MAP_ITEM(STX_IID_BaseControl)
/**/STX_COM_MAP_ITEM(STX_IID_MediaInfo)
STX_COM_MAP_END()


STX_API_IMP	STX_NEW_BEGIN(stp_download)
{
	STX_SET_THE(stx_base_source);
	STX_COM_NEW_DEFAULT(stx_base_source,the->stx_base_source_vt,stx_base_source_vt,
		STX_CLSID_StpDownload,STX_CATEGORY_FileSource,g_szStreamX_StpDownload);

	STX_SET_THE(stx_stream_writer);
	STX_COM_NEW_DEFAULT(stx_stream_writer,the->stx_stream_writer_vt,stx_stream_writer_vt,
		STX_CLSID_StpDownload,STX_CATEGORY_FileWriter,g_szStreamX_StpDownload);

	STX_SET_THE(stx_base_control);
	STX_COM_NEW_DEFAULT(stx_base_control,the->stx_base_control_vt,stx_base_control_vt,
		STX_CLSID_StpDownload,STX_CATEGORY_FileSource,g_szStreamX_StpDownload);

	STX_SET_THE(stx_media_info);
	STX_COM_NEW_DEFAULT(stx_media_info,the->stx_media_info_vt,stx_media_info_vt,
		STX_CLSID_StpDownload,STX_CATEGORY_FileSource,g_szStreamX_StpDownload);

	the->h_stack = stx_stack_create();
	if( !the->h_stack ) {
		break;
	}
	the->h_mutex = stx_create_mutex(NULL,0,NULL);
	if( !the->h_mutex ) {
		break;
	}

}
STX_NEW_END()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_QUERY_BEGIN(stp_download)
{
	STX_COM_QUERY_DEFAULT(stx_base_source,the->stx_base_source_vt);
	STX_COM_QUERY_DEFAULT(stx_stream_writer,the->stx_stream_writer_vt);
	STX_COM_QUERY_DEFAULT(stx_base_control,the->stx_base_control_vt);
	STX_COM_QUERY_DEFAULT(stx_media_info,the->stx_media_info_vt);
}
STX_QUERY_END()



/***************************************************************************
STX_PURE sint32 flv_release(STX_HANDLE h)
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_DELETE_BEGIN(stp_download)
{
	/* todo : release object; */
	{
		stx_base_source* const src = &the->stx_base_source_vt;
		src->close_stream(src);
	}

	if( the->sz_output_file_name ) {
		stx_free(the->sz_output_file_name);
	}

	if( the->h_stack ) {
		stx_stack_close(the->h_stack);
	}

	if( the->h_mutex ) {
		stx_close_mutex(the->h_mutex);
	}

	STX_COM_DELETE_DEFAULT(stx_stream_writer);
}
STX_DELETE_END
(
STX_COM_DELETE_BEGIN(stx_stream_writer)
,
STX_COM_DELETE_END(stx_stream_writer)
)




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE void stx_base_source_vt_xxx_close_stream(STX_HANDLE h)
{
	STX_MAP_THE(stp_download);
	{
		SAFE_CLOSEXIO(the->h_output_stream );

		SAFE_CLOSEXIO(the->p_file_io);
		SAFE_XDELETE0(the->h_as_plugin);

		if( the->sz_file_name ) {
			stx_free( the->sz_file_name );
			the->sz_file_name = STX_NULL;
		}

		the->b_opened = FALSE;
	}

}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
HTTP: use http stream io;
TCP: use tcp stream io;
UDP: use udp stream io;
else use local file stream io;
***************************************************************************/
STX_PURE STX_RESULT stx_base_source_vt_xxx_load_stream
(STX_HANDLE h, const char* sz_stream,stx_sync_inf* h_sync)
{
	STX_RESULT		i_err;

	STX_MAP_THE(stp_download);


	if( the->b_opened ) {
		return STX_OK;
	}

	if( !the->p_file_io  ) {

		char sz_prot[8];

		if( strlen(sz_stream) < 6 ) {
			return STX_ERR_INVALID_PARAM;
		}

		the->sz_file_name = xstrdup(sz_stream);
		if( !the->sz_file_name ) {
			return STX_FAIL;
		}

		memcpy(sz_prot,sz_stream,4);
		sz_prot[4] = 0;
		stx_strupr(sz_prot,5);

		if( !strcmp(sz_prot,"HTTP") ) {  // url;

			the->h_as_plugin = XCREATE(stx_io_as,NULL);
			if( !the->h_as_plugin ) {
				return STX_FAIL;
			}
			XCALL(set_parent,the->h_as_plugin,(stx_base_plugin*)&the->stx_stream_writer_vt);
			XCALL(set_gbd,the->h_as_plugin,the->h_gbd);
			XCALL(set_ssrc,the->h_as_plugin,the->h_ssrc);
			i_err = XCALL(query_interf,the->h_as_plugin,STX_IID_BaseIo,(void**)&the->p_file_io);
			if( STX_OK != i_err ) {
				return i_err;
			}
			i_err = XCALL(open,the->p_file_io,sz_stream,O_RDONLY);
			if( STX_WOUNLD_BLOCK == i_err ) {
				h_sync->i_idle = MILISEC2REFTIME(100);
			}
			if( STX_OK != i_err ) {
				return i_err;
			}

		}
		else {
			// the input stream is local file;
			the->p_file_io = stx_create_io_file();
			if( !the->p_file_io ) {
				return STX_FAIL;
			}
			i_err = XCALL(open,the->p_file_io,sz_stream,O_RDONLY );
			if( STX_OK != i_err ) {
				return i_err;
			}
			XCALL(seek,the->p_file_io,0,SEEK_SET);

		}// file;

	} // if( !the->p_file_io ) {
	else{

		// use open to test it ;
		i_err = XCALL(open,the->p_file_io,sz_stream,O_RDONLY);
		if( STX_WOUNLD_BLOCK == i_err ) {
			h_sync->i_idle = MILISEC2REFTIME(100);
			return i_err;
		}
		if( STX_OK != i_err ) {
			return i_err;
		}
	} // else{

	the->i_file_size = XCALL(size,the->p_file_io);
	the->b_opened = TRUE;


	// get the output xio;
	{
		stx_base_message*	p_msg;
		stx_msg_cnt*		p_cnt;


		p_msg = XCREATE(base_msg,NULL,NULL);
		if( !p_msg) {
			return STX_FAIL;
		}

		do{

			p_msg->set_msg_type(p_msg,STX_MSG_TYPE_UPSTREAM);
			i_err = XCALL(set_msg_buf,p_msg,(u8*)&STX_IID_OutputIo,sizeof(STX_IID_OutputIo));
			if( STX_OK != i_err ) {
				break;
			}
			p_cnt = p_msg->get_msg_cnt(p_msg);
			p_cnt->msg_gid = STX_MSG_QueryObject;
			p_cnt->param.i_param[0] = STP_ID_STREAM_DATA; // file stream channel;

			i_err = XCALL(send_msg,the->p_parent,p_msg);
			if( STX_OK != i_err ) {
				break;
			}

			if( !p_msg->is_msg_closed(p_msg) ) {
				break;
			}

			the->h_output_stream = (stx_xio*)p_cnt->param.i_param[0];
			if( !the->h_output_stream) {
				break;
			}

			the->em_status = emStxStatusReady;

			stx_stack_push(the->h_stack,dnl_read);

			i_err = STX_OK;

		}while(FALSE);

		SAFE_XDELETE(p_msg);

		return i_err;

	} // block

}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_stream_writer_vt_flt_plug_xxx_run
( STX_HANDLE h , stx_sync_inf* h_sync )
{
	STX_RESULT i_err;

	STX_MAP_THE(stp_download);

	stx_waitfor_mutex(the->h_mutex,INFINITE);

	i_err = run_proc(the,h_sync);

	stx_release_mutex(the->h_mutex);

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT run_proc ( stp_download* the , stx_sync_inf* h_sync )
{
	STX_RESULT		i_err;
	size_t*			h_status;
	size_t			i_status;

	h_status = stx_stack_pop(the->h_stack);
	if( !h_status ) { // wait for stack reset, or initialized;
		h_sync->i_idle = MILISEC2REFTIME(10);
		RESET_XENTRY(h_sync,&the->stx_stream_writer_vt);
		return STX_WOUNLD_BLOCK;
	}
	i_status = *h_status;

	if( dnl_read == i_status ) {

		size_t i_read;

		do{
			i_read = 0;
			i_err = XCALL(read,the->p_file_io,the->buf,sizeof(the->buf),&i_read);
		}while( STX_AGAIN == i_err);

		if( i_err < 0 ) {
			return i_err;
		}
		if( STX_WOUNLD_BLOCK == i_err ) {
			stx_stack_push(the->h_stack,dnl_read);
			h_sync->i_idle = MILISEC2REFTIME(10);
			RESET_XENTRY(h_sync,&the->stx_stream_writer_vt);
			return STX_WOUNLD_BLOCK;
		}
		if( STX_EOF == i_err ) {
			the->b_end = TRUE;
		}

		if( i_read ) {
			the->i_rear = the->i_data = (s32)i_read;
			stx_stack_push(the->h_stack,dnl_write);
			return STX_AGAIN;
		}

		stx_stack_push(the->h_stack,dnl_auto_stop);
		return STX_AGAIN;
	}
	
	if( dnl_write == i_status ) {

		size_t	i_write;
		u8*		buf = the->buf + the->i_data - the->i_rear;

		do{
			i_err = XCALL(write,the->h_output_stream,buf,the->i_rear,&i_write);
		}while( STX_AGAIN == i_err);

		if( i_err < 0 ) {
			return i_err;
		}
		if( STX_WOUNLD_BLOCK == i_err ) {
			stx_stack_push(the->h_stack,dnl_write);
			h_sync->i_idle = MILISEC2REFTIME(10);
			RESET_XENTRY(h_sync,&the->stx_stream_writer_vt);
			return STX_WOUNLD_BLOCK;
		}
		if( STX_EOF == i_err ) {
			stx_stack_push(the->h_stack,dnl_auto_stop);
			return STX_AGAIN;
		}

		the->i_rear -= (s32)i_write;

		if( !the->i_rear) {
			if( the->b_end ) {
				stx_stack_push(the->h_stack,dnl_auto_stop);
				return STX_AGAIN;
			}
			stx_stack_push(the->h_stack,dnl_read);
//			return STX_AGAIN;
//			h_sync->i_idle = MILISEC2REFTIME(10);
			h_sync->i_idle = USEC2REFTIME( 10 + rand()%89 );
			RESET_XENTRY(h_sync,&the->stx_stream_writer_vt);
			return STX_WOUNLD_BLOCK;
		}

		stx_stack_push(the->h_stack,dnl_write);
//		h_sync->i_idle = MILISEC2REFTIME(10);
		h_sync->i_idle = USEC2REFTIME( 10 + rand()%89 );
		RESET_XENTRY(h_sync,&the->stx_stream_writer_vt);
		return STX_WOUNLD_BLOCK;

	} // if( dnl_write == i_status ) {

	// auto stop;
	{
		do{
			i_err = XCALL(flush,the->h_output_stream);
		}while( STX_AGAIN == i_err);
		if( i_err < 0 ) {
			return i_err;
		}
		if( STX_IDLE == i_err || STX_WOUNLD_BLOCK == i_err ) {
			stx_stack_push(the->h_stack,dnl_auto_stop);
			//h_sync->i_idle_time = MILISEC2REFTIME(10);
			h_sync->i_idle = USEC2REFTIME( 10 + rand()%89 );
			RESET_XENTRY(h_sync,&the->stx_stream_writer_vt);
			return STX_WOUNLD_BLOCK;
		}

		// STX_EOF will trigger a autostop message;
		stx_log("stp download: EOF \r\n" );
		return STX_EOF;

	} // auto stop status
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_stream_writer_vt_flt_plug_xxx_send_msg
( STX_HANDLE h, stx_base_message* p_msg )
{
	STX_RESULT	i_err;

	STX_MAP_THE(stp_download);

	do{
		u32			i_type;
		s32			i = 0;

		i_err = dispatch_msg(h,p_msg);
		if( i_err < 0 || p_msg->is_msg_closed(p_msg)) {
			break;
		}

		i_type = p_msg->get_msg_type(p_msg);

		if( i_type & STX_MSG_TYPE_UPSTREAM ) {
			stx_base_plugin* h_gph = the->p_parent;
			i_err = h_gph->send_msg(h_gph,p_msg);
		}

		if( i_err < 0 || p_msg->is_msg_closed(p_msg)) {
			break;
		}

		i_err = response_msg(h,p_msg);
		if( i_err < 0 || p_msg->is_msg_closed(p_msg)) {
			break;
		}

		i_err = STX_OK;

	}while(FALSE);

	return i_err;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_source_vt_xxx_set_pos(STX_HANDLE h,sint64 i_pos)
{
	STX_RESULT i_err;

	STX_MAP_THE(stp_download);

	i_err = STX_FAIL;


	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_source_vt_xxx_get_pos(STX_HANDLE h,sint64 *i_pos)
{
	STX_RESULT i_err;

	STX_MAP_THE(stp_download);

	i_err = STX_FAIL;


	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_base_source_vt_xxx_get_size(STX_HANDLE h,sint64 *i_size)
{
	STX_MAP_THE(stp_download);

	if( the->b_opened ) {
		*i_size = the->i_file_size;
		return STX_OK;
	}

	return STX_ERR_OBJ_UNINIT;
}



/* control; */
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_PURE STX_RESULT stx_base_control_vt_xxx_get_caps
(STX_HANDLE h,stx_xio* h_xio)
{
	STX_MAP_THE(stp_download);
	{

		STX_RESULT i_err;
		stx_xini*  h_xini;
		STX_HANDLE h_key;

		i_err = STX_FAIL;
		h_xini = NULL;

		do{

			i_err = stx_ini_create(NULL,h_xio,STX_INI_READ_WRITE|STX_INI_NO_COMMENT,0,&h_xini);
			if(STX_INI_OK != i_err ) {
				break;
			}

			i_err = XCALL(create_key,h_xini,NULL,(char*)g_szCtlCaps_play_stop,(char*)g_szTrue,&h_key);
			if(STX_INI_OK != i_err ) {
				break;
			}

			i_err = XCALL(create_key,h_xini,NULL,(char*)g_szCtlCaps_pause_resume,(char*)g_szTrue,&h_key);
			if(STX_INI_OK != i_err ) {
				break;
			}

			i_err = STX_OK;

		}while(FALSE);

		if( h_xini ) {
			h_xini->close(h_xini);
		}

		return i_err;
	}
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_get_status
(STX_HANDLE h,u32* i_status)
{
	STX_MAP_THE(stp_download);

	*i_status = the->em_status;

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_play(STX_HANDLE h)
{
	STX_RESULT			i_err;
	stx_base_plugin*    plug;

	STX_MAP_THE(stp_download);

	plug = (stx_base_plugin*)&the->stx_stream_writer_vt;

	// first send play message;
	{
		stx_base_message*	p_msg;
		stx_msg_cnt*		cnt;


		p_msg = XCREATE(base_msg,NULL,NULL);
		if( !p_msg) {
			return STX_FAIL;
		}

		p_msg->set_msg_type(p_msg,STX_MSG_TYPE_DOWNSTREAM);

		do{

			cnt = p_msg->get_msg_cnt(p_msg);
			cnt->msg_gid = STX_MSG_Play;
			i_err = plug->send_msg(plug,p_msg);
			if( i_err < 0 ) {
				break;
			}
			i_err = STX_OK;

		}while(FALSE);

		SAFE_XDELETE(p_msg);

		if( STX_OK != i_err ) {
			return i_err;
		}

	} //

	i_err = XCALL(reg_task,the->h_ssrc,&the->h_task,plug,TASK_NORMAL);
	if( STX_OK != i_err ) {
		return i_err;
	}

	the->em_status = emStxStatusPlay;
	// active ssrc handle;
	XCALL(reset_task,the->h_ssrc,the->h_task,0,0);

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_pause(STX_HANDLE h)
{
	// first send pause message;
	STX_RESULT			i_err;
	stx_base_plugin*    p_flt;

	STX_MAP_THE(stp_download);

	stx_waitfor_mutex(the->h_mutex,INFINITE);

	do{
		i_err = STX_OK;

		if( emStxStatusPause != the->em_status ){
			XCALL(set_task_events,the->h_ssrc,the->h_task,ev_pause);
			i_err = STX_WOUNLD_BLOCK;
			break;
		}

		// send stop message;
		{
			stx_base_message*	p_msg;
			stx_msg_cnt*		cnt;

			p_msg= XCREATE(base_msg,NULL,NULL);
			if( !p_msg) {
				i_err = STX_FAIL;
				break;
			}

			p_msg->set_msg_type(p_msg,STX_MSG_TYPE_DOWNSTREAM);

			cnt = p_msg->get_msg_cnt(p_msg);
			cnt->msg_gid = STX_MSG_Pause;
			p_flt = (stx_base_plugin*)&the->stx_stream_writer_vt;
			i_err = p_flt->send_msg(p_flt,p_msg);
			if( i_err < 0 ) {
				break;
			}

			SAFE_XDELETE(p_msg);

			i_err = STX_OK;

		} // block;

	}while(FALSE);

	stx_release_mutex(the->h_mutex);

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_resume(STX_HANDLE h)
{
	// first send pause message;
	STX_RESULT			i_err;
	stx_base_plugin*    p_flt;

	STX_MAP_THE(stp_download);

	stx_waitfor_mutex(the->h_mutex,INFINITE);

	do{

		assert( emStxStatusPause == the->em_status );

		// send resume message;
		{
			stx_base_message*	p_msg;
			stx_msg_cnt*		cnt;

			p_msg= XCREATE(base_msg,NULL,NULL);
			if( !p_msg) {
				i_err = STX_FAIL;
				break;
			}

			p_msg->set_msg_type(p_msg,STX_MSG_TYPE_DOWNSTREAM);

			cnt = p_msg->get_msg_cnt(p_msg);
			cnt->msg_gid = STX_MSG_Resume;
			p_flt = (stx_base_plugin*)&the->stx_stream_writer_vt;
			i_err = p_flt->send_msg(p_flt,p_msg);
			if( i_err < 0 ) {
				break;
			}

			SAFE_XDELETE(p_msg);

			XCALL(reset_task,the->h_ssrc,the->h_task,0,0);

			i_err = STX_OK;

		} // block;

	}while(FALSE);

	stx_release_mutex(the->h_mutex);

	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_set
(STX_HANDLE h,u32 i_flag,size_t i_set)
{
	STX_MAP_THE(stp_download);
	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_stop(STX_HANDLE h)
{
	STX_RESULT i_err;

	STX_MAP_THE(stp_download);

	stx_waitfor_mutex(the->h_mutex,INFINITE);

	i_err = STX_OK;

	do{

		i_err = STX_OK;

		if( emStxStatusStop != the->em_status ){
			XCALL(set_task_events,the->h_ssrc,the->h_task,ev_stop);
			i_err = STX_WOUNLD_BLOCK;
			break;
		} // if( emStxStatusStop != the->em_status ){

		// check the as io;
		if( the->h_as_plugin ) {
			i_err = the->p_file_io->stop(the->p_file_io);
			if( STX_OK != i_err ) {
				break;
			}
		}

		// unreg ssrc handle;
		the->h_ssrc->unreg_task(the->h_ssrc,the->h_task);

		// thread task stopped, next , send stop message to downstream filters;
		{
			stx_base_message*	p_msg;
			stx_msg_cnt*		cnt;

			stx_base_plugin* const plug = (stx_base_plugin*)&the->stx_stream_writer_vt;

			p_msg= XCREATE(base_msg,NULL,NULL);
			if( !p_msg) {
				return STX_FAIL;
			}

			p_msg->set_msg_type(p_msg,STX_MSG_TYPE_DOWNSTREAM);

			cnt = p_msg->get_msg_cnt(p_msg);
			cnt->msg_gid = STX_MSG_Stop;
			i_err = plug->send_msg(plug,p_msg);
			if( i_err < 0 ) {
				break;
			}

			SAFE_XDELETE(p_msg);

			i_err = STX_OK;

		} // block

		// return to do final cleanup;
		the->em_status = emStxStatusInit;

	}while(FALSE);

	stx_release_mutex(the->h_mutex);

	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_next(STX_HANDLE h)
{
	STX_RESULT i_err;

	STX_MAP_THE(stp_download);

	i_err = STX_FAIL;


	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_prev(STX_HANDLE h)
{
	STX_RESULT i_err;

	STX_MAP_THE(stp_download);

	i_err = STX_FAIL;


	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_step(STX_HANDLE h)
{
	STX_RESULT i_err;

	STX_MAP_THE(stp_download);

	i_err = STX_FAIL;

	return i_err;
}

/* media info; */
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_media_info_vt_xxx_get_desc
(STX_HANDLE h, sint32* i_len, char** sz_desc )
{
	STX_RESULT i_err;

	STX_MAP_THE(stp_download);

	i_err = STX_FAIL;


	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_media_info_vt_xxx_get_total_time
(STX_HANDLE h,sint64 *i_time)
{
	STX_MAP_THE(stp_download);

	*i_time = the->i_file_time;

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_media_info_vt_xxx_get_statistic
(STX_HANDLE h,s32 * i_size,char ** pp_sz )
{
	return STX_ERR_NOT_IMP;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_media_info_vt_xxx_get_current_time
(STX_HANDLE h,sint64 *i_time)
{
	STX_RESULT i_err;

	STX_MAP_THE(stp_download);

	i_err = STX_FAIL;


	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_media_info_vt_xxx_time_to_pos
(STX_HANDLE h,sint64 i_time,offset_t * pos )
{
	STX_RESULT i_err;

	STX_MAP_THE(stp_download);

	i_err = STX_FAIL;


	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_media_info_vt_xxx_pos_to_time
(STX_HANDLE h, offset_t pos ,sint64* i_time )
{
	STX_RESULT i_err;

	STX_MAP_THE(stp_download);

	i_err = STX_FAIL;


	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT on_play(STX_HANDLE h, stx_base_message* p_msg )
{
	STX_MAP_THE(stp_download);



	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT on_stop(STX_HANDLE h,stx_base_message* p_msg)
{	
	STX_MAP_THE(stp_download);



	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_ENTRY STX_RESULT at_BreakPin(STX_HANDLE h, stx_base_message* p_msg )
{
	STX_MAP_THE(stp_download);
	{
	}

	return STX_OK;
}


/***************************************************************************
STX_MSG_PROC STX_RESULT on_pause(STX_HANDLE h, stx_base_message* p_msg )
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT on_pause(STX_HANDLE h, stx_base_message* p_msg)
{
	STX_MAP_THE(stp_download);

	return STX_OK;
}

/***************************************************************************
STX_MSG_PROC STX_RESULT on_resume( STX_HANDLE h, stx_base_message* p_msg )
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT on_resume( STX_HANDLE h, stx_base_message* p_msg )
{
	STX_MAP_THE(stp_download);

	return STX_OK;
}


/***************************************************************************
STX_MSG_PROC STX_RESULT at_play(STX_HANDLE h, stx_base_message* p_msg )
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT at_play(STX_HANDLE h, stx_base_message* p_msg )
{
	STX_MAP_THE(stp_download);

	// source filter status is not correct ;
	return STX_OK;
}

/***************************************************************************
STX_MSG_PROC STX_RESULT at_stop(STX_HANDLE h,stx_base_message* p_msg)
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT at_stop(STX_HANDLE h,stx_base_message* p_msg )
{

	STX_MAP_THE(stp_download);
	{
		stx_base_source* h_src;

		h_src = &the->stx_base_source_vt;
		h_src->close_stream(h_src);

		return STX_OK;
	}

}



/***************************************************************************
STX_MSG_PROC STX_RESULT at_pause(STX_HANDLE h, stx_base_message* p_msg )
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT at_pause(STX_HANDLE h, stx_base_message* p_msg )
{
	STX_MAP_THE(stp_download);

	// source filter status is not correct ;
	return STX_OK;
}


/***************************************************************************
STX_MSG_PROC STX_RESULT at_resume( STX_HANDLE h, stx_base_message* p_msg )
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT at_resume( STX_HANDLE h, stx_base_message* p_msg )
{
	STX_MAP_THE(stp_download);

	return STX_OK;
}




/***************************************************************************
RETURN VALUE:
INPUT: 
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT 
on_auto_stop(STX_HANDLE h,stx_base_message* p_msg )
{

	STX_MAP_THE(stp_download);
	{
		STX_HANDLE h_stack = p_msg->get_stack(p_msg);

		// push plugin interface pointer;
		stx_stack_push(h_stack,(size_t)&the->stx_stream_writer_vt);

		return STX_OK;
	}
}



/***************************************************************************
RETURN VALUE:
INPUT: 
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT 
on_app_stop(STX_HANDLE h,stx_base_message* p_msg )
{
	STX_MAP_THE(stp_download);
	{
		stx_msg_cnt* p_cnt = p_msg->get_msg_cnt(p_msg);

		p_msg->set_msg_close(p_msg);

		// must be as io; send stop message to app handler;
		return stx_base_plugin_stop(
			(stx_base_plugin*)&the->stx_stream_writer_vt,
			(STX_RESULT)p_cnt->param.i_param[0],
			FALSE);

	}
}




/***************************************************************************
RETURN VALUE:
INPUT: 
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT stx_stream_writer_vt_flt_xxx_set_input_media_type
(STX_HANDLE h,stx_media_type * p_mtype)
{
	return STX_ERR_NOT_SUPPORT;
}



/***************************************************************************
RETURN VALUE:
INPUT: 
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT stx_stream_writer_vt_flt_xxx_set_output_media_type
(STX_HANDLE h,stx_media_type * p_mtype)
{
	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_stream_writer_vt_flt_plug_xxx_start
(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT: 
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT stx_stream_writer_vt_flt_plug_xxx_stop
(STX_HANDLE h,u32 i_flag,stx_sync_inf *h_sync)
{
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_stream_writer_vt_flt_plug_xxx_flush
(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_stream_writer_vt_flt_xxx_enum_input_pin
(STX_HANDLE h,sint32* i_idx,stx_base_pin** pp_pin )
{
	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_stream_writer_vt_flt_xxx_enum_output_pin
(STX_HANDLE h,sint32 *i_idx,stx_base_pin** pp_pin )
{
	return STX_ERR_NOT_SUPPORT;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_stream_writer_vt_flt_xxx_check_input_media_type
( STX_HANDLE h, stx_media_type* p_mdt )
{

	return STX_ERR_NOT_SUPPORT;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_stream_writer_vt_flt_xxx_check_output_media_type
( STX_HANDLE h, stx_media_type* p_mdt )
{
	return STX_ERR_NOT_SUPPORT;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_stream_writer_vt_xxx_set_stream
( STX_HANDLE h, stx_xio* p_output )
{
	STX_MAP_THE(stp_download);

	if( the->sz_file_name ) {
		stx_free(the->sz_file_name);
		the->sz_file_name = NULL;
	}

	SAFE_CLOSEXIO(the->h_output_stream);
	the->h_output_stream = p_output;

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT stx_stream_writer_vt_xxx_set_stream_name
(STX_HANDLE h,const char * sz_name)
{
	STX_MAP_THE(stp_download);

	if( the->sz_output_file_name ) {
		stx_free(the->sz_output_file_name);
	}

	the->sz_output_file_name = xstrdup(sz_name);
	if( !the->sz_output_file_name ) {
		return STX_FAIL;
	}

	return STX_OK;

}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_stream_writer_vt_flt_xxx_deliver
(
 STX_HANDLE			h,
 stx_base_pin*		h_pin, // which input pin;
 stx_media_data*	p_mdat, // output media data;
 stx_sync_inf*		h_sync
 )
{
	return STX_ERR_NOT_SUPPORT;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_stream_writer_vt_flt_xxx_new_segment
( STX_HANDLE h )
{
	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_stream_writer_vt_flt_xxx_receive
(
 STX_HANDLE			h,
 stx_base_pin*		h_pin, // which input pin;
 stx_media_data**	pp_mdat,// output media data;
 stx_sync_inf*		h_sync 
 )
{
	return STX_ERR_NOT_SUPPORT;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT  stx_stream_writer_vt_flt_plug_xxx_get_property
(STX_HANDLE h,stx_xio* h_xio)
{
	STX_MAP_THE(stp_download);
	{
		STX_RESULT i_err;
		stx_xini*  h_xini;
		STX_HANDLE h_prop;
		STX_HANDLE h_rule;
		STX_HANDLE h_sub_rule;

		i_err = STX_FAIL;
		h_xini = NULL;


		do{

			i_err = stx_ini_create(NULL,h_xio,STX_INI_READ_WRITE|STX_INI_NO_COMMENT,0,&h_xini);
			if(STX_INI_OK != i_err ) {
				break;
			}

			// property page = list;
			i_err = h_xini->create_key(h_xini,NULL,(char*)g_szPropertyPage,(char*)g_szControl_list,&h_prop);
			if(STX_INI_OK != i_err ) {
				break;
			}


			i_err = h_xini->create_key(h_xini,h_prop,"file name",(char*)g_szType_string,&h_rule);
			if(STX_INI_OK != i_err ) {
				break;
			}
			if( the->sz_file_name ) {
				i_err = h_xini->create_key(h_xini,h_rule,(char*)g_szVal,the->sz_file_name,&h_sub_rule);
			}
			else {
				i_err = h_xini->create_key(h_xini,h_rule,(char*)g_szVal,"@input valid path name",&h_sub_rule);
			}
			if(STX_INI_OK != i_err ) {
				break;
			}

			i_err = STX_OK;

		}while(FALSE);

		if( h_xini ) {
			h_xini->close(h_xini);
		}

		return i_err;

	}// block;

	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_stream_writer_vt_flt_plug_xxx_set_property
(STX_HANDLE h,stx_xio* h_xio)
{
	STX_RESULT	i_err;
	stx_xini*	h_xini;
	STX_HANDLE	h_prop;
	STX_HANDLE	h_rule;
	STX_HANDLE	h_sub_rule;
	char*		sz_val;

	stx_stream_writer* writer;

	STX_MAP_THE(stp_download);

	i_err = STX_FAIL;
	h_xini = NULL;

	writer = &the->stx_stream_writer_vt;

	do{
		i_err = stx_ini_create(NULL,h_xio,STX_INI_READ_ONLY|STX_INI_NO_COMMENT,0,&h_xini );
		if( STX_INI_OK != i_err ) {
			break;
		}

		// property page = property page;
		i_err = h_xini->create_key(h_xini,NULL,(char*)g_szPropertyPage,NULL,&h_prop);
		if(STX_INI_OK != i_err ) {
			break;
		}

		// output file name;
		i_err = h_xini->create_key(h_xini,h_prop,"file name",(char*)g_szType_string,&h_rule);
		if(STX_INI_OK == i_err ) {
			i_err = h_xini->create_key(h_xini,h_rule,(char*)g_szVal,NULL,&h_sub_rule);
			if(STX_INI_OK != i_err ) {
				break;
			}
			i_err = h_xini->read_string(h_xini,h_sub_rule,&sz_val);
			if(STX_INI_OK != i_err ) {
				break;
			}
			if( '@'!= sz_val[0] ) {
				i_err = writer->set_stream_name(writer,sz_val);
				if( STX_OK!= i_err ) {
					break;
				}
			}
		}

		i_err = STX_OK;

	}while(FALSE);

	if( h_xini ) {
		h_xini->close(h_xini);
	}

	return i_err;
}
