/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#include "stx_base_type.h"

#include "stx_cpuid.h"

#include "stx_string_parser.h"





typedef struct {
	const char name[16];
	int flags;
} x264_cpu_name_t;


/* CPU flags
*/
#define X264_CPU_CACHELINE_32   0x000001  /* avoid memory loads that span the border between two cachelines */
#define X264_CPU_CACHELINE_64   0x000002  /* 32/64 is the size of a cacheline in bytes */
#define X264_CPU_ALTIVEC        0x000004
#define X264_CPU_MMX            0x000008
#define X264_CPU_MMXEXT         0x000010  /* MMX2 aka MMXEXT aka ISSE */
#define X264_CPU_SSE            0x000020
#define X264_CPU_SSE2           0x000040
#define X264_CPU_SSE2_IS_SLOW   0x000080  /* avoid most SSE2 functions on Athlon64 */
#define X264_CPU_SSE2_IS_FAST   0x000100  /* a few functions are only faster on Core2 and Phenom */
#define X264_CPU_SSE3           0x000200
#define X264_CPU_SSSE3          0x000400
#define X264_CPU_SHUFFLE_IS_FAST 0x000800 /* Penryn, Nehalem, and Phenom have fast shuffle units */
#define X264_CPU_STACK_MOD4     0x001000  /* if stack is only mod4 and not mod16 */
#define X264_CPU_SSE4           0x002000  /* SSE4.1 */
#define X264_CPU_SSE42          0x004000  /* SSE4.2 */
#define X264_CPU_SSE_MISALIGN   0x008000  /* Phenom support for misaligned SSE instruction arguments */
#define X264_CPU_LZCNT          0x010000  /* Phenom support for "leading zero count" instruction. */

#if 0
const x264_cpu_name_t x264_cpu_names[] = {
	{"Altivec", X264_CPU_ALTIVEC},
	//  {"MMX",     X264_CPU_MMX}, // we don't support asm on mmx1 cpus anymore
	{"MMX2",    X264_CPU_MMX|X264_CPU_MMXEXT},
	{"MMXEXT",  X264_CPU_MMX|X264_CPU_MMXEXT},
	//  {"SSE",     X264_CPU_MMX|X264_CPU_MMXEXT|X264_CPU_SSE}, // there are no sse1 functions in x264
	{"SSE2Slow",X264_CPU_MMX|X264_CPU_MMXEXT|X264_CPU_SSE|X264_CPU_SSE2|X264_CPU_SSE2_IS_SLOW},
	{"SSE2",    X264_CPU_MMX|X264_CPU_MMXEXT|X264_CPU_SSE|X264_CPU_SSE2},
	{"SSE2Fast",X264_CPU_MMX|X264_CPU_MMXEXT|X264_CPU_SSE|X264_CPU_SSE2|X264_CPU_SSE2_IS_FAST},
	{"SSE3",    X264_CPU_MMX|X264_CPU_MMXEXT|X264_CPU_SSE|X264_CPU_SSE2|X264_CPU_SSE3},
	{"SSSE3",   X264_CPU_MMX|X264_CPU_MMXEXT|X264_CPU_SSE|X264_CPU_SSE2|X264_CPU_SSE3|X264_CPU_SSSE3},
	{"FastShuffle",   X264_CPU_MMX|X264_CPU_MMXEXT|X264_CPU_SSE|X264_CPU_SSE2|X264_CPU_SHUFFLE_IS_FAST},
	{"SSE4.1",  X264_CPU_MMX|X264_CPU_MMXEXT|X264_CPU_SSE|X264_CPU_SSE2|X264_CPU_SSE3|X264_CPU_SSSE3|X264_CPU_SSE4},
	{"SSE4.2",  X264_CPU_MMX|X264_CPU_MMXEXT|X264_CPU_SSE|X264_CPU_SSE2|X264_CPU_SSE3|X264_CPU_SSSE3|X264_CPU_SSE4|X264_CPU_SSE42},
	{"Cache32", X264_CPU_CACHELINE_32},
	{"Cache64", X264_CPU_CACHELINE_64},
	{"SSEMisalign", X264_CPU_SSE_MISALIGN},
	{"LZCNT", X264_CPU_LZCNT},
	{"Slow_mod4_stack", X264_CPU_STACK_MOD4},
	{"", 0},
};
#endif

#ifdef __WIN32_LIB

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
#ifndef STX64
u32 stx_cpuid_test()
{
	__asm{
		pushfd
		push    ebx
		push    ebp
		push    esi
		push    edi
		pushfd
		pop     eax
		mov     ebx, eax
		xor     eax, 0x200000
		push    eax
		popfd
		pushfd
		pop     eax
		xor     eax, ebx
		pop     edi
		pop     esi
		pop     ebp
		pop     ebx
		popfd
	}

}
#endif


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
s32 get_cpu_flag()
{
	uint32_t cpu = 0;
	uint32_t flag[8] = {0};
	uint32_t vendor[8] = {0};

	int max_extended_cap;
	int cache;

#ifndef STX64
	if( !stx_cpuid_test() ){
		return 0;
	}
#endif

	__cpuid(vendor, 0 );
	if( vendor[0] == 0 )
		return 0;

	__cpuid(flag, 1 );

	if( flag[3] & 0x00800000 )
		cpu |= X264_CPU_MMX;
	else
		return 0;

	if( flag[3] & 0x02000000 )
		cpu |= X264_CPU_MMXEXT|X264_CPU_SSE;

	if( flag[3] & 0x04000000 )
		cpu |= X264_CPU_SSE2;

	if( flag[2] & 0x00000001 )
		cpu |= X264_CPU_SSE3;

	if( flag[2] & 0x00000200 )
		cpu |= X264_CPU_SSSE3;

	if( flag[2] & 0x00080000 )
		cpu |= X264_CPU_SSE4;

	if( flag[2] & 0x00100000 )
		cpu |= X264_CPU_SSE42;

	if( cpu & X264_CPU_SSSE3 )
		cpu |= X264_CPU_SSE2_IS_FAST;

	if( cpu & X264_CPU_SSE4 )
		cpu |= X264_CPU_SHUFFLE_IS_FAST;

	__cpuid(flag, 0x80000000 );

	max_extended_cap = flag[0];

	if( ( !strcmp((char*)&vendor[1], "AuthenticAMD")  || !strcmp((char*)&vendor[1], "AuthcAMDenti")  )
		&& max_extended_cap >= 0x80000001 ){

		__cpuid(flag, 0x80000001 );

		if( flag[3] & 0x00400000 )
			cpu |= X264_CPU_MMXEXT;

	}

	if( !strcmp((char*)vendor, "GenuineIntel") ){

		int family, model, stepping;

		__cpuid(flag, 1 );
	
		family = ((flag[0]>>8)&0xf) + ((flag[0]>>20)&0xff);
		model  = ((flag[0]>>4)&0xf) + ((flag[0]>>12)&0xf0);
		stepping = flag[0]&0xf;

		/* 6/9 (pentium-m "banias"), 6/13 (pentium-m "dothan"), and 6/14 (core1 "yonah")
		* theoretically support sse2, but it's significantly slower than mmx for
		* almost all of x264's functions, so let's just pretend they don't. */
		if( family==6 && (model==9 || model==13 || model==14) )
		{
			cpu &= ~(X264_CPU_SSE2|X264_CPU_SSE3);
			//stx_assert(!(cpu&(X264_CPU_SSSE3|X264_CPU_SSE4)));
		}
	}


	{
		u32 mmflag = 0;

		if( cpu & X264_CPU_MMX ) {
			mmflag |= MM_MMX;
		}
		if( cpu & X264_CPU_MMXEXT ) {
			mmflag |= MM_MMXEXT;
		}
		if( cpu & X264_CPU_SSE ) {
			mmflag |= MM_SSE;
		}
		if( cpu & X264_CPU_SSE2 ) {
			mmflag |= MM_SSE2;
		}
		if( cpu & X264_CPU_SSE3 ) {
			mmflag |= MM_SSE3;
		}
		if( cpu & X264_CPU_SSSE3 ) {
			mmflag |= MM_SSSE3;
		}
		if( cpu & X264_CPU_SSE4 ) {
			mmflag |= MM_SSE41;
		}
		if( cpu & X264_CPU_SSE42 ) {
			mmflag |= MM_SSE42;
		}

		return mmflag;
	}

}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
s32 stx_cpu_cpuid( s32 op, s32 *eax, s32 *ebx, s32 *ecx, s32 *edx )
{
	s32 flag[4] = {0};
	__cpuid(flag,op);
	*eax = flag[0];
	*ebx = flag[1];
	*ecx = flag[2];
	*edx = flag[3];
	return flag[0];
}


#endif



#ifdef __LINUX_LIB

#	ifdef STX64
#		define PUSHF "pushfq\n\t"
#		define POPF "popfq\n\t"
#		define REG_b rbx
#		define REG_S rsi
#	else
#		define PUSHF "pushfl\n\t"
#		define POPF "popfl\n\t"
#		define REG_b ebx
#		define REG_S esi
#	endif

	/* ebx saving is necessary for PIC. gcc seems unable to see it alone */
#	ifdef STX64
#		define cpuid(index,eax,ebx,ecx,edx)\
			asm volatile\
			("mov %%rbx, %%rsi\n\t"\
			 "cpuid\n\t"\
			 "xchg %%rbx, %%rsi\n\t"\
			 : "=a" (eax), "=S" (ebx),\
			   "=c" (ecx), "=d" (edx)\
			 : "0" (index));
#	else
#		define cpuid(index,eax,ebx,ecx,edx)\
    			asm volatile\
        		("mov %%ebx, %%esi\n\t"\
        		 "cpuid\n\t"\
         		"xchg %%ebx, %%esi\n\t"\
         		: "=a" (eax), "=S" (ebx),\
           		"=c" (ecx), "=d" (edx)\
         		: "0" (index));
#	endif

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
s32 stx_cpu_cpuid( s32 iop, s32 *pa, s32 *pb, s32 *pc, s32 *pd )
{
	size_t eax,ebx,ecx,edx;
	cpuid(iop,eax,ebx,ecx,edx);
	*pa = eax;
	*pb = ebx;
	*pc = ecx;
	*pd = edx;
	return eax;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
u64 get_rdtsc()
{
	u32 a, d;
	__asm__ volatile("rdtsc" : "=a" (a), "=d" (d));
	return (((u64)a) | (((u64)d) << 32));
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
b32 stx_cpuid_test()
{
	size_t a, c;

	__asm__ volatile (
		/* See if CPUID instruction is supported ... */
		/* ... Get copies of EFLAGS into eax and ecx */
		PUSHF
		"pop %0\n\t"
		"mov %0, %1\n\t"

		/* ... Toggle the ID bit in one copy and store */
		/*     to the EFLAGS reg */
		"xor $0x200000, %0\n\t"
		"push %0\n\t"
		POPF

		/* ... Get the (hopefully modified) EFLAGS */
		PUSHF
		"pop %0\n\t"
		: "=a" (a), "=c" (c)
		:
	: "cc"
		);

/*return 0 CPUID not supported */	
	return a != c;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
s32 get_cpu_flag()
{
	/* Function to test if multimedia instructions are supported...  */

	s32 rval = 0;
	s32 eax, ebx, ecx, edx;
	s32 max_std_level, max_ext_level, std_caps=0, ext_caps=0;

	if( !stx_cpuid_test() ) {
		return 0;
	}

	cpuid(0, max_std_level, ebx, ecx, edx);

	if(max_std_level >= 1){

		cpuid(1, eax, ebx, ecx, std_caps);

		if (std_caps & (1<<23))
			rval |= MM_MMX;

		if (std_caps & (1<<25))
			rval |= MM_MMXEXT | MM_SSE;

		if (std_caps & (1<<26))
			rval |= MM_SSE2;

		if (ecx & 1)
			rval |= MM_SSE3;

		if (ecx & 0x00000200 )
			rval |= MM_SSSE3;

		if( ecx & 0x00080000 )
			rval |= MM_SSE41;

		if( ecx & 0x00100000 )
			rval |= MM_SSE42;
	}

	cpuid(0x80000000, max_ext_level, ebx, ecx, edx);

	if(max_ext_level >= 0x80000001){
		cpuid(0x80000001, eax, ebx, ecx, ext_caps);
		if (ext_caps & (1<<31))
			rval |= MM_3DNOW;
		if (ext_caps & (1<<30))
			rval |= MM_3DNOWEXT;
		if (ext_caps & (1<<23))
			rval |= MM_MMX;
		if (ext_caps & (1<<22))
			rval |= MM_MMXEXT;
	}

#if 0
	stx_log( "%s%s%s%s%s%s%s%s\n",
		(rval&FF_MM_MMX) ? "MMX ":"",
		(rval&FF_MM_MMXEXT) ? "MMX2 ":"",
		(rval&FF_MM_SSE) ? "SSE ":"",
		(rval&FF_MM_SSE2) ? "SSE2 ":"",
		(rval&FF_MM_SSE3) ? "SSE3 ":"",
		(rval&FF_MM_SSSE3) ? "SSSE3 ":"",
		(rval&FF_MM_3DNOW) ? "3DNow ":"",
		(rval&FF_MM_3DNOWEXT) ? "3DNowExt ":"");
#endif

	return rval;
}

#endif
