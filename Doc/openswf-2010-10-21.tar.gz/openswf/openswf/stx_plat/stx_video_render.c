/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/
#include "stdio.h"
#include "stdlib.h"
#include "fcntl.h"
#include "malloc.h"
#include "memory.h"
#include "string.h"

#include "stx_mem.h"
#include "stx_debug.h"
#include "stx_gid_def.h"
#include "stx_module_reg.h"
#include "stx_video_render.h"





















