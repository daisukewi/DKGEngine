/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-06
***********************************************************************************/
#include "stdio.h"
#include "stdlib.h"
#include "fcntl.h"
#include "memory.h"
#include "string.h"
#include "assert.h"

#include "stx_os.h"
#include "stx_mem.h"
#include "stx_debug.h"


#include "stp_client.h"

#include "stx_io_stream.h"
#include "stx_io_file.h"
#include "stx_io_direct.h"
#include "stx_io_tcp.h"

#include "stx_prop_def.h"
#include "stx_module_reg.h"
#include "stx_protocol.h"
#include "stx_io_interleaved.h"
#include "stx_all_codec.h"


#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif

enum stp_client_status{
	em_open_socket,
	em_send_request,
	em_send_graph,
	em_wait_header,
	em_wait_response,
	em_send_play,
	em_wait_play_hdr,
	em_wait_play_body,
	em_receive_file,
	em_send_close,
	em_wait_close,
};


STX_INTERF(stp_client);

struct stp_client{

	stx_xio				stx_xio_vt;

	char*				sz_url;
	char*				sz_graph;
	char				sz_param[128];
	stx_io_op_param		param;
	stx_xio*			h_tcp;
	stx_xio*			h_stream;
	//stx_xio*			h_graph;
	u8*					p_graph;
	u32					i_graph_size;
	stx_interleaved*	h_interleave;
	stx_xio*			h_cmd;

	s32					i_channel;
	stp_subchannel		sub_cha[8];

	stx_xio*			h_attach;

	s64					i_file_size;
	s64					i_file_time;
	s64					i_moddate;

	s64					i_download_size;

	THEE				h_stack;
};


STX_COM_FUNC_DECL_DEFAULT(stx_xio,stx_xio_vt);


STX_PRIVATE STX_RESULT stp_client_open_socket(stp_client* the);
STX_PRIVATE STX_RESULT stp_client_send_request(stp_client* the);
STX_PRIVATE STX_RESULT stp_client_send_graph(stp_client* the);
STX_PRIVATE STX_RESULT stp_client_wait_header(stp_client* the);
STX_PRIVATE STX_RESULT stp_client_wait_response(stp_client* the);
STX_PRIVATE STX_RESULT stp_client_send_play(stp_client* the);
STX_PRIVATE STX_RESULT stp_client_wait_play_hdr(stp_client* the);
STX_PRIVATE STX_RESULT stp_client_wait_play_body(stp_client* the);
STX_PRIVATE STX_RESULT stp_client_receive_file(stp_client* the);
STX_PRIVATE STX_RESULT stp_client_send_close(stp_client* the);
STX_PRIVATE STX_RESULT stp_client_wait_close(stp_client* the);

STX_PRIVATE STX_RESULT stp_download_file
(stp_client* the, stx_xio* h_data, stx_xio* h_file, size_t* p_size );

STX_PRIVATE STX_RESULT write_out_stream(stp_client* the);

STX_PRIVATE STX_RESULT write_cmd_download(stp_client *the );
STX_PRIVATE STX_RESULT write_cmd_play(stp_client *the );
STX_PRIVATE STX_RESULT write_cmd_close_dwonload( stx_xio* h_stream );




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
stx_xio* stx_create_io_stp
(
	const char*		sz_ip,
	u16				i_port,
	const char*		sz_url,
	const char*		sz_graph,
	stx_xio*		h_stream
)
{
	STX_RESULT		i_err;
	stp_client*		the;

	i_err = STX_FAIL;
	the = NULL;

	do{

		if( !sz_url || !sz_graph ) {
			break;
		}

		the = (stp_client*)xmallocz(sizeof(stp_client) );
		if( !the) {
			break;
		}

		STX_COM_NEW_DEFAULT(stx_xio,the->stx_xio_vt,stx_xio_vt,DEFAULT_CODE,DEFAULT_CODE,DEFAULT_CODE);

		the->h_stack = stx_stack_create();
		if( !the->h_stack ) {
			break;
		}

		the->h_tcp = stx_create_io_tcp();
		if( !the->h_tcp ) {
			break;
		}

		the->sz_url = xstrdup(sz_url);
		if(!the->sz_url) {
			break;
		}

		the->sz_graph = xstrdup(sz_graph);
		if(!the->sz_graph) {
			break;
		}

		/* TCP open; */
		stx_io_tcp_make_string( (char*)sz_ip, i_port, the->sz_param ,sizeof(the->sz_param ) );

		i_err = stx_io_tcp_make_open_string(NULL,the->sz_param,the->sz_param);
		if( STX_OK != i_err )  {
			break;
		}
		
		the->h_attach = h_stream;

		stx_stack_push(the->h_stack,em_open_socket);

		i_err = STX_OK;

	}while(FALSE);

	if( STX_OK != i_err ) {
		if( the ) {
			the->stx_xio_vt.close(&the->stx_xio_vt);
		}
		return NULL;
	}

	return (stx_xio*)the;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static STX_RESULT  stx_xio_vt_xxx_set( stx_xio* h, u32 flags, STX_HANDLE h_val )
{
	return STX_ERR_NOT_SUPPORT;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static STX_RESULT stx_xio_vt_xxx_get( stx_xio* h, u32 flags, STX_HANDLE h_val )
{
	stp_op_param*	pinf;

	STX_DIRECT_THE(stp_client);

	pinf = (stp_op_param*)h_val;

	if( STX_IO_READ_HND == flags ) {
		pinf->h_obj = (void*)the->h_tcp;
		return STX_OK;
	}

	if( STX_IO_ENUM == flags ) {
		if( !pinf->i_idx ) {
			pinf->i_channel = the->i_channel;
			pinf->i_file_size = the->i_file_size;
			pinf->i_time_milisec = the->i_file_time;
			pinf->i_moddate = the->i_moddate;
			return STX_OK;
		}

		pinf->h_obj = (void*)&the->sub_cha[*pinf->i_idx];
		return STX_OK;
	}

	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT  stx_xio_vt_xxx_open
( stx_xio* h, const char* filename, s32 oflag  )
{
	STX_DIRECT_THE(stp_client);
	{
		STX_RESULT i_err;

		size_t*		h_status;
		size_t		i_status;

		if( STX_SERVICE_REQUEST_PLAY == oflag ) {

			for( ; ; ) {

				h_status = stx_stack_pop(the->h_stack);
				if( !h_status ) {
					return STX_FAIL;
				}

				i_status = *h_status;

				switch(i_status ) {

				case em_send_play:
					i_err =  stp_client_send_play(the);
					break;

				case em_wait_play_hdr:
					i_err =  stp_client_wait_play_hdr(the);
					break;

				case em_wait_play_body:
					return stp_client_wait_play_body(the);

				} // switch(the->i_status ) {

				if( i_err != STX_OK ) {
					return i_err;
				}

			} // for( ; ; ) {

		}
		else {

			for( ; ; ) {

				h_status = stx_stack_pop(the->h_stack);
				if( !h_status ) {
					return STX_FAIL;
				}

				i_status = *h_status;

				switch(i_status ) {

				case em_open_socket:
					i_err = stp_client_open_socket(the);
					break;

				case em_send_request:
					i_err =  stp_client_send_request(the);
					break;

				case em_send_graph:
					i_err =  stp_client_send_graph(the);
					break;

				case em_wait_header:
					i_err =  stp_client_wait_header(the);
					break;

				case em_wait_response:
					return stp_client_wait_response(the);

				} // switch(the->i_status ) {

				if( i_err != STX_OK ) {
					return i_err;
				}

			} // for( ; ; ) {

		}

		// never reach;
		return STX_OK;

	}
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT  stx_xio_vt_xxx_close( stx_xio* h )
{
	STX_DIRECT_THE(stp_client);

	if( the->sz_url ) {
		stx_free(the->sz_url);
		the->sz_url = NULL;
	}
	if( the->sz_graph ) {
		stx_free(the->sz_graph);
		the->sz_graph = NULL;
	}
	SAFE_CLOSEXIO(the->h_cmd);
	{
		s32 i;
		for( i = 0; i < the->i_channel; i ++ ) {
			SAFE_CLOSEXIO(the->sub_cha[i].h_data);
			if( the->sub_cha[i].major_name ) {
				stx_free(the->sub_cha[i].major_name);
				the->sub_cha[i].major_name = NULL;
			}
			if( the->sub_cha[i].sub_name ) {
				stx_free(the->sub_cha[i].sub_name);
				the->sub_cha[i].sub_name = NULL;
			}
			if( the->sub_cha[i].p_hdr ) {
				stx_free(the->sub_cha[i].p_hdr);
				the->sub_cha[i].p_hdr = NULL;
			}
		}
		the->i_channel = 0;
	}
	SAFE_XDELETE(the->h_interleave);

	SAFE_CLOSEXIO(the->h_tcp);
	SAFE_CLOSEXIO(the->h_stream);
	SAFE_XFREE(the->p_graph);

	if( the->h_stack ) {
		stx_stack_close(the->h_stack);
	}

	stx_free(the);

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
**************************************************************************/
STX_PURE STX_RESULT  stx_xio_vt_xxx_read
(stx_xio* h,void* buffer,size_t cnt,size_t* i_read)
{
	STX_DIRECT_THE(stp_client);
	{
		STX_RESULT	i_err;
		ssize_t		i_size;
		size_t		i_data;
		s32			i_chid;
		u8*			buf;

		i_size = (ssize_t)cnt;
		buf = (u8*)buffer;

		// pay attention to it;
		i_chid = (s32)*i_read;

		while( i_size > 0 ){

			size_t i_to_read = (size_t)( i_size > 32768 ? 32768 : i_size );
			stx_xio* h_xio = the->sub_cha[i_chid].h_data;

			i_data = 0;
			i_err = h_xio->read(h_xio,buf,i_to_read,&i_data);

			if( STX_OK != i_err ) {
				if( STX_IDLE == i_err || STX_WOUNLD_BLOCK == i_err ) {
					*i_read = cnt - i_size;
					if( *i_read ) {
						return STX_OK;
					}
					if( the->i_file_size > 0  && the->i_download_size == the->i_file_size ) {
						stx_log("stp client: EOF \r\n" );
						return STX_EOF;
					}
				}
				if( STX_EOF == i_err ) {
					if( the->i_file_size > 0 ){
						stx_log("stp client %"PRIdPTR"x: %"PRId64"d bytes remained \r\n", 
							the,the->i_file_size - the->i_download_size);
					}
				}
				return i_err;
			}

			i_size -= i_data;
			buf += i_data;

			the->i_download_size += i_data;

		} //while( i_size ){

		*i_read = cnt;

		if( the->i_file_size > 0 ){
			if( the->i_download_size == the->i_file_size ) {
				stx_log("stp client: EOF \r\n" );
				return STX_EOF;
			}
//			stx_log("stp client %"PRIdPTR"x: %"PRId64"d bytes remained \r\n", 
//				the,the->i_file_size - the->i_download_size);
		}
		return STX_OK;
	}

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_xio_vt_xxx_write
(stx_xio* h,const void* buffer,size_t cnt,size_t* i_write)
{
	return STX_ERR_NOT_SUPPORT;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE offset_t stx_xio_vt_xxx_seek(stx_xio* h,offset_t off,s32 whence)
{


	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE offset_t stx_xio_vt_xxx_tell(stx_xio* h)
{
	STX_DIRECT_THE(stp_client);
	{
		return (offset_t)the->i_download_size;
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE offset_t stx_xio_vt_xxx_size(stx_xio* h)
{
	STX_DIRECT_THE(stp_client);
	{
		return (offset_t)the->i_file_size;
	}

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_xio_vt_xxx_clear(stx_xio* h)
{
	return STX_ERR_NOT_SUPPORT;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_xio_vt_xxx_stop(stx_xio* h)
{
	STX_DIRECT_THE(stp_client);
	{
		STX_RESULT	i_err;
		size_t*		h_status;
		size_t		i_status;

		if( !the->h_stack ) {

			the->h_stack = stx_stack_create();
			if( !the->h_stack ) {
				return STX_FAIL;
			}

			the->h_stream->clear(the->h_stream);
			i_err = write_cmd_close_dwonload(the->h_stream);
			if( STX_OK != i_err ) {
				return i_err;
			}
			INIT_MEMBER(the->param);
			i_err = the->h_stream->get(the->h_stream,STX_IO_READ_P,&the->param);
			if( STX_OK != i_err ) {
				return i_err;
			}

			stx_stack_push(the->h_stack,em_send_close);
			//stx_log("stp_client:: goto em_send_close \r\n");
		}

		for( ; ; ) {

			h_status = stx_stack_pop(the->h_stack);
			if( !h_status ) {
				return STX_FAIL;
			}

			i_status = *h_status;

			switch(i_status ) {

				case em_send_close:
					i_err =  stp_client_send_close(the);
					break;

				case em_wait_close:
					return stp_client_wait_close(the);

				default:
					i_err = STX_FAIL;
					break;

			} // switch(the->i_status ) {

			if( i_err != STX_OK ) {
				return i_err;
			}

		} // for( ; ; ) {

		// never reach;
		return STX_OK;
	}
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_xio_vt_xxx_flush( stx_xio* h )
{
	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT stp_client_open_socket(stp_client* the)
{
	STX_RESULT i_err;

	do{
		i_err = the->h_tcp->open(the->h_tcp, the->sz_param, 
			STX_XIO_TCP_OPEN_CONNECT | STX_XIO_TCP_OPEN_ASYNC );
	}while(STX_AGAIN == i_err );

	if( STX_OK != i_err ) {
		if( STX_IDLE == i_err || STX_WOUNLD_BLOCK == i_err ) {
			stx_stack_push(the->h_stack,em_open_socket);
		}
		return i_err;
	}

	the->h_interleave = XCREATE(stx_io_int,NULL,the->h_tcp, O_RDONLY);
	if(!the->h_interleave ) {
		return STX_FAIL;
	}

	i_err = XCALL(create_channel,the->h_interleave,STP_ID_SYS_RESPONSE, &the->h_cmd);
	if( STX_OK != i_err ) {
		return i_err;
	}

	//h_data->open(h_data,"e:\\read.dump",O_CREAT);

	the->h_stream = XCREATE(stx_io_stream,NULL);
	if( !the->h_stream ) {
		return STX_FAIL;
	}

	i_err = write_cmd_download(the);
	if( STX_OK != i_err) {
		return i_err;
	}

	INIT_MEMBER(the->param);
	i_err = the->h_stream->get(the->h_stream,STX_IO_READ_P,&the->param);
	if( STX_OK != i_err ) {
		return i_err;
	}

	stx_stack_push(the->h_stack,em_send_request);
	stx_log("stp_client:: goto em_send_request \r\n");

	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT stp_client_send_request(stp_client* the)
{
	STX_RESULT i_err;

	i_err = write_out_stream(the);
	if( STX_OK != i_err ) {
		if( STX_IDLE == i_err || STX_WOUNLD_BLOCK == i_err ) {
			stx_stack_push(the->h_stack,em_send_request);
		}
		return i_err;
	}

	// next;
	{
		size_t i_size,i_attach,i_read;

		i_attach = 0;
		
		i_size = (size_t)the->i_graph_size;

		if( the->h_attach ) {
			i_attach = (size_t)the->h_attach->size(the->h_attach);
		}

		the->h_stream->clear(the->h_stream);

		INIT_MEMBER(the->param);
		the->param.i_buf_size = i_size + i_attach;
		i_err = the->h_stream->set(the->h_stream,STX_XIO_SET_BUF_SIZE,&the->param);
		if( STX_OK != i_err ) {
			return i_err;
		}

		i_err = the->h_stream->get(the->h_stream,STX_IO_READ_P,&the->param);
		if( STX_OK != i_err ) {
			return i_err;
		}

		memcpy(the->param.buf,the->p_graph,i_size);
		the->param.i_available_data = i_size;

		// free not used memory;
		stx_free(the->p_graph);
		the->p_graph = NULL;

		if( the->h_attach ) {
			the->h_attach->seek(the->h_attach,0,SEEK_SET);
			i_err = the->h_attach->read(the->h_attach,the->param.buf + i_size,i_attach,&i_read);
			if( STX_OK != i_err ) {
				return i_err;
			}
			the->param.i_available_data += i_read;
		}

		if( the->h_attach ) {
			// free not used memory;
			the->h_attach->close(the->h_attach);
			the->h_attach = NULL;
		}

		// set the ->buf, ->i_available_data

		stx_stack_push(the->h_stack,em_send_graph);
		stx_log("stp_client:: goto em_send_graph \r\n");

		return STX_OK;
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT stp_client_send_graph(stp_client* the)
{
	STX_RESULT i_err;

	i_err = write_out_stream(the);
	if( STX_OK != i_err ) {
		if( STX_IDLE == i_err || STX_WOUNLD_BLOCK == i_err ) {
			stx_stack_push(the->h_stack,em_send_graph);
		}
		return i_err;
	}

	// next;
	the->h_stream->clear(the->h_stream);

	stx_stack_push(the->h_stack,STX_PROT_HDR_SIZE);
	stx_stack_push(the->h_stack,em_wait_header);

	stx_log("stp_client:: goto em_wait_header \r\n");

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT stp_client_send_play(stp_client* the)
{
	STX_RESULT i_err;

	i_err = write_out_stream(the);
	if( STX_OK != i_err ) {
		if( STX_IDLE == i_err || STX_WOUNLD_BLOCK == i_err ) {
			stx_stack_push(the->h_stack,em_send_play);
		}
		return i_err;
	}

	// next;
	the->h_stream->clear(the->h_stream);

	stx_stack_push(the->h_stack,STX_PROT_HDR_SIZE);
	stx_stack_push(the->h_stack,em_wait_play_hdr);

	stx_log("stp_client:: goto em_wait_play \r\n");

	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT stp_client_wait_header(stp_client* the)
{
	STX_RESULT		i_err;
	size_t*			h_status;
	size_t			i_wait_size;

	h_status = stx_stack_pop(the->h_stack);
	if( !h_status ) {
		return STX_FAIL;
	}

	i_wait_size = *h_status;

	// receive hdr;
	i_err = stp_download_file(the,the->h_cmd,the->h_stream,&i_wait_size);
	if( STX_OK != i_err ) {
		if( STX_IDLE == i_err || STX_WOUNLD_BLOCK == i_err ) {
			stx_stack_push(the->h_stack,i_wait_size);
			stx_stack_push(the->h_stack,em_wait_header);
		}
		return i_err;
	}

	// next;
	{
		ByteIOContext	pb;
		u8				buf[128];

		// get the body size;
		the->h_stream->seek(the->h_stream,0,SEEK_SET);
		INIT_BYTEIO_R(pb,sizeof(buf),buf,the->h_stream);

		get_be32(&pb); // STX:
		get_be32(&pb); // flags

		i_wait_size = get_be32(&pb);
		stx_stack_push(the->h_stack,i_wait_size);
		stx_stack_push(the->h_stack,em_wait_response); // receive xini data;
		the->h_stream->clear(the->h_stream);

		stx_log("stp_client:: goto em_wait_response \r\n");

		return STX_OK;
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT stp_client_wait_response(stp_client* the)
{
	STX_RESULT		i_err;
	stx_xini*		h_xini;
	STX_HANDLE		h_key;
	s32				i_result;

	size_t*			h_status;
	size_t			i_wait_size;

	h_status = stx_stack_pop(the->h_stack);
	if( !h_status ) {
		return STX_FAIL;
	}

	i_wait_size = *h_status;

	// receive hdr;
	i_err = stp_download_file(the,the->h_cmd,the->h_stream,&i_wait_size);
	if( STX_OK != i_err ) {
		if( STX_IDLE == i_err || STX_WOUNLD_BLOCK == i_err ) {
			stx_stack_push(the->h_stack,i_wait_size);
			stx_stack_push(the->h_stack,em_wait_response);
		}
		return i_err;
	}

	do{

		h_xini = NULL;

		the->h_stream->seek(the->h_stream,0,SEEK_SET);

		// get the response content;
		i_err = stx_ini_create(NULL,the->h_stream,STX_INI_READ_ONLY|STX_INI_NO_COMMENT,0,&h_xini);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = h_xini->create_key(h_xini,NULL,g_sz_service_respond,NULL,&h_key);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = h_xini->read_int32(h_xini,h_key,&i_result);
		if( STX_OK != i_err ) {
			break;
		}
		if( STX_SERVICE_RESPOND_OK != i_result) {
			i_err = STX_EOF;
			break;
		}

		i_err = h_xini->create_key(h_xini,NULL,g_sz_file_size,"0",&h_key);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = h_xini->read_int64(h_xini,h_key,&the->i_file_size);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = h_xini->create_key(h_xini,NULL,g_sz_file_time,"0",&h_key);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = h_xini->read_int64(h_xini,h_key,&the->i_file_time);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = h_xini->create_key(h_xini,NULL,g_sz_moddate,"0",&h_key);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = h_xini->read_int64(h_xini,h_key,&the->i_moddate);
		if( STX_OK != i_err ) {
			break;
		}

		// channel num, and each channel id;
		i_err = h_xini->create_key(h_xini,NULL,g_sz_channel,NULL,&h_key);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = h_xini->read_int32(h_xini,h_key,&the->i_channel);
		if( STX_OK != i_err ) {
			break;
		}

		//
		stx_log("stp client get channel num = %d\r\n",the->i_channel);

		if( !the->i_channel || the->i_channel > 16 ) {
			i_err = STX_ERR_INVALID_PARAM;
			break;
		}

		{
			s32				i;
			STX_HANDLE		h_cha,h_type;
			char			sz_key[256];

			size_t			i_write;
			char*			sz_val;
			s32				i_hdr_size;
			stx_xio*		h_stream = NULL;
			u8*				p_hdr = NULL;


			h_stream = XCREATE(stx_io_stream,NULL);
			if( !h_stream ) {
				i_err = STX_FAIL;
				break;
			}

			for( i = 0; i < the->i_channel; i ++ ) {

				stp_subchannel* h_sub = &the->sub_cha[i];

				h_sub->i_idx = i;

				stx_sprintf(sz_key,sizeof(sz_key),"%s-%d",g_sz_channel,i);
				i_err = h_xini->create_key(h_xini,h_key,sz_key,NULL,&h_cha);
				if( STX_OK != i_err ) {
					break;
				}
				i_err = h_xini->read_int32(h_xini,h_cha,&h_sub->i_chid);
				if( STX_OK != i_err ) {
					break;
				}

				i_err = the->h_interleave->create_channel(the->h_interleave,h_sub->i_chid, &h_sub->h_data);
				if( STX_OK != i_err ) {
					break;
				}

				stx_log("stp client, create sub channel id = %d\r\n",h_sub->i_chid);

				// read media type info, file stream, video or audio;
				i_err = h_xini->create_key(h_xini,h_cha,g_szStreamX_MajorDataType,NULL,&h_type);
				if( STX_OK != i_err ) {
					break;
				}
				i_err = h_xini->read_binary(h_xini,h_type,&i_hdr_size,NULL);
				if( STX_OK != i_err ) {
					break;
				}
				i_err = h_xini->read_binary(h_xini,h_type,&i_hdr_size,h_sub->major_type.data);
				if( STX_OK != i_err ) {
					break;
				}
				i_err = h_xini->create_key(h_xini,h_cha,g_szStreamX_MajorDataTypeName,NULL,&h_type);
				if( STX_OK != i_err ) {
					break;
				}
				i_err = h_xini->read_string(h_xini,h_type,&sz_val);
				if( STX_OK != i_err ) {
					break;
				}
				h_sub->major_name = xstrdup(sz_val);
				if( !h_sub->major_name ) {
					i_err = STX_FAIL;
					break;
				}

				i_err = h_xini->create_key(h_xini,h_cha,g_szStreamX_SubDataType,NULL,&h_type);
				if( STX_OK != i_err ) {
					break;
				}
				i_err = h_xini->read_binary(h_xini,h_type,&i_hdr_size,NULL);
				if( STX_OK != i_err ) {
					break;
				}
				i_err = h_xini->read_binary(h_xini,h_type,&i_hdr_size,h_sub->sub_type.data);
				if( STX_OK != i_err ) {
					break;
				}
				i_err = h_xini->create_key(h_xini,h_cha,g_szStreamX_SubDataTypeName,NULL,&h_type);
				if( STX_OK != i_err ) {
					break;
				}
				i_err = h_xini->read_string(h_xini,h_type,&sz_val);
				if( STX_OK != i_err ) {
					break;
				}
				h_sub->sub_name = xstrdup(sz_val);
				if( !h_sub->sub_name ) {
					i_err = STX_FAIL;
					break;
				}

				//		
				i_err = h_xini->create_key(h_xini,h_cha,g_szStreamX_header,NULL,&h_type);
				if( STX_OK != i_err ) {
					i_err = STX_OK;
					continue; // file type do not have header;
				}
				i_err = h_xini->read_base64(h_xini,h_type,&i_hdr_size,NULL);
				if( STX_OK != i_err ) {
					break;
				}
				p_hdr = (u8*)xmallocz(i_hdr_size);
				if(!p_hdr ) {
					i_err = STX_FAIL;
					break;
				}
				i_err = h_xini->read_base64(h_xini,h_type,&i_hdr_size,p_hdr);
				if( STX_OK != i_err ) {
					break;
				}

				h_stream->clear(h_stream);

				i_err = h_stream->write(h_stream,p_hdr,i_hdr_size,&i_write);
				if( STX_OK != i_err ) {
					break;
				}

				stx_free(p_hdr);
				p_hdr = NULL;

				if( IS_EQUAL_GID(h_sub->major_type,MEDIATYPE_Video)) {
					i_err = decode_vd2(NULL,&h_sub->i_hdr_size,h_stream);
					if( STX_OK != i_err ) {
						break;
					}
					h_sub->p_hdr = (u8*)xmallocz(h_sub->i_hdr_size);
					if(!h_sub->p_hdr ) {
						i_err = STX_FAIL;
						break;
					}
					i_err = decode_vd2((STX_VIDEOINFOHEADER2*)h_sub->p_hdr,&h_sub->i_hdr_size,h_stream);
					if( STX_OK != i_err ) {
						break;
					}
				}
				else if( IS_EQUAL_GID(h_sub->major_type,MEDIATYPE_Audio) ) {
					i_err = decode_wex(NULL,&h_sub->i_hdr_size,h_stream);
					if( STX_OK != i_err ) {
						break;
					}
					h_sub->p_hdr = (u8*)xmallocz(h_sub->i_hdr_size);
					if(!h_sub->p_hdr ) {
						i_err = STX_FAIL;
						break;
					}
					i_err = decode_wex((STX_WAVEFORMATEXTENSIBLE*)h_sub->p_hdr,&h_sub->i_hdr_size,h_stream);
					if( STX_OK != i_err ) {
						break;
					}
				}
				else {
					i_err = STX_FAIL;
					break;
				}

			} // for( i = 0; i < the->i_output; i ++ ) {

			if( p_hdr ) {
				stx_free(p_hdr);
			}
			SAFE_CLOSEXIO(h_stream);

			if( STX_OK != i_err ) {
				break;
			}

		} // block;

		i_err = STX_OK;

	}while(FALSE);

	SAFE_CLOSEXIO(h_xini);

	if( STX_OK != i_err ) {
		return i_err;
	}

	if( the->i_file_size <= 0 ) {
		the->i_file_size = INT_MAX; // 2GB;
	}

	i_err = write_cmd_play(the);
	if( STX_OK != i_err) {
		return i_err;
	}

	INIT_MEMBER(the->param);
	i_err = the->h_stream->get(the->h_stream,STX_IO_READ_P,&the->param);
	if( STX_OK != i_err ) {
		return i_err;
	}

	{
		char sz_data[32];
		binary_to_string(12,the->param.buf,sz_data);
		stx_log("stp_client:send play cmd:%s\r\n",sz_data);
	}

	stx_stack_push(the->h_stack,em_send_play);

	stx_log("stp_client:: open success, goto em_send_play \r\n");

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT stp_client_wait_play_hdr(stp_client* the)
{
	STX_RESULT		i_err;
	size_t*			h_status;
	size_t			i_wait_size;

	h_status = stx_stack_pop(the->h_stack);
	if( !h_status ) {
		return STX_FAIL;
	}

	i_wait_size = *h_status;

	// receive hdr;
	i_err = stp_download_file(the,the->h_cmd,the->h_stream,&i_wait_size);
	if( STX_OK != i_err ) {
		if( STX_IDLE == i_err || STX_WOUNLD_BLOCK == i_err ) {
			stx_stack_push(the->h_stack,i_wait_size);
			stx_stack_push(the->h_stack,em_wait_play_hdr);
		}
		return i_err;
	}

	// next;
	{
		ByteIOContext	pb;
		u8				buf[128];

		// get the body size;
		the->h_stream->seek(the->h_stream,0,SEEK_SET);
		INIT_BYTEIO_R(pb,sizeof(buf),buf,the->h_stream);

		get_be32(&pb); // STX:
		get_be32(&pb); // flags

		i_wait_size = get_be32(&pb);
		stx_stack_push(the->h_stack,i_wait_size);
		stx_stack_push(the->h_stack,em_wait_play_body); // receive xini data;
		the->h_stream->clear(the->h_stream);

		stx_log("stp_client:: goto em_wait_response \r\n");

		return STX_OK;
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT stp_client_wait_play_body(stp_client* the)
{
	STX_RESULT		i_err;
	stx_xini*		h_xini;
	STX_HANDLE		h_key;
	s32				i_result;

	size_t*			h_status;
	size_t			i_wait_size;

	h_status = stx_stack_pop(the->h_stack);
	if( !h_status ) {
		return STX_FAIL;
	}

	i_wait_size = *h_status;


	// receive hdr;
	i_err = stp_download_file(the,the->h_cmd,the->h_stream,&i_wait_size);
	if( STX_OK != i_err ) {
		if( STX_IDLE == i_err || STX_WOUNLD_BLOCK == i_err ) {
			stx_stack_push(the->h_stack,i_wait_size);
			stx_stack_push(the->h_stack,em_wait_play_body);
		}
		return i_err;
	}

	do{

		h_xini = NULL;

		the->h_stream->seek(the->h_stream,0,SEEK_SET);

		// get the response content;
		i_err = stx_ini_create(NULL,the->h_stream,STX_INI_READ_ONLY|STX_INI_NO_COMMENT,0,&h_xini);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = h_xini->create_key(h_xini,NULL,g_sz_service_respond,NULL,&h_key);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = h_xini->read_int32(h_xini,h_key,&i_result);
		if( STX_OK != i_err ) {
			break;
		}
		if( STX_SERVICE_RESPOND_OK != i_result) {
			i_err = STX_EOF;
			break;
		}

		i_err = STX_OK;

	}while(FALSE);

	SAFE_CLOSEXIO(h_xini);

	if( STX_OK != i_err ) {
		return i_err;
	}

	if( the->i_file_size <= 0 ) {
		the->i_file_size = INT_MAX; // 2GB;
	}

	//stx_stack_push(the->h_stack,(size_t)the->i_file_size);
	//stx_stack_push(the->h_stack,em_receive_file);
	stx_stack_close(the->h_stack);
	the->h_stack = NULL;

	stx_log("stp_client:: play success, close stack \r\n");

	return STX_OK;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT stp_client_send_close(stp_client* the)
{
	STX_RESULT i_err;

	i_err = write_out_stream(the);
	if( STX_OK != i_err ) {
		if( STX_IDLE == i_err || STX_WOUNLD_BLOCK == i_err ) {
			stx_stack_push(the->h_stack,em_send_close);
		}
		return i_err;
	}

	stx_stack_push(the->h_stack,em_wait_close);
	//stx_log("stp_client:: goto em_wait_close \r\n");

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT stp_client_wait_close(stp_client* the)
{
	STX_RESULT	i_err;
	size_t		i_read;
	char		buf[2048];

	for( ; ; ) {

		do{
			i_err = the->h_tcp->read(the->h_tcp,buf,sizeof(buf),&i_read);
		}while(i_err == STX_AGAIN);

		if( STX_IDLE == i_err || STX_WOUNLD_BLOCK == i_err ) {
			stx_stack_push(the->h_stack,em_wait_close);
			return STX_WOUNLD_BLOCK;
		}

		if( STX_EOF == i_err || i_err < 0 ) {
			return STX_OK;
		}

	} // for( ; ; ) {

	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static STX_RESULT write_cmd_close_dwonload( stx_xio* h_stream )
{

	STX_RESULT		i_err;
	stx_xini*		h_xini;
	stx_xio*		h_cmd_stream;
	STX_HANDLE		h_key;
	ByteIOContext	pb;
	char            buf[STX_DEFAULT_PATH];

	h_xini = NULL;
	h_cmd_stream = NULL;


	do{

		stx_io_op_param param;
		size_t i_write;

		i_err = STX_FAIL;

		h_cmd_stream = XCREATE(stx_io_stream,NULL);
		if( !h_cmd_stream ) {
			break;
		}

		i_err = stx_ini_create(NULL,h_cmd_stream,STX_INI_CREATE_NEW|STX_INI_NO_COMMENT,0,&h_xini);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = h_xini->create_key(h_xini,NULL,g_sz_service_request,NULL,&h_key);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = h_xini->write_int32(h_xini,h_key,STX_SERVICE_REQUEST_CLOSE);
		if( STX_OK != i_err ) {
			break;
		}

		// close it, save xini body to h_cmd_stream;
		h_xini->close(h_xini);
		h_xini = NULL;

		// get xini body data pointer and length;
		INIT_MEMBER(param);
		i_err = h_cmd_stream->get(h_cmd_stream,STX_IO_READ_P,&param);
		if( STX_OK != i_err ) {
			break;
		}

		h_stream->clear(h_stream);
	
		// write header;
		INIT_BYTEIO_W(pb,STX_DEFAULT_PATH,(uint8*)buf,h_stream);
		put_tag(&pb,g_sz_prot_stx);
		put_be32(&pb,STX_PROTOCOL_XINI);
		put_be32(&pb,(u32)param.i_available_data);

		// write xini body;
		i_err = xio_fwrite(&pb,(const u8*)param.buf,(size_t)param.i_available_data,&i_write);
		if( STX_OK != i_err ) {
			break;
		}

		// flush out data;
		xio_flush(&pb);

		i_err = STX_OK;

	}while(FALSE);

	if( h_xini ) {
		h_xini->close(h_xini);
	}

	if( h_cmd_stream ) {
		h_cmd_stream->close(h_cmd_stream);
	}

	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT write_cmd_play(stp_client *the )
{
	STX_RESULT		i_err;
	stx_xini*		h_xini;
	stx_xio*		h_cmd_stream;
	STX_HANDLE		h_key;
	ByteIOContext	pb;
	char            buf[STX_DEFAULT_PATH];

	h_xini = NULL;
	h_cmd_stream = NULL;


	do{
		stx_io_op_param param;
		size_t			i_write;

		i_err = STX_FAIL;

		h_cmd_stream = XCREATE(stx_io_stream,NULL);
		if( !h_cmd_stream ) {
			break;
		}

		i_err = stx_ini_create(NULL,h_cmd_stream,STX_INI_CREATE_NEW|STX_INI_NO_COMMENT,0,&h_xini);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = h_xini->create_key(h_xini,NULL,g_sz_service_request,NULL,&h_key);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = h_xini->write_int32(h_xini,h_key,STX_SERVICE_REQUEST_PLAY);
		if( STX_OK != i_err ) {
			break;
		}

		// close it, save xini body to h_cmd_stream;
		h_xini->close(h_xini);
		h_xini = NULL;

		// get xini body data pointer and length;
		INIT_MEMBER(param);
		i_err = h_cmd_stream->get(h_cmd_stream,STX_IO_READ_P,&param);
		if( STX_OK != i_err ) {
			break;
		}

		the->h_stream->clear(the->h_stream);

		// write header;
		INIT_BYTEIO_W(pb,STX_DEFAULT_PATH,(uint8*)buf,the->h_stream);
		put_tag(&pb,g_sz_prot_stx);
		put_be32(&pb,STX_PROTOCOL_XINI);
		put_be32(&pb,(u32)param.i_available_data);

		// write xini body;
		i_err = xio_fwrite(&pb,(const u8*)param.buf,(size_t)param.i_available_data,&i_write);
		if( STX_OK != i_err ) {
			break;
		}

		// flush out data;
		xio_flush(&pb);

		i_err = STX_OK;

	}while(FALSE);

	if( h_xini ) {
		h_xini->close(h_xini);
	}

	if( h_cmd_stream ) {
		h_cmd_stream->close(h_cmd_stream);
	}

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT write_cmd_download( stp_client *the)
{

	STX_RESULT		i_err;
	stx_xini*		h_xini;
	stx_xio*		h_cmd_stream;
	stx_xio*		h_graph;
	STX_HANDLE		h_key,h_size;
	ByteIOContext	pb;
	char            buf[STX_DEFAULT_PATH];

	h_xini = NULL;
	h_cmd_stream = NULL;


	do{
		stx_io_op_param param;
		size_t			i_read,i_write;

		i_err = STX_FAIL;
		h_graph = NULL;

		h_cmd_stream = XCREATE(stx_io_stream,NULL);
		if( !h_cmd_stream ) {
			break;
		}

		i_err = stx_ini_create(NULL,h_cmd_stream,STX_INI_CREATE_NEW|STX_INI_NO_COMMENT,0,&h_xini);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = h_xini->create_key(h_xini,NULL,g_sz_service_request,NULL,&h_key);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = h_xini->write_int32(h_xini,h_key,STX_SERVICE_REQUEST_DOWNLOAD);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = h_xini->create_key(h_xini,NULL,g_sz_URL,NULL,&h_key);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = h_xini->write_base64(h_xini,h_key,(s32)strlen(the->sz_url) + 1, (u8*)the->sz_url);
		if( STX_OK != i_err ) {
			break;
		}

		h_graph = stx_create_io_file();
		if(!h_graph ) {
			i_err = STX_FAIL;
			break;
		}
		i_err = h_graph->open(h_graph,the->sz_graph,O_RDONLY);
		if( STX_OK != i_err ) {
			break;
		}
		the->i_graph_size = (u32)h_graph->size(h_graph);
		the->p_graph = (u8*)xmallocz(the->i_graph_size);
		if( !the->p_graph ) {
			i_err = STX_FAIL;
			break;
		}
		h_graph->seek(h_graph,0,SEEK_SET);
		h_graph->read(h_graph,the->p_graph,the->i_graph_size,&i_read);

		i_err = h_xini->create_key(h_xini, NULL, g_sz_GRAPH, the->sz_graph, &h_key);
		if(STX_OK != i_err){
			break;
		}
		i_err = h_xini->create_key(h_xini, h_key, g_sz_file_size, NULL, &h_size);
		if(STX_OK != i_err){
			break;
		}
		i_err = h_xini->write_int32(h_xini,h_size,(s32)the->i_graph_size);
		if( STX_OK != i_err ) {
			break;
		}

		// close it, save xini body to h_cmd_stream;
		h_xini->close(h_xini);
		h_xini = NULL;

		// get xini body data pointer and length;
		INIT_MEMBER(param);
		i_err = h_cmd_stream->get(h_cmd_stream,STX_IO_READ_P,&param);
		if( STX_OK != i_err ) {
			break;
		}

		the->h_stream->clear(the->h_stream);

		// write header;
		INIT_BYTEIO_W(pb,STX_DEFAULT_PATH,(uint8*)buf,the->h_stream);
		put_tag(&pb,g_sz_prot_stx);
		put_be32(&pb,STX_PROTOCOL_XINI);
		put_be32(&pb,(u32)param.i_available_data);

		// write xini body;
		i_err = xio_fwrite(&pb,(const u8*)param.buf,(size_t)param.i_available_data,&i_write);
		if( STX_OK != i_err ) {
			break;
		}

		// flush out data;
		xio_flush(&pb);

		i_err = STX_OK;

	}while(FALSE);

	if( h_xini ) {
		h_xini->close(h_xini);
	}

	if( h_cmd_stream ) {
		h_cmd_stream->close(h_cmd_stream);
	}

	SAFE_CLOSEXIO(h_graph);

	return i_err;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT write_out_stream(stp_client* the)
{
	STX_RESULT		i_err;
	size_t			i_write;
	size_t			i_data;

	while( the->param.i_available_data ){

		i_data = (size_t)( the->param.i_available_data > 32*1024 ? 32*1024: the->param.i_available_data );

		do{
			i_err = the->h_tcp->write(the->h_tcp,the->param.buf,i_data,&i_write);
		}while(STX_AGAIN == i_err );
		if( STX_OK != i_err ) {
			return i_err;
		}

		the->param.buf += i_write;
		the->param.i_available_data -= i_write;

	} //while( param.i_available_data ){

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT stp_download_file
(stp_client* the, stx_xio* h_data, stx_xio* h_file, size_t* p_size )
{
	STX_RESULT	i_err;
	size_t		i_size;
	size_t		i_write;
	size_t		i_data;
	u8			buf[2048];

	i_size = *p_size;

	while( i_size > 0 ){

		size_t i_read = (size_t)( i_size > 2048 ? 2048 : i_size );

		*p_size = i_size;

		i_data = 0;
		i_err = h_data->read(h_data,buf,i_read,&i_data);

		if( STX_OK != i_err ) {
			return i_err;
		}

		if( h_file ) {
			i_write = 0;
			i_err = h_file->write(h_file,buf,i_data,&i_write);
			if( i_err < 0 ) {
				return i_err;
			}
		}

		i_size -= i_data;

		if( i_data < i_read ) {
			*p_size = i_size;
			return STX_WOUNLD_BLOCK;
		}

	} //while( i_size ){

	return STX_OK;
}

