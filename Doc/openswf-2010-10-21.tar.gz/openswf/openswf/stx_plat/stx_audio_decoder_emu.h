


#ifndef __STX_AUDIO_DECODER_EMU_H__
#define __STX_AUDIO_DECODER_EMU_H__

/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/


#include "base_class.h"

#include "stx_gid_def.h"


#if defined( __cplusplus )
extern "C" {
#endif






#if defined( __cplusplus )
}
#endif


#endif /* __STX_AUDIO_DECODER_EMU_H__ */ 