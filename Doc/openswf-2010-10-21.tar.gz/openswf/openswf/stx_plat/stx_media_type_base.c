
/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#include "stdio.h"
#include "stdlib.h"
#include "fcntl.h"
#include "malloc.h"
#include "memory.h"
#include "string.h"

#include "stx_mem.h"
#include "stx_debug.h"
#include "stx_module_reg.h"
#include "stx_media_type_base.h"
#include "stx_gid_def.h"

#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif

struct base_media_type {
	stx_media_type		mtyp;
	sint32				i_ref;
	stx_gid				gid_major_type;
	stx_gid				gid_sub_type;
	void*				header;
	sint32				i_hdr_len;
	const char*			sz_name;
	const char*			sz_subname;
};



static	STX_RESULT		query_interf( STX_HANDLE h, stx_gid gid, STX_HANDLE* p_interf);
static	sint32 			add_ref( STX_HANDLE h );
static	sint32 			release( STX_HANDLE h );

static	void			set_type( STX_HANDLE h, stx_gid gid_type );
static	stx_gid			get_type( STX_HANDLE h);
static	void 			set_subtype( STX_HANDLE h, stx_gid gid_sub_type );
static	stx_gid			get_subtype( STX_HANDLE h);
static	STX_RESULT		get_header( STX_HANDLE h , void** pp_hdr, sint32* i_len );
static	STX_RESULT		set_header( STX_HANDLE h, void* p_hdr, sint32 i_len );

STX_PURE void			set_type_name( STX_HANDLE h, const char* sz_name );
STX_PURE const char*	get_type_name( STX_HANDLE h);
STX_PURE void			set_subtype_name( STX_HANDLE h, const char* sz_name );
STX_PURE const char*	get_subtype_name( STX_HANDLE h);


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
#ifdef __USE_STX_DEBUG__
	stx_media_type* create_base_media_type
		(THEE hinst,const char* file,s32 line,stx_media_type* p_mtyp)
#else
	stx_media_type* create_base_media_type(THEE hinst,stx_media_type* p_mtyp)
#endif
{
	STX_RESULT				i_err;
	base_media_type*		the;
	sint32				    i_len;

	i_err = STX_FAIL;
	the = STX_NULL;

	for( ; ; ) {

#ifdef __USE_STX_DEBUG__
		the = (base_media_type*)debug_mallocz(sizeof( base_media_type),file,line);
#else
		the = (base_media_type*)xmallocz(sizeof( base_media_type));
#endif
		if( !the ) {
			break;
		}

		the->i_ref = 1;

		the->mtyp.query_interf	= query_interf;
		the->mtyp.add_ref			= add_ref;
		the->mtyp.release			= release;

		the->mtyp.get_header	= get_header;
		the->mtyp.get_subtype = get_subtype;
		the->mtyp.get_type	= get_type;
		the->mtyp.set_header	= set_header;
		the->mtyp.set_subtype = set_subtype;
		the->mtyp.set_type	= set_type;
		the->mtyp.set_type_name	= set_type_name;
		the->mtyp.set_subtype_name	= set_subtype_name;
		the->mtyp.get_type_name	= get_type_name;
		the->mtyp.get_subtype_name	= get_subtype_name;

		if( p_mtyp ) {

			void* header;

			set_type( the, p_mtyp->get_type(p_mtyp) );
			set_subtype( the, p_mtyp->get_subtype(p_mtyp) ) ;
			set_type_name( the, p_mtyp->get_type_name(p_mtyp) );
			set_subtype_name( the, p_mtyp->get_subtype_name(p_mtyp) ) ;

			i_len = 0;

			if( STX_OK == p_mtyp->get_header( p_mtyp, &header, &i_len ) ) {
				if( i_len > 0 ) {
					if( STX_OK != set_header(the,header,i_len) ) {
						break;
					}
				}/*if( i_len > 0 ) {*/
			} /*if( STX_OK == p_mtyp->get_header( p_mtyp, STX_NULL, &i_len ) ) {*/
		}/* if( p_mtyp ) { */

		i_err = STX_OK;

		break;
	}

	if( STX_OK != i_err ) {

		SAFE_XDELETE(the);
		return STX_NULL;
	}

	return (stx_media_type*)the;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE void set_type_name( STX_HANDLE h, const char* sz_name )
{
	STX_DIRECT_THE(base_media_type);
	the->sz_name = sz_name;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE const char* get_type_name( STX_HANDLE h)
{
	STX_DIRECT_THE(base_media_type);

	return the->sz_name;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE void set_subtype_name( STX_HANDLE h, const char* sz_name )
{
	STX_DIRECT_THE(base_media_type);
	the->sz_subname = sz_name;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE const char* get_subtype_name( STX_HANDLE h)
{
	STX_DIRECT_THE(base_media_type);

	return the->sz_subname;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT query_interf( STX_HANDLE h, stx_gid gid, STX_HANDLE* p_interf)
{
	STX_DIRECT_THE(base_media_type);

	if( IS_EQUAL_GID( gid.guid , STX_IID_MediaType ) ) {

		the->i_ref ++;

		*p_interf = the;

		return STX_OK;
	}

	return STX_ERR_INVALID_PARAM;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE sint32 add_ref( STX_HANDLE h )
{
	STX_DIRECT_THE(base_media_type);

	the->i_ref ++;

	return the->i_ref;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE sint32 release( STX_HANDLE h )
{
	STX_DIRECT_THE(base_media_type);

	the->i_ref --;

	if( the->i_ref > 0 ) {

		return the->i_ref;
	}

	if( the->header ) {

		stx_free( the->header );

		the->header = STX_NULL;
	}

	stx_free( the );

	return 0;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE void set_type( STX_HANDLE h, stx_gid gid_type )
{
	STX_DIRECT_THE(base_media_type);

	the->gid_major_type = gid_type;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE stx_gid get_type( STX_HANDLE h)
{
	STX_DIRECT_THE(base_media_type);

	return the->gid_major_type;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE void set_subtype( STX_HANDLE h, stx_gid gid_sub_type )
{
	STX_DIRECT_THE(base_media_type);

	the->gid_sub_type = gid_sub_type;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE stx_gid get_subtype( STX_HANDLE h)
{
	STX_DIRECT_THE(base_media_type);

	return the->gid_sub_type;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT get_header( STX_HANDLE h , void** pp_hdr, sint32* i_len )
{
	STX_DIRECT_THE(base_media_type);

	if( the->header && the->i_hdr_len ) {

		if( pp_hdr ) {
			*i_len = the->i_hdr_len;
			*pp_hdr =  the->header;
		}
		else {
			*i_len = the->i_hdr_len;
		}

		return STX_OK;
	}

	return STX_ERR_OBJ_UNINIT;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT set_header( STX_HANDLE h, void* p_hdr, sint32 i_len )
{
	STX_DIRECT_THE(base_media_type);

	if( the->header ) {
		stx_free( the->header );
		the->header = STX_NULL;
	}

	if( !p_hdr ) {
		return STX_OK;
	}
	
	if( i_len <= 0 ) {
		return STX_ERR_INVALID_PARAM;
	}

	the->header = xmallocz( i_len);
	if( !the->header ) {
		return STX_FAIL;
	}

	memcpy( the->header, p_hdr, i_len );

    the->i_hdr_len = i_len;       

	return STX_OK;
}


