/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#include "stdio.h"
#include "stdlib.h"
#include "fcntl.h"
#include "malloc.h"
#include "memory.h"
#include "string.h"

#include "stx_ini.h"
#include "stx_mem.h"
#include "stx_os.h"
#include "stx_io_file.h"
#include "stx_io_stream.h"
#include "stx_debug.h"
#include "stx_mutex.h"

#include "stx_avb.h"

#include "base_class.h"


// {4845655A-00CC-4d4a-8A52-A07013935F00}
//DEFINE_XGUID( gidLxAvbHdr,
//0x4845655a, 0xcc, 0x4d4a, 0x8a, 0x52, 0xa0, 0x70, 0x13, 0x93, 0x5f, 0x0 );

// {820DE6D6-BB4A-40ba-ACD6-E49F6EF4B356}
DEFINE_XGUID( gidLxAvbStmLst , 
0x820de6d6, 0xbb4a, 0x40ba, 0xac, 0xd6, 0xe4, 0x9f, 0x6e, 0xf4, 0xb3, 0x56 );

// {5BD4DBF8-C915-4975-B6EB-6FC4C2EBAF02}
DEFINE_XGUID( gidLxAvbVidHdr , 
0x5bd4dbf8, 0xc915, 0x4975, 0xb6, 0xeb, 0x6f, 0xc4, 0xc2, 0xeb, 0xaf, 0x2 );

// {ED6BC208-15CE-4ee9-AC4B-8A21D48C6325}
DEFINE_XGUID( gidLxAvbAudHdr , 
0xed6bc208, 0x15ce, 0x4ee9, 0xac, 0x4b, 0x8a, 0x21, 0xd4, 0x8c, 0x63, 0x25 );

// {E914B749-4A4E-4d60-9537-FE59A3D01427}
DEFINE_XGUID( gidLxAvbStmFrm , 
0xe914b749, 0x4a4e, 0x4d60, 0x95, 0x37, 0xfe, 0x59, 0xa3, 0xd0, 0x14, 0x27 );

// {CD34CF33-FAAC-4e37-9A6F-107B934A335F}
DEFINE_XGUID( gidLxAvbVidFrm ,
0xcd34cf33, 0xfaac, 0x4e37, 0x9a, 0x6f, 0x10, 0x7b, 0x93, 0x4a, 0x33, 0x5f );

// {7BA7CD4C-AC8D-4218-BF17-B09E6FC6FEDA}
DEFINE_XGUID( gidLxAvbAudFrm,
0x7ba7cd4c, 0xac8d, 0x4218, 0xbf, 0x17, 0xb0, 0x9e, 0x6f, 0xc6, 0xfe, 0xda );


// {DDBD783B-531F-4baa-892C-98807C5E0802}
DEFINE_XGUID( gidLxAvbIdx,
0xddbd783b, 0x531f, 0x4baa, 0x89, 0x2c, 0x98, 0x80, 0x7c, 0x5e, 0x8, 0x2 );

// {26DEC693-6F6F-4f5c-AB11-30F4D8958DE7}
DEFINE_XGUID( gidLxAvbNameIdx, 
0x26dec693, 0x6f6f, 0x4f5c, 0xab, 0x11, 0x30, 0xf4, 0xd8, 0x95, 0x8d, 0xe7 );

// {27E2D904-36FF-493e-BDA4-878508D4B314}
DEFINE_XGUID( gidLxAvbPci, 
0x27e2d904, 0x36ff, 0x493e,0xbd, 0xa4, 0x87, 0x85, 0x8, 0xd4, 0xb3, 0x14 );

// {66834595-3D54-4723-974C-D9A527A85101}
DEFINE_XGUID( gidLxAvbSub, 
0x66834595, 0x3d54, 0x4723,0x97, 0x4c, 0xd9, 0xa5, 0x27, 0xa8, 0x51, 0x1 );

// {F191D6B7-71C8-4dc6-AE35-239162C8E6F5}
DEFINE_XGUID( gidLxAvbFrm,
0xf191d6b7, 0x71c8, 0x4dc6, 0xae, 0x35, 0x23, 0x91, 0x62, 0xc8, 0xe6, 0xf5 );


// {972F1417-2C0E-4a9c-ABC9-CF102D51ADB6}
DEFINE_XGUID( gidLxAvbContainer, 
0x972f1417, 0x2c0e, 0x4a9c, 0xab, 0xc9, 0xcf, 0x10, 0x2d, 0x51, 0xad, 0xb6 );

// {05FCD232-10B4-45f2-81BD-371748D294B4}
DEFINE_XGUID( gidLxAvbMpeg2_Ps ,
0x5fcd232, 0x10b4, 0x45f2, 0x81, 0xbd, 0x37, 0x17, 0x48, 0xd2, 0x94, 0xb4 );

// {523FA7B4-BA76-467c-A753-7B39111BEF6E}
DEFINE_XGUID( gidLxAvbMpeg2_Ts ,
0x523fa7b4, 0xba76, 0x467c, 0xa7, 0x53, 0x7b, 0x39, 0x11, 0x1b, 0xef, 0x6e );

// {C06200FE-55EA-4acd-801D-BE20A6F3C6E7}
DEFINE_XGUID( gidLxAvbWmv ,
0xc06200fe, 0x55ea, 0x4acd, 0x80, 0x1d, 0xbe, 0x20, 0xa6, 0xf3, 0xc6, 0xe7 );

// {366FB285-A7C9-4ad4-968B-66AA782FE725}
DEFINE_XGUID( gidLxAvbAvi ,
0x366fb285, 0xa7c9, 0x4ad4, 0x96, 0x8b, 0x66, 0xaa, 0x78, 0x2f, 0xe7, 0x25 );

// {62F06FE7-EB7A-4d54-AA9F-089326B4E62B}
DEFINE_XGUID( gidLxAvbInterleave ,
0x62f06fe7, 0xeb7a, 0x4d54, 0xaa, 0x9f, 0x8, 0x93, 0x26, 0xb4, 0xe6, 0x2b );



STX_INTERF(LxAvbEnc);
STX_INTERF(LxAvbDec);




struct LxAvbEnc{
	stx_xio*			m_hAvbFile;
	stx_xio*			m_hIdxFile;
	stx_xio*			m_hSegNameIdxFile;
	char*				m_szIdx;
	char*				m_szSegNameIdx;
	LxAvbHdr*			m_pHdr;
	LxAvbAtom**			m_ppHdrLst;
	LxAvbAtom			m_FrmAtom;
	DECL_TRACE
};


STX_PRIVATE	STX_RESULT	AvbWriteStartEx(LxAvbEnc* the, const char* szFileName);
STX_PRIVATE	STX_RESULT	AvbWriteEndEx(LxAvbEnc* the);
STX_PRIVATE	void		AvbWriteHdr(LxAvbEnc* the);
STX_PRIVATE	void		AvbWriteStreamList(LxAvbEnc* the);
STX_PRIVATE	STX_RESULT	AvbMoveIdxFile(LxAvbEnc* the);
STX_PRIVATE	STX_RESULT	AvbWriteStreamData
	(LxAvbEnc* the,	s32 nStmNum,u8* pData,s32 nDataLen,s64 qwTime,b32 bFirstBlock );



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API_IMP STX_RESULT 
AvbEncOpen(STX_HANDLE* pHnd,const char* szName, u32 dwFlags)
{
	STX_RESULT	i_err;
	LxAvbEnc*	the;

	*pHnd = NULL;

	the = (LxAvbEnc*)smart_mallocz(sizeof(LxAvbEnc),"stx_avb.c::AvbEncOpen::the");
	if( !the ) {
		return STX_FAIL;
	}

	do{

		i_err = STX_FAIL;

		the->m_hAvbFile = stx_create_io_file();
		if( !the->m_hAvbFile ) {
			break;
		}

		i_err = the->m_hAvbFile->open(the->m_hAvbFile,szName,O_CREAT);
		if( STX_OK != i_err ) {
			break;
		}

		STX_MAKE_TRACE
		the->m_pHdr = (LxAvbHdr*)smart_mallocz(LXAVB_HDR_SIZE(),STX_MAP_TRACE);
		if( !the->m_pHdr ) {
			i_err = STX_FAIL;
			break;
		}

		the->m_pHdr->dwAvbTag = LXAVB_HDR_TAG;
		the->m_pHdr->dwAvbVer = LXAVB_VERSION;
		the->m_pHdr->dwFlags  = dwFlags;
		the->m_pHdr->dwHdrSize = LXAVB_HDR_SIZE();
		the->m_pHdr->qwFrmPos = LXAVB_ATOM_HDR_SIZE() + LXAVB_HDR_SIZE();

		the->m_FrmAtom.gid = gidLxAvbFrm;
		the->m_FrmAtom.qwAtomSize = 0;

		AvbWriteHdr(the);

		if( ! (the->m_pHdr->dwFlags & LXAVB_HAVE_IDX ) ) {
			i_err = STX_OK;
			break;
		}

		i_err = AvbWriteStartEx(the,szName);
		if( STX_OK != i_err ) {
			break;
		}

		*pHnd = the;

		i_err = STX_OK;

	}while(FALSE);

	if( STX_OK != i_err ) {

		AvbEncClose(the);

		return i_err;
	}

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_API_IMP STX_RESULT   AvbEncClose(THEE h)
{
	STX_DIRECT_THE(LxAvbEnc);
	AvbWriteEndEx(the);
	stx_free(the);
	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE	STX_RESULT AvbWriteStartEx(LxAvbEnc* the, const char* szFileName)
{
	STX_RESULT i_err;

	size_t nLen = strlen(szFileName) + 16;

	STX_MAKE_TRACE
	the->m_szIdx = (char*)smart_mallocz(nLen,STX_MAP_TRACE);
	if( !the->m_szIdx ) {
		return STX_FAIL;
	}

	{

		// split path;
		char szDriver[12] = { 0 } ;
		char szPath[512]= { 0 } ;
		char szName[512]= { 0 } ;
		char szExt[12] = {0};

		stx_splitpath( szFileName, 
			szDriver,12,
			szPath,512,
			szName,512, 
			szExt,12 );

		stx_sprintf(the->m_szIdx,nLen,"%s%s%s%s",szDriver,szPath,szName,".indx");

		the->m_hIdxFile = stx_create_io_file();
		if( !the->m_hIdxFile ) {
			return STX_FAIL;
		}

		i_err = the->m_hIdxFile->open(the->m_hIdxFile,the->m_szIdx,O_CREAT);
		if( STX_OK != i_err ) {
			return i_err;
		}
			
		if( !( the->m_pHdr->dwFlags & LXAVB_HAVE_IDX_NAME ) ) {
			return STX_OK;
		}

		STX_MAKE_TRACE
		the->m_szSegNameIdx = (char*)smart_mallocz(nLen,STX_MAP_TRACE);
		if( !the->m_szSegNameIdx ) {
			return STX_FAIL;
		}

		stx_sprintf(the->m_szSegNameIdx,nLen,"%s%s%s%s",szDriver,szPath,szName,".name");

		the->m_hSegNameIdxFile = stx_create_io_file();
		if( !the->m_hSegNameIdxFile ) {
			return STX_FAIL;
		}
		i_err = the->m_hSegNameIdxFile->open(the->m_hSegNameIdxFile,the->m_szSegNameIdx,O_CREAT);
		if( STX_OK != i_err ) {
			return i_err;
		}
		
		return STX_OK;

	}
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE	STX_RESULT AvbWriteEndEx(LxAvbEnc* the)
{
	if( the->m_hAvbFile ) {

		// write the stream list;
		AvbWriteStreamList(the);

		if( the->m_pHdr->dwFlags & LXAVB_HAVE_IDX ) {
			if( STX_OK != AvbMoveIdxFile(the) ) {
				return STX_FAIL;
			}
		}

		// rewrite the header, atom size;
		AvbWriteHdr(the);

		SAFE_CLOSEXIO(the->m_hAvbFile);
	}

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_PRIVATE	void AvbWriteHdr(LxAvbEnc* the)
{
	size_t		dwWrote;
	s64			lavb;
	LxAvbAtom	hda;

	lavb = the->m_hAvbFile->size(the->m_hAvbFile);

	// write atom header of avb header;
	the->m_hAvbFile->seek(the->m_hAvbFile,0,SEEK_SET);
	INIT_MEMBER(hda);
	hda.gid = gidLxAvbHdr;
	hda.qwAtomSize = lavb - LXAVB_ATOM_HDR_SIZE();   
	LxAvbWriteAtomHdr(the->m_hAvbFile,&hda);

	// rewrite avb header;
	the->m_hAvbFile->write(the->m_hAvbFile,the->m_pHdr,LXAVB_HDR_SIZE(),&dwWrote);

	// update the frame atom ;
	LxAvbWriteAtomHdr(the->m_hAvbFile,&the->m_FrmAtom);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_PRIVATE	void AvbWriteStreamList(LxAvbEnc* the)
{
	s32			i;
	LxAvbAtom	hda;
	size_t		dwWrote = 0;

	// record stream list position;
	the->m_pHdr->qwLstPos = the->m_hAvbFile->size(the->m_hAvbFile);

	// write atom header of avb header;
	AvbWriteHdr(the);

	the->m_hAvbFile->seek(the->m_hAvbFile,0,SEEK_SET);

	// write avb stream header list;
	INIT_MEMBER(hda);
	hda.gid = gidLxAvbStmLst;
	hda.qwAtomSize = 0;   
	for( i = 0; i < (s32)the->m_pHdr->dwStreamNum; i ++ ) {
		hda.qwAtomSize += the->m_ppHdrLst[i]->qwAtomSize + LXAVB_ATOM_HDR_SIZE();
	}
	LxAvbWriteAtomHdr(the->m_hAvbFile,&hda);
	for( i = 0; i < (s32)the->m_pHdr->dwStreamNum; i ++ ) {
		the->m_hAvbFile->write( 
			the->m_hAvbFile,
			the->m_ppHdrLst[i], 
			(size_t)(the->m_ppHdrLst[i]->qwAtomSize + LXAVB_ATOM_HDR_SIZE()),
			&dwWrote);
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE	STX_RESULT	AvbMoveIdxFile(LxAvbEnc* the)
{
	size_t		dwWrite;
	s64			lavb,lar_idx,lar_name;
	LxAvbAtom	hda;
	s64			qwIdxSize;

	lavb = the->m_hAvbFile->size(the->m_hAvbFile);

	the->m_hAvbFile->seek(the->m_hAvbFile,0,SEEK_SET);

	// add index flags;

	// IDX at file end;
	the->m_pHdr->qwIdxPos = lavb;

	lar_idx = the->m_hIdxFile->size(the->m_hIdxFile);

	if( the->m_pHdr->dwFlags & LXAVB_HAVE_IDX_NAME ) {
		lar_name = the->m_hSegNameIdxFile->size(the->m_hSegNameIdxFile);
	}

	INIT_MEMBER(hda);
	hda.gid = gidLxAvbIdx;
	hda.qwAtomSize = lar_idx + lar_name;   
	LxAvbWriteAtomHdr(the->m_hAvbFile,&hda);

	the->m_hIdxFile->seek(the->m_hIdxFile,0,SEEK_SET);

	qwIdxSize = lar_idx;

	while( qwIdxSize > 0 ) {

		// struct LxAvbIdxItem is packed;
		LxAvbIdxItem	IdxItem = {0};
		size_t			dwLen = sizeof(IdxItem);
		size_t			dwRead = 0;

		the->m_hIdxFile->read(the->m_hIdxFile,&IdxItem,dwLen,&dwRead);

		if( the->m_pHdr->dwFlags & LXAVB_HAVE_IDX_NAME ) {
			IdxItem.qwNameStrPos += lar_idx; // index part;
		}

		dwWrite = 0;
		the->m_hAvbFile->write(the->m_hAvbFile,&IdxItem,dwRead,&dwWrite);
		qwIdxSize -= dwLen;

	} // while( qwIdxSize > 0 ) {

	SAFE_CLOSEXIO(the->m_hIdxFile);

	if( the->m_pHdr->dwFlags & LXAVB_HAVE_IDX_NAME ) {

		s64 qwNameSize = lar_name;

		the->m_hSegNameIdxFile->seek(the->m_hSegNameIdxFile,0,SEEK_SET);

		while( qwNameSize > 0 ) {
			u8		buf[2048];
			size_t	dwLen = (size_t)( qwNameSize > 2048 ? 2048 : qwNameSize );
			size_t	dwRead = 0;
			the->m_hSegNameIdxFile->read(the->m_hSegNameIdxFile,buf,dwLen,&dwRead);
			dwWrite = 0;
			the->m_hAvbFile->write(the->m_hAvbFile,buf,dwRead,&dwWrite);
			qwNameSize -= dwLen;
		}

		SAFE_CLOSEXIO(the->m_hSegNameIdxFile);

	} // if( the->m_pHdr->dwFlags & LXAVB_HAVE_IDX_NAME ) {

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_PRIVATE	STX_RESULT	AvbWriteStreamData
(LxAvbEnc* the,	s32 nStmNum,u8* pData,s32 nDataLen,s64 qwTime,b32 bFirstBlock )
{
	LxAvbAtom	atom;
	size_t		dwWrote;

	if( ! bFirstBlock ) {
		dwWrote = 0;
		the->m_hAvbFile->write(the->m_hAvbFile,pData,nDataLen,&dwWrote);
		the->m_FrmAtom.qwAtomSize += nDataLen;
		return STX_OK;
	}

	INIT_MEMBER(atom);

	if( IS_EQUAL_GID(gidLxAvbVidHdr,the->m_ppHdrLst[nStmNum]->gid ) ) {

		LxAvbFrmHdr frm;
		STX_VIDEOINFOHEADER2* vd2;

		atom.gid = gidLxAvbVidFrm;
		atom.qwAtomSize = LxAvbAtomFrm_HdrSize() + nDataLen;
		LxAvbWriteAtomHdr(the->m_hAvbFile,&atom);
		the->m_FrmAtom.qwAtomSize += atom.qwAtomSize;

		INIT_MEMBER(frm);
		frm.dwDataLen = nDataLen;
		frm.dwStmNum  = nStmNum;
		vd2 = (STX_VIDEOINFOHEADER2*)( (u8*)the->m_ppHdrLst[nStmNum] + LXAVB_ATOM_HDR_SIZE() );
		frm.dwFcc = vd2->bmiHeader.biCompression;
		frm.dwFlags = LXAVB_KEY_FRAME;
		frm.qwTimeCode = qwTime;
		LxAvbWriteFrmHdr(the->m_hAvbFile,&frm);
	}
	else if( IS_EQUAL_GID(gidLxAvbAudHdr,the->m_ppHdrLst[nStmNum]->gid ) ) {

		LxAvbFrmHdr frm;
		STX_WAVEFORMATEX* pwx;

		atom.gid = gidLxAvbAudFrm;
		atom.qwAtomSize = LxAvbAtomFrm_HdrSize() + nDataLen;
		LxAvbWriteAtomHdr(the->m_hAvbFile,&atom);
		the->m_FrmAtom.qwAtomSize += atom.qwAtomSize;

		INIT_MEMBER(frm);
		frm.dwDataLen = nDataLen;
		frm.dwStmNum  = nStmNum;
		pwx = (STX_WAVEFORMATEX*)( (u8*)the->m_ppHdrLst[nStmNum] + LXAVB_ATOM_HDR_SIZE() );
		frm.dwFcc = pwx->wFormatTag;
		frm.dwFlags = LXAVB_KEY_FRAME;
		frm.qwTimeCode = qwTime;
		LxAvbWriteFrmHdr(the->m_hAvbFile,&frm);
	}
	else {   // system stream;

		LxAvbStmFrmHdr frm;

		atom.gid = gidLxAvbStmFrm;
		atom.qwAtomSize = LxAvbAtomStmFrm_HdrSize() + nDataLen;
		LxAvbWriteAtomHdr(the->m_hAvbFile,&atom);
		the->m_FrmAtom.qwAtomSize += atom.qwAtomSize + LXAVB_ATOM_HDR_SIZE();

		INIT_MEMBER(frm);
		frm.dwFlags = LXAVB_KEY_FRAME;
		frm.qwTimeCode = qwTime;
		frm.dwDataLen = nDataLen;
		LxAvbWriteStmFrmHdr(the->m_hAvbFile,&frm);
	}

	the->m_hAvbFile->write(the->m_hAvbFile,pData, nDataLen, &dwWrote);

	if( qwTime > the->m_pHdr->qwTotalTime ) {
		the->m_pHdr->qwTotalTime = qwTime;
	}

	if( nDataLen > (s32)the->m_pHdr->dwMaxBufSize ) {
		the->m_pHdr->dwMaxBufSize = nDataLen;
	}

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API_IMP STX_RESULT   
AvbCreateStream(STX_HANDLE h,s32* pnStmNum,LxAvbAtom* pFormatHdr)
{
	STX_DIRECT_THE(LxAvbEnc);
	{

		LxAvbAtom* pAtom;
		LxAvbAtom** ppNewLst;

		STX_MAKE_TRACE
		ppNewLst = (LxAvbAtom**)smart_mallocz( 
			sizeof(LxAvbAtom*)*( the->m_pHdr->dwStreamNum + 1 ),
			STX_MAP_TRACE);
		if( !ppNewLst ) {
			return STX_FAIL;
		}

		if( the->m_ppHdrLst ) {
			s32 i;
			for( i = 0; i < (s32)the->m_pHdr->dwStreamNum ; i ++ ) {
				ppNewLst[i] = the->m_ppHdrLst[i];
			}
			stx_free(the->m_ppHdrLst);
		}
		the->m_ppHdrLst = ppNewLst;

		STX_MAKE_TRACE
		pAtom = (LxAvbAtom*)smart_mallocz( (size_t)(pFormatHdr->qwAtomSize + LXAVB_ATOM_HDR_SIZE()),
			STX_MAP_TRACE);
		if( !pAtom ) {
			return STX_FAIL;
		}

		memcpy(pAtom,pFormatHdr, (size_t)( pFormatHdr->qwAtomSize + LXAVB_ATOM_HDR_SIZE() ) );

		the->m_ppHdrLst[the->m_pHdr->dwStreamNum] = pAtom;

		*pnStmNum = the->m_pHdr->dwStreamNum;

		the->m_pHdr->dwStreamNum ++;

		return STX_OK;

	}
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_API_IMP STX_RESULT   AvbWriteStream
	(STX_HANDLE h,s32 nStmNum,u8* pData,s32 nDataLen,LxP2PStreamInf* pInf)
{
	size_t dwWrite;

	STX_DIRECT_THE(LxAvbEnc);

	if( ! ( the->m_pHdr->dwFlags & LXAVB_HAVE_IDX ) ){

		// no index case;

		if( pInf->nSegId == 0 ) {
			the->m_pHdr->qwTotalSegment ++;
		}

		return AvbWriteStreamData(the,nStmNum,pData,nDataLen,pInf->qwSegStartTime,pInf->nSegId == 0);
	}

	if( pInf->nSegId ) {

		// have index, not the first block;

		return AvbWriteStreamData(the,nStmNum,pData,nDataLen,pInf->qwSegStartTime, FALSE );
	}

	// have index, first block, write index file;

	if( the->m_pHdr->dwFlags & LXAVB_HAVE_IDX_NAME  ){

		// must get the stream file size before write block data to it;
		s64				lar;
		s64				lar_name;
		char			szDriver[16] = { 0 } ;
		char			szPath[512]= { 0 } ;
		char			szName[512]= { 0 } ;
		char			szExt[16] = {0};
		char			szTmpName[512] = {0};
		LxAvbIdxItem	IdxItem = {0};
		LxAvbSegName	seg = {0};

		lar = the->m_hAvbFile->size(the->m_hAvbFile);

		// must get the name index file size before write the name to it;
		lar_name = the->m_hSegNameIdxFile->size(the->m_hSegNameIdxFile);

		// write name string idx;

		// split path;

		stx_splitpath( pInf->szName, szDriver,16,szPath,512,szName,512, szExt,16 );
		stx_sprintf(szTmpName,sizeof(szTmpName),"%s%s",szName,szExt);

		seg.wSize = (u16)strlen( szTmpName );
		the->m_hSegNameIdxFile->write(the->m_hSegNameIdxFile,&seg.wSize,sizeof(seg.wSize),&dwWrite);
		the->m_hSegNameIdxFile->write(the->m_hSegNameIdxFile,szTmpName,strlen(szTmpName),&dwWrite);

		// write idx;  struct LxAvbIdxItem is packed;

		IdxItem.dwStmNum     = nStmNum;
		IdxItem.dwFlags      = LXAVB_KEY_FRAME;
		IdxItem.qwSegId      = the->m_pHdr->qwTotalSegment;  // need set;
		IdxItem.qwFrmSize    = pInf->qwSegSize;
		IdxItem.qwTimeCode   = pInf->qwSegStartTime;
		IdxItem.qwFrmPos     = lar;
		IdxItem.qwNameStrPos = lar_name;

		the->m_hIdxFile->write(the->m_hIdxFile,&IdxItem,LXAVB_IDXITEM_SIZE,&dwWrite);
	}
	else {
		// write idx;
		s64 lar;
		LxAvbIdxItem IdxItem = {0};

		lar = the->m_hAvbFile->size(the->m_hAvbFile);

		IdxItem.dwStmNum     = nStmNum;
		IdxItem.dwFlags      = LXAVB_KEY_FRAME;
		IdxItem.qwSegId      = the->m_pHdr->qwTotalSegment;  // need set;
		IdxItem.qwFrmSize    = pInf->qwSegSize;
		IdxItem.qwTimeCode   = pInf->qwSegStartTime;
		IdxItem.qwDurationTime = pInf->qwSegDuraTime;
		IdxItem.qwFrmPos     = lar;

		IdxItem.qwNameStrPos = 0;

		the->m_hIdxFile->write(the->m_hIdxFile,&IdxItem,LXAVB_IDXITEM_SIZE,&dwWrite);
	}

	// increase the segment counter after write the index file;
	the->m_pHdr->qwTotalSegment ++;

	// write to the stream file block data at last;

	return AvbWriteStreamData(the,nStmNum,pData,nDataLen,pInf->qwSegStartTime, TRUE );
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

struct LxAvbDec{

	stx_xio*			m_hAvbFile;
	s32					m_nHdrSize;
	LxAvbHdr*			m_pAvbHdr;
	u8**				m_ppStmLst;

	u8*					m_pReadBuf;

	s32					m_nVidHdrSize;
	LxAvbAtomVidHdr*	m_pVidHdr;
	s32					m_nAudHdrSize;
	LxAvbAtomAudHdr*	m_pAudHdr;

	u8*					m_pIdx;

	DECL_TRACE
};

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_PRIVATE		STX_RESULT   AvbHdrDec(LxAvbDec* the);
STX_PRIVATE		STX_RESULT   AvbIdxDec(LxAvbDec* the);

STX_PRIVATE		STX_RESULT   AvbDecMpegStmHdr(LxAvbDec* the,LxAvbAtom* pAtom);
STX_PRIVATE		STX_RESULT   AvbDecWmvStmHdr(LxAvbDec* the,LxAvbAtom* pAtom);
STX_PRIVATE		STX_RESULT   AvbDecAviStmHdr(LxAvbDec* the,LxAvbAtom* pAtom);

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_API STX_RESULT   AvbDecOpen(STX_HANDLE* pHnd,const char* szName)
{
	u8			buf[2048];
	STX_RESULT	i_err;
	size_t		dwHigh;
	LxAvbDec*	the;
	LxAvbAtom*	pAtom;
	u32			dwBufSize;
	s64			lar;


	i_err = STX_FAIL;
	the = NULL;

	do{
		DECL_TRACE

		MAKE_TRACE2
		the = (LxAvbDec*)smart_mallocz(sizeof(LxAvbDec),MAP_TRACE);
		if( !the ) {
			return STX_FAIL;
		}

		the->m_hAvbFile = stx_create_io_file();
		if( !the->m_hAvbFile ) {
			break;
		}

		i_err = the->m_hAvbFile->open(the->m_hAvbFile,szName,O_RDONLY);
		if( STX_OK != i_err ) {
			break;
		}

		the->m_hAvbFile->seek(the->m_hAvbFile,0,SEEK_SET);

		i_err = the->m_hAvbFile->read(the->m_hAvbFile,buf,LXAVB_ATOM_HDR_SIZE(),&dwHigh);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = STX_FAIL;
		pAtom = (LxAvbAtom*)buf;
		if( !IS_EQUAL_GID(pAtom->gid,gidLxAvbHdr) ) {
			break;
		}

		the->m_nHdrSize = LXAVB_HDR_SIZE();

		STX_MAKE_TRACE
		the->m_pAvbHdr = (LxAvbHdr*)smart_mallocz( LXAVB_HDR_SIZE(), STX_MAP_TRACE);
		if( !the->m_pAvbHdr ) {
			break;
		}

		i_err = the->m_hAvbFile->read( the->m_hAvbFile, the->m_pAvbHdr, LXAVB_HDR_SIZE(),&dwHigh );
		if( STX_OK != i_err ) {
			break;
		}

		i_err = STX_FAIL;
		if(the->m_pAvbHdr->dwAvbTag != LXAVB_HDR_TAG ) {
			break;
		}

		dwBufSize = the->m_pAvbHdr->dwMaxBufSize ? the->m_pAvbHdr->dwMaxBufSize : 128*1024;

		STX_MAKE_TRACE
		the->m_pReadBuf = (u8*)smart_mallocz( dwBufSize, STX_MAP_TRACE);
		if( !the->m_pReadBuf ) {
			break;
		}

		i_err = AvbHdrDec(the);
		if( STX_OK != i_err ) {
			break;
		}

		if( the->m_pAvbHdr->dwFlags & LXAVB_HAVE_IDX ) {
			// initialize index file;
			i_err = AvbIdxDec(the);
			if( STX_OK != i_err ) {
				break;
			}
		}

		lar = the->m_pAvbHdr->qwFrmPos + LXAVB_ATOM_HDR_SIZE();
		the->m_hAvbFile->seek(the->m_hAvbFile,lar,SEEK_SET);

		i_err = STX_OK;

		*pHnd = the;

	}while(FALSE);

	if( STX_OK != i_err ) {
		AvbDecClose(the);
	}

	return i_err;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_API STX_RESULT   AvbDecClose(STX_HANDLE h)
{
	STX_DIRECT_THE(LxAvbDec);

	SAFE_CLOSEXIO(the->m_hAvbFile);

	if( the->m_ppStmLst ) {
		int i;
		for( i = 0; i < (int)the->m_pAvbHdr->dwStreamNum; i ++ ) {
			if( the->m_ppStmLst[i] ) {
				stx_free(the->m_ppStmLst[i]);
			}
		}
		stx_free(the->m_ppStmLst);
	}

	if( the->m_pAvbHdr ) {
		stx_free(the->m_pAvbHdr);
	}

	if( the->m_pReadBuf ) {
		stx_free(the->m_pReadBuf);
	}

	if( the->m_pVidHdr ) {
		stx_free(the->m_pVidHdr);
	}

	if( the->m_pAudHdr ) {
		stx_free(the->m_pAudHdr);
	}

	if( the->m_pIdx ) {
		stx_free(the->m_pIdx);
	}

	stx_free(the);

	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_API STX_RESULT AvbDecGetHdr(STX_HANDLE h,LxAvbHdr* pHdr)
{
	STX_DIRECT_THE(LxAvbDec);

	if( !pHdr) {
		return the->m_nHdrSize;
	}

	memcpy(pHdr,the->m_pAvbHdr,the->m_nHdrSize);

	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_API STX_RESULT AvbDecGetVidFmt(STX_HANDLE h,LxAvbAtomVidHdr* pVidHdr)
{
	STX_DIRECT_THE(LxAvbDec);
	if( !pVidHdr ) {
		return the->m_nVidHdrSize;
	}
	memcpy(pVidHdr,the->m_pVidHdr,the->m_nVidHdrSize);
	return STX_OK;

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_API STX_RESULT AvbDecGetAudFmt(STX_HANDLE h,LxAvbAtomAudHdr* pAudHdr)
{
	STX_DIRECT_THE(LxAvbDec);
	if( !pAudHdr ) {
		return the->m_nAudHdrSize;
	}
	memcpy(pAudHdr,the->m_pAudHdr,the->m_nAudHdrSize);
	return STX_OK;

}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_API STX_RESULT   AvbRead
(
	STX_HANDLE	h,
	void*		pData,
	size_t		nDataSize
)
{
	size_t dwRead;
	STX_DIRECT_THE(LxAvbDec);
	return the->m_hAvbFile->read(the->m_hAvbFile,pData,nDataSize,&dwRead);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_PRIVATE STX_RESULT AvbHdrDec(LxAvbDec* the)
{
	s32			i;
	size_t		dwRead;
	s64			lar;
	LxAvbAtom	hda;

	STX_MAKE_TRACE
	the->m_ppStmLst = (u8**) smart_mallocz( the->m_pAvbHdr->dwStreamNum*sizeof(u8*), 
		STX_MAP_TRACE );
	if( !the->m_ppStmLst ) {
		return STX_FAIL;
	}

	lar = the->m_pAvbHdr->qwLstPos;

	the->m_hAvbFile->seek(the->m_hAvbFile,lar,SEEK_SET);

	the->m_hAvbFile->read( the->m_hAvbFile, &hda,LXAVB_ATOM_HDR_SIZE(),&dwRead );

	for( i = 0; i < (s32)the->m_pAvbHdr->dwStreamNum; i ++ ) {
		the->m_hAvbFile->read( the->m_hAvbFile, &hda,LXAVB_ATOM_HDR_SIZE(),&dwRead);
		STX_MAKE_TRACE
		the->m_ppStmLst[i] = (u8*)smart_mallocz( 
			(size_t)( hda.qwAtomSize + LXAVB_ATOM_HDR_SIZE() ),
			STX_MAP_TRACE);
		if( !the->m_ppStmLst[i] ) {
			return STX_FAIL;
		}
		memcpy(the->m_ppStmLst[i],&hda,LXAVB_ATOM_HDR_SIZE());
		the->m_hAvbFile->read(the->m_hAvbFile, the->m_ppStmLst[i]+LXAVB_ATOM_HDR_SIZE(),
			(size_t)(hda.qwAtomSize),&dwRead );
	}

	for( i = 0; i < (s32)the->m_pAvbHdr->dwStreamNum; i ++ ) {

		LxAvbAtom* pAtom = (LxAvbAtom*)the->m_ppStmLst[i];

		s32 nSize = (s32)pAtom->qwAtomSize;

		if( IS_EQUAL_GID(pAtom->gid,gidLxAvbVidHdr) ) {
			STX_MAKE_TRACE
			the->m_pVidHdr = (LxAvbAtomVidHdr*) smart_mallocz(nSize,STX_MAP_TRACE);
			if( !the->m_pVidHdr ) {
				return STX_FAIL;
			}
			memcpy(the->m_pVidHdr,(u8*)pAtom + LXAVB_ATOM_HDR_SIZE() ,nSize);
			the->m_nVidHdrSize = nSize;

		} 
		else if( IS_EQUAL_GID(pAtom->gid,gidLxAvbAudHdr) ) {
			STX_MAKE_TRACE
			the->m_pAudHdr = (LxAvbAtomAudHdr*) smart_mallocz(nSize,STX_MAP_TRACE);
			if( !the->m_pAvbHdr ) {
				return STX_FAIL;
			}
			memcpy(the->m_pAudHdr,(u8*)pAtom + LXAVB_ATOM_HDR_SIZE(),nSize);
			the->m_nAudHdrSize = nSize;
		}
		else if( IS_EQUAL_GID(pAtom->gid ,gidLxAvbMpeg2_Ps) || 
			IS_EQUAL_GID(pAtom->gid,gidLxAvbMpeg2_Ts ) ) {
			AvbDecMpegStmHdr(the,pAtom);
		}
		else if( IS_EQUAL_GID(pAtom->gid,gidLxAvbWmv) ) {
			AvbDecWmvStmHdr(the,pAtom);
		}
		else if( IS_EQUAL_GID(pAtom->gid,gidLxAvbAvi) ) {
			AvbDecAviStmHdr(the,pAtom);
		}
	}

	return STX_OK;	
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_PRIVATE STX_RESULT AvbIdxDec(LxAvbDec* the)
{
	s64			lar;
	size_t		dwRead;
	size_t		dwIdxLen;
	u8*			buf;
	LxAvbAtom	hda;

	lar = the->m_pAvbHdr->qwIdxPos;
	the->m_hAvbFile->seek( the->m_hAvbFile, lar, SEEK_SET );

	the->m_hAvbFile->read(the->m_hAvbFile,&hda,LXAVB_ATOM_HDR_SIZE(),&dwRead);

	dwIdxLen = (size_t) hda.qwAtomSize;

	STX_MAKE_TRACE
	the->m_pIdx = (u8*) smart_mallocz(dwIdxLen,STX_MAP_TRACE) ;
	if( !the->m_pIdx ) {
		return STX_FAIL;
	}

	buf = the->m_pIdx;

	while( dwIdxLen > 0 ) {
		size_t dwLen = dwIdxLen > 2048 ? 2048 : dwIdxLen;
		size_t dwRead = 0;
		the->m_hAvbFile->read(the->m_hAvbFile,buf,dwLen,&dwRead);
		dwIdxLen -= dwLen;
		buf += dwLen;
	}

	return STX_OK;	
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_PRIVATE		STX_RESULT   AvbDecMpegStmHdr(LxAvbDec* the,LxAvbAtom* pAtom)
{

	return STX_ERR_NOT_IMP;

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_PRIVATE		STX_RESULT   AvbDecWmvStmHdr(LxAvbDec* the,LxAvbAtom* pAtom)
{
	return STX_ERR_NOT_IMP;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_PRIVATE		STX_RESULT   AvbDecAviStmHdr(LxAvbDec* the,LxAvbAtom* pAtom)
{
	return STX_ERR_NOT_IMP;

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_API STX_RESULT AvbDecSetTime(STX_HANDLE h,s64 qwTime)
{
	STX_DIRECT_THE(LxAvbDec);

	if( ! ( the->m_pAvbHdr->dwFlags & LXAVB_HAVE_IDX ) ) {
		return STX_ERR_NOT_SUPPORT;
	}

	// search the index , set the file pointer to key frame position;
	{
		s32 i;
		u8* pIdxBuf = the->m_pIdx;

		for( i = 0; i < the->m_pAvbHdr->qwTotalSegment; i ++ ) {

			LxAvbIdxItem* pIdxItem = (LxAvbIdxItem*)pIdxBuf;

			if( pIdxItem->qwTimeCode >= qwTime ) {
				the->m_hAvbFile->seek( the->m_hAvbFile, pIdxItem->qwFrmPos, SEEK_SET );
				return STX_OK;
			}

			pIdxBuf += sizeof(LxAvbIdxItem);
		}

		return STX_FAIL;
	}
}
