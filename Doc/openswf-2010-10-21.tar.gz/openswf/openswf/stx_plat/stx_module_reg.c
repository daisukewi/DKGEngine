/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/
#include "stdio.h"
#include "stdlib.h"
#include "fcntl.h"
#include "malloc.h"
#include "memory.h"
#include "string.h"

#include "stx_os.h"
#include "stx_mem.h"
#include "stx_debug.h"
#include "stx_mutex.h"
#include "stx_ini.h"
#include "stx_gid_def.h"
#include "stx_module_reg.h"
#include "stx_dll.h"

#include "stx_graph_builder.h"
#include "stx_message.h"
#include "stx_msg_def.h"


#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif

/* {2EB24117-F67D-4874-84B6-8E34EB8A387B}*/
DEFINE_XGUID( STX_REG_MONITOR,0x2eb24117, 0xf67d, 0x4874, 0x84, 0xb6, 0x8e, 0x34, 0xeb, 0x8a, 0x38, 0x7b)


// // {5DD9809E-B7D6-475b-A504-8AF93B2ECE68}
// DEFINE_XGUID( STX_PLUG_LAST_RUN,
// 0x5dd9809e, 0xb7d6, 0x475b, 0xa5, 0x4, 0x8a, 0xf9, 0x3b, 0x2e, 0xce, 0x68 )


/***********************************************************************************
***********************************************************************************/
char* g_szStreamX_Root = _SZ_CUR_ROOT;
char* g_szStreamX_Path = _SZ_CUR_ROOT STX_SEP _SZ_STX_PLAT;


char* g_szGraphBuilder = "StreamX graph builder";
char* g_szFilterGraph = "StreamX filter graph";
char* g_szSyncSource = "StreamX sync source";
char* g_szMemAllocator = "StreamX memory allocator";
char* g_szRender  = "StreamX render";
char* g_szFileSource = "StreamX file source";
char* g_szIntermediateFilter = "StreamX filter";
char* g_szStreamX_Cfg = "StreamX.xini";
char* g_sz_service_cfg = "service.xini";

char* g_szStreamX_AllModule = "All modules";
char* g_szStreamX_AllService = "All services";
char* g_szStreamX_AllDlib = "All dlib";
char* g_szStreamX_PathName = "Path Name";

char* g_szStreamX_MainCategory = "Main category";
char* g_szStreamX_CategoryDesc= "Category Name";

char* g_szStreamX_Interface = "Interface";

char* g_szStreamX_FilterName = "Filter name";
char* g_szStreamX_ClassId = "ClassId";
char* g_szStreamX_ClassIdName = "ClassId name";

char* g_szStreamX_OutputPin = "OutputPin";

char* g_szStreamX_InputPin = "InputPin";

char* g_szStreamX_InputType= "Input Type";
char* g_szStreamX_OutputType= "Output Type";

char* g_szStreamX_MajorDataType = "Major Type";
char* g_szStreamX_MajorDataTypeName = "Major Type Name";

char* g_szStreamX_SubDataType = "Sub Type";
char* g_szStreamX_SubDataTypeName = "Sub Type Name";

char* g_szStreamX_CreateModule = "stx_create_instance";

char* g_szStreamX_AllStream= "All Streams";
char* g_szStreamX_Extension= "Extension";

char* g_szStreamX_VideoFile = "Video File";
char* g_szStreamX_AudioFile = "Audio File";
char* g_szStreamX_QuickTimeVideo = "QuickTime Video File";
char* g_szStreamX_QuickTimeAudio = "QuickTime Audio File";
char* g_szStreamX_WMV = "Windows Video File";
char* g_szStreamX_WMA = "Windows Audio File";


char* g_szStreamX_length = "length";
char* g_szStreamX_dts = "dts";
char* g_szStreamX_pts = "pts";
char* g_szStreamX_duration = "duration";
char* g_szStreamX_header = "header";
char* g_szStreamX_width = "width";
char* g_szStreamX_pitch = "pitch";
char* g_szStreamX_height = "height";
char* g_szStreamX_display = "display";
char* g_szStreamX_pushmode = "pushmode";
char* g_szStreamX_enable = "enable";




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API_IMP STX_RESULT on_first_audio_data(stx_base_plugin* plug,s64 i_pts)
{
	STX_RESULT				i_err;

	// send upstream message
	stx_base_message*       p_msg;
	stx_msg_cnt*			p_cnt;

	i_err = STX_FAIL;
	p_msg = NULL;

	do{

		p_msg = XCREATE(base_msg,NULL,NULL);
		if( !p_msg ) {
			break;
		}
		p_msg->set_msg_buf(p_msg,(u8*)&i_pts,(s32)sizeof(i_pts));
		p_msg->set_msg_type(p_msg,STX_MSG_TYPE_UPSTREAM);
		p_cnt = p_msg->get_msg_cnt(p_msg);
		p_cnt->msg_gid = STX_MSG_REND;

		i_err = plug->send_msg(plug,p_msg);
		if( STX_OK != i_err ) {
			break;
		}

		if( !p_msg->is_msg_closed(p_msg) ) {
			i_err = STX_FAIL;
			break;
		}

		i_err = STX_OK;

	}while(FALSE); // do{

	SAFE_XDELETE(p_msg);

	return i_err;
}






