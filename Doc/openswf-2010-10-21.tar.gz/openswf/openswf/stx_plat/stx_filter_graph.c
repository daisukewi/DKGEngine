
/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/


#include "stdio.h"
#include "stdlib.h"
#include "fcntl.h"
#include "malloc.h"
#include "memory.h"
#include "string.h"

#include "stx_mem.h"
#include "stx_debug.h"
#include "stx_gid_def.h"
#include "stx_module_reg.h"
#include "stx_filter_graph.h"
#include "stx_os.h"
#include "stx_sync_source.h"
#include "stx_message.h"
#include "stx_async_loader.h"


#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif


STX_API_IMP
CREATE_STX_COM(stx_base_graph,STX_IID_FilterGraph,base_graph);


char* g_szStreamX_FilterGraph = "StreamX FilterGraph filter";




STX_COM_BEGIN(base_graph);

    STX_PUBLIC(stx_base_graph)
	STX_COM_DATA_DEFAULT(stx_base_graph)

    s32					i_plugins;
	s32					i_max_plugins;
    stx_base_plugin**	pp_plugin;

    s32					i_src;
	s32					i_max_src;
    stx_base_source**	pp_src;

	stx_base_plugin*	h_task_plugin;
	STX_HANDLE          h_task_handle;

STX_COM_END();


STX_COM_FUNC_DECL_DEFAULT(stx_base_graph,stx_base_graph_vt);
STX_COM_FUNCIMP_DEFAULT(base_graph,stx_base_graph,stx_base_graph_vt);


/*{{{STX_MSG_ENTRY_DECLARE**************************************************/
/* to do : add msg proc entry  declaration here; */
STX_MSG_ENTRY_DECLARE(on_query_obj)
STX_MSG_ENTRY_DECLARE(on_load_source_as)
STX_MSG_ENTRY_DECLARE(on_auto_stop)
STX_MSG_ENTRY_DECLARE(on_app_stop)
/*}}}***********************************************************************/


/*{{{STX_BEGIN_MSG_MAP******************************************************/
STX_BEGIN_MSG_MAP(the_msg_data)
/* to do : add msg proc entry name here; */
// asynchronous add file source;
/**/ON_STX_MSG(STX_MSG_QueryObject,on_query_obj)
/**/ON_STX_MSG(STX_MSG_LoadSourceAs,on_load_source_as)
/**/ON_STX_MSG(STX_MSG_AutoStop,on_auto_stop)
/**/ON_STX_MSG(STX_MSG_AppStop,on_app_stop)
STX_END_MSG_MAP
/*}}}***********************************************************************/



/*{{{STX_BEGIN_MSG_RESPONSE_MAP*********************************************/
STX_BEGIN_MSG_RESPONSE_MAP(the_msg_response)

/* to do : add msg process entry name here; */

STX_END_MSG_RESPONSE_MAP
/*}}}***********************************************************************/


/*{{{STX_DISPATHCH_MSG_PROC*************************************************/
STX_DISPATCH_MSG_PROC(  dispatch_msg,the_msg_data )
/*}}}***********************************************************************/


/*{{{STX_RESPONSE_MSG_PROC**************************************************/
STX_RESPONSE_MSG_PROC(  response_msg,the_msg_response )
/*}}}***********************************************************************/


/*}}}async_plugin inherit block; ***********************************************/





/***************************************************************************
stx_base_graph_create
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_COM_MAP_BEGIN(base_graph)
/**/STX_COM_MAP_ITEM(STX_IID_FilterGraph)
STX_COM_MAP_END()

STX_API_IMP 
STX_NEW_BEGIN(base_graph)
{
    STX_SET_THE(stx_base_graph);
	STX_COM_NEW_DEFAULT(
		stx_base_graph,
		the->stx_base_graph_vt,
		stx_base_graph_vt,
		CLSID_FilterGraph,
		STX_CATEGORY_FilterGraph,
		g_szStreamX_FilterGraph);
}
STX_NEW_END()




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API_IMP	
STX_QUERY_BEGIN(base_graph)
	STX_COM_QUERY_DEFAULT(stx_base_graph,the->stx_base_graph_vt);
STX_QUERY_END()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API_IMP
STX_DELETE_BEGIN(base_graph)
{
	s32 i;

	if( the->pp_src ){
		for( i = 0; i < (s32)the->i_src ; i ++ ) {
			SAFE_XDELETE(the->pp_src[i]);
		}
		stx_free(the->pp_src);
	}//if( the->pp_src ){

	if( the->pp_plugin ) {
		for( i = 0; i < (s32)the->i_plugins ; i ++ ) {
			SAFE_XDELETE(the->pp_plugin[i]);
		}
		stx_free(the->pp_plugin);
	}//if( the->pp_plugin ) {

	STX_COM_DELETE_DEFAULT(stx_base_graph);
}
STX_DELETE_END(
STX_COM_DELETE_BEGIN(stx_base_graph)
,
STX_COM_DELETE_END(stx_base_graph)
)


STX_PRIVATE STX_RESULT add_source_internal
(base_graph* the, char* sz_file_name, stx_base_source** pp_src, b32 b_async );


/***************************************************************************
send_msg
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_graph_vt_plug_xxx_send_msg
( STX_HANDLE h, stx_base_message* p_msg )
{
	STX_RESULT i_err;

	STX_MAP_THE(base_graph);

	i_err = dispatch_msg(h,p_msg);
	if(i_err < 0 || p_msg->is_msg_closed(p_msg) ) {
		return i_err;
	}

	{
		u32 i_type = p_msg->get_msg_type(p_msg);
		if( i_type & STX_MSG_TYPE_UPSTREAM ) {
			// parent is gbd;
			i_err = the->p_parent->send_msg(the->p_parent,p_msg);
			if(i_err < 0 || p_msg->is_msg_closed(p_msg) ) {
				return i_err;
			}
		}
		else if( i_type & STX_MSG_TYPE_DOWNSTREAM ) {
			s32 i;
			for( i = 0; i < the->i_src; i ++ ) {
				stx_base_source* psrc = the->pp_src[i];
				stx_base_plugin* plug = NULL;
				i_err = psrc->query_interf(psrc,STX_IID_BasePlugin,(void**)&plug);
				if(i_err < 0  ) {
					return i_err;
				}
				i_err = plug->send_msg(plug,p_msg);
				SAFE_XDELETE(plug);
				if(i_err < 0 || p_msg->is_msg_closed(p_msg) ) {
					return i_err;
				}
			}//for( i = 0; i < the->i_src; i ++ ) {

		}//else if( i_type & STX_MSG_TYPE_DOWNSTREAM ) {

	}//

	i_err = response_msg(h,p_msg);

	return i_err;
}


/***************************************************************************

enum_plugin
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_graph_vt_xxx_enum_plugin
(STX_HANDLE h, size_t* i_index, stx_base_plugin** pp_plugin )
{
    STX_MAP_THE(base_graph);

	if( !i_index ) {
		return STX_ERR_INVALID_PARAM;
	}

    if( !pp_plugin ) {
        *i_index = the->i_plugins;
        return STX_OK;
    }

	{
		size_t idx = *i_index;
		if( idx < (size_t)the->i_plugins ) {
			stx_base_plugin* p = the->pp_plugin[idx];
			p->add_ref(p);
			*pp_plugin = p;
			return STX_OK;
		}
	}

    return STX_ERR_INVALID_PARAM;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT	stx_base_graph_vt_xxx_add_plugin
( STX_HANDLE h, stx_base_plugin* p_plugin )
{
    STX_RESULT			i_err;
    stx_base_source*	p_source;

    STX_MAP_THE(base_graph);

    i_err = STX_FAIL;
    p_source = STX_NULL;

    if( the->i_plugins >= the->i_max_plugins ) {

		stx_base_plugin** pp;

		pp = (stx_base_plugin**)xmallocz( sizeof(stx_base_plugin*)*(the->i_max_plugins + STX_MAX_PLUGINS));
		if( !pp ) {
			return STX_FAIL;
		}

		if( the->pp_plugin ) {
			s32 i;
			for( i = 0; i < the->i_plugins; i ++ ) {
				pp[i] = the->pp_plugin[i];
			}
			stx_free( the->pp_plugin);
		}
		the->pp_plugin = pp;
		the->i_max_plugins += STX_MAX_PLUGINS;

    } //if( the->i_plugins >= the->i_max_plugins ) {


	the->pp_plugin[the->i_plugins] = p_plugin;
	the->i_plugins ++;
	p_plugin->add_ref(p_plugin);

	p_plugin->set_parent(p_plugin,(stx_base_plugin*)&the->stx_base_graph_vt);

	p_plugin->set_ssrc(p_plugin,the->h_ssrc);
	the->h_ssrc->add_ref(the->h_ssrc);

	p_plugin->set_gbd(p_plugin,the->h_gbd);
	the->h_gbd->add_ref(the->h_gbd);

    /* to do a test, if it is a file source; */
    i_err = p_plugin->query_interf(p_plugin,STX_IID_FileSource,(void**)&p_source);

    if( STX_OK == i_err ) {

		if( the->i_src >= the->i_max_src ) {

			stx_base_source** pp;

			pp = (stx_base_source**)xmallocz( sizeof(stx_base_source*)*(the->i_max_src + STX_MAX_PLUGINS));
			if( !pp ) {
				i_err = STX_FAIL;
				goto fail;
			}

			if( the->pp_src ) {
				s32 i;
				for( i = 0; i < the->i_src; i ++ ) {
					pp[i] = the->pp_src[i];
				}
				stx_free( the->pp_src);
			}
			the->pp_src = pp;
			the->i_max_src += STX_MAX_PLUGINS;

		} // if( the->i_src >= the->i_max_src ) {

		the->pp_src[the->i_src] = p_source;

		the->i_src  ++;

    }// if( STX_OK == i_err ) {

    i_err = STX_OK;

fail:

	if( STX_OK != i_err ) {
		SAFE_XDELETE(p_source);
	}

    return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT	stx_base_graph_vt_xxx_remove_plugin
( STX_HANDLE h, const char* sz_name )
{
    STX_RESULT			i_err;
    s32					i,j,k;
    stx_base_plugin*	p_plugin;

    STX_MAP_THE(base_graph);

    i_err = STX_FAIL;
    p_plugin = STX_NULL;

    for( i = 0; i < (s32)the->i_plugins; i ++ ) {

		p_plugin = the->pp_plugin[i];


        if( !strcmp(sz_name,p_plugin->get_name(p_plugin) ) ) {

            p_plugin->release(p_plugin);

            for( j = 0; j < the->i_src; j ++ ) {

				stx_base_plugin* p_src_plug;

				p_src_plug = NULL;
				i_err = the->pp_src[j]->query_interf(the->pp_src[j],STX_IID_BasePlugin,(void**)&p_src_plug);
				if( STX_OK != i_err ) {
					goto fail;
				}

                if( p_src_plug == the->pp_plugin[i] ) {

					p_src_plug->release(p_src_plug);
					SAFE_XDELETE(the->pp_src[j]);

                    for( k = j; k + 1 < the->i_src; k ++ ) {
                        the->pp_src[k] = the->pp_src[k+1];
                    }

                    the->pp_src[the->i_src-1] = STX_NULL;
                    the->i_src  --;
                    break;

                } /* if( the->pp_src[j] == the->pp_plugin[i] ) { */

				p_src_plug->release(p_src_plug);

            } /* for( j = 0; j < the->i_src; j ++ ) { */


            the->pp_plugin[i]->release(the->pp_plugin[i]);

            for( j = i; j + 1 < (s32)the->i_plugins; j ++ ) {
                the->pp_plugin[j] = the->pp_plugin[j+1];
            }

            the->pp_plugin[the->i_plugins-1] = STX_NULL;
            the->i_plugins --;
            i_err = STX_OK;

            goto fail;

        } /* if( !strcmp(sz_name,p_plugin->get_name(p_plugin) ) ) { */

        p_plugin->release(p_plugin);
        p_plugin = STX_NULL;

    } /* for( i = 0; i < the->i_plugins; i ++ ) { */


    i_err = STX_ERR_FILE_NOT_FOUND;

fail:

    if( p_plugin ) {
        p_plugin->release(p_plugin);
    }

    return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT	stx_base_graph_vt_xxx_find_plugin
(STX_HANDLE h, stx_base_plugin** pp_plugin,const char* sz_name )
{
    STX_RESULT			i_err;
    s32					i;
    stx_base_plugin*	p_plugin;

    STX_MAP_THE(base_graph);

    i_err = STX_FAIL;

    p_plugin = STX_NULL;

    for( i = 0; i < (s32)the->i_plugins; i ++ ) {

        i_err = the->pp_plugin[i]->query_interf(the->pp_plugin[i],STX_IID_BasePlugin,(void**)&p_plugin);

        if( STX_OK != i_err ) {
            goto fail;
        }

        if( !strcmp(sz_name,p_plugin->get_name(p_plugin) ) ) {

            i_err = p_plugin->query_interf(p_plugin,STX_IID_BaseCom,(void**)pp_plugin );
            if( STX_OK != i_err ) {
                goto fail;
            }

            p_plugin->release(p_plugin);

            i_err = STX_OK;

            goto fail;

        } /* if( !strcmp(sz_name,p_plugin->get_name(p_plugin) ) ) { */

        p_plugin->release(p_plugin);
        p_plugin = STX_NULL;

    } /*for( i = 0; i < the->i_plugins; i ++ ) { */

    i_err = STX_ERR_FILE_NOT_FOUND;

fail:

    if( p_plugin ) {
        p_plugin->release(p_plugin);
    }

    return i_err;
}

/***************************************************************************
find_source
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_graph_vt_xxx_find_source
(STX_HANDLE h, stx_base_com** pp_plugin,stx_media_type_inf media_inf )
{
    STX_RESULT			i_err;
    stx_base_filter*	p_source;
    s32					i,j,i_all;
    stx_media_type_inf	mtype;

    STX_MAP_THE(base_graph);

    i_err = STX_ERR_FILE_NOT_FOUND;
    p_source = STX_NULL;

    for( i = 0; i < the->i_src; i ++ ) {

        if( the->pp_src[i] ) {

            i_err = the->pp_src[i]->query_interf(the->pp_src[i],STX_IID_BaseFilter,(void**)&p_source );
            if( STX_OK != i_err ) {
                goto fail;
            }

			i_all = 0;
			i_err = p_source->enum_output_media_type(p_source,&i_all,NULL);
			if( STX_OK != i_err ) {
				goto fail;
			}

			if( i_all == MAX_MEDIA_TYPE ) {  // skip enmulator;
				continue;
			}

			for( j = 0; j < i_all; j ++ ){

				i_err = p_source->enum_output_media_type(p_source,&j,&mtype);

				p_source->release(p_source);
				p_source = STX_NULL;

				if( is_compatible_gid( media_inf.major_type ,mtype.major_type ) &&
					is_compatible_gid( media_inf.sub_type ,mtype.sub_type ) ) {

					i_err = the->pp_src[i]->query_interf(the->pp_src[i],STX_IID_BaseCom,(void**)pp_plugin );
					if( STX_OK != i_err ) {
						goto fail;
					}

					i_err = STX_OK;
					goto fail;

				} /* if( major_type == p_source->get_major_type(p_source) ) { */

			} // for( j = 0; j < i_all; j ++ ){

        } /* if( the->p_src ) { */

    } /* for( i = 0; i < the->i_src; i ++ ) { */

fail:

	SAFE_XDELETE(p_source);

    return i_err;
}


/***************************************************************************
find_render
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_graph_vt_xxx_find_render
( STX_HANDLE h, stx_base_com** pp_plugin,stx_media_type_inf media_inf )
{

    STX_RESULT			i_err;
    s32					i;
    stx_base_filter*	p_flt;
    s32					i_pin;
    stx_gid				md_type;
	stx_gid				md_subtype;
    stx_base_pin*		p_pin;
    stx_media_type*		p_md_in;

    STX_MAP_THE(base_graph);

    i_err = STX_FAIL;
    p_flt = STX_NULL;
    p_pin = STX_NULL;
    p_md_in = STX_NULL;

    for( i = 0; i < (s32)the->i_plugins; i ++ ) {

        i_err = the->pp_plugin[i]->query_interf(the->pp_plugin[i],STX_IID_BaseFilter,(void**)&p_flt);
        if( STX_OK != i_err ) {
            goto fail;
        }

		i_err = p_flt->enum_output_pin(p_flt,&i_pin,NULL);
		if( STX_OK != i_err ) {
			goto fail;
		}

        if( i_pin ) {  /* not a render; */
            p_flt->release(p_flt);
            p_flt = STX_NULL;
            continue;
        }

		i_err = p_flt->enum_input_pin(p_flt,&i_pin,NULL);
		if( STX_OK != i_err ) {
			goto fail;
		}

        if( !i_pin ) {  /* fatal error? */
            p_flt->release(p_flt);
            p_flt = STX_NULL;
            continue;
        }

        for( i = 0; i < i_pin ; i ++ ) {

            i_err = p_flt->enum_input_pin( p_flt, &i, &p_pin );
            if( STX_OK != i_err ) {
                goto fail;
            }

            p_md_in = p_pin->get_media_type(p_pin);
            if( !p_md_in ) {
                goto fail;
            }

            md_type = p_md_in->get_type(p_md_in);
			md_subtype = p_md_in->get_subtype(p_md_in);

            if( is_compatible_gid(media_inf.major_type,md_type ) &&
				is_compatible_gid(media_inf.sub_type,md_subtype) ) {

                i_err = p_flt->query_interf(p_flt,STX_IID_BaseCom,(void**)pp_plugin);
                if( STX_OK != i_err ) {
                    goto fail;
                }

                i_err = STX_OK;

                goto fail;
            }

            p_pin->release(p_pin);
            p_pin = STX_NULL;

            p_md_in->release(p_md_in);
            p_md_in = STX_NULL;
        }

        p_flt->release(p_flt);
        p_flt = STX_NULL;

    }

    i_err = STX_ERR_FILE_NOT_FOUND;

fail:

	SAFE_XDELETE(p_md_in);
	SAFE_XDELETE(p_pin);
	SAFE_XDELETE(p_flt);

    return i_err;
}


/***************************************************************************

connect_direct
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT	stx_base_graph_vt_xxx_connect_direct
(STX_HANDLE h, stx_base_pin* p_out,stx_base_pin* p_in, stx_media_type* p_mt )
{
    STX_RESULT 		i_err;
    stx_media_type* p_mt_in;
    stx_media_type* p_mt_out;
    stx_gid    		md_type;
    stx_gid    		md_type_in;
    stx_gid    		md_type_out;

    STX_MAP_THE(base_graph);

    i_err = STX_FAIL;
    p_mt_out = STX_NULL;
    p_mt_in = STX_NULL;

    md_type = p_mt->get_type(p_mt);

    p_mt_in = p_in->get_media_type(p_in);
    if( !p_mt_in ) {
        goto fail;
    }

    p_mt_out = p_out->get_media_type(p_out);
    if( !p_mt_out ) {
        goto fail;
    }

    md_type_in = p_mt_in->get_type(p_mt_in);

    md_type_out = p_mt_out->get_type(p_mt_out);

    if( !is_compatible_gid(md_type,md_type_in ) ) {
        i_err = STX_INCOMPATIBLE;
        goto fail;
    }

    if( !is_compatible_gid(md_type,md_type_out ) ) {
        i_err = STX_INCOMPATIBLE;
        goto fail;
    }

    md_type = p_mt->get_subtype(p_mt);

    md_type_in = p_mt_in->get_subtype(p_mt_in);

    md_type_out = p_mt_out->get_subtype(p_mt_out);

    if( !is_compatible_gid(md_type,md_type_in ) ) {
        i_err = STX_INCOMPATIBLE;
        goto fail;
    }

    if( !is_compatible_gid(md_type,md_type_out ) ) {
        i_err = STX_INCOMPATIBLE;
        goto fail;
    }

    i_err = p_out->connect(p_out,p_in);
    if(STX_OK != i_err ) {
        goto fail;
    }

    i_err = p_in->connect(p_in,p_out);
    if(STX_OK != i_err ) {
        goto fail;
    }

    i_err = STX_OK;

fail:

    if( p_mt_out ) {
        p_mt_out->release(p_mt_out);
    }

    if( p_mt_in ) {
        p_mt_in->release(p_mt_in);
    }

    return i_err;
}



/***************************************************************************
disconnect
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_graph_vt_xxx_disconnect
(STX_HANDLE h, stx_base_pin* p_pin)
{

    STX_RESULT		i_err;
    stx_base_pin*   p_con_pin;

    STX_MAP_THE(base_graph);

    i_err = STX_FAIL;

    p_con_pin = STX_NULL;

    if( ! p_pin->is_connected(p_pin,&p_con_pin ) ) {
        return STX_OK;
    }

    i_err = p_con_pin->break_connect(p_con_pin);
    if( STX_OK != i_err ) {
        goto fail;
    }

    i_err = p_pin->break_connect(p_pin);
    if( STX_OK != i_err ) {
        goto fail;
    }

    i_err = STX_OK;

fail:

    if( p_con_pin ) {
        p_con_pin->release(p_con_pin);
    }

    return i_err;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG STX_RESULT on_query_obj(STX_HANDLE h,stx_base_message* p_msg)
{
	STX_MAP_THE(base_graph);
	{
// 		stx_gid			buf_iid;
// 		stx_msg_cnt*	cnt;
// 		s32				i_len;
// 
// 		buf_iid = *(stx_gid*)p_msg->get_msg_buf(p_msg,&i_len);
// 
// 		// ActiveMovieWindow
// 		if( IS_EQUAL_GID(STX_IID_GraphBuilder,buf_iid) ) {
// 			stx_base_graph_builder* h_gbd = stx_base_plugin_map_gbd((stx_base_plugin*)h);
// 			if( h_gbd ) {
// 				cnt = p_msg->get_msg_cnt(p_msg);
// 				cnt->param.i_param[0] = (size_t)h_gbd;
// 				p_msg->set_msg_close(p_msg);
// 				return STX_OK;
// 			}
// 		} // if( IS_EQUAL_GID(STX_IID_ActiveMovieWindow,buf_iid) ) {
// 
// 		return STX_FAIL;
	}

	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT: 
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT 
on_auto_stop(STX_HANDLE h,stx_base_message* p_msg )
{
	STX_MAP_THE(base_graph);
	{
		STX_HANDLE h_stack = p_msg->get_stack(p_msg);

		// push plugin interface pointer;
		stx_stack_push(h_stack,(size_t)&the->stx_base_graph_vt);

		return STX_OK;
	}	
}

/***************************************************************************
RETURN VALUE:
INPUT: 
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT 
on_app_stop(STX_HANDLE h,stx_base_message* p_msg )
{
	STX_MAP_THE(base_graph);
	{
		STX_HANDLE h_stack = p_msg->get_stack(p_msg);

		stx_base_plugin* const plug = (stx_base_plugin*)*stx_stack_pop(h_stack);

		return plug->send_msg(plug,p_msg);
	}	
}



/***************************************************************************
RETURN VALUE:
INPUT: 
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT 
on_load_source_as(STX_HANDLE h,stx_base_message* p_msg )
{
	STX_RESULT			i_err;
	stx_msg_cnt*		cnt;
	char*				sz_url;
	stx_base_source**	hh_src;

	STX_MAP_THE(base_graph);

	i_err = STX_FAIL;
	p_msg = NULL;

	cnt = p_msg->get_msg_cnt(p_msg);

	sz_url = (char*)(char*)cnt->param.i_param[0];
	hh_src = (stx_base_source**)cnt->param.i_param[1];

	do{

		*hh_src = NULL;
		i_err = add_source_internal(the,sz_url,hh_src,TRUE);
		if( STX_OK != i_err ) {
			break;
		}

		the->h_task_plugin = XCREATE(async_loader,NULL); 
		if( !the->h_task_plugin ) {
			break;
		}

		i_err = the->h_task_plugin->send_msg(the->h_task_plugin,p_msg);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = the->h_ssrc->reg_task(the->h_ssrc,
			&the->h_task_handle,(stx_base_plugin*)&the->stx_base_graph_vt,TASK_NORMAL);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = STX_OK;

	}while(FALSE);

	if( STX_OK != i_err ) {
		SAFE_XDELETE(the->h_task_plugin);
		the->h_task_plugin = NULL;
	}

	return i_err;
}


/***************************************************************************
RETURN VALUE: 
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_graph_vt_plug_xxx_flush
(STX_HANDLE h,u32 i_flag,stx_sync_inf *h_sync)
{
	return STX_OK;
}

/***************************************************************************
RETURN VALUE: 
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_graph_vt_plug_xxx_start
(STX_HANDLE h,u32 i_flag,stx_sync_inf *h_sync)
{
	STX_MAP_THE(base_graph);
	return STX_OK;
}


/***************************************************************************
RETURN VALUE: 
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_graph_vt_plug_xxx_stop
(STX_HANDLE h,u32 i_flag,stx_sync_inf *h_sync)
{
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static STX_RESULT stx_base_graph_vt_plug_xxx_run
(STX_HANDLE h,stx_sync_inf* h_sync)
{
	s32 i;
	STX_RESULT i_err;

	stx_base_graph_builder* h_gbd;

	STX_MAP_THE(base_graph);


	if( !h_sync->h_task ) {  // come from user pear;

		do{

			h_gbd = NULL;
			i_err = the->p_parent->query_interf(the->p_parent,STX_IID_GraphBuilder,(void**)&h_gbd);
			if( STX_OK != i_err ) {
				break;
			}

			// create main task for each source filter;
			for( i = 0; i < the->i_src; i ++ ) {

				stx_sync_inf		sync_inf;
				stx_base_plugin*	p_flt;
				stx_base_source*	src = the->pp_src[i];

				p_flt = NULL;
				i_err = src->query_interf(src,STX_IID_BasePlugin,(void**)&p_flt);
				if( STX_OK != i_err ) {
					break;
				}

				INIT_MEMBER(sync_inf);
				i_err = p_flt->run(p_flt,&sync_inf);
				SAFE_XDELETE(p_flt);
				if( STX_OK != i_err ) {
					break;
				}

			}// for( i = 0; i < the->i_src; i ++ ) {

			if( STX_OK != i_err ) {
				break;
			}

		}while(FALSE);

		SAFE_XDELETE(h_gbd);

		return i_err;

	} // if( !i_idle_time ) {

	// come from ssrc; it is src initialize task;

	if( the->h_task_plugin ) {
		
		i_err = the->h_task_plugin->run(the->h_task_plugin,h_sync);
		if( STX_OK == i_err ) {
			// if success, first unregister the task handle, then close plugin, and return STX_STOP;
			the->h_ssrc->unreg_task(the->h_ssrc,the->h_task_handle);
			the->h_task_handle = STX_NULL;
			SAFE_XDELETE0(the->h_task_plugin);
			return STX_STOP;
		}
		return i_err;
	}// if( the->h_task_plugin ) {

	return STX_STOP;
}





/***************************************************************************

gbd_connect_internal

RETURN VALUE:
INPUT:
OUTPUT:
NOTE: intelligent connect;

***************************************************************************/
static STX_RESULT gbd_connect_internal
(
 base_graph*			the, 
 stx_gid				major_type, 
 stx_gid				sub_type,
 stx_base_pin*			p_in, 
 stx_connect_ctx*		p_connect_ctx
 )
{
	s32					    i;
	STX_RESULT				i_err;
	stx_media_type*			p_mt_in;
	stx_gid					cls_gid;
	stx_gid					major_in;
	stx_gid					sub_in;
	stx_gid					cls_major_type;
	stx_gid					cls_sub_type;

	i_err = STX_FAIL;

	p_mt_in = p_in->get_media_type(p_in);
	if( !p_mt_in ) {
		goto fail;
	}
	major_in = p_mt_in->get_type(p_mt_in);
	sub_in = p_mt_in->get_subtype(p_mt_in);

	i_err = the->h_gbd->reg_query_input_type( 
		the->h_gbd,
		major_type,
		sub_type,
		p_connect_ctx );

	if( STX_OK != i_err ) {
		goto fail;
	}

	i_err = p_connect_ctx->get_cur_cls_gid(p_connect_ctx,&cls_gid);
	if( STX_OK != i_err ) {
		goto fail;
	}

	if( 0 == p_connect_ctx->get_cur_cls_pin_num(p_connect_ctx) ) {  /* it is a render; */
		p_connect_ctx->add_skip_cls_gid(p_connect_ctx,cls_gid);
		return STX_EOF;
	}

	i_err = p_connect_ctx->add_con_cls_gid(p_connect_ctx,cls_gid);
	if( STX_OK != i_err ) {
		goto fail;
	}

	for( i = 0; i < p_connect_ctx->get_cur_cls_pin_num(p_connect_ctx); i ++ ) {

		i_err = p_connect_ctx->get_cur_cls_type( p_connect_ctx,i,&cls_major_type,&cls_sub_type );
		if( STX_OK != i_err ) {
			goto fail;
		}

		if( is_compatible_gid(major_in,cls_major_type) && is_compatible_gid(sub_in,cls_sub_type) ) {
			return  STX_OK;
		}

		i_err = gbd_connect_internal(
			the,
			cls_major_type,
			cls_sub_type,
			p_in,
			p_connect_ctx );

		if( STX_EOF == i_err ) {
			continue;
		}

		if( i_err < 0 ) {
			goto fail;
		}
	}

	i_err = p_connect_ctx->rem_con_cls_gid( p_connect_ctx, cls_gid );
	if( i_err < 0 ) {
		goto fail;
	}
	i_err = p_connect_ctx->add_skip_cls_gid( p_connect_ctx, cls_gid );
	if( i_err < 0 ) {
		goto fail;
	}

	i_err = STX_EOF;  /* it is a dead way; */

fail:

	return i_err;
}


/***************************************************************************

gbd_connect

RETURN VALUE: 
1) STX_OK: success;
2) STX_EOF: connect failed;
3) other negative value, internal error;

INPUT: 
1) p_out, the first filter's output pin;
2) p_in, the input pin of the next filter;

OUTPUT: no output;

NOTE: intelligent connect;

***************************************************************************/
STX_PURE STX_RESULT stx_base_graph_vt_xxx_connect
(STX_HANDLE h, stx_base_pin* p_out,stx_base_pin* p_in )
{

	STX_RESULT				    i_err;
	s32					        i,j,k;
	s32					        i_input_pin,i_output_pin;
	stx_base_plugin*			p_parent;
	stx_base_com*				p_obj;
	stx_base_filter*			p_flt_prev;
	stx_base_filter*			p_flt_next;
	stx_base_pin*				p_input;
	stx_base_pin*				p_output;
	stx_media_type*				p_mt_in;
	stx_media_type*				p_mt_out;
	stx_connect_ctx*			con_ctx;
	stx_gid					    major_type;
	stx_gid					    sub_type;

	stx_gid					    cls_gid;


	STX_MAP_THE(base_graph);

	i_err = STX_FAIL;
	p_obj = STX_NULL;
	p_flt_prev = STX_NULL;
	p_flt_next = STX_NULL;
	p_output = STX_NULL;
	p_input = STX_NULL;
	p_mt_in = STX_NULL;
	p_mt_out = STX_NULL;


	con_ctx = stx_connect_ctx_create();
	if( !con_ctx ) {
		goto fail;
	}

	p_mt_out = p_out->get_media_type(p_out);
	if( !p_mt_out ) {
		goto fail;
	}

	i_err = the->stx_base_graph_vt.connect_direct(&the->stx_base_graph_vt,p_out,p_in,p_mt_out);
	if( STX_OK == i_err ) {
		goto fail;
	}

	p_parent = p_out->get_parent(p_out);
	if( !p_parent ) {
		goto fail;
	}
	{
		stx_base_plugin* plug = NULL;
		i_err = p_parent->query_interf( 
			p_parent, 
			MKGID(STX_IID_BasePlugin), 
			(void**)&plug );

		if( STX_OK !=i_err ) {
			goto fail;
		}

		cls_gid = plug->get_clsid(plug);
		SAFE_XDELETE(plug);
	}
	p_parent->release(p_parent);
	p_parent = STX_NULL;
	i_err = con_ctx->add_skip_cls_gid(con_ctx,cls_gid);
	if( STX_OK !=i_err ) {
		goto fail;
	}

	major_type = p_mt_out->get_type(p_mt_out);
	sub_type = p_mt_out->get_subtype(p_mt_out);
	p_mt_out->release(p_mt_out);
	p_mt_out = STX_NULL;

	i_err = gbd_connect_internal(
		the,major_type,sub_type,p_in,con_ctx);

	if( STX_OK != i_err ) {
		goto fail;
	}

	/* create instance, connect the intermediate pin; */

	for( i = 0; i < con_ctx->get_con_cls_num(con_ctx); i ++ ) {

		i_err = con_ctx->get_con_cls_gid( con_ctx, i, &cls_gid );
		if( STX_OK != i_err ) {
			goto fail;
		}

		i_err = the->h_gbd->co_create_obj( the->h_gbd,cls_gid,&p_obj);
		if( STX_OK != i_err ) {
			goto fail;
		}

		i_err = p_obj->query_interf(p_obj,MKGID(STX_IID_BaseFilter),(void**)&p_flt_next);
		if( STX_OK != i_err ) {
			goto fail;
		}

		if( !p_flt_prev ) {
			p_output = p_out;
			i_output_pin = 1;
		}
		else {
			i_err = p_flt_prev->enum_output_pin(p_flt_prev,&i_output_pin,NULL);
			if( STX_OK != i_err ) {
				goto fail;
			}
			if( !i_output_pin ) {   
				/* the flt is not compatible with StreamX configure file; fatal error; */
				i_err = STX_FAIL;
				goto fail;
			}
		}

		for( j = 0; j < i_output_pin; j ++ ) {

			if( !p_flt_prev ) {
				p_output = p_out;
			}
			else {
				i_err = p_flt_prev->enum_output_pin(p_flt_prev,&j,&p_output);
				if( STX_OK != i_err ) {
					goto fail;
				}
			}

			i_err = p_flt_next->enum_input_pin(p_flt_next,&i_input_pin,NULL);
			if( STX_OK != i_err ) {
				goto fail;
			}

			if( !i_input_pin ) {   
				/* the flt is not compatible with StreamX configure file; fatal error; */
				i_err = STX_FAIL;
				goto fail;
			}

			for( k = 0; k < i_input_pin; k ++ ) {

				i_err = p_flt_next->enum_input_pin(p_flt_next,&k,&p_input);
				if( STX_OK != i_err ) {
					goto fail;
				}

				p_mt_out = p_output->get_media_type(p_output);

				i_err = the->stx_base_graph_vt.connect_direct(
					&the->stx_base_graph_vt, p_output, p_input, p_mt_out );

				p_input->release(p_input);
				p_input = STX_NULL;

				p_mt_out->release(p_mt_out);
				p_mt_out = STX_NULL;

				if( i_err < 0 ) {
					goto fail;
				}

				if( STX_INCOMPATIBLE == i_err ) {
					continue;
				}

				if( STX_OK == i_err ) {	/* success; */				
					goto add_filter;
				}

			} /* for( k = 0; k < i_input_pin; k ++ ) { */

			if( k == i_input_pin ) {  /* failed; */
				i_err = STX_EOF;
				goto fail;
			}

			if( p_flt_prev ) {
				p_output->release(p_output);
				p_output = STX_NULL;
			}

		} /* for( j = 0; j < i_output_pin; j ++ ) { */

		i_err = STX_FAIL;
		goto fail;

		/* add the p_obj to filter graph; */
add_filter:
		{
			stx_base_plugin* plug = NULL;
			i_err = p_obj->query_interf(p_obj,STX_IID_BasePlugin,(void**)&plug);
			if( STX_OK != i_err ) {
				goto fail;
			}
			i_err = the->stx_base_graph_vt.add_plugin(&the->stx_base_graph_vt,plug);
			SAFE_XDELETE(plug);
			if( STX_OK != i_err ) {
				goto fail;
			}
		}

		/* swap the filter; */
		if( p_flt_prev ) {			
			if( p_output ) {
				p_output->release(p_output);
				p_output = STX_NULL;
			}		
			p_flt_prev->release(p_flt_prev);
		}

		p_flt_prev = p_flt_next;

	} /* for( i = 0; i < con_ctx.i_connect_idx; i ++ ) { */

	/* connect the last filter to p_in; */
	i_err = p_flt_prev->enum_output_pin(p_flt_prev,&i_output_pin,NULL);		
	if( STX_OK != i_err ) {
		goto fail;
	}
	if( !i_output_pin ) {   
		/* the flt is not compatible with StreamX configure file; fatal error; */
		i_err = STX_FAIL;
		goto fail;
	}

	for( j = 0; j < i_output_pin; j ++ ) {

		i_err = p_flt_prev->enum_output_pin(p_flt_prev,&j,&p_output);
		if( STX_OK != i_err ) {
			goto fail;
		}

		p_mt_out = p_output->get_media_type(p_output);

		i_err = the->stx_base_graph_vt.connect_direct(
			&the->stx_base_graph_vt, p_output, p_in, p_mt_out );

		p_output->release(p_input);
		p_output = STX_NULL;

		p_mt_out->release(p_mt_out);
		p_mt_out = STX_NULL;

		if( i_err < 0 ) {
			goto fail;
		}

		if( STX_INCOMPATIBLE == i_err ) {
			continue;
		}

		if( STX_OK == i_err ) {	/* success; */				
			break;
		}

	} /* for( j = 0; j < i_output_pin; j ++ ) { */

	i_err = STX_OK;

fail:

	/* check and release all the interface left; */

	if( con_ctx ) {
		con_ctx->release(con_ctx);
	}

	if(p_flt_prev){
		p_flt_prev->release(p_flt_prev);
	}

	if( p_mt_in ) {
		p_mt_in->release(p_mt_in);
	}

	if( p_mt_out ) {
		p_mt_out->release(p_mt_out);
	}

	if( p_input && p_input != p_in ) {
		p_input->release(p_input);
	}

	if( p_output && p_output != p_out ) {
		p_output->release(p_output);
	}

	return i_err;
}



/***************************************************************************

gbd_rend_internal

RETURN VALUE:
INPUT:
OUTPUT:
NOTE: 
intelligent connect; until find a render that have the right input type;

***************************************************************************/

static STX_RESULT gbd_rend_internal
(
 base_graph*			the, 
 stx_gid				major_type, 
 stx_gid				sub_type,
 stx_connect_ctx*		p_connect_ctx
 )
{
	s32							i;
	STX_RESULT					i_err;
	stx_gid						cls_gid;
	stx_gid						cls_major_type;
	stx_gid						cls_sub_type;

	i_err = the->h_gbd->reg_query_input_type( the->h_gbd,
		major_type,
		sub_type,
		p_connect_ctx );

	if( STX_OK != i_err ) {
		goto fail;
	}

	i_err = p_connect_ctx->get_cur_cls_gid(p_connect_ctx,&cls_gid);
	if( STX_OK != i_err ) {
		goto fail;
	}


	if( 0 == p_connect_ctx->get_cur_cls_pin_num(p_connect_ctx) ) {  /* it is a render; */
		i_err = p_connect_ctx->add_con_cls_gid(p_connect_ctx,cls_gid);
		if( STX_OK != i_err ) {
			goto fail;
		}
		return STX_OK;
	}

	/* try each output pin of the filter; */

	for( i = 0; i < p_connect_ctx->get_cur_cls_pin_num(p_connect_ctx); i ++ ) {

		/* get the output pin[i] type; */
		i_err = p_connect_ctx->get_cur_cls_type( p_connect_ctx,i,&cls_major_type,&cls_sub_type );
		if( STX_OK != i_err ) {
			goto fail;
		}

		i_err = gbd_rend_internal(
			the,
			cls_major_type,
			cls_sub_type,
			p_connect_ctx );

		if( i_err < 0 ) { /* fatal error; */
			goto fail;
		}

		if( STX_EOF == i_err ) {  /* dead way; */
			continue;
		}

		if( STX_OK == i_err ) { /* found render; */
			return STX_OK;
		}

	} /* for( i = 0; i < p_connect_ctx->get_cur_cls_pin_num(p_connect_ctx); i ++ ) { */

	i_err = p_connect_ctx->add_skip_cls_gid( p_connect_ctx, cls_gid );
	if( i_err < 0 ) {
		goto fail;
	}

	i_err = STX_EOF;  /* it is a dead way; */

fail:

	return i_err;
}



/***************************************************************************

gbd_rend_render

RETURN VALUE:
INPUT:
OUTPUT:
NOTE:

***************************************************************************/
static STX_RESULT gdb_rend_render(STX_HANDLE h,stx_base_pin* p_out )
{
	STX_RESULT				i_err;
	stx_base_com*			p_obj;
	stx_base_filter*		p_flt;
	stx_base_pin*			p_input;
	stx_base_graph*         h_gph;
	s32					    i,i_input_pin;
	stx_media_type*         ptype;
	stx_media_type_inf      minf;


	STX_MAP_THE(base_graph);

	i_err = STX_FAIL;
	p_obj = STX_NULL;
	p_flt = STX_NULL;
	p_input = STX_NULL;
	ptype = STX_NULL;

	h_gph = &the->stx_base_graph_vt;

	ptype = p_out->get_media_type(p_out);
	if( !ptype) {
		return STX_FAIL;
	}

	minf.major_type = ptype->get_type(ptype);
	minf.sub_type = ptype->get_subtype(ptype);

	i_err = h_gph->find_render(h_gph, &p_obj,minf);
	if( i_err < 0 ) {
		return i_err;
	}

	if(  STX_OK != i_err ) {
		return STX_EOF;
	}

	i_err = p_obj->query_interf(p_obj,MKGID(STX_IID_BaseFilter),(void**)&p_flt);
	if( STX_OK != i_err ) {
		goto fail;
	}

	i_err = p_flt->enum_input_pin(p_flt,&i_input_pin,NULL);
	if( STX_OK != i_err ) {
		goto fail;
	}

	for( i = 0; i < i_input_pin; i ++ ) {

		if( p_input ) {
			p_input->release(p_input);
			p_input = STX_NULL;
		}

		i_err = p_flt->enum_input_pin(p_flt,&i,&p_input);
		if( i_err < 0 ) {
			goto fail;
		}

		i_err = stx_base_graph_vt_xxx_connect(h,p_out,p_input);
		if( i_err == STX_EOF ) {
			continue;
		}
		if( i_err < 0 || STX_OK == i_err ) {
			goto fail;
			/* fatal error or success; */
		}

	} /* for( i = 0; i < i_input_pin; i ++ ) { */

	i_err = STX_FAIL;  /* this pin do not compatible with the render; */

fail:

	if( p_input ) {
		p_input->release(p_input);
	}

	if( p_flt ) {
		p_flt->release(p_flt);
	}

	if( p_obj ) {
		p_obj->release(p_obj);
	}

	return i_err;
}

/***************************************************************************

gbd_rend_pin

RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
automatically rend a output pin, until got a render;
***************************************************************************/
STX_PURE STX_RESULT	
stx_base_graph_vt_xxx_rend_pin( STX_HANDLE h, stx_base_pin* p_out )
{
	STX_RESULT				i_err;
	s32					    i,j,k;
	s32					    i_input_pin,i_output_pin;
	stx_base_plugin*		p_parent;
	stx_base_com*			p_obj;
	stx_base_filter*		p_flt_prev;
	stx_base_filter*		p_flt_next;
	stx_base_pin*			p_input;
	stx_base_pin*			p_output;
	stx_media_type*			p_mt_out;
	stx_connect_ctx*		con_ctx;
	stx_gid					major_type;
	stx_gid					sub_type;
	stx_gid					cls_gid;


	STX_MAP_THE(base_graph);

	con_ctx = STX_NULL;
	i_err = STX_FAIL;
	p_obj = STX_NULL;
	p_flt_prev = STX_NULL;
	p_flt_next = STX_NULL;
	p_output = STX_NULL;
	p_input = STX_NULL;
	p_mt_out = STX_NULL;

	/* 
	first to check if have a render (video or audio) already loaded/connected to the graph;
	if exist, force to do pin connection; 
	or, try to rend this pin;
	*/

	i_err = gdb_rend_render(the,p_out);

	if( STX_OK == i_err ) { /* connect to the exist render, success; */
		return STX_OK;
	}

	if( i_err < 0 ) {  /* fatal error; */
		goto fail;
	}

	/* not compatible render exist; rend this pin; */

	con_ctx = stx_connect_ctx_create();
	if( !con_ctx ) {
		goto fail;
	}

	p_parent = p_out->get_parent(p_out);
	if( !p_parent ) {
		goto fail;
	}
	cls_gid = p_parent->get_clsid(p_parent);
	SAFE_XDELETE(p_parent);
	p_parent = STX_NULL;

	i_err = con_ctx->add_skip_cls_gid(con_ctx,cls_gid);
	if( STX_OK !=i_err ) {
		goto fail;
	}

	p_mt_out = p_out->get_media_type(p_out);
	if( !p_mt_out ) {
		goto fail;
	}
	major_type = p_mt_out->get_type(p_mt_out);
	sub_type = p_mt_out->get_subtype(p_mt_out);
	p_mt_out->release(p_mt_out);
	p_mt_out = STX_NULL;

	i_err = gbd_rend_internal(
		the,major_type,sub_type,con_ctx);

	if( STX_OK != i_err ) {
		goto fail;
	}

	/* create instance, connect the intermediate pin; */

	for( i = 0; i < con_ctx->get_con_cls_num(con_ctx); i ++ ) {

		i_err = con_ctx->get_con_cls_gid( con_ctx, i, &cls_gid );
		if( STX_OK != i_err ) {
			goto fail;
		}

		i_err = the->h_gbd->co_create_obj( the->h_gbd,cls_gid,&p_obj);
		if( STX_OK != i_err ) {
			goto fail;
		}

		i_err = p_obj->query_interf(p_obj,MKGID(STX_IID_BaseFilter),(void**)&p_flt_next);
		if( STX_OK != i_err ) {
			goto fail;
		}

		if( !p_flt_prev ) {
			p_output = p_out;
			i_output_pin = 1;
		}
		else {
			i_err = p_flt_prev->enum_output_pin(p_flt_prev,&i_output_pin,NULL);
			if( STX_OK != i_err ) {
				goto fail;
			}
			if( !i_output_pin ) {   
				/* the flt is not compatible with StreamX configure file; fatal error; */
				i_err = STX_FAIL;
				goto fail;
			}
		}

		for( j = 0; j < i_output_pin; j ++ ) {

			if( !p_flt_prev ) {
				p_output = p_out;
			}
			else {
				i_err = p_flt_prev->enum_output_pin(p_flt_prev,&j,&p_output);
				if( STX_OK != i_err ) {
					goto fail;
				}
			}

			i_err = p_flt_next->enum_input_pin(p_flt_next,&i_input_pin,NULL);
			if( STX_OK != i_err ) {
				goto fail;
			}

			if( !i_input_pin ) {   
				/* the flt is not compatible with StreamX configure file; fatal error; */
				i_err = STX_FAIL;
				goto fail;
			}

			for( k = 0; k < i_input_pin; k ++ ) {

				i_err = p_flt_next->enum_input_pin(p_flt_next,&k,&p_input);
				if( STX_OK != i_err ) {
					goto fail;
				}

				p_mt_out = p_output->get_media_type(p_output);

				i_err = the->stx_base_graph_vt.connect_direct(
					&the->stx_base_graph_vt, p_output, p_input, p_mt_out );

				p_input->release(p_input);
				p_input = STX_NULL;

				p_mt_out->release(p_mt_out);
				p_mt_out = STX_NULL;

				if( i_err < 0 ) {
					goto fail;
				}

				if( STX_INCOMPATIBLE == i_err ) {
					continue;
				}

				if( STX_OK == i_err ) {	/* success; */				
					goto add_filter;
				}

			} /* for( k = 0; k < i_input_pin; k ++ ) { */

			if( k == i_input_pin ) {  /* failed; */
				i_err = STX_EOF;
				goto fail;
			}

			if( p_flt_prev ) {
				p_output->release(p_output);
				p_output = STX_NULL;
			}

		} /* for( j = 0; j < i_output_pin; j ++ ) { */

		i_err = STX_FAIL;
		goto fail;

		/* add the p_obj to filter graph; */
add_filter:
		{
			stx_base_plugin* plug = NULL;
			i_err = p_obj->query_interf(p_obj,STX_IID_BasePlugin,(void**)&plug);
			if( STX_OK != i_err ) {
				goto fail;
			}
			i_err = the->stx_base_graph_vt.add_plugin(&the->stx_base_graph_vt,plug);
			SAFE_XDELETE(plug);
			if( STX_OK != i_err ) {
				goto fail;
			}
		}

		/* swap the filter; */
		if( p_flt_prev ) {			
			if( p_output ) {
				p_output->release(p_output);
				p_output = STX_NULL;
			}		
			p_flt_prev->release(p_flt_prev);
		}

		p_flt_prev = p_flt_next;

	} /* for( i = 0; i < con_ctx.i_connect_idx; i ++ ) { */

	i_err = STX_OK;

fail:

	/* check and release all the interface left; */

	if( con_ctx ) {
		con_ctx->release(con_ctx);
	}

	if(p_flt_prev){
		p_flt_prev->release(p_flt_prev);
	}

	if( p_mt_out ) {
		p_mt_out->release(p_mt_out);
	}

	if( p_input ) {
		p_input->release(p_input);
	}

	if( p_output && p_output != p_out ) {
		p_output->release(p_output);
	}

	return i_err;
}



/***************************************************************************

gbd_rend_file

RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
automatically add file source, connect pin;
***************************************************************************/
STX_PURE STX_RESULT	
stx_base_graph_vt_xxx_rend_file( STX_HANDLE h, char* sz_file_name )
{

	STX_RESULT			i_err;
	stx_base_com*		p_obj;
	stx_base_filter*	p_flt;
	stx_base_pin*		p_out;
	s32					i,i_out_pin;

	STX_MAP_THE(base_graph);


	i_err = STX_FAIL;
	p_obj = STX_NULL;
	p_flt = STX_NULL;
	p_out = STX_NULL;

	/* add source filter to graph; */

	i_err = stx_base_graph_vt_xxx_add_source( h, sz_file_name, &p_obj );
	if( STX_OK != i_err ) {
		goto fail;
	}

	/* get the filter interface; */
	i_err = p_obj->query_interf(p_obj,STX_IID_BaseFilter, (void**)&p_flt);
	if( STX_OK != i_err ) {
		goto fail;
	}

	/* rend each pin of the source filter; */
	i_err = p_flt->enum_output_pin(p_flt,&i_out_pin,NULL);
	if( STX_OK != i_err ) {
		goto fail;
	}
	if( !i_out_pin ) {
		goto fail;
	}

	for( i = 0; i < i_out_pin; i ++ ) {

		i_err = p_flt->enum_output_pin(p_flt,&i,&p_out);
		if( STX_OK != i_err ) {
			goto fail;
		}

		i_err = stx_base_graph_vt_xxx_rend_pin(h,p_out);
		if( STX_OK != i_err ) {
			goto fail;
		}

		p_out->release(p_out);
		p_out = STX_NULL;

	} /* for( i = 0; i < i_out_pin; i ++ ) { */


fail:

	if( p_obj ) {
		p_obj->release(p_obj);
	}

	if( p_flt ) {
		p_flt->release(p_flt);
	}

	if( p_out ) {
		p_out->release(p_out);
	}

	return i_err;
}

/***************************************************************************

gbd_rend

RETURN VALUE:
INPUT:
OUTPUT:
NOTE:

***************************************************************************/
STX_PURE STX_RESULT 
stx_base_graph_vt_xxx_rend( STX_HANDLE h )
{
	return STX_FAIL;
}


/***************************************************************************
add_source_plugin
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_PRIVATE STX_RESULT add_source_internal
(base_graph* the, char* sz_file_name, stx_base_source** pp_src, b32 b_async )
{

	STX_RESULT		    i_err;
	stx_base_com*		p_obj;
	stx_base_source*	p_source;
	stx_reg_find_ctx	find_ctx;
	STX_HANDLE		    h_find;


	i_err = STX_FAIL;
	p_obj = STX_NULL;
	p_source = STX_NULL;
	h_find = STX_NULL;

	memset( &find_ctx, 0, sizeof( find_ctx ) );

	find_ctx.i_find_flags = STX_REG_FIND_SRC | STX_REG_FIND_BY_EXTENSION;

	stx_strcpy( find_ctx.sz_text, sizeof(find_ctx.sz_text),sz_file_name );

	/* first find file source; */
	i_err = the->h_gbd->reg_find_class(the->h_gbd,&find_ctx,&h_find);
	if( STX_OK != i_err ) {
		goto fail;
	}

	/* create file source; */
	i_err = the->h_gbd->co_create_obj( the->h_gbd,find_ctx.cls_gid, &p_obj );
	if( STX_OK != i_err ) {
		goto fail;
	}

	{
		stx_base_plugin* plug = NULL;
		i_err = p_obj->query_interf(p_obj,STX_IID_BasePlugin,(void**)&plug);
		if( STX_OK != i_err ) {
			goto fail;
		}
		i_err = the->stx_base_graph_vt.add_plugin(&the->stx_base_graph_vt,plug);
		SAFE_XDELETE(plug);
		if( STX_OK != i_err ) {
			goto fail;
		}
	}

	/* get file source interface; */
	i_err = p_obj->query_interf(p_obj,STX_IID_FileSource,(void**)pp_src );
	if( STX_OK != i_err ) {
		goto fail;
	}

	if( !b_async ) {

		stx_sync_inf sync_inf;

		/* try to load stream;  */ 
		for(;;){
			INIT_MEMBER(sync_inf);
			i_err = p_source->load_stream(p_source,sz_file_name,&sync_inf);
			if(STX_AGAIN == i_err ){
				continue;
			}
			if( STX_IDLE == i_err || STX_WOUNLD_BLOCK == i_err){
				stx_sleep(10);
				continue;
			}
			break;
		}// for(;;){

		if( STX_OK != i_err ) {
			goto fail;
		}

	} // if( !b_async ) {

	i_err = STX_OK;

fail:

	if( h_find ) {
		the->h_gbd->reg_find_close(the->h_gbd,h_find);
	}
	SAFE_XDELETE( p_source );
	SAFE_XDELETE( p_obj );

	return i_err;

}



/***************************************************************************
add_source
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_graph_vt_xxx_add_source
(STX_HANDLE h, char* sz_file_name, stx_base_com** pp_src )
{
	STX_MAP_THE(base_graph);

	return add_source_internal(the,
		sz_file_name,(stx_base_source**)pp_src,FALSE);
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_graph_vt_plug_xxx_get_property
(STX_HANDLE h,stx_xio* h_xio)
{
	STX_MAP_THE(base_graph);

	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_graph_vt_plug_xxx_set_property
(STX_HANDLE h,stx_xio* h_xio)
{
	STX_MAP_THE(base_graph);

	return STX_ERR_NOT_SUPPORT;
}