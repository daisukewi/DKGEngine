/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#ifndef __STX_VIDEO_FRAME_H__
#define __STX_VIDEO_FRAME_H__


#include "stdio.h"
#include "stdlib.h"
#include "fcntl.h"
#include "malloc.h"
#include "memory.h"
#include "string.h"

#include "stx_base_type.h"
#include "base_interf.h"
#include "base_class.h"
#include "stx_mem.h"
#include "stx_mutex.h"


    typedef struct VideoFrame VideoFrame;


    struct VideoFrame
    {
        //<< combine the flags to dwFlags;>>
#define VIDF_FLAG_END             1
#define VIDF_FLAG_ENDSEQ         (1<<1)
#define VIDF_FLAG_SKIP_ALL       (1<<2)
#define VIDF_FLAG_PRED           (1<<3)  //
#define VIDF_FLAG_SKIP_BOT       (1<<5)
#define VIDF_FLAG_SPEED_FAST     (1<<6)
#define VIDF_FLAG_ERR            (1<<7)
#define VIDF_FLAG_STILL          (1<<8)
#define VIDF_FLAG_HALF_WIDTH     (1<<9)
#define VIDF_FLAG_HALF_HEIGHT    (1<<10)
#define VIDF_FLAG_BANK_SWITCH    (1<<11) //
#define VIDF_FLAG_DISPLAY        (1<<13)
#define VIDF_FLAG_DELAY          (1<<14)
#define VIDF_FLAG_DECODED        (1<<15)
#define VIDF_FLAG_DBFREQ         (1<<16)

        u32                  dwFlags;
        //<< combine the flags to dwFlags;>>
        s32                  nPtf;

        stx_base_com*		 pUserData;
		// user data is a stx_com interface;

        s32                  dwMemoryType;

        s32                  emCompressType;
        s32                  nFlagRepeatFrame;

        s32                  ChromaFormat;        // 420,422,444
        s32                  PictureCodingType;   // i,p,b
        s32                  PictureStructure;    // frame or field
        s32                  MotionType;
        s32                  DctType;             //

        s32                  dwFmtFourCC;       // yuv; rgb;
        s32                  nFrameSize;
        s32                  MacroBlockNumber;
        s32                  nCodedPictureWidth;    // original width in pixel; decoder used value;
        s32                  nCodedPictureHeight;   // original height in pixel; decoder used value;

        // the actual picture area;
        RECT				 SrcRect;        

        // the display area; as video frame, equal to cropped area, or need to do stretch to fit it;
        // if is the sub-picture, the the display-area maybe moved to relative positions;
        RECT				 TargetRect;       

        u8*                  lpData0[4];        // aligned;
        u8*                  lpData[4];         // aligned; lpDada[4] is the private data in h264;
        s32                  nPitch[4];
		s32					 nBufMin[4];
		s32					 nBufMax[4];

        u32                  dwDisplayWhr;      // DisplayWidthHeightRatio *= 16384; 1 << 14;
        u32                  dwNvWhr;           // fNvVideoRatio *= 16384;  1 << 14;

        s32                  BitRate;
        s32                  FrameRateCode;
        s32                  nFrameRate;
        s32                  nClockMiliSecond;
        s32                  dwPlaySpeed;

        s64                  DecodeTimeStamp;    // DTS
        s64                  PresentTimeStamp;   // PTS

        s32                  FlagOutputMode;  // data wrote manner;
        s32                  DisplayMode;     // }

        s32                  RepeatDisplayTimes;     // still picture or drop;
        s32                  NumberStreamPacket;     // data search
        s32                  NumberPresentUnit;      // navigation vobu
        s32                  NumberGroupOfPicture;   // gop no.

        STX_HANDLE           hCritic;

        void*                lpOutput;          // 

        VideoFrame*          lpForwardPicture;  // forward prediction frame;
        VideoFrame*          lpBackwardPicture; // backward prediction frame;
        u8*                  lpAlpha;                // if is a sub picture;
        u8*                  lpMacroblockType;       // anti spurs;
        s32*                 lpFlagMacroblockError;  // if error occurred;

        void*                lpPrivateData;
		// private data must be a single memory block, can't have 
		// internal object pointer; if must be a object , use userdata instead;

    };
    //} 


#if defined( __cplusplus )
	extern "C" {
#endif
		s32			vfrmAjustSurfaceSize(VideoFrame* pFrame,s32 Width,s32 Height,s32 nMemType);
		STX_RESULT	vfrmSetPrivateData(VideoFrame* pFrame,s32 nSize);

#if defined( __cplusplus )
	}
#endif


    stx_inline void  vfrmInitialize(VideoFrame* pFrame);
    stx_inline void  vfrmRelease(VideoFrame* pFrame);
    stx_inline void  vfrmReleaseBuffer(VideoFrame* pFrame);
    stx_inline void  vfrmFreeUserData(VideoFrame* pFrame);
	stx_inline void  vfrmSetUserData(VideoFrame* pFrame,stx_base_com* pData);
    stx_inline stx_base_com* vfrmGetUserData(VideoFrame* pFrame);
    stx_inline void  vfrmLock(VideoFrame* pFrame,s32 time);
    stx_inline void  vfrmUnLock(VideoFrame* pFrame);
    stx_inline void  vfrmDupInfo(VideoFrame* pDst,VideoFrame* pSrc);
    stx_inline void  vfrmGetPitch(s32* nPitLuma,s32* nPitChroma,s32 nChromaFormat);
    stx_inline void  vfrmSetFlags(VideoFrame* pFrame,s32 dwFlags);
    stx_inline s32   vfrmGetFlags(VideoFrame* pFrame);
    stx_inline void  vfrmSetPtf(VideoFrame* pFrame,s32 nPtf);
    stx_inline s32   vfrmGetPtf(VideoFrame* pFrame);
    stx_inline b32  vfrmIsEnd(VideoFrame* pFrame);
    stx_inline b32  vfrmIsEndSeq(VideoFrame* pFrame);
    stx_inline b32  vfrmIsSkipAll(VideoFrame* pFrame);
    stx_inline b32  vfrmIsInPred(VideoFrame* pFrame);
    stx_inline b32  vfrmIsSkipBot(VideoFrame* pFrame);
    stx_inline b32  vfrmIsSpeedFast(VideoFrame* pFrame);
    stx_inline b32  vfrmIsErr(VideoFrame* pFrame);
    stx_inline b32  vfrmIsStill(VideoFrame* pFrame);
    stx_inline b32  vfrmIsHalfWidth(VideoFrame* pFrame);
    stx_inline b32  vfrmIsHalfHeight(VideoFrame* pFrame);
    stx_inline b32  vfrmIsBankSwitch(VideoFrame* pFrame);
    stx_inline b32  vfrmIsDisplay(VideoFrame* pFrame);
    stx_inline b32  vfrmIsDelay(VideoFrame* pFrame);
    stx_inline b32  vfrmIsDecoded(VideoFrame* pFrame);
    stx_inline b32  vfrmIsUpGradeDisplay(VideoFrame* pFrame);
    stx_inline void  vfrmSetEnd(VideoFrame* pFrame,b32 bSet);
    stx_inline void  vfrmSetEndSeq(VideoFrame* pFrame,b32 bSet);
    stx_inline void  vfrmSetSkipAll(VideoFrame* pFrame,b32 bSet);
    stx_inline void  vfrmSetInPred(VideoFrame* pFrame,b32 bSet);
    stx_inline void  vfrmSetSkipBot(VideoFrame* pFrame,b32 bSet);
    stx_inline void  vfrmSetSpeedFast(VideoFrame* pFrame,b32 bSet);
    stx_inline void  vfrmSetErr(VideoFrame* pFrame,b32 bSet);
    stx_inline void  vfrmSetStill(VideoFrame* pFrame,b32 bSet);
    stx_inline void  vfrmSetHalfWidth(VideoFrame* pFrame,b32 bSet);
    stx_inline void  vfrmSetHalfHeight(VideoFrame* pFrame,b32 bSet);
    stx_inline void  vfrmSetBankSwitch(VideoFrame* pFrame,b32 bSet);
    stx_inline void  vfrmSetDisplay(VideoFrame* pFrame,b32 bSet);
    stx_inline void  vfrmSetDelay(VideoFrame* pFrame,b32 bSet);
    stx_inline void  vfrmSetDecoded(VideoFrame* pFrame,b32 bSet);
    stx_inline void  vfrmSetUpGradeDisplay(VideoFrame* pFrame,b32 bSet);



    stx_inline void  vfrmInitialize(VideoFrame* pFrame)
    {
        memset(pFrame,0,sizeof(VideoFrame));
        pFrame->dwDisplayWhr = LX_RATIO_4X3;
        pFrame->hCritic = stx_create_mutex(NULL,0,NULL);
    }

    stx_inline void vfrmRelease(VideoFrame* pFrame)
    {
        vfrmReleaseBuffer(pFrame);
        vfrmSetPrivateData(pFrame,0);
		vfrmFreeUserData(pFrame);
        stx_close_mutex(pFrame->hCritic);
    }

	stx_inline void vfrmFreeUserData(VideoFrame* pFrame)
	{
		SAFE_XDELETE0(pFrame->pUserData);
	}

    stx_inline void  vfrmSetUserData(VideoFrame* pFrame,stx_base_com* pData )
    {
        pFrame->pUserData = pData;
    }

    stx_inline stx_base_com*  vfrmGetUserData(VideoFrame* pFrame )
    {
        return pFrame->pUserData;
    }


    stx_inline void vfrmLock(VideoFrame* pFrame,s32 time)
    {
        stx_waitfor_mutex(pFrame->hCritic,time);
    }

    stx_inline void vfrmUnLock(VideoFrame* pFrame)
    {
        stx_release_mutex(pFrame->hCritic);
    }

    stx_inline void vfrmReleaseBuffer(VideoFrame* pFrame)
    {
        s32 i;
        for( i = 0; i < 4; i ++ ) {
            if( pFrame->lpData0[i] ) {
                xlivFree(pFrame->lpData0[i]);
                pFrame->lpData0[i] = NULL;
                pFrame->lpData[i] = NULL;
            }
        }

        if(pFrame->lpMacroblockType)	{
            xlivFree(pFrame->lpMacroblockType);
            pFrame->lpMacroblockType = NULL;
        }

        INIT_MEMBER(pFrame->nCodedPictureWidth);
        INIT_MEMBER(pFrame->nCodedPictureHeight);
        INIT_MEMBER(pFrame->SrcRect);
		INIT_MEMBER(pFrame->TargetRect);
   }




    stx_inline void  vfrmGetPitch(s32* nPitLuma,s32* nPitChroma,s32 nChromaFormat)
    {
        s32 npy = *nPitLuma;
        s32 npuv = *nPitChroma;
		s32 pit = (npy + 64 + 127) & ~127 ;

        if( nChromaFormat == CHROMA420 || nChromaFormat == CHROMA422){
            *nPitLuma = pit;
            *nPitChroma = pit >> 1 ;
        }
        else if( nChromaFormat == CHROMA444 ){
			*nPitLuma = pit;
            *nPitChroma = pit;
        }
        else{
            *nPitLuma = pit;
            *nPitChroma = ( npuv + 32 + 63 ) & ~63;
        }
    }

    stx_inline void vfrmDupInfo(VideoFrame* pDst,VideoFrame* pSrc)
    {
        pDst->dwFlags = vfrmGetFlags(pSrc);
        pDst->nPtf = vfrmGetPtf(pSrc);

        pDst->nFrameRate = pSrc->nFrameRate;
        pDst->ChromaFormat = pSrc->ChromaFormat;    
        pDst->PictureCodingType = pSrc->PictureCodingType;
        pDst->PictureStructure = pSrc->PictureStructure;
        pDst->MotionType = pSrc->MotionType; 
        pDst->DctType = pSrc->DctType;         
        pDst->FlagOutputMode = pSrc->FlagOutputMode;  
        pDst->DisplayMode = pSrc->DisplayMode;     
        pDst->RepeatDisplayTimes = pSrc->RepeatDisplayTimes;  

        pDst->NumberStreamPacket = pSrc->NumberStreamPacket;  
        pDst->NumberPresentUnit = pSrc->NumberPresentUnit;   
        pDst->NumberGroupOfPicture = pSrc->NumberGroupOfPicture;

        pDst->FrameRateCode = pSrc->FrameRateCode; 
        pDst->BitRate = pSrc->BitRate; 
        pDst->nClockMiliSecond = pSrc->nClockMiliSecond;
        pDst->DecodeTimeStamp = pSrc->DecodeTimeStamp; 
        pDst->PresentTimeStamp = pSrc->PresentTimeStamp;
        pDst->dwDisplayWhr = pSrc->dwDisplayWhr;
    }


    stx_inline void  vfrmSetFlags(VideoFrame* pFrame,s32 dwFlags)
    { 
        pFrame->dwFlags = dwFlags;	
    }
    stx_inline s32   vfrmGetFlags(VideoFrame* pFrame)
    {
        return pFrame->dwFlags;	
    }
    stx_inline void  vfrmSetPtf(VideoFrame* pFrame,s32 nPtf)
    {
        pFrame->nPtf = nPtf;	
    }
    stx_inline s32   vfrmGetPtf(VideoFrame* pFrame)
    {
        return pFrame->nPtf;	
    }

    //<< attribute functiosn;>>
    stx_inline b32  vfrmIsEnd(VideoFrame* pFrame)
    {
        return ( pFrame->dwFlags & VIDF_FLAG_END) > 0 ;	
    }
    stx_inline b32  vfrmIsEndSeq(VideoFrame* pFrame)
    {
        return ( pFrame->dwFlags & VIDF_FLAG_ENDSEQ) > 0 ;	
    }
    stx_inline b32  vfrmIsSkipAll(VideoFrame* pFrame){
        return ( pFrame->dwFlags & VIDF_FLAG_SKIP_ALL) > 0 ;	
    }
    stx_inline b32  vfrmIsInPred(VideoFrame* pFrame)
    {
        return ( pFrame->dwFlags & VIDF_FLAG_PRED) > 0 ;	
    }
    stx_inline b32  vfrmIsSkipBot(VideoFrame* pFrame)
    {
        return ( pFrame->dwFlags & VIDF_FLAG_SKIP_BOT) > 0 ;	
    }
    stx_inline b32  vfrmIsSpeedFast(VideoFrame* pFrame)
    {
        return ( pFrame->dwFlags & VIDF_FLAG_SPEED_FAST) > 0 ;	
    }
    stx_inline b32  vfrmIsErr(VideoFrame* pFrame)
    {
        return ( pFrame->dwFlags & VIDF_FLAG_ERR) > 0 ;	
    }
    stx_inline b32  vfrmIsStill(VideoFrame* pFrame)
    {
        return ( pFrame->dwFlags & VIDF_FLAG_STILL) > 0 ;	
    }
    stx_inline b32  vfrmIsHalfWidth(VideoFrame* pFrame)
    {
        return ( pFrame->dwFlags & VIDF_FLAG_HALF_WIDTH) > 0 ;	
    }
    stx_inline b32  vfrmIsHalfHeight(VideoFrame* pFrame)
    {
        return ( pFrame->dwFlags & VIDF_FLAG_HALF_HEIGHT) > 0 ;	
    }
    stx_inline b32  vfrmIsBankSwitch(VideoFrame* pFrame)
    {
        return ( pFrame->dwFlags & VIDF_FLAG_BANK_SWITCH) > 0 ;	
    }
    stx_inline  b32  vfrmIsDisplay(VideoFrame* pFrame)
    {
        return ( pFrame->dwFlags & VIDF_FLAG_DISPLAY) > 0 ;	
    }
    stx_inline b32  vfrmIsDelay(VideoFrame* pFrame)
    {
        return ( pFrame->dwFlags & VIDF_FLAG_DELAY) > 0 ;	
    }
    stx_inline b32  vfrmIsDecoded(VideoFrame* pFrame)
    {
        return ( pFrame->dwFlags & VIDF_FLAG_DECODED) > 0 ;	
    }
    stx_inline b32  vfrmIsUpGradeDisplay(VideoFrame* pFrame)
    {
        return ( pFrame->dwFlags & VIDF_FLAG_DBFREQ) > 0 ;	
    }


    stx_inline void  vfrmSetEnd(VideoFrame* pFrame,b32 bSet)
    { 
        pFrame->dwFlags =  bSet ? ( pFrame->dwFlags | VIDF_FLAG_END) : 
            ( pFrame->dwFlags & ~VIDF_FLAG_END) ;	
    }

    stx_inline void  vfrmSetEndSeq(VideoFrame* pFrame,b32 bSet)
    { 
        pFrame->dwFlags =  bSet ? ( pFrame->dwFlags | VIDF_FLAG_ENDSEQ) : 
            ( pFrame->dwFlags & ~VIDF_FLAG_ENDSEQ) ;	
    }

    stx_inline void  vfrmSetSkipAll(VideoFrame* pFrame,b32 bSet)
    { 
        pFrame->dwFlags =  bSet ? ( pFrame->dwFlags | VIDF_FLAG_SKIP_ALL) : 
            ( pFrame->dwFlags & ~VIDF_FLAG_SKIP_ALL) ;	
    }

    stx_inline void  vfrmSetInPred(VideoFrame* pFrame,b32 bSet)
    { 
        pFrame->dwFlags =  bSet ? ( pFrame->dwFlags | VIDF_FLAG_PRED) : 
            ( pFrame->dwFlags & ~VIDF_FLAG_PRED) ;	
    }

    stx_inline void  vfrmSetSkipBot(VideoFrame* pFrame,b32 bSet)
    { 
        pFrame->dwFlags =  bSet ? ( pFrame->dwFlags | VIDF_FLAG_SKIP_BOT) : 
            ( pFrame->dwFlags & ~VIDF_FLAG_SKIP_BOT) ;	
    }

    stx_inline void  vfrmSetSpeedFast(VideoFrame* pFrame,b32 bSet)
    { 
        pFrame->dwFlags =  bSet ? ( pFrame->dwFlags | VIDF_FLAG_SPEED_FAST) : 
            ( pFrame->dwFlags & ~VIDF_FLAG_SPEED_FAST) ;	
    }

    stx_inline void  vfrmSetErr(VideoFrame* pFrame,b32 bSet)
    { 
        pFrame->dwFlags =  bSet ? ( pFrame->dwFlags | VIDF_FLAG_ERR) : 
            ( pFrame->dwFlags & ~VIDF_FLAG_ERR) ;	
    }	

    stx_inline void  vfrmSetStill(VideoFrame* pFrame,b32 bSet)
    { 
        pFrame->dwFlags = bSet ? ( pFrame->dwFlags | VIDF_FLAG_STILL) :  
            ( pFrame->dwFlags & ~VIDF_FLAG_STILL) ;	
    }

    stx_inline void  vfrmSetHalfWidth(VideoFrame* pFrame,b32 bSet)
    { 
        pFrame->dwFlags = bSet ? ( pFrame->dwFlags | VIDF_FLAG_HALF_WIDTH) : 
            ( pFrame->dwFlags & ~VIDF_FLAG_HALF_WIDTH) ;	
    }

    stx_inline  void  vfrmSetHalfHeight(VideoFrame* pFrame,b32 bSet)
    { 
        pFrame->dwFlags =  bSet ? ( pFrame->dwFlags | VIDF_FLAG_HALF_HEIGHT) : 
            ( pFrame->dwFlags & ~VIDF_FLAG_HALF_HEIGHT) ;	
    }

    stx_inline void  vfrmSetBankSwitch(VideoFrame* pFrame,b32 bSet){ 
        pFrame->dwFlags =  bSet ? ( pFrame->dwFlags | VIDF_FLAG_BANK_SWITCH) : 
            ( pFrame->dwFlags & ~VIDF_FLAG_BANK_SWITCH) ;	
    }

    stx_inline void  vfrmSetDisplay(VideoFrame* pFrame,b32 bSet)
    { 
        pFrame->dwFlags = bSet ? ( pFrame->dwFlags |  VIDF_FLAG_DISPLAY) : 
            ( pFrame->dwFlags & ~VIDF_FLAG_DISPLAY);	
    }

    stx_inline void  vfrmSetDelay(VideoFrame* pFrame,b32 bSet){ 
        pFrame->dwFlags =  bSet ? ( pFrame->dwFlags | VIDF_FLAG_DELAY) : 
            ( pFrame->dwFlags & ~VIDF_FLAG_DELAY );	
    }

    stx_inline void  vfrmSetDecoded(VideoFrame* pFrame,b32 bSet){ 
        pFrame->dwFlags =  bSet ? ( pFrame->dwFlags | VIDF_FLAG_DECODED) : 
            ( pFrame->dwFlags & ~VIDF_FLAG_DECODED );	
    }


    stx_inline void  vfrmSetUpGradeDisplay(VideoFrame* pFrame,b32 bSet){ 
        pFrame->dwFlags =  bSet ? ( pFrame->dwFlags | VIDF_FLAG_DBFREQ) : 
            ( pFrame->dwFlags & ~VIDF_FLAG_DBFREQ );	
    }
    //<< attribute functions;>>



#endif // __STX_VIDEO_FRAME_H__