
#ifndef __STX_DLL_H__
#define __STX_DLL_H__

/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/



#include "stx_base_type.h"


#if defined( __cplusplus )
extern "C" {
#endif


typedef struct stx_dll stx_dll;


struct stx_dll {

	_STX_PURE	STX_RESULT  (*load_library)( STX_HANDLE h, char* sz_dll );

	_STX_PURE	void		(*close)(STX_HANDLE h );

	_STX_PURE	void*		(*entry_by_name)(STX_HANDLE h , char* sz_name);

	_STX_PURE	void*		(*entry_by_index)(STX_HANDLE h, int i_index);
};


stx_dll* stx_dll_create();

stx_dll* stx_dll_create_ex();



#if defined( __cplusplus )
}
#endif



#endif /*__STX_DLL_H__*/ 