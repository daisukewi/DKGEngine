

#ifndef __STX_SEMAPHORE_H__
#define __STX_SEMAPHORE_H__

/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#include "stx_base_type.h"


#if defined( __cplusplus )
extern "C" {
#endif


STX_HANDLE	stx_semaphore_create(
    STX_HANDLE	lpSemaphoreAttributes,
    int32_t		lInitialCount,
    int32_t		lMaximumCount,
    char*		lpName
    );

uint32_t	stx_semaphore_wait( STX_HANDLE h_semaphore, uint32_t i_wait_time );

uint32_t	stx_semaphore_release(
	STX_HANDLE h_semaphore, uint32_t i_release_count, uint32_t* i_prev_count );

void		stx_semaphore_destory(STX_HANDLE h_semaphore);



#if defined( __cplusplus )
}
#endif


#endif	/*__STX_SEMAPHORE_H__*/