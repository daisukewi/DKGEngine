
#ifndef __STX_CONFIG_H__
#define __STX_CONFIG_H__

/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#if defined( __cplusplus )
extern "C" {
#endif

#define __USE_STX_DEBUG__

/******************************************************************
place this code at beginning of each source file ;
#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif
******************************************************************/


#if defined(WIN32) || defined(WIN64)
#	define __WIN32_LIB
#endif


#ifdef __linux__  
#	define __LINUX_LIB
#	define __USE_GNUC
#endif


#if defined(WIN64) || defined(__Linux64__)
#	define STX64
#endif
	
#ifndef HAVE_MMX
#	define HAVE_MMX
#endif


#define HAVE_CMOV


//#define __ENABLE_SSSE3
//#define __ENALBE_SSE41


#ifdef __ICC
#	define DECLARE_ALIGNED(n,t,v)      t v __attribute__ ((aligned (n)))
#	define DECLARE_ASM_CONST(n,t,v)    const t __attribute__ ((aligned (n))) v
#elif defined(__GNUC__)
#	define DECLARE_ALIGNED(n,t,v)      t v __attribute__ ((aligned (n)))
#	define DECLARE_ASM_CONST(n,t,v)    static const t v attribute_used __attribute__ ((aligned (n)))
#elif defined(_MSC_VER)
#	define DECLARE_ALIGNED(n,t,v)      __declspec(align(n)) t v
#	define DECLARE_ASM_CONST(n,t,v)    __declspec(align(n)) static const t v
#	elif defined(HAVE_INLINE_ASM)
#	error The asm code needs alignment, but we do not know how to do it for this compiler.
#else
#	define DECLARE_ALIGNED(n,t,v)      t v
#	define DECLARE_ASM_CONST(n,t,v)    static const t v
#endif


#if defined( __cplusplus )
}
#endif


#endif /*__STX_CONFIG_H__*/ 
