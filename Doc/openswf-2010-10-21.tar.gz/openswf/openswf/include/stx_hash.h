/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-11
***********************************************************************************/
#ifndef __STX_HASH_H__
#define __STX_HASH_H__

#include "stx_base_type.h"

#if defined( __cplusplus )
extern "C" {
#endif


	THEE		stx_hash_create(u32 i_max_size);
	void		stx_hash_close(THEE h );
	void		stx_hash_rem_all(THEE h);

	STX_RESULT	stx_hash_add(THEE h,THEE h_obj,size_t key);
	STX_RESULT	stx_hash_write(THEE h,THEE h_obj,size_t key);
	THEE		stx_hash_find(THEE h,size_t key);
	THEE		stx_hash_rem(THEE h,size_t key);

	STX_RESULT	stx_hash_add_byname(THEE h,THEE h_obj,const char* sz_name);
	STX_RESULT	stx_hash_write_byname(THEE h,THEE h_obj,const char* sz_name);
	THEE		stx_hash_find_byname(THEE h,const char* sz_name);
	THEE		stx_hash_rem_byname(THEE h,const char* sz_name);

	STX_RESULT	stx_hash_add_ex(THEE h,u8* p_data,s32 i_len,size_t key);
	STX_RESULT	stx_hash_write_ex(THEE h,u8* p_data,s32 i_len,size_t key);
	u8*			stx_hash_find_ex(THEE h,size_t key,s32* i_len);

	STX_RESULT	stx_hash_add_ex_byname(THEE h,u8* p_data,s32 i_len,const char* sz_name);
	STX_RESULT	stx_hash_write_ex_byname(THEE h,u8* p_data,s32 i_len,const char* sz_name);
	u8*			stx_hash_find_ex_byname(THEE h,const char* sz_name,s32* i_len);

	s32			compute_hash(THEE h,size_t i_key);
	s32			compute_hash_byname(THEE h,const char* sz_input);

	THEE		stx_hash_find_first(THEE h);
	THEE		stx_hash_find_next(THEE h);

	s32			stx_hash_size(THEE h);


	void hash_test(b32 b_string,s32 SAMPLE,void (*logout)(const char *fmt, ... ));

#if defined( __cplusplus )
}
#endif

#endif // __STX_HASH_H__




