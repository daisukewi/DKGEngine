/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/


#ifndef __BASE_INTERF_H__
#define __BASE_INTERF_H__



#include "stx_base_type.h"
#include "stx_stack.h"
#include "stx_gid.h"
#include "stx_io.h"
#include "stx_ini.h"
#include "stx_msg_def.h"
#include "stx_mem.h"
#include "stx_thread.h"



#if defined( __cplusplus )
extern "C" {
#endif


#ifdef __USE_GNUC
#	define XCALL(name,h,args...) h->name(h,## args)
#	define SAFE_XCALL(name,h,args...) if( h ) h->name(h,## args)
#	define SAFE_CALL(name,h,args...) if( h ) name(h,## args)
#else
#	define XCALL(name,h,...) h->name(h,## __VA_ARGS__)
#	define SAFE_XCALL(name,h,...) if( h ) h->name(h,## __VA_ARGS__)
#	define SAFE_CALL(name,h,...) if( h ) name(h,## __VA_ARGS__)
#endif

STX_INTERF(stx_msg_cnt);

STX_INTERF(stx_base_com);

STX_INTERF(stx_base_message);

STX_INTERF(stx_base_plugin);

STX_INTERF(stx_base_graph);

STX_INTERF(stx_base_graph_builder);

STX_INTERF(stx_media_type);

STX_INTERF(stx_media_data);

STX_INTERF(stx_media_data_allocator);

STX_INTERF(stx_base_pin);

STX_INTERF(stx_output_pin);

STX_INTERF(stx_base_filter);

STX_INTERF(stx_base_control);

STX_INTERF(stx_speed_control);

STX_INTERF(stx_base_source);

STX_INTERF(stx_base_render);

STX_INTERF(stx_base_player);

STX_INTERF(stx_media_info);

STX_INTERF(stx_video_render);

STX_INTERF(stx_audio_render);

STX_INTERF(stx_stream_writer);

STX_INTERF(stx_stream_parser);

STX_INTERF(stx_smart_tee);

STX_INTERF(stx_base_module);

STX_INTERF(stx_video_device);

STX_INTERF(stx_audio_device);

STX_INTERF(stx_msg_param);

STX_INTERF(async_plugin);

STX_INTERF(stx_sync_source);



STX_INTERF(stx_sync_inf);

struct stx_sync_inf{
	THEE				h_task;			// in
	size_t				i_flags;		// in

#define STX_DELIVER 0x01
#define STX_REPEAT  0x02
#define STX_SUBTASK 0x04
#define STX_STEP    0x08
	size_t				i_result;		// out;

	s64					i_idle;	// out, REF TIME;
	THEE				h_data;	// in,out
	THEE				h_stack;
	stx_sync_source*	h_ssrc;
};

#define RESET_XENTRY(h_sync,p) \
	if( h_sync->h_stack ){ \
		stx_stack_push(h_sync->h_stack,(size_t)p);\
	}


STX_INTERF(stx_media_type_inf);

struct stx_media_type_inf{
	stx_gid		major_type;
	stx_gid		sub_type;
	char**		major_type_name;
	char**		sub_type_name;
};

#define MAX_MEDIA_TYPE  0x0FFFFFFFF

STX_INTERF(stx_media_type_map);

struct stx_media_type_map{
	stx_gid*	major_type;
	stx_gid*	sub_type;
	char**		major_type_name;
	char**		sub_type_name;
};

/*****************************************************************************
*****************************************************************************/
struct stx_msg_param{
	size_t    i_param[4];
};

/*****************************************************************************
*****************************************************************************/
struct stx_msg_cnt{
	stx_gid			msg_gid;
	stx_msg_param	param;
};

/*****************************************************************************
*****************************************************************************/
#define stx_base_com_vtdef() \
	_STX_PURE STX_RESULT (*query_interf)( STX_HANDLE h, stx_gid gid, STX_HANDLE* p_interf );\
	_STX_PURE s32		 (*add_ref)( STX_HANDLE h );\
	_STX_PURE s32		 (*release)( STX_HANDLE h );\


struct stx_base_com{
	stx_base_com_vtdef()
};




/*****************************************************************************
*****************************************************************************/
#define STX_MSG_TYPE_DOWNSTREAM 0x01
#define STX_MSG_TYPE_UPSTREAM   0x02
#define STX_MSG_TYPE_BLOCK	    0x04
#define STX_MSG_TYPE_ASYNC		0x08
#define STX_MSG_TYPE_DIRECT		0x10

#define STX_MAX_PLUGINS			128


#define stx_base_message_vtdef() \
	stx_base_com_vtdef()\
	_STX_PURE STX_RESULT	(*set_msg_src)(STX_HANDLE h, stx_gid cls_gid );\
	_STX_PURE STX_RESULT	(*set_msg_dest)(STX_HANDLE h, stx_gid cls_gid );\
	_STX_PURE STX_RESULT	(*set_msg_type)(STX_HANDLE h, u32 i_type );\
	_STX_PURE STX_RESULT	(*set_msg_name)(STX_HANDLE h, char* sz_name );\
	_STX_PURE STX_RESULT	(*set_msg_text)(STX_HANDLE h, char* sz_txt );\
	_STX_PURE void			(*set_msg_cnt)( STX_HANDLE h, stx_msg_cnt* p_cnt );\
	_STX_PURE void			(*set_msg_time_out)(STX_HANDLE h, u32 i_wait_time);\
	_STX_PURE void			(*set_msg_close)( STX_HANDLE h);\
	_STX_PURE b32           (*is_msg_closed)(STX_HANDLE h);\
	_STX_PURE STX_RESULT	(*wait)(STX_HANDLE h );\
	_STX_PURE stx_gid		(*get_msg_src)(STX_HANDLE h );\
	_STX_PURE stx_gid		(*get_msg_dest)(STX_HANDLE h );\
	_STX_PURE u32			(*get_msg_type)(STX_HANDLE h );\
	_STX_PURE char*			(*get_msg_name)(STX_HANDLE h );\
	_STX_PURE char*			(*get_msg_text)(STX_HANDLE h );\
	_STX_PURE stx_msg_cnt*	(*get_msg_cnt)( STX_HANDLE h );\
	_STX_PURE u32			(*get_msg_time_out)(STX_HANDLE h );\
	_STX_PURE void			(*signal)(STX_HANDLE h);\
	_STX_PURE STX_RESULT	(*set_msg_buf)(STX_HANDLE h, u8* buf, s32 i_len );\
	_STX_PURE u8*			(*get_msg_buf)(STX_HANDLE h, s32* i_len );\
	_STX_PURE STX_RESULT	(*set_stack)(STX_HANDLE h );\
	_STX_PURE STX_HANDLE	(*get_stack)(STX_HANDLE h );\


struct stx_base_message{
	stx_base_message_vtdef()
};




/*****************************************************************************
interface stx_base_plugin
<run> method: parameters < (s64) h_sync->i_flags > , input value is defined below;
*****************************************************************************/
#define CALL_TYPE_NOT_USED	0
#define CALL_TYPE_AS		1
#define CALL_TYPE_INIT		2

#define CALL_GBD_RUN_START  0
#define CALL_GBD_RUN_STOP   1

#define stx_base_plugin_vtdef() \
	stx_base_com_vtdef()\
	_STX_PURE void				(*set_user_data)(STX_HANDLE h, STX_HANDLE h_data);\
	_STX_PURE STX_HANDLE		(*get_user_data)(STX_HANDLE h);\
	_STX_PURE STX_RESULT        (*set_property)(STX_HANDLE h,stx_xio* h_xio);\
	_STX_PURE STX_RESULT        (*get_property)(STX_HANDLE h,stx_xio* h_xio);\
	_STX_PURE STX_RESULT		(*set_gbd)( STX_HANDLE h, stx_base_graph_builder* h_gbd );\
	_STX_PURE stx_base_graph_builder*	(*get_gbd)( STX_HANDLE h);\
	_STX_PURE void				(*set_ssrc)( STX_HANDLE h, stx_sync_source* h_ssrc );\
	_STX_PURE stx_sync_source*	(*get_ssrc)( STX_HANDLE h);\
	_STX_PURE void				(*set_parent)( STX_HANDLE h, stx_base_plugin* p_parent );\
	_STX_PURE stx_base_plugin*	(*get_parent)( STX_HANDLE h );\
	_STX_PURE STX_RESULT		(*set_name)( STX_HANDLE h, const char* sz_name);\
	_STX_PURE char*				(*get_name)( STX_HANDLE h);\
	_STX_PURE void    			(*set_clsid)( STX_HANDLE h, stx_gid clsid);\
	_STX_PURE stx_gid			(*get_clsid)( STX_HANDLE h);\
	_STX_PURE void   			(*set_catid)( STX_HANDLE h,stx_gid catid);\
	_STX_PURE stx_gid			(*get_catid)( STX_HANDLE h);\
	_STX_PURE void    			(*set_insid)( STX_HANDLE h, stx_gid insid);\
	_STX_PURE stx_gid			(*get_insid)( STX_HANDLE h);\
	_STX_PURE STX_RESULT		(*set_clsid_name)( STX_HANDLE h, const char* sz_name);\
	_STX_PURE char*				(*get_clsid_name)( STX_HANDLE h);\
	_STX_PURE STX_RESULT		(*set_catid_name)( STX_HANDLE h,const char* sz_name);\
	_STX_PURE char*				(*get_catid_name)( STX_HANDLE h);\
	_STX_PURE STX_RESULT		(*send_msg)( STX_HANDLE h, stx_base_message* p_msg );\
	_STX_PURE STX_RESULT		(*run)(STX_HANDLE h, stx_sync_inf* h_sync);\
	_STX_PURE stx_com_status	(*get_status)(STX_HANDLE h);\
	_STX_PURE void				(*set_status)(STX_HANDLE h,stx_com_status em_status);\
	_STX_PURE STX_RESULT		(*start)(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync);\
	_STX_PURE STX_RESULT		(*flush)(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync);\
	_STX_PURE STX_RESULT		(*stop)(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync);\
	_STX_PURE stx_gid			(*get_uuid)( STX_HANDLE h);\
	_STX_PURE STX_RESULT		(*reg_key)(THEE h, stx_gid keyid,s32 i_len);\
	_STX_PURE void				(*rem_key)(THEE h, stx_gid keyid);\
	_STX_PURE STX_RESULT		(*write_key)(THEE h, stx_gid keyid,u8* data, s32 i_len);\
	_STX_PURE u8*				(*read_key)(THEE h, stx_gid keyid,s32* i_len);\
	/* all the extend features could be add through message;*/


struct stx_base_plugin{
	stx_base_plugin_vtdef()
};


/*****************************************************************************
*****************************************************************************/
#define stx_base_graph_vtdef() \
	stx_base_plugin_vtdef()\
	/* to find a source filter match the file name; */\
	_STX_PURE STX_RESULT (*connect)(\
		STX_HANDLE h, stx_base_pin* p_out,stx_base_pin* p_in );\
	/* auto build graph; when do rend output pins, first check the filter added in the graph;*/\
	_STX_PURE STX_RESULT (*rend_file)( STX_HANDLE h, char* sz_file_name );\
	/* rend the output pin; when do rend output pins, first check the filter added in the graph;*/\
	_STX_PURE STX_RESULT (*rend_pin)( STX_HANDLE h, stx_base_pin* p_out );\
	/* auto build graph from source filter added in the graph; */\
	/* when do rend output pins, first check the filter added in the graph; */\
	_STX_PURE STX_RESULT (*rend)( STX_HANDLE h );\
	_STX_PURE STX_RESULT (*enum_plugin)( STX_HANDLE h, size_t* i_index, stx_base_plugin** pp_plugin );\
	_STX_PURE STX_RESULT (*add_plugin)( STX_HANDLE h, stx_base_plugin* p_plugin );\
	_STX_PURE STX_RESULT (*remove_plugin)( STX_HANDLE h, const char* sz_name );\
	_STX_PURE STX_RESULT (*find_plugin)( STX_HANDLE h, stx_base_plugin** pp_plugin,const char* sz_name );\
	_STX_PURE STX_RESULT (*add_source)(\
		STX_HANDLE h, char* sz_file_name, stx_base_com** pp_src );\
	_STX_PURE STX_RESULT (*find_source)( STX_HANDLE h, stx_base_com** pp_plugin,stx_media_type_inf media_inf );\
	_STX_PURE STX_RESULT (*find_render)( STX_HANDLE h, stx_base_com** pp_plugin,stx_media_type_inf media_inf );\
	_STX_PURE STX_RESULT (*connect_direct)(\
		STX_HANDLE h, stx_base_pin* p_out,stx_base_pin* p_in, stx_media_type* p_mt );\
	_STX_PURE STX_RESULT (*disconnect)(STX_HANDLE h, stx_base_pin* p_pin);\


struct stx_base_graph{
	stx_base_graph_vtdef()
};




/*****************************************************************************
*****************************************************************************/
#define stx_base_graph_builder_vtdef() \
	stx_base_plugin_vtdef()\
	_STX_PURE STX_RESULT	(*create_graph)(THEE h,stx_base_graph** h_graph);\
	_STX_PURE STX_RESULT	(*detach_graph)(THEE h,stx_base_graph* h_graph);\
	_STX_PURE s32			(*get_max_subtask)(THEE h);\
	_STX_PURE STX_RESULT	(*enum_ssrc)(THEE h,s32* i_idx,stx_sync_source** hh);\
	_STX_PURE STX_RESULT	(*alloc_ssrc)\
	(THEE h,b32 b_cpu,stx_sync_source* h_ori,s32 i_ssrc,stx_sync_source* hh_alloc[]);\
	_STX_PURE STX_RESULT	(*reg_plug)(THEE h,stx_base_plugin* plug);\
	_STX_PURE void			(*unreg_plug)(THEE h,stx_base_plugin* plug);\
	_STX_PURE u32			(*get_occupy)(THEE h)


STX_INTERF(stx_reg_stream_ctx);
struct stx_reg_stream_ctx {
	stx_gid*	major_type;
	stx_gid*	sub_type;
	char		sz_major_name[64];
	char		sz_sub_name[64];
	char		sz_ext[256];
};

STX_INTERF(stx_connect_ctx);
struct stx_connect_ctx {
	_STX_PURE	void		(*release)(THEE h);
	_STX_PURE	STX_RESULT	(*add_skip_cls_gid)( THEE h, stx_gid cls_gid );
	_STX_PURE	STX_RESULT	(*rem_skip_cls_gid)( THEE h, stx_gid cls_gid );
	_STX_PURE	int32_t		(*get_skip_cls_num)( THEE h );
	_STX_PURE	STX_RESULT  (*get_skip_cls_gid)(THEE h, int i_idx, stx_gid* cls_gid );
	_STX_PURE	STX_RESULT	(*add_con_cls_gid)( THEE h, stx_gid cls_gid );
	_STX_PURE	STX_RESULT	(*rem_con_cls_gid)( THEE h, stx_gid cls_gid );
	_STX_PURE	s32			(*get_con_cls_num)( THEE h );
	_STX_PURE	STX_RESULT  (*get_con_cls_gid)(THEE h, int i_idx, stx_gid* cls_gid );
	_STX_PURE	STX_RESULT	(*set_cur_cls_cat)( THEE h, stx_gid cat_gid );
	_STX_PURE	STX_RESULT	(*set_cur_cls_desc)( THEE h, char* sz_desc);
	_STX_PURE   STX_RESULT  (*get_cur_cls_cat)( THEE h, stx_gid* cat_gid );
	_STX_PURE   char*		(*get_cur_cls_desc)( THEE h );
	_STX_PURE	STX_RESULT	(*set_cur_cls_gid)( THEE h, stx_gid cls_gid );
	_STX_PURE	STX_RESULT  (*get_cur_cls_gid)( THEE h, stx_gid* cls_gid );
	_STX_PURE	STX_RESULT	(*set_cur_cls_pin_num)( THEE h, int i_pin_num );
	_STX_PURE	STX_RESULT	(*set_cur_cls_pin_type)( 
		THEE h, int i_idx, stx_gid major_gid, stx_gid sub_gid );
	_STX_PURE	int32_t		(*get_cur_cls_pin_num)( THEE h );
	_STX_PURE	STX_RESULT  (*get_cur_cls_type)(
		THEE h, int i_idx, stx_gid* major_gid, stx_gid* sub_gid);
};

STX_INTERF(stx_reg_find_ctx);
struct stx_reg_find_ctx {
	stx_gid		cls_gid;
	stx_gid		cat_gid;
	stx_gid		major_type;
	stx_gid		sub_type;
	stx_gid		major_type_out;
	stx_gid		sub_type_out;
	u32			i_find_flags;
	char		sz_text[256];
};

#define STX_REG_FIND_SRC						0x01
#define STX_REG_FIND_REN						0x02
#define STX_REG_FIND_FILTER						0x04
#define STX_REG_FIND_BY_CATEGORY				0x08
#define STX_REG_FIND_BY_CATEGORY_DESC			0x10
#define STX_REG_FIND_BY_OUTPUT_MDTYPE			0x20
#define STX_REG_FIND_BY_INPUT_MDTYPE			0x40
#define STX_REG_FIND_BY_EXTENSION				0x80

struct stx_base_graph_builder{
	stx_base_graph_builder_vtdef();

	// callback api;
	STX_API STX_RESULT  (*co_query_obj)(THEE h, stx_gid cls_gid ,  char** sz_dll_path );
	STX_API STX_RESULT  (*co_create_obj)(THEE h, stx_gid cls_gid ,  stx_base_com** pp_com );
	STX_API STX_RESULT  (*co_create_obj_svr)
		(THEE h, stx_gid cls_gid , char* sz_svr, stx_base_com** pp_com );
	STX_API STX_RESULT	(*get_svr_inf)(THEE h, char* sz_svr, stx_xini* h_xini );
	STX_API STX_RESULT	(*get_filter_inf)(THEE h, stx_base_filter* p_flt, stx_xini* h_xini );
	STX_API STX_RESULT	(*reg_svr)(THEE h, char* sz_svr );
	STX_API STX_RESULT  (*unreg_svr)(THEE h, char* sz_svr );

	STX_API STX_RESULT	(*reg_protocol)(THEE h, char* sz_svr );
	STX_API STX_RESULT  (*unreg_protocol)(THEE h, char* sz_svr );

	STX_API void		(*unregister_module_as)(THEE h,THEE h_dat);
	STX_API STX_RESULT	(*reg_query_input_type)
		( 
		THEE h,
		stx_gid				major_type, 
		stx_gid				sub_type,
		stx_connect_ctx*	p_con_ctx 
		);
	STX_API STX_RESULT	(*reg_query_src_ext)
		( 
		THEE h,
		char*				sz_ext, 
		stx_connect_ctx*	p_con_ctx 
		);
	STX_API STX_RESULT	(*reg_query_src_type)
		( 
		THEE h,
		stx_gid				major_type,
		stx_gid				sub_type,
		stx_connect_ctx*	p_con_ctx 
		);
	STX_API STX_RESULT	(*reg_query_ren_type)
		( 
		THEE h,
		stx_gid				major_type,
		stx_gid				sub_type,
		stx_connect_ctx*	p_con_ctx 
		);
	STX_API STX_RESULT	(*reg_query_cat_desc)
		( 
		THEE h,
		stx_gid				cat_gid,
		char*				sz_cat_desc,
		stx_connect_ctx*	p_con_ctx 
		);
	STX_API STX_RESULT	(*reg_query_flt_type)
		( 
		THEE h,
		stx_gid				major_type_in,
		stx_gid				sub_type_in,
		stx_gid				major_type_out,
		stx_gid				sub_type_out,
		stx_connect_ctx*	p_con_ctx 
		);
	STX_API STX_RESULT  (*reg_stream)(	THEE h,stx_reg_stream_ctx* h_stream);
	STX_API STX_RESULT  (*unreg_stream)(THEE h,stx_reg_stream_ctx* h_stream);
	/***********************************************************************************
	stx_reg_find_ctx
	parameters struct used in STX_API
	stx_reg_find_class
	stx_reg_find_next
	stx_reg_find_close
	***********************************************************************************/
	STX_API STX_RESULT	(*reg_find_class)(THEE h,stx_reg_find_ctx* h_find_ctx,THEE* h_find);
	STX_API STX_RESULT	(*reg_find_next)(THEE h,stx_reg_find_ctx* h_find_ctx,THEE h_find);
	STX_API void		(*reg_find_close)(THEE h,STX_HANDLE h_find);
	STX_API STX_RESULT  (*reg_stream_default)(THEE h);
	STX_API STX_RESULT  (*unreg_stream_default)(THEE h);

	STX_API STX_RESULT	(*create_thread)
		(
			THEE			h_param,	// thread proc param void*
			THEE			h_proc,		// thread proc
			stx_thread*		h_thread 
		);

	STX_API void		(*close_thread)(stx_thread* h_thread);

	STX_API STX_RESULT	(*set_main_data)(THEE h,THEE h_module,THEE h_dat);
	STX_API THEE		(*get_main_data)(THEE h,THEE h_module);
	STX_API stx_thread* (*get_cur_thread)(THEE h);

	STX_API STX_RESULT	(*reg_dlib)(THEE h, char* sz_svr );
	STX_API STX_RESULT  (*unreg_dlib)(THEE h, char* sz_svr );

};


/*****************************************************************************
*****************************************************************************/
#define stx_media_type_vtdef() \
	stx_base_com_vtdef()\
	_STX_PURE void			(*set_type)( STX_HANDLE h, stx_gid gid_type );\
	_STX_PURE stx_gid		(*get_type)( STX_HANDLE h);\
	_STX_PURE void 			(*set_subtype)( STX_HANDLE h, stx_gid gid_sub_type );\
	_STX_PURE stx_gid		(*get_subtype)( STX_HANDLE h);\
	_STX_PURE STX_RESULT	(*get_header)( STX_HANDLE h , void** pp_hdr, s32* i_len );\
	_STX_PURE STX_RESULT	(*set_header)( STX_HANDLE h, void* p_hdr, s32 i_len );\
	_STX_PURE void			(*set_type_name)( STX_HANDLE h, const char* sz_name );\
	_STX_PURE const char*	(*get_type_name)( STX_HANDLE h);\
	_STX_PURE void			(*set_subtype_name)( STX_HANDLE h, const char* sz_name );\
	_STX_PURE const char*	(*get_subtype_name)( STX_HANDLE h);\

struct stx_media_type{
	stx_media_type_vtdef()
};




/*****************************************************************************
The REFERENCE_TIME data type defines the units for reference time. 
Each unit of reference time is 100 nanoseconds
ref_time : 100 * ( 1 second / 1000*1000*1000 )
ns : ref_time * 100 
us : ref_time / 10
ms : ref_time / (10*1000)
s  : ref_time / (10*1000*1000)
pts/dts : ref_time * 90 / (10*1000)
*****************************************************************************/
#define KEY_FRAME		0x01
#define START_FRAME		0x02

#define stx_media_data_vtdef() \
	stx_base_com_vtdef() \
	_STX_PURE size_t		(*get_buf)( STX_HANDLE h, void** pp_data);\
	_STX_PURE STX_RESULT	(*resize)( STX_HANDLE h, size_t i_new_size );\
	_STX_PURE STX_RESULT	(*get_data)( STX_HANDLE h, void** pp_cur,size_t* i_data_size );\
	_STX_PURE STX_RESULT	(*set_data)( STX_HANDLE h, u8* p_cur, size_t i_len );\
	_STX_PURE STX_RESULT	(*set_time)( STX_HANDLE h, s64 i_pts,s64 i_dts );\
	_STX_PURE s64			(*get_time)( STX_HANDLE h, s64* i_dts );\
	_STX_PURE STX_RESULT	(*set_duration)( STX_HANDLE h, s64 i_duration);\
	_STX_PURE s64			(*get_duration)( STX_HANDLE h );\
	_STX_PURE STX_RESULT	(*set_flags)( STX_HANDLE h, size_t i_flags );\
	_STX_PURE size_t		(*get_flags)( STX_HANDLE h );\
	_STX_PURE s32			(*incr)( THEE h );\
	_STX_PURE s32			(*decr)( THEE h );\

struct stx_media_data{
	stx_media_data_vtdef()
};



/*****************************************************************************
*****************************************************************************/
#define stx_media_data_allocator_vtdef() \
	stx_base_com_vtdef() \
	_STX_PURE STX_RESULT	(*set_param)( STX_HANDLE h, void* param, s32 i_len );\
	_STX_PURE STX_RESULT	(*get_param)( STX_HANDLE h, void* param , s32* i_len );\
	_STX_PURE STX_RESULT	(*reset)(STX_HANDLE h);\
	_STX_PURE STX_RESULT	(*get_media_data)( STX_HANDLE h, stx_media_data** pp_mda, s32 i_wait );\
	_STX_PURE STX_RESULT	(*free_media_data)( STX_HANDLE h, stx_media_data* p_mda );\

struct stx_media_data_allocator{
	stx_media_data_allocator_vtdef()
};




/*****************************************************************************
*****************************************************************************/
#define stx_base_pin_vtdef() \
	stx_base_plugin_vtdef() \
	_STX_PURE STX_BOOL			(*is_connected)( THEE h ,stx_base_pin** pp_pin);\
	_STX_PURE STX_RESULT		(*connect)( THEE h, stx_base_pin* p_pin );\
	_STX_PURE STX_RESULT		(*break_connect)( THEE h );\
	_STX_PURE stx_media_type*	(*get_media_type)( THEE h );\
	_STX_PURE STX_RESULT		(*set_media_type)( THEE h, stx_media_type* p_mtype );\
	_STX_PURE STX_RESULT		(*receive)(THEE h, stx_media_data** pp_mdat,stx_sync_inf* h_sync);\
	_STX_PURE STX_RESULT		(*deliver)(THEE h, stx_media_data* p_mdat,stx_sync_inf* h_sync);\
	_STX_PURE STX_RESULT		(*get_media_data)(THEE h, stx_media_data** pp_mdat, s32 i_wait );\
	_STX_PURE STX_RESULT		(*release_media_data)( THEE h, stx_media_data* p_mdat );

struct stx_base_pin{
	stx_base_pin_vtdef()
};




/*****************************************************************************
*****************************************************************************/

#define stx_output_pin_vtdef() \
	stx_base_pin_vtdef()\
	_STX_PURE STX_RESULT (*set_mem_allocator)( STX_HANDLE h, stx_media_data_allocator* p_alloc );\
	_STX_PURE stx_media_data_allocator*	(*get_mem_allocator)( STX_HANDLE h );


struct stx_output_pin{
	stx_output_pin_vtdef()
};



/*****************************************************************************
*****************************************************************************/
#define FLT_DELIVER_NROMAL 0
#define FLT_DELIVER_FLUSH  1



#define stx_base_filter_vtdef() \
	stx_base_plugin_vtdef() \
	_STX_PURE STX_RESULT	(*enum_input_pin)(THEE h,s32* i_index,stx_base_pin** pp_pin);\
	_STX_PURE STX_RESULT	(*enum_output_pin)(THEE h,s32* i_index,stx_base_pin** pp_pin);\
	_STX_PURE STX_RESULT	(*enum_input_media_type)(THEE h,s32* i_index,stx_media_type_inf* p_inf );\
	_STX_PURE STX_RESULT	(*check_input_media_type)(THEE h,stx_media_type* p_mtype );\
	_STX_PURE STX_RESULT	(*set_input_media_type)(THEE h, stx_media_type* p_mtype );\
	_STX_PURE STX_RESULT	(*enum_output_media_type)(THEE h,s32* i_index,stx_media_type_inf* p_inf );\
	_STX_PURE STX_RESULT	(*check_output_media_type)(THEE h,stx_media_type* p_mtype );\
	_STX_PURE STX_RESULT	(*set_output_media_type)(THEE h,stx_media_type* p_mtype );\
	_STX_PURE STX_RESULT	(*new_segment)( THEE h );\
	_STX_PURE STX_RESULT	(*receive)( \
		THEE				h, \
		stx_base_pin*		h_pin, \
		stx_media_data**	pp_mdat,stx_sync_inf* h_sync\
		);\
	_STX_PURE STX_RESULT	(*deliver)(\
		THEE				h, \
		stx_base_pin*		h_pin, \
		stx_media_data*		p_mdat,stx_sync_inf* h_sync\
		);

struct stx_base_filter{
	stx_base_filter_vtdef()
};





/*****************************************************************************
*****************************************************************************/
#define STX_SET_FLAG_POS			1
#define STX_SET_FLAG_TIME			2
#define STX_SET_FLAG_CHAPTER		3
#define STX_SET_FLAG_TITLE			4

#define stx_base_control_vtdef() \
	stx_base_com_vtdef() \
	_STX_PURE STX_RESULT	(*get_caps)(STX_HANDLE h,stx_xio* h_xio);\
	_STX_PURE STX_RESULT	(*get_status)(STX_HANDLE h,u32* i_status);\
	_STX_PURE STX_RESULT	(*play)(STX_HANDLE h);\
	_STX_PURE STX_RESULT	(*pause)(STX_HANDLE h);\
	_STX_PURE STX_RESULT	(*resume)(STX_HANDLE h);\
	_STX_PURE STX_RESULT	(*set)(STX_HANDLE h,u32 i_flag,size_t i_set);\
	_STX_PURE STX_RESULT	(*stop)(STX_HANDLE h);\
	_STX_PURE STX_RESULT	(*next)(STX_HANDLE h);\
	_STX_PURE STX_RESULT	(*prev)(STX_HANDLE h);\
	_STX_PURE STX_RESULT	(*step)(STX_HANDLE h);\


struct stx_base_control{
	stx_base_control_vtdef()
};




/*****************************************************************************
*****************************************************************************/
#define stx_speed_control_vtdef() \
	stx_base_com_vtdef() \
	_STX_PURE STX_RESULT	(*get_caps)(STX_HANDLE h,stx_xio* h_xio);\
	_STX_PURE STX_RESULT	(*set_speed)(STX_HANDLE h, f64 r_speed );\
	_STX_PURE STX_RESULT	(*get_speed)(STX_HANDLE h, f64* r_speed );\


struct stx_speed_control{
	stx_speed_control_vtdef()
};



/******************************************************************
the source have no input pin;
and should implement the control interface, base control and speed
control;
******************************************************************/
#define stx_base_source_vtdef() \
	stx_base_com_vtdef() \
	_STX_PURE STX_RESULT	(*load_stream)(STX_HANDLE h, const char* sz_stream,stx_sync_inf* h_sync);\
	_STX_PURE void			(*close_stream)(STX_HANDLE h);\
	_STX_PURE STX_RESULT	(*set_pos)(STX_HANDLE h,s64 i_pos);\
	_STX_PURE STX_RESULT	(*get_pos)(STX_HANDLE h,s64 *i_pos);\
	_STX_PURE STX_RESULT	(*get_size)(STX_HANDLE h,s64 *i_size);\


struct stx_base_source {
	stx_base_source_vtdef()
};



/*****************************************************************************
*****************************************************************************/
#define stx_media_info_vtdef() \
	stx_base_com_vtdef() \
	_STX_PURE STX_RESULT	(*get_desc)(STX_HANDLE h, s32* i_len, char** sz_desc );\
	_STX_PURE STX_RESULT	(*get_statistic)(STX_HANDLE h, s32* i_len, char** sz_desc );\
	_STX_PURE STX_RESULT	(*get_total_time)(STX_HANDLE h,s64 *i_time);\
	_STX_PURE STX_RESULT	(*get_current_time)(STX_HANDLE h,s64 *i_time);\
	_STX_PURE STX_RESULT	(*time_to_pos)(STX_HANDLE h,s64 i_time,offset_t * pos );\
	_STX_PURE STX_RESULT	(*pos_to_time)(STX_HANDLE h, offset_t pos ,s64* i_time );\

struct stx_media_info{
	stx_media_info_vtdef()
};

/******************************************************************
the render have no output pin;
******************************************************************/
#define stx_base_render_vtdef() \
	stx_base_filter_vtdef() \
	_STX_PURE s64		 (*get_current_time)( STX_HANDLE h );\
	_STX_PURE void		 (*set_start_time)( STX_HANDLE h, s64 i_start );\
	_STX_PURE STX_RESULT (*reset)(STX_HANDLE h);\
	_STX_PURE STX_RESULT (*get_device_num)(STX_HANDLE h,s32* i_num );\
	_STX_PURE STX_RESULT (*enum_device)(STX_HANDLE h,s32 i_idx, STX_HANDLE* pp_dev );\
	_STX_PURE STX_RESULT (*set_device)(STX_HANDLE h,s32 i_idx);\

struct stx_base_render{
	stx_base_render_vtdef()
};

/*****************************************************************************
*****************************************************************************/
#define stx_audio_render_vtdef() \
	stx_base_render_vtdef() \
	_STX_PURE STX_RESULT (*set_channels)( STX_HANDLE h, s32 i_channels);\
	_STX_PURE STX_RESULT (*get_channels)( STX_HANDLE h, s32* i_channels);\
	_STX_PURE STX_RESULT (*set_volume)( STX_HANDLE h, s32 i_volume );\
	_STX_PURE STX_RESULT (*get_volume)( STX_HANDLE h, s32* i_volume );\

struct stx_audio_render{
	stx_audio_render_vtdef()
};

/*****************************************************************************
*****************************************************************************/
#define stx_video_render_vtdef() \
	stx_base_render_vtdef() \
	_STX_PURE STX_RESULT	(*set_video_window)( STX_HANDLE h, stx_base_plugin* p_video_window );\
	_STX_PURE STX_RESULT	(*set_color_key)( STX_HANDLE h, u32 i_color_key);\
	_STX_PURE STX_RESULT	(*set_src_rect)(STX_HANDLE h, STX_RECT rect );\
	_STX_PURE STX_RESULT	(*set_dst_rect)(STX_HANDLE h, STX_RECT rect );\
	_STX_PURE STX_RESULT	(*hide)(STX_HANDLE h);\
	_STX_PURE STX_RESULT	(*show)(STX_HANDLE h);\
	_STX_PURE STX_RESULT	(*update)(STX_HANDLE h);\

struct stx_video_render{
	stx_video_render_vtdef()
};

/*****************************************************************************
*****************************************************************************/
#define stx_video_device_vtdef() \
	stx_video_render_vtdef()\

struct stx_video_device{
	stx_video_device_vtdef()
};


/*****************************************************************************
*****************************************************************************/
#define stx_audio_device_vtdef() \
	stx_audio_render_vtdef()\

struct stx_audio_device{
	stx_audio_device_vtdef()
};


/*****************************************************************************
*****************************************************************************/
#define stx_stream_writer_vtdef() \
	stx_base_filter_vtdef() \
	_STX_PURE STX_RESULT (*set_stream_name)(STX_HANDLE h, const char* sz_name );\
	_STX_PURE STX_RESULT (*set_stream)( STX_HANDLE h, stx_xio* p_output );\

struct stx_stream_writer{
	stx_stream_writer_vtdef()
};


/*****************************************************************************
*****************************************************************************/
#define stx_stream_parser_vtdef() \
	stx_base_com_vtdef() \
	_STX_PURE void		  (*reset)(STX_HANDLE h);/*new stream;*/\
	_STX_PURE void		  (*flush)(STX_HANDLE h);/*slide op;*/\
	_STX_PURE STX_RESULT  (*parse)(\
		STX_HANDLE		h, \
		u8*				buf, \
		size_t			i_len,\
		u8**			buf_ptr); \
	_STX_PURE STX_RESULT  (*get_data)(\
	/**/STX_HANDLE			h, \
	/**/stx_media_data*		p_mdat );\

struct stx_stream_parser{
	stx_stream_parser_vtdef()
};


/*****************************************************************************
*****************************************************************************/
#define stx_smart_tee_vtdef()\
	stx_base_filter_vtdef() \
	/* deliver the stream data from one input pin to multiple output pin; */\
	/*the default output pin num is 2; */\
	_STX_PURE STX_RESULT	(*set_output_pin_num)(STX_HANDLE h, s32 i_num );\

struct stx_smart_tee {
	stx_smart_tee_vtdef()
};


/***********************************************************************************
***********************************************************************************/
#define stx_base_player_vtdef() \
	stx_base_com_vtdef() \
	_STX_PURE STX_RESULT (*send_cmd)( STX_HANDLE h,\
		size_t i_msg, size_t i_wparam, size_t i_lparam, size_t i_ext );\

struct stx_base_player {
	stx_base_player_vtdef()
};


/***********************************************************************************
this interface allow create multiple plug in in one dll;
***********************************************************************************/
#define  stx_base_module_vtdef() \
	stx_base_plugin_vtdef() \
	_STX_PURE s32			(*get_filter_num)(STX_HANDLE h);\
	_STX_PURE STX_RESULT	(*get_filter_gid)(STX_HANDLE h, s32 i_index, stx_gid* p_gid);\
	_STX_PURE STX_RESULT	(*create_instance)(STX_HANDLE h, stx_gid gid, STX_HANDLE* p_hinst );\

struct stx_base_module {
	stx_base_module_vtdef()
};


#if defined( __cplusplus )
}
#endif



#endif /* __BASE_INTERF_H__ */ 

