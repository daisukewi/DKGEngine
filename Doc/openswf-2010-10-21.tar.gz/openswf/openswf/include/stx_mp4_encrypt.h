
#ifndef __MOV_ENCRYPT_H__2008_06_21
#define __MOV_ENCRYPT_H__2008_06_21


/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#if defined( __cplusplus )
extern "C" {
#endif


#include "stx_all_codec.h"

#include "stx_io.h"



	STX_INTERF(stx_mp4_encrypt_interf);

	struct  stx_mp4_encrypt_interf{

		_STX_PURE stx_base_com   com;

		_STX_PURE STX_RESULT	 (*mp4_open)(
			THEE		h,
			const char*		sz_file,
			const char*		sz_new_file);

		_STX_PURE STX_RESULT	 (*mp4_write_sdp_keyinfo)( 
			THEE		h, 
			char*			buf, 
			size_t			data_size );

		_STX_PURE STX_RESULT	 (*mp4_read_first_keyframe)( 
			THEE h, char* buf, size_t* buf_size );

		_STX_PURE STX_RESULT	 (*mp4_read_next_keyframe)( 
			THEE h, char* buf, size_t* buf_size );

		_STX_PURE STX_RESULT	 (*mp4_write_current_keyframe)( 
			THEE h, char* buf, size_t* buf_size );

	};


	STX_API stx_mp4_encrypt_interf*  stx_mp4_encrypt_create();



#if defined( __cplusplus )
}
#endif


#endif // __MOV_ENCRYPT_H__2008_06_21
