
#ifndef __STX_SYNC_SOURCE_H__
#define __STX_SYNC_SOURCE_H__
/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/
#include "stx_async_plugin.h"


#if defined( __cplusplus )
extern "C" {
#endif

	///////////////////////////////////////////////////////////////
	STX_API extern STX_RESULT	xtcall(void* pstack,void* pfunc,void* plug, void* hsync);
	STX_API extern STX_RESULT	xtswap(void** pold,void* pnew);
	///////////////////////////////////////////////////////////////


	STX_API STX_RESULT stx_base_plugin_stop
		(stx_base_plugin* plug,STX_RESULT i_err_ext,b32 b_stopped);

	STX_API STX_COM(sync_source);


#if defined( __cplusplus )
}
#endif




#endif /*__STX_SYNC_SOURCE_H__*/