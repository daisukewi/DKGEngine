/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/


#ifndef __STX_RTSP_SOURCE_H__
#define __STX_RTSP_SOURCE_H__


#include "stx_async_plugin.h"


#include "stx_gid_def.h"



#if defined( __cplusplus )
extern "C" {
#endif


extern char* g_szStreamX_RtspFileSource;

/* {555D43B4-72E7-4869-BB11-12C6EED268BB}*/
DECLARE_XGUID( STX_CLSID_RtspFileSource,
0x555d43b4, 0x72e7, 0x4869, 0xbb, 0x11, 0x12, 0xc6, 0xee, 0xd2, 0x68, 0xbb );


STX_API //stx_base_source*	stx_rtsp_source_create();
STX_COM(rtsp_source);


#if defined( __cplusplus )
}
#endif


#endif /* __STX_RTSP_SOURCE_H__ */ 
