/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-11
***********************************************************************************/
#ifndef __STX_HTTP_PROT_H__
#define __STX_HTTP_PROT_H__

#include "stx_async_plugin.h"
#include "stx_prop_def.h"
#include "stx_protocol.h"


#if defined( __cplusplus )
extern "C" {
#endif

	// {23C61798-F6DF-4b39-9D8A-4A1C092201C2}
	DECLARE_XGUID( STX_CLSID_HttpProtocol,
	0x23c61798, 0xf6df, 0x4b39, 0x9d, 0x8a, 0x4a, 0x1c, 0x9, 0x22, 0x1, 0xc2);
	extern char* g_sz_StreamX_HttpProtocol;
	STX_COM(stx_http_prot);
	STX_API CREATE_STX_COM_DECL(stx_base_filter,stx_http_prot,char* sz_dbg);


#if defined( __cplusplus )
}
#endif


#endif // __STX_HTTP_PROT_H__