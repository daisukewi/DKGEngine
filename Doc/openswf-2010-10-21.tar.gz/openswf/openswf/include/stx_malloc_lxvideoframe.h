
/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#ifndef __STX_VIDEOFRAME_ALLOC_H__
#define __STX_VIDEOFRAME_ALLOC_H__


#include "stx_mem_alloc_base.h"

#if defined( __cplusplus )
extern "C" {
#endif

	typedef struct vfrm_alloc vfrm_alloc;

#ifdef __USE_STX_DEBUG__
	STX_API stx_media_data_allocator* create_vfrm_alloc(THEE hinst,const char* file,s32 line);
#else
	STX_API stx_media_data_allocator* create_vfrm_alloc(THEE hinst);
#endif


#if defined( __cplusplus )
}
#endif



#endif /* __STX_VIDEOFRAME_ALLOC_H__ */ 