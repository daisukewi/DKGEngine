/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#ifndef __STX_ALL_H__
#define __STX_ALL_H__


#include "stdio.h"
#include "stdlib.h"
#include "fcntl.h"
#include "malloc.h"
#include "memory.h"
#include "string.h"
#include "ctype.h"
#include "time.h"
#include "math.h"

#include "stx_base_type.h"
#include "base_interf.h"
#include "base_class.h"
#include "stx_os.h"
#include "stx_debug.h"
#include "stx_process.h"
#include "stx_thread.h"
#include "stx_dll.h"
#include "stx_event.h"
#include "stx_mutex.h"
#include "stx_semaphore.h"
#include "stx_mem.h"

#include "stx_io.h"
#include "stx_io_direct.h"
#include "stx_io_stream.h"
#include "stx_io_file.h"
#include "stx_io_tcp.h"
#include "stx_io_http.h"
#include "stx_io_xudp.h"
#include "stx_io_as.h"
#include "stx_io_buf.h"
#include "stx_io_interleaved.h"

#include "stx_ini.h"
#include "stx_gid.h"
#include "stx_gid_def.h"
#include "stx_msg_def.h"
#include "stx_message.h"
#include "stx_sock_err.h"
#include "stx_string.h"

#include "stream_service.h"
#include "stream_slice.h"
#include "xdisk_loop.h"
#include "xdisk_interf.h"
#include "xdisk_handle.h"

#include "stx_all_codec.h"
#include "stx_module_reg.h"
#include "stx_video_frame.h"
#include "stx_output_pin.h"
#include "stx_direct_pin.h"
#include "stx_stream_pin.h"
#include "stx_async_plugin.h"
#include "stx_sync_source.h"
#include "stx_audio_render_emu.h"
#include "stx_audio_device.h"
#include "stx_connect_ctx.h"
#include "stx_direct_pin.h"
#include "stx_stream_pin.h"
#include "stx_graph_builder.h"
#include "stx_filter_graph.h"
#include "stx_dvd_interf.h"
#include "stx_media_data_base.h"
#include "stx_media_type_base.h"
#include "stx_malloc_lxvideoframe.h"
#include "stx_mdat_lxvideoframe.h"
#include "stx_mem_alloc_base.h"
#include "stx_rtsp_source.h"
#include "stx_rtsp_player.h"
#include "stx_video_device.h"
#include "stx_video_render.h"
#include "stx_video_render_emu.h"

#include "stx_mp4_clip.h"
#include "stx_mp4_enc_drm.h"
#include "stx_mp4_encrypt.h"
#include "stx_mp4_encrypt_demo.h"

#include "stx_prop_def.h"
#include "stx_getopt.h"



#endif // __STX_ALL_H__