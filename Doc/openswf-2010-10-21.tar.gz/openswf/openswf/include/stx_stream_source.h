/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/



#ifndef __STX_STREAM_SOURCE_BASE_H__
#define __STX_STREAM_SOURCE_BASE_H__



#include "stx_async_plugin.h"


#if defined( __cplusplus )
extern "C" {
#endif


//stx_base_source* stx_stream_source_create();

STX_COM(stream_source);


#if defined( __cplusplus )
}
#endif


#endif /* __STX_STREAM_SOURCE_BASE_H__ */ 