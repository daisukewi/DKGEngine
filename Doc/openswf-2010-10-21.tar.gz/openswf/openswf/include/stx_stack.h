/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/


#ifndef __STX_STACK_H__
#define __STX_STACK_H__


#include "stx_base_type.h"


#if defined( __cplusplus )
extern "C" {
#endif


	STX_HANDLE stx_stack_create();

	void stx_stack_close(STX_HANDLE h);

	void stx_stack_reset(STX_HANDLE h);

	STX_RESULT stx_stack_push(STX_HANDLE h,size_t i_val);

	size_t* stx_stack_pop(STX_HANDLE h);

	size_t* stx_stack_top(STX_HANDLE h);

	STX_HANDLE stx_stack_dup(STX_HANDLE h);


#if defined( __cplusplus )
}
#endif


#endif /* __STX_LOOP_H__*/
