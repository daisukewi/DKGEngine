/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/
#ifndef __STX_PROP_DEF_H__
#define __STX_PROP_DEF_H__


#include "stx_base_type.h"

#include "stx_io.h"
#include "stx_io_stream.h"
#include "stx_ini.h"

#include "base_class.h"


#if defined( __cplusplus )
extern "C" {
#endif

	STX_RESULT create_stream_rule_exclusive(
		stx_xini*			h_xini,
		STX_HANDLE			h_key,
		char*				sz_key_name,
		char*               sz_desc,
		s32					i_default,
		s32					i_current,
		s32					i_size,
		stx_media_type_map	minf[], 
		b32                 b_pin_rule[]
	);

	STX_RESULT create_stream_rule_none_exclusive(
		stx_xini*			h_xini,
		STX_HANDLE			h_key,
		char*				sz_key_name,
		char*               sz_desc,
		s32					i_size,
		stx_media_type_map	minf[], 
		b32                 b_checked[],
		b32                 b_pin_rule[]
	);



/*{{{***************************************************************************/
	extern char* g_szPropertyPage;
	extern char* g_szPropertyData;

	extern char* g_szStreamRule;
	extern char* g_szGroup;
	extern char* g_szDescription;
	extern char* g_szPinRule;
	extern char* g_szExclusive;
	extern char* g_szNoneExclusive;

	extern char* g_szType;
	extern char* g_szVal;

	extern char* g_szType_s8  ;
	extern char* g_szType_s16 ;
	extern char* g_szType_s32 ;
	extern char* g_szType_s64 ;

	extern char* g_szType_u8  ;
	extern char* g_szType_u16 ;
	extern char* g_szType_u32 ;
	extern char* g_szType_u64 ;

	extern char* g_szType_f32 ;
	extern char* g_szType_f64 ;
	extern char* g_szType_b16 ;
	extern char* g_szType_b32 ;

	extern char* g_szType_array;
	extern char* g_szType_string;
	extern char* g_szType_binary;  // text format of binary data;
	extern char* g_szType_base64;  // base64 text format of binary data;
	extern char* g_szType_ipv4;
	extern char* g_szType_ipv6;

	extern char* g_szControl_list;			// multiple item;
	extern char* g_szControl_checkbox;	// multiple selection;
	extern char* g_szControl_radio;			// single selection;
	extern char* g_szControl_combo;			// drop list, single selection;

	extern char* g_szDefaultOption;
	extern char* g_szDefaultVal;
	extern char* g_szOption;
	extern char* g_szCurrentOption;
	extern char* g_szCurrentVal;

	extern char* g_szControl_slider;
	extern char* g_szDefaultPos;
	extern char* g_szMinPos;
	extern char* g_szMaxPos;
	extern char* g_szStep;
	extern char* g_szCurPos;

	extern char* g_szInputFormatSelect;
	extern char* g_szOutputFormatSelect;
	extern char* g_szInputFormat;
	extern char* g_szOutputFormat;
	extern char* g_szOutputWidth;
	extern char* g_szOutputHeight;

	extern char* g_szStatus;
	extern char* g_szChecked;
	extern char* g_szUnChecked;

	extern char* g_szTrue;
	extern char* g_szFalse;



/*}}}***************************************************************************/



/*{{{***************************************************************************/
	extern char* g_szCtlCaps_play_stop;
	extern char* g_szCtlCaps_pause_resume;
	extern char* g_szCtlCaps_next;
	extern char* g_szCtlCaps_previous;
	extern char* g_szCtlCaps_step;
	extern char* g_szCtlCaps_resumePlay;
	extern char* g_szCtlCaps_forward;
	extern char* g_szCtlCaps_backward;

	extern char* g_szSpeedCaps_speed;
/*}}}***************************************************************************/





	/*{{{***************************************************************************/
	extern char*		g_sz_service;
	extern char*		g_sz_server_config;
	extern char*		g_sz_service_config;
	extern char*		g_sz_ip4;
	extern char*		g_sz_bind;
	extern char*		g_sz_port;
	extern char*		g_sz_service_heart;
	extern char*		g_sz_stp_time_out;
	extern char*		g_sz_stp_channel_buf;
	extern char*		g_sz_rtp_graph_file;
	extern char*		g_sz_stp_graph_file;
	extern char*		g_sz_rtsp_ip4;
	extern char*		g_sz_rtsp_port;

	extern char*	    g_sz_ip4_default;
	extern char*	    g_sz_port_default;
	extern char*	    g_sz_rtsp_port_default;

	extern char*	    g_sz_key_thread_num;
	extern char*	    g_sz_key_task_status;
	extern char*	    g_sz_key_last_plug;
	extern char*	    g_sz_key_task_monitor;
	extern char*	    g_sz_key_plug_monitor;



#define STX_NORMAL_STOP		0
#define STX_SYSTEM_STOP		1
#define STX_APP_FATAL		2
	extern char*	    g_sz_service_status;
	extern char*	    g_sz_service_restart;

	extern char*	    g_sz_service_start_time;
	extern char*	    g_sz_service_heart_time;
	extern char*	    g_sz_service_extcode;



#define STX_PROTOCOL_ENCRYT					0x0001
#define STX_PROTOCOL_XINI					0x0002

#define STX_STP_ADMIN_STOP					500
#define STX_STP_ADMIN_RESTART				501

#define STX_STP_ADMIN_GET					502

#define GET_LEVEL_OCCUPY					0x01
#define GET_LEVEL_CONNECTION_NUM			0x02
#define GET_LEVEL_CONNECTION_DETAIL			0x04
#define GET_LEVEL_CONNECTION_ALL			0x08
	extern char*	    g_sz_get_level;
	extern char*	    g_sz_occupy;
	extern char*	    g_sz_connection_num;

	extern char*	    g_sz_user_aggent;
	extern char*	    g_sz_user_name;
	extern char*	    g_sz_password;
	extern char*	    g_sz_authenticate;

#define STX_SERVICE_REQUEST_DOWNLOAD		810
#define STX_SERVICE_REQUEST_CONVERT			811	//added by xmp
	extern char*		g_sz_URL;
	extern char*		g_sz_HEADERS;
	extern char*		g_sz_GRAPH;
	extern char*		g_sz_file_size;
	extern char*		g_sz_channel;
	extern char*		g_sz_file_time;
	extern char*		g_sz_moddate;

#define STX_SERVICE_REQUEST_PLAY			812
//#define STX_SERVICE_REQUEST_PAUSE			813
#define STX_SERVICE_REQUEST_CLOSE			814

#define STX_SERVICE_REQUEST_CONNECT			820
#define STX_SERVICE_REQUEST_DELIVER			830


	// respond code;
#define STX_SERVICE_RESPOND_OK				900
#define STX_SERVICE_RESPOND_BAD_GRAPH		910
#define STX_SERVICE_RESPOND_BAD_MODULE		920
#define STX_SERVICE_RESPOND_FILE_NOT_FOUND	930
#define STX_SERVICE_MSG_INTERNAL_ERR		940
#define STX_SERVICE_MSG_END				    950





	extern char*	    g_sz_service_request;

	extern char*	    g_sz_service_respond;
	extern char*	    g_sz_service_respond_context;


	extern char*		g_sz_prot_http;
	extern char*		g_sz_prot_stx;
	extern char*		g_sz_prot_rtsp;

	extern char*		g_sz_request_head;
	extern char*		g_sz_request_get;
	extern char*		g_sz_request_post;

	extern char*		g_sz_request_describe;
	extern char*		g_sz_request_setup;
	extern char*		g_sz_request_option;
	extern char*		g_sz_request_play;
	extern char*		g_sz_request_pause;
	extern char*		g_sz_request_teardown;

	STX_INTERF(stx_prot_tab);
	struct stx_prot_tab{
		char** sz_prot;
		char** sz_method;
	};
	extern stx_prot_tab g_prot_tab[];

	char* quote_method_protocol(const char* sz_method);

	/*}}}***************************************************************************/


#if defined( __cplusplus )
}
#endif



#endif /*__STX_PROP_DEF_H__*/ 