/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/
#ifndef __STX_IO_AS_H__2008_06_21
#define __STX_IO_AS_H__2008_06_21

#include "stx_base_type.h"
#include "stx_io.h"
#include "stx_gid_def.h"
#include "base_class.h"

#if defined( __cplusplus )
extern "C" {
#endif

#define AS_MAX_SIZE			128*1024
#define AS_MIN_SIZE			64*1024
#define AS_READ_SIZE		32*1024

	// {8B82BC74-98EA-472f-9D9F-CC13A0391C95}
	DECLARE_XGUID( STX_CLSID_AsIo,
	0x8b82bc74, 0x98ea, 0x472f, 0x9d, 0x9f, 0xcc, 0x13, 0xa0, 0x39, 0x1c, 0x95)

	extern char* g_szAsIo;

	STX_COM(stx_io_as);

	STX_API CREATE_STX_COM_DECL(stx_base_plugin,stx_io_as);


#if defined( __cplusplus )
}
#endif


#endif /* __STX_IO_AS_H__2008_06_21*/

