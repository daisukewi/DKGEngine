/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/


#ifndef __BLEND_API_H__
#define __BLEND_API_H__

#include "stx_base_type.h"

#if defined( __cplusplus )
extern "C" {
#endif

	void blend_api_init(u32 mm_flags);

	void blend_field(u8* three[3],u8* dest,s32 width);


#if defined( __cplusplus )
}
#endif


#endif // __BLEND_API_H__