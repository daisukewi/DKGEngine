
#ifdef __STX_SERVICE_API_C__


#include "stx_protocol.h"
#include "stx_io_interleaved.h"



#ifdef __USE_STX_DEBUG__
	static const char __T_THIS_FILE__[] = __FILE__;
#	define __THIS_FILE__  __T_THIS_FILE__
#endif

#define STX_SERVICE_ACTIVE         0
#define STX_SERVICE_NOT_ACTIVE     1
#define STX_SERVICE_NORMAL_EXIT    2
#define STX_SERVICE_EXCEPTION_EXIT 3

static s64 g_service_start_time = 0;
static char g_service_heart_file[1024];

static STX_RESULT	check_service_status();
static STX_RESULT	send_exit_command();
static STX_RESULT	write_cmd_close( stx_xio* h_stream );

STX_PRIVATE STX_RESULT write_service_status(STX_RESULT i_prot_err,char* sz_file);

#ifdef __WIN32_LIB
static BOOL GetCurrentPath(LPTSTR szPath, DWORD nSize);
#endif


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE void get_service_ha_file_name(char* buf, size_t i_size)
{
#ifdef __WIN32_LIB
	char dir[1024];
	GetCurrentPath(dir,1024);
	stx_sprintf(buf,i_size,"%s\\%s",dir,g_sz_service_heart);
#else

#endif
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_PRIVATE STX_RESULT init_service_ha_file( char* dir )
{
	STX_RESULT		i_err;
	STX_HANDLE		h_status;
	STX_HANDLE		h_start_time;
	STX_HANDLE		h_last_time;
	stx_xini*		h_xini;

	h_xini = NULL;

	i_err = stx_ini_create(dir,NULL,STX_INI_CREATE_NEW|STX_INI_NO_COMMENT,0,&h_xini);
	if( STX_OK != i_err ) {
		return i_err;
	}

	do{
		i_err = h_xini->create_key(h_xini,NULL,g_sz_service_status,"0",&h_status);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = h_xini->create_key(h_xini,NULL,g_sz_service_start_time,"0",&h_start_time);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = h_xini->create_key(h_xini,NULL,g_sz_service_heart_time,"0",&h_last_time);
		if( STX_OK != i_err ) {
			break;
		}

	}while(FALSE);

	h_xini->close(h_xini);

	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_PRIVATE STX_RESULT write_service_status(STX_RESULT i_prot_err,char* sz_file)
{

	STX_RESULT		i_err;

	stx_xini*		h_xini;

	STX_HANDLE		h_status;

	STX_HANDLE		h_start_time;
	STX_HANDLE		h_last_time;

	s64				i_start_time;
	s64				i_cur_time;


	i_err = stx_ini_create(sz_file,NULL,STX_INI_READ_WRITE|STX_INI_NO_COMMENT,0,&h_xini);
	if( STX_OK != i_err ) {
		return STX_OK; // try next time;
	}

	i_cur_time = stx_get_milisec();

	do{

		// check if is avtive status; or need restart ? STX_SERVICE_NOT_ACTIVE
		i_err = h_xini->create_key(h_xini,NULL,g_sz_service_status,NULL,&h_status);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = h_xini->write_int32(h_xini,h_status,(s32)i_prot_err);
		if( STX_OK != i_err ) {
			break;
		}

		if( i_prot_err == STX_RESTART ) {
			break;
		} 

		i_err = h_xini->create_key(h_xini,NULL,g_sz_service_start_time,"0",&h_start_time);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = h_xini->read_int64(h_xini,h_start_time,&i_start_time);
		if( STX_OK != i_err ) {
			break;
		}

		if( !i_start_time ) {
			i_err = h_xini->write_int64(h_xini,h_start_time, i_cur_time );
			if( STX_OK != i_err ) {
				break;
			}
		}

		i_err = h_xini->create_key(h_xini,NULL,g_sz_service_heart_time,NULL,&h_last_time);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = h_xini->write_int64(h_xini,h_last_time,i_cur_time );
		if( STX_OK != i_err ) {
			break;
		}

	}while(FALSE);

	if( h_xini ) {
		h_xini->close(h_xini);
	}

	return i_err;

}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static STX_RESULT check_service_status()
{
	STX_RESULT		i_err;
	stx_xini*		h_xini;

	STX_HANDLE		h_status;
	s32				i_status;

	STX_HANDLE		h_start_time;
	STX_HANDLE		h_last_time;

	s64				i_start_time;
	s64				i_last_time;
	s64				i_cur_time;


	i_err = stx_ini_create(g_service_heart_file,NULL,STX_INI_READ_ONLY|STX_INI_NO_COMMENT,0,&h_xini);
	if( STX_OK != i_err ) {
		return STX_SERVICE_ACTIVE; // try next time;
	}

	do{

		// check if is avtive status; or need restart ? STX_SERVICE_NOT_ACTIVE
		i_err = h_xini->create_key(h_xini,NULL,g_sz_service_status,NULL,&h_status);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = h_xini->read_int32(h_xini,h_status,&i_status);
		if( STX_OK != i_err ) {
			break;
		}

		if( STX_RESTART == i_status ) {

			i_err = STX_SERVICE_NOT_ACTIVE;
			break;

		} // if( STX_RESTART == i_status ) {


		i_err = h_xini->create_key(h_xini,NULL,g_sz_service_start_time,NULL,&h_start_time);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = h_xini->read_int64(h_xini,h_start_time,&i_start_time);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = h_xini->create_key(h_xini,NULL,g_sz_service_start_time,NULL,&h_last_time);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = h_xini->read_int64(h_xini,h_last_time,&i_last_time);
		if( STX_OK != i_err ) {
			break;
		}

		i_cur_time = stx_get_milisec();

		if( i_last_time - i_start_time < i_cur_time + 3000 ) {
			i_err = STX_SERVICE_EXCEPTION_EXIT; 
		}
		else{
			i_err = STX_SERVICE_ACTIVE;
		}

	}while(FALSE);

	if( h_xini ) {
		h_xini->close(h_xini);
	}

	return i_err;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static STX_RESULT send_exit_command()
{
	STX_RESULT	i_err;
	stx_xio*	h_tcp;
	stx_xio*	h_stream;
	char		sz_param[128];
	size_t		i_read;
	u32			i_port;

	h_tcp = stx_create_io_tcp();
	if( !h_tcp ) {
		return STX_FAIL;
	}

	h_stream = NULL;

	/* TCP open; */
	i_port = atoi(g_sz_port_default);

	stx_io_tcp_make_string( g_sz_ip4_default, i_port, sz_param ,sizeof(sz_param ) );



	do{
		DECL_TRACE stx_io_op_param param;
		size_t			i_write;
		size_t			i_data;

		i_err = stx_io_tcp_make_open_string(NULL,sz_param,sz_param);
		if( STX_OK != i_err )  {
			break;
		}

		i_err = h_tcp->open(h_tcp, sz_param, STX_XIO_TCP_OPEN_CONNECT );
		if( STX_OK != i_err) {
			break;
		}

		i_err = STX_FAIL;

		h_stream = XCREATE(stx_io_stream,NULL);
		if( !h_stream ) {
			break;
		}

		i_err = write_cmd_close(h_stream);
		if( STX_OK != i_err) {
			break;
		}

		INIT_MEMBER(param);
		i_err = h_stream->get(h_stream,STX_IO_READ_P,&param);
		if( STX_OK != i_err ) {
			break;
		}

		while( param.i_available_data ){

			i_data = (size_t)( param.i_available_data > 32*1024 ? 32*1024: param.i_available_data );

			i_err = h_tcp->write(h_tcp,param.buf,i_data,&i_write);
			if( STX_OK != i_err ) {
				break;
			}
			param.buf += i_write;
			param.i_available_data -= i_write;
		} //while( param.i_available_data ){

		if( STX_OK != i_err ) {
			break;
		}

		// parse response ???


		for( ; ; ) {// wait form stx_service close the socket;

			i_err = h_tcp->read(h_tcp,sz_param,4,&i_read);

			if( i_err < 0 || STX_EOF ==  i_err) {
				i_err = 0;
				break;
			}

			stx_sleep(10);

		}// for( ; ; ) {

	}while(FALSE);

	h_tcp->close(h_tcp);

	if( h_stream ) {
		h_stream->close(h_stream);
	}

	return i_err;
}





/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static STX_RESULT write_cmd_close( stx_xio* h_stream )
{

	STX_RESULT		i_err;
	stx_xini*		h_xini;
	stx_xio*		h_cmd_stream;
	STX_HANDLE		h_key;
	ByteIOContext	pb;
	char            buf[STX_DEFAULT_PATH];

	h_xini = NULL;
	h_cmd_stream = NULL;


	do{

		stx_io_op_param param;
		size_t i_write;

		i_err = STX_FAIL;

		h_cmd_stream = XCREATE(stx_io_stream,NULL);
		if( !h_cmd_stream ) {
			break;
		}

		i_err = stx_ini_create(NULL,h_cmd_stream,STX_INI_CREATE_NEW|STX_INI_NO_COMMENT,0,&h_xini);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = h_xini->create_key(h_xini,NULL,g_sz_service_request,NULL,&h_key);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = h_xini->write_int32(h_xini,h_key,STX_STP_ADMIN_STOP);
		if( STX_OK != i_err ) {
			break;
		}

		// close it, save xini body to h_cmd_stream;
		h_xini->close(h_xini);
		h_xini = NULL;

		// get xini body data pointer and length;
		INIT_MEMBER(param);
		i_err = h_cmd_stream->get(h_cmd_stream,STX_IO_READ_P,&param);
		if( STX_OK != i_err ) {
			break;
		}

		// write header;
		INIT_BYTEIO_W(pb,STX_DEFAULT_PATH,(uint8*)buf,h_stream);
		put_tag(&pb,g_sz_prot_stx);
		put_be32(&pb,STX_PROTOCOL_XINI);
		put_be32(&pb,(u32)param.i_available_data);

		// write xini body;
		i_err = xio_fwrite(&pb,(const u8*)param.buf,(size_t)param.i_available_data,&i_write);
		if( STX_OK != i_err ) {
			break;
		}

		// flush out data;
		xio_flush(&pb);

		i_err = STX_OK;

	}while(FALSE);

	if( h_xini ) {
		h_xini->close(h_xini);
	}

	if( h_cmd_stream ) {
		h_cmd_stream->close(h_cmd_stream);
	}

	return i_err;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE stx_base_graph_builder* i_service_api_init(void (*_trace)(char*),u32 i_debug)
{
	return stx_initialize(_trace,i_debug);
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE void i_service_api_close(stx_base_graph_builder* h)
{
	stx_cleanup(h);
}



#ifdef __WIN32_LIB

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static BOOL GetCurrentPath(LPTSTR szPath, DWORD nSize) //nSize: n TCHARs
{
	DWORD dwRet = GetModuleFileName(GetModuleHandle(NULL), szPath, nSize);

	if(0 == dwRet){
		return FALSE;
	}
	else{
		TCHAR* p = szPath;
		while(*p)++p;// let p point to '\0'
		while('\\' != *p)--p;// let p point to '\\'
		*p = '\0';// get the path

		return TRUE;
	}
}

#endif



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static STX_RESULT write_cmd_close_dwonload( stx_xio* h_stream )
{

	STX_RESULT		i_err;
	stx_xini*		h_xini;
	stx_xio*		h_cmd_stream;
	STX_HANDLE		h_key;
	ByteIOContext	pb;
	char            buf[STX_DEFAULT_PATH];

	h_xini = NULL;
	h_cmd_stream = NULL;


	do{

		stx_io_op_param param;
		size_t i_write;

		i_err = STX_FAIL;

		h_cmd_stream = XCREATE(stx_io_stream,NULL);
		if( !h_cmd_stream ) {
			break;
		}

		i_err = stx_ini_create(NULL,h_cmd_stream,STX_INI_CREATE_NEW|STX_INI_NO_COMMENT,0,&h_xini);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = h_xini->create_key(h_xini,NULL,g_sz_service_request,NULL,&h_key);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = h_xini->write_int32(h_xini,h_key,STX_SERVICE_REQUEST_CLOSE);
		if( STX_OK != i_err ) {
			break;
		}

		// close it, save xini body to h_cmd_stream;
		h_xini->close(h_xini);
		h_xini = NULL;

		// get xini body data pointer and length;
		INIT_MEMBER(param);
		i_err = h_cmd_stream->get(h_cmd_stream,STX_IO_READ_P,&param);
		if( STX_OK != i_err ) {
			break;
		}

		// write header;
		INIT_BYTEIO_W(pb,STX_DEFAULT_PATH,(uint8*)buf,h_stream);
		put_tag(&pb,g_sz_prot_stx);
		put_be32(&pb,STX_PROTOCOL_XINI);
		put_be32(&pb,(u32)param.i_available_data);

		// write xini body;
		i_err = xio_fwrite(&pb,(const u8*)param.buf,(size_t)param.i_available_data,&i_write);
		if( STX_OK != i_err ) {
			break;
		}

		// flush out data;
		xio_flush(&pb);

		i_err = STX_OK;

	}while(FALSE);

	if( h_xini ) {
		h_xini->close(h_xini);
	}

	if( h_cmd_stream ) {
		h_cmd_stream->close(h_cmd_stream);
	}

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static STX_RESULT write_cmd_download( stx_xio* h_stream, char* sz_url )
{

	STX_RESULT		i_err;
	stx_xini*		h_xini;
	stx_xio*		h_cmd_stream;
	STX_HANDLE		h_key;
	ByteIOContext	pb;
	char            buf[STX_DEFAULT_PATH];

	h_xini = NULL;
	h_cmd_stream = NULL;


	do{
		stx_io_op_param param;
		size_t i_write;

		i_err = STX_FAIL;

		h_cmd_stream = XCREATE(stx_io_stream,NULL);
		if( !h_cmd_stream ) {
			break;
		}

		i_err = stx_ini_create(NULL,h_cmd_stream,STX_INI_CREATE_NEW|STX_INI_NO_COMMENT,0,&h_xini);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = h_xini->create_key(h_xini,NULL,g_sz_service_request,NULL,&h_key);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = h_xini->write_int32(h_xini,h_key,STX_SERVICE_REQUEST_DOWNLOAD);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = h_xini->create_key(h_xini,NULL,g_sz_URL,NULL,&h_key);
		if( STX_OK != i_err ) {
			break;
		}
		i_err = h_xini->write_base64(h_xini,h_key,(s32)strlen(sz_url) + 1, (u8*)sz_url);
		if( STX_OK != i_err ) {
			break;
		}


		// close it, save xini body to h_cmd_stream;
		h_xini->close(h_xini);
		h_xini = NULL;

		// get xini body data pointer and length;
		INIT_MEMBER(param);
		i_err = h_cmd_stream->get(h_cmd_stream,STX_IO_READ_P,&param);
		if( STX_OK != i_err ) {
			break;
		}

		// write header;
		INIT_BYTEIO_W(pb,STX_DEFAULT_PATH,(uint8*)buf,h_stream);
		put_tag(&pb,g_sz_prot_stx);
		put_be32(&pb,STX_PROTOCOL_XINI);
		put_be32(&pb,(u32)param.i_available_data);

		// write xini body;
		i_err = xio_fwrite(&pb,(const u8*)param.buf,(size_t)param.i_available_data,&i_write);
		if( STX_OK != i_err ) {
			break;
		}

		// flush out data;
		xio_flush(&pb);

		i_err = STX_OK;

	}while(FALSE);

	if( h_xini ) {
		h_xini->close(h_xini);
	}

	if( h_cmd_stream ) {
		h_cmd_stream->close(h_cmd_stream);
	}

	return i_err;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static STX_RESULT write_out_stream(stx_xio* h_tcp,stx_xio* h_stream)
{
	STX_RESULT	i_err;

	stx_io_op_param param;
	size_t			i_write;
	size_t			i_data;


	INIT_MEMBER(param);
	i_err = h_stream->get(h_stream,STX_IO_READ_P,&param);
	if( STX_OK != i_err ) {
		return i_err;
	}

	while( param.i_available_data ){

		i_data = (size_t)( param.i_available_data > 32*1024 ? 32*1024: param.i_available_data );

		i_err = h_tcp->write(h_tcp,param.buf,i_data,&i_write);
		if( i_err < 0 ) {
			return i_err;
		}
		if( STX_WOUNLD_BLOCK == i_err ) {
			stx_sleep(10);
			continue;
		}
		param.buf += i_write;
		param.i_available_data -= i_write;
	} //while( param.i_available_data ){

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static STX_RESULT stp_download_file
(stx_xio* h_data, stx_xio* h_file, s64 i_size )
{
	STX_RESULT	i_err;
	size_t		i_write;
	size_t		i_data;
	u8			buf[2048];


	while( i_size > 0 ){

		size_t i_read = (size_t)( i_size > 2048 ? 2048 : i_size );

		i_data = 0;
		i_err = h_data->read(h_data,buf,i_read,&i_data);
		if( i_err < 0 || STX_EOF == i_err ) {
			return i_err;
		}
		if( STX_IDLE == i_err || STX_WOUNLD_BLOCK == i_err ) {
			stx_sleep(10);
			continue;
		}

		i_write = 0;
		i_err = h_file->write(h_file,buf,i_data,&i_write);
		if( i_err < 0 ) {
			return i_err;
		}

		i_size -= i_data;

	} //while( i_size ){

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static STX_RESULT stp_download_response
(stx_xio* h_cmd,stx_xio* h_stream,s64* i_size)
{

	STX_RESULT		i_err;
	size_t			i_body_size;
	stx_xini*		h_xini;
	STX_HANDLE		h_key;
	s32				i_result;

	ByteIOContext	pb;
	u8				buf[128];


	h_xini = NULL;
	*i_size = 0;

	// receive hdr;
	h_stream->clear(h_stream);
	i_err = stp_download_file(h_cmd,h_stream,STX_PROT_HDR_SIZE);
	if( STX_OK != i_err ) {
		return i_err;
	}

	// get the body size;
	h_stream->seek(h_stream,0,SEEK_SET);
	INIT_BYTEIO_R(pb,sizeof(buf),buf,h_stream);

	get_be32(&pb);
	get_be32(&pb);
	i_body_size = get_be32(&pb);

	do{
		// receive body;
		h_stream->clear(h_stream);
		i_err = stp_download_file(h_cmd,h_stream,i_body_size);
		if( STX_OK != i_err ) {
			break;
		}

		// get the response content;
		i_err = stx_ini_create(NULL,h_stream,STX_INI_READ_ONLY|STX_INI_NO_COMMENT,0,&h_xini);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = h_xini->create_key(h_xini,NULL,g_sz_service_respond,NULL,&h_key);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = h_xini->read_int32(h_xini,h_key,&i_result);
		if( STX_OK != i_err ) {
			break;
		}
		if( STX_SERVICE_RESPOND_OK != i_result) {
			i_err = STX_EOF;
			break;
		}

		i_err = h_xini->create_key(h_xini,NULL,g_sz_file_size,NULL,&h_key);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = h_xini->read_int64(h_xini,h_key,i_size);
		if( STX_OK != i_err ) {
			break;
		}


		// download graph and http mode encode graph, only use STP_ID_STREAM_DATA channel;
		// this channel is created at the beginning of stp_download_test ;
		{
			s32			i,i_channel;
			STX_HANDLE	h_cha;
			char		sz_key[256];

			// channel num, and each channel id;
			i_err = h_xini->create_key(h_xini,NULL,g_sz_channel,NULL,&h_key);
			if( STX_OK != i_err ) {
				break;
			}
			i_err = h_xini->read_int32(h_xini,h_key,&i_channel);
			if( STX_OK != i_err ) {
				break;
			}

			if( i_channel > 16 ) {
				i_err = STX_ERR_INVALID_PARAM;
				break;
			}

			for( i = 0; i < i_channel; i ++ ) {

				stx_sprintf(sz_key,sizeof(sz_key),"%s-%d",g_sz_channel,i);
				i_err = h_xini->create_key(h_xini,h_key,sz_key,NULL,&h_cha);
				if( STX_OK != i_err ) {
					break;
				}

// 				i_err = h_xini->read_int32(h_xini,h_cha,&the->i_chid[i]);
// 				if( STX_OK != i_err ) {
// 					break;
// 				}
// 
// 				i_err = the->h_interleave->create_channel(the->h_interleave,
// 					the->i_chid[i], &the->h_data[i]);
// 				if( STX_OK != i_err ) {
// 					break;
// 				}

			} // for( i = 0; i < the->i_output; i ++ ) {

			if( STX_OK != i_err ) {
				break;
			}

		} // block;


		i_err = STX_OK;

	}while(FALSE);

	SAFE_CLOSEXIO(h_xini);

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
obsolete function. use stp_client to do the stx_protocol interactions;
***************************************************************************/
static STX_RESULT stp_download_test(char* sz_url,char* sz_file)
{
	DECL_TRACE

	STX_RESULT	i_err;
	stx_xio*	h_tcp;
	stx_xio*	h_stream;
	char		sz_param[128];
	size_t		i_read;
	u32			i_port;

	stx_interleaved*	h_interleave;
	stx_xio*			h_cmd_channel;
	stx_xio*			h_data_channel;

	s64 i_file_size;

	h_tcp = stx_create_io_tcp();
	if( !h_tcp ) {
		return STX_FAIL;
	}

	h_stream = NULL;

	/* TCP open; */
	i_port = atoi(g_sz_port_default);

	stx_io_tcp_make_string( g_sz_ip4_default, i_port, sz_param ,sizeof(sz_param ) );



	do{

		i_err = stx_io_tcp_make_open_string(NULL,sz_param,sz_param);
		if( STX_OK != i_err )  {
			break;
		}


		for( ; ; ) {
			i_err = h_tcp->open(h_tcp, sz_param, STX_XIO_TCP_OPEN_CONNECT | STX_XIO_TCP_OPEN_ASYNC );
			if( STX_OK == i_err || i_err < 0 ) {
				break;
			}

			if( STX_WOUNLD_BLOCK == i_err ) {
				stx_sleep(10);
			}
		}

		if( i_err < 0) {
			break;
		}

		h_interleave = XCREATE(stx_io_int,NULL,h_tcp, O_RDONLY);
		if(!h_interleave ) {
			i_err = STX_FAIL;
			break;
		}

		i_err = h_interleave->create_channel(h_interleave,STP_ID_SYS_RESPONSE, &h_cmd_channel);
		if( STX_OK != i_err ) {
			break;
		}

		// create STREAM_DATA channel;
		i_err = h_interleave->create_channel(h_interleave,STP_ID_STREAM_DATA, &h_data_channel);
		if( STX_OK != i_err ) {
			break;
		}

		//h_data_channel->open(h_data_channel,"e:\\read.dump",O_CREAT);

		i_err = STX_FAIL;

		h_stream = XCREATE(stx_io_stream,NULL);
		if( !h_stream ) {
			break;
		}

		i_err = write_cmd_download(h_stream,sz_url);
		if( STX_OK != i_err) {
			break;
		}

		i_err = write_out_stream(h_tcp,h_stream);
		if( STX_OK != i_err ) {
			break;
		}

		// parse response
		i_err = stp_download_response(h_cmd_channel,h_stream,&i_file_size);
		if( STX_OK != i_err ) {
			break;
		}
		if( i_file_size <= 0 ) {
			i_err = STX_EOF;
			break;
		}


		// save at local place;
		{
			stx_xio* h_file = stx_create_io_file();
			i_err = h_file->open(h_file,sz_file,O_CREAT);
			if( STX_OK != i_err){
				h_file->close(h_file);
				break;
			}
			// receive data;
			i_err = stp_download_file(h_data_channel,h_file,i_file_size);
			h_file->close(h_file);
			if( STX_OK != i_err ) {
				break;
			}
		}


		// write cmd close;
		h_stream->clear(h_stream);
		i_err = write_cmd_close_dwonload(h_stream);
		if( i_err < 0 ) {
			break;
		}
		i_err = write_out_stream(h_tcp,h_stream);
		if( STX_OK != i_err ) {
			break;
		}

		// wait for stx_service close the socket;
		for( ; ; ) {// 
			i_err = h_tcp->read(h_tcp,sz_param,4,&i_read);
			if( i_err < 0 || STX_EOF ==  i_err) {
				i_err = 0;
				break;
			}
			stx_sleep(10);
		}// for( ; ; ) {

		i_err = STX_OK;

	}while(FALSE);


	SAFE_CLOSEXIO(h_cmd_channel);
	SAFE_CLOSEXIO(h_data_channel);
	SAFE_XDELETE(h_interleave);

	h_tcp->close(h_tcp);

	if( h_stream ) {
		h_stream->close(h_stream);
	}

	return i_err;

}



#ifdef __USE_STX_DEBUG__
#	undef __THIS_FILE__
#endif

#endif // __STX_SERVICE_API_C__