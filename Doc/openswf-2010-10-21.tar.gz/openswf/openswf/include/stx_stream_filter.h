
#ifndef __STX_STREAM_FILTER_BASE_H__
#define __STX_STREAM_FILTER_BASE_H__


/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/


#include "stx_async_plugin.h"

#include "stx_stream_pin.h"

#include "stx_direct_pin.h"


#if defined( __cplusplus )
extern "C" {
#endif


	STX_COM_DECLARE(stream_filter);



STX_COM_BEGIN(stream_filter);

	STX_PUBLIC(async_plugin);

	STX_PURE    STX_PUBLIC(stx_base_filter);

	/* pure virtual functions; must be implemented at inherited class; */
	STX_PURE    STX_PURE_MSG_PROC_DECLARE(dispatch_msg)

	STX_PURE    STX_PURE_MSG_PROC_DECLARE(response_msg)

	STX_PURE    STX_PURE_MSG_PROC_DECLARE(up_stream_msg)

	STX_PURE    STX_PURE_MSG_PROC_DECLARE(down_stream_msg)

	/* share member functions; */
	STX_SHARE	STX_RESULT	(*run)(STX_HANDLE h,u32 i_wait_milisec);

	STX_SHARE	void		(*flush)(STX_HANDLE h);

	STX_SHARE   void 	  	(*new_segment)(STX_HANDLE h);

	/* other members; for sub class to inherited; */

	stx_stream_pin*				p_input_pin;

	stx_direct_pin*				p_output_pin;

	stx_media_data*				p_input_data;

	stx_media_data*				p_output_data;

	b32					        b_deliver;

	stx_media_data_allocator*   p_mem_alloc;

STX_COM_END();


#define stream_filter_funcdecl(PREFIX) \
	STX_MSG_PROC_DECLARE( PREFIX ## _xxx_ ## dispatch_msg)\
	STX_MSG_PROC_DECLARE( PREFIX ## _xxx_ ## response_msg)\
	STX_MSG_PROC_DECLARE( PREFIX ## _xxx_ ## up_stream_msg)\
	STX_MSG_PROC_DECLARE( PREFIX ## _xxx_ ## down_stream_msg)\
	stx_base_filter_funcdecl( PREFIX ## _stx_base_filter_vt )

#define stream_filter_funcinit(vt,PREFIX) \
	if( ! STX_NEW(stream_filter,&vt,"STX_NEW(stream_filter;") ) {\
		break;\
	}\
	STX_VT_INIT(vt,PREFIX,dispatch_msg);\
	STX_VT_INIT(vt,PREFIX,response_msg);\
	STX_VT_INIT(vt,PREFIX,up_stream_msg);\
	STX_VT_INIT(vt,PREFIX,down_stream_msg)





#if defined( __cplusplus )
}
#endif


#endif /* __STX_STREAM_FILTER_BASE_H__ */ 