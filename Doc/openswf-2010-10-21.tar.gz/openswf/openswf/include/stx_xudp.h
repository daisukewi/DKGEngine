



#ifndef __STX_XUDP_H__
#define __STX_XUDP_H__

/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#include "stx_base_type.h"

#include "stx_sock_err.h"


#if defined( __cplusplus )
extern "C" {
#endif



#define XUDP_MAX_SOCKETS   256


typedef struct stx_xudp stx_xudp;

typedef struct stx_xudp_cln stx_xudp_cln;

struct stx_xudp {

/*********************************************************
normal socket like interface functions;
*********************************************************/
	int32_t		(*socket)( stx_xudp* xudp, 
		int32_t		af, 
		int32_t		type, 
		int32_t		protocol );

	int32_t     (*closesocket)( stx_xudp* xudp,
		int32_t i_socket);

	int32_t		(*listen)( stx_xudp* xudp,
		int32_t i_socket, 
		int32_t	backlog );

	SOCKET		(*accept)( stx_xudp* xudp,
		int32_t				i_socket, 
		struct sockaddr*	addr,  
		int32_t*			addrlen  );

	int32_t		(*connect)( stx_xudp* xudp,
		int32_t		i_socket, 
		STX_BYTE*	p_sockaddr, 
		int32_t		namelen );

	int32_t		(*select)( stx_xudp* xudp,
		int32_t			i_socket, 
		fd_set*			readfds, 
		fd_set*			writefds, 
		fd_set*			exceptfds, 
		struct timeval*	timeout );

	int32_t		(*recv)( stx_xudp* xudp,
		int32_t		i_socket, 
		char*		buf, 
		int32_t		len, 
		int32_t		flags);

	int32_t		(*write)( stx_xudp* xudp,
		int32_t		i_socket, 
		char*		buf, 
		int32_t		len);

	int32_t		(*setopt)( stx_xudp* xudp,
		int32_t		i_socket, 
		uint32_t	i_set_flags, 
		uint32_t	i_set_opt, 
		int32_t*	i_args );

	int32_t		(*getopt)( stx_xudp* xudp,
		int32_t		i_socket, 
		int32_t		level,        
		int32_t		optname,      
		char*		optval, 
		int32_t*	optlen  );

	int32_t		(*bind)( stx_xudp* xudp,
		int32_t		i_socket, 
		STX_BYTE*	p_sockaddr, 
		int32_t		namelen );

	int			(*getsockname)( stx_xudp* xudp,
		int32_t				i_socket, 
		struct sockaddr*	name,  
		int32_t*			namelen	);

	int			(*getpeername)( stx_xudp* xudp,
		int32_t				i_socket, 
		struct sockaddr*	name,  
		int32_t*			namelen	);

};


struct stx_xudp_cln {

/*********************************************************
config local and remote server;
*********************************************************/
	STX_RESULT	(*open)( stx_xudp_cln* xudp_cln, char* sz_xini, stx_xio* h_xini );

/*********************************************************
close the interface and all it's socket instance;;
*********************************************************/
	void		(*close)( stx_xudp_cln* xudp_cln );

/*********************************************************
extract the interface;
*********************************************************/
	stx_xudp*	(*get_xudp)( stx_xudp_cln* xudp_cln );
};


stx_xudp_cln* stx_create_xudp_cln();




#if defined( __cplusplus )
}
#endif


#endif /*    __STX_XUDP_H__   */ 
