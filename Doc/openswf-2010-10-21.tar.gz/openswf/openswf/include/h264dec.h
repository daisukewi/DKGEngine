// LxH264Dec.h: interface for the LxH264Dec class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(__LXH264DEC_H__)
#define __LXH264DEC_H__


#include "stx_base_type.h"
#include "h264data.h"
#include "stx_video_frame.h"
#include "get_bits.h"

#if defined( __cplusplus )
extern "C" {
#endif



#define MAX_ITEM_VALUE  0x7fffffff

#define INTERNAL_BUFFER_SIZE 32

#define ALIGN(x, a) (((x)+(a)-1)&~((a)-1))

#define interlaced_dct       interlaced_dct_is_a_bad_name
#define mb_intra             mb_intra_isnt_initalized_see_mb_type

#define LUMA_DC_BLOCK_INDEX   25
#define CHROMA_DC_BLOCK_INDEX 26

#define CHROMA_DC_COEFF_TOKEN_VLC_BITS 8
#define COEFF_TOKEN_VLC_BITS           8
#define TOTAL_ZEROS_VLC_BITS           9
#define CHROMA_DC_TOTAL_ZEROS_VLC_BITS 3
#define RUN_VLC_BITS                   3
#define RUN7_VLC_BITS                  6

#define MAX_SPS_COUNT 32
#define MAX_PPS_COUNT 256

#define MAX_MMCO_COUNT 66


#define CABAC_BITS 8
#define CABAC_MASK ((1<<CABAC_BITS)-1)


	STX_INTERF(CABACContext);

struct CABACContext{
	u32			low0;        // 64 bits mode use;
    u32			low;         //
    s32			range;       //
	s32			queue;       // bits saved in low/low0;
	s32			nTotalBytes; // rem data;
	u8*			lpCurData;   // current buffer pointer;
	u8			byCabacState[512];
};


//extern u8 cropTbl[256 + 2 * MAX_NEG_CROP];


// for 1920*1088, nMbSize is 120 * 68 = 8160;
// so the pos table size is 8160 * 2 = aboud 16k;
// slice group map is 8k;
// mb type is 16k;
// total 40k used;

STX_INTERF(MbMapInf);

struct MbMapInf
{
	u8     nMbPosX;
	u8     nMbPosY;
};

#define MAKE_BOXOUT_DIR( x,y )  ( ( ( x < 0 ? 2 : x ) << 1 ) | ( ( y < 0 ? 2 : y ) << 3 ) )
#define GET_BOXOUT_DIR(x,y,dir)\
{\
x = ( dir >> 1 ) & 3; \
x = x > 1 ? -1 : x;   \
y = ( dir >> 3 ) & 3; \
y = y > 1 ? -1 : y;   \
}

/**
 * Sequence parameter set
 */

STX_INTERF(HRDPS);
struct HRDPS{
	// hrd;
	s32             cpb_count;
	s32             bit_rate_scale;
	s32             cpb_size_scale;
	s32             bit_rate_value_minus1[32]; 
	s32             cpb_size_value_minus1[32];   
	s32             cbr_flag[32];  
	s32             initial_cpb_removal_delay_length_minus1  ;
	s32             cpb_removal_delay_length_minus1  ;
	s32             dpb_output_delay_length_minus1  ;
	s32             time_offset_length ;
};

STX_INTERF(SPS);

struct SPS{
    
    s32             profile_idc;
    s32             level_idc;
    s32             transform_bypass;              ///< qpprime_y_zero_transform_bypass_flag
    s32             log2_max_frame_num;            ///< log2_max_frame_num_minus4 + 4

	s32             nPicOrderCntType;              //< pic_order_cnt_type

    s32             log2_max_poc_lsb;              ///< log2_max_pic_order_cnt_lsb_minus4
    s32             delta_pic_order_always_zero_flag;
    s32             offset_for_non_ref_pic;
    s32             offset_for_top_to_bottom_field;
    s32             poc_cycle_length;              ///< num_ref_frames_in_pic_order_cnt_cycle
    s32             ref_frame_count;               ///< num_ref_frames
    s32             gaps_in_frame_num_allowed_flag;
    s32             mb_width;                      ///< frame_width_in_mbs_minus1 + 1
    s32             mb_height;                     ///< frame_height_in_mbs_minus1 + 1
    s32             frame_mbs_only_flag;
    s32             mb_aff;                        ///<mb_adaptive_frame_field_flag
    s32             direct_8x8_inference_flag;
    s32             crop;                          ///< frame_cropping_flag
    s32             crop_left;                     ///< frame_cropping_rect_left_offset
    s32             crop_right;                    ///< frame_cropping_rect_right_offset
    s32             crop_top;                      ///< frame_cropping_rect_top_offset
    s32             crop_bottom;                   ///< frame_cropping_rect_bottom_offset

	// vui;
    s32             vui_parameters_present_flag;
    AVRational      sar;

	s32             overscan_info_present_flag  ;
	s32             overscan_appropriate_flag ;
	s32             video_signal_type_present_flag  ;
	s32             video_format  ;
	s32             video_full_range_flag  ;
	s32             colour_description_present_flag  ;
	s32             colour_primaries  ;
	s32             transfer_characteristics  ;
	s32             matrix_coefficients ;
	s32             chroma_location_info_present_flag  ;
	s32             chroma_sample_location_type_top_field  ;
	s32             chroma_sample_location_type_bottom_field ;

    s32             timing_info_present_flag;
    u32           num_units_in_tick;
    u32           time_scale;
    s32             fixed_frame_rate_flag;
    s32             nal_hrd_parameters_present_flag;
	s32             vcl_hrd_parameters_present_flag; 
	HRDPS           nal_hrdps;
	HRDPS           vcl_hrdps;

	s32             low_delay_hrd_flag;
	s32             pic_struct_present_flag;

    s32             bitstream_restriction_flag;
	s32             motion_vectors_over_pic_boundaries_flag  ;
	s32             max_bytes_per_pic_denom  ;
	s32             max_bits_per_mb_denom  ;
	s32             log2_max_mv_length_horizontal  ;
	s32             log2_max_mv_length_vertical ;
    s32             num_reorder_frames;
	s32             max_dec_frame_buffering;

    s16           offset_for_ref_frame[256];     //FIXME dyn aloc?
	s32				sps_id;
};


/**
 * Picture parameter set
 */
STX_INTERF(PPS);
struct PPS{
    s32                sps_id;
	b32                bCabac;       //< entropy_coding_mode_flag

    s32                pic_order_present;      ///< pic_order_present_flag
    s32                slice_group_count;      ///< num_slice_groups_minus1 + 1
    s32                mb_slice_group_map_type;

	//<< baojinlong, added at 2006-06-08;
	s32*               pRunLength;
	s32*               pTopLeftMb;
	s32*               pBottomRightMb;
	u8*					pSliceGroupIdBase;
	u8*					pSliceGroupId;
	s32                slice_group_change_direction_flag;
	s32                slice_group_change_rate_minus1;
	s32                slice_group_id_cnt_minus1;
	//>>       
       
    s32                nRefCount[2];           ///< num_ref_idx_l(0/1)_active_minus1 + 1
       
    s32                weighted_pred;          ///< weighted_pred_flag
    s32                weighted_bipred_idc;
    s32                init_qp;                ///< pic_init_qp_minus26 + 26
    s32                init_qs;                ///< pic_init_qs_minus26 + 26
    s32                chroma_qp_index_offset;
    s32                deblocking_filter_parameters_present; ///< deblocking_filter_parameters_present_flag
    s32                constrained_intra_pred; ///< constrained_intra_pred_flag
    s32                redundant_pic_cnt_present; ///< redundant_pic_cnt_present_flag
    s32                transform_8x8_mode;     ///< transform_8x8_mode_flag
	s32                pic_scaling_matrix_present_flag;
	s32                second_chroma_qp_index_offset;

	//<< extensions;
	s32                nMbWidth;
	s32                nMbHeight;
	s32                nMbSize;
	MbMapInf*          pMbMapInf;
	s16*             pMbFlag;

	SPS*               pCurSps;
	// extensions ; >> 
};


/**
 * Memory management control operation opcode.
 */
enum MMCOOpcode{
    MMCO_END = 0,
    MMCO_SHORT2UNUSED,
    MMCO_LONG2UNUSED,
    MMCO_SHORT2LONG,
    MMCO_SET_MAX_LONG,
    MMCO_RESET, 
    MMCO_LONG,
	MMCO_CUR2SHORT,
	MMCO_OVERFLOW,
};

typedef enum MMCOOpcode MMCOOpcode;

/**
 * Memory management control operation.
 */
STX_INTERF(MMCO);
struct MMCO{
    MMCOOpcode opcode;
    s32        short_frame_num;
    s32        long_index;
	s32        pad;
};





#define NAL_SLICE	         	1
#define NAL_DPA					2
#define NAL_DPB					3
#define NAL_DPC					4

#define NAL_IDR_SLICE			5
#define NAL_SEI					6

#define NAL_SPS					7     //<<
#define NAL_PPS					8     //used to find decode unit;
#define NAL_PICTURE_DELIMITER	9     //>>

#define NAL_FILTER_DATA			10

#define SMAPTYPE_INTERLEAVE                0
#define SMAPTYPE_DISPERSE                  1
#define SMAPTYPE_FOREGROUND_BACKGROUND     2
#define SMAPTYPE_BOXOUT                    3
#define SMAPTYPE_RASTER_SCAN               4
#define SMAPTYPE_WIPE                      5
#define SMAPTYPE_EXPLICIT                  6

enum  SliceMapType{
	emInterleave = 0,
	emDisperse = 1,
	emForeGroundBackGround = 2,
	emBoxOutClockWise = 3,
	emBoxOutCounterClockWize = 4,
	emRasterScan = 5,
	emReverseRasterScan = 6,
	emWipeRight = 7,
	emWipeLeft = 8,
	emExplicit = 9,
};
typedef enum  SliceMapType SliceMapType;


enum emNameOfMbType
{
	emI_4x4 = 0,        
	emI_16x16_0_0_0 = 1,
	emI_16x16_1_0_0 = 2,
	emI_16x16_2_0_0 = 3 ,
	emI_16x16_3_0_0 = 4 ,
	emI_16x16_0_1_0 = 5 ,
	emI_16x16_1_1_0 = 6 ,
	emI_16x16_2_1_0 = 7 ,
	emI_16x16_3_1_0 = 8 ,
	emI_16x16_0_2_0 = 9 ,
	emI_16x16_1_2_0 = 10,
	emI_16x16_2_2_0 = 11,
	emI_16x16_3_2_0 = 12,
	emI_16x16_0_0_1 = 13,
	emI_16x16_1_0_1 = 14,
	emI_16x16_2_0_1 = 15,
	emI_16x16_3_0_1 = 16,
	emI_16x16_0_1_1 = 17,
	emI_16x16_1_1_1 = 18,
	emI_16x16_2_1_1 = 19,
	emI_16x16_3_1_1 = 20,
	emI_16x16_0_2_1 = 21,
	emI_16x16_1_2_1 = 22,
	emI_16x16_2_2_1 = 23,
	emI_16x16_3_2_1 = 24,
	emI_PCM         = 25, 

	emSI            = 26,

	emP_L0_16x16    = 27,
	emP_L0_L0_16x8  = 28,
	emP_L0_L0_8x16  = 29,
	emP_8x8         = 30,
	emP_8x8ref0     = 31,
	emP_Skip        = 32,

	emB_Direct_16x16,
	emB_L0_16x16    ,
	emB_L1_16x16    ,
	emB_Bi_16x16    ,
	emB_L0_L0_16x8  ,
	emB_L0_L0_8x16  ,
	emB_L1_L1_16x8  ,
	emB_L1_L1_8x16  ,
	emB_L0_L1_16x8  ,
	emB_L0_L1_8x16  ,
	emB_L1_L0_16x8  ,
	emB_L1_L0_8x16  ,
	emB_L0_Bi_16x8  ,
	emB_L0_Bi_8x16  ,
	emB_L1_Bi_16x8  ,
	emB_L1_Bi_8x16  ,
	emB_Bi_L0_16x8  ,
	emB_Bi_L0_8x16  ,
	emB_Bi_L1_16x8  ,
	emB_Bi_L1_8x16  ,
	emB_Bi_Bi_16x8  ,
	emB_Bi_Bi_8x16  ,
	emB_8x8         ,
	emB_Skip        ,

	emMbTypeErr,


};
typedef enum emNameOfMbType emNameOfMbType;



enum emMbPartPredMode
{
	emIntra4x4   ,
	emIntra16x16 ,
	emPred_L0    ,
	emPred_L1    ,
	emBiPred     ,
	emDirect     ,
	emNa         ,
};
typedef enum emMbPartPredMode emMbPartPredMode;

STX_INTERF(LxMbTypeInf_I);
struct LxMbTypeInf_I
{
	emNameOfMbType     emTypeName;
	emMbPartPredMode   emPartPredMode;
	u8      byIntra16x16PredMode;
	u8      byCpbUV;
	u8      byCbpY;
	u8      byMbPart;
	s32                nPad;
};
STX_INTERF(LxMbTypeInf_PB);
struct LxMbTypeInf_PB
{
	emNameOfMbType     emTypeName;
	emMbPartPredMode   emPartPredMode0;
	emMbPartPredMode   emPartPredMode1;
	u8               byMbPart;
	u8               byMbPartWith;
	u8               byMbPartHeight;
	u8               byPad;
};




static const LxMbTypeInf_I MbTypeInfTab_I[] = {
	{ emI_4x4,          emIntra4x4,    0 , 0, 0 ,},
	{ emI_16x16_0_0_0 , emIntra16x16,  0 , 0, 0 ,},
	{ emI_16x16_1_0_0 , emIntra16x16,  1 , 0, 0 ,},
	{ emI_16x16_2_0_0 , emIntra16x16,  2 , 0, 0 ,},
	{ emI_16x16_3_0_0 , emIntra16x16,  3 , 0, 0 ,},
	{ emI_16x16_0_1_0 , emIntra16x16,  0 , 1, 0 ,},
	{ emI_16x16_1_1_0 , emIntra16x16,  1 , 1, 0 ,},
	{ emI_16x16_2_1_0 , emIntra16x16,  2 , 1, 0 ,},
	{ emI_16x16_3_1_0 , emIntra16x16,  3 , 1, 0 ,},
	{ emI_16x16_0_2_0 , emIntra16x16,  0 , 2, 0 ,},
	{ emI_16x16_1_2_0 , emIntra16x16,  1 , 2, 0 ,},
	{ emI_16x16_2_2_0 , emIntra16x16,  2 , 2, 0 ,},
	{ emI_16x16_3_2_0 , emIntra16x16,  3 , 2, 0 ,},
	{ emI_16x16_0_0_1 , emIntra16x16,  0 , 0, 15,},
	{ emI_16x16_1_0_1 , emIntra16x16,  1 , 0, 15,},
	{ emI_16x16_2_0_1 , emIntra16x16,  2 , 0, 15,},
	{ emI_16x16_3_0_1 , emIntra16x16,  3 , 0, 15,},
	{ emI_16x16_0_1_1 , emIntra16x16,  0 , 1, 15,},
	{ emI_16x16_1_1_1 , emIntra16x16,  1 , 1, 15,},
	{ emI_16x16_2_1_1 , emIntra16x16,  2 , 1, 15,},
	{ emI_16x16_3_1_1 , emIntra16x16,  3 , 1, 15,},
	{ emI_16x16_0_2_1 , emIntra16x16,  0 , 2, 15,},
	{ emI_16x16_1_2_1 , emIntra16x16,  1 , 2, 15,},
	{ emI_16x16_2_2_1 , emIntra16x16,  2 , 2, 15,},
	{ emI_16x16_3_2_1 , emIntra16x16,  3 , 2, 15,},
	{ emI_PCM         , emNa        ,  0 , 0, 0 ,},
	// 26 ????
	{ emMbTypeErr     , emNa        ,  0 , 0, 0 ,},   // error;
};// I_TYPE;

static const LxMbTypeInf_PB MbTypeInfTab_P[] = {
	{ emP_L0_16x16,     emPred_L0,   emNa,      1,   16 , 16, 0  },
	{ emP_L0_L0_16x8,   emPred_L0,   emPred_L0, 2,   16 , 8 , 0  },
	{ emP_L0_L0_8x16,   emPred_L0,   emPred_L0, 2,   8  , 16, 0  },
	{ emP_8x8,          emNa,        emNa,      4,   8  , 8 , 0  },
	{ emP_8x8ref0,      emNa,        emNa,      4,   8  , 8 , 0  },
	{ emP_Skip,         emPred_L0,   emNa,      1,   16 , 16, 0  },
};  // P_TYPE;


static const LxMbTypeInf_PB MbTypeInfTab_B[] = {
	{ emB_Direct_16x16,  emDirect  ,  emNa      ,  0  ,   8  ,   8  },
	{ emB_L0_16x16    ,  emPred_L0 ,  emNa      ,  1  ,   16 ,   16 },
	{ emB_L1_16x16    ,  emPred_L1 ,  emNa      ,  1  ,   16 ,   16 },
	{ emB_Bi_16x16    ,  emBiPred  ,  emNa      ,  1  ,   16 ,   16 },
	{ emB_L0_L0_16x8  ,  emPred_L0 ,  emPred_L0 ,  2  ,   16 ,   8  },
	{ emB_L0_L0_8x16  ,  emPred_L0 ,  emPred_L0 ,  2  ,   8  ,   16 },
	{ emB_L1_L1_16x8  ,  emPred_L1 ,  emPred_L1 ,  2  ,   16 ,   8  },
	{ emB_L1_L1_8x16  ,  emPred_L1 ,  emPred_L1 ,  2  ,   8  ,   16 },
	{ emB_L0_L1_16x8  ,  emPred_L0 ,  emPred_L1 ,  2  ,   16 ,   8  },
	{ emB_L0_L1_8x16  ,  emPred_L0 ,  emPred_L1 ,  2  ,   8  ,   16 },
	{ emB_L1_L0_16x8  ,  emPred_L1 ,  emPred_L0 ,  2  ,   16 ,   8  },
	{ emB_L1_L0_8x16  ,  emPred_L1 ,  emPred_L0 ,  2  ,   8  ,   16 },
	{ emB_L0_Bi_16x8  ,  emPred_L0 ,  emBiPred  ,  2  ,   16 ,   8  },
	{ emB_L0_Bi_8x16  ,  emPred_L0 ,  emBiPred  ,  2  ,   8  ,   16 },
	{ emB_L1_Bi_16x8  ,  emPred_L1 ,  emBiPred  ,  2  ,   16 ,   8  },
	{ emB_L1_Bi_8x16  ,  emPred_L1 ,  emBiPred  ,  2  ,   8  ,   16 },
	{ emB_Bi_L0_16x8  ,  emBiPred  ,  emPred_L0 ,  2  ,   16 ,   8  },
	{ emB_Bi_L0_8x16  ,  emBiPred  ,  emPred_L0 ,  2  ,   8  ,   16 },
	{ emB_Bi_L1_16x8  ,  emBiPred  ,  emPred_L1 ,  2  ,   16 ,   8  },
	{ emB_Bi_L1_8x16  ,  emBiPred  ,  emPred_L1 ,  2  ,   8  ,   16 },
	{ emB_Bi_Bi_16x8  ,  emBiPred  ,  emBiPred  ,  2  ,   16 ,   8  },
	{ emB_Bi_Bi_8x16  ,  emBiPred  ,  emBiPred  ,  2  ,   8  ,   16 },
	{ emB_8x8         ,  emNa      ,  emNa      ,  4  ,   8  ,   8  },
	{ emB_Skip        ,  emDirect  ,  emNa      ,  0  ,   8  ,   8  },
};  // B_TYPE;

static const LxMbTypeInf_PB MbTypeInfTab_SP[8] = {
	{ emP_L0_16x16   , emPred_L0, emNa     , 1  , 16 , 16 },
	{ emP_L0_L0_16x8 , emPred_L0, emPred_L0, 2  , 16 , 8  },
	{ emP_L0_L0_8x16 , emPred_L0, emPred_L0, 2  , 8  , 16 },
	{ emP_8x8        , emNa     , emNa     , 4  , 8  , 8  },
	{ emP_8x8ref0    , emNa     , emNa     , 4  , 8  , 8  },
	{ emP_Skip       , emPred_L0, emNa     , 1  , 16 , 16 },
}; // SP;



//<< sub mb type and pred;
enum emNameOfSubMbTypeP{
	emP_L0_8x8 = 0,
	emP_L0_8x4,
	emP_L0_4x8,
	emP_L0_4x4,
};
typedef enum emNameOfSubMbTypeP emNameOfSubMbTypeP;

//<< sub mb type and pred;
enum emNameOfSubMbTypeB{
	emB_Direct_8x8 = 0,
	emB_L0_8x8,    
	emB_L1_8x8,    
	emB_Bi_8x8,    
	emB_L0_8x4,    
	emB_L0_4x8,    
	emB_L1_8x4,    
	emB_L1_4x8,    
	emB_Bi_8x4,    
	emB_Bi_4x8,    
	emB_L0_4x4,    
	emB_L1_4x4,    
	emB_Bi_4x4,    
};
typedef enum emNameOfSubMbTypeB emNameOfSubMbTypeB;

STX_INTERF(LxSubMbTypeInf);
struct LxSubMbTypeInf
{
	s32                emTypeName;
	emMbPartPredMode   emPartPredMode;

	u8               byMbPart;
	u8               byMbPartWith;
	u8               byMbPartHeight;
	u8               byPad;

	u32              dwPad;
};

/*
Table 7-14 �C Sub-macroblock types in P macro blocks
sub_mb_type	Name		NumSubMbPart	SubMbPredMode	SubMbPartWidth	SubMbPartHeight
0			P_L0_8x8	1				Pred_L0			8				8
1			P_L0_8x4	2				Pred_L0			8				4
2			P_L0_4x8	2				Pred_L0			4				8
3			P_L0_4x4	4				Pred_L0			4				4
*/

static const  LxSubMbTypeInf g_SubMbInfTab_P[] = {
	{	emP_L0_8x8, emPred_L0, 1, 8, 8	},
	{   emP_L0_8x4, emPred_L0, 2, 8, 4	},
	{   emP_L0_4x8, emPred_L0, 2, 4, 8	},
	{   emP_L0_4x4, emPred_L0, 4, 4, 4	},
};

/* Table 7-15 �C Sub-macroblock types in B macro blocks
sub_mb_type	Name			NumSubMbPart	SubMbPredMode	SubMbPartWidth	SubMbPartHeight
na			B_Skip			na				Direct			4				4
na			B_Direct_16x16	na				Direct			4				4
0			B_Direct_8x8	na				Direct			4 				4
1			B_L0_8x8		1				Pred_L0			8 				8
2			B_L1_8x8		1				Pred_L1			8 				8
3			B_Bi_8x8		1				BiPred			8 				8
4			B_L0_8x4		2				Pred_L0			8 				4
5			B_L0_4x8		2				Pred_L0			4 				8
6			B_L1_8x4		2				Pred_L1			8 				4
7			B_L1_4x8		2				Pred_L1			4 				8
8			B_Bi_8x4		2				BiPred			8 				4
9			B_Bi_4x8		2				BiPred			4 				8
10			B_L0_4x4		4				Pred_L0			4 				4
11			B_L1_4x4		4				Pred_L1			4 				4
12			B_Bi_4x4		4				BiPred			4 				4
*/

static const LxSubMbTypeInf g_SubMbInfTab_B[] = {

	{ emB_Direct_8x8,  emDirect ,     0,      4,      4   },
	{ emB_L0_8x8,      emPred_L0,     1,      8,      8   },
	{ emB_L1_8x8,      emPred_L1,     1,      8,      8   },
	{ emB_Bi_8x8,      emBiPred ,     1,      8,      8   },
	{ emB_L0_8x4,      emPred_L0,     2,      8,      4   },
	{ emB_L0_4x8,      emPred_L0,     2,      4,      8   },
	{ emB_L1_8x4,      emPred_L1,     2,      8,      4   },
	{ emB_L1_4x8,      emPred_L1,     2,      4,      8   },
	{ emB_Bi_8x4,      emBiPred ,     2,      8,      4   },
	{ emB_Bi_4x8,      emBiPred ,     2,      4,      8   },
	{ emB_L0_4x4,      emPred_L0,     4,      4,      4   },
	{ emB_L1_4x4,      emPred_L1,     4,      4,      4   },
	{ emB_Bi_4x4,      emBiPred ,     4,      4,      4   },
};


// sub mb type and pred; >> 

STX_INTERF(LxMbCbpInf);

struct LxMbCbpInf{
	u8 byIntra_4x4;
	u8 byInter;
};

static const LxMbCbpInf MbCbpInfTab[] = {
	//DRAFT ISO/IEC 14496-10 : 2002 (E)
	//DRAFT ITU-T Rec. H.264 (2002 E) 151
	//152 DRAFT ITU-T Rec. H.264 (2002 E)
	{  47 , 0   },	{  31 , 16  },	{  15 , 1   },	{  0  , 2   },
	{  23 , 4   },	{  27 , 8   },	{  29 , 32  },	{  30 , 3   },
	{  7  , 5   },	{  11 , 10  },	{  13 , 12  },	{  14 , 15  },
	{  39 , 47  },	{  43 , 7   },	{  45 , 11  },	{  46 , 13  },
	{  16 , 14  },	{  3  , 6   },	{  5  , 9   },	{  10 , 31  },
	{  12 , 35  },	{  19 , 37  },	{  21 , 42  },	{  26 , 44  },
	{  28 , 33  },	{  35 , 34  },	{  37 , 36  },	{  42 , 40  },
	{  44 , 39  },	{  1  , 43  },	{  2  , 45  },	{  4  , 46  },
	{  8  , 17  },	{  17 , 18  },	{  18 , 20  },	{  20 , 24  },
	{  24 , 19  },	{  6  , 21  },	{  9  , 26  },	{  22 , 28  },
	{  25 , 23  },	{  32 , 27  },	{  33 , 29  },	{  34 , 30  },
	{  36 , 22  },	{  40 , 25  },	{  38 , 38  },	{  41 , 41  },
}; 



static const u8 lps_range[64][4]= {
	{128,176,208,240}, {128,167,197,227}, {128,158,187,216}, {123,150,178,205},
	{116,142,169,195}, {111,135,160,185}, {105,128,152,175}, {100,122,144,166},
	{ 95,116,137,158}, { 90,110,130,150}, { 85,104,123,142}, { 81, 99,117,135},
	{ 77, 94,111,128}, { 73, 89,105,122}, { 69, 85,100,116}, { 66, 80, 95,110},
	{ 62, 76, 90,104}, { 59, 72, 86, 99}, { 56, 69, 81, 94}, { 53, 65, 77, 89},
	{ 51, 62, 73, 85}, { 48, 59, 69, 80}, { 46, 56, 66, 76}, { 43, 53, 63, 72},
	{ 41, 50, 59, 69}, { 39, 48, 56, 65}, { 37, 45, 54, 62}, { 35, 43, 51, 59},
	{ 33, 41, 48, 56}, { 32, 39, 46, 53}, { 30, 37, 43, 50}, { 29, 35, 41, 48},
	{ 27, 33, 39, 45}, { 26, 31, 37, 43}, { 24, 30, 35, 41}, { 23, 28, 33, 39},
	{ 22, 27, 32, 37}, { 21, 26, 30, 35}, { 20, 24, 29, 33}, { 19, 23, 27, 31},
	{ 18, 22, 26, 30}, { 17, 21, 25, 28}, { 16, 20, 23, 27}, { 15, 19, 22, 25},
	{ 14, 18, 21, 24}, { 14, 17, 20, 23}, { 13, 16, 19, 22}, { 12, 15, 18, 21},
	{ 12, 14, 17, 20}, { 11, 14, 16, 19}, { 11, 13, 15, 18}, { 10, 12, 15, 17},
	{ 10, 12, 14, 16}, {  9, 11, 13, 15}, {  9, 11, 12, 14}, {  8, 10, 12, 14},
	{  8,  9, 11, 13}, {  7,  9, 11, 12}, {  7,  9, 10, 12}, {  7,  8, 10, 11},
	{  6,  8,  9, 11}, {  6,  7,  9, 10}, {  6,  7,  8,  9}, {  2,  2,  2,  2},
};

static const u8 mps_state[64]= {
	1, 2, 3, 4, 5, 6, 7, 8,
	9,10,11,12,13,14,15,16,
	17,18,19,20,21,22,23,24,
	25,26,27,28,29,30,31,32,
	33,34,35,36,37,38,39,40,
	41,42,43,44,45,46,47,48,
	49,50,51,52,53,54,55,56,
	57,58,59,60,61,62,62,63,
};

static const u8 lps_state[64]= {
	0, 0, 1, 2, 2, 4, 4, 5,
	6, 7, 8, 9, 9,11,11,12,
	13,13,15,15,16,16,18,18,
	19,19,21,21,22,22,23,24,
	24,25,26,26,27,27,28,29,
	29,30,30,30,31,32,32,33,
	33,33,34,34,35,35,35,36,
	36,36,37,37,37,38,38,63,
};

static const u8 lx_h264_norm_shift[512]= {
	9,8,7,7,6,6,6,6,5,5,5,5,5,5,5,5,
	4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,
	3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,
	3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,
	2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,
	2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,
	2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,
	2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,
	1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
	1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
	1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
	1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
};



/*
* exp golomb vlc stuff
* Copyright (c) 2003 Michael Niedermayer <michaelni@gmx.at>
* Copyright (c) 2004 Alex Beregszaszi
*
* This library is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 2 of the License, or (at your option) any later version.
*
* This library is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public
* License along with this library; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*
*/

/**
* @file golomb.h
* @brief 
*     exp golomb vlc stuff
* @author Michael Niedermayer <michaelni@gmx.at> and Alex Beregszaszi
*/

#define INVALID_VLC           0x80000000

static const u8 ff_golomb_vlc_len[512]={
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,
	7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
	5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,
	5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,
	3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,
	3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,
	3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,
	3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,
	1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
	1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
	1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
	1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
	1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
	1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
	1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
	1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1
};

static const u8 ff_ue_golomb_vlc_code[512]={ 
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,
	7, 7, 7, 7, 8, 8, 8, 8, 9, 9, 9, 9,10,10,10,10,11,11,11,11,12,12,12,12,13,13,13,13,14,14,14,14,
	3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4,
	5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
	2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

static const signed char ff_se_golomb_vlc_code[512]={ 
	0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  8, -8,  9, -9, 10,-10, 11,-11, 12,-12, 13,-13, 14,-14, 15,-15,
	4,  4,  4,  4, -4, -4, -4, -4,  5,  5,  5,  5, -5, -5, -5, -5,  6,  6,  6,  6, -6, -6, -6, -6,  7,  7,  7,  7, -7, -7, -7, -7,
	2,  2,  2,  2,  2,  2,  2,  2,  2,  2,  2,  2,  2,  2,  2,  2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2,
	3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3, -3, -3, -3, -3, -3, -3, -3, -3, -3, -3, -3, -3, -3, -3, -3, -3,
	1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,
	1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,
	-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
	-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
	0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
	0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
	0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
	0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
	0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
	0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
	0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
	0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
};


static const u8 ff_ue_golomb_len[256]={ 
	1, 3, 3, 5, 5, 5, 5, 7, 7, 7, 7, 7, 7, 7, 7, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9,11,
	11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,13,
	13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,
	13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,15,
	15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,
	15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,
	15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,
	15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,17,
};

static const u8 ff_interleaved_golomb_vlc_len[256]={
	9,9,7,7,9,9,7,7,5,5,5,5,5,5,5,5,
	9,9,7,7,9,9,7,7,5,5,5,5,5,5,5,5,
	3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,
	3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,
	9,9,7,7,9,9,7,7,5,5,5,5,5,5,5,5,
	9,9,7,7,9,9,7,7,5,5,5,5,5,5,5,5,
	3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,
	3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,
	1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
	1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
	1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
	1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
	1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
	1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
	1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
	1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
};

static const u8 ff_interleaved_ue_golomb_vlc_code[256]={ 
	15,16,7, 7, 17,18,8, 8, 3, 3, 3, 3, 3, 3, 3, 3,
	19,20,9, 9, 21,22,10,10,4, 4, 4, 4, 4, 4, 4, 4, 
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	23,24,11,11,25,26,12,12,5, 5, 5, 5, 5, 5, 5, 5, 
	27,28,13,13,29,30,14,14,6, 6, 6, 6, 6, 6, 6, 6,
	2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
	2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
};

static const signed char ff_interleaved_se_golomb_vlc_code[256]={ 
	8, -8,  4,  4,  9, -9, -4, -4,  2,  2,  2,  2,  2,  2,  2,  2,
	10,-10,  5,  5, 11,-11, -5, -5, -2, -2, -2, -2, -2, -2, -2, -2,
	1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,
	1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,
	12,-12,  6,  6, 13,-13, -6, -6,  3,  3,  3,  3,  3,  3,  3,  3,
	14,-14,  7,  7, 15,-15, -7, -7, -3, -3, -3, -3, -3, -3, -3, -3,
	-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
	-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
	0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
	0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
	0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
	0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
	0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
	0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
	0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
	0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
};

static const s32 g_nLumaPos[16] = { 
	0,      4,       16*4,       16*4+4, 
	8,      12 ,     16*4 + 8,   16*4+12, 
	16*8,   16*8+4,  16*12,      16*12+4,
	16*8+8, 16*8+12, 16*12+8,    16*12+12
};
static const s32 g_nChromaPos[2][4] = { 
	{ 256+0,      256+4,     256+8*4,       256+8*4 + 4},
	{ 256+64+0,   256+64+4,  256+64+8*4,    256+64+8*4 + 4},
};


STX_INTERF(LxH264MbResidualData);

struct LxH264MbResidualData{
	s16      Intra16x16DCLevel[16];
	s16      Intra16x16ACLevel[16][16];  // use 15;
	s16      LumaLevel[16][16];          //
	s16      ChromaDCLevel[2][4];
	s16      ChromaACLevel[2][4][16];    // use 15;
};

STX_INTERF(LxRefPicMark);
struct LxRefPicMark{
	VideoFrame*   pPicture;
	
#define MARK_ATTRIB_DECODE           0x0001
#define MARK_ATTRIB_SHORT_REF_P      0x0002
#define MARK_ATTRIB_SHORT_REF_B      0x0004
#define MARK_ATTRIB_LONG_REF_P       0x0008
#define MARK_ATTRIB_LONG_REF_B       0x0010
#define MARK_ATTRIB_DISPLAY          0x0020
#define MARK_ATTRIB_FRAME            0x0040
#define MARK_ATTRIB_TOP_FIELD        0x0080
#define MARK_ATTRIB_BOTTOM_FIELD     0x0100
	u32         dwMarkAttrib;
	u32         dwListIdx;          // 8

	s32           nFrameNum;
	s32           nFrameNumWrap;
	s32           nLongTermIdx;

	s32           nPicNum;          // s16 term identify;
	s32           nLongTermPicNum;	// long term identify;

}; // size is 32;


STX_INTERF(LxH264PrivateData);
STX_INTERF(H264InterMbHdr);

struct H264InterMbHdr{
	s32             nMbType;
	s32             nQscale;
	u32           dwCbp;                  // 12;
	u32           dwMbAvaFlag;
	u32           dwMbAvaFlag2;           // 8;
#define MV_CA_RLC  (1<<0)
#define REF_CA_RLC (1<<1)
	u8            byFlags;
	u8            byData[3];
};

STX_INTERF(H264InterMbInf);
struct H264InterMbInf{
	s32             nMbType;                // 4
	u32           dwMbPart;               // 4;
	u16            wSubMbType[4];          // 8;
	s32             nQscale;                // 
	u32           dwCbp;                  // 
	u32           dwMbAvaFlag;            //
	u32           dwMbAvaFlag2;           // +32
    char            ref_cache[2][16];       // +32;
    s16           mv_cache[2][16][2];     // 128 + 32;
};
STX_INTERF(H264InterMbCache);
struct H264InterMbCache{
	H264InterMbInf   MbInf;
};

STX_INTERF(H264IntraMbHdr);
struct H264IntraMbHdr{
	s32             chroma_pred_mode;        // 4;
#define MVD_CA_RLC (1<<0)
#define NNZ_CA_RLC (1<<1)
#define DIR_CA_RLC (1<<2)
#define IN4_CA_RLC (1<<3)
	u8            byFlags;
	u8            byData[3];
};


STX_INTERF(H264IntraMbInf);
struct H264IntraMbInf{
	s32                 chroma_pred_mode;        // 4;
	char                intra4x4_pred_mode[8];   // 8
    u8                nnzCache[24];            // 24;
    u8                direct_cache[24];        // 24; 
};

STX_INTERF(H264IntraMbCache);
struct H264IntraMbCache{
	H264IntraMbInf      MbInf;
	u8                byPad[64 - (sizeof(H264IntraMbInf) & 63) ];
    s16               mvd_cache[2][16][2];     // 128; move to top slice end;
};

#define  BORDER_UNIT_SIZE    (96+32)
#define  BORDER_UNIT_SIZEA   192
#define  MB_UNIT_SIZE        384

//#define  YPIT_IN_CTX         48
//#define  UVPIT_IN_CTX        YPIT_IN_CTX
//
//#define  YHEIGHT_IN_CTX      20   // 4 + 16
//#define  YSIZE_IN_CTX        (YPIT_IN_CTX * YHEIGHT_IN_CTX)
//#define  UVHEIGHT_IN_CTX     12   // 4 + 8;

//<< aff frame use;
#define  YPIT_AFF_FRAME      48
#define  YPIT_AFF_FIELD      (YPIT_AFF_FRAME*2)
#define  UVPIT_AFF_FRAME     YPIT_AFF_FRAME
#define  UVPIT_AFF_FIELD     YPIT_AFF_FIELD

#define  YOFFSET_AFF_TOP     (YPIT_AFF_FRAME*8)
#define  YOFFSET_AFF_BOT     (YOFFSET_AFF_TOP + YPIT_AFF_FRAME)

#define  YHEIGHT_AFF         40   // 8 + 32;
#define  UVHEIGHT_AFF        20   // 4 + 16;
#define  YSIZE_AFF           (YPIT_AFF_FRAME*YHEIGHT_AFF)

#define  CbOFFSET_AFF_TOP    (YSIZE_AFF + UVPIT_AFF_FRAME*4)
#define  CbOFFSET_AFF_BOT    (CbOFFSET_AFF_TOP + UVPIT_AFF_FRAME)
#define  CrOFFSET_AFF_TOP    (CbOFFSET_AFF_TOP + 24)
#define  CrOFFSET_AFF_BOT    (CrOFFSET_AFF_TOP + UVPIT_AFF_FRAME)
//>> aff frame use;

//#define  YOFFSET_IN_CTX      YOFFSET_AFF_TOP
//#define  CbOFFSET_IN_CTX     CbOFFSET_AFF_TOP
//#define  CrOFFSET_IN_CTX     CrOFFSET_AFF_TOP

#define  FIL_BAK_Y           (YOFFSET_AFF_TOP - YPIT_AFF_FRAME*6)
#define  FIL_BAK_CbCr        (YOFFSET_AFF_TOP - YPIT_AFF_FRAME*5)
#define  DEC_BAK_Y           (YOFFSET_AFF_TOP - YPIT_AFF_FRAME*4)
#define  DEC_BAK_CbCr        (YOFFSET_AFF_TOP - YPIT_AFF_FRAME*3)
#define  TR_BAK_Y            (YOFFSET_AFF_TOP - YPIT_AFF_FRAME*2)
#define  TR_BAK_Cb           (CbOFFSET_AFF_TOP - UVPIT_AFF_FRAME*2)
#define  TR_BAK_Cr           (CrOFFSET_AFF_TOP - UVPIT_AFF_FRAME*2)

/*

left border decode data buffer :     D 
left border filter data buffer :     F 
decode data:                         Y, U, V;
decode data border:                  y, u, v;
filter data:                         L(luma), B(cb), R(cr); 
unused buffer, could be use as temp: 0;

frame picture, field picture, aff frame top mb, use frame map;

  if use filter,
	  after mb decode, move the y top right 16 bytes to line 2 0~15;
	  move top y 16 bytes to line 3 0~15;
	  in filter process, first swap the left 4x16 to top right corner;
	  then restore the F data to top right line;
	  then transpose the Y,U,V data to right 16x16;
	  U,V filter use the line 8~19,12 lines;
	  after transpose, move the bottom line to area D; (save decode data);
	  do filter-> up-down;
      the middle block 16x16,8x8,8x8 could be used as tmp buffer;
	  save the top right line to F area;(save filter data);
	  move the area D data to top right line; (restore decode data);
	  transpose back;
	  do filter up-down;

  if not use filter, use swap the top line , move left border simply;

00000000 00000000 00000000 00000000 00000000 00000000
00000000 00000000 00000000 00000000 00000000 00000000
FFFFFFFF FFFFFFFF 00000000 00000000 00000000 00000000
FFFFFFFF FFFFFFFF 00000000 00000000 00000000 00000000

DDDDDDDD DDDDDDDD LLLLLLLL LLLLLLLL 00000000 00000000
DDDDDDDD DDDDDDDD LLLLLLLL LLLLLLLL 00000000 00000000
yyyyyyyy yyyyyyyy LLLLLLLL LLLLLLLL 00000000 00000000
yyyyyyyy yyyyyyyy yyyyyyyy yyyyyyyy yyyyyyyy yyyyyyyy

LLLLLLLL LLLLLLLL YYYYYYYY YYYYYYYY 00000000 00000000
LLLLLLLL LLLLLLLL YYYYYYYY YYYYYYYY 00000000 00000000
LLLLLLLL LLLLLLLL YYYYYYYY YYYYYYYY 00000000 00000000
LLLLLLLL LLLLLLLL YYYYYYYY YYYYYYYY 00000000 00000000

LLLLLLLL LLLLLLLL YYYYYYYY YYYYYYYY 00000000 00000000
LLLLLLLL LLLLLLLL YYYYYYYY YYYYYYYY 00000000 00000000
LLLLLLLL LLLLLLLL YYYYYYYY YYYYYYYY 00000000 00000000
LLLLLLLL LLLLLLLL YYYYYYYY YYYYYYYY 00000000 00000000

LLLLLLLL LLLLLLLL YYYYYYYY YYYYYYYY 00000000 00000000
LLLLLLLL LLLLLLLL YYYYYYYY YYYYYYYY 00000000 00000000
LLLLLLLL LLLLLLLL YYYYYYYY YYYYYYYY 00000000 00000000
LLLLLLLL LLLLLLLL YYYYYYYY YYYYYYYY 00000000 00000000

LLLLLLLL LLLLLLLL YYYYYYYY YYYYYYYY 00000000 00000000
LLLLLLLL LLLLLLLL YYYYYYYY YYYYYYYY 00000000 00000000
LLLLLLLL LLLLLLLL YYYYYYYY YYYYYYYY 00000000 00000000
LLLLLLLL LLLLLLLL YYYYYYYY YYYYYYYY 00000000 00000000

  // BLNAK AREA 48*16;

00000000 00000000 00000000 00000000 00000000 00000000
00000000 00000000 00000000 00000000 00000000 00000000
00000000 BBBBBBBB 00000000 00000000 RRRRRRRR 00000000
uuuuuuuu uuuuuuuu uuuuuuuu vvvvvvvv vvvvvvvv vvvvvvvv

BBBBBBBB UUUUUUUU 00000000 RRRRRRRR VVVVVVVV 00000000
BBBBBBBB UUUUUUUU 00000000 RRRRRRRR VVVVVVVV 00000000
BBBBBBBB UUUUUUUU 00000000 RRRRRRRR VVVVVVVV 00000000
BBBBBBBB UUUUUUUU 00000000 RRRRRRRR VVVVVVVV 00000000

BBBBBBBB UUUUUUUU 00000000 RRRRRRRR VVVVVVVV 00000000
BBBBBBBB UUUUUUUU 00000000 RRRRRRRR VVVVVVVV 00000000
BBBBBBBB UUUUUUUU 00000000 RRRRRRRR VVVVVVVV 00000000
BBBBBBBB UUUUUUUU 00000000 RRRRRRRR VVVVVVVV 00000000

// BLANK AREA 48*8;


  when aff flag is true, decode bottom mb must use map below:

  after mb decode, 
	  1) rotate bot mb to down right mb;

  filter top mb:
	  2) from slice cache, rotate top mb to right mb;
	  3)   if mb frame
			  rotate left 4x16 (0~15)to top right;
		   else
		      rotate left 4x16 top field to top right;
	  4) filter up down;
	  5) reverse rotate;
	  6) filter up down;

  filter bot mb:
	  7) if frame,
			rotate left 4x16 (16~31) to down right mb above 4 lines;
		  else 
			rotate left 4x16 bottom field to down right mb above 4 lines;
	  8) filter up down;
	  9) reverse rotate;
	  10) filter up down;


00000000 00000000 LLLLLLLL LLLLLLLL 00000000 00000000
00000000 00000000 LLLLLLLL LLLLLLLL 00000000 00000000
FFFFFFFF FFFFFFFF LLLLLLLL LLLLLLLL 00000000 00000000
FFFFFFFF FFFFFFFF LLLLLLLL LLLLLLLL 00000000 00000000

DDDDDDDD DDDDDDDD LLLLLLLL LLLLLLLL 00000000 00000000
DDDDDDDD DDDDDDDD LLLLLLLL LLLLLLLL 00000000 00000000
yyyyyyyy yyyyyyyy LLLLLLLL LLLLLLLL 00000000 00000000
yyyyyyyy yyyyyyyy yyyyyyyy yyyyyyyy yyyyyyyy yyyyyyyy

LLLLLLLL LLLLLLLL YYYYYYYY YYYYYYYY 00000000 00000000
LLLLLLLL LLLLLLLL YYYYYYYY YYYYYYYY 00000000 00000000
LLLLLLLL LLLLLLLL YYYYYYYY YYYYYYYY 00000000 00000000
LLLLLLLL LLLLLLLL YYYYYYYY YYYYYYYY 00000000 00000000

LLLLLLLL LLLLLLLL YYYYYYYY YYYYYYYY 00000000 00000000
LLLLLLLL LLLLLLLL YYYYYYYY YYYYYYYY 00000000 00000000
LLLLLLLL LLLLLLLL YYYYYYYY YYYYYYYY 00000000 00000000
LLLLLLLL LLLLLLLL YYYYYYYY YYYYYYYY 00000000 00000000

LLLLLLLL LLLLLLLL YYYYYYYY YYYYYYYY 00000000 00000000
LLLLLLLL LLLLLLLL YYYYYYYY YYYYYYYY 00000000 00000000
LLLLLLLL LLLLLLLL YYYYYYYY YYYYYYYY 00000000 00000000
LLLLLLLL LLLLLLLL YYYYYYYY YYYYYYYY 00000000 00000000

LLLLLLLL LLLLLLLL YYYYYYYY YYYYYYYY 00000000 00000000
LLLLLLLL LLLLLLLL YYYYYYYY YYYYYYYY 00000000 00000000
LLLLLLLL LLLLLLLL YYYYYYYY YYYYYYYY 00000000 00000000
LLLLLLLL LLLLLLLL YYYYYYYY YYYYYYYY 00000000 00000000

LLLLLLLL LLLLLLLL 00000000 00000000 00000000 00000000
LLLLLLLL LLLLLLLL 00000000 00000000 00000000 00000000
LLLLLLLL LLLLLLLL 00000000 00000000 00000000 00000000
LLLLLLLL LLLLLLLL 00000000 00000000 00000000 00000000

LLLLLLLL LLLLLLLL 00000000 00000000 00000000 00000000
LLLLLLLL LLLLLLLL 00000000 00000000 00000000 00000000
LLLLLLLL LLLLLLLL 00000000 00000000 00000000 00000000
LLLLLLLL LLLLLLLL 00000000 00000000 00000000 00000000

LLLLLLLL LLLLLLLL 00000000 00000000 00000000 00000000
LLLLLLLL LLLLLLLL 00000000 00000000 00000000 00000000
LLLLLLLL LLLLLLLL 00000000 00000000 00000000 00000000
LLLLLLLL LLLLLLLL 00000000 00000000 00000000 00000000

LLLLLLLL LLLLLLLL 00000000 00000000 00000000 00000000
LLLLLLLL LLLLLLLL 00000000 00000000 00000000 00000000
LLLLLLLL LLLLLLLL 00000000 00000000 00000000 00000000
LLLLLLLL LLLLLLLL 00000000 00000000 00000000 00000000

00000000 00000000 00000000 00000000 00000000 00000000
00000000 00000000 00000000 00000000 00000000 00000000
00000000 BBBBBBBB 00000000 00000000 RRRRRRRR 00000000
uuuuuuuu uuuuuuuu uuuuuuuu vvvvvvvv vvvvvvvv vvvvvvvv

BBBBBBBB UUUUUUUU 00000000 RRRRRRRR VVVVVVVV 00000000
BBBBBBBB UUUUUUUU 00000000 RRRRRRRR VVVVVVVV 00000000
BBBBBBBB UUUUUUUU 00000000 RRRRRRRR VVVVVVVV 00000000
BBBBBBBB UUUUUUUU 00000000 RRRRRRRR VVVVVVVV 00000000

BBBBBBBB UUUUUUUU 00000000 RRRRRRRR VVVVVVVV 00000000
BBBBBBBB UUUUUUUU 00000000 RRRRRRRR VVVVVVVV 00000000
BBBBBBBB UUUUUUUU 00000000 RRRRRRRR VVVVVVVV 00000000
BBBBBBBB UUUUUUUU 00000000 RRRRRRRR VVVVVVVV 00000000

BBBBBBBB 00000000 00000000 RRRRRRRR 00000000 00000000
BBBBBBBB 00000000 00000000 RRRRRRRR 00000000 00000000
BBBBBBBB 00000000 00000000 RRRRRRRR 00000000 00000000
BBBBBBBB 00000000 00000000 RRRRRRRR 00000000 00000000

BBBBBBBB 00000000 00000000 RRRRRRRR 00000000 00000000
BBBBBBBB 00000000 00000000 RRRRRRRR 00000000 00000000
BBBBBBBB 00000000 00000000 RRRRRRRR 00000000 00000000
BBBBBBBB 00000000 00000000 RRRRRRRR 00000000 00000000
*/

STX_INTERF(rotate_inf);
struct rotate_inf{
	u8* data;
	s32   pit;
};

STX_INTERF(H264Context);
struct H264Context            // should do the memory align use new;
{
	//[[ getbits;
	stx_bits_window			bs;
	stx_bits_window			bs_rbsp;
	//]]

    DCTELEM					mb[16*24] ;      // slice depend;
    u8						reccoe[ 48*(8+32 + 4+16) ];      // 2880 ;mc idct add result;
	H264IntraMbCache		IntraMbCache;    // ALIGN 16;
	H264InterMbCache		InterMbCache;    // ALIGN 16;
	u8						g_McTmp[1024];     // ALIGN 16;
	u8						g_McTmpAlign[16*6*22]; // 1920 + 192 = 2112;

	CABACContext			CabacCtx;
	s32						nCabacInitIdc;


	H264InterMbCache*		pInterMbTopAff[2][2];    // Aff frame , top mb buffer;
	H264InterMbCache**		ppInterMbTopAff[2][2];   // Aff frame , top mb buffer;
	H264IntraMbCache*		pIntraMbTopAff[2][2];    // Aff frame , top mb buffer;
	H264IntraMbCache**		ppIntraMbTopAff[2][2];   // Aff frame , top mb buffer;

	H264InterMbCache**		ppInterMbTopCur;         // top line buffer;
	H264InterMbCache**		ppInterMbTopBak;         // top line buffer;
	H264IntraMbCache**		ppIntraMbTopCur;         // top line buffer;
	H264IntraMbCache**		ppIntraMbTopBak;         // top line buffer;

	H264IntraMbCache*		pIntraMbPic;             // whole picture buffer;
	H264IntraMbCache**		ppIntraMbPic;            // whole picture buffer;

    u8*                  pBorderBuf[2][2];
    u8**                 ppBorderBuf[2][2];
    u8**                 ppBorderBufCur;
    u8**                 ppBorderBufBak;

    u8*                  pBorderBufAff[2];
    u8**                 ppBorderBufAff[2];
    u8**                 ppBorderBufAffCur;
    u8**                 ppBorderBufAffBak;

	// used first 384 bytes when aff; use last 128 bytes as cabac mvd cache;
	u8*                  pTopSlice[2];
	u8**                 ppTopSlice[2];     
	u8**                 ppTopSliceCur;     
	u8**                 ppTopSliceBak;     

    /**
     * non zero coeff count cache.
     * is 64 if not available.
     */
    u8                   nnzCache[6*8];  // slice depend;
//    u8                   (*nnzCount)[16];

    s32                    nal_ref_idc;	
    s32                    nal_unit_type;

    u8*                  rbsp_buffer;
	s32                    rbsp_data_length;
    s32                    rbsp_buffer_size;

    /**
      * Used to parse AVC variant of h264
      */
    s32                    is_avc;           //< this flag is != 0 if codec is avc1
    s32                    got_avcC;         //< flag used to parse avcC data only once
    s32                    nal_length_size;  //< Number of bytes used for nal length (1, 2 or 4)

    s32                    chroma_qp;        //QPc

    s32                    prev_mb_skipped;  //FIXME remove (IMHO not used)

    //prediction           stuff
    s32                    chroma_pred_mode;  
    char                   intra4x4_pred_mode_cache[6*8]; // slice depend;



	b32                   bYcont;
	b32                   bXcontLeft2Right;  //obselete;
	b32                   bXcontRight2Left;  //obselete;

#define MB_AVA_ALL               0xffffffff

#define LEFT_TOP_MB_EXIST        (1<<0)
#define TOP_MB_EXIST             (1<<1)
#define TOP_RIGHT_MB_EXIST       (1<<2)
#define LEFT_MB_EXIST            (1<<3)

#define LEFT_TOP_PRED_AVA        (1<<4)
#define TOP_PRED_AVA             (1<<5)
#define TOP_RIGHT_PRED_AVA       (1<<6)
#define LEFT_PRED_AVA            (1<<7)

#define LEFT_TOP_MB_INTRA        (1<<8)
#define TOP_MB_INTRA             (1<<9)
#define TOP_RIGHT_MB_INTRA       (1<<10)
#define LEFT_MB_INTRA            (1<<11)

#define LEFT_TOP_MB_INTRA_4x4    (1<<12)
#define TOP_MB_INTRA_4x4         (1<<13)
#define TOP_RIGHT_MB_INTRA_4x4   (1<<14)  
#define LEFT_MB_INTRA_4x4        (1<<15)

#define LEFT_TOP_MB_FRAME        (1<<16)  
#define TOP_MB_FRAME             (1<<17)	
#define TOP_RIGHT_MB_FRAME       (1<<18)
#define LEFT_MB_FRAME            (1<<19)

#define LEFT_TOP_MB_DIFF         (1<<20)
#define TOP_MB_DIFF              (1<<21)
#define TOP_RIGHT_MB_DIFF        (1<<22)
#define LEFT_MB_DIFF             (1<<23)	
#define RIGHT_MB_DIFF            (1<<24)
#define BOTTOM_MB_DIFF           (1<<25)

#define TOP_DEBLOCK_AVA          (1<<26)
#define LEFT_DEBLOCK_AVA       	 (1<<27)
#define	TOP_MB_8X8DCT            (1<<28)
#define LEFT_MB_8X8DCT	         (1<<29)
	u32                  dwMbAvaFlag; 

#define LEFT_TOP_MB_SKIP2         (1<<0)
#define TOP_MB_SKIP2              (1<<1)
#define TOP_RIGHT_MB_SKIP2        (1<<2)
#define LEFT_MB_SKIP2             (1<<3)

#define LEFT_TOP_MB_DIRECT2       (1<<4)
#define TOP_MB_DIRECT2            (1<<5)
#define TOP_RIGHT_MB_DIRECT2      (1<<6)
#define LEFT_MB_DIRECT2           (1<<7)

#define LEFT_TOP_DEC_VALID2       (1<<8)
#define TOP_DEC_VALID2            (1<<9)
#define TOP_DEC_RIGHT_VALID2      (1<<10)
#define LEFT_DEC_VALID2           (1<<11)

#define LEFT_TOP_FIL_VALID2       (1<<12)
#define TOP_FIL_VALID2            (1<<13)
#define TOP_RIGHT_FIL_VALID2      (1<<14)
#define LEFT_FIL_VALID2           (1<<15)

#define LEFT_TOP_MB8X8			  (1<<16)
#define TOP_MB8X8				  (1<<17)
#define TOP_RIGHT_MB8X8           (1<<18)
#define LEFT_MB8X8                (1<<19)
	u32                  dwMbAvaFlag2;

	u32                  dwTopRightAva;  // 0-15, top right; 16-31, top;
	u32                  dwTopLeftAva;   // 0-15, top left;  16-31, left;

	u32                  dwSubMbFlag;

    /**
     * Motion vector cache.
     */
    s16                  mv_cache[2][8*8][2];
    char                   ref_cache[2][8*8];
#define LIST_NOT_USED      ((u32)-1)                         //FIXME rename?
#define PART_NOT_AVAILABLE ((u32)-2)
    
    /**
     * is 1 if the specific list MV&references are set to 0,0,-2.
     */
    s32                    mv_cache_clean[2];
             
    /**
     * number of neighbors (top and/or left) that used 8x8 dct
     */
    s32                    neighbor_transform_size;

    /**
     * block_offset[ 0..23] for frame macro blocks
     * block_offset[24..47] for field macro blocks
     */
    s32                    block_offset[2*(16+8)];
    s32                    chroma_subblock_offset[16]; //FIXME remove
    s32                    b_stride;
    s32                    b8_stride;
             
    s32                    halfpel_flag;
    s32                    thirdpel_flag;
             
    s32                    unknown_svq3_flag;
    s32                    next_slice_index;
             
    SPS*                   sps_buffer[MAX_SPS_COUNT];
    SPS*                   pCurSps;                    // current sps
    
    PPS*                   pps_buffer[MAX_PPS_COUNT];
    PPS*                   pCurPps;                    // current              pps
             
    WORD                   (*dequant4_coeff)[16]; // FIXME quant matrices should be per SPS or PPS
    WORD                   (*dequant8_coeff)[64];
	

	s32                    nMbX;                // << slice depend;
	s32                    nMbY;                // slice depend;

	s32                    nMbType;             // slice depend;
	emNameOfMbType         emMbTypeName;        // slice depend;
	emMbPartPredMode       emPartPredMode[16];  // slice depend;
	s32                    nNumMbPart;          // slice depend;
	s32                    nIntra16x16PredMode; // slice depend;
	s32                    nCbp;
	s32                    nCbpY;               // slice depend;
	s32                    nCbpUV;              // slice depend;
	s32                    nMbPartWidth;        // slice depend;
	s32                    nMbPartHeight;       // slice depend;
	b32                   bFirstMb;            // slice depend;
	b32                   bDct8x8Allowed;

    s32                    sub_mb_type[4];      // slice depend;
	LxSubMbTypeInf         SubMbInf[4];         // slice depend;

    s32                    slice_num;           // slice depend;
    u8*                  slice_table_base;
    u8*                  slice_table;         // slice_table_base + mb_stride + 1

    s32                    slice_type;          // slice depend;
    s32                    slice_type_fixed;    // slice depend;
	s32                    slice_group_change_cycle;  // slice depend;

	SliceMapType           emSliceMapType;      // slice depend;
	s32                    nFirstMbInSlice;     //<< baojinlong, added in 2006-06-08; >>
	s32                    nCurMbAddr;
	s32                    nPrevMbAddr[2];
	s32                    nPrevMbX[2];
	s32                    nPrevMbY;

	s32                    nCurSliceMbAddr;

    //interlacing specific flags
    s32                    mb_field_decoding_flag;  // slice depend; >>

                  
    //POC stuff
    s32                    poc_lsb;
    s32                    poc_msb;
    s32                    delta_poc_bottom;
    s32                    delta_poc[2];
    s32                    frame_num;
    s32                    prev_poc_msb;             ///< poc_msb of the last reference pic for POC type 0
    s32                    prev_poc_lsb;             ///< poc_lsb of the last reference pic for POC type 0
    s32                    frame_num_offset;         ///< for POC type 2
    s32                    prev_frame_num_offset;    ///< for POC type 2
    s32                    prev_frame_num;           ///< frame_num of the last pic for POC type 1/2
              
    /**              
     * frame_num for frames or 2*frame_num for field pics.
     */
    s32                    curr_pic_num;
    
    /**
     * max_frame_num or 2*max_frame_num for field pics.
     */
    s32                    max_pic_num;


    //Weighted pred stuff
    s32                    luma_log2_weight_denom;
    s32                    chroma_log2_weight_denom;
    s32                    luma_weight[2][16];
    s32                    luma_offset[2][16];
    s32                    chroma_weight[2][16][2];
    s32                    chroma_offset[2][16][2];
            
    //deblock
    s32                    deblocking_filter;         ///< disable_deblocking_filter_idc with 1<->0 
    s32                    slice_alpha_c0_offset;
    s32                    slice_beta_offset;
    s32                    redundant_pic_count;

    s32                    direct_spatial_mv_pred;
    s32                    dist_scale_factor[16];
    s32                    map_col_to_list0[2][16];
         
    /**
     * num_ref_idx_l(0/1)_active_minus1 + 1
     */  
	s32                    nListCount;
    s32                    nRefCount[4];
	s32                    ref_idx_l0[4];
	s32                    ref_idx_l1[4];
	s32                    mvd_l0[4][4][2];
	s32                    mvd_l1[4][4][2];

	s32                    nShortRefCount[2];
	LxRefPicMark           ShortRefList[2][32];
    s32                    nLongRefCount[2];
	LxRefPicMark           LongRefList[2][32];

	LxRefPicMark           DecodePicMark;
	LxRefPicMark           DisplayPicture;
	LxRefPicMark           DisplayList[32];
	LxH264PrivateData*     pCurrentPicture;
	b32                   bHaveDisplayPicture;
	s32                    nDisplayListNum;

	s32                    nPicNumPred[2];
	s32                    nPrevRefFrameNum;
	s32                    nLongTermRefFlag;
	s32                    nMaxLongTermFrameIdx;

//    Picture*               short_ref[16];
//    Picture*               long_ref[16];
//
//    Picture                default_ref_list[2][32];
//    Picture                ref_list[2][32];         //FIXME size?
//    Picture                field_ref_list[2][32];   //FIXME size?
//             
//    Picture                current_picture;         ///< buffer to store the decompressed current picture 
//    Picture*               last_picture_ptr;        ///< pointer to the previous picture.
//    Picture*               next_picture_ptr;        ///< pointer to the next picture (for bi direction pred) 
//    Picture*               current_picture_ptr;     ///< pointer to the current picture
    /**         
     * memory management control operations buffer.
     */
    MMCO                   mmco[MAX_MMCO_COUNT];
    s32                    mmco_index;
    
//    /**      
//     * Cabac
//     */      
//    CABACContext           cabac;
//    u8                   cabac_state[512];
//    s32                    cabac_init_idc;
      
    /* 0x100 -> non n      ull luma_dc, 0x80/0x40 -> non null chroma_dc (cb/cr), 0x?0 -> chroma_cbp(0,1,2), 0x0? luma_cbp */
    s32                    top_cbp;
    s32                    left_cbp;

    /* chroma_pred_mode for i4x4 or i16x16, else 0 */

    s32                    last_qscale_diff;
    s16                  mvd_cache[2][8*8][2];

    u8                   direct_cache[6*8];

    u8                   zigzag_scan[16];
    u8                   field_scan[16];
    u8*                  zigzag_scan_q0;
    u8*                  field_scan_q0;
    s32                    x264_build;

	//<< move from codec context and encode context;>>
	b32                   bDecode;
	b32                   bHurryUp;
	b32                   bSkipFrame;
	b32                   bLowDelay;
	b32                   bHasBFrames;
	b32                   bKeyFrame;
	b32                   bDataPartitioning;
	b32                   bPartitionedFrame;
	b32                   bMbAff;
	b32                   bBottomField;
	b32                   bSecondField;
	b32                   bErr;
      
	u32           dwFlags;
	u32           dwCodecTag;  // ???
      
	s32                    nPictureNumber;
	s32                    nReference;
	s32                    nPicType;

	s32                    nWidth;
	s32                    nHeight;
	s32                    nCodedWidth;  
	s32                    nCodedHeight;           

	s32                    nPicWidthInMbSize;      // spec; nMbWidth in mpeg1/2;
	s32                    nMbStride;
	s32                    nPicHeightInMbSize;
	s32                    nPicHeightInMapUnits;   // spec; nMbHeight in mpeg1/2;
	s32                    nPicSizeInMbSize;     // spec; nMbSize in mpeg1/2;
	s32                    nPicSizeInMapUnits;     // spec; nMbSize in mpeg1/2;

	s32                    nFrameRate;
	s32                    nFrameRateBase;
	s32                    nDecodedFrameNum;
	s32                    nQScale;

	s32                    nMbSkipRun;
	s32                    nMbQpDelta;
	s32                    nResyncMbX;
	s32                    nResyncMbY;
	s32                    nBlockCount;
	s32                    nPictureStructure;
	s32                    nProgressiveSequence;
	s32                    nBrokenLink;

	u8*                  lpData[4];
	s32                    nLineSize[4];

	s32                    nExtDataSize;
	void*                  pExtData;

	s32                    nInternalBufferCount;
	void*                  pInternalBuffer;

	u8*         pAllocatedEdgeEmuBuffer;
	u8*         pEdgeEmuBuffer;     ///< points into the middle of allocated_edge_emu_buffer
      
	AVRational             sample_aspect_ratio;      


	// temp data;
    //s32 topleft_xy, top_xy, topright_xy, left_xy[2];
    //s32 topleft_type, top_type, topright_type, left_type[2];
    //s32 left_block[8];


	STX_VIDEOINFOHEADER2		g_VideoInfo;  
	s64							g_qwPresentTimeStamp;

	//static LxH264Parser                             g_Parser;

	b32	g_bContextInitialized;
	int	g_nWidth;
	int	g_nHeight;


	b32 bUpGrade;
	u32 dwUseDeinterlacing;
};



STX_INTERF(InternalBuffer);
struct InternalBuffer{
    s32           last_pic_num;
    u8*         base[4];
    u8*         data[4];
    s32           linesize[4];
};


STX_INTERF(LxH264Pred4x4);

struct LxH264Pred4x4{
    void  (*pred) (u8 *src, u8 *topright, s32 nStride);         //FIXME move to dsp?
};
STX_INTERF(LxH264Pred8x8);
struct LxH264Pred8x8{
    void  (*pred) (u8 *src, s32 nStride);
};
STX_INTERF(LxH264Pred8x8L);
struct LxH264Pred8x8L{
    void  (*pred) (u8 *src, s32 topleft, s32 topright, s32 stride);
};

STX_INTERF(H264ChromaMcFunc);

//typedef void (*h264_chroma_mc_func)(u8 *dst/*align 8*/, u8 *src/*align 1*/, s32 srcStride, s32 h, s32 x, s32 y);
struct H264ChromaMcFunc{
    void  (*pred) (
		u8 *dst/*align 8*/, 
		u8 *src/*align 1*/, 
		s32   dstStride,
		s32   srcStride, 
		s32   h, 
		s32   x, 
		s32   y);
};

STX_INTERF(H264WeightFunc);
//typedef void (*h264_weight_func)(u8 *block, s32 stride, s32 log2_denom, s32 weight, s32 offset);
struct H264WeightFunc{
    void  (*pred) (	u8 *dst, s32 stride, s32 log2_denom, s32 weight, s32 offset);
};

STX_INTERF(H264BiWeightFunc);
//typedef void (*h264_biweight_func)(u8 *dst, u8 *src, s32 stride, s32 log2_denom, s32 weightd, s32 weights, s32 offsetd, s32 offsets);
struct H264BiWeightFunc{
    void  (*pred) (
		u8 *dst, u8 *src, 
		s32 stride, s32 log2_denom, s32 weightd, s32 weights, s32 offsetd, s32 offsets);
};

STX_INTERF(QpelMcFunc);
//typedef void (*qpel_mc_func)(u8 *dst/*align width (8 or 16)*/, u8 *src/*align 1*/, s32 stride);
struct QpelMcFunc{
    void  (*pred) (
		u8 *dst/*align width (8 or 16)*/, 
		u8 *src/*align 1*/,
		s32  dst_stride,
		s32  src_stride );
};

STX_INTERF(LxPicMarkLink);
struct LxPicMarkLink{
	LxRefPicMark*    pMark;
	LxPicMarkLink*   pNext;
};

/**
 * Picture.
 */
STX_INTERF(LxH264PrivateData);
struct LxH264PrivateData{

	stx_base_com	mda;
	s32				i_ref;  // stx_com ref;

    /**
     * 1 -> keyframe, 0-> not
     * - encoding: set by lavc
     * - decoding: set by lavc
     */
    s32 key_frame;

    /**
     * picture type of the frame, see ?_TYPE below.
     * - encoding: set by lavc for coded_picture (and set by user for input)
     * - decoding: set by lavc
     */
    s32 pict_type;

    /**
     * presentation timestamp in AV_TIME_BASE (=micro seconds currently) (time when frame should be shown to user)
     * if AV_NOPTS_VALUE then the frame_rate will be used as reference
     * - encoding: MUST be set by user
     * - decoding: set by lavc
     */
    s64 pts;

    /**
     * picture number in bitstream order.
     * - encoding: set by
     * - decoding: set by lavc
     */
    s32 coded_picture_number;
    /**
     * picture number in display order.
     * - encoding: set by
     * - decoding: set by lavc
     */
    s32 display_picture_number;

    /**
     * quality (between 1 (good) and FF_LAMBDA_MAX (bad)) 
     * - encoding: set by lavc for coded_picture (and set by user for input)
     * - decoding: set by lavc
     */
    s32 quality; 

    /**
     * buffer age (1->was last buffer and dint change, 2->..., ...).
     * set to INT_MAX if the buffer has not been used yet 
     * - encoding: unused
     * - decoding: MUST be set by get_buffer()
     */
    s32 age;

    /**
     * is this picture used as reference
     * - encoding: unused
     * - decoding: set by lavc (before get_buffer() call))
     */
    s32  reference;
	b32 bDisplay;

    /**
     * QP table
     * - encoding: unused
     * - decoding: set by lavc
     */
    //u8 *qscale_table;
    /**
     * QP store stride
     * - encoding: unused
     * - decoding: set by lavc
     */
    s32 qstride;

    /**
     * mbskip_table[mb]>=1 if MB didnt change
     * stride= mb_width = (width+15)>>4
     * - encoding: unused
     * - decoding: set by lavc
     */
    //u8 *mbskip_table;

    /**
     * Motion vector table
     * - encoding: set by user
     * - decoding: set by lavc
     */
    //s16 (*motion_val[2])[2];

    /**
     * Macroblock type table
     * mb_type_base + mb_width + 2
     * - encoding: set by user
     * - decoding: set by lavc
     */
    //u32 *mb_type;

    /**
     * Macroblock size: (0->16x16, 1->8x8, 2-> 4x4, 3-> 2x2)
     * - encoding: unused
     * - decoding: set by lavc
     */
    u8 motion_subsample_log2;

    /**
     * for some private data of the user
     * - encoding: unused
     * - decoding: set by user
     */
    void *opaque;

    /**
     * error
     * - encoding: set by lavc if flags&CODEC_FLAG_PSNR
     * - decoding: unused
     */
    u64 error[4];

    /**
     * type of the buffer (to keep track of who has to dealloc data[*])
     * - encoding: set by the one who allocs it
     * - decoding: set by the one who allocs it
     * Note: user allocated (direct rendering) & internal buffers can not coexist currently
     */
    s32 type;
    
    /**
     * when decoding, this signal how much the picture must be delayed.
     * extra_delay = repeat_pict / (2*fps)
     * - encoding: unused
     * - decoding: set by lavc
     */
    s32 repeat_pict;
    
    /**
     * 
     */
    s32 qscale_type;
    
    /**
     * The content of the picture is interlaced.
     * - encoding: set by user
     * - decoding: set by lavc (default 0)
     */
    s32 interlaced_frame;
    
    /**
     * if the content is interlaced, is top field displayed first.
     * - encoding: set by user
     * - decoding: set by lavc
     */
    s32 top_field_first;
    
    /**
     * Pan scan.
     * - encoding: set by user
     * - decoding: set by lavc
     */
    //AVPanScan *pan_scan;
    
    /**
     * tell user application that palette has changed from previous frame.
     * - encoding: ??? (no palette-enabled encoder yet)
     * - decoding: set by lavc (default 0)
     */
    s32 palette_has_changed;
    
    /**
     * Codec suggestion on buffer type if != 0
     * - encoding: unused
     * - decoding: set by lavc (before get_buffer() call))
     */
    s32 buffer_hints;

    /**
     * DCT coeffitients
     * - encoding: unused
     * - decoding: set by lavc
     */
    s16 *dct_coeff;

    /**
     * Motion referece frame index
     * - encoding: set by user
     * - decoding: set by lavc
     */
    //char *ref_index[2];

    /**
     * halfpel luma planes.
     */

    u8   *interpolated[3];

//  s16   (*motion_val_base[2])[2];

//  u32*  pDwMbTypeBase;
//	u32*  pDwMbTypeBuf;
//	u8*   pByQscaleBuf;
//	u8*   pByMbSkipBuf;

#define MB_TYPE_INTRA    MB_TYPE_INTRA4x4                  //default mb_type if theres just one type
#define IS_INTRA4x4(a)   ((a)&MB_TYPE_INTRA4x4)
#define IS_INTRA16x16(a) ((a)&MB_TYPE_INTRA16x16)
#define IS_PCM(a)        ((a)&MB_TYPE_INTRA_PCM)
#define IS_INTRA(a)      ((a)&7)
#define IS_INTER(a)      ((a)&(MB_TYPE_16x16|MB_TYPE_16x8|MB_TYPE_8x16|MB_TYPE_8x8))
#define IS_SKIP(a)       ((a)&MB_TYPE_SKIP)
#define IS_INTRA_PCM(a)  ((a)&MB_TYPE_INTRA_PCM)
#define IS_INTERLACED(a) ((a)&MB_TYPE_INTERLACED)
#define IS_DIRECT(a)     ((a)&MB_TYPE_DIRECT2)
#define IS_GMC(a)        ((a)&MB_TYPE_GMC)
#define IS_16X16(a)      ((a)&MB_TYPE_16x16)
#define IS_16X8(a)       ((a)&MB_TYPE_16x8)
#define IS_8X16(a)       ((a)&MB_TYPE_8x16)
#define IS_8X8(a)        ((a)&MB_TYPE_8x8)

#define IS_SUB_DIRECT(a) ((a)&SUB_MB_TYPE_DIRECT2)
#define IS_SUB_8X8(a)    ((a)&SUB_MB_TYPE_8x8)  
#define IS_SUB_8X4(a)    ((a)&SUB_MB_TYPE_8x4) 
#define IS_SUB_4X8(a)    ((a)&SUB_MB_TYPE_4x8) 
#define IS_SUB_4X4(a)    ((a)&SUB_MB_TYPE_4x4) 

#define IS_ACPRED(a)     ((a)&MB_TYPE_ACPRED)
#define IS_QUANT(a)      ((a)&MB_TYPE_QUANT)

#define IS_DIR(a, par, lst) ((a) & (MB_TYPE_P0L0<<((par)+2*(lst))))

#define IS_SUB_DIR(a, par, lst) ((a) & (SUB_MB_TYPE_P0L0<<((par)+2*(lst))))

#define USES_LIST(a, lst) ((a) & ((MB_TYPE_P0L0|MB_TYPE_P1L0)<<(2*(lst)))) 

#define HAS_CBP(a)        ((a)&MB_TYPE_CBP)

    s32       field_poc[2];           ///< h264 top/bottom POC
    s32       poc;                    ///< h264 frame POC
    s32       frame_num;              ///< h264 frame_num
    s32       pic_id;                 ///< h264 pic_num or long_term_pic_idx
    s32       long_ref;               ///< 1->long term reference 0->s16 term reference
    s32       ref_poc[2][16];         ///< h264 POCs of the frames used as reference
    s32       nRefCount[2];           ///< number of entries in ref_poc

    s32       mb_var_sum;             ///< sum of MB variance for current frame 
    s32       mc_mb_var_sum;          ///< motion compensated MB variance for current frame 
    
//	WORD      *mb_var;                ///< Table for MB variances 
//  WORD      *mc_mb_var;             ///< Table for motion compensated MB variances 
//  u8      *mb_mean;               ///< Table for MB luminance 
//  u32     *mb_cmp_score;	      ///< Table for MB cmp scores, for mb decission FIXME remove
    s32       b_frame_score;          /* */

	H264InterMbCache*     pInterMbCache;
	H264InterMbCache**    ppInterMbCache;

	// when add a picture to a list, nRef++; otherwise nRef --; 
	// when nRef is zero, should release it;
	s32                   nRef;

	LxPicMarkLink*        pFirstLink;
};


STX_RESULT	h264_init();
void		h264_cleanup();
STX_RESULT  h264_decode(H264Context* the, u8* buf,s32 buf_size );


#if defined( __cplusplus )
}
#endif



#endif //
