/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/
#ifndef __STX_INI_H__
#define __STX_INI_H__

#include "stx_base_type.h"
#include "stx_io.h"

#if defined( __cplusplus )
extern "C" {
#endif


#define STX_INI_OK					0
#define STX_INI_FAIL				-1
#define STX_INI_INVALID_KEY			-2
#define STX_INI_INVALID_VAL         -3
#define STX_INI_END					-4
#define STX_INI_INVALID_PARAM		-5
#define STX_INI_INVALID_PATH		-6


#define STX_INI_MAX_STRING          256
#define STX_INI_MAX_PATH            256*4
#define STX_INI_MAX_SUBKEY          65536
#define STX_INI_TAG_SUBKEY			"subkey"
#define STX_INI_MAX_LAYER           16


typedef struct stx_xini stx_xini;

struct stx_xini{

	_STX_PURE void         (*close)(STX_HANDLE h_ini);

	_STX_PURE STX_RESULT   (*create_key_by_path)(STX_HANDLE h_ini,const char* sz_path, 		
		const char* sz_key, const char* sz_default_val,STX_HANDLE* p_h_key );

	_STX_PURE STX_RESULT   (*delete_key_by_path)(STX_HANDLE h_ini, const char* sz_path );

	_STX_PURE STX_RESULT   (*create_key)(STX_HANDLE h_ini, STX_HANDLE h_parent,		
		const char* sz_key,const char* sz_default_val,STX_HANDLE* p_h_key );

	_STX_PURE STX_RESULT   (*delete_key)(STX_HANDLE h_ini, STX_HANDLE h_key );


	_STX_PURE STX_RESULT   (*get_key)( STX_HANDLE h_ini, const char* sz_path, STX_HANDLE* p_h_key );

	_STX_PURE STX_RESULT   (*get_sub_key_num)( STX_HANDLE h_ini, STX_HANDLE h_parent, s32* i_num );

	_STX_PURE STX_RESULT   (*get_sub_key)( STX_HANDLE h_ini, STX_HANDLE h_parent, s32 i_idx, STX_HANDLE* p_h_key );

	_STX_PURE STX_RESULT   (*get_parent_key)( STX_HANDLE h_ini, STX_HANDLE h_key, STX_HANDLE* p_h_key );


	_STX_PURE STX_RESULT   (*read_key)( STX_HANDLE h_ini, STX_HANDLE h_key, char** sz_key );

	_STX_PURE STX_RESULT   (*read_int32)( STX_HANDLE h_ini, STX_HANDLE h_key, s32* i_val );

	_STX_PURE STX_RESULT   (*read_int64)( STX_HANDLE h_ini, STX_HANDLE h_key, s64* i_val );
		
	_STX_PURE STX_RESULT   (*read_string)( STX_HANDLE h_ini, STX_HANDLE h_key, char** sz_val );

	_STX_PURE STX_RESULT   (*write_int32)( STX_HANDLE h_ini, STX_HANDLE h_key, s32 i_val );

	_STX_PURE STX_RESULT   (*write_int64)( STX_HANDLE h_ini, STX_HANDLE h_key, s64 i_val );
		
	_STX_PURE STX_RESULT   (*write_string)( STX_HANDLE h_ini, STX_HANDLE h_key, const char* sz_val );

	_STX_PURE STX_RESULT   (*serialize)( STX_HANDLE h_ini, stx_xio* h_xio );

	_STX_PURE STX_RESULT   (*read_array)( STX_HANDLE h_ini, STX_HANDLE h_key, s32 i_item,size_t i_val[] );

	_STX_PURE STX_RESULT   (*write_array)( STX_HANDLE h_ini, STX_HANDLE h_key, s32 i_item,size_t i_val[] );

	_STX_PURE STX_RESULT   (*read_binary)( STX_HANDLE h_ini, STX_HANDLE h_key, s32* i_item_size,u8* val );

	_STX_PURE STX_RESULT   (*write_binary)( STX_HANDLE h_ini, STX_HANDLE h_key, s32 i_item_size,u8* val );

	_STX_PURE STX_RESULT   (*read_base64)( STX_HANDLE h_ini, STX_HANDLE h_key, s32* i_item_size,u8* val );

	_STX_PURE STX_RESULT   (*write_base64)( STX_HANDLE h_ini, STX_HANDLE h_key, s32 i_item_size,u8* val );

	_STX_PURE STX_RESULT   (*delete_sub_key)(STX_HANDLE h_ini, STX_HANDLE h_key, const char* sz_sub_key );
	
	_STX_PURE STX_RESULT   (*serialize_key)( STX_HANDLE h_ini, STX_HANDLE h_key,stx_xio* h_xio );

	_STX_PURE s32			(*get_attr)( THEE h_ini );

	_STX_PURE void			(*set_attr)( THEE h_ini, s32 i_attr );

};


#define STX_INI_READ_WRITE		0x01
#define STX_INI_READ_ONLY		0x02
#define STX_INI_CREATE_NEW		0x04
#define STX_INI_NO_COMMENT		0x08

#define STX_INI_TYPE_TXT		0
#define STX_INI_TYPE_MYSQL		1
#define STX_INI_TYPE_ODBC		2

STX_API STX_RESULT stx_ini_create
(char* sz_file_name, stx_xio* h_xio, s32 i_open_flags, s32 i_type ,stx_xini** hh_xini);    



#if defined( __cplusplus )
}
#endif


#endif /*  __STX_INI_H__ */

