/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/



#ifndef __STX_PROCESS_H__
#define __STX_PROCESS_H__

#include "stx_base_type.h"

#include "stx_io.h"


#if defined( __cplusplus )
extern "C" {
#endif


typedef struct STX_PROCESS_INF STX_PROCESS_INF;

struct STX_PROCESS_INF{

	char*					lpApplicationName;
	char*					lpCommandLine;
	STX_HANDLE				lpProcessAttributes;
	STX_HANDLE				lpThreadAttributes;
	STX_BOOL				bInheritHandles;
	STX_DWORD				dwCreationFlags;
	STX_HANDLE				lpEnvironment;
	char*					lpCurrentDirectory;
};

STX_HANDLE  stx_create_process(STX_PROCESS_INF* p_inf);

STX_RESULT  stx_close_process( STX_HANDLE h);



#if defined( __cplusplus )
}
#endif


#endif /*  __STX_PROCESS_H__ */

