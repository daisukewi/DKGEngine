/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-11
***********************************************************************************/
#ifndef __STX_STAT_H__
#define __STX_STAT_H__

#include "stx_base_type.h"

#if defined( __cplusplus )
extern "C" {
#endif


	STX_HANDLE  stx_stat_create();

	void		stx_stat_close(STX_HANDLE h);
	
	void		stx_stat_set_period(STX_HANDLE h, u32 i_mili_sec);

	void		stx_stat_reset(STX_HANDLE h);

	s64			stx_stat_update(STX_HANDLE h);

	void		stx_stat_pause(STX_HANDLE h);

	// data size, or idle time;
	void		stx_stat_add_val(STX_HANDLE h, s64 i_val);

	u32			stx_stat_get_occupy(STX_HANDLE h);

	s64			stx_stat_get_speed(STX_HANDLE h);




#if defined( __cplusplus )
}
#endif

#endif // __STX_STAT_H__