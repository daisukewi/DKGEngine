// xdisk_interf.h: interface for the xdisk_interf class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(__XDISK_INTERF_H__)
#define __XDISK_INTERF_H__



#include "stx_base_type.h"

#include "stx_io.h"



#if defined( __cplusplus )
extern "C" {
#endif



#define __XDISK_DEV__


extern char*	g_sz_ssvr;
extern char*    g_sz_xdisk_config_file;
extern char*	g_sz_stream_service_name;
extern char*	g_sz_ssvr_path;

extern char*  g_sz_vdisk;

extern char*  g_sz_gid;

extern char*  g_sz_name;

extern char*  g_sz_desc;

extern char*  g_sz_channel;

extern char*  g_sz_vdisk_version;

extern char*  g_sz_xsvr_cfg;

extern char*  g_sz_cell_name;
	
extern char*  g_sz_xsvr_ip;

/*extern char*  g_sz_default_ip_val = "192.168.0.145";*/
extern char*  g_sz_default_ip_val;

extern char*  g_sz_xsvr_port;

extern char*  g_sz_xsvr_port_val;

extern int    g_xsvr_port;

extern char*  g_sz_xcln_ip;

extern char*  g_sz_xcln_port;

extern char*  g_sz_xcln_port_val;

extern int    g_xcln_port;

extern char*  g_sz_sector_size;

extern char*  g_sz_sector_size_val;

extern char*  g_sz_slice_inf;

extern char*  g_sz_slice_path;

extern char*  g_sz_start_slice; /* file's start slice index; */

extern char*  g_sz_start_strip; /* slice's start strip counter; */

extern char*  g_sz_slice_num;

extern char*  g_sz_slice_num_val;

extern char*  g_sz_strip_size;

extern char*  g_sz_strip_size_val;  /* 16 MB */

extern char*  g_sz_slice_bandwidth;

extern char*  g_sz_slice_bandwidth_val;  /* 50 MB */

extern char*  g_sz_max_mem;


extern char*  g_sz_local_driver;


extern char*  g_sz_xcln_cfg;

extern char*  g_sz_mirror_map;

extern char*  g_sz_xdisk;

extern char*  g_sz_driver_cfg;

extern char*  g_sz_vdisk_cln;

extern char*  g_sz_vdisk_svr;

extern char*  g_sz_vdisk_log;


#define	STX_MAX_BLOCK_NUM   5



enum xdisk_user_data_type{

	em_thread_status,
	em_user_info,
	em_driver_info,
	em_vdisk_info,
	em_inet_addr,
	em_inet_protocal,
};

typedef enum xdisk_user_data_type xdisk_user_data_type;


void		i_get_cell_config_file(char* sz_file, char* sz_path);

void		i_get_server_config_file(char* sz_file, char* sz_path);

void		i_get_driver_config_file(char* sz_file, char* sz_driver);

void		i_get_driver_config_path(char* sz_path, char* sz_driver);

STX_RESULT  	i_get_driver_inf(char* sz_driver, char* sz_gid, char* sz_desc);


STX_RESULT  	i_xdisk_api_init( void (*_trace)(char*) );

void		i_xdisk_api_close();


STX_RESULT	i_xdisk_server_create( stx_err_handle* h_err, stx_err_handle** h_result );

STX_RESULT  	i_xdisk_initialize( stx_err_handle* h_err,  stx_err_handle** h_result  ) ;


STX_RESULT  	i_xdisk_vdisk_create( char* sz_vdisk_name ,stx_err_handle* h_notify, stx_err_handle** h_err );



STX_RESULT  	i_xdisk_vdisk_create_from_folder( char* sz_vdisk_name , char* sz_src, 
	stx_err_handle* h_notify,stx_err_handle** h_err );



STX_RESULT  	i_xdisk_vdisk_remove( char* sz_vdisk_name , stx_err_handle* h_notify, stx_err_handle** h_err );



STX_RESULT  	i_xdisk_vdisk_folder_create( char* sz_vdisk_name, char* sz_vdisk_gid, char* sz_dst, 
	stx_err_handle* h_notify, stx_err_handle** h_err );



STX_RESULT  	i_xdisk_vdisk_folder_copy( char* sz_vdisk_name, char* sz_vdisk_gid, char* sz_dst, char* sz_src, 
	stx_err_handle* h_notify, stx_err_handle** h_err );



STX_RESULT  	i_xdisk_vdisk_folder_remove(char* sz_vdisk_name,char* sz_path, 
	stx_err_handle* h_notify,stx_err_handle** h_err );



STX_RESULT  	i_xdisk_vdisk_file_create (		  
	char* sz_vdisk_name, char* sz_vdisk_gid, char* sz_dst, stx_err_handle* h_notify, stx_err_handle** h_err );



STX_RESULT  	i_xdisk_vdisk_file_copy( char* sz_vdisk_name,char* sz_dst, char* sz_src, 
	stx_err_handle* h_notify,stx_err_handle** h_err);



STX_RESULT  	i_xdisk_vdisk_file_remove(char* sz_vdisk_name,char* sz_file,
	stx_err_handle* h_notify, stx_err_handle** h_err );


stx_xio*    	i_stx_create_io_xdisk();




#if defined( __cplusplus )
}
#endif



#endif // !defined(__XDISK_INTERF_H__)
