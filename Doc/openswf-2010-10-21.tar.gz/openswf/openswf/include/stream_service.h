/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#ifndef __STREAM_SERVICE_H__
#define __STREAM_SERVICE_H__



#include "base_interf.h"

#include "stx_io.h"


#if defined( __cplusplus )
extern "C" {
#endif





#define STREAM_SERVICE_CMD_READ  1

#define STREAM_SERVICE_CMD_CLOSE 2

#define MAX_STREAM_SERVICE 2048


STX_RESULT  stream_service_write_cmd_read(
	char* sz_file, stx_xio* h_stream );

STX_RESULT  stream_service_write_cmd_close( 
	stx_xio* h_stream );

STX_RESULT stream_service_request_read(
	stx_xio* h_tcp,char* buf, size_t i_read );


STX_RESULT  stream_service( char* sz_cfg );



#if defined( __cplusplus )
}
#endif



#endif /* __STREAM_SERVICE_H__*/