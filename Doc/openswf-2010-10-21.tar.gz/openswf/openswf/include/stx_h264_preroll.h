
/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#ifndef __STX_H264_PREROLL_H__
#define __STX_H264_PREROLL_H__


#include "base_interf.h"
#include "stx_io.h"

#include "h264dec.h"



#if defined( __cplusplus )
extern "C" {
#endif


STX_API     bool32 ff_avc_find_startcode(
        uint8**      p, 
        uint8*       end, 
        uint32*      b_start,
        uint32*      start_code );

STX_API     bool32 ff_avc_parse_nal_units(
        uint8*       buf_in, 
        size_t       i_size, 
        size_t*      i_used,
        uint32*      b_start,
        uint32*      start_code, 
        stx_xio*     p_stream );


STX_API THEE stx_h264_preroll_create();

STX_API void        stx_h264_preroll_close(THEE h);

STX_API STX_RESULT  stx_h264_preroll_decode_pack(THEE h,u8* buf,size_t i_len );

STX_API SPS*        stx_h264_preroll_get_sps(THEE h);


STX_API s32			stx_h264_decode_sps(ByteIOContext* pb, SPS* sps);


#if defined( __cplusplus )
}
#endif




#endif // __STX_H264_PREROLL_H__