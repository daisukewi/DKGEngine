
/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/



/* stx_stream_pin.h: interface for the stx_stream_pin class.*/


#if !defined(__STX_STREAM_PIN_H__)
#define __STX_STREAM_PIN_H__



#include "base_class.h"


#if defined( __cplusplus )
extern "C" {
#endif



/* p_obj must be NULL; */

STX_API stx_base_pin*	stx_stream_pin_input_create( );


#if defined( __cplusplus )
}
#endif



#endif /*!defined(__STX_STREAM_PIN_H__)*/ 
