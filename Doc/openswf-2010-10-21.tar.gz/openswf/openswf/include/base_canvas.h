/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/
#ifndef __BASE_CANVAS_H__
#define __BASE_CANVAS_H__

#include "base_flt_wnd.h"
#include "stx_stack.h"

#if defined( __cplusplus )
extern "C" {
#endif

	STX_INTERF(base_canvas);

#define CANVAS_LEFT         100/2
#define CANVAS_TOP          100/2

#define CANVAS_MIN_WIDTH	800
#define CANVAS_MIN_HEIGHT	500

#define CANVAS_MAX_WIDTH	2560
#define CANVAS_MAX_HEIGHT	1600

#define GRADE_WIDTH			200
#define GRADE_EDGE			25

#define MAX_GRADE           (CANVAS_MAX_WIDTH/GRADE_WIDTH)

#define FLTWND_WIDTH        (GRADE_WIDTH - GRADE_EDGE*2)
#define FLTWND_HEIGHT       FLTWND_WIDTH


#define TITLE_LEFT  5
#define TITLE_TOP   5

#define RESIZE_EDGE  10

#define DUSTBIN_WIDTH  100
#define DUSTBIN_HEGHT  100

#define CAPTION_HEIGHT 50

#define PIN_EDGE   5
#define PIN_WIDTH  25
#define PIN_HEIGHT 25


#define STX_RET_PAINT		1
#define STX_RET_MOVE		2
#define STX_RET_DELETE		3
#define STX_RET_SAVE		4
#define STX_RET_CONNECT		5
#define STX_RET_HIT			6


#define SRC_CAPS_GET_SIZE					0x01
#define SRC_CAPS_GET_POS					0x02
#define SRC_CAPS_SET_POS					0x04

#define CTL_CAPS_PLAY_STOP					0x08
#define CTL_CAPS_PAUSE_RESUME				0x10
#define CTL_CAPS_CONTINUE					0x20
#define CTL_CAPS_STEP						0x40
#define CTL_CAPS_FORWARD_BACKWARD			0x80

#define SPEED_CAPS_2X						0x100
#define SPEED_CAPS_4X						0x200
#define SPEED_CAPS_8X						0x400
#define SPEED_CAPS_16X						0x800
#define SPEED_CAPS_XX						0x1000
#define SPEED_CAPS_05X						0x2000

#define MINF_CAPS_CURRENT_TIME				0x4000
#define MINF_CAPS_TOTAL_TIME				0x8000
#define MINF_CAPS_TIME2POS					0x10000
#define MINF_CAPS_POS2TIME					0x20000



#define UPDATE_RESIZE \
	SetRect(&the->m_resize,\
	the->m_pos.right-RESIZE_EDGE,the->m_pos.top,the->m_pos.right,the->m_pos.bottom)

#define UPDATE_DUSTBIN \
	SetRect(&the->m_dustbin,\
	the->m_pos.right - DUSTBIN_WIDTH,the->m_pos.bottom-DUSTBIN_HEGHT,the->m_pos.right,the->m_pos.bottom)

#define UPDATE_VIEW \
	SetRect(&the->m_view_pos,\
	the->m_pos.left - CANVAS_LEFT ,\
	the->m_pos.top - CANVAS_TOP,\
	the->m_pos.right + CANVAS_LEFT,\
	the->m_pos.bottom + CANVAS_TOP)



	static char* g_szGraphFileName = "GraphFileName";
	static char* g_szCanvasPos = "CanvasPos";
	static char* g_szAllGrades = "Grades";
	static char* g_szAllFilters = "Filters";
	static char* g_szAllConnectTions = "AllConnectTions";
	static char* g_szConnectTion = "ConnectTion";




	struct stx_connection_point{
		b32             b_start;
		s32				i_grade;
		s32				i_filter;
		s32             i_pin;				// 
		stx_gid			major_type;			// 
		stx_gid			sub_type;			// 
		stx_gid         insid;				// serialize,identify;
		base_pin_wnd*	pwnd;
	};


	struct stx_connection{
		b32						b_valid;		// if the connection actually exist;
		stx_connection_point	start_pos;
		stx_connection_point	end_pos;
	};


	struct stx_grade{
		s32                 i_grade;
		s32					i_filter;
		s32                 i_max_filter;
		base_flt_wnd**		ppFilterWnd;
	};

	struct base_canvas{

		stx_base_graph_builder* m_hGbd;

		HWND				m_hWnd;
		base_canvas*		m_the;
		stx_base_plugin*	m_hParent;

		b32                 m_bDrawConnection;
		base_pin_wnd*		m_start_pwnd;
		stx_gid             m_start_flt_insid;  

		b32                 m_bResize;
		b32                 m_bDrag;
		POINT               m_lastPoint;

		POINT               m_start_point;
		POINT               m_end_point;

		stx_base_graph*		m_hGph;
		stx_base_control*   m_hCtl;
		stx_base_source*	m_hSrc;
		s32                 m_icaps;

		char*               m_szFileName;

		s32                 m_iMaxGrades;
		s32                 m_iGrades;
		stx_grade**         m_hhGrade;

		RECT				m_pos;
		RECT				m_view_pos;
		RECT				m_clip;
		RECT				m_resize;
		RECT				m_dustbin;

		s32                 m_iAllConnectTions;
		s32                 m_iMaxConnectTions;
		stx_connection**    m_ppConnectRect;

		u32					m_dwColorKey;

		STX_HANDLE			m_hStack;
	};


	STX_RESULT	canvas_initialize(base_canvas* the,char* sz_file,stx_xio* h_xio);
	STX_RESULT	canvas_serialize(base_canvas* the,char* sz_file,stx_xio* h_xio);

	STX_RESULT	canvas_OnAddFilter(base_canvas* the,stx_gid clsid,char* sz_dll);
	STX_RESULT	canvas_OnRendStream(base_canvas* the,char* sz_url);
	STX_RESULT	canvas_OnLoadStream(base_canvas* the,char* sz_url, stx_sync_inf* h_sync);
	STX_RESULT	canvas_OnCloseStream(base_canvas* the);
	STX_RESULT	canvas_OnRendPin(base_canvas* the);
	STX_RESULT	canvas_OnRendRender(base_canvas* the);

	STX_RESULT	canvas_OnRunGraph(base_canvas* the);
	STX_RESULT	canvas_OnPause(base_canvas* the);
	STX_RESULT	canvas_OnResume(base_canvas* the);
	STX_RESULT	canvas_OnStop(base_canvas* the);
	STX_RESULT	canvas_on_auto_stop(base_canvas* the,stx_base_message* p_msg);

	s32			canvas_get_graph_caps(base_canvas* the);
	s32			canvas_get_graph_status(base_canvas* the);

	STX_RESULT canvas_initialize_control(base_canvas* the);
	STX_RESULT canvas_get_control_caps(base_canvas* the);

	STX_RESULT canvas_initialize_default(base_canvas* the);
	STX_RESULT canvas_confirm_connections(base_canvas* the);
	STX_RESULT canvas_invalid_connections(base_canvas* the);
	STX_RESULT canvas_confirm_filter_connections(base_canvas* the,base_flt_wnd* fltwnd);

	STX_RESULT canvas_break_connections(base_canvas* the);
	STX_RESULT canvas_break_filter_connections(base_canvas* the,base_flt_wnd* fltwnd);

	STX_RESULT canvas_add_connections(base_canvas* the,base_pin_wnd* start,base_pin_wnd* end);
	STX_RESULT canvas_remove_connections(base_canvas* the,base_pin_wnd* start,base_pin_wnd* end);
	STX_RESULT canvas_remove_fltwnd_connections(base_canvas* the,base_flt_wnd* fltwnd);
	STX_RESULT canvas_update_fltwnd_connections(base_canvas* the,base_flt_wnd* fltwnd);

	STX_RESULT canvas_find_connection_pin(base_canvas* the,
		stx_connection* pcon,output_pin_wnd** pp_start,base_pin_wnd** pp_end);

	STX_RESULT canvas_check_fltwnd_pos(base_canvas* the,base_flt_wnd* fltwnd);
	STX_RESULT canvas_remove_fltwnd(base_canvas* the,base_flt_wnd* fltwnd,b32 b_delete);
	STX_RESULT canvas_insert_fltwnd(base_canvas* the,base_flt_wnd* fltwnd,s32 i_grade);
	STX_RESULT canvas_add_grade(base_canvas* the);
	STX_RESULT canvas_remove_grade(base_canvas* the,stx_grade* g);
	void       canvas_remove_all_grade(base_canvas* the);
	void       canvas_release_grade(stx_grade* g);
	STX_RESULT canvas_sort_grade(base_canvas* the,stx_grade* g );

	STX_RESULT canvas_initialize_fltwnd(base_canvas* the,base_flt_wnd* fltwnd,stx_base_com* p);

	STX_RESULT canvas_initialize_connection_point
		(base_canvas* the,stx_xini* h_xini,STX_HANDLE h_parent,stx_connection_point* p);

	STX_RESULT canvas_serialize_connection_point
		(base_canvas* the,stx_xini* h_xini,STX_HANDLE h_parent,stx_connection_point* p);

	void       canvas_fltwnd_default_pos(base_canvas* the,base_flt_wnd* fltwnd,s32 i_grade);
	void       canvas_info(base_canvas* the);

	void canvas_set_color_key(base_canvas* the,u32 i_color_key);
	void canvas_set_dst_rect(base_canvas* the,RECT dst_rect);
	void canvas_show_render(base_canvas* the, b32 bShow);


	base_canvas* canvas_create
	(
		base_canvas				*the,
		HWND					hwnd,
		stx_base_plugin			*h_parent,
		stx_base_graph_builder	*gbd
	);

	void canvas_close(base_canvas*the);


#if defined( __cplusplus )
}
#endif


#endif /* __BASE_CANVAS_H__ */ 