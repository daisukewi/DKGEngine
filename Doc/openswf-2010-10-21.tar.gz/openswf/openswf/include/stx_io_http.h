/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#ifndef __STX_IO_HTTP_H__2008_06_21
#define __STX_IO_HTTP_H__2008_06_21


#include "stx_base_type.h"

#include "stx_io.h"




#if defined( __cplusplus )
extern "C" {
#endif



	STX_API stx_xio*	stx_create_io_http();





#if defined( __cplusplus )
}
#endif


#endif /* __STX_IO_HTTP_H__2008_06_21*/