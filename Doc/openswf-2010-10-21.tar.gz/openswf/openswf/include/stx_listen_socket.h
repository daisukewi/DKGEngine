/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#ifndef __STX_LISTEN_SOCKET_H__2008_06_21
#define __STX_LISTEN_SOCKET_H__2008_06_21


#include "stx_all_codec.h"


#if defined( __cplusplus )
extern "C" {
#endif


	// {60DF5E98-5644-444f-90A6-56B472F062A7}
	DECLARE_XGUID( STX_CLSID_ListenSocket,
	0x60df5e98, 0x5644, 0x444f, 0x90, 0xa6, 0x56, 0xb4, 0x72, 0xf0, 0x62, 0xa7);

	extern char* g_szStreamX_ListenSocket;

	STX_API	STX_COM(listen_socket);
	STX_API CREATE_STX_COM_DECL(stx_base_plugin,listen_socket);


#if defined( __cplusplus )
}
#endif


#endif /*   __STX_LISTEN_SOCKET_H__2008_06_21  */
