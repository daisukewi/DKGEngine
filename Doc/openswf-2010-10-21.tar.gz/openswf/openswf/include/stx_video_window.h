
/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/


#ifndef __STX_VIDEO_WINDOW_H__
#define __STX_VIDEO_WINDOW_H__


#include "base_class.h"


#if defined( __cplusplus )
extern "C" {
#endif






#if defined( __cplusplus )
}
#endif


#endif /* __STX_VIDEO_WINDOW_H__ */ 