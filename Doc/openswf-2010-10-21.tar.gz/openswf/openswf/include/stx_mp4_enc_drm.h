

#ifndef __STX_MP4_ENC_DRM_H__2008_06_21
#define __STX_MP4_ENC_DRM_H__2008_06_21


/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#if defined( __cplusplus )
extern "C" {
#endif


#include "stx_all_codec.h"

#include "stx_io.h"



	STX_INTERF(stx_base_drm);

	struct  stx_base_drm{

		_STX_PURE stx_base_com   com;

		_STX_PURE STX_RESULT	 (*drm_read_sdp_keyinfo)( 
			void* h,char* buf, size_t* buf_size );

		_STX_PURE STX_RESULT	 (*drm_encrypt_data)( 
			void* h,char* buf, size_t data_size );
	};


	STX_API stx_base_drm*  stx_base_drm_create( char* sz_param );




#if defined( __cplusplus )
}
#endif


#endif /* __STX_MP4_ENC_DRM_H__2008_06_21*/
