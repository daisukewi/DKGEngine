/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/


#ifndef __MOV_DEC_H__2008_06_21
#define __MOV_DEC_H__2008_06_21

#include "stx_all_codec.h"
#include "stx_io.h"


#if defined( __cplusplus )
extern "C" {
#endif


/* 
	stx_mp4_mov_dec.h 
	create: 2008-06-21
	author: baojinlong
*/ 



	STX_INTERF(stx_mp4_clipper);

	struct stx_mp4_clipper{

		_STX_PURE void				(*set_io)(THEE h,stx_mp4_io* io_input);

		_STX_PURE void				(*set_trace)(THEE h, void (*verbose)(char*) );

		_STX_PURE STX_MP4_HANDLE		(*create_header)(THEE h);

		_STX_PURE STX_MP4_RESULT		(*clip_header)(	
			THEE			h,	
			STX_MP4_HANDLE		header_ori,
			STX_MP4_HANDLE*		header_clip,	
			offset_t*			pos);

		_STX_PURE offset_t			(*header_size)(THEE h,STX_MP4_HANDLE header);

		_STX_PURE offset_t			(*header_pos)(THEE h,STX_MP4_HANDLE header);

		_STX_PURE void*				(*header_data)(THEE h,STX_MP4_HANDLE header);

		_STX_PURE sint64			    (*header_start_time)(THEE h,STX_MP4_HANDLE header);

		_STX_PURE void				(*close)(THEE h);

		_STX_PURE void				(*header_close)(THEE h,STX_MP4_HANDLE header);
	};


	STX_API stx_mp4_clipper*  stx_mp4_clip_create();




#if defined( __cplusplus )
}
#endif


#endif // __MOV_DEC_H__2008_06_21
