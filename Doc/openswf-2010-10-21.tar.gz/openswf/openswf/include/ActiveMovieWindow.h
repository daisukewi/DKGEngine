/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#ifndef __ACTIVEMOVIEWINDOW_H__
#define __ACTIVEMOVIEWINDOW_H__

#include "stx_all_codec.h"


#if defined( __cplusplus )
extern "C" {
#endif


	STX_INTERF(stx_active_movie_wnd);

	#define stx_active_movie_wnd_vtdef() \
		stx_base_com_vtdef()\
		_STX_PURE STX_RESULT (*create)(STX_HANDLE h,stx_base_plugin* h_parent);\
		_STX_PURE STX_HANDLE (*get_hinstance)(STX_HANDLE h);\
		_STX_PURE STX_HANDLE (*get_hwnd)(STX_HANDLE h);\
		_STX_PURE STX_HANDLE (*get_active_hwnd)(STX_HANDLE h);\
		_STX_PURE u32        (*get_color_key)(STX_HANDLE h);\
		_STX_PURE void       (*set_color_key)(STX_HANDLE h,u32 i_color_key);\
		_STX_PURE STX_RECT   (*get_dst_rect)(STX_HANDLE h);\
		_STX_PURE void       (*set_dst_rect)(STX_HANDLE h,STX_RECT dst_rect);\
		_STX_PURE STX_RESULT (*set_aspect_ratio)(STX_HANDLE h,u32 i_width,u32 i_height,u32 i_aspect);

	struct stx_active_movie_wnd{
		stx_active_movie_wnd_vtdef()
	};

	#define stx_active_movie_wnd_funcdecl(PREFIX) \
		stx_base_com_funcdecl(PREFIX ## _ ## com);\
		STX_PURE STX_RESULT PREFIX ## _xxx_ ## create(STX_HANDLE h,stx_base_plugin* h_parent);\
		STX_PURE STX_HANDLE PREFIX ## _xxx_ ## get_hinstance(STX_HANDLE h);\
		STX_PURE STX_HANDLE PREFIX ## _xxx_ ## get_hwnd(STX_HANDLE h);\
		STX_PURE STX_HANDLE PREFIX ## _xxx_ ## get_active_hwnd(STX_HANDLE h);\
		STX_PURE u32        PREFIX ## _xxx_ ## get_color_key(STX_HANDLE h);\
		STX_PURE void       PREFIX ## _xxx_ ## set_color_key(STX_HANDLE h,u32 i_color_key);\
		STX_PURE STX_RECT   PREFIX ## _xxx_ ## get_dst_rect(STX_HANDLE h);\
		STX_PURE void       PREFIX ## _xxx_ ## set_dst_rect(STX_HANDLE h,STX_RECT dst_rect);\
		STX_PURE STX_RESULT PREFIX ## _xxx_ ## set_aspect_ratio(STX_HANDLE h,u32 i_width,u32 i_height,u32 i_aspect)

	#define stx_active_movie_wnd_vtinit(vt,PREFIX) \
		STX_VT_INIT(vt,PREFIX,create);\
		STX_VT_INIT(vt,PREFIX,get_hinstance);\
		STX_VT_INIT(vt,PREFIX,get_hwnd);\
		STX_VT_INIT(vt,PREFIX,get_active_hwnd);\
		STX_VT_INIT(vt,PREFIX,get_color_key);\
		STX_VT_INIT(vt,PREFIX,set_color_key);\
		STX_VT_INIT(vt,PREFIX,get_dst_rect);\
		STX_VT_INIT(vt,PREFIX,set_dst_rect);\
		STX_VT_INIT(vt,PREFIX,set_aspect_ratio)

	#define stx_active_movie_wnd_data_default()			\
		stx_base_com_data_default()

	#define stx_active_movie_wnd_funcimp_default(SCOM,PREFIX)			\
		stx_base_com_funcimp_default(SCOM,PREFIX ## _ ## com )\

	#define stx_active_movie_wnd_create_default(vt,PREFIX,CLS,CAT,NAME)		\
		stx_base_com_create_default(vt,PREFIX ## _ ## com,CLS,CAT,NAME); \
		stx_active_movie_wnd_vtinit(vt,PREFIX)

	#define stx_active_movie_wnd_release_default(SCOM)			\
		stx_base_com_release_default(SCOM)\

	#define stx_active_movie_wnd_release_begin(SCOM)			\
		stx_base_com_release_begin(SCOM)\

	#define stx_active_movie_wnd_release_end(SCOM)			\
		stx_base_com_release_end(SCOM)\

	#define stx_active_movie_wnd_query_default(SCOM,vt)			\
		if( IS_EQUAL_GID(gid,STX_IID_ActiveMovieWindow) ) {\
			the->i_ref ++;\
			*pp_interf = (void*)&vt;\
			return STX_OK;\
		}\
		stx_base_com_query_default(SCOM,vt)\



BOOL   InitializeActiveMovieWindow();
void   ReleaseActiveMovieWindow();
void   AddVidWnd(ActiveMovieWindow* pVidWnd,HWND hWnd );
void   RemoveVidWnd(ActiveMovieWindow* pVidWnd);


STX_PRIVATE CREATE_STX_COM(stx_base_plugin,STX_IID_BasePlugin,ActiveMovieWindow);


#if defined( __cplusplus )
}
#endif


#endif // __ACTIVEMOVIEWINDOW_H__

