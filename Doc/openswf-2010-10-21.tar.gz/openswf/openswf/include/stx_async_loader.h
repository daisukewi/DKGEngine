/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#ifndef __STX_ASYNC_LOADER_H__2008_06_21
#define __STX_ASYNC_LOADER_H__2008_06_21

#include "base_class.h"

#if defined( __cplusplus )
extern "C" {
#endif

// {FE46CC3A-BF6C-492e-9D26-F1575A1B924F}
DECLARE_XGUID( STX_CLSID_AsLoader,
	0xfe46cc3a, 0xbf6c, 0x492e, 0x9d, 0x26, 0xf1, 0x57, 0x5a, 0x1b, 0x92, 0x4f);

STX_API	STX_COM(async_loader);

STX_API	CREATE_STX_COM_DECL(stx_base_plugin,async_loader);


#if defined( __cplusplus )
}
#endif


#endif /* __STX_ASYNC_LOADER_H__2008_06_21*/

