/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/


#ifndef __MOV_ENCRYPT_DEMO_H__2008_06_21
#define __MOV_ENCRYPT_DEMO_H__2008_06_21


#if defined( __cplusplus )
extern "C" {
#endif

#include "stx_base_type.h"


STX_API STX_RESULT stx_mp4_encrypt(char* sz_input,char* sz_output);



#if defined( __cplusplus )
}
#endif


#endif /*__MOV_ENCRYPT_DEMO_H__2008_06_21*/ 
