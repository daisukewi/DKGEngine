/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#ifndef __STP_DOWNLOAD_H__
#define __STP_DOWNLOAD_H__


#include "stx_base_type.h"
#include "stx_io.h"
#include "stx_gid_def.h"
#include "base_class.h"



#if defined( __cplusplus )
extern "C" {
#endif


	// {47ECAC06-57C0-42f4-A00D-346D08235EDE}
	DECLARE_XGUID( STX_CLSID_StpDownload,
	0x47ecac06, 0x57c0, 0x42f4, 0xa0, 0xd, 0x34, 0x6d, 0x8, 0x23, 0x5e, 0xde);

	extern char* g_szStreamX_StpDownload;

	STX_API	STX_COM(stp_download);

	STX_API CREATE_STX_COM_DECL(stx_stream_writer,stp_download);



#if defined( __cplusplus )
}
#endif


#endif /*   __STP_DOWNLOAD_H__  */ 
