

#ifndef __MOV_IO_DIRECT_H__2008_06_21
#define __MOV_IO_DIRECT_H__2008_06_21

/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#include "stx_base_type.h"

#include "stx_io.h"

#if defined( __cplusplus )
extern "C" {
#endif


    typedef struct stx_xio_direct stx_xio_direct;

    struct stx_xio_direct{

        stx_xio         stx_xio_vt;

        ByteIOContext*  pb;
    };


STX_API void stx_create_io_direct( ByteIOContext* pb,stx_xio_direct* p_direct );



#if defined( __cplusplus )
}
#endif

#endif /*   __MOV_IO_DIRECT_H__2008_06_21 */ 
