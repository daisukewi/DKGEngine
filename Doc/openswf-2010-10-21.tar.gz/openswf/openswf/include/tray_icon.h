// tray_icon.h: interface for the tray_icon class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TRAY_ICON_H__C02908FF_00F9_4C01_A017_935621C6EBF4__INCLUDED_)
#define AFX_TRAY_ICON_H__C02908FF_00F9_4C01_A017_935621C6EBF4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#define SHELL_TRAY_WND_NAME     _T("Shell_TrayWnd")

#define TRAY_ICON_CLASS_NAME	_T("TrayNotifyWnd")



#define WM_NOTIFYTRAYICON		WM_USER + 500

#define WM_UPDATETRAYICON		WM_USER + 510

#define WM_XDISK_ERR			WM_USER + 520

#define WM_RESIZEPAGE           WM_USER + 530



#define WM_RHOT_BASEID			0x100
#define TRAYICON_NOTIFYID		500	//����ͼ����Ӧ��Ϣ



BOOL	AddTrayIcon(HWND hWnd, UINT nID, HICON hIcon, LPCTSTR lpTip, UINT nCBMsg);

BOOL	DeleteTrayIcon(HWND hWnd, UINT nID);

BOOL	ReplaceTrayIcon(HWND hWnd, UINT nID, HICON hIcon, LPCTSTR lpTip);

DWORD	stxGetAppPath(LPTSTR lpPath,DWORD dwSize);

void	GetTrayWndRect(LPRECT lpRect, char* szTrayWndClass );

void	GetFullScreenSize(SIZE &size, BOOL bWorkArea);


#endif // !defined(AFX_TRAY_ICON_H__C02908FF_00F9_4C01_A017_935621C6EBF4__INCLUDED_)
