/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#ifndef __STX_IO_H__2008_06_21
#define __STX_IO_H__2008_06_21

#include "stx_base_type.h"
#include "stx_cpuid.h"

#if defined( __cplusplus )
extern "C" {
#endif

	
#define INVALID_IO_HANDLE				-1


#define STX_XIO_SET_TIME_OUT			1
#define STX_XIO_SET_ERR_HND				2
#define STX_XIO_SET_BUF_SIZE		    3
#define STX_XIO_SET_DAT_SIZE		    4  /* discard rear data; */
#define STX_XIO_SET_DAT_SHRINK		    5  /* discard header data; */
#define STX_XIO_SET_OPT                 6
#define STX_XIO_SET_BITRATE             7
#define STX_XIO_SET_MIN_DAT_SIZE		8  /* socket read; */

#define STX_XIO_SET_HND					9  /* set socket; */
#define STX_XIO_SET_BIND				10  /* set socket bind string ; */
#define STX_XIO_SET_MAX_SIZE		    11


#define STX_IO_READ_P        1/* buffer pointer;*/
#define STX_IO_READ_SIZE     2/* buffer size;*/
#define STX_IO_READ_S        3/* socket;*/
#define STX_IO_READ_PEER     4/* socket;*/
#define STX_IO_READ_OPT      5
#define STX_IO_READ_HND      6
//#define STX_IO_READ_BITRATE  7
//#define STX_IO_READ_DAT_INF  8
#define STX_IO_READ_IOTYPE	 9
#define STX_IO_READ_OPENKEY	 10

#define STX_IO_PREFETCH		 11
#define STX_IO_PREWRITE		 12
	typedef struct stx_io_op_fetch  stx_io_op_fetch;
	struct stx_io_op_fetch{
		s32			i_max;			// in
		s32			i_op;			// in
		u8*			buf;			// out
		s64			i_data;			// out
		s32			i_rate;			// out
		offset_t	i_pos;			// out
		offset_t	i_size;			// out
	};

#define STX_IO_READ_COM		 100
#define STX_IO_READ_PLUGIN   101
#define STX_IO_ENUM			 102

#define STX_IO_TYPE_LOCAL   1
#define STX_IO_TYPE_STREAM  2


typedef struct stx_io_op_param  stx_io_op_param;

struct stx_io_op_param{
	STX_HANDLE  h_obj;
	char*       buf;
	ssize_t     i_buf_size;
	u32         i_io_type;
	size_t      i_min_data_size;
	offset_t    i_file_size;
	offset_t    i_pos;
	s64			i_available_data;
	s64			i_bit_rate;
	s64         i_shrink_size;
};



typedef struct stx_xio stx_xio;

struct stx_xio{
	_STX_PURE STX_RESULT	(*open)( stx_xio* h, const char *filename, s32 oflag );
	_STX_PURE STX_RESULT	(*close)( stx_xio* h );
	_STX_PURE STX_RESULT	(*read)( stx_xio* h, void *buffer, size_t count, size_t* i_read );
	_STX_PURE STX_RESULT	(*write)( stx_xio* h, const void *buffer, size_t count, size_t* i_write );
	_STX_PURE offset_t		(*seek)( stx_xio* h, offset_t offset, s32 origin );
	_STX_PURE offset_t		(*tell)( stx_xio* h );
	_STX_PURE offset_t		(*size)( stx_xio* h );
	_STX_PURE STX_RESULT	(*set)( stx_xio* h, u32 flags, STX_HANDLE h_val );
	_STX_PURE STX_RESULT	(*get)( stx_xio* h, u32 flags, STX_HANDLE h_val );
	_STX_PURE STX_RESULT	(*clear)( stx_xio* h );
	_STX_PURE STX_RESULT	(*stop)(stx_xio* h);
	_STX_PURE STX_RESULT	(*flush)(stx_xio* h);
};

#define SAFE_CLOSEXIO(h) if( h ) { h->close(h); h = NULL; }
#define SAFE_CLOSE(close,h) if( h ) { close(h); h = NULL; }


#define stx_xio_funcdecl(PREFIX) \
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## open( stx_xio* h, const char *filename, s32 oflag );\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## close( stx_xio* h );\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## read( stx_xio* h, void *buffer, size_t count, size_t* i_read );\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## write( stx_xio* h, const void *buffer, size_t count, size_t* i_write );\
	STX_PURE offset_t	PREFIX ## _xxx_ ## seek( stx_xio* h, offset_t offset, s32 origin );\
	STX_PURE offset_t   PREFIX ## _xxx_ ## tell( stx_xio* h );\
	STX_PURE offset_t   PREFIX ## _xxx_ ## size( stx_xio* h );\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## set( stx_xio* h, u32 flags, STX_HANDLE h_val );\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## get( stx_xio* h, u32 flags, STX_HANDLE h_val );\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## clear( stx_xio* h );\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## stop( stx_xio* h );\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## flush(stx_xio* h)

#define stx_xio_vtinit(vt,PREFIX) \
	STX_VT_INIT(vt,PREFIX,open);\
	STX_VT_INIT(vt,PREFIX,close);\
	STX_VT_INIT(vt,PREFIX,read);\
	STX_VT_INIT(vt,PREFIX,write);\
	STX_VT_INIT(vt,PREFIX,seek);\
	STX_VT_INIT(vt,PREFIX,tell);\
	STX_VT_INIT(vt,PREFIX,size);\
	STX_VT_INIT(vt,PREFIX,set);\
	STX_VT_INIT(vt,PREFIX,get);\
	STX_VT_INIT(vt,PREFIX,clear);\
	STX_VT_INIT(vt,PREFIX,stop);\
	STX_VT_INIT(vt,PREFIX,flush)

#define stx_xio_create_default(vt,PREFIX,CLS,CAT,NAME)		\
	stx_xio_vtinit(vt,PREFIX)


typedef stx_xio stx_mp4_io;

STX_INTERF(ByteIOContext);


struct ByteIOContext{
    size_t			buffer_size;
    u8	           *buffer;
    u8	           *buf_ptr;
	u8	           *buf_end;
	u32				nBits;
	s32             nCurrentBit;
	stx_mp4_io*     pio;
    u32				flags;
    s32				error_code;
};

#define BYTEIO_READ    0x01
#define BYTEIO_WRITE   0x02


#define INIT_BYTEIO_W(pb,i_len,buf,h_stream)\
{\
	memset(&pb,0,sizeof(pb));					\
	pb.buffer = buf;							\
	pb.buffer_size = i_len;						\
	pb.buf_ptr = pb.buffer;						\
	pb.buf_end = pb.buffer + pb.buffer_size;	\
	pb.pio = h_stream;							\
    pb.flags = BYTEIO_WRITE;                  \
}

#define INIT_BYTEIO_DIRECT(pb,i_len,buf)\
{\
    memset(&pb,0,sizeof(pb));					\
    pb.buffer = buf;							\
    pb.buffer_size = i_len;						\
    pb.buf_ptr = pb.buffer;						\
    pb.buf_end = pb.buffer + pb.buffer_size;	\
    pb.flags = BYTEIO_READ;                   \
}

#define INIT_BYTEIO_R(pb,i_len,buf,h_stream)\
{\
	memset(&pb,0,sizeof(pb));					\
	pb.buffer = buf;							\
	pb.buffer_size = i_len;						\
	pb.buf_end = pb.buffer + pb.buffer_size;	\
	pb.buf_ptr = pb.buf_end;					\
	pb.pio = h_stream;							\
    pb.flags = BYTEIO_READ;                   \
}



STX_RESULT		xio_fread(ByteIOContext *s, unsigned char *buf, size_t i_size,size_t* i_read);
STX_RESULT		xio_fwrite(ByteIOContext *s, const unsigned char *buf, size_t i_size,size_t* i_write);
offset_t		xio_fseek(ByteIOContext *s, offset_t offset, int whence);
void			xio_fskip(ByteIOContext *s, offset_t offset);
offset_t		xio_ftell(ByteIOContext *s);
offset_t		xio_fsize(ByteIOContext *s);
b32				xio_feof(ByteIOContext *s);
void			xio_flush(ByteIOContext* s);


#define INVALID_VLC           0x80000000


void	init_get_bits(ByteIOContext *s);
#define	show_bits(s,n)  ( s->nBits >> ( 32 - n ) )
u32		get_bits(ByteIOContext *s,s32 nBits);
s32		svq3_get_ue_golomb(ByteIOContext *s);
void	put_strz(ByteIOContext *s, const s8 *buf);

STX_RESULT stx_flush_buffer(ByteIOContext *s);
STX_RESULT stx_fill_buffer(ByteIOContext *s);


#if defined( __cplusplus )
}
#endif



stx_inline u32		show_bits32(ByteIOContext *s);
stx_inline uint32	get_byte(ByteIOContext *s);
stx_inline uint32	get_le24(ByteIOContext *s);
stx_inline uint32	get_le32(ByteIOContext *s);
stx_inline uint64	get_le64(ByteIOContext *s);
stx_inline uint32	get_le16(ByteIOContext *s);
stx_inline uint32	get_be16(ByteIOContext *s);
stx_inline uint32	get_be24(ByteIOContext *s);
stx_inline uint32	get_be32(ByteIOContext *s);
stx_inline uint64	get_be64(ByteIOContext *s);

stx_inline char*	get_strz(ByteIOContext *s, char *buf, int maxlen);
stx_inline void		put_byte(ByteIOContext *s, uint32 b);
stx_inline void		put_le64(ByteIOContext *s, uint64 val);
stx_inline void		put_be64(ByteIOContext *s, uint64 val);
stx_inline void		put_le32(ByteIOContext *s, uint32 val);
stx_inline void		put_be32(ByteIOContext *s, uint32 val);
stx_inline void		put_le24(ByteIOContext *s, uint32 val);
stx_inline void		put_be24(ByteIOContext *s, uint32 val);
stx_inline void		put_le16(ByteIOContext *s, uint32 val);
stx_inline void		put_be16(ByteIOContext *s, uint32 val);
stx_inline void		put_tag(ByteIOContext *s, const char *tag);



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
only under arch x86, little endian only;
***************************************************************************/
stx_inline void put_le32(ByteIOContext *s, uint32 val)
{
	if (s->buf_ptr + sizeof(u32) <= s->buf_end ){

		*(u32*)s->buf_ptr = val;

		s->buf_ptr += sizeof(u32);

		if (s->buf_ptr >= s->buf_end) {

			stx_flush_buffer(s);
		}

		return;
	}

	put_byte(s, val); 

	put_byte(s, val >> 8);

	put_byte(s, val >> 16);

	put_byte(s, val >> 24);
}







/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
stx_inline void put_le64(ByteIOContext *s, uint64 val)
{
	put_le32(s, (u32)(val & 0xffffffff));

	put_le32(s, (u32)(val >> 32));
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
stx_inline void put_be64(ByteIOContext *s, uint64 val)
{
	put_be32(s, (u32)(val >> 32));

	put_be32(s, (u32)(val & 0xffffffff));
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
only under arch x86, little endian only;
***************************************************************************/
stx_inline void put_be32(ByteIOContext *s, uint32 val)
{
	if (s->buf_ptr + sizeof(u32) <= s->buf_end){

		u32 t;

		FAST_SWAP32(t,val);

		*(u32*)s->buf_ptr = t;

		s->buf_ptr += sizeof(u32);

		if (s->buf_ptr >= s->buf_end) {

			stx_flush_buffer(s);
		}

		return;
	}

	put_byte(s, val >> 24);    

	put_byte(s, val >> 16);    

	put_byte(s, val >> 8);     

	put_byte(s, val); 
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

stx_inline void put_le16(ByteIOContext *s,uint32 val)
{
	put_byte(s, val);

	put_byte(s, val >> 8);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

stx_inline void put_be16(ByteIOContext *s, uint32 val)
{
	put_byte(s, val >> 8);

	put_byte(s, val);
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

stx_inline void put_le24(ByteIOContext *s, uint32 val)
{
	put_le16(s, val & 0xffff );

	put_byte(s, val >> 16 );
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

stx_inline void put_be24(ByteIOContext *s, uint32 val)
{
	put_be16(s, val >> 8);

	put_byte(s, val);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

stx_inline void put_tag(ByteIOContext *s, const char *tag)
{
	while (*tag) {

		put_byte(s, *tag++);
	}
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

stx_inline void put_byte(ByteIOContext *s, uint32 b)
{
	*s->buf_ptr = (u8)b;

	s->buf_ptr++;

	if( s->buf_ptr >= s->buf_end ){

		stx_flush_buffer(s);
	}
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

/* XXX: put an inline version */
stx_inline uint32 get_byte(ByteIOContext *s)
{
	if (s->buf_ptr < s->buf_end) {

		return *s->buf_ptr++;
	} 
	else {

		stx_fill_buffer(s);

		if (s->buf_ptr < s->buf_end){

			return *s->buf_ptr++;
		}
		else{

			return 0;
		}
	}
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

stx_inline uint32 get_le16(ByteIOContext *s)
{
	uint32 val;

	val = get_byte(s);

	val |= get_byte(s) << 8;

	return val;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

stx_inline uint32 get_le24(ByteIOContext *s)
{
	uint32 val;

	val = get_le16(s);

	val |= get_byte(s) << 16;

	return val;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

stx_inline uint32 get_le32(ByteIOContext *s)
{
	uint32 val;

	val = get_le16(s);

	val |= get_le16(s) << 16;

	return val;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

stx_inline uint64 get_le64(ByteIOContext *s)
{
	uint64 val;

	val = (uint64)get_le32(s);

	val |= (uint64)get_le32(s) << 32;

	return val;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

stx_inline uint32 get_be16(ByteIOContext *s)
{
	uint32 val;

	val = get_byte(s) << 8;

	val |= get_byte(s);

	return val;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

stx_inline uint32 get_be24(ByteIOContext *s)
{
	uint32 val;

	val = get_be16(s) << 8;

	val |= get_byte(s);

	return val;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

stx_inline uint32 get_be32(ByteIOContext *s)
{
	uint32 val;

	val = get_be16(s) << 16;

	val |= get_be16(s);

	return val;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

stx_inline char *get_strz(ByteIOContext *s, char *buf, int maxlen)
{
	int i = 0;
	char c;

	while ((c = (char)get_byte(s))) {

		if (i < maxlen-1){

			buf[i++] = c;
		}
	}

	buf[i] = 0; /* Ensure null terminated, but may be truncated */

	return buf;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

stx_inline uint64 get_be64(ByteIOContext *s)
{
	uint64 val;

	val = (uint64)get_be32(s) << 32;

	val |= (uint64)get_be32(s);

	return val;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
stx_inline u32 show_bits32(ByteIOContext *s)
{
	if( s->nCurrentBit & 7 ) {
		get_bits(s, s->nCurrentBit & 7 );
	}

	if( s->nCurrentBit < 32 ) {
		get_bits(s,0);
	}

	return s->nBits;
}




#endif /*    __STX_IO_H__2008_06_21  */ 
