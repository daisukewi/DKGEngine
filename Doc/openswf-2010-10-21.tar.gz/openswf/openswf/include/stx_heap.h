/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#ifndef _STXHEAP_H_
#define _STXHEAP_H_

#define _STXHEAP_TESTING_ 0

#include "base_interf.h"
#include "stx_os.h"
#include "stx_mem.h"



#if defined( __cplusplus )
extern "C" {
#endif




#define kDefaultStartSize 1024


STX_INTERF(stxHeapElem);

STX_INTERF(stxHeap);

struct stxHeap
{
	stxHeapElem**    fHeap;
	u32				fFreeIndex;
	u32				fArraySize;
	u32             fSize;
};

STX_API stxHeap*		stxHeapCreate(u32 inStartSize);
STX_API STX_RESULT  stxHeapInsert(stxHeap* h,stxHeapElem*  inElem);
STX_API stxHeapElem* stxHeapRemove(stxHeap* h,stxHeapElem* elem);
STX_API stxHeapElem* stxHeapExtract(stxHeap* h,u32 index);
STX_API void        stxHeapEmpty(stxHeap* h);


#if _STXHEAP_TESTING_
//returns true if it passed the test, false otherwise
STX_API b16			stxHeapTest(stxHeap* h);
//verifies that the heap is in fact a heap
STX_API void        stxHeapSanityCheck(stxHeap* h,u32 root);
#endif



struct stxHeapElem
{
	s64		fValue;
	void*	fEnclosingObject;
	stxHeap* fCurrentHeap;
};


#if defined( __cplusplus )
}
#endif


stx_inline void stxHeapClose(stxHeap* h)
{
	if( h->fHeap ) {
		stx_free( h->fHeap );
	}
	stx_free( h );
}

stx_inline u32 stxHeapCurrentHeapSize(stxHeap* h)
{ 
	return h->fFreeIndex - 1; 
}

stx_inline stxHeapElem* stxHeapPeekMin(stxHeap* h)
{ 
	if (stxHeapCurrentHeapSize(h) > 0) 
		return h->fHeap[1]; 
	return NULL; 
}


stx_inline stxHeapElem* stxHeapExtractMin(stxHeap* h) 
{ 
	return stxHeapExtract(h,1); 
}


stx_inline stxHeapElem* stxHeapElemCreate(void* enclosingObject)
{
	stxHeapElem* h;
	DECL_TRACE

	MAKE_TRACE2
	h = smart_mallocz( sizeof( stxHeapElem) ,MAP_TRACE );
	if( !h){
		return NULL;
	}

	h->fEnclosingObject = enclosingObject;

	return h;
}

stx_inline void stxHeapElemClose(stxHeapElem* h)
{
	stx_free( h );
}

//This data structure emphasizes performance over extensibility
//If it were properly object-oriented, the compare routine would
//be virtual. However, to avoid the use of v-functions in this data
//structure, I am assuming that the objects are compared using a 64 bit number.
//
stx_inline	void    stxHeapElemSetValue(stxHeapElem* h,s64 newValue) 
{ 
	h->fValue = newValue; 
}
stx_inline	s64		stxHeapElemGetValue(stxHeapElem* h)              
{ 
	return h->fValue; 
}
stx_inline	void*   stxHeapElemGetEnclosingObject(stxHeapElem* h)    
{ 
	return h->fEnclosingObject; 
}
stx_inline	void	stxHeapElemSetEnclosingObject(stxHeapElem* h,void* obj) 
{ 
	h->fEnclosingObject = obj; 
}
stx_inline	b16		stxHeapElemIsMemberOfAnyHeap(stxHeapElem* h)     
{ 
	return h->fCurrentHeap != NULL; 
}



#endif //_STXHEAP_H_
