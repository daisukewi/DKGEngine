/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#ifndef __STX_MODULE_REG_H__
#define __STX_MODULE_REG_H__

#include "base_class.h"

#include "stx_connect_ctx.h"


STX_INTERF(stx_plug_monitor);
struct stx_plug_monitor{
	THEE	h_stat;
	s64		i_report_time;
	s64		i_last_time;
};



#if defined( __cplusplus )
extern "C" {
#endif



/* {2EB24117-F67D-4874-84B6-8E34EB8A387B}*/
DECLARE_XGUID( STX_REG_MONITOR,0x2eb24117, 0xf67d, 0x4874, 0x84, 0xb6, 0x8e, 0x34, 0xeb, 0x8a, 0x38, 0x7b)

extern char* g_szStreamX_Root;
extern char* g_szStreamX_Path;

extern char* g_szGraphBuilder;

extern char* g_szFilterGraph;

extern char* g_szSyncSource;

extern char* g_szMemAllocator;

extern char* g_szRender;

extern char* g_szFileSource;

extern char* g_szIntermediateFilter;

extern char* g_szStreamX_Cfg;
extern char* g_sz_service_cfg;

extern char* g_szStreamX_AllModule;
extern char* g_szStreamX_AllService;
extern char* g_szStreamX_AllDlib;

extern char* g_szStreamX_FilterName;
extern char* g_szStreamX_PathName;
extern char* g_szStreamX_ClassId;
extern char* g_szStreamX_ClassIdName;

extern char* g_szStreamX_MainCategory;
extern char* g_szStreamX_CategoryDesc;

extern char* g_szStreamX_Interface;

extern char* g_szStreamX_InputType;
extern char* g_szStreamX_OutputType;
extern char* g_szStreamX_MajorDataType;
extern char* g_szStreamX_MajorDataTypeName;
extern char* g_szStreamX_SubDataType;
extern char* g_szStreamX_SubDataTypeName;

extern char* g_szStreamX_CreateModule;

extern char* g_szStreamX_OutputPin;
extern char* g_szStreamX_InputPin;

extern char* g_szStreamX_AllStream;
extern char* g_szStreamX_Extension;

extern char* g_szStreamX_VideoFile;
extern char* g_szStreamX_AudioFile;
extern char* g_szStreamX_QuickTimeVideo;
extern char* g_szStreamX_QuickTimeAudio;
extern char* g_szStreamX_WMV;
extern char* g_szStreamX_WMA;

extern char* g_szStreamX_length;
extern char* g_szStreamX_dts;
extern char* g_szStreamX_pts;
extern char* g_szStreamX_duration;
extern char* g_szStreamX_header;
extern char* g_szStreamX_width;
extern char* g_szStreamX_pitch;
extern char* g_szStreamX_height;
extern char* g_szStreamX_display;
extern char* g_szStreamX_pushmode;
extern char* g_szStreamX_enable;



STX_API stx_base_graph_builder*	stx_initialize( void (*)(char*),u32 i_debug );
STX_API void					stx_cleanup(stx_base_graph_builder* h);


STX_API STX_RESULT				on_first_audio_data(stx_base_plugin* plug,s64 i_pts);


#if defined( __cplusplus )
}
#endif



#endif /*    __STX_MODULE_REG_H__   */ 
