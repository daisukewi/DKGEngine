/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/
#ifndef __BASE_PIN_WND_H__
#define __BASE_PIN_WND_H__

#include "stx_all.h"


#if defined( __cplusplus )
extern "C" {
#endif

	static char* g_szGradeIndex = "GradeIndex";
	static char* g_szFilterIndex = "FilterIndex";
	static char* g_szPinIndex = "PinIndex";
	static char* g_szInstanceId = "InstanceId";
	static char* g_szStartPin = "StartPin";
	static char* g_szEndPin = "EndPin";


	STX_INTERF(base_flt_wnd);
	STX_INTERF(base_pin_wnd);

#define base_pin_wnd_def() \
	HWND				m_hWnd; \
	base_flt_wnd*		m_fltwnd; \
	stx_base_pin*		m_hPin; \
	stx_gid				m_insid; \
	RECT				m_pos; \
	b32					m_bFocus; \
	stx_xio*			m_hPropStream; \
	s32                 m_iIndex; \
	stx_media_type_inf  m_minf; \
	b32                 m_bConnection; \
	b32					m_bOutput; \
	DECL_TRACE\
	void (*close)(STX_HANDLE h); \
	STX_RESULT	(*initialize)(STX_HANDLE h,stx_xini* h_xini,STX_HANDLE h_parent); \
	STX_RESULT	(*serialize)(STX_HANDLE h,stx_xini* h_xini,STX_HANDLE h_parent); \
	void		(*SetPin)(STX_HANDLE h,stx_base_pin* pin); \
	void		(*move)(STX_HANDLE h,s32 x,s32 y); \
	stx_base_pin* (*GetPin)(STX_HANDLE h); \
	void (*ReleasePin)(STX_HANDLE h); \
	POINT (*GetPoint)(STX_HANDLE h)


	struct base_pin_wnd{
		base_pin_wnd_def();
	};

	base_pin_wnd* create_base_pin_wnd(size_t i_size,HWND hwnd);

	void base_pin_wnd_close(STX_HANDLE h);



	static b32 base_pin_wnd_IsOutputPin(base_pin_wnd* the){
		return the->m_bOutput;
	}

	static  void base_pin_wnd_SetPos(base_pin_wnd* the,RECT pos){
		the->m_pos = pos;
	}

	static  void base_pin_wnd_set_pin_inf(base_pin_wnd* the,s32 i_index,stx_media_type_inf* minf){
		the->m_iIndex = i_index;
		the->m_minf = *minf;
	}

	static  void base_pin_wnd_get_pin_inf(base_pin_wnd* the,s32* i_index,stx_media_type_inf* minf){
		*i_index = the->m_iIndex;
		*minf = the->m_minf;
	}

	static  base_flt_wnd* base_pin_wnd_get_fltwnd(base_pin_wnd* the){
		return the->m_fltwnd;
	}

	static  void base_pin_wnd_set_fltwnd(base_pin_wnd* the,base_flt_wnd* fltwnd){
		the->m_fltwnd = fltwnd;
	}

	static  stx_gid base_pin_wnd_GetInsId(base_pin_wnd* the){
		return the->m_insid;
	}

	static  void    base_pin_wnd_SetInsId(base_pin_wnd* the,stx_gid insid){
		the->m_insid = insid;
	}

	static  RECT base_pin_wnd_get_pos(base_pin_wnd* the){
		return the->m_pos;
	}

	static  void base_pin_wnd_set_pos(base_pin_wnd* the,RECT rec){
		the->m_pos = rec;
	}

	static  void base_pin_wnd_set_connection(base_pin_wnd* the,b32 b_connection){
		the->m_bConnection = b_connection;
	}

	static  b32 base_pin_wnd_is_connection(base_pin_wnd* the){
		return the->m_bConnection;
	}


#if defined( __cplusplus )
}
#endif


#endif /* __BASE_PIN_WND_H__ */ 