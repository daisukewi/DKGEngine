/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/
#ifndef __STX_ASYNC_PLUGIN_H__
#define __STX_ASYNC_PLUGIN_H__

#include "base_class.h"
#include "stx_msg_def.h"
#include "stx_thread.h"
#include "xdisk_loop.h"
#include "stx_stat.h"

#if defined( __cplusplus )
extern "C" {
#endif


/*****************************************************************************
*****************************************************************************/
#define OCUPY_PERIOD_TIME 500*1000

#define async_plugin_vtdef() \
	stx_base_plugin_vtdef() \
	_STX_PURE    STX_PURE_MSG_PROC_DECLARE(dispatch_msg) \
	_STX_PURE    STX_PURE_MSG_PROC_DECLARE(response_msg) \
	_STX_PURE    STX_PURE_MSG_PROC_DECLARE(up_stream_msg) \
	_STX_PURE    STX_PURE_MSG_PROC_DECLARE(down_stream_msg) \
	_STX_PURE    u32		(*async_plugin_proc)(STX_HANDLE h);\
	_STX_PURE	 void		(*lock)(STX_HANDLE h); \
	_STX_PURE	 void		(*unlock)(STX_HANDLE h); \
	_STX_PURE	 u32		(*get_occupy)(STX_HANDLE h); \

	struct async_plugin{
		async_plugin_vtdef()
	};


	/*{{{**********************************************************************/
#define async_plugin_funcdecl(PREFIX) \
	stx_base_plugin_funcdecl(PREFIX ## _plug);\
	STX_MSG_PROC_DECLARE( PREFIX ## _xxx_ ## dispatch_msg )\
	STX_MSG_PROC_DECLARE( PREFIX ## _xxx_ ## response_msg )\
	STX_MSG_PROC_DECLARE( PREFIX ## _xxx_ ## up_stream_msg )\
	STX_MSG_PROC_DECLARE( PREFIX ## _xxx_ ## down_stream_msg )\
	STX_PURE u32  PREFIX ## _xxx_ ## async_plugin_proc(STX_HANDLE h);\
	STX_PURE void PREFIX ## _xxx_ ## lock(STX_HANDLE h);\
	STX_PURE void PREFIX ## _xxx_ ## unlock(STX_HANDLE h);\
	STX_PURE u32  PREFIX ## _xxx_ ## get_occupy(STX_HANDLE h)


#define async_plugin_vtinit(vt,PREFIX) \
	STX_VT_INIT(vt,PREFIX,dispatch_msg);\
	STX_VT_INIT(vt,PREFIX,response_msg);\
	STX_VT_INIT(vt,PREFIX,up_stream_msg);\
	STX_VT_INIT(vt,PREFIX,down_stream_msg);\
	STX_VT_INIT(vt,PREFIX,async_plugin_proc);\
	STX_VT_INIT(vt,PREFIX,lock);\
	STX_VT_INIT(vt,PREFIX,unlock);\
	STX_VT_INIT(vt,PREFIX,get_occupy)


#define async_plugin_data_default()					\
	stx_base_plugin_data_default() \
	STX_HANDLE					h_stat_mutex;\
	s64							i_idle;\
	s32							i_lock;\
	STX_HANDLE					h_stat;\
	STX_HANDLE					h_mutex;\
	STX_HANDLE					h_sync;\
	b32							b_sleep;\
	xloop*						p_msg_pool;	\
	stx_thread 					thread_param;


#define async_plugin_funcimp_default(SCOM,PREFIX)	\
stx_base_plugin_funcimp_default(SCOM,PREFIX ## _plug )\
/*{{{***********************************************************************/\
STX_MSG_PROC_DECLARE(PREFIX ## _xxx_ ## dispatch_msg)\
/*}}}***********************************************************************/\
\
/*{{{STX_MSG_ENTRY_DECLARE**************************************************/\
STX_MSG_ENTRY_DECLARE(PREFIX ## _xxx_ ## on_play)\
STX_MSG_ENTRY_DECLARE(PREFIX ## _xxx_ ## on_stop)\
/*}}}***********************************************************************/\
\
/*{{{STX_BEGIN_MSG_MAP******************************************************/\
STX_BEGIN_MSG_MAP(PREFIX ## _the_msg_data)\
/* to do : add msg proc entry here; */\
ON_STX_MSG(STX_MSG_AsStop,PREFIX ## _xxx_ ## on_stop)\
ON_STX_MSG(STX_MSG_AsPlay,PREFIX ## _xxx_ ## on_play)\
STX_END_MSG_MAP\
/*}}}***********************************************************************/\
/*{{{STX_BEGIN_MSG_RESPONSE_MAP*********************************************/\
STX_BEGIN_MSG_RESPONSE_MAP(PREFIX ## _the_msg_response)\
/* to do : add msg process entry name here; */\
STX_END_MSG_RESPONSE_MAP\
\
/*{{{***********************************************************************/\
STX_DISPATCH_MSG_PROC(PREFIX ## _xxx_ ## base_ ## dispatch_msg,PREFIX ## _the_msg_data )  \
/*}}}***********************************************************************/\
/*{{{STX_RESPONSE_MSG_PROC**************************************************/\
STX_RESPONSE_MSG_PROC(PREFIX ## _xxx_ ## base_ ## response_msg,PREFIX ## _the_msg_response)\
/*}}}***********************************************************************/\
\
/*{{{***********************************************************************/\
STX_MSG_PROC_DECLARE(PREFIX ## _xxx_ ## post_msg)\
STX_MSG_PROC_DECLARE(PREFIX ## _xxx_ ## post_msg_check)\
/*}}}***********************************************************************/\
\
/*{{{***********************************************************************/\
STX_PRIVATE STX_RESULT			PREFIX ## _xxx_ ## check_msg( STX_HANDLE h );\
STX_PRIVATE stx_base_message*	PREFIX ## _xxx_ ## pick_msg(STX_HANDLE h );\
/*}}}***********************************************************************/\
STX_PURE u32 PREFIX ## _xxx_ ## get_occupy(STX_HANDLE h)\
{\
	u32  i_ret;\
	STX_MAP_THE(SCOM);\
	stx_waitfor_mutex(the->h_stat_mutex,INFINITE);\
	i_ret = stx_stat_get_occupy(the->h_stat); \
	stx_release_mutex(the->h_stat_mutex);\
	return i_ret;\
}\
\
STX_PURE void PREFIX ## _xxx_ ## lock(STX_HANDLE h)\
{\
	STX_DIRECT_THE(SCOM);\
	/*stx_log("async plugin::lock::i_lock = %d\r\n",the->i_lock);*/\
	stx_waitfor_mutex( the->h_mutex, INFINITE );\
	/*the->i_lock ++;*/ \
}\
\
STX_PURE void PREFIX ## _xxx_ ## unlock(STX_HANDLE h)\
{\
	STX_DIRECT_THE(SCOM);\
	/*the->i_lock --; */\
	/*stx_log("async plugin::unlock::i_lock = %d\r\n",the->i_lock);*/\
	stx_release_mutex(the->h_mutex );\
}\
\
STX_PURE STX_RESULT PREFIX ## _plug ## _xxx_ ## send_msg( STX_HANDLE h, stx_base_message* p_msg )\
{\
	STX_RESULT				i_err;\
	u32						i_msg_type;\
	stx_gid					cls_gid,cls_gid_plug;\
	async_plugin*           h_asy; \
\
	STX_MAP_THE(SCOM);\
	h_asy = (async_plugin*)h;\
	i_err = STX_ERR_INVALID_PARAM;\
\
	cls_gid = p_msg->get_msg_dest(p_msg);\
	cls_gid_plug = h_asy->get_clsid(h_asy);\
\
	i_msg_type = p_msg->get_msg_type(p_msg);\
\
	if( STX_MSG_TYPE_ASYNC & i_msg_type ) {\
		return PREFIX ## _xxx_ ## post_msg( h, p_msg );\
	}\
\
	PREFIX ## _xxx_ ## lock(the);\
\
	do{\
\
		/* call sub class msg routine */\
		i_err = h_asy->dispatch_msg( h_asy, p_msg );\
		if( i_err < 0 || p_msg->is_msg_closed(p_msg) ) {\
			break;\
		}\
		i_err = PREFIX ## _xxx_ ## base_ ## dispatch_msg( h, p_msg );\
		if( i_err < 0 || p_msg->is_msg_closed(p_msg) ) {\
			break;\
		}\
		/* call sub class msg routine */\
		i_err = h_asy->response_msg( h_asy, p_msg );\
		if( p_msg->is_msg_closed(p_msg) ||  IS_EQUAL_GID( cls_gid, cls_gid_plug ) ) {\
			break;\
		}\
		i_err = PREFIX ## _xxx_ ## base_ ## response_msg( h, p_msg );\
		if( i_err < 0 || p_msg->is_msg_closed(p_msg) ) {\
			break;\
		}\
		if( STX_MSG_TYPE_UPSTREAM & i_msg_type ) {\
			i_err = h_asy->up_stream_msg( h_asy, p_msg );\
			if( i_err < 0 ) {\
				break;\
			}\
		}\
		else if( STX_MSG_TYPE_DOWNSTREAM & i_msg_type){\
			i_err = h_asy->down_stream_msg( h_asy, p_msg );\
			if( i_err < 0 ) {\
				break;\
			}\
		}\
	}while(FALSE);\
\
	PREFIX ## _xxx_ ## unlock(the);\
\
	return i_err;\
}\
\
STX_MSG_PROC STX_RESULT PREFIX ## _xxx_ ## on_play(STX_HANDLE h, stx_base_message* p_msg )\
{\
	STX_RESULT				i_err;\
	stx_msg_cnt*			cnt;\
	STX_MAP_THE(SCOM);\
	cnt = p_msg->get_msg_cnt(p_msg);\
	if( emStxStatusReady != the->em_status  ) {\
		cnt->param.i_param[0] = STX_ERR_OBJ_STATUS;\
		return STX_OK;\
	}\
	i_err = stx_thread_init( h, PREFIX ## _xxx_async_plugin_proc, &the->thread_param );\
	cnt->param.i_param[0] = i_err;\
	if( STX_OK == i_err ) {\
		the->em_status = emStxStatusPlay;\
	}\
	return STX_OK;\
}\
\
STX_MSG_PROC STX_RESULT PREFIX ## _xxx_ ## on_stop(STX_HANDLE h, stx_base_message* p_msg )\
{\
	stx_msg_cnt* cnt;\
	STX_MAP_THE(SCOM);\
	cnt = p_msg->get_msg_cnt(p_msg);\
	if( emStxStatusStop == the->em_status  ) {\
		cnt->param.i_param[0] = STX_ERR_OBJ_STATUS;\
		return STX_OK;\
	}\
	cnt->param.i_param[0] = STX_OK;\
	the->em_status = emStxStatusStop;\
	\
	return STX_OK;\
}\
\
static STX_RESULT PREFIX ## _xxx_ ## post_msg_check( STX_HANDLE h, stx_base_message* p_msg )\
{\
	stx_msg_cnt* p_msn;\
	STX_MAP_THE(SCOM);\
	p_msn = p_msg->get_msg_cnt(p_msg);\
	if( IS_EQUAL_GID(p_msn->msg_gid ,STX_MSG_AsStop) ) {\
		stx_thread_destory(&the->thread_param);\
	}\
	return STX_OK;\
}\
\
static STX_RESULT PREFIX ## _xxx_ ## post_msg( STX_HANDLE h, stx_base_message* p_msg )\
{\
	STX_RESULT		i_err;\
	u32				i_type;\
	STX_MAP_THE(SCOM);\
	i_err = STX_FAIL;\
	i_type = p_msg->get_msg_type(p_msg);\
	PREFIX ## _xxx_ ## lock(the);\
	if( xloopIsFull(the->p_msg_pool) ) {\
		void* p;\
		xloop* pl = xloopCreate(the->p_msg_pool->size + 1024);\
		if( !pl ) {\
			PREFIX ## _xxx_ ## unlock(the);\
			return STX_FAIL;\
		}\
		while( p = xloopPull(the->p_msg_pool) ) {\
			xloopPush(pl,p);\
		}\
		xloopRelease(the->p_msg_pool);\
		the->p_msg_pool = pl;\
	}\
	if( i_type & STX_MSG_TYPE_BLOCK ) {\
		xloopPush(the->p_msg_pool,p_msg);\
		PREFIX ## _xxx_ ## unlock(the);\
		p_msg->wait(p_msg);\
	}\
	else {\
		stx_base_message* p = XCREATE(base_msg,NULL,p_msg);\
		if( !p) {\
			PREFIX ## _xxx_ ## unlock(the);\
			return STX_FAIL;\
		}\
		xloopPush(the->p_msg_pool,p);\
		PREFIX ## _xxx_ ## unlock(the);\
	}\
	/* do msg check;*/\
	i_err = PREFIX ## _xxx_ ## post_msg_check(h,p_msg);\
	return i_err;\
}\
\
static stx_base_message* PREFIX ## _xxx_ ## pick_msg(STX_HANDLE h )\
{\
	stx_base_message* p_msg;\
	STX_MAP_THE(SCOM);\
	PREFIX ## _xxx_ ## lock(the);\
	p_msg = xloopPull(the->p_msg_pool);\
	PREFIX ## _xxx_ ## unlock(the);\
	return p_msg;\
}\
\
static STX_RESULT PREFIX ## _xxx_ ## check_msg( STX_HANDLE h )\
{\
	STX_RESULT			i_err;\
	stx_base_message*	p_msg;\
	async_plugin*       h_asy;\
	STX_MAP_THE(SCOM);\
	h_asy = (async_plugin*)h;\
	p_msg = PREFIX ## _xxx_ ## pick_msg( h );\
	if( !p_msg ) {\
		return STX_IDLE;\
	}\
	/*PREFIX ## _xxx_ ## lock(the);*/\
	do{\
		/* call sub class msg routine */\
		/*__debugbreak(); */\
		i_err = h_asy->dispatch_msg( h_asy, p_msg );\
		if( i_err < 0 || p_msg->is_msg_closed(p_msg) ) {\
			break;\
		}\
		i_err = PREFIX ## _xxx_ ## base_ ## dispatch_msg( h, p_msg );\
		if( i_err < 0 || p_msg->is_msg_closed(p_msg) ) {\
			break;\
		}\
		i_err = h_asy->response_msg( h_asy, p_msg );\
		if( i_err < 0 || p_msg->is_msg_closed(p_msg) ) {\
			break;\
		}\
		i_err = PREFIX ## _xxx_ ## base_ ## response_msg( h, p_msg );\
		if( i_err < 0 || p_msg->is_msg_closed(p_msg) ) {\
			break;\
		}\
	}while(FALSE);\
	/*PREFIX ## _xxx_ ## unlock(the);*/\
	p_msg->get_msg_cnt(p_msg)->param.i_param[0] = i_err;\
	if( STX_MSG_TYPE_BLOCK & p_msg->get_msg_type(p_msg) ){\
		p_msg->signal(p_msg);\
	}\
	else{/*duplicate msg, free it; */\
		p_msg->release(p_msg);\
	}\
	return i_err;\
}\
\
STX_PURE u32 PREFIX ## _xxx_ ## async_plugin_proc(STX_HANDLE h)\
{\
	STX_RESULT		i_err;\
	s64             i_start;\
	s64				i_cur;\
	async_plugin*   h_asy;\
	stx_sync_inf    sync_inf;\
	\
	STX_MAP_THE(SCOM);\
	h_asy = (async_plugin*)h;\
	i_err = STX_OK;\
	the->i_idle = 0;\
	INIT_MEMBER(sync_inf);\
	i_cur = 0;\
	\
	for( ; ; ) {\
		\
		i_err = PREFIX ## _xxx_ ## check_msg( h );\
		\
		if( STX_IDLE != i_err ) { \
			/* until all the message were dispatched;*/\
			continue;\
		}\
		\
		if( emStxStatusStop == the->em_status ) {\
			/* there must dispatched a stop message ; thread exit method; */\
			break;\
		}\
		\
		if( emStxStatusPause == the->em_status ) {\
			/* there must dispatched a pause message; */\
			i_cur = stx_get_microsec();\
			stx_semaphore_wait(the->h_sync,10);\
			i_cur = stx_get_microsec() - i_cur;\
			stx_waitfor_mutex(the->h_stat_mutex,INFINITE);\
			stx_stat_add_val(the->h_stat,i_cur);\
			stx_release_mutex(the->h_stat_mutex);\
			continue;\
		}\
		\
		if( the->i_idle ) {\
			i_cur = stx_get_microsec();\
			if( i_cur - i_start < the->i_idle ) {\
				/*stx_sleep(1);*/\
				the->b_sleep = TRUE;\
				stx_semaphore_wait(the->h_sync,1);\
				the->b_sleep = FALSE;\
				i_cur = stx_get_microsec() - i_cur;\
				/*stx_log("sleep 1 milisec, microsec value = %d\r\n",i_cur);*/\
				stx_waitfor_mutex(the->h_stat_mutex,INFINITE);\
				stx_stat_add_val(the->h_stat,i_cur);\
				stx_release_mutex(the->h_stat_mutex);\
				continue;\
			}\
			the->i_idle = 0; \
		}\
		\
		INIT_MEMBER(sync_inf);\
		i_err = h_asy->run( h , &sync_inf );\
		\
		if( i_err < 0 ) {\
			/* fatal error , report and exit; */\
			the->em_status = emStxStatusStop;\
			break;\
		}\
		\
		if( STX_IDLE == i_err && sync_inf.i_idle ) {\
			the->i_idle = REFTIME2USEC(sync_inf.i_idle);\
			/*stx_log("idle time value = %"PRId64"d microsec;\r\n",the->i_idle);*/\
			i_start = stx_get_microsec();\
		}\
		stx_waitfor_mutex(the->h_stat_mutex,INFINITE);\
		stx_stat_update(the->h_stat);\
		stx_release_mutex(the->h_stat_mutex);\
		\
	} /*for( ; ; ) {*/\
	\
	return 0;\
}



#define async_plugin_create_default(vt,PREFIX,CLS,CAT,NAME)     \
	stx_base_plugin_create_default(vt,PREFIX ## _plug,CLS,CAT,NAME); \
	async_plugin_vtinit(vt,PREFIX);\
	the->h_stat_mutex = stx_create_mutex(STX_NULL,0,STX_NULL);\
	if( !the->h_stat_mutex ) {\
		break;\
	}\
	the->h_mutex = stx_create_mutex(STX_NULL,0,STX_NULL);\
	if( !the->h_mutex ) {\
		break;\
	}\
	the->p_msg_pool = xloopCreate( STX_MSG_MAX );	\
	if( !the->p_msg_pool ) {\
		break;\
	}\
	the->h_stat = stx_stat_create();\
	if( !the->h_stat) {\
		break;\
	}\
	the->h_sync = stx_semaphore_create(NULL,0,1,NULL);\
	if( !the->h_sync) {\
		break;\
	}\
	the->em_status = emStxStatusReady


#define async_plugin_release_default(SCOM)          \
	stx_base_plugin_release_default(SCOM)\
	if( the->h_sync ) {\
		stx_semaphore_destory(the->h_sync);\
		the->h_sync = NULL; \
	}\
	if( the->h_stat ) {\
		stx_stat_close(the->h_stat);\
		the->h_stat = NULL; \
	}\
	if( the->p_msg_pool ) {\
		xloopRelease( the->p_msg_pool );\
		the->p_msg_pool = STX_NULL;\
	}\
	if( the->h_mutex ) {\
		stx_close_mutex( the->h_mutex );\
		the->h_mutex = STX_NULL;\
	}\
	if( the->h_stat_mutex ) {\
		stx_close_mutex( the->h_stat_mutex );\
		the->h_stat_mutex = STX_NULL;\
	}

#define async_plugin_release_begin(SCOM)            \
	stx_base_plugin_release_begin(SCOM)\

#define async_plugin_release_end(SCOM)				\
	stx_base_plugin_release_end(SCOM)\

#define async_plugin_query_default(SCOM,vt)         \
	if( IS_EQUAL_GID(gid,STX_IID_AsyncPlugin) ) {\
		the->i_ref ++;\
		*pp_interf = (void*)&vt;\
		return STX_OK;\
	}\
	stx_base_plugin_query_default(SCOM,vt)\


/*}}}**********************************************************************/




/*****************************************************************************
*****************************************************************************/
#define TASK_NORMAL 0x01
#define TASK_IDLE   0x02

#define stx_sync_source_vtdef() \
	async_plugin_vtdef() \
	_STX_PURE	STX_RESULT	(*reg_task)(THEE h, THEE* hh_task,stx_base_plugin* plug,u32 i_flag);\
	_STX_PURE   void		(*unreg_task)( THEE h, THEE h_task );\
	_STX_PURE   void		(*reset_task)( THEE h, THEE h_task,u32 i_flags, s64 i_start_time );\
	_STX_PURE	STX_RESULT	(*reg_subtask)\
	(THEE h, THEE h_main,s32 i_subtask,THEE h_subtask[],u32 i_stack_size);\
	_STX_PURE   void		(*unreg_subtask)( THEE h, THEE h_main );\
	_STX_PURE   void		(*set_task_events)( THEE h, THEE h_task,u32 i_events );\
	_STX_PURE   u32			(*get_task_events)( THEE h, THEE h_task);\
	_STX_PURE   s32         (*get_task_num)(THEE h);\
	_STX_PURE   b32         (*is_started)(THEE h);\
	_STX_PURE   s64         (*get_last_task_time)(THEE h);\
	_STX_PURE   char*       (*get_last_task_name)(THEE h);\
	_STX_PURE	STX_RESULT	(*reg_task_ex)(THEE h, THEE* hh_task,stx_base_plugin* plug,u32 i_flag,u32 i_stack_size);\
	_STX_PURE	STX_RESULT	(*xsleep)(THEE h, THEE h_task,u64 usec);\
	_STX_PURE	STX_RESULT	(*xwait)(THEE h, THEE h_task,u64 usec);\
	_STX_PURE	STX_RESULT	(*xresume)(THEE h, THEE h_task);\
	_STX_PURE	stx_sync_source* (*task2ssrc)(THEE h, THEE h_task);\

struct stx_sync_source{
	stx_sync_source_vtdef()
};

/*{{{**********************************************************************/
#define stx_sync_source_funcdecl(PREFIX) \
	async_plugin_funcdecl(PREFIX ## _asy);\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## reg_task(THEE h, THEE* hh_task,stx_base_plugin* plug,u32 i_flag);\
	STX_PURE void		PREFIX ## _xxx_ ## unreg_task(THEE h, THEE h_task );\
	STX_PURE void		PREFIX ## _xxx_ ## reset_task(THEE h, THEE h_task,u32 i_flags, s64 i_start_time );\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## reg_subtask\
	(THEE h,THEE h_main,s32 i_subtask,THEE h_subtask[],u32 i_stack_size);\
	STX_PURE void		PREFIX ## _xxx_ ## unreg_subtask( THEE h, THEE h_main );\
	STX_PURE void		PREFIX ## _xxx_ ## set_task_events( THEE h, THEE h_task,u32 i_events );\
	STX_PURE u32		PREFIX ## _xxx_ ## get_task_events( THEE h, THEE h_task);\
	STX_PURE s32        PREFIX ## _xxx_ ## get_task_num(THEE h);\
	STX_PURE b32        PREFIX ## _xxx_ ## is_started(THEE h);\
	STX_PURE s64        PREFIX ## _xxx_ ## get_last_task_time(THEE h);\
	STX_PURE char*      PREFIX ## _xxx_ ## get_last_task_name(THEE h);\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## reg_task_ex\
	(THEE h, THEE* hh_task,stx_base_plugin* plug,u32 i_flag,u32 i_stack_size);\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## xsleep(THEE h, THEE h_task,u64 usec);\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## xwait(THEE h, THEE h_task,u64 usec);\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## xresume(THEE h, THEE h_task);\
	STX_PURE stx_sync_source*	PREFIX ## _xxx_ ## task2ssrc(THEE h, THEE h_task);\

#define stx_sync_source_vtinit(vt,PREFIX) \
	STX_VT_INIT(vt,PREFIX,reg_task);\
	STX_VT_INIT(vt,PREFIX,unreg_task);\
	STX_VT_INIT(vt,PREFIX,reset_task);\
	STX_VT_INIT(vt,PREFIX,reg_subtask);\
	STX_VT_INIT(vt,PREFIX,unreg_subtask);\
	STX_VT_INIT(vt,PREFIX,set_task_events);\
	STX_VT_INIT(vt,PREFIX,get_task_events);\
	STX_VT_INIT(vt,PREFIX,get_task_num);\
	STX_VT_INIT(vt,PREFIX,is_started);\
	STX_VT_INIT(vt,PREFIX,get_last_task_time);\
	STX_VT_INIT(vt,PREFIX,get_last_task_name);\
	STX_VT_INIT(vt,PREFIX,reg_task_ex);\
	STX_VT_INIT(vt,PREFIX,xsleep);\
	STX_VT_INIT(vt,PREFIX,xwait);\
	STX_VT_INIT(vt,PREFIX,xresume);\
	STX_VT_INIT(vt,PREFIX,task2ssrc);\



#define stx_sync_source_data_default()			\
	async_plugin_data_default()

#define stx_sync_source_funcimp_default(SCOM,PREFIX)			\
	async_plugin_funcimp_default(SCOM,PREFIX ## _asy )\

#define stx_sync_source_create_default(vt,PREFIX,CLS,CAT,NAME)		\
	async_plugin_create_default(vt,PREFIX ## _asy,CLS,CAT,NAME); \
	stx_sync_source_vtinit(vt,PREFIX)

#define stx_sync_source_release_default(SCOM)			\
	async_plugin_release_default(SCOM)\

#define stx_sync_source_release_begin(SCOM)			\
	async_plugin_release_begin(SCOM)\

#define stx_sync_source_release_end(SCOM)			\
	async_plugin_release_end(SCOM)\

#define stx_sync_source_query_default(SCOM,vt)			\
	if( IS_EQUAL_GID(gid,STX_IID_SyncSource ) ) {\
		the->i_ref ++;\
		*pp_interf = (void*)&vt;\
		return STX_OK;\
	}\
	async_plugin_query_default(SCOM,vt)\


/*}}}**********************************************************************/



#if defined( __cplusplus )
}
#endif



#endif /* __STX_ASYNC_PLUGIN_H__ */ 

