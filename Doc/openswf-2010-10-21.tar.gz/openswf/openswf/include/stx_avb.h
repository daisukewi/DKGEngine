/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-06
***********************************************************************************/
#ifndef __STX_AVB_H__
#define __STX_AVB_H__


#include "stx_base_type.h"
#include "stx_gid_def.h"
#include "stx_io.h"


#if defined( __cplusplus )
extern "C" {
#endif



	enum LxAvbStreamType{
		LXAVB_STREAM_TYPE_ERR,  //0
		LXAVB_STREAM_TYPE_PES,  //0
		LXAVB_STREAM_TYPE_TS ,  //10
		LXAVB_STREAM_TYPE_AVI,  //20
		LXAVB_STREAM_TYPE_WMV,  //30
		LXAVB_STREAM_TYPE_MOV,  //40
		LXAVB_STREAM_TYPE_RMV,  //50
	};


#define  gidLxAvbHdr MEDIASUBTYPE_Avb
	// {4845655A-00CC-4d4a-8A52-A07013935F00}
	//DECLARE_XGUID( MEDIASUBTYPE_Avb,//gidLxAvbHdr,
	//0x4845655a, 0xcc, 0x4d4a, 0x8a, 0x52, 0xa0, 0x70, 0x13, 0x93, 0x5f, 0x0 );

	// {820DE6D6-BB4A-40ba-ACD6-E49F6EF4B356}
	DECLARE_XGUID( gidLxAvbStmLst , 
	0x820de6d6, 0xbb4a, 0x40ba, 0xac, 0xd6, 0xe4, 0x9f, 0x6e, 0xf4, 0xb3, 0x56 );

	// {5BD4DBF8-C915-4975-B6EB-6FC4C2EBAF02}
	DECLARE_XGUID( gidLxAvbVidHdr , 
	0x5bd4dbf8, 0xc915, 0x4975, 0xb6, 0xeb, 0x6f, 0xc4, 0xc2, 0xeb, 0xaf, 0x2 );

	// {ED6BC208-15CE-4ee9-AC4B-8A21D48C6325}
	DECLARE_XGUID( gidLxAvbAudHdr , 
	0xed6bc208, 0x15ce, 0x4ee9, 0xac, 0x4b, 0x8a, 0x21, 0xd4, 0x8c, 0x63, 0x25 );

	// {E914B749-4A4E-4d60-9537-FE59A3D01427}
	DECLARE_XGUID( gidLxAvbStmFrm , 
	0xe914b749, 0x4a4e, 0x4d60, 0x95, 0x37, 0xfe, 0x59, 0xa3, 0xd0, 0x14, 0x27 );

	// {CD34CF33-FAAC-4e37-9A6F-107B934A335F}
	DECLARE_XGUID( gidLxAvbVidFrm ,
	0xcd34cf33, 0xfaac, 0x4e37, 0x9a, 0x6f, 0x10, 0x7b, 0x93, 0x4a, 0x33, 0x5f );

	// {7BA7CD4C-AC8D-4218-BF17-B09E6FC6FEDA}
	DECLARE_XGUID( gidLxAvbAudFrm,
	0x7ba7cd4c, 0xac8d, 0x4218, 0xbf, 0x17, 0xb0, 0x9e, 0x6f, 0xc6, 0xfe, 0xda );


	// {DDBD783B-531F-4baa-892C-98807C5E0802}
	DECLARE_XGUID( gidLxAvbIdx,
	0xddbd783b, 0x531f, 0x4baa, 0x89, 0x2c, 0x98, 0x80, 0x7c, 0x5e, 0x8, 0x2 );

	// {26DEC693-6F6F-4f5c-AB11-30F4D8958DE7}
	DECLARE_XGUID( gidLxAvbNameIdx, 
	0x26dec693, 0x6f6f, 0x4f5c, 0xab, 0x11, 0x30, 0xf4, 0xd8, 0x95, 0x8d, 0xe7 );

	// {27E2D904-36FF-493e-BDA4-878508D4B314}
	DECLARE_XGUID( gidLxAvbPci, 
	0x27e2d904, 0x36ff, 0x493e,0xbd, 0xa4, 0x87, 0x85, 0x8, 0xd4, 0xb3, 0x14 );

	// {66834595-3D54-4723-974C-D9A527A85101}
	DECLARE_XGUID( gidLxAvbSub ,
	0x66834595, 0x3d54, 0x4723,0x97, 0x4c, 0xd9, 0xa5, 0x27, 0xa8, 0x51, 0x1 );

	// {F191D6B7-71C8-4dc6-AE35-239162C8E6F5}
	DECLARE_XGUID( gidLxAvbFrm,
	0xf191d6b7, 0x71c8, 0x4dc6, 0xae, 0x35, 0x23, 0x91, 0x62, 0xc8, 0xe6, 0xf5 );


	// {972F1417-2C0E-4a9c-ABC9-CF102D51ADB6}
	DECLARE_XGUID( gidLxAvbContainer, 
	0x972f1417, 0x2c0e, 0x4a9c, 0xab, 0xc9, 0xcf, 0x10, 0x2d, 0x51, 0xad, 0xb6 );

	// {05FCD232-10B4-45f2-81BD-371748D294B4}
	DECLARE_XGUID( gidLxAvbMpeg2_Ps ,
	0x5fcd232, 0x10b4, 0x45f2, 0x81, 0xbd, 0x37, 0x17, 0x48, 0xd2, 0x94, 0xb4 );

	// {523FA7B4-BA76-467c-A753-7B39111BEF6E}
	DECLARE_XGUID( gidLxAvbMpeg2_Ts ,
	0x523fa7b4, 0xba76, 0x467c, 0xa7, 0x53, 0x7b, 0x39, 0x11, 0x1b, 0xef, 0x6e );

	// {C06200FE-55EA-4acd-801D-BE20A6F3C6E7}
	DECLARE_XGUID( gidLxAvbWmv ,
	0xc06200fe, 0x55ea, 0x4acd, 0x80, 0x1d, 0xbe, 0x20, 0xa6, 0xf3, 0xc6, 0xe7 );

	// {366FB285-A7C9-4ad4-968B-66AA782FE725}
	DECLARE_XGUID( gidLxAvbAvi ,
	0x366fb285, 0xa7c9, 0x4ad4, 0x96, 0x8b, 0x66, 0xaa, 0x78, 0x2f, 0xe7, 0x25 );

	// {62F06FE7-EB7A-4d54-AA9F-089326B4E62B}
	DECLARE_XGUID( gidLxAvbInterleave ,
	0x62f06fe7, 0xeb7a, 0x4d54, 0xaa, 0x9f, 0x8, 0x93, 0x26, 0xb4, 0xe6, 0x2b );


	/*
	enum LxAvbAtomType{
	gidLxAvbHdr    = 1,
	gidLxAvbVidHdr ,   // videoinfo2;
	gidLxAvbAudHdr ,   // WAVEFORMATEX;
	gidLxAvbVidFrm ,   // video frame;
	gidLxAvbAudFrm ,   // audio frame;
	gidLxAvbIdx    ,   // IDX set;
	gidLxAvbPci    ,   // PCI set;
	gidLxAvbContainer ,   // used in XML set;

	gidLxAvbMpeg2_Ps,  // videoinfo2, WAVEFORMATEX and extension data;
	gidLxAvbMpeg2_Ts,  // videoinfo2, WAVEFORMATEX and extension data;
	gidLxAvbWmv,       // WMV header;
	gidLxAvbAvi,       // AVI header;
	};

	as for system stream(PS,WMV,AVI), the stream list content is need to be defined;

	now we only use the atom guid to identify the stream type;

	*/


	/////////////////////////////////////////////////////////////////<<
	typedef struct LxAvbAtom{
		stx_gid        gid;          // 16
		s64            qwAtomSize;   // 8
	}LxAvbAtom;

#define LXAVB_ATOM_HDR_SIZE() 24

	static  STX_RESULT LxAvbWriteAtomHdr(stx_xio* hFile,LxAvbAtom* pAtom)
	{
		size_t dwWrite;
		return hFile->write(hFile,pAtom,LXAVB_ATOM_HDR_SIZE(),&dwWrite);
	}
	/////////////////////////////////////////////////////////////////>>



	//////////////////////////////////////////////////////////////////<<
#define LXAVB_HDR_TAG         MKTAG('X','L','I','V')
#define LXAVB_VERSION         1

#define LXAVB_SHARE           1        // each segment is a file, fix length;
#define LXAVB_STREAM          (1<<1)   // playable file, fix length;
#define LXAVB_PROGRAM         (1<<2)   // short segment, fix length;
#define LXAVB_LIVE            (1<<3)   // short segment, live;

#define LXAVB_HAVE_SYS        (1<<15)  // play control, system block;
#define LXAVB_HAVE_IDX        (1<<16)  // frame search index block;
#define LXAVB_HAVE_IDX_NAME   (1<<17)  // segment name index block, after the IDX block;
#define LXAVB_HAVE_PCI        (1<<18)  // play control, navigator block;
#define LXAVB_HAVE_SUB        (1<<19)  // subtitle block;

	typedef struct LxAvbHdr {

		u32       dwAvbTag;        // mmioFourcc("XLIV")
		u32       dwAvbVer;        //
		u32       dwHdrSize;       // sizeof(LxAvbHdr)	
		u32       dwFlags;
		u32       dwMaxBufSize;    // bytes; zero means dynamic;	
		u32       dwStreamNum;     // the total streams number;

		s64       qwTotalSegment;  // the total segment number;
		s64       qwTotalTime;     // milisecond;	
		s64       qwFrmPos;        // frame start position;
		s64       qwLstPos;        // stream list position;	
		s64       qwIdxPos;        // IDX position;
		s64       qwPciPos;        // PCI position;

	}LxAvbHdr;

#define LXAVB_HDR_SIZE()  72

	//////////////////////////////////////////////////////////////////>>



	//////////////////////////////////////////////////////////////////<<
#define LXAVB_HDR_PRI       1        // first stream choice;
#define LXAVB_HDR_SUBTITLE  (1<<1)   // if it is a video subtitle;

	typedef struct LxAvbAtomVidHdr{
		u32            dwFlags;  // LXAVB_HDR_PRI
		u32            dwPack;
		STX_VIDEOINFOHEADER2 vdr;
	}LxAvbAtomVidHdr;
#define LxAvbAtomVidHdr_size()  8
	//////////////////////////////////////////////////////////////////>>


	//////////////////////////////////////////////////////////////////<<
	typedef struct LxAvbAtomAudHdr{
		u32					dwFlags;  // LXAVB_HDR_PRI
		u32					dwPack;
		STX_WAVEFORMATEX    adr;
	}LxAvbAtomAudHdr;
#define LxAvbAtomAudHdr_size() 8
	//////////////////////////////////////////////////////////////////>>


	//////////////////////////////////////////////////////////////////<<
#define LXAVB_KEY_FRAME  1

	typedef struct LxAvbFrmHdr{
		u32            dwFcc;
		u32            dwFlags;

		// this member enables multi audio stream, subtitle features;
		u32            dwStmNum;  
		u32            dwDataLen;    // 16;

		s64            qwTimeCode;   // milisecond * 10000;

	}LxAvbFrmHdr;

#define LxAvbAtomFrm_HdrSize() 24


	static  STX_RESULT LxAvbWriteFrmHdr(stx_xio* hFile,LxAvbFrmHdr* pHdr)
	{
		size_t dwWrite;
		return hFile->write(hFile,pHdr,LxAvbAtomFrm_HdrSize(),&dwWrite);
	}

	typedef struct LxAvbStmFrmHdr{
		u32            dwFlags;
		u32            dwDataLen;    // 20;
		s64            qwTimeCode;   // milisecond * 1000;
	}LxAvbStmFrmHdr;

#define LxAvbAtomStmFrm_HdrSize() 16

	static  STX_RESULT LxAvbWriteStmFrmHdr(stx_xio* hFile,LxAvbStmFrmHdr* pHdr)
	{
		size_t dwWrite;
		return hFile->write(hFile,pHdr,LxAvbAtomStmFrm_HdrSize(),&dwWrite);
	}
	//////////////////////////////////////////////////////////////////>>


	typedef  struct LxAvbIdxItem{
		u32    dwStmNum;          // stream number;
		u32    dwFlags;           // if is key frame; etc;

		s64    qwSegId;           //
		s64    qwFrmSize;         //
		s64    qwTimeCode;        // start time code;  32
		s64    qwDurationTime;    // segment duration time;
		s64    qwFrmPos;          // 48
		s64    qwNameStrPos;      // if have segment name string, the address from end of IDX end;

		s64    qwPad;             // 64;
	}LxAvbIdxItem;

#define LXAVB_IDXITEM_SIZE 0x40


	// this struct not packing;
	typedef struct LxAvbSegName{
		u16 wSize;    // strlen(name) + 2;
		u8  name[2];  // variable length;
	}LxAvbSegName;
	//>>


	typedef struct LxP2PStreamInf {
		stx_gid             gidCreate;

#define STREAM_SEGMENT    1
#define STREAM_SLICE      2
#define STREAM_COMPLETED  4
		u32                 dwFlags;

		char*               szName;           // segment name;
		s32                 nSegId;           // segment id or slice id;
		s64                 qwSegStartTime;   // must be 64 bits;
		s64                 qwSegDuraTime;    // could be large file;
		s64                 qwSegSize;        // segment size or slice size;
		u32                 dwBlockSize;      // constant in same version;
		u32                 dwTotalBlock;     // 
	}LxP2PStreamInf;



	STX_API STX_RESULT   AvbEncOpen(STX_HANDLE* pHnd,const char* szName,u32 dwFlags);
	STX_API STX_RESULT   AvbEncClose(STX_HANDLE h);
	STX_API STX_RESULT   AvbCreateStream(STX_HANDLE h,s32* pnStmNum,LxAvbAtom* pFormatHdr);
	STX_API STX_RESULT   AvbWriteStream(
		STX_HANDLE h,s32 nStmNum,u8* pData,s32 nDataLen,LxP2PStreamInf* pInf);

	STX_API STX_RESULT   AvbDecOpen(STX_HANDLE* pHnd,const char* szName);
	STX_API STX_RESULT   AvbDecClose(STX_HANDLE h);
	STX_API STX_RESULT   AvbDecGetHdr(STX_HANDLE h,LxAvbHdr* pHdr);
	STX_API STX_RESULT   AvbDecGetVidFmt(STX_HANDLE h,LxAvbAtomVidHdr* pVidHdr);
	STX_API STX_RESULT   AvbDecGetAudFmt(STX_HANDLE h,LxAvbAtomAudHdr* pAudHdr);
	STX_API STX_RESULT   AvbDecSetTime(STX_HANDLE h,s64 qwTime);

	STX_API STX_RESULT   AvbRead
	(
		STX_HANDLE	h,
		void*		pData,
		size_t		nDataSize
	);



#if defined( __cplusplus )
}
#endif

#endif // __STX_AVB_H__