/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/
#ifndef __STX_MEDIA_TYPE_BASE_H__
#define __STX_MEDIA_TYPE_BASE_H__


#include "base_class.h"


// media type binary header: written behind the vd2 or wex;

#define tag_MP3H			MKTAG('m','p','3','h')		// mpeg audio sync layer 1/2/3
#define tag_AC3H			MKTAG('a','c','3','h')		// ac3 sync header
#define tag_ADTS			MKTAG('a','d','t','s')		// aac sync header
#define tag_ASCF            MKTAG('a','s','c','f')		// MPEG4 audio config AudioSpecificConfig
#define tag_LATM            MKTAG('l','a','t','m')		// MPEG4 audio config latm;

#define tag_SEQ2			MKTAG('s','e','q','2')		// mpeg 1/2 video

#define tag_SREC            MKTAG('s','r','e','c')		// frame size: source rect;
#define tag_DREC            MKTAG('d','r','e','c')		// clip rect
#define tag_M4VH            MKTAG('m','4','v','h')		// MPEG4 video config;     

#define tag_PFID			MKTAG('p','f','i','d')		// profile level id;
#define tag_SPS				MKTAG(' ','s','p','s')		// h264 sps;



#if defined( __cplusplus )
extern "C" {
#endif


	typedef struct base_media_type  base_media_type;

#ifdef __USE_STX_DEBUG__
	stx_media_type* create_base_media_type(THEE hinst,const char* file,s32 line,stx_media_type* p_mtyp);
#else
	stx_media_type* create_base_media_type(THEE hinst,stx_media_type* p_mtyp);
#endif


#if defined( __cplusplus )
}
#endif


#endif /* __STX_MEDIA_TYPE_BASE_H__ */ 