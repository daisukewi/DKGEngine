/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#ifndef __STX_GETOPT_H__
#define __STX_GETOPT_H__


#include "stx_base_type.h"


#if defined( __cplusplus )
extern "C" {
#endif

	THEE	create_opt(s32 argc, char *argv[], const char *optList);
	s32		get_opt(THEE h);
	char*	get_optarg(THEE h);
	char*	get_opterr(THEE h);
	void	close_opt(THEE h);



#if defined( __cplusplus )
}
#endif


#endif // __STX_GETOPT_H__