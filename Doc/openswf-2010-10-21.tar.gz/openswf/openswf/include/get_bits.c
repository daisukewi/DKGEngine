/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-06
***********************************************************************************/


#ifdef __GET_BITS_INC__

#include "stx_cpuid.h"


#ifdef __USE_STX_DEBUG__
static const char __T_THIS_FILE__[] = __FILE__;
#define __THIS_FILE__  __T_THIS_FILE__
#endif

#ifdef __WIN32_LIB
#	define bswap_16 _byteswap_ushort
#	define bswap_32 _byteswap_ulong
#	define bswap_64 _byteswap_uint64
#else
#	define bswap_16 __builtin_bswap16
#	define bswap_32 __builtin_bswap32
#	define bswap_64 __builtin_bswap64
#endif


#ifdef HAVE_MMX

#if 0

#ifdef __LINUX_LIB
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
#	ifdef STX64
stx_inline u32 stx_show_bits(stx_bits_window* lpCurBitsWin,s32 n)
{
	__m128i mmbshr,mmb10;

	mmbshr = _mm_cvtsi32_si128( 64 - n );
	mmb10 = _mm_loadl_epi64( CONV_PXMMI( &lpCurBitsWin->nBits0 ));
	mmb10 = _mm_srl_epi64(mmb10,mmbshr);
	return (u32) _mm_cvtsi128_si32(mmb10);
}
#	else
stx_inline u32 stx_show_bits(stx_bits_window* lpCurBitsWin,s32 n)
{
	u32 i_re;
	__m64 mmbshr,mmb10;

	mmbshr = _m_from_int( 64 - n );
	mmb10 = *CONV_PM64(&lpCurBitsWin->nBits0);
	mmb10 = _m_psrlq(mmb10,mmbshr);
	i_re = (u32)_m_to_int(mmb10);
	_m_empty();
	return i_re;
}
#	endif //STX64
#endif // #ifdef __LINUX_LIB
#endif // 0



#ifdef STX64

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
#define stx_clear_bytes(lpCurBitsWin)\
{\
	__m128i ix0,ix1,ix2,ix3;\
	s32 const i_bits = lpCurBitsWin->nRemainedBytes * 8;\
	ix0 = _mm_cvtsi32_si128( bswap_32( *(s32*)lpCurBitsWin->Bytes3) );\
	ix1 = _mm_cvtsi32_si128( 32 - i_bits );\
	ix3 = _mm_cvtsi32_si128( 32 - lpCurBitsWin->nCurrentBit );\
	ix0 = _mm_srl_epi64(ix0,ix1);\
	lpCurBitsWin->nCurrentBit += i_bits;\
	ix0 = _mm_sll_epi64(ix0,ix1);\
	ix2 = _mm_loadl_epi64( (__m128i*)&lpCurBitsWin->nBits0 );\
	ix0 = _mm_sll_epi64(ix0,ix3);\
	lpCurBitsWin->nRemainedBytes = 0;\
	ix0 = _mm_or_si128(ix0,ix2);\
	_mm_storel_epi64((__m128i*)&lpCurBitsWin->nBits0,ix0);\
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

stx_inline void 
stx_flush_bits(stx_bits_window* lpCurBitsWin,s32 n)
{
	__m128i mmbshl,mmb10,mmb32;

	mmbshl = _mm_cvtsi32_si128( n );
	mmb10 = _mm_loadl_epi64( (__m128i*)&lpCurBitsWin->nBits0 );
	lpCurBitsWin->nCurrentBit -= n;
	mmb10 = _mm_sll_epi64(mmb10,mmbshl);
	_mm_storel_epi64((__m128i*)&lpCurBitsWin->nBits0,mmb10);

	if( lpCurBitsWin->nCurrentBit < LEASTBITS ) {

		if( lpCurBitsWin->nTotalBytes > 0 ) {

			mmb32 = _mm_cvtsi32_si128( _byteswap_ulong( *(s32*)lpCurBitsWin->lpCurrentByte) );
			lpCurBitsWin->nTotalBytes -= 4;
			mmbshl = _mm_cvtsi32_si128( 32 - lpCurBitsWin->nCurrentBit );
			lpCurBitsWin->lpCurrentByte += 4;
			mmb32 = _mm_sll_epi64(mmb32,mmbshl);
			lpCurBitsWin->nCurrentBit += 32;
			mmb32 = _mm_or_si128(mmb32,mmb10);
			_mm_storel_epi64((__m128i*)&lpCurBitsWin->nBits0,mmb32);

		}
		else {

			stx_clear_bytes(lpCurBitsWin);
		}
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

stx_inline u32 
stx_get_bits(stx_bits_window* lpCurBitsWin,s32 n)
{
	__m128i mmbshl,mmbshr,mmbre,mmb10,mmb32;

	u32 i_re;

	mmbshl = _mm_cvtsi32_si128( n );
	mmb10 = _mm_loadl_epi64( (__m128i*)&lpCurBitsWin->nBits0 );
	lpCurBitsWin->nCurrentBit -= n;
	mmbre = mmb10;
	mmbshr = _mm_cvtsi32_si128( 64 - n );
	mmb10 = _mm_sll_epi64(mmb10,mmbshl);
	mmbre = _mm_srl_epi64(mmbre,mmbshr);
	_mm_storel_epi64((__m128i*)&lpCurBitsWin->nBits0,mmb10);
	i_re = _mm_cvtsi128_si32(mmbre);

	if( lpCurBitsWin->nCurrentBit < LEASTBITS ) {

		if( lpCurBitsWin->nTotalBytes > 0 ) {

			mmb32 = _mm_cvtsi32_si128( bswap_32( *(s32*)lpCurBitsWin->lpCurrentByte) );
			lpCurBitsWin->nTotalBytes -= 4;
			mmbshl = _mm_cvtsi32_si128( 32 - lpCurBitsWin->nCurrentBit );
			lpCurBitsWin->lpCurrentByte += 4;
			mmb32 = _mm_sll_epi64(mmb32,mmbshl);
			lpCurBitsWin->nCurrentBit += 32;
			mmb32 = _mm_or_si128(mmb32,mmb10);
			_mm_storel_epi64((__m128i*)&lpCurBitsWin->nBits0,mmb32);

		}
		else {

			stx_clear_bytes(lpCurBitsWin);
		}
	}

	return i_re;
}

#else

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
#define stx_clear_bytes(lpCurBitsWin)\
{\
	__m64 ix0,ix1,ix2,ix3;\
	s32 const i_bits = lpCurBitsWin->nRemainedBytes * 8;\
	ix0 = _m_from_int( bswap_32( *(s32*)lpCurBitsWin->Bytes3) );\
	ix1 = _m_from_int( 32 - i_bits );\
	ix3 = _m_from_int( 32 - lpCurBitsWin->nCurrentBit );\
	ix0 = _m_psrlq(ix0,ix1);\
	lpCurBitsWin->nCurrentBit += i_bits;\
	ix0 = _m_psllq(ix0,ix1);\
	ix2 = *CONV_PM64(&lpCurBitsWin->nBits0 );\
	ix0 = _m_psllq(ix0,ix3);\
	lpCurBitsWin->nRemainedBytes = 0;\
	ix0 = _m_por(ix0,ix2);\
	*CONV_PM64(&lpCurBitsWin->nBits0) = ix0;\
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
stx_inline void 
stx_flush_bits(stx_bits_window* lpCurBitsWin,s32 n)
{
	__m64 mmbshl,mmb10,mmb32;

	mmbshl = _m_from_int( n );
	mmb10 = *CONV_PM64( &lpCurBitsWin->nBits0 );
	lpCurBitsWin->nCurrentBit -= n;
	mmb10 = _m_psllq(mmb10,mmbshl);
	*CONV_PM64(&lpCurBitsWin->nBits0) = mmb10;

	if( lpCurBitsWin->nCurrentBit < LEASTBITS ) {
		if( lpCurBitsWin->nTotalBytes > 0 ) {
			mmb32 = _m_from_int( bswap_32( *(s32*)lpCurBitsWin->lpCurrentByte) );
			lpCurBitsWin->nTotalBytes -= 4;
			mmbshl = _m_from_int( 32 - lpCurBitsWin->nCurrentBit );
			lpCurBitsWin->lpCurrentByte += 4;
			mmb32 = _m_psllq(mmb32,mmbshl);
			lpCurBitsWin->nCurrentBit += 32;
			*CONV_PM64(&lpCurBitsWin->nBits0) = _m_por(mmb32,mmb10);
		}
		else{
			stx_clear_bytes(lpCurBitsWin);
		}
	}
	_m_empty();
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
stx_inline u32 stx_get_bits(stx_bits_window* lpCurBitsWin,s32 n)
{
	__m64 mmbshl,mmbshr,mmbre,mmb10,mmb32;

	u32 i_re;

	mmbshl = _m_from_int( n );
	mmb10 = *CONV_PM64( &lpCurBitsWin->nBits0 );
	lpCurBitsWin->nCurrentBit -= n;
	mmbre = mmb10;
	mmbshr = _m_from_int( 64 - n );
	mmb10 = _m_psllq(mmb10,mmbshl);
	mmbre = _m_psrlq(mmbre,mmbshr);
	*CONV_PM64(&lpCurBitsWin->nBits0) = mmb10;
	i_re = _m_to_int(mmbre);

	if( lpCurBitsWin->nCurrentBit < LEASTBITS ) {
		if( lpCurBitsWin->nTotalBytes > 0 ) {
			mmb32 = _m_from_int( bswap_32( *(s32*)lpCurBitsWin->lpCurrentByte) );
			lpCurBitsWin->nTotalBytes -= 4;
			mmbshl = _m_from_int( 32 - lpCurBitsWin->nCurrentBit );
			lpCurBitsWin->lpCurrentByte += 4;
			mmb32 = _m_psllq(mmb32,mmbshl);
			lpCurBitsWin->nCurrentBit += 32;
			*CONV_PM64(&lpCurBitsWin->nBits0) = _m_por(mmb32,mmb10);
		}
		else{
			stx_clear_bytes(lpCurBitsWin);
		}
	}
	_m_empty();
	return i_re;
}

#endif // STX64


#else

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
#define stx_clear_bytes(lpCurBitsWin)\
{\
	s32 i;\
	for( i = 0; i < lpCurBitsWin->nRemainedBytes; i ++ ){\
		u32 iCode = lpCurBitsWin->Bytes3[i];\
		iCode <<= 24;\
		lpCurBitsWin->nBits1 |= ( iCode >> lpCurBitsWin->nCurrentBit );\
		if( lpCurBitsWin->nCurrentBit > 24  ){   \
			lpCurBitsWin->nBits0 = iCode << ( 32 - lpCurBitsWin->nCurrentBit );\
		}\
		lpCurBitsWin->nCurrentBit += 8;\
	}\
	lpCurBitsWin->nRemainedBytes = 0;\
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
stx_inline void 
stx_flush_bits(stx_bits_window* lpCurBitsWin,s32 n)
{
	if( n == 32 ) {
		lpCurBitsWin->nBits1 = lpCurBitsWin->nBits0;
		lpCurBitsWin->nBits0 = 0;
		lpCurBitsWin->nCurrentBit -= 32;
	}
	else if( n ) {
		lpCurBitsWin->nBits1 <<= n;
		if( lpCurBitsWin->nCurrentBit > 32 ){
			lpCurBitsWin->nBits1 |= ( lpCurBitsWin->nBits0 >> ( 32 - n ) );
			lpCurBitsWin->nBits0 <<= n;
		}
		lpCurBitsWin->nCurrentBit -= n;
	}

	if( lpCurBitsWin->nCurrentBit >= LEASTBITS ){
		return;
	}

	if( lpCurBitsWin->nTotalBytes > 0 ){
		u32 const dwTmp0 = bswap_32( *(s32*)lpCurBitsWin->lpCurrentByte);
		lpCurBitsWin->nBits1 |= ( dwTmp0 >> lpCurBitsWin->nCurrentBit );
		lpCurBitsWin->nBits0 = lpCurBitsWin->nCurrentBit ? ( dwTmp0 << ( 32 - lpCurBitsWin->nCurrentBit) ) : 0;
		lpCurBitsWin->lpCurrentByte += 4;
		lpCurBitsWin->nTotalBytes -= 4;
		lpCurBitsWin->nCurrentBit += 32;
		return;
	}

	stx_clear_bytes(lpCurBitsWin);
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
stx_inline u32 stx_get_bits(stx_bits_window* lpCurBitsWin,s32 n)
{
	u32 dwCode = 0;

	if( n == 32 ) {
		dwCode = lpCurBitsWin->nBits1;
		lpCurBitsWin->nBits1 = lpCurBitsWin->nBits0;
		lpCurBitsWin->nBits0 = 0;
		lpCurBitsWin->nCurrentBit -= 32;
	}
	else if( n ) {
		dwCode = lpCurBitsWin->nBits1 >> ( 32 - n );
		lpCurBitsWin->nBits1 <<= n;
		if( lpCurBitsWin->nCurrentBit > 32 ){
			lpCurBitsWin->nBits1 |= ( lpCurBitsWin->nBits0 >> ( 32 - n ) );
			lpCurBitsWin->nBits0 <<= n;
		}
		lpCurBitsWin->nCurrentBit -= n;
	}


	if( lpCurBitsWin->nCurrentBit >= LEASTBITS ){
		return dwCode;
	}

	if( lpCurBitsWin->nTotalBytes > 0 ){
		u32 const dwTmp0 = bswap_32( *(s32*)lpCurBitsWin->lpCurrentByte);
		lpCurBitsWin->nBits1 |= ( dwTmp0 >> lpCurBitsWin->nCurrentBit );
		lpCurBitsWin->nBits0 = lpCurBitsWin->nCurrentBit ? ( dwTmp0 << ( 32 - lpCurBitsWin->nCurrentBit) ) : 0;
		lpCurBitsWin->lpCurrentByte += 4;
		lpCurBitsWin->nTotalBytes -= 4;
		lpCurBitsWin->nCurrentBit += 32;
		return dwCode;
	}

	stx_clear_bytes(lpCurBitsWin);
	return dwCode;
}


#endif // HAVE_MMX



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

stx_inline s32 
stx_get_xbits(stx_bits_window* lpCurBitsWin,s32 n)
{
	s32 const cache = lpCurBitsWin->nBits1;

	s32 const sign = (~cache) >> 31;

	s32 const re32 = ( ( ( sign ^ cache) >> ( 32 - n ) ) ^ sign ) - sign;

	stx_flush_bits(lpCurBitsWin,n);

	return re32;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

stx_inline s32 
stx_get_sbits(stx_bits_window* lpCurBitsWin,s32 n)
{
	s32 re = (s32)stx_get_bits(lpCurBitsWin,n);

	s32 const sh = 32 - n;

	return ( re << sh ) >> sh;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

stx_inline s32 
stx_get_bits_count(stx_bits_window *the)
{
	if( the->nTotalBytes > 0 ) {

		return ( the->nTotalBytes + the->nRemainedBytes) * 8 + the->nCurrentBit;
	}

	return the->nRemainedBytes *8 + the->nCurrentBit;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
stx_inline STX_RESULT 
stx_set_bits_buffer(stx_bits_window *the,s32 i_size)
{
	if( the->nBufferSize < i_size ) {
		if( the->lpBitsPool ) {
			xlivFree( the->lpBitsPool );
		}
		the->lpBitsPool = (u8*)xlivAlloc(i_size+2048,0,16);
		if( !the->lpBitsPool ) {
			return STX_FAIL;
		}
		the->nBufferSize = i_size+2048;
	}
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
stx_inline STX_RESULT 
stx_init_get_bits_inplace(stx_bits_window *the,s32 bit_size)
{
	s32 i;

	s32 const nBytes = ( bit_size + 7 ) / 8;
	s32 const ba = nBytes & ~3;

	the->lpCurrentByte = the->lpBitsPool;
	the->lpBitsEnd = the->lpBitsPool + nBytes;
	the->nTotalBytes = ba;
	the->nRemainedBytes = nBytes & 3;

	if( the->nRemainedBytes ) {
		for( i = 0; i < the->nRemainedBytes; i ++ ) {
			the->Bytes3[i] = the->lpBitsPool[ ba + i ];
		}
	}

	the->size_in_bits = bit_size;
	the->nBits0 = 0;
	the->nBits1 = 0;
	the->nCurrentBit = 0;
	stx_get_bits(the,0);

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
stx_inline STX_RESULT 
stx_init_get_bits( stx_bits_window *the, u8 *buffer, s32 bit_size)
{
	s32 i;

	s32 const nBytes = ( bit_size + 7 ) / 8;

	if( the->nBufferSize < nBytes ) {
		if( the->lpBitsPool ) {
			xlivFree( the->lpBitsPool );
		}
		the->lpBitsPool = (u8*)xlivAlloc(nBytes+2048,0,16);
		if( !the->lpBitsPool ) {
			return STX_FAIL;
		}
		the->nBufferSize = nBytes+2048;
	}

	memcpy( the->lpBitsPool, buffer, nBytes);
	the->lpCurrentByte = the->lpBitsPool;
	the->lpBitsEnd = the->lpBitsPool + nBytes;
	the->nTotalBytes = nBytes & ~3;
	the->nRemainedBytes = nBytes & 3;

	if( the->nRemainedBytes ) {
		s32 const ba = nBytes & ~3;
		for( i = 0; i < the->nRemainedBytes; i ++ ) {
			the->Bytes3[i] = buffer[ ba + i ];
		}
	}

	the->size_in_bits = bit_size;
	the->nBits0 = 0;
	the->nBits1 = 0;
	the->nCurrentBit = 0;
	stx_get_bits(the,0);

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
stx_inline STX_RESULT 
stx_dup_get_bits(stx_bits_window *the,stx_bits_window* src)
{
	s32 i;

	if( the->nBufferSize < src->nBufferSize ) {
		if( the->lpBitsPool ) {
			xlivFree( the->lpBitsPool );
		}
		the->lpBitsPool = (u8*)xlivAlloc(src->nBufferSize+16,0,16);
		if( !the->lpBitsPool ) {
			return STX_FAIL;
		}
		the->nBufferSize = src->nBufferSize;
	} // if( the->nBufferSize < src->nBufferSize ) {

	memcpy( the->lpBitsPool, src->lpBitsPool, src->nBufferSize);
	the->lpCurrentByte = the->lpBitsPool + (src->lpCurrentByte - src->lpBitsPool);
	the->lpBitsEnd = the->lpBitsPool + (src->lpBitsEnd - src->lpBitsPool);
	the->nTotalBytes = src->nTotalBytes;
	the->nRemainedBytes = src->nRemainedBytes;

	for( i = 0; i < the->nRemainedBytes; i ++ ) {
		the->Bytes3[i] = src->Bytes3[i];
	}

	the->size_in_bits = src->size_in_bits;
	the->nBits0 = src->nBits0;
	the->nBits1 = src->nBits1;
	the->nCurrentBit = src->nCurrentBit;

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
stx_inline STX_RESULT 
stx_direct_get_bits( stx_bits_window *the, u8 *buffer, s32 bit_size)
{
	s32 i;

	s32 const nBytes = ( bit_size + 7 ) / 8;

	the->lpBitsPool = buffer;
	the->nBufferSize = nBytes;
	the->lpCurrentByte = the->lpBitsPool;
	the->lpBitsEnd = the->lpBitsPool + nBytes;
	the->nTotalBytes = nBytes & ~3;
	the->nRemainedBytes = nBytes & 3;

	if( the->nRemainedBytes ) {
		s32 const ba = nBytes & ~3;
		for( i = 0; i < the->nRemainedBytes; i ++ ) {
			the->Bytes3[i] = buffer[ ba + i ];
		}
	}

	the->size_in_bits = bit_size;
	the->nBits0 = 0;
	the->nBits1 = 0;
	the->nCurrentBit = 0;
	stx_get_bits(the,0);

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
**************************************************************************/
stx_inline void 
stx_free_get_bits(stx_bits_window *the )
{
	if( the->lpBitsPool ) {
		xlivFree(the->lpBitsPool);
		the->lpBitsPool = NULL;
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
stx_inline void 
stx_align_get_bits( stx_bits_window *the)
{
	s32 n =  the->nCurrentBit & 7;
	if( n ) {
		stx_flush_bits(the, n);
	}
}


#ifdef __USE_STX_DEBUG__
#undef __THIS_FILE__
#endif

#endif // __GET_BITS_INC__
