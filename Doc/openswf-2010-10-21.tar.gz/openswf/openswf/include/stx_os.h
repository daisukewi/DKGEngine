

#ifndef __STX_OS_H__
#define __STX_OS_H__

/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#include "stx_base_type.h"


#if defined( __cplusplus )
extern "C" {
#endif


STX_RESULT		stx_base_init( void (*dump_str)(char*), u32 i_flag );

void            stx_base_cleanup();

s64				stx_get_milisec();

s64				stx_get_microsec();

void			stx_sleep(u32 i_msec);

void			stx_usleep(u64 i_usec);

b32             stx_interrupted();

void            stx_set_interrupted();

s32             stx_get_cpu_num();



STX_HANDLE  stx_sync_create();

void		stx_sync_close(STX_HANDLE h);

void		stx_sync_wait(STX_HANDLE h, s64 i_microsec);



#ifdef __LINUX_LIB


#define FILE_ATTRIBUTE_READONLY             0x00000001  
#define FILE_ATTRIBUTE_HIDDEN               0x00000002  
#define FILE_ATTRIBUTE_SYSTEM               0x00000004  
#define FILE_ATTRIBUTE_DIRECTORY            0x00000010  
#define FILE_ATTRIBUTE_ARCHIVE              0x00000020  
#define FILE_ATTRIBUTE_DEVICE               0x00000040  
#define FILE_ATTRIBUTE_NORMAL               0x00000080  
#define FILE_ATTRIBUTE_TEMPORARY            0x00000100  
#define FILE_ATTRIBUTE_SPARSE_FILE          0x00000200  
#define FILE_ATTRIBUTE_REPARSE_POINT        0x00000400  
#define FILE_ATTRIBUTE_COMPRESSED           0x00000800  
#define FILE_ATTRIBUTE_OFFLINE              0x00001000  
#define FILE_ATTRIBUTE_NOT_CONTENT_INDEXED  0x00002000  
#define FILE_ATTRIBUTE_ENCRYPTED            0x00004000  
#define FILE_ATTRIBUTE_VIRTUAL              0x00010000  


typedef struct _FILETIME {
    u32 dwLowDateTime;
    u32 dwHighDateTime;
} FILETIME;


typedef struct _WIN32_FIND_DATAA
{
    u32 dwFileAttributes;
    FILETIME ftCreationTime;
    FILETIME ftLastAccessTime;
    FILETIME ftLastWriteTime;
    u32 nFileSizeHigh;
    u32 nFileSizeLow;
    u32 dwReserved0;
    u32 dwReserved1;
    s8 cFileName[ 260 ];
    s8 cAlternateFileName[ 14 ];
}WIN32_FIND_DATAA;


STX_HANDLE FindFirstFile(
    char* lpFileName,
    WIN32_FIND_DATAA* lpFindFileData );

b32 FindNextFile(
    STX_HANDLE hFindFile,
    WIN32_FIND_DATAA* lpFindFileData );

void FindClose(STX_HANDLE hFileFile);


char* stx_getcwd();



#endif


#if defined( __cplusplus )
}
#endif


#endif /*   __STX_OS_H__  */

