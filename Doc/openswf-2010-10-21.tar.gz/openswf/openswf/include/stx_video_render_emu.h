

#ifndef __STX_VIDEO_RENDER_EMU_H__
#define __STX_VIDEO_RENDER_EMU_H__

/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/


#include "stx_async_plugin.h"

#include "stx_gid_def.h"


#if defined( __cplusplus )
extern "C" {
#endif

/* {90A1CF7A-AAC4-40da-9F6A-3B5B7EB59BDF} */
DECLARE_XGUID( STX_CLSID_VideoRenderEmulator,
0x90a1cf7a, 0xaac4, 0x40da, 0x9f, 0x6a, 0x3b, 0x5b, 0x7e, 0xb5, 0x9b, 0xdf);

extern char* g_szStreamX_VideoRenderEmulator;

STX_API
STX_COM(video_render_emu);


#if defined( __cplusplus )
}
#endif


#endif /* __STX_VIDEO_RENDER_EMU_H__ */ 

