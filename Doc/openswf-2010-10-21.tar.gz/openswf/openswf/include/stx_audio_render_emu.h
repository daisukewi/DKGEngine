
#ifndef __STX_AUDIO_RENDER_EMU_H__
#define __STX_AUDIO_RENDER_EMU_H__

/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/


#include "stx_async_plugin.h"

#include "stx_gid_def.h"


#if defined( __cplusplus )
extern "C" {
#endif




/* {285C50FB-A4DA-4e90-A91C-F5DBD2C7CF40} */
DECLARE_XGUID( STX_CLSID_AudioRenderEmulator,
			 0x285c50fb, 0xa4da, 0x4e90,0xa9, 0x1c, 0xf5, 0xdb, 0xd2, 0xc7, 0xcf, 0x40 );

extern char* g_szStreamX_AudioRenderEmulator;


STX_API
STX_CONSTRUCTOR 
STX_COM(audio_render_emu);


#if defined( __cplusplus )
}
#endif


#endif /* __STX_AUDIO_RENDER_EMU_H__ */ 
