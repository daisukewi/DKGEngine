/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/


#ifndef __BASE_CLASS_DEMO_H__
#define __BASE_CLASS_DEMO_H__


#include "base_class.h"


#if defined( __cplusplus )
extern "C" {
#endif




	// sample code: I'm afraid of it's difficulties...

#define USER_VT_NAME 1

// typedef;
// class declare, should in header file;
STX_COM(
				demo_module,   // class name;
				s32 i,s32 j // construct function parameters list;
				);


// imp code, should write in source file;

// {{class definition;
STX_COM_BEGIN(demo_module);

#if USER_VT_NAME
__STX_PUBLIC(stx_base_module,bae_moe);
#else
STX_PUBLIC(stx_base_module);
#endif

STX_COM_END(demo_module);
// }}class definition;


// declare the inherited class pure member functions;
#if USER_VT_NAME
STX_COM_FUNC_DECL_DEFAULT(stx_base_module,bae_moe);
#else
STX_COM_FUNC_DECL_DEFAULT(stx_base_module,stx_base_module_vt);
#endif


// {{imp the constructor;
STX_NEW_BEGIN(demo_module,s32 i,s32 j)

// init vt;
#if USER_VT_NAME
STX_SET_THE(bae_moe);
STX_COM_NEW_DEFAULT(stx_base_module, the->bae_moe, bae_moe);
#else
STX_SET_THE(stx_base_module);
STX_COM_NEW_DEFAULT(stx_base_module, the->stx_base_module_vt, stx_base_module_vt);
#endif

STX_NEW_END()
// }}imp the constructor;



STX_API_IMP	STX_RESULT	STX_COM_FUNC_NAME(demo_module,query_interf)( 
	STX_HANDLE h, stx_gid gid, STX_HANDLE* pp_interf)
{
	demo_module* the = (demo_module*)h;
	// add code;
	if( IS_EQUAL_GID(gid,STX_IID_BaseCom) ) {
		the->i_ref ++;
		*pp_interf = the;
		return STX_OK;
	}
	if( IS_EQUAL_GID(gid,STX_IID_BaseModule) ) {
		the->i_ref ++;
#if USER_VT_NAME
		*pp_interf = &the->bae_moe;
#else
		*pp_interf = &the->stx_base_module_vt;
#endif
		return STX_OK;
	}
	return STX_ERR_INVALID_PARAM;
}

STX_API_IMP	s32 STX_COM_FUNC_NAME(demo_module,add_ref)( STX_HANDLE h )
{
	demo_module* the = (demo_module*)h;
	// add code;
	the->i_ref ++;
	return the->i_ref;
}

STX_API_IMP	s32 STX_COM_FUNC_NAME(demo_module,release)(STX_HANDLE h)
{
	demo_module* the = (demo_module*)h;

	the->i_ref --;

	if( the->i_ref > 0 ){

		return the->i_ref;
	}

	// add code;

	if( the->b_inst){

		stx_free(the);
	}

	return 0;
}

#if USER_VT_NAME
STX_PURE s32 
bae_moe_com_xxx_release(STX_HANDLE h)
{
	STX_MAP_THE(demo_module);
	return STX_COM_FUNC_NAME(demo_module,release)(the);
}
STX_PURE s32 
bae_moe_com_xxx_add_ref(STX_HANDLE)
{
	return 0;
}
STX_PURE STX_RESULT 
bae_moe_com_xxx_query_interf(STX_HANDLE,stx_gid,STX_HANDLE *)
{
	return STX_OK;
}

STX_PURE STX_RESULT 
bae_moe_xxx_create_instance(STX_HANDLE,stx_gid,STX_HANDLE *)
{
	return STX_OK;
}
STX_PURE s32 
bae_moe_xxx_get_filter_num(STX_HANDLE h)
{
	return 0;
}
STX_PURE STX_RESULT 
bae_moe_xxx_get_filter_gid(STX_HANDLE h, s32 i_index, stx_gid* p_gid)
{
	return STX_OK;
}
#else

STX_PURE s32 
stx_base_module_vt_com_xxx_release(STX_HANDLE h)
{
	STX_MAP_THE(demo_module);
	return STX_COM_FUNC_NAME(demo_module,release)(the);
}
STX_PURE s32 
stx_base_module_vt_com_xxx_add_ref(STX_HANDLE)
{
	return 0;
}
STX_PURE STX_RESULT 
stx_base_module_vt_com_xxx_query_interf(STX_HANDLE,stx_gid,STX_HANDLE *)
{
	return STX_OK;
}

STX_PURE STX_RESULT 
stx_base_module_vt_xxx_create_instance(STX_HANDLE,stx_gid,STX_HANDLE *)
{
	return STX_OK;
}
STX_PURE s32 
stx_base_module_vt_xxx_get_filter_num(STX_HANDLE h)
{
	return 0;
}
STX_PURE STX_RESULT 
stx_base_module_vt_xxx_get_filter_gid(STX_HANDLE h, s32 i_index, stx_gid* p_gid)
{
	return STX_OK;
}
#endif


void test()
{
	stx_base_com *p = XNEW(demo_module,NULL,
		"stx_base_com *p = XNEW(demo_module,NULL",
		1,1);

	stx_base_module* pflt = NULL;

	p->query_interf(p,STX_IID_BaseModule,(void**)&pflt);

	// tmp pointer p is not used;
	SAFE_XDELETE(p);

	// add code; use pflt interface, 

	s32 i_flt = pflt->get_filter_num(pflt);

	SAFE_XDELETE(pflt);
}



	/***********************************************************************/





#if defined( __cplusplus )
}
#endif



#endif /* __BASE_CLASS_DEMO_H__ */ 