
#ifndef __STX_AUDIO_RENDER_H__
#define __STX_AUDIO_RENDER_H__

/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/


#include "base_class.h"


#if defined( __cplusplus )
extern "C" {
#endif






#if defined( __cplusplus )
}
#endif


#endif /* __STX_AUDIO_RENDER_H__ */ 