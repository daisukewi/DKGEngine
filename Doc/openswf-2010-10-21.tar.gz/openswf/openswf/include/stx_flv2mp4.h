/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/
#ifndef __STX_FLV2MP4_H__
#define __STX_FLV2MP4_H__


#if defined( __cplusplus )
extern "C" {
#endif

#include "stx_all.h"


STX_API STX_HANDLE      flv2mp4(char* sz_input,char* sz_output);

STX_API STX_RESULT      flv2mp4_cmd( 
    STX_HANDLE h, 
    size_t i_cmd, 
    size_t i_wparam,
    size_t i_lparam);

STX_API void           flv2mp4_close(STX_HANDLE h);


#if defined( __cplusplus )
}
#endif




#endif //__STX_FLV2MP4_H__
