/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-06
***********************************************************************************/
#ifndef __STP_CLIENT_H__
#define __STP_CLIENT_H__


#include "stx_base_type.h"
#include "stx_io.h"


#if defined( __cplusplus )
extern "C" {
#endif

	typedef struct stp_op_param  stp_op_param;

	struct stp_op_param{
		s32		i_channel;
		s64		i_file_size;
		s64		i_time_milisec;
		s64		i_moddate;
		THEE	h_obj;
		s32*	i_idx;
	};

	stx_xio* stx_create_io_stp(
		const char*		sz_ip,
		u16				i_port,
		const char*		sz_url,
		const char*		sz_graph,
		stx_xio*		h_stream);



#if defined( __cplusplus )
}
#endif


#endif // __STP_CLIENT_H__



