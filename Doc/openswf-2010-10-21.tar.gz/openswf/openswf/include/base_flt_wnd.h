/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/
#ifndef __BASE_FLT_WND_H__
#define __BASE_FLT_WND_H__

#include "output_pin_wnd.h"



#if defined( __cplusplus )
extern "C" {
#endif


	STX_INTERF(stx_connection_point);
	STX_INTERF(stx_connection);
	STX_INTERF(stx_grade);


struct base_flt_wnd{

	HWND				m_hWnd;

	stx_base_filter*	m_hFilter;
	stx_gid             m_catid;
	stx_gid             m_clsid;
	stx_gid             m_insid;

	s32					m_iInputPin;
	s32                 m_iMaxInputPin;
	base_pin_wnd**		m_hhInputPinWnd;

	s32					m_iOutputPin;
	s32                 m_iMaxOutputPin;

	output_pin_wnd**	m_hhOutputPinWnd;

	s32                 m_iZorder;
	s32                 m_iGrade;
	RECT                m_pos;

	RECT                m_caption;
	s32                 m_iTitleWidth;
	s32                 m_iTitleClip;

	b32                 m_bFocus;
	b32                 m_bDrag;
	POINT               m_lastPoint;
	POINT               m_point;

	char*               m_szLastPath;
	char*               m_szStream;
	s32                 m_iLastStream;
	char**              m_szLastStream;

	s32					m_iMaxGraph;

	stx_base_graph_builder* h_gbd;

	DECL_TRACE
};

static stx_base_filter* fw_get_filter(base_flt_wnd* the){
	return the->m_hFilter;
}
static s32 fw_get_zorder(base_flt_wnd* the){
	return the->m_iZorder;
}
static void fw_set_zorder(base_flt_wnd* the,s32 i_order){
	the->m_iZorder = i_order;
}

static s32 fw_get_grade(base_flt_wnd* the){
	return the->m_iGrade;
}
static void fw_set_grade(base_flt_wnd* the,s32 i_grade){
	the->m_iGrade = i_grade;
}

static stx_gid fw_GetCatGid(base_flt_wnd* the){
	return the->m_catid;
}
static stx_gid fw_GetClsGid(base_flt_wnd* the){
	return the->m_clsid;
}
static stx_gid fw_GetInsGid(base_flt_wnd* the){
	return the->m_insid;
}

static char* fw_get_last_path(base_flt_wnd* the){
	return the->m_szLastPath;
}

static char** fw_get_last_stream(base_flt_wnd* the,s32* i_num){
	*i_num = the->m_iLastStream;
	return the->m_szLastStream;
}

static RECT fw_get_pos(base_flt_wnd* the){
	return the->m_pos;
}


base_flt_wnd* fw_create(HWND hWnd,stx_base_graph_builder* h);
void fw_close(base_flt_wnd* the);


STX_RESULT fw_initialize(base_flt_wnd* the,stx_xini* h_xini,STX_HANDLE h_parent);
STX_RESULT fw_serialize(base_flt_wnd* the,stx_xini* h_xini,STX_HANDLE h_parent);

STX_RESULT fw_load_stream(base_flt_wnd* the,char* sz_stream);
STX_RESULT fw_close_stream(base_flt_wnd* the);

void  fw_set_filter(base_flt_wnd* the,stx_base_filter* hFilter);


b32 fw_set_pos(base_flt_wnd* the,RECT rec);
b32 fw_PtInPin(base_flt_wnd* the,POINT pt,base_pin_wnd** pin);
b32 fw_move(base_flt_wnd* the,s32 x,s32 y,RECT clip);

STX_RESULT fw_check_connection_point(base_flt_wnd* the,stx_connection_point* p);

STX_RESULT fw_enum_input_pinwnd(base_flt_wnd* the,s32* i_idx,base_pin_wnd** pp_pinwnd);
STX_RESULT fw_enum_output_pinwnd(base_flt_wnd* the,s32* i_idx,output_pin_wnd** pp_pinwnd);

base_pin_wnd*	fw_find_inputpin(base_flt_wnd* the,stx_gid insid);
output_pin_wnd*	fw_find_outputpin(base_flt_wnd* the,stx_gid insid);

void fw_ReleasePinWndPin(base_flt_wnd* the);

STX_RESULT          fw_update_stream_list(base_flt_wnd* the,char* sz_cur);
STX_RESULT          fw_map_pinwnd(base_flt_wnd* the);
STX_RESULT          fw_attach_pinwnd(base_flt_wnd* the);
STX_RESULT          fw_initialize_pinwnd(base_flt_wnd* the);

// return : if need reset the grade;
b32					fw_update_pin_pos(base_flt_wnd* the);





#if defined( __cplusplus )
}
#endif


#endif /* __BASE_FLT_WND_H__ */ 
