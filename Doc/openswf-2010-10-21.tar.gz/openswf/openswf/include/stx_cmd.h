#ifndef __INCLUDE_COMMAND_H__
#define __INCLUDE_COMMAND_H__


#include "stx_base_type.h"


#define FORCE_DECODE                1
#define FORCE_DROP                  2
#define FORCE_END                   4

#define AJUST_VIDEOWND_SCALE		8925

#define WM_NOTIFY_TRAYWND_TODO		2511
#define NOTIFY_UI_UPDATE		5010
#define NOTIFY_UISTATE_UPDATE		5012
#define NOTIFYAPPMSG			5014

#define APP_SETUP			5016
#define APP_ABOUT			5018
#define APP_HELP			5019
#define APP_EXIT			5020
#define UPDATE_UI_MSG			5022
#define RESPOND_MSG			5024

#define UPDATE_OSDINFO_PLAYSPEED    	5025
#define UPDATE_OSDINFO_PLAYSTATE    	5026

//[[ BASIC COMMAND;



#define LX_CMD_BASE                 	32768



//<< LX_OPEN command used in playcontrol, open the source and get the stream infomations,
// to initialize the codecs;
#define LX_OPEN                   LX_CMD_BASE +  900
enum LxOpenPm1{
	LX_OPEN_INIT     ,	
	LX_OPEN_GET_ALL  ,	
	LX_OPEN_ENUM     ,
	LX_OPEN_GET_VIDEO,
};
typedef enum LxOpenPm1 LxOpenPm1;

enum LxOpenPm2{
	STREAMMAP_INIT          ,   // initialize value;
	STREAMMAP_OK            ,   // have stream map table; seldom success;
	STREAMMAP_UNAVAILBLE    ,   // mpeg1/2 system, mpeg1/2 video;
	STREAMMAP_VIDEOSEQUENCE ,
	STREAMMAP_TS            ,   // mpeg2 TS;
	STREAMMAP_PS_1X2        ,   // mpeg12;
	STREAMMAP_PS_H264       ,   // mpeg2 system, h264 video;
	STREAMMAP_PS_XLIV       ,   // XLIV standard;
};

typedef enum LxOpenPm2 LxOpenPm2;

//>> end of LX_OPEN;

//<< LX_GET, LX_SET, LX_CONNECT command used in codecs, controls connect together,
// to build the target stream graph;
#define LX_GET                    LX_CMD_BASE +  910

enum LxGetPm1{
	emGetPinNum     ,	
	emGetPin  ,	
	emGetPinDataNum,
	emGetPinDataType,
	emGetCurPin,
	emGetCurPinDataType,
	emGetStatus,
	emGetAttrib,
	emGetNextFile,
	emGetPrivateData,
	emGetModelName,
	emGetAppInstance,
	emGetParent,
	emGetSvrInf,
	emGetChannel,
	emGetSegment,
	emGetSlice,
	emGetInetAddr,
	emGetInetPort,
	emGetSize,
	emGetReport,
	emGetSystemHdr,
	emGetLastErrStr,
	emGetBitRate,
	emGetStatistic,
};
typedef enum LxGetPm1 LxGetPm1;

enum LxGetPm2{
	emLxGetStart,
	emLxGetAt,
	emLxGetNext,
	emLxGetEnd,
	emLxGetNum,
	emLxGetItemByIdx,
};
typedef enum LxGetPm2 LxGetPm2;

typedef struct LxGetInf LxGetInf;
struct LxGetInf{
	LxGetPm1 emGetType;
	LxGetPm2 emGetCmd;
	DWORD    dwPosition;  // POSITION*,or idx;
	DWORD    dwParam1;    // item*;
}; 


#define LX_SET                    LX_CMD_BASE +  920
enum LxSetPm1{
	emSetCurPin,
	emSetCurPinDataType,
	emSetStatus,
	emSetAttrib,
	emSetPrivateData,
	emSetParent,
	emSetSvrInf,
	emSetPreroll,
	emSetPreview,
	emSetInetAddr,
	emSetInetPort,
	emSetReload,
	emSetVolume,
	emSetRecord,
	emSetEncode,
	emSetVidAccUpdate,
};
typedef enum LxSetPm1 LxSetPm1;

#define LX_ADD                    LX_CMD_BASE +  930
enum LxAddPm1{
	emAddChannel,
	emAddSegment,
	emAddSlice,
};
typedef enum LxAddPm1 LxAddPm1;

#define LX_DEC                    LX_CMD_BASE +  935


#define LX_CLOSE                  LX_CMD_BASE +  940   // xliv close channel;
enum LxClosePm1{
	emCloseChannel,
	emCloseSegment,
	emCloseSlice,
	emCloseNetReader,
};
typedef enum LxClosePm1 LxClosePm1;

#define LX_POST                     LX_CMD_BASE +  950
enum LxPostPm1{
	emPostExit,
	emPostStartReport,
	emPostCreateXsvr,
	emPostUpdateHistory,
	emPostCloseXsvr,
	emPostStmTskEnd,
};
typedef enum LxPostPm1 LxPostPm1;

#define LX_P2P                      LX_CMD_BASE +  960

#define LX_SOCKTHR                  LX_CMD_BASE +  970
#define LX_SOCKTHR_INTERNAL         LX_CMD_BASE +  971


#define LX_CONNECT                  LX_CMD_BASE +  990
//>> end of LX_GET, LX_SET, LX_CONNECT;


#define LX_PLAY                     LX_CMD_BASE +  1000
#define LX_PAUSE                    LX_CMD_BASE +  1010
#define LX_STEP                     LX_CMD_BASE +  1020
#define LX_RESUME                   LX_CMD_BASE +  1030
#define LX_NV_STOP                  LX_CMD_BASE +  1035
#define LX_STOP                     LX_CMD_BASE +  1040
#define LX_EXIT                     LX_CMD_BASE +  1041   // bok control exit;
#define LX_REPORT                   LX_CMD_BASE +  1042
#define LX_JUMP                     LX_CMD_BASE +  1050
#define LX_PREVIOUS                 LX_CMD_BASE +  1060
#define LX_NEXT                     LX_CMD_BASE +  1070
#define LX_GOTO                     LX_CMD_BASE +  1075
#define LX_REVERSE                  LX_CMD_BASE +  1080
#define LX_SET_SPEED                LX_CMD_BASE +  1090
#define LX_GET_SPEED                LX_CMD_BASE +  1100
#define LX_GET_DIRECTION            LX_CMD_BASE +  1110
//]]



// begin of command list

//[[ // control panal infomation;
#define GET_STATISTIC               LX_CMD_BASE + 1200  
#define GET_FILE_INFO               LX_CMD_BASE + 1210
#define GET_FILE_RANGE              LX_CMD_BASE + 1220
#define GET_CURRENT_FILE_POS        LX_CMD_BASE + 1230
//]]

//[[ decoder ?
#define SET_VIDEO_MODE              LX_CMD_BASE + 1300
#define GET_VIDEO_MODE			    LX_CMD_BASE + 1310
#define SET_VIDEO_OUTPUT_MODE	    LX_CMD_BASE + 1320
#define GET_VIDEO_OUTPUT_MODE       LX_CMD_BASE + 1330
//]]

//[[ lxvid global;
#define LX_CMD_VID                  LX_CMD_BASE + 1340
#define LX_CMD_AUD                  LX_CMD_BASE + 1350
#define LX_CMD_AUR                  LX_CMD_BASE + 1360

#define LX_CMD_VIDEO_RENDER         LX_CMD_BASE + 1361
#define	LX_CMD_NEED_CODEC			LX_CMD_BASE	+ 1362
#define	LX_CMD_DBFREQ               LX_CMD_BASE	+ 1363

#define	LX_CMD_TV_IN				LX_CMD_BASE + 1371
#define	LX_CMD_TV_OUT				LX_CMD_BASE	+ 1372

enum LxLiveUpdateCodecInfo
{
	emGUID,
	emExtName,
};

enum LxCmdVideoRender{
	emUpdateOsdTxt, 
	emLxWndMsg,
	emLxGetFmt, 
	emRenderSample,
	emPrePause,
	emRelease,
	emLxRenderUsed,
	emMinSize,
	emSetControl,
	emGetVideoInfo,
	emSetRenderType,
	emUpdateSurface,
};

/*

enum LxD3DFmt{
	emLxD3DFmtYUY2,
	emLxD3DFmtR5G6B5,
	emLxD3DFmtR5G5B5,
	emLxD3DFmtX8R8G8B8,
	emLxD3DFmtR8G8B8,
};
*/



enum LxTVRetAutoTurn	//used when dw1 is emRetAutoTurn
{
	emBegin,			
	emFinish,			//finished auto turn
	emContinue,			//the auto turn is continue,and dw3 id the index of current channel
	emTerminated,			//the auto turn were terminated by user
};
enum LxTVDeviceType
{
	emVideo,
	emAudio,
};

enum LxTVType
{
	emChannel,
	emDevice,
	emConnector,
};
struct LxTVElement 
{
	int				index;		//in, the index of Element;
	char*			buffer;		//out,need pre-allco,and the content may be modified.
	BOOL			bFav;		//in/out,may be modified,not used for Device command
	long			lAudioFre;	//in/out,not used for Device Command
	long			lVideoFre;	//in/out,not used for Device Command
};

struct LxTVDeviceElement
{
	enum LxTVDeviceType	emType;
	int		iDevIndex;
	int		iConCount;
	int		iConIndex;
	char*	DevName;
	char*	ConName;
};
enum LxTVCommand
{
	emGetPointer,
	emGetDeviceCount,	//dw2:LxTVDeviceType,dw3:pointer to a variable to receive the count of channel
	emGetDevice,		//dw2:LxTVDeviceType,dw3:pointer to LxTVElement struct
	emGetConnect,		//dw2:index of device, dw3, pointer
	emSetConnect,
	emSetDevice,		//dw2:LxTVDeviceType,dw3:the index of select device 
	emGetChanCount,		//dw2:pointer to a variable to receive the count of channel
	emSetCurrentChannel,//dw2:pointer to LxTVElement struct
	emReturnLastChannel,
	emRecord,			//dw2:string to path,dw3: not used current

	emGetChanInfo,		//dw2:pointer to LxTVElement struct
	emSetChanInfo,		//dw2:pointer to LxTVElement struct
	emDeleteChan,		//dw2:index of channel to delete

	emAutoTurn,			//dw2:pointer to LxBaseFilter object used for call back
	emStopAutoTurn,		//dw2:pointer to LxBaseFilter object used for call back,this command to stop the auto-turn thread
	emRetAutoTurn,		//send this command to the call back object,to notify the result of auto-turn
};




#define LX_CMD_COLORSPACE_ADJUST    LX_CMD_BASE + 1400
#define LX_CMD_GET_CONTRAST_INFO    LX_CMD_BASE + 1410
//]]

#define LX_GET_TV_INTERFACE         (LX_CMD_BASE + 1420)


//[[ must be video render;
#define SET_PLAY_RECT               LX_CMD_BASE + 1500
#define GET_DISPLAY_MODE            LX_CMD_BASE + 1510
#define SET_LOCAL_RECT              LX_CMD_BASE + 1520
#define DISABLE_LOCAL_RECT          LX_CMD_BASE + 1530
#define HIDE_OVERLAY                LX_CMD_BASE + 1540
#define SHOW_OVERLAY                LX_CMD_BASE + 1550
#define SET_CURRENT_MEDIA_ID        LX_CMD_BASE + 1570
//]]

//<< DVD;
//[[ DVD SP;
#define SET_USER_SUB_ALPHA          LX_CMD_BASE + 1641
#define CLOSE_USER_SUB_ALPHA        LX_CMD_BASE + 1642
#define SET_USER_SUB_COLOR          LX_CMD_BASE + 1643
#define CLOSE_USER_SUB_COLOR        LX_CMD_BASE + 1644
#define OPEN_ZOOM_SUB               LX_CMD_BASE + 1645
#define CLOSE_ZOOM_SUB              LX_CMD_BASE + 1646
#define PT_IN_SP_RECT               LX_CMD_BASE + 1647
#define SET_SP_POS                  LX_CMD_BASE + 1648

#define IS_SP_ZOOM				    LX_CMD_BASE + 1650
#define ENABLE_SP_ZOOM			    LX_CMD_BASE + 1660
#define SET_SPZOOM_RATIO		    LX_CMD_BASE + 1670
#define GET_SPZOOM_RATIO		    LX_CMD_BASE + 1680
#define GET_SPUSERPALETTE		    LX_CMD_BASE + 1690
#define SET_MENUNIFO    		    LX_CMD_BASE + 1700
//]]

#define LX_NAVIGATION			    LX_CMD_BASE + 2000

#define CHANGE_HOT_AREA			    LX_CMD_BASE + 2010
#define VMG_BOOT_MENU			    LX_CMD_BASE + 2020
#define VTS_BOOT_MENU			    LX_CMD_BASE + 2030	
#define VTS_PROGRAM_ID			    LX_CMD_BASE + 2040
#define VTS_TITLE_ID			    LX_CMD_BASE + 2050

#define GET_DST_TITLE_ID		    LX_CMD_BASE + 	2055
#define GET_CUR_TITLE_ID		    LX_CMD_BASE + 	2060
#define GET_DST_PTT_ID			    LX_CMD_BASE + 	2065
#define GET_CUR_PTT_ID			    LX_CMD_BASE + 	2070
#define GET_CUR_A_ID			    LX_CMD_BASE + 	2080
#define GET_CUR_SP_ID			    LX_CMD_BASE + 	2090	

#define CHANGE_TITLE			    LX_CMD_BASE + 2100
#define CHANGE_AUDIO_STREAM		    LX_CMD_BASE + 2110
#define OPEN_AUDIO_STREAM		    LX_CMD_BASE + 2120
#define CHANGE_SUBPICTURE_STREAM    LX_CMD_BASE + 2130
#define OPEN_SUBPICTURE_STREAM	    LX_CMD_BASE + 2140

#define GET_VOB_ROM_MODE_STATUS	    LX_CMD_BASE + 2150
#define GET_VOB_FILE_MODE_STATUS    LX_CMD_BASE + 2160 
#define JUDGE_ROM_MODE_DISK_TYPE    LX_CMD_BASE + 2170

#define GET_CHAPTERMSG              LX_CMD_BASE + 2180
#define UNLOAD_CDROM                LX_CMD_BASE + 2190

#define GET_AUD_MODE                LX_CMD_BASE + 2200
#define GET_AUD_SUPPORT_MODE        LX_CMD_BASE + 2210
#define GET_AUD_CHANNEL_MODE        LX_CMD_BASE + 2220

#define CAN_JUMP_PRETITLE			LX_CMD_BASE + 2230
#define CAN_JUMP_NEXTTITLE			LX_CMD_BASE + 2240
#define CAN_PROGRESS_POS            LX_CMD_BASE + 2241

#define CHANGE_DIRECTORY_MENU_ITEM  LX_CMD_BASE + 2250
#define DIRECT_DVD_PLAY				LX_CMD_BASE + 2260

#define GETVIDEOINFO				LX_CMD_BASE + 2270
#define SET_CHANNEL_MODE			LX_CMD_BASE + 2280


#define JUMP_VCD_BOOT_MENU		    LX_CMD_BASE + 2290

#define NVCANRESUME					LX_CMD_BASE + 2300
#define RESUME_PLAY					LX_CMD_BASE + 2310
#define ISVALID_SPSTREAM		    LX_CMD_BASE + 2320	
#define ISVALID_AUSTREAM		    LX_CMD_BASE + 2330	
#define GET_ATST_SPECICODE		    LX_CMD_BASE + 2340
#define GET_ATST_ENCODETYPE		    LX_CMD_BASE + 2341
#define GET_SPST_SPECICODE		    LX_CMD_BASE + 2350	

#define IS_SP_ENABLE				LX_CMD_BASE + 2360
#define ENABLE_SP					LX_CMD_BASE + 2370
#define CHANGE_SP_LANGUAGE			LX_CMD_BASE + 2380

#define ROOTM_EXST					LX_CMD_BASE + 2390
#define SPM_EXST					LX_CMD_BASE + 2400
#define AM_EXST						LX_CMD_BASE + 2410
#define AGLEM_EXST					LX_CMD_BASE + 2420
#define PTTM_EXST					LX_CMD_BASE + 2430
#define JUMPTOSPM					LX_CMD_BASE + 2440
#define JUMPTOAM					LX_CMD_BASE + 2450
#define JUMPTOAGLM					LX_CMD_BASE + 2460
#define JUMPTOPTTM					LX_CMD_BASE + 2470
#define GET_VMG_STATE			    LX_CMD_BASE + 2480
#define TTM_EXST					LX_CMD_BASE + 2490
#define GET_AUDIO_NUMBER		    LX_CMD_BASE + 2500
#define GET_SUBPICTURE_NUMBER	    LX_CMD_BASE + 2510
#define GET_TITLE_NUMBER		    LX_CMD_BASE + 2520
#define GET_DVD_PROGRAM_ID		    LX_CMD_BASE + 2530
#define GET_PROGRAM_NUMBER		    LX_CMD_BASE + 2540
#define GET_TITLE_PROGRAM_NUMBER    LX_CMD_BASE + 2550
#define GET_CURRENT_TITLE_ID	    LX_CMD_BASE + 2560
#define GET_CURRENT_PROGRAM_ID	    LX_CMD_BASE + 2570		
#define SET_TITLE_ID			    LX_CMD_BASE + 2580
#define GET_DOM_TYPE			    LX_CMD_BASE + 2590
#define CALL_BACK_TITLE_ID		    LX_CMD_BASE + 2600	
#define GET_CURRENT_PLAYDOM         LX_CMD_BASE + 2610
#define IS_ROOTMENU_EXIST           LX_CMD_BASE + 2620
#define IS_TITLEMENU_EXIST          LX_CMD_BASE + 2630
#define KEYNUMBER_JUMP              LX_CMD_BASE + 2640
#define CHANGE_AUDSTM               LX_CMD_BASE + 2650
#define CHANGE_SUBSTM               LX_CMD_BASE + 2660
// DVD;>> 

//<< TS; baojinlong, 2006-06-25;
#define TS_GET_CHANNEL_INF      	LX_CMD_BASE + 2670
#	define P1_GET_CHANNEL_NUM          0
#	define P1_GET_CHANNEL              1

#define TS_SET_CHANNEL_NUM	        LX_CMD_BASE + 2680

#define TS_GET_AUDIO_INF	        LX_CMD_BASE + 2690
#	define P1_GET_AUDIO_NUM            0
#	define P1_GET_AUDIO                1

#define TS_SET_AUDIO_NUM	        LX_CMD_BASE + 2700
// TS; baojinlong, 2006-06-25; >>


#define AUDIO_DRIVER_ENABLE         LX_CMD_BASE +  3000

#define GET_VOLUME_FLAGS		    LX_CMD_BASE + 3010
#define SET_VOLUME_FLAGS		    LX_CMD_BASE + 3020

#define SET_VOLUME				    LX_CMD_BASE + 3030
#define INC_VOLUME				    LX_CMD_BASE + 3040
#define DEC_VOLUME				    LX_CMD_BASE + 3050

#define GET_CUR_VOLUME			 	LX_CMD_BASE + 3060
#define GET_MIN_VOLUME			 	LX_CMD_BASE + 3070
#define GET_MAX_VOLUME			 	LX_CMD_BASE + 3080
#define GET_SILENCE_FLAG		 	LX_CMD_BASE + 3090
#define SET_SILENCE_FLAG		 	LX_CMD_BASE + 3100


#define	ARROW_KEY_DOWN			    LX_CMD_BASE + 4000
#define KEY_ENTER			        LX_CMD_BASE + 4010


//<< ADDED BY XINGYJ
#define GET_FILE_NUMBER             LX_CMD_BASE + 5000 // VCD;
#define GET_TOTAL_FILE_NUMBER       LX_CMD_BASE + 5010  // VCD;
#define GET_MAINMENU_STATE          LX_CMD_BASE + 5020  // VCD;
#define KEY_NUMBER                  LX_CMD_BASE + 5030
#define WM_TO_VCDSEG                LX_CMD_BASE + 5040
#define VCD_PLAY_BYSEGNO            LX_CMD_BASE + 5050
#define VCD_DEFAULT                 LX_CMD_BASE + 5060
#define VCD_MENUPLAY_BYSEGNO        LX_CMD_BASE + 5070
//>>

//<< capture picture command;
#define CAPTURE_PICTURE             LX_CMD_BASE + 5080

#define LX_VIDEO_CAPTURE            LX_CMD_BASE + 5081
enum emVidCapOption{
	emVidCapOpAvi,emVidCapOpBokFile,emVidCapOpBokLive,
};


#define	LX_TV2BOK_CAPTURE			LX_CMD_BASE + 5082
#define LX_GET_LIVE_DEVICE			LX_CMD_BASE + 5083
#define	LX_SET_LIVE_DEVICE			LX_CMD_BASE + 5084
#define	LX_TV2BOK_STOP				LX_CMD_BASE + 5085
#define	LX_TV2BOK_HWND				LX_CMD_BASE + 5086
#define	LX_WMV2BOK_START			LX_CMD_BASE + 5087
#define	LX_WMV2BOK_END				LX_CMD_BASE + 5088
#define	LX_PIC_CAPTURED				LX_CMD_BASE	+ 5089
// >>


#define REMOTEMESSAGE               LX_CMD_BASE + 5090
#define GET_SOUNDMODE               LX_CMD_BASE + 5100
#define GET_SP1MODE                 LX_CMD_BASE + 5110
#define GET_SP2MODE                 LX_CMD_BASE + 5120


//[[ internal command;
#define OKPLAY                      LX_CMD_BASE + 6000
#define CMD_NV_STEP				    LX_CMD_BASE + 6010
#define CMD_EXECUTE_NV				LX_CMD_BASE + 6020
#define	CMD_SET_DPLAY				LX_CMD_BASE + 6030
#define CMD_PLAYWND_RESIZE			LX_CMD_BASE + 6040
#define CMD_CANADJUST_BRIGHTNESS	LX_CMD_BASE + 6050
#define CMD_CANADJUST_CONTRAST		LX_CMD_BASE + 6060
#define CMD_RELEASE_DSHOW			LX_CMD_BASE + 6070
#define CMD_HAS_VIDEOSTREAM			LX_CMD_BASE + 6080
#define CMD_CAN_CAPTURE				LX_CMD_BASE + 6090
#define CMD_SLIDER_JUMP				LX_CMD_BASE + 6100
#define CMD_GET_CAPS    			LX_CMD_BASE + 6110
#define CMD_CAN_FLIPVERTICAL		LX_CMD_BASE + 6200
#define CMD_FLIPVERTICAL			LX_CMD_BASE + 6300
#define CMD_CAN_DESKTOPPLAY			LX_CMD_BASE + 6400

#define VCD_AUTO_JUMP               LX_CMD_BASE + 6410

#define SET_PLAY_FILENAME		    LX_CMD_BASE + 6420  // dshow command 

#define GET_HOT_RECT                LX_CMD_BASE + 6430  // SPDEC USE;
#define GET_STREAM_DATA             LX_CMD_BASE + 6440  // DIVX USE;
#define RELEASE_STREAM_DATA         LX_CMD_BASE + 6450  // DIVX USE;

// end of internal command  list]]

#endif //__INCLUDE_COMMAND_H__
