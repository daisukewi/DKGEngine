/*
 * Copyright (c) 2007 Mans Rullgard
 *
 * This file is part of FFmpeg.
 *
 * FFmpeg is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * FFmpeg is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with FFmpeg; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
 */

#ifndef FFMPEG_AVSTRING_H
#define FFMPEG_AVSTRING_H

#include "stx_base_type.h"


#if defined( __cplusplus )
extern "C" {
#endif

	/* misc math functions */
	extern const uint8_t ff_log2_tab[256];

	extern const uint8_t ff_sqrt_tab[256];

	STX_API char*			data_to_hex(char *buff, const uint8_t *src, int s);

	STX_API int			    hex_to_data(uint8_t *data, const char *p);

	STX_API STX_BOOL		stx_isdigit ( int code );

	STX_API void			get_word(char *buf, int buf_size, const char **pp);

	STX_API void			get_word_sep(char *buf, int buf_size, const char *sep,const char **pp);

	STX_API void			skip_spaces(const char **pp);

	STX_API int			redir_isspace(int c);

	STX_API int			rtsp_next_attr_and_value(
                const char **p, 
		char *attr, 
		int attr_size, 
		char *value, 
		int value_size);





void url_split(	char *proto, 
		int proto_size,
		char *authorization, 
		int authorization_size,
		char *hostname, 
		int hostname_size,
		int *port_ptr,
		char *path, 
		int path_size,
		const char *url);


/**
 * Return non-zero if pfx is a prefix of str. If it is, *ptr is set to
 * the address of the first character in str after the prefix.
 *
 * @param str input string
 * @param pfx prefix to test
 * @param ptr updated after the prefix in str in there is a match
 * @return non-zero if the prefix matches, zero otherwise
 */
int av_strstart(const char *str, const char *pfx, const char **ptr);

/**
 * Return non-zero if pfx is a prefix of str independent of case. If
 * it is, *ptr is set to the address of the first character in str
 * after the prefix.
 *
 * @param str input string
 * @param pfx prefix to test
 * @param ptr updated after the prefix in str in there is a match
 * @return non-zero if the prefix matches, zero otherwise
 */
int av_stristart(const char *str, const char *pfx, const char **ptr);

/**
 * Copy the string src to dst, but no more than size - 1 bytes, and
 * null terminate dst.
 *
 * This function is the same as BSD strlcpy().
 *
 * @param dst destination buffer
 * @param src source string
 * @param size size of destination buffer
 * @return the length of src
 */
size_t av_strlcpy(char *dst, const char *src, size_t size);

/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/


int av_base64_decode(uint8_t * out, const char *in, int out_length);

char *av_base64_encode(char * buf, int buf_len, const uint8_t * src, int len);



/**
 * Append the string src to the string dst, but to a total length of
 * no more than size - 1 bytes, and null terminate dst.
 *
 * This function is similar to BSD strlcat(), but differs when
 * size <= strlen(dst).
 *
 * @param dst destination buffer
 * @param src source string
 * @param size size of destination buffer
 * @return the total length of src and dst
 */
size_t av_strlcat(char *dst, const char *src, size_t size);

/**
 * Append output to a string, according to a format. Never write out of
 * the destination buffer, and and always put a terminating 0 within
 * the buffer.
 * @param dst destination buffer (string to which the output is
 *  appended)
 * @param size total size of the destination buffer
 * @param fmt printf-compatible format string, specifying how the
 *  following parameters are used
 * @return the length of the string that would have been generated
 *  if enough space had been available
 */
size_t av_strlcatf(char *dst, size_t size, const char *fmt, ...);


#if defined( __cplusplus )
}
#endif


#endif /* FFMPEG_AVSTRING_H */
