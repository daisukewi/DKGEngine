
#ifndef __STX_GID_H__
#define __STX_GID_H__


/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/


#include "stx_base_type.h"


#if defined( __cplusplus )
extern "C" {
#endif


stx_gid stx_gid_create();

char*   stx_gid_to_string(stx_gid gid);

void    stx_gid_close_string(char** sz_gid);

stx_gid stx_gid_from_string(char* sz_gid);


void	binary_from_string(u8* val,char* str);
void	binary_to_string(size_t i_size,u8* val,char* str);
char*	binary_create_string(size_t i_size,u8* val);

size_t  binary_to_base64_size(size_t i_size);
size_t  binary_from_base64_size(char* str,char** start);

void	binary_from_base64(u8* val,char* str);
void	binary_to_base64(size_t i_size,u8* val,char* str);

void    base64_init();


#if defined( __cplusplus )
}
#endif


stx_inline size_t  binary_to_string_size(size_t i_size)
{
	return i_size*2+1;
}
stx_inline size_t binary_from_string_size(char* str)
{
	return strlen(str) / 2;
}

#endif /*__STX_GID_H__*/ 
