/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/


#ifndef __STX_MEM_ALLOC_BASE_H__
#define __STX_MEM_ALLOC_BASE_H__


#include "base_interf.h"



#if defined( __cplusplus )
extern "C" {
#endif



typedef struct stx_media_data_allocator		stx_mem_alloc_base;

STX_INTERF(stx_mda_alloc_base_param);
struct stx_mda_alloc_base_param{
	int32_t		i_mda_num;
	int32_t		i_mda_size;
};

STX_INTERF(stx_base_alloc);

#ifdef __USE_STX_DEBUG__
STX_API stx_mem_alloc_base*		create_stx_base_alloc(THEE hinst,const char* file,s32 line);
#else
STX_API stx_mem_alloc_base*		create_stx_base_alloc(THEE hinst);
#endif





#if defined( __cplusplus )
}
#endif



#endif /* __STX_MEM_ALLOC_BASE_H__ */ 