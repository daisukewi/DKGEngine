#ifndef __Z264_H__
#define __Z264_H__

#include "stx_base_type.h"
#include "stx_cpuid.h"


typedef struct x264_run_level_t x264_run_level_t;
struct x264_run_level_t
{
	s32     last;
	s16		level[16];
	u8		run[16];
} ;


#define FENC_STRIDE 16
#define FDEC_STRIDE 32


extern DECLARE_ALIGNED_16(s16,	pw_1[8]);

extern  DECLARE_ALIGNED_16(s16,	pw_2[8]);
extern  DECLARE_ALIGNED_16(s16,	pw_4[8]);
extern  DECLARE_ALIGNED_16(s16,	pw_8[8]);
extern  DECLARE_ALIGNED_16(s16,	pw_16[8]);
extern  DECLARE_ALIGNED_16(s16,	pw_32[8]);
extern  DECLARE_ALIGNED_16(s16,	pw_64[8]);
extern  DECLARE_ALIGNED_16(s16,	pw_8000[8]);

extern DECLARE_ALIGNED_16(s16,  pw_00ff[8]);

extern DECLARE_ALIGNED_16(s32,	ssim_c1[4]);
extern DECLARE_ALIGNED_16(s32,	ssim_c2[4]);
extern DECLARE_ALIGNED_16(u8,	mask_ff[32]);
extern DECLARE_ALIGNED_16(s16,	mask_ac4[8]);
extern DECLARE_ALIGNED_16(s16,	mask_ac8[8]);
extern DECLARE_ALIGNED_16(s16,  mask_acb[8]);

extern DECLARE_ALIGNED_16(s8,   hmul_4p[16]);
extern DECLARE_ALIGNED_16(s8,   hmul_8p[16]);
extern DECLARE_ALIGNED_16(s16,  mask_10[8]);
extern DECLARE_ALIGNED_16(s32,  mask_1100[4]);

extern DECLARE_ALIGNED_16(s8,   ch_shuffle[32]);
extern DECLARE_ALIGNED_16(s8,	hsub_mul[16]); 
extern DECLARE_ALIGNED_16(s8,	pb_sub4frame[16]);
extern DECLARE_ALIGNED_16(s8,	pb_sub4field[16]);
extern DECLARE_ALIGNED_16(s16,	pb_subacmask[8]);
extern DECLARE_ALIGNED_16(u8,	pb_scan4framea[16]);
extern DECLARE_ALIGNED_16(u8,	pb_scan4frameb[16]);
extern DECLARE_ALIGNED_16(u8,	pb_idctdc_unpack[16]);
extern DECLARE_ALIGNED_16(u8,	pb_idctdc_unpack2[16]);
extern DECLARE_ALIGNED_16(u8,	pb_1[16]);

extern DECLARE_ALIGNED_16(u8,	pb_00[16]);
extern DECLARE_ALIGNED_16(u8,	pb_01[16]);
extern DECLARE_ALIGNED_16(u8,	pb_03[16]);
extern DECLARE_ALIGNED_16(u8,	pb_a1[16]);

extern DECLARE_ALIGNED_16(u8,	filt_mul20[16]);
extern DECLARE_ALIGNED_16(u8,	filt_mul51[16]);
extern DECLARE_ALIGNED_16(s32,	pd_ffff[4]);
extern DECLARE_ALIGNED_16(s32,	pd_128[4]);
extern DECLARE_ALIGNED_16(s32,	pd_1[4]);

extern DECLARE_ALIGNED_16(s16,  zdequant4_scale[8*6]);
extern DECLARE_ALIGNED_16(s16,  zdequant8_scale[32*6]);
extern DECLARE_ALIGNED_16(u8,	decimate_mask_table4[384]);


// quant.c
extern const DECLARE_ALIGNED_16(u8, x264_decimate_table4[16]);
extern const DECLARE_ALIGNED_16(u8, x264_decimate_table8[64]);
//

// predict-a.asm
extern DECLARE_ALIGNED_16(s16,	pw_76543210[8] );
extern DECLARE_ALIGNED_16(s16,	pw_3210[8] );
extern DECLARE_ALIGNED_16(u8,	pb_00s_ff[8] );
extern DECLARE_ALIGNED_16(u8,	pb_0s_ff[8] );
extern DECLARE_ALIGNED_16(s16,	pw_ff00[8] );
extern DECLARE_ALIGNED_16(u8,	pb_reverse[8] );
//


#if defined( __cplusplus )
extern "C" {
#endif

	extern s32 z264_cpu_cpuid( s32 op, s32 *eax, s32 *ebx, s32 *ecx, s32 *edx );
	extern s32 z264_cpu_cpuid_test();
	extern void z264_cpu_mask_misalign_sse(void);
	extern void z264_emms( void );

//{{ frame.c
#if !defined(STX64)
	void y264_deblock_v_chroma_mmxext( u8 *pix, s32 stride, s32 alpha, s32 beta, s8 *tc0 );
	void y264_deblock_h_chroma_mmxext( u8 *pix, s32 stride, s32 alpha, s32 beta, s8 *tc0 );
	void y264_deblock_v_chroma_intra_mmxext( u8 *pix, s32 stride, s32 alpha, s32 beta );
	void y264_deblock_h_chroma_intra_mmxext( u8 *pix, s32 stride, s32 alpha, s32 beta );

	void y264_deblock_h_luma_mmxext( u8 *pix, s32 stride, s32 alpha, s32 beta, s8 *tc0 );
	void y264_deblock_v8_luma_mmxext( u8 *pix, s32 stride, s32 alpha, s32 beta, s8 *tc0 );
	void y264_deblock_h_luma_intra_mmxext( u8 *pix, s32 stride, s32 alpha, s32 beta );
	void y264_deblock_v8_luma_intra_mmxext( u8 *pix, s32 stride, s32 alpha, s32 beta );

	static void y264_deblock_v_luma_mmxext( u8 *pix, s32 stride, s32 alpha, s32 beta, s8 *tc0 )
	{
		y264_deblock_v8_luma_mmxext( pix,   stride, alpha, beta, tc0   );
		y264_deblock_v8_luma_mmxext( pix+8, stride, alpha, beta, tc0+2 );
	}
	static void y264_deblock_v_luma_intra_mmxext( u8 *pix, s32 stride, s32 alpha, s32 beta )
	{
		y264_deblock_v8_luma_intra_mmxext( pix,   stride, alpha, beta );
		y264_deblock_v8_luma_intra_mmxext( pix+8, stride, alpha, beta );
	}
#endif

	//{{ zzdeblock_64.c;
	void z264_deblock_v_chroma_sse2( u8 *pix, s32 stride, s32 alpha, s32 beta, s8 *tc0 );
	void z264_deblock_h_chroma_sse2( u8 *pix, s32 stride, s32 alpha, s32 beta, s8 *tc0 );
	void z264_deblock_v_chroma_intra_sse2( u8 *pix, s32 stride, s32 alpha, s32 beta );
	void z264_deblock_h_chroma_intra_sse2( u8 *pix, s32 stride, s32 alpha, s32 beta );

	void z264_deblock_h_luma_sse2( u8 *pix, s32 stride, s32 alpha, s32 beta, s8 *tc0 );
	void z264_deblock_v8_luma_sse2( u8 *pix, s32 stride, s32 alpha, s32 beta, s8 *tc0 );
	void z264_deblock_h_luma_intra_sse2( u8 *pix, s32 stride, s32 alpha, s32 beta );
	void z264_deblock_v8_luma_intra_sse2( u8 *pix, s32 stride, s32 alpha, s32 beta );
	void z264_deblock_v_luma_sse2( u8 *pix, s32 stride, s32 alpha, s32 beta, s8 *tc0 );
	void z264_deblock_v_luma_intra_sse2( u8 *pix, s32 stride, s32 alpha, s32 beta );
	//}}

//}} frame.c


//{{ dct.h
#if !defined(STX64)
	void y264_sub4x4_dct_mmx     ( s16 dct[ 4][4]   ,  u8 *pix1, u8 *pix2 );
	void y264_sub8x8_dct_mmx     ( s16 dct[ 4][4][4],  u8 *pix1, u8 *pix2 );
	void y264_sub16x16_dct_mmx   ( s16 dct[16][4][4],  u8 *pix1, u8 *pix2 );
	void y264_sub8x8_dct_dc_mmxext( s16 dct[2][2], u8 *pix1, u8 *pix2 );
	void y264_add4x4_idct_mmx    ( u8 *p_dst, s16 dct[ 4][4]    );
	void y264_add8x8_idct_mmx    ( u8 *p_dst, s16 dct[ 4][4][4] );
	void y264_add8x8_idct_dc_mmx ( u8 *p_dst, s16 dct[2][2] );
	void y264_add16x16_idct_mmx  ( u8 *p_dst, s16 dct[16][4][4] );
	void y264_add16x16_idct_dc_mmx ( u8 *p_dst, s16 dct[4][4] );
	void y264_dct4x4dc_mmx       ( s16 d[4][4] );
	void y264_idct4x4dc_mmx      ( s16 d[4][4] );
	void y264_sub8x8_dct8_mmx    ( s16 dct[8][8]   , u8 *pix1, u8 *pix2 );
	void y264_sub16x16_dct8_mmx  ( s16 dct[4][8][8], u8 *pix1, u8 *pix2 );
	void y264_add8x8_idct8_mmx   ( u8 *dst, s16 dct[8][8]    );
	void y264_add16x16_idct8_mmx ( u8 *dst, s16 dct[4][8][8] );
	void y264_zigzag_scan_8x8_frame_mmxext( s16 level[64], s16 dct[8][8] );
	void y264_zigzag_scan_4x4_frame_mmx   ( s16 level[16], s16 dct[4][4] );
	void y264_zigzag_interleave_8x8_cavlc_mmx( s16 *dst, s16 *src, u8 *nnz );
	void y264_zigzag_scan_4x4_field_mmxext( s16 level[16], s16 dct[4][4] );
#endif

	//{{ imping from mmx;
	void z264_add4x4_idct_sse2    ( u8 *p_dst, s16 dct[ 4][4]    );
	void z264_sub4x4_dct_sse2     ( s16 dct[ 4][4]   ,  u8 *pix1, u8 *pix2 );
	void z264_add8x8_idct_dc_sse2 ( u8 *p_dst, s16 dct[2][2] );
	void z264_dct4x4dc_sse2       ( s16 d[4][4] );
	void z264_idct4x4dc_sse2      ( s16 d[4][4] );
	void z264_add8x8_idct8_sse2   ( u8 *dst, s16 dct[8][8]    );
	void z264_zigzag_scan_4x4_frame_sse2   ( s16 level[16], s16 dct[4][4] );
	void z264_zigzag_scan_4x4_field_sse2( s16 level[16], s16 dct[4][4] );
	//}}

	//{{ imp from sse2;
	void z264_add8x8_idct8_sse2  ( u8 *dst, s16 dct[8][8]    );
	void z264_add16x16_idct8_sse2( u8 *dst, s16 dct[4][8][8] );

	void z264_sub8x8_dct_sse2    ( s16 dct[ 4][4][4],  u8 *pix1, u8 *pix2 );
	void z264_sub16x16_dct_sse2  ( s16 dct[16][4][4],  u8 *pix1, u8 *pix2 );
	void z264_sub8x8_dct_dc_sse2 ( s16 dct[2][2], u8 *pix1, u8 *pix2 );

	void z264_add8x8_idct_sse2   ( u8 *p_dst, s16 dct[ 4][4][4] );
	void z264_add16x16_idct_sse2 ( u8 *p_dst, s16 dct[16][4][4] );
	void z264_add16x16_idct_dc_sse2( u8 *p_dst, s16 dct[4][4] );
	void z264_sub8x8_dct8_sse2   ( s16 dct[8][8]   , u8 *pix1, u8 *pix2 );
	void z264_sub16x16_dct8_sse2 ( s16 dct[4][8][8], u8 *pix1, u8 *pix2 );
	void z264_zigzag_interleave_8x8_cavlc_sse2( s16 *dst, s16 *src, u8 *nnz );
	void z264_zigzag_scan_8x8_frame_sse2  ( s16 level[64], s16 dct[8][8] );
	//}}

	void z264_sub4x4_dct_ssse3   ( s16 dct[ 4][4]   ,  u8 *pix1, u8 *pix2 );
	void z264_sub8x8_dct_ssse3   ( s16 dct[ 4][4][4],  u8 *pix1, u8 *pix2 );
	void z264_sub16x16_dct_ssse3 ( s16 dct[16][4][4],  u8 *pix1, u8 *pix2 );
	void z264_add8x8_idct_dc_ssse3( u8 *p_dst, s16 dct[2][2] );
	void z264_add16x16_idct_dc_ssse3( u8 *p_dst, s16 dct[4][4] );

	void z264_sub8x8_dct8_ssse3  ( s16 dct[8][8]   , u8 *pix1, u8 *pix2 );
	void z264_sub16x16_dct8_ssse3( s16 dct[4][8][8], u8 *pix1, u8 *pix2 );

	void z264_zigzag_scan_8x8_frame_ssse3 ( s16 level[64], s16 dct[8][8] );
	void z264_zigzag_scan_4x4_frame_ssse3 ( s16 level[16], s16 dct[4][4] );
	s32  z264_zigzag_sub_4x4_frame_ssse3  ( s16 level[16], const u8 *src, u8 *dst );
	s32  z264_zigzag_sub_4x4ac_frame_ssse3( s16 level[16], const u8 *src, u8 *dst, s16 *dc );
	s32  z264_zigzag_sub_4x4_field_ssse3  ( s16 level[16], const u8 *src, u8 *dst );
	s32  z264_zigzag_sub_4x4ac_field_ssse3( s16 level[16], const u8 *src, u8 *dst, s16 *dc );
//}} dct.h


//{{ quant.h

#if !defined(STX64)
	s32 y264_quant_2x2_dc_mmxext( s16 dct[2][2], s32 mf, s32 bias );
	s32 y264_quant_4x4_dc_mmxext( s16 dct[4][4], s32 mf, s32 bias );
	s32 y264_quant_4x4_mmx( s16 dct[4][4], u16 mf[16], u16 bias[16] );
	s32 y264_quant_8x8_mmx( s16 dct[8][8], u16 mf[64], u16 bias[64] );
	
	void y264_dequant_4x4_mmx( s16 dct[4][4], s32 dequant_mf[6][4][4], s32 i_qp );
	void y264_dequant_4x4dc_mmxext( s16 dct[4][4], s32 dequant_mf[6][4][4], s32 i_qp );
	void y264_dequant_8x8_mmx( s16 dct[8][8], s32 dequant_mf[6][8][8], s32 i_qp );
	void y264_dequant_4x4_flat16_mmx( s16 dct[4][4], s32 dequant_mf[6][4][4], s32 i_qp );
	void y264_dequant_8x8_flat16_mmx( s16 dct[8][8], s32 dequant_mf[6][8][8], s32 i_qp );

	void y264_denoise_dct_mmx( s16 *dct, u32 *sum, u16 *offset, s32 size );
	
	s32 y264_decimate_score15_mmxext( s16 *dct );
	s32 y264_decimate_score16_mmxext( s16 *dct );
	s32 y264_decimate_score64_mmxext( s16 *dct );
	
	s32 y264_coeff_last4_mmxext( s16 *dct );
	s32 y264_coeff_last15_mmxext( s16 *dct );
	s32 y264_coeff_last16_mmxext( s16 *dct );
	s32 y264_coeff_last64_mmxext( s16 *dct );
	s32 y264_coeff_last4_mmxext_lzcnt( s16 *dct );
	s32 y264_coeff_level_run16_mmxext( s16 *dct, x264_run_level_t *runlevel );
	s32 y264_coeff_level_run4_mmxext( s16 *dct, x264_run_level_t *runlevel );
	s32 y264_coeff_level_run4_mmxext_lzcnt( s16 *dct, x264_run_level_t *runlevel );
	s32 y264_coeff_level_run15_mmxext( s16 *dct, x264_run_level_t *runlevel );
#endif

	//{{ imp from mmx
	s32 z264_quant_2x2_dc_sse2( s16 dct[2][2], s32 mf, s32 bias );
	s32 z264_coeff_last4_sse2( s16 *dct );
	s32 z264_coeff_last4_sse2_lzcnt( s16 *dct );
	s32 z264_coeff_level_run4_sse2( s16 *dct, x264_run_level_t *runlevel );
	s32 z264_coeff_level_run4_sse2_lzcnt( s16 *dct, x264_run_level_t *runlevel );
	//}}

	s32 z264_quant_4x4_dc_sse2( s16 dct[4][4], s32 mf, s32 bias );
	s32 z264_quant_4x4_sse2( s16 dct[4][4], u16 mf[16], u16 bias[16] );
	s32 z264_quant_8x8_sse2( s16 dct[8][8], u16 mf[64], u16 bias[64] );

	s32 z264_quant_2x2_dc_ssse3( s16 dct[2][2], s32 mf, s32 bias );
	s32 z264_quant_4x4_dc_ssse3( s16 dct[4][4], s32 mf, s32 bias );
	s32 z264_quant_4x4_ssse3( s16 dct[4][4], u16 mf[16], u16 bias[16] );
	s32 z264_quant_8x8_ssse3( s16 dct[8][8], u16 mf[64], u16 bias[64] );
	s32 z264_quant_4x4_dc_sse4( s16 dct[4][4], s32 mf, s32 bias );
	s32 z264_quant_4x4_sse4( s16 dct[4][4], u16 mf[16], u16 bias[16] );
	s32 z264_quant_8x8_sse4( s16 dct[8][8], u16 mf[64], u16 bias[64] );
	
	void z264_dequant_4x4_sse2( s16 dct[4][4], s32 dequant_mf[6][4][4], s32 i_qp );
	void z264_dequant_4x4dc_sse2( s16 dct[4][4], s32 dequant_mf[6][4][4], s32 i_qp );
	void z264_dequant_8x8_sse2( s16 dct[8][8], s32 dequant_mf[6][8][8], s32 i_qp );
	void z264_dequant_4x4_flat16_sse2( s16 dct[4][4], s32 dequant_mf[6][4][4], s32 i_qp );
	void z264_dequant_8x8_flat16_sse2( s16 dct[8][8], s32 dequant_mf[6][8][8], s32 i_qp );


	void z264_denoise_dct_sse2( s16 *dct, u32 *sum, u16 *offset, s32 size );
	void z264_denoise_dct_ssse3( s16 *dct, u32 *sum, u16 *offset, s32 size );

	s32 z264_decimate_score15_sse2  ( s16 *dct );
	s32 z264_decimate_score15_ssse3 ( s16 *dct );
	s32 z264_decimate_score16_sse2  ( s16 *dct );
	s32 z264_decimate_score16_ssse3 ( s16 *dct );
	s32 z264_decimate_score64_sse2  ( s16 *dct );
	s32 z264_decimate_score64_ssse3 ( s16 *dct );

	s32 z264_coeff_last15_sse2( s16 *dct );
	s32 z264_coeff_last16_sse2( s16 *dct );
	s32 z264_coeff_last64_sse2( s16 *dct );

	s32 z264_coeff_last15_sse2_lzcnt( s16 *dct );
	s32 z264_coeff_last16_sse2_lzcnt( s16 *dct );
	s32 z264_coeff_last64_sse2_lzcnt( s16 *dct );

	s32 z264_coeff_level_run16_sse2_lzcnt( s16 *dct, x264_run_level_t *runlevel );
	s32 z264_coeff_level_run16_sse2( s16 *dct, x264_run_level_t *runlevel );
	s32 z264_coeff_level_run15_sse2( s16 *dct, x264_run_level_t *runlevel );
	s32 z264_coeff_level_run15_sse2_lzcnt( s16 *dct, x264_run_level_t *runlevel );
//}}quant.h


	//{{ mc-c.c
#define DECL_SUF( func, args )\
	void y##func##_mmxext args;\
	void z##func##_sse2 args;\
	void z##func##_ssse3 args;

	DECL_SUF( 264_pixel_avg_16x16, ( u8 *, s32, u8 *, s32, u8 *, s32, s32 ))
	DECL_SUF( 264_pixel_avg_16x8,  ( u8 *, s32, u8 *, s32, u8 *, s32, s32 ))
	DECL_SUF( 264_pixel_avg_8x16,  ( u8 *, s32, u8 *, s32, u8 *, s32, s32 ))
	DECL_SUF( 264_pixel_avg_8x8,   ( u8 *, s32, u8 *, s32, u8 *, s32, s32 ))
	DECL_SUF( 264_pixel_avg_8x4,   ( u8 *, s32, u8 *, s32, u8 *, s32, s32 ))
	DECL_SUF( 264_pixel_avg_4x8,   ( u8 *, s32, u8 *, s32, u8 *, s32, s32 ))
	DECL_SUF( 264_pixel_avg_4x4,   ( u8 *, s32, u8 *, s32, u8 *, s32, s32 ))
	DECL_SUF( 264_pixel_avg_4x2,   ( u8 *, s32, u8 *, s32, u8 *, s32, s32 ))

#undef DECL_SUF



#define PIXEL_AVG_W(width,cpu)\
	extern void z264_pixel_avg2_w##width##_##cpu( u8 *, s32, u8 *, s32, u8 *, s32 );

	/* This declares some functions that don't exist, but that isn't a problem. */
#define PIXEL_AVG_WALL(cpu)\
	PIXEL_AVG_W(4,cpu);		\
	PIXEL_AVG_W(8,cpu);		\
	PIXEL_AVG_W(12,cpu);	\
	PIXEL_AVG_W(16,cpu);	\
	PIXEL_AVG_W(20,cpu);

	PIXEL_AVG_WALL(cache32_sse2)
	PIXEL_AVG_WALL(cache64_sse2)
	PIXEL_AVG_WALL(sse2)
	PIXEL_AVG_WALL(sse2_misalign)
	PIXEL_AVG_WALL(cache64_ssse3)

#undef PIXEL_AVG_WALL
#undef PIXEL_AVG_W

	extern void z264_frame_init_lowres_core_sse2
	(
	u8 *src0, u8 *dst0, u8 *dsth, u8 *dstv, u8 *dstc,
	s32 src_stride, s32 dst_stride, s32 width, s32 height
	);

	extern void z264_frame_init_lowres_core_ssse3
	(
	u8 *src0, u8 *dst0, u8 *dsth, u8 *dstv, u8 *dstc,
	s32 src_stride, s32 dst_stride, s32 width, s32 height
	);

	//}}



//{{mc.c

#define z264_sfence _mm_sfence 

#if !defined(STX64)
	void y264_mc_copy_w4_mmx( u8 *, s32, u8 *, s32, s32 );
	void y264_mc_copy_w8_mmx( u8 *, s32, u8 *, s32, s32 );
	void y264_mc_copy_w16_mmx( u8 *, s32, u8 *, s32, s32 );
	void y264_prefetch_fenc_mmxext( u8 *, s32, u8 *, s32, s32 );
	void y264_prefetch_ref_mmxext( u8 *, s32, s32 );
	void y264_mc_chroma_mmxext( u8 *src, s32 i_src_stride,
		u8 *dst, s32 i_dst_stride,
		s32 dx, s32 dy, s32 i_width, s32 i_height );
	void y264_plane_copy_mmxext(u8 *dst, s32 i_dst,u8 *src, s32 i_src, s32 w, s32 h);
	void *y264_memcpy_aligned_mmx( void * dst, const void * src, size_t n );
	void y264_memzero_aligned_mmx( void * dst, s32 n );
	void y264_integral_init4v_mmx( u16 *sum8, u16 *sum4, s32 stride );
	void y264_integral_init8v_mmx( u16 *sum8, s32 stride );
#endif

	//{{ imp from mmx
	void z264_mc_copy_w4_sse2( u8 *, s32, u8 *, s32, s32 );
	void z264_mc_copy_w8_sse2( u8 *, s32, u8 *, s32, s32 );
	void z264_prefetch_fenc_sse2( u8 *, s32, u8 *, s32, s32 );
	void z264_prefetch_ref_sse2( u8 *, s32, s32 );
	void z264_plane_copy_sse2(u8 *dst, s32 i_dst,u8 *src, s32 i_src, s32 w, s32 h);
	//}}

	void z264_mc_copy_w16_sse2( u8 *, s32, u8 *, s32, s32 );
	void z264_mc_copy_w16_sse3( u8 *, s32, u8 *, s32, s32 );

	void z264_mc_copy_w16_aligned_sse2( u8 *, s32, u8 *, s32, s32 );

	void z264_mc_chroma_sse2( u8 *src, s32 i_src_stride,
		u8 *dst, s32 i_dst_stride,
		s32 dx, s32 dy, s32 i_width, s32 i_height );
	void z264_mc_chroma_ssse3( u8 *src, s32 i_src_stride,
		u8 *dst, s32 i_dst_stride,
		s32 dx, s32 dy, s32 i_width, s32 i_height );

	void z264_mc_chroma_ssse3_cache64( u8 *src, s32 i_src_stride,
		u8 *dst, s32 i_dst_stride,
		s32 dx, s32 dy, s32 i_width, s32 i_height );

	void *z264_memcpy_aligned_sse2( void * dst, const void * src, size_t n );
	void z264_memzero_aligned_sse2( void * dst, s32 n );

	void z264_integral_init4h_sse4( u16 *sum, u8 *pix, s32 stride );
	void z264_integral_init8h_sse4( u16 *sum, u8 *pix, s32 stride );

	void z264_integral_init4v_sse2( u16 *sum8, u16 *sum4, s32 stride );
	void z264_integral_init8v_sse2( u16 *sum8, s32 stride );

	void z264_integral_init4v_ssse3( u16 *sum8, u16 *sum4, s32 stride );

	void z264_mbtree_propagate_cost_sse2( s32 *dst, u16 *propagate_in, u16 *intra_costs,
		u16 *inter_costs, u16 *inv_qscales, s32 len );
//}}mc.c


//{{ pixel.h
	//{{ zzdeblock_64.c;
	extern void z264_deblock_v_chroma_sse2( uint8_t *pix, int stride, int alpha, int beta, int8_t *tc0 );
	extern void z264_deblock_h_chroma_sse2( uint8_t *pix, int stride, int alpha, int beta, int8_t *tc0 );
	extern void z264_deblock_v_chroma_intra_sse2( uint8_t *pix, int stride, int alpha, int beta );
	extern void z264_deblock_h_chroma_intra_sse2( uint8_t *pix, int stride, int alpha, int beta );

	extern void z264_deblock_h_luma_sse2( uint8_t *pix, int stride, int alpha, int beta, int8_t *tc0 );
	extern void z264_deblock_v8_luma_sse2( uint8_t *pix, int stride, int alpha, int beta, int8_t *tc0 );
	extern void z264_deblock_h_luma_intra_sse2( uint8_t *pix, int stride, int alpha, int beta );
	extern void z264_deblock_v8_luma_intra_sse2( uint8_t *pix, int stride, int alpha, int beta );
	//}}


#define _DECL_PIXELS( ret, name, prefix, suffix, args ) \
	ret prefix##_pixel_##name##_16x16_##suffix args;\
	ret prefix##_pixel_##name##_16x8_##suffix args;\
	ret prefix##_pixel_##name##_8x16_##suffix args;\
	ret prefix##_pixel_##name##_8x8_##suffix args;\
	ret prefix##_pixel_##name##_8x4_##suffix args;\
	ret prefix##_pixel_##name##_4x8_##suffix args;\
	ret prefix##_pixel_##name##_4x4_##suffix args;\

#define _DECL_X1( name, prefix, suffix ) \
	_DECL_PIXELS( s32, name, prefix, suffix, ( u8* pix1, s32 s1, u8* pix2, s32 s2) )

#define _DECL_X4( name, prefix, suffix ) \
	_DECL_PIXELS( void, name##_x3, prefix, suffix, ( u8 *fenc, u8 *pix0, u8 *pix1, u8 *pix2, s32 i_stride, s32* scores ) )\
	_DECL_PIXELS( void, name##_x4, prefix, suffix, ( u8 *fenc, u8 *pix0, u8 *pix1, u8 *pix2, u8 *pix3, s32 i_stride, s32* scores ) )


	_DECL_X1( ssd, y264, mmxext )		//
	_DECL_X1( ssd, y264, sse2 )			// 4x4
	_DECL_X1( ssd, y264, sse2slow )		// 4x4
	_DECL_X1( ssd, y264, ssse3 )		//

	_DECL_X1( sad, y264, mmxext )		//
	_DECL_X1( sad, z264, sse2 )			// 4x4,4x8,8x4,8x8

	_DECL_X4( sad, z264,sse2_misalign ) // 4x4,4x8,8x4,8x8,8x16,(16x8,16x16);

	_DECL_X1( sad, z264,sse3 )			// 4x4,4x8,8x4,8x8,8x16,(16x8,16x16);

	_DECL_X1( sad, z264,sse2_aligned )	// 4x4,4x8,8x4,8x8,(8x16,16x8,16x16);

	_DECL_X4( sad, y264,mmxext )		//
	_DECL_X4( sad, z264,sse2 )			// 4x4
	_DECL_X4( sad, z264,sse3 )			// 4x4,4x8,8x4,8x8,8x16,(16x8,16x16);

	_DECL_X1( ssd, y264,mmx )		//
	_DECL_X1( ssd, z264,sse2slow )	//4x4 4x8
	_DECL_X1( ssd, z264,sse2 )		//4x4 4x8
	_DECL_X1( ssd, z264,ssse3 )		//

	_DECL_X1( satd,y264, mmxext )	//
	_DECL_X1( satd, z264,sse2 )		// 4x4
	_DECL_X1( satd, z264,ssse3 )	//
	_DECL_X1( satd, z264,sse4 )		//

	_DECL_X1( sa8d, y264, mmxext )  // (8x8,16x16)
	_DECL_X1( sa8d, z264, sse2 )	// (8x8,16x16)
	_DECL_X1( sa8d, z264, ssse3 )	// (8x8,16x16)
	_DECL_X1( sa8d, z264, sse4)		// (8x8,16x16)

	_DECL_X1( sad, y264, cache32_mmxext ); // (8x16
	_DECL_X4( sad, y264, cache32_mmxext ); // 4x4

	_DECL_X1( sad, y264, cache64_mmxext ); // (8x4,8x8,8x16
	_DECL_X4( sad, y264, cache64_mmxext ); // (8x8,8x16

	_DECL_X1( sad, z264, cache64_sse2 ); // (16x16,
	_DECL_X4( sad, z264, cache64_sse2 ); // (8x16,16X16
	
	_DECL_X1( sad, z264, cache64_ssse3 ); // (16x8,16x16
	_DECL_X4( sad, z264, cache64_ssse3 ); // (16x8,16x16

	_DECL_PIXELS( s32, var, y264, mmxext, ( u8 *pix, s32 i_stride )) // (8x8,16x16)
	_DECL_PIXELS( s32, var, z264, sse2,   ( u8 *pix, s32 i_stride )) // (8x8,16x16)

	_DECL_PIXELS( u64, hadamard_ac, y264, mmxext, ( u8 *pix, s32 i_stride ))//

	_DECL_PIXELS( u64, hadamard_ac, z264, sse2,   ( u8 *pix, s32 i_stride ))//
	_DECL_PIXELS( u64, hadamard_ac, z264, ssse3,  ( u8 *pix, s32 i_stride ))//
	_DECL_PIXELS( u64, hadamard_ac, z264, sse4,   ( u8 *pix, s32 i_stride ))//

	void y264_intra_sad_x3_4x4_mmxext   ( u8 *pa, u8 *pb, s32 *scores );//
	void y264_intra_sad_x3_8x8_mmxext   ( u8 *pa, u8 *pb, s32 *scores  );//
	void y264_intra_sad_x3_8x8c_mmxext  ( u8 *pa, u8 *pb, s32 *scores  );//
	void y264_intra_sad_x3_16x16_mmxext ( u8 *pa, u8 *pb, s32 *scores  );//

	void z264_intra_sad_x3_4x4_sse2   ( u8 *pa, u8 *pb, s32 *scores );//
	void z264_intra_sad_x3_8x8_sse2   ( u8 *pa, u8 *pb, s32 *scores  );//
	void z264_intra_sad_x3_8x8c_sse2  ( u8 *pa, u8 *pb, s32 *scores  );//
	void z264_intra_sad_x3_16x16_sse2   ( u8 *pa, u8 *pb, s32 *scores  ); //

	void z264_intra_sad_x3_8x8c_ssse3   ( u8 *pa, u8 *pb, s32 *scores  ); //
	void z264_intra_sad_x3_16x16_ssse3  ( u8 *pa, u8 *pb, s32 *scores  ); //

	void y264_intra_sa8d_x3_8x8_core_mmxext( u8 *, s16 [2][8], s32 * ); //
	void z264_intra_sa8d_x3_8x8_core_sse2  ( u8 *, s16 [2][8], s32 * ); //
	void z264_intra_sa8d_x3_8x8_core_ssse3 ( u8 *, s16 [2][8], s32 * ); //

	//{{ imp at predict-c.c
	void z264_intra_sa8d_x3_8x8_sse2  ( u8 *fenc, u8 edge[33], s32 res[3] );
	void z264_intra_sa8d_x3_8x8_ssse3 ( u8 *fenc, u8 edge[33], s32 res[3] );
	//}}

	void y264_intra_satd_x3_4x4_mmxext  ( u8 *pa, u8 *pb, s32 *scores );//
	void y264_intra_satd_x3_8x8c_mmxext ( u8 *pa, u8 *pb, s32 *scores  );//
	void y264_intra_satd_x3_16x16_mmxext( u8 *pa, u8 *pb, s32 *scores  );//

	void z264_intra_satd_x3_4x4_sse2  ( u8 *pa, u8 *pb, s32 *scores );//x
	void z264_intra_satd_x3_8x8c_sse2 ( u8 *pa, u8 *pb, s32 *scores  );//x
	void z264_intra_satd_x3_16x16_sse2( u8 *pa, u8 *pb, s32 *scores  );//x

	void z264_intra_satd_x3_4x4_ssse3   ( u8 *pa, u8 *pb, s32 *scores  );//
	void z264_intra_satd_x3_8x8c_ssse3  ( u8 *pa, u8 *pb, s32 *scores  );//
	void z264_intra_satd_x3_16x16_ssse3 ( u8 *pa, u8 *pb, s32 *scores  );//


	void y264_pixel_ssim_4x4x2_core_mmxext( const u8 *pix1, s32 stride1,
		const u8 *pix2, s32 stride2, s32 sums[2][4] );//

	void z264_pixel_ssim_4x4x2_core_sse2( const u8 *pix1, s32 stride1,
		const u8 *pix2, s32 stride2, s32 sums[2][4] );//

	float z264_pixel_ssim_end4_sse2( s32 sum0[5][4], s32 sum1[5][4], s32 width );//

	s32  y264_pixel_var2_8x8_mmxext( u8 *, s32, u8 *, s32, s32 * );//

	s32  z264_pixel_var2_8x8_sse2( u8 *, s32, u8 *, s32, s32 * );//
	s32  z264_pixel_var2_8x8_ssse3( u8 *, s32, u8 *, s32, s32 * );//



#define _DECL_ADS( size, prefix, suffix ) \
	s32 prefix##_pixel_ads##size##_##suffix( s32 enc_dc[size], u16 *sums, s32 delta,\
	u16 *cost_mvx, s16 *mvs, s32 width, s32 thresh,u8* masks );

	_DECL_ADS( 4, y264, mmxext )//
	_DECL_ADS( 2, y264, mmxext )//
	_DECL_ADS( 1, y264, mmxext )//
	_DECL_ADS( 4, z264, sse2 )//
	_DECL_ADS( 2, z264, sse2 )//
	_DECL_ADS( 1, z264, sse2 )//
	_DECL_ADS( 4, z264, ssse3 )//
	_DECL_ADS( 2, z264, ssse3 )//
	_DECL_ADS( 1, z264, ssse3 )//

#undef _DECL_PIXELS
#undef _DECL_X1
#undef _DECL_X4
#undef _DECL_ADS

	s32 y264_pixel_ads_mvs( s16 *mvs, u8 *masks, s32 width );
//}} pixel.h


//{{ predict.c   10 zfunc left
	extern void y264_predict_16x16_v_mmx( u8 *src );
	extern void z264_predict_16x16_v_sse2( u8 *src );

	extern void y264_predict_16x16_h_mmxext( u8 *src );
	extern void z264_predict_16x16_h_sse2( u8 *src ); //++
	extern void z264_predict_16x16_h_ssse3( u8 *src );

	extern void y264_predict_16x16_dc_core_mmxext( u8 *src, s32 i_dc_left );
	extern void z264_predict_16x16_dc_core_sse2( u8 *src, s32 i_dc_left );

	extern void y264_predict_16x16_dc_left_core_mmxext( u8 *src, s32 i_dc_left );
	extern void z264_predict_16x16_dc_left_core_sse2( u8 *src, s32 i_dc_left );
	
	extern void y264_predict_16x16_dc_top_mmxext( u8 *src );
	extern void z264_predict_16x16_dc_top_sse2( u8 *src );
	
	extern void y264_predict_16x16_p_core_mmxext( u8 *src, s32 i00, s32 b, s32 c );
	extern void z264_predict_16x16_p_core_sse2( uint8_t *src, s32 i00, s32 b, s32 c );

	extern void y264_predict_8x8c_p_core_mmxext( u8 *src, s32 i00, s32 b, s32 c );
	extern void z264_predict_8x8c_p_core_sse2( u8 *src, s32 i00, s32 b, s32 c );

	extern void y264_predict_8x8c_dc_core_mmxext( u8 *src, s32 s2, s32 s3 );
	extern void z264_predict_8x8c_dc_core_sse2( u8 *src, s32 s2, s32 s3 ); //++

	extern void y264_predict_8x8c_dc_top_mmxext( u8 *src );
	extern void z264_predict_8x8c_dc_top_sse2( u8 *src );  //++

	extern void y264_predict_8x8c_v_mmx( u8 *src );
	extern void z264_predict_8x8c_v_sse2( u8 *src ); //++

	extern void y264_predict_8x8c_h_mmxext( u8 *src );
	extern void z264_predict_8x8c_h_sse2( u8 *src );  //++
	extern void z264_predict_8x8c_h_ssse3( u8 *src );

	extern void y264_predict_8x8_v_mmxext( u8 *src, u8 edge[33] );
	extern void z264_predict_8x8_v_sse2( u8 *src, u8 edge[33] );   //++

	extern void y264_predict_8x8_h_mmxext( u8 *src, u8 edge[33] );
	extern void z264_predict_8x8_h_sse2( u8 *src, u8 edge[33] );    //++

	extern void y264_predict_8x8_hd_mmxext( u8 *src, u8 edge[33] );
	extern void z264_predict_8x8_hd_sse2( u8 *src, u8 edge[33] );
	extern void z264_predict_8x8_hd_ssse3( u8 *src, u8 edge[33] );
	
	extern void y264_predict_8x8_hu_mmxext( u8 *src, u8 edge[33] );
	extern void z264_predict_8x8_hu_sse2( u8 *src, u8 edge[33] );
	extern void z264_predict_8x8_hu_ssse3( u8 *src, u8 edge[33] );

	extern void y264_predict_8x8_dc_mmxext( u8 *src, u8 edge[33] );
	extern void z264_predict_8x8_dc_sse2( u8 *src, u8 edge[33] );   // ++

	extern void y264_predict_8x8_dc_top_mmxext( u8 *src, u8 edge[33] );
	extern void z264_predict_8x8_dc_top_sse2( u8 *src, u8 edge[33] );    //++

	extern void y264_predict_8x8_dc_left_mmxext( u8 *src, u8 edge[33] );
	extern void z264_predict_8x8_dc_left_sse2( u8 *src, u8 edge[33] );   //++

	extern void y264_predict_8x8_ddl_mmxext( u8 *src, u8 edge[33] );
	extern void z264_predict_8x8_ddl_sse2( u8 *src, u8 edge[33] );
	
	extern void y264_predict_8x8_ddr_mmxext( u8 *src, u8 edge[33] );
	extern void z264_predict_8x8_ddr_sse2( u8 *src, u8 edge[33] );

	//{{ unused;
	extern void z264_predict_8x8_vl_sse2(u8 *src, u8 edge[33] );
	extern void z264_predict_8x8_vr_sse2(u8 *src, u8 edge[33] );
	//}}

	extern void y264_predict_8x8_vr_core_mmxext(u8 *src, u8 edge[33] );
	extern void z264_predict_8x8_vr_core_sse2(u8 *src, u8 edge[33] );    //++

	extern void y264_predict_8x8_filter_mmxext(u8 *src, u8 edge[33], s32 i_neighbor, s32 i_filters );
	extern void z264_predict_8x8_filter_sse2(u8 *src, u8 edge[33], s32 i_neighbor, s32 i_filters );  //++
	extern void z264_predict_8x8_filter_ssse3(u8 *src, u8 edge[33], s32 i_neighbor, s32 i_filters );
	
	extern void y264_predict_4x4_ddl_mmxext(u8 *src );
	extern void z264_predict_4x4_ddl_sse2(u8 *src );   //++

	extern void y264_predict_4x4_ddr_mmxext(u8 *src );
	extern void z264_predict_4x4_ddr_sse2(u8 *src );  //++
	extern void z264_predict_4x4_ddr_ssse3(u8 *src );

	extern void y264_predict_4x4_vl_mmxext(u8 *src );
	extern void z264_predict_4x4_vl_sse2(u8 *src );  //++

	extern void y264_predict_4x4_vr_mmxext(u8 *src );
	extern void z264_predict_4x4_vr_sse2(u8 *src );   //++
	extern void z264_predict_4x4_vr_ssse3(u8 *src );

	extern void y264_predict_4x4_hd_mmxext(u8 *src );
	extern void z264_predict_4x4_hd_sse2(u8 *src ); //++
	extern void z264_predict_4x4_hd_ssse3(u8 *src );

	extern void y264_predict_4x4_dc_mmxext(u8 *src );
	extern void z264_predict_4x4_dc_sse2(u8 *src ); //++

	extern void y264_predict_4x4_hu_mmxext(u8 *src );
	extern void z264_predict_4x4_hu_sse2(u8 *src );   //++

//}}



#if defined( __cplusplus )
}
#endif


#endif // __Z264_H__