

#ifndef __STX_IO_XUDP_H__
#define __STX_IO_XUDP_H__

/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/


#include "stx_base_type.h"


#include "stx_io.h"



#if defined( __cplusplus )
extern "C" {
#endif



stx_xio* stx_create_io_xudp();


#if defined( __cplusplus )
}
#endif


#endif /*    __STX_IO_XUDP_H__   */ 
