/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-11
***********************************************************************************/

#ifndef __STX_H263_PARSER_H__
#define __STX_H263_PARSER_H__

#include "base_class.h"



#if defined( __cplusplus )
extern "C" {
#endif

	STX_API	STX_COM(h263_parser);

	STX_API	CREATE_STX_COM_DECL(stx_stream_parser,h263_parser);


#if defined( __cplusplus )
}
#endif


#endif // __STX_H263_PARSER_H__