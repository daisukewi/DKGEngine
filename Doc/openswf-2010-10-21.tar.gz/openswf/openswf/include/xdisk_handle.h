// xdisk_handle.h: interface for the xdisk_handle class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_XDISK_HANDLE_H__FD741B3E_ED35_4F47_A2AC_60E739165D5B__INCLUDED_)
#define AFX_XDISK_HANDLE_H__FD741B3E_ED35_4F47_A2AC_60E739165D5B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include "stx_base_type.h"



typedef struct xdisk_handle xdisk_handle;

struct xdisk_handle{

	stx_err_handle		err;

	STX_RESULT			i_err_code;

	char				sz_err[MAX_PATH];

	HWND				h_wnd;

	BOOL				b_alloc;

	stx_err_cmd			em_cmd;
	
	size_t				i_hparam;

	size_t				i_lparam;
};


xdisk_handle*		create_xdisk_handle(xdisk_handle* hnd,HWND h_wnd);



#endif // !defined(AFX_XDISK_HANDLE_H__FD741B3E_ED35_4F47_A2AC_60E739165D5B__INCLUDED_)
