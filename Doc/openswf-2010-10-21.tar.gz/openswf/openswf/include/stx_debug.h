/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/
#ifndef __STX_DEBUG_H__
#define __STX_DEBUG_H__

#include "stx_base_type.h"

#if defined( __cplusplus )
extern "C" {
#endif


#define STX_TRACE_CONSOLE		0x01
#define STX_TRACE_WINDOW		0x02
#define STX_INIT_THREAD			0x04
#define STX_INIT_NETWORK		0x08

#define GBD_DEBUG_TASK_MONITOR  0x010
#define GBD_DEBUG_PLUG_MONITOR  0x020
#define GBD_DEBUG_LAST_PLUG    0x040
#define GBD_DEBUG_TASK_STATUS  0x080


extern u32	g_i_debug;
extern void dbg_output(char* szdbg);
extern void (*stx_trace)(char* sz_err);

STX_RESULT	stx_debug_init( void (*dump_str)(char*),u32 i_debug );
void		stx_debug_cleanup();
void        stx_global_lock();
void        stx_global_unlock();
void*		debug_malloc(size_t i_size, const char* file,s32 line);
void*		debug_mallocz(size_t i_size, const char* file,s32 line);
void*		debug_realloc(void* p_mem,size_t i_size, const char* file,s32 line );


#ifdef __USE_STX_DEBUG__

#define xmalloc(i_size)		debug_malloc(i_size,__THIS_FILE__,__LINE__)
#define xmallocz(i_size)	debug_mallocz(i_size,__THIS_FILE__,__LINE__)
#define xrealloc(p,i_size)	debug_realloc(p,i_size,__THIS_FILE__,__LINE__)

	void*	stx_malloc(size_t i_size, const char* sz_dump);
	void*   stx_realloc(void* p_mem,size_t i_size, const char* sz_dump );

#	ifdef __LINUX_LIB
		void stx_log(const char *fmt, ...); // __attribute__ ((__format__ (__printf__, 3, 4)));
#	else
		void stx_log(const char *fmt, ...);
#	endif

	void stx_assert( b32 b_normal );

#else

	void* xmalloc(size_t i_size);
	void* xmallocz(size_t i_size);
	void* xrealloc(void* p_mem,size_t i_size);

#	define stx_malloc(a,b)		xmalloc(a)
#	define stx_realloc(a,b,c)	xrealloc(a,b)

#	define stx_log(fmt,...)
#	define stx_assert(b)

#endif

	void	stx_free(void* p_mem);

	char* stx_err_string(STX_RESULT i_err);

#if defined( __cplusplus )
}
#endif


#endif /*  __STX_DEBUG_H__   */ 
