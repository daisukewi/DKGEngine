
#ifndef __STX_MEDIA_DATA_BASE_H__
#define __STX_MEDIA_DATA_BASE_H__

/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/


#include "base_class.h"


#if defined( __cplusplus )
extern "C" {
#endif




stx_media_data* stx_media_data_base_create(stx_media_data* p_mda);



#if defined( __cplusplus )
}
#endif


#endif /* __STX_MEDIA_DATA_BASE_H__ */ 