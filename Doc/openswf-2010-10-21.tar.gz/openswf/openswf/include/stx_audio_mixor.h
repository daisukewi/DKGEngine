/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-06
***********************************************************************************/
#ifndef __STX_AUDIO_MIXOR_H__
#define __STX_AUDIO_MIXOR_H__


#include "base_class.h"


#if defined( __cplusplus )
extern "C" {
#endif


#define MAX_AUDIO_SLOT_NUM		24
#define MAX_AUDIO_SLOT_TIME		125
#define MAX_AUDIO_BUFFER_TIME   (MAX_AUDIO_SLOT_NUM*MAX_AUDIO_SLOT_TIME) // milisecond;
#define MAX_AUDIO_SMAPLE_TIME   MAX_AUDIO_SLOT_TIME 


#define CONVERT_CH_5p1T6p1(A)  ( (A*7) / 6 )  
#define CONVERT_CH_5p1T7p1(A)  ( (A*8) / 6 )  
#define CONVERT_CH_6p1T7p1(A)  ( (A*8) / 7 )  


#define STX_LF  0x01
#define STX_RF  0x02
#define STX_LB  0x04
#define STX_RB  0x08
#define STX_CT  0x10
#define STX_SW  0x20
#define STX_LS  0x40
#define STX_RS  0x80
#define STX_CB  0x100

#define STX_MIX 0x8000


#define	aout_dtype_1ch_mono_16bit_pcm			(STX_CT)
#define	aout_dtype_2ch_stereo_16bit_pcm 		(STX_LF|STX_RF)//

#define	aout_dtype_2ch_stereo_16bit_pcm_left 	(STX_MIX|STX_LF)//
#define	aout_dtype_2ch_stereo_16bit_pcm_right 	(STX_MIX|STX_RF)//

#define	aout_dtype_4ch_quad_16bit_pcm 			\
	(STX_LF|STX_RF|STX_LB|STX_RB) 

#define	aout_dtype_6ch_5point1_16bit_pcm 		\
	(STX_LF|STX_RF|STX_LB|STX_RB|STX_CT|STX_SW) 

#define	aout_dtype_7ch_6point1_16bit_pcm 		\
	(STX_LF|STX_RF|STX_LB|STX_RB|STX_CT|STX_SW|STX_CB) 

#define	aout_dtype_8ch_7point1_16bit_pcm 		\
	(STX_LF|STX_RF|STX_LB|STX_RB|STX_CT|STX_SW|STX_LS|STX_RS) 

#define	aout_dtype_2ch_mix_16bit_pcm 			\
	(STX_MIX|STX_LF|STX_RF)

	typedef  u32 STX_AUDCAP_CH;


#define STX_AUDCAP_FR_22050  1
#define STX_AUDCAP_FR_32000  2
#define STX_AUDCAP_FR_44100  4
#define STX_AUDCAP_FR_48000  8
#define STX_AUDCAP_FR_96000  16
	typedef  u32 STX_AUDCAP_FR;

	static u32 stx_audcap_fr2fr(STX_AUDCAP_FR fr){
		switch(fr){
			case STX_AUDCAP_FR_22050:
				return 22050;
			case STX_AUDCAP_FR_32000:
				return 32000;
			case STX_AUDCAP_FR_44100:
				return 44100;
			case STX_AUDCAP_FR_48000:
				return 48000;
			case STX_AUDCAP_FR_96000:
				return 96000;
			default:
				return 0;
		}
	}


#define STX_AUDCAP_SAMPLE_PCM16  1
#define STX_AUDCAP_SAMPLE_PCM24  2
#define STX_AUDCAP_SAMPLE_F32	 4
#define STX_AUDCAP_SAMPLE_SPDIF	 8
	typedef  u32 STX_AUDCAP_SAMPLE;

	static u32 stx_audcap_sample2sample(STX_AUDCAP_SAMPLE scap){
		switch(scap){
			case STX_AUDCAP_SAMPLE_PCM16:
				return 16;
			case STX_AUDCAP_SAMPLE_PCM24:
				return 24;
			case STX_AUDCAP_SAMPLE_F32:
				return 32;
			default:
				return 0;
		}
	}

	STX_INTERF(DownMixPart);
	STX_INTERF(dm_par_t);
	STX_INTERF(mm_dm_par_t);
	STX_INTERF(StxAudMixFx);
	STX_INTERF(StxAudioMixor);

	struct DownMixPart{
		s16 unit;  
		s16 clev;  
		s16 slev;
		s16 pad;     // align to 16 bytes; default is 0.5;
	};

	struct dm_par_t {
		f32 unit;  
		f32 clev;  
		f32 slev;
		f32 pad;
	} ; 

	struct mm_dm_par_t {
		s16 unit;  
		s16 clev;  
		s16 slev;
		s16 pad;
	};    

	typedef union UnionDownMixPart UnionDownMixPart;

	union UnionDownMixPart{
		DownMixPart  stDownMixPart[2];
		s64			nDownMixPart[2];
	};


	struct StxAudMixFx{
		// should align to 16 bytes;
		UnionDownMixPart       unDm;   

		// maximize zoom value; all the channels must use the same value;
		unsigned int           nZoomRatio[4];       
		unsigned int           tmp[8];   

		u32			  dwInput;
		u32			  dwOutput;

#define LX_AUDMIXFX_ZOOM        1
#define LX_AUDMIXFX_DOWNMIX     (1<<1)
#define LX_AUDMIXFX_SHARP       (1<<2)
#define LX_AUDMIXFX_DENOISE     (1<<3)
#define LX_AUDMIXFX_SRC_PLAIN   (1<<16)          // if the source data have been packed;
		u32           dwFlags;             // effect parameters exist in src data;

		u32           dwEffects;           // effect;

		STX_WAVEFORMATEXTENSIBLE wex;   // input format;
	};


#define  StxAudioMixor_vtdef() \
	void (*convert_6p1_to_7p1)(STX_HANDLE h,void* src,void* dst,s32 nLen,s32 nFlags );\
	void (*convert_5p1_to_7p1)(STX_HANDLE h,void* src,void* dst,s32 nLen,s32 nFlags );\
	void (*convert_5p1_to_6p1)(STX_HANDLE h,void* src,void* dst,s32 nLen,s32 nFlags );\
	s32  (*MaximizeAbsPcmCh  )(STX_HANDLE h,void* lpSrc,s32 nLen);\
	void (*OutputPcm1T2		 )(STX_HANDLE h,void *lpSrc, void *lpDst, s32 nLen,StxAudMixFx* pfx);\
	void (*OutputPcm2T2      )(STX_HANDLE h,void* lpSrc[2], void* lpDst, s32 nLen,StxAudMixFx* pfx);\
	void (*OutputPcm2T4      )(STX_HANDLE h,void* lpSrc[2], void* lpDst, s32 nLen,StxAudMixFx* pfx);\
	void (*OutputPcm2T6      )(STX_HANDLE h,void* lpSrc[2], void* lpDst, s32 nLen,StxAudMixFx* pfx);\
	void (*OutputPcm2p1T2    )(STX_HANDLE h,void* lpSrc[3], void* lpDst, s32 nLen,StxAudMixFx* pfx);\
	void (*OutputPcm2p1T4    )(STX_HANDLE h,void* lpSrc[3], void* lpDst, s32 nLen,StxAudMixFx* pfx);\
	void (*OutputPcm2p1T5p1  )(STX_HANDLE h,void* lpSrc[3], void* lpDst, s32 nLen,StxAudMixFx* pfx);\
	void (*OutputPcm3p0T2    )(STX_HANDLE h,void* lpSrc[3], void* lpDst, s32 nLen,StxAudMixFx* pfx);\
	void (*OutputPcm3p0T4    )(STX_HANDLE h,void* lpSrc[3], void* lpDst, s32 nLen,StxAudMixFx* pfx);\
	void (*OutputPcm3p0T5p1  )(STX_HANDLE h,void* lpSrc[3], void* lpDst, s32 nLen,StxAudMixFx* pfx);\
	void (*OutputPcm2p2T2    )(STX_HANDLE h,void* lpSrc[4], void* lpDst, s32 nLen,StxAudMixFx* pfx);\
	void (*OutputPcm2p2T4    )(STX_HANDLE h,void* lpSrc[4], void* lpDst, s32 nLen,StxAudMixFx* pfx);\
	void (*OutputPcm2p2T5p1  )(STX_HANDLE h,void* lpSrc[4], void* lpDst, s32 nLen,StxAudMixFx* pfx);\
	void (*OutputPcm3p1T2    )(STX_HANDLE h,void* lpSrc[4], void* lpDst, s32 nLen,StxAudMixFx* pfx);\
	void (*OutputPcm3p1T4    )(STX_HANDLE h,void* lpSrc[4], void* lpDst, s32 nLen,StxAudMixFx* pfx);\
	void (*OutputPcm3p1T5p1  )(STX_HANDLE h,void* lpSrc[4], void* lpDst, s32 nLen,StxAudMixFx* pfx);\
	void (*OutputPcm5p1T2    )(STX_HANDLE h,void* lpSrc[6], void *lpDst, s32 nLen,StxAudMixFx* pfx);\
	void (*OutputPcm5p1T4    )(STX_HANDLE h,void* lpSrc[6], void *lpDst, s32 nLen,StxAudMixFx* pfx);\
	void (*OutputPcm5p1T5p1  )(STX_HANDLE h,void* lpSrc[6], void* lpDst, s32 nLen,StxAudMixFx* pfx);\
	void (*OutputPcmCh5p1T6p1)(STX_HANDLE h,void* lpSrc, void* lpDst, s32 nLen,StxAudMixFx* pfx);\
	void (*OutputPcmCh5p1T7p1)(STX_HANDLE h,void* lpSrc, void* lpDst, s32 nLen,StxAudMixFx* pfx);\
	void (*OutputPcmCh6p1T7p1)(STX_HANDLE h,void* lpSrc, void* lpDst, s32 nLen,StxAudMixFx* pfx);\
	void (*OutputPcm24       )(STX_HANDLE h,void* lpSrc, void* lpDst, s32 nLen,StxAudMixFx* pfx);\
	void (*OutputPcmPlain    )(STX_HANDLE h,void* lpSrc, void* lpDst, s32 nLen,StxAudMixFx* pfx);\
	void (*OutputPcmLeft     )(STX_HANDLE h,void* lpSrc, void* lpDst, s32 nLen,StxAudMixFx* pfx);\
	void (*OutputPcmRight    )(STX_HANDLE h,void* lpSrc, void* lpDst, s32 nLen,StxAudMixFx* pfx);\
	STX_RESULT (*audiomixor_transform)\
	(\
		STX_HANDLE			h,\
		u8					*src,\
		size_t				i_src_size,\
		stx_media_data*		lpDst,\
		StxAudMixFx*		pFx \
	);\
	void (*audiomixor_reset) (STX_HANDLE h);\
	void (*audiomixor_close) (STX_HANDLE h);\


	struct StxAudioMixor{
		StxAudioMixor_vtdef()
	};


	StxAudioMixor*		CreateStxAudioMixor(u32 mmflags);



#if defined( __cplusplus )
}
#endif

#endif // __STX_AUDIO_MIXOR_H__