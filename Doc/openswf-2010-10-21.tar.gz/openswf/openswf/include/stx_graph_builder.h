
#ifndef __STX_GRAPH_BUILDER_H__
#define __STX_GRAPH_BUILDER_H__

/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/


#include "base_class.h"


#if defined( __cplusplus )
extern "C" {
#endif

extern char* g_szStreamX_BaseGraphBuilder;

STX_API
STX_COM(base_graph_builder);

STX_API
CREATE_STX_COM_DECL(stx_base_graph_builder,base_graph_builder);


#if defined( __cplusplus )
}
#endif


#endif /* __STX_GRAPH_BUILDER_H__ */ 