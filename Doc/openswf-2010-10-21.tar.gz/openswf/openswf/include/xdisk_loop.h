/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/
#ifndef __STX_LOOP_H__
#define __STX_LOOP_H__

#include "stdio.h"
#include "stdlib.h"
#include "memory.h"

#include "stx_base_type.h"



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
typedef struct xloop xloop;

struct xloop{
	s32				size;
	s32				w;
	s32				r;
	s32				FreeSlot;
	void**			buffer;
};

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
stx_inline void xloopGetDataDepth(xloop* p_loop,int* pnFree,int* pnUsed)
{
	*pnFree = p_loop->FreeSlot;

	*pnUsed = p_loop->size - p_loop->FreeSlot;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
stx_inline s32 xloopIsFull(xloop* p_loop)
{
	return p_loop->FreeSlot == 0;	
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
stx_inline s32 xloopIsEmpty(xloop* p_loop)
{ 
	return p_loop->FreeSlot == p_loop->size;	
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
stx_inline void xloopFlush(xloop* p_loop)
{
	p_loop->w = p_loop->r = 0;

	p_loop->FreeSlot = p_loop->size;

	memset((void*)p_loop->buffer,0,p_loop->size * sizeof(void*) );
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
stx_inline void xloopRelease(xloop* p_loop)	
{

	if (p_loop->buffer ) {

		free( (void*)p_loop->buffer );

		p_loop->buffer = STX_NULL;
	}

	free( (void*)p_loop );
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
stx_inline xloop* xloopCreate(int MaxPointerNumber)
{

	xloop* p_loop;

	p_loop = (xloop*)malloc(sizeof(xloop));

	if( !p_loop ) {

		return STX_NULL;
	}

	p_loop->size = MaxPointerNumber;

	p_loop->buffer = (void**) malloc( p_loop->size * sizeof(void*) );

	if( !p_loop->buffer ) {

		xloopRelease(p_loop);

		return STX_NULL;
	}

	memset((void*)p_loop->buffer,0,p_loop->size * sizeof(void*) );

	p_loop->w = p_loop->r = 0;

	p_loop->FreeSlot = p_loop->size;

	return p_loop;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
stx_inline void* xloopPull(xloop* p_loop)
{

	void* p;

	if(p_loop->FreeSlot == p_loop->size){

		return 0;
	}

	p = p_loop->buffer[p_loop->r];

	p_loop->buffer[p_loop->r] = 0; /* important; */

	if(p_loop->r >= p_loop->w) 
		p_loop->FreeSlot = p_loop->r - p_loop->w + 1;
	else 
		p_loop->FreeSlot = p_loop->size - p_loop->w + p_loop->r + 1;

	p_loop->r ++;

	if(p_loop->r == p_loop->size)
		p_loop->r = 0;

	return p;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
stx_inline s32 xloopPush(xloop* p_loop,void* p)
{
	if(p_loop->FreeSlot==0)
		return 0;

	p_loop->buffer[p_loop->w] =  p ;
	p_loop->w ++;

	p_loop->FreeSlot --;

	if(p_loop->w == p_loop->size)
		p_loop->w = 0;

	return 1;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
stx_inline void* xloopTryPull(xloop* p_loop)	
{
	if(p_loop->FreeSlot==p_loop->size){

		return NULL;
	}

	return p_loop->buffer[p_loop->r];
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
stx_inline s32 xloopTryPush(xloop* p_loop)	
{
	if( ! p_loop->FreeSlot ){

		return 0;
	}

	return 1;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
stx_inline s32 xloopGetPushPos(xloop* p_loop)
{
	return p_loop->w;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
stx_inline s32 xloopGetPullPos(xloop* p_loop)
{
	return p_loop->r;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
stx_inline void* xloopGetAt(xloop* p_loop,int pos)
{
	return p_loop->buffer[pos];
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
**************************************************************************/
stx_inline s32 xloopGetFree(xloop* p_loop)
{
	return p_loop->FreeSlot;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
stx_inline s32 xloopGetUsed(xloop* p_loop)
{
	return p_loop->size - p_loop->FreeSlot;
}



#endif /* __STX_LOOP_H__*/
