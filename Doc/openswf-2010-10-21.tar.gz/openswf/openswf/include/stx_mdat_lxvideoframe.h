
#ifndef __STX_MDAT_LXVIDEOFRAME_H__
#define __STX_MDAT_LXVIDEOFRAME_H__

/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/


#include "base_class.h"

#include "stx_video_frame.h"


#if defined( __cplusplus )
extern "C" {
#endif


	stx_media_data* stx_mdat_lxvideoframe_create();



#if defined( __cplusplus )
}
#endif


#endif /* __STX_MDAT_LXVIDEOFRAME_H__ */ 