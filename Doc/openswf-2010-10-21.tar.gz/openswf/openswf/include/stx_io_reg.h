/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#ifndef __STX_IO_REG_H__2008_06_21
#define __STX_IO_REG_H__2008_06_21


#include "stx_base_type.h"

#include "stx_io.h"




#if defined( __cplusplus )
extern "C" {
#endif


	STX_API char*		make_register_string(char* server,char* url);

	STX_API stx_xio*	create_stx_io_reg();





#if defined( __cplusplus )
}
#endif


#endif /* __STX_IO_REG_H__2008_06_21*/