



#ifndef __STX_XUDP_SVR_H__
#define __STX_XUDP_SVR_H__

/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#include "stx_base_type.h"

#include "stx_io.h"


#if defined( __cplusplus )
extern "C" {
#endif


typedef struct stx_xudp_svr stx_xudp_svr;

struct stx_xudp_svr{

	void	(*close)( stx_xudp_svr* h_svr );


};

stx_xudp_svr*	stx_xudp_svr_create( char* sz_xini , stx_xio* h_xini );


#if defined( __cplusplus )
}
#endif


#endif /* __STX_XUDP_SVR_H__ */ 