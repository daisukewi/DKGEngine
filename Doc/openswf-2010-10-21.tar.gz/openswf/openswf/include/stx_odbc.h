#ifndef __STX_ODBC_H__
#define __STX_ODBC_H__

/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#include "stx_ini.h"


#if defined( __cplusplus )
extern "C" {
#endif

	

stx_xini*   stx_ini_create_odbc( char* sz_file_name, stx_xio* h_xio, int i_open_flags, int i_type );




#if defined( __cplusplus )
}
#endif



#endif /*   __STX_ODBC_H__ */ 
