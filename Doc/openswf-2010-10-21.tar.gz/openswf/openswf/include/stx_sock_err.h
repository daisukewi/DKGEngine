
#ifndef __STX_SOCK_ERR_H__
#define __STX_SOCK_ERR_H__

/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#include "stx_base_type.h"

#if defined( __cplusplus )
extern "C" {
#endif


typedef struct in_addr in_addr;

typedef struct sockaddr_in sockaddr_in;

typedef struct sockaddr sockaddr;

typedef struct timeval timeval;

STX_INTERF(iovec);
STX_INTERF(hostent);



#if defined (__WIN32_LIB )


#define setuid(a)  

typedef struct xfd_set {
        uint32_t   fd_count;      /* how many are SET? */
        uint32_t   fd_array[1];   /* an array of SOCKETs */
}xfd_set;

static int gDwWsaErr[] = {
	WSANOTINITIALISED   ,
	WSAENETDOWN         ,
	WSAEFAULT           ,
	WSAEINPROGRESS      ,
	WSAENOTCONN         ,
	WSAENOTSOCK         ,
	WSANOTINITIALISED   , 
	WSAENETDOWN         , 
	WSAEADDRINUSE       , 					  
	WSAEINTR            , 
	WSAEINPROGRESS      , 
	WSAEALREADY         , 
						 
	WSAEADDRNOTAVAIL    , 
	WSAEAFNOSUPPORT     , 
	WSAECONNREFUSED     , 
	WSAEFAULT           , 
	WSAEINVAL           , 
	WSAEISCONN          , 
	WSAENETUNREACH      , 
	WSAENOBUFS          , 
	WSAENOTSOCK         , 
	WSAETIMEDOUT        , 
	WSAEWOULDBLOCK      , 
	WSAEACCES           , 

	//<<send;
	WSANOTINITIALISED   , 
	WSAENETDOWN         , 
	WSAEACCES           ,
	WSAEINTR            ,
	WSAEINPROGRESS      ,
	WSAEFAULT           ,
	WSAENETRESET        ,
	WSAENOBUFS          ,
	WSAENOTCONN         ,
	WSAENOTSOCK         ,
	WSAEOPNOTSUPP       ,
	WSAESHUTDOWN        ,
	WSAEWOULDBLOCK      ,
	WSAEMSGSIZE         ,
	WSAEHOSTUNREACH     ,
	WSAEINVAL           ,
	WSAECONNABORTED     ,
	WSAECONNRESET       ,
	WSAETIMEDOUT        ,
	//>>
};

static char* gSzUnknownErr = "unknown error";

static char* gSzWsaErr[] = {
	"A successful WSAStartup call must occur before using this function. \n",
	"The network subsystem has failed. \n",
	"The name or the namelen parameter is not a valid part of the user address space, or the namelen parameter is too small. \n",
	"A blocking Windows Sockets 1.1 call is in progress, or the service provider is still processing a callback function. \n",
	"The socket is not connected.\n ",
	"The descriptor is not a socket. \n",
	"A successful WSAStartup call must occur before using this function. \n",
	"The network subsystem has failed. \n",
	"The socket's local address is already in use and the socket was not marked to allow address reuse with SO_REUSEADDR. \n",
	  /*This error usually occurs when executing bind, 
	  but could be delayed until this function if the bind was 
	  to a partially wildcard address (involving ADDR_ANY) and 
	  if a specific address needs to be committed at the time of this function. */
	"The blocking Windows Socket 1.1 call was canceled through WSACancelBlockingCall. \n",
	"A blocking Windows Sockets 1.1 call is in progress, or the service provider is still processing a callback function. \n",
	"A nonblocking connect call is in progress on the specified socket. \n",
		/*Note In order to preserve backward compatibility, 
		this error is reported as WSAEINVAL to Windows Sockets 1.1 applications 
		that link to either Winsock.dll or Wsock32.dll.
	*/
	"The remote address is not a valid address (such as ADDR_ANY). \n",
	"Addresses in the specified family cannot be used with this socket. \n",
	"The attempt to connect was forcefully rejected. \n",
	"The name or the namelen parameter is not a valid part of the user address space, the namelen parameter is too small, \n",
	/*
	or the name parameter contains incorrect address format for the associated address family. 
	*/
	
	"The parameter s is a listening socket. \n",
	"The socket is already connected (connection-oriented sockets only). \n",
	"The network cannot be reached from this host at this time. \n",
	"No buffer space is available. The socket cannot be connected. \n",
	"The descriptor is not a socket. \n",
	"Attempt to connect timed out without establishing a connection. \n",
	"The socket is marked as nonblocking and the connection cannot be completed immediately. \n",
	"Attempt to connect datagram socket to broadcast address failed because setsockopt option SO_BROADCAST is not enabled. \n",

	"A successful WSAStartup call must occur before using this function. \n",
	"The network subsystem has failed. \n",
	"The requested address is a broadcast address, but the appropriate flag was not set. \n Call setsockopt with the SO_BROADCAST parameter to allow the use of the broadcast address. \n",
	"A blocking Windows Sockets 1.1 call was canceled through WSACancelBlockingCall. \n",
	"A blocking Windows Sockets 1.1 call is in progress, or the service provider is still processing a callback function. \n",
	"The buf parameter is not completely contained in a valid part of the user address space. \n",
	"The connection has been broken due to the keep-alive activity detecting a failure while the operation was in progress. \n",
	"No buffer space is available. \n",
	"The socket is not connected. \n",
	"The descriptor is not a socket. \n",
	"MSG_OOB was specified, but the socket is not stream-style such as type SOCK_STREAM, \n OOB data is not supported in the communication domain associated with this socket, \n or the socket is unidirectional and supports only receive operations. \n",
	"The socket has been shut down; it is not possible to send on a socket after shutdown has been invoked with how set to SD_SEND or SD_BOTH. \n",
	"The socket is marked as nonblocking and the requested operation would block. \n",
	"The socket is message oriented, and the message is larger than the maximum supported by the underlying transport. \n",
	"The remote host cannot be reached from this host at this time. \n",
	"The socket has not been bound with bind, or an unknown flag was specified, or MSG_OOB was specified for a socket with SO_OOBINLINE enabled. \n",
	"The virtual circuit was terminated due to a time-out or other failure. The application should close the socket as it is no longer usable. \n",
	"The virtual circuit was reset by the remote side executing a hard or abortive close. \n For UPD sockets, the remote host was unable to deliver a previously \n sent UDP datagram and responded with a <Port Unreachable> ICMP packet. \n The application should close the socket as it is no longer usable. \n",
	"The connection has been dropped, because of a network failure or because the system on the other end went down without notice. \n",
};



#endif /*    #if defined (__WIN32_LIB )  */ 






#if defined (__LINUX_LIB)


#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>

#include <sys/uio.h>
#include <unistd.h>
#include <errno.h>

#include <netdb.h>
#include <arpa/inet.h>


#define INVALID_SOCKET          (~0)
#define SOCKET_ERROR            (-1)

#define closesocket close

typedef ssize_t SOCKET ;

extern int 	gDwWsaErr[16];
extern char*    gSzUnknownErr;
extern char* 	gSzWsaErr[16];

typedef struct  fd_set xfd_set;


#endif /* __LINUX_LIB */


#if defined( __cplusplus )
}
#endif



#if defined (__LINUX_LIB)

	stx_inline s32 stx_get_sock_err()
	{
		return errno;
	}

#else

	stx_inline s32 stx_get_sock_err()
	{
		return WSAGetLastError();
	}


	stx_inline s32 inet_aton( char* sz_ip, struct in_addr* p_addr )
	{
		return p_addr->s_addr = inet_addr(sz_ip);
	}
#endif



stx_inline char* SockPrintWsaErr(s32 iRet)
{
	s32 i;

	for( i = 0; i < sizeof(gDwWsaErr) / sizeof(s32); i ++ ) {

		if( iRet == (s32)gDwWsaErr[i] ){

			return gSzWsaErr[i];
		}
	}

	return gSzUnknownErr;

}








#endif /* __STX_SOCK_ERR_H__*/

