/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#ifndef __STREAM_SLICE_H__
#define __STREAM_SLICE_H__



#include "base_interf.h"


#if defined( __cplusplus )
extern "C" {
#endif


#define STX_MAX_SLICE  32

#define DEFAULT_SLICE_BLOCK_SIZE (4*1024*1024)


STX_HANDLE  stream_slice_create(
	char* sz_cfg );

STX_RESULT  stream_slice_release( 
	STX_HANDLE	h_slice );


STX_RESULT  stream_slice_status( 
	STX_HANDLE	h_slice, 
	size_t*		i_status );

STX_RESULT  stream_slice_start( 
	STX_HANDLE	h_slice );

STX_RESULT  stream_slice_stop(
	STX_HANDLE	h_slice );


STX_HANDLE  stream_slice_fopen( 
	STX_HANDLE	h_slice, 
	char*		sz_file_body );

offset_t	stream_slice_fsize( 
   STX_HANDLE	h_slice, 
   STX_HANDLE	h_file);

offset_t	stream_slice_fpos( 
   STX_HANDLE	h_slice, 
   STX_HANDLE	h_file);

STX_RESULT  stream_slice_fseek( 
	STX_HANDLE	h_slice, 
	STX_HANDLE	h_file, 
	offset_t	pos, 
	size_t		i_whence );

STX_RESULT  stream_slice_fread( 
	STX_HANDLE	h_slice, 
	STX_HANDLE	h_file, 
	char*		buffer, 
	size_t		i_read );

STX_RESULT  stream_slice_fclose(
	STX_HANDLE	h_slice, 
	STX_HANDLE	h_file );


STX_RESULT  stream_slice_fadd( 
	STX_HANDLE	h_slice, 
	char*		sz_file_name);

STX_RESULT  stream_slice_fremove( 
	STX_HANDLE	h_slice, 
	char*		sz_file_name);


#if defined( __cplusplus )
}
#endif



#endif /* __STREAM_SLICE_H__*/