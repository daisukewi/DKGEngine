/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#ifndef __STX_LISTEN_FILTER_H__2008_06_21
#define __STX_LISTEN_FILTER_H__2008_06_21



#include "stx_all_codec.h"


#if defined( __cplusplus )
extern "C" {
#endif


#define FLAG_SET_GBD_HND	1
#define FLAG_SET_CALLBACK	2
#define FLAG_START_TASK		3
#define FLAG_SET_INPUTIO	4


	// {73463C4E-7C11-4edd-A746-3B5F6D8CA2F5}
	DECLARE_XGUID( STX_CLSID_ListenFilter,
	0x73463c4e, 0x7c11, 0x4edd, 0xa7, 0x46, 0x3b, 0x5f, 0x6d, 0x8c, 0xa2, 0xf5)
	extern char* g_szStreamX_ListenFilter;
	STX_API	STX_COM(ListenFilter);

	STX_API CREATE_STX_COM_DECL(stx_base_plugin,ListenFilter);


#if defined( __cplusplus )
}
#endif


#endif /*   __STX_LISTEN_FILTER_H__2008_06_21  */

