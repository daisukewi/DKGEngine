#ifndef __STX_EVENT_H__
#define __STX_EVENT_H__

/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/


#include "stx_base_type.h"

#if defined( __cplusplus )
extern "C" {
#endif



STX_HANDLE		stx_create_event(void* security, int i_manual_reset, int i_init_state,char* sz_name);

unsigned int	stx_waitfor_event(STX_HANDLE h_event,unsigned int i_wait_time);

STX_RESULT		stx_set_event(STX_HANDLE h_event);

STX_RESULT		stx_reset_event(STX_HANDLE h_event);

void            stx_close_event(STX_HANDLE h_event);

unsigned int	stx_waitfor_multiple_objects(
	int i_count,STX_HANDLE* p_h,unsigned int i_wait_all, unsigned int i_wait_time);


#if defined( __cplusplus )
}
#endif


#endif /*    __STX_EVENT_H__   */ 
