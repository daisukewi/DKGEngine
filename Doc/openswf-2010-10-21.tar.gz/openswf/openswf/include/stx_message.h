

#ifndef __STX_MESSAGE_H__
#define __STX_MESSAGE_H__

/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/


#include "base_class.h"

#if defined( __cplusplus )
extern "C" {
#endif

	STX_API STX_COM(base_msg,stx_base_message* p_msg);

	STX_API CREATE_STX_COM_DECL(stx_base_message,base_msg,stx_base_message* p_msg);


#if defined( __cplusplus )
}
#endif



#endif /* __STX_MESSAGE_H__ */ 