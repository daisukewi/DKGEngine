/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#ifndef __STX_IO_TCP_H__2008_06_21
#define __STX_IO_TCP_H__2008_06_21


#include "stx_base_type.h"

#include "stx_io.h"

#include "stx_sock_err.h"


#if defined( __cplusplus )
extern "C" {
#endif

	u16			tcpio_get_local_port(stx_xio* h);
	char*		tcpio_get_local_addr_str(stx_xio* h);
	u32			tcpio_get_local_addr(stx_xio* h);
	u16			tcpio_get_remote_port(stx_xio* h);
	char*		tcpio_get_remote_addr_str(stx_xio* h);
	u32			tcpio_get_remote_addr(stx_xio* h);

	STX_RESULT	tcpio_write_vector(stx_xio* h,const iovec* iov, const u32 numIOvecs, u32* outLengthSent);


#define STX_XIO_TCP_OPEN_SVR            0x01

#define STX_XIO_TCP_OPEN_CONNECT        0x02

#define STX_XIO_TCP_OPEN_ASYNC	        0x04

#define STX_XIO_TCP_OPEN_KEEPALIVE	    0x08

#define STX_XIO_TCP_OPEN_REUSEADDR      0x10

#define STX_XIO_TCP_OPEN_NODELAY        0x20

#define STX_XIO_TCP_ATTACH				0x40

#define STX_XIO_UDP_BIND_REMOTE			0x80


extern char*  g_sz_tcp_key_bind ;
extern char*  g_sz_tcp_key_remote;
extern char*  g_sz_tcp_key_connect_timeout;
extern char*  g_sz_tcp_key_wait_timeout;
extern char*  g_sz_tcp_key_read_timeout;
extern char*  g_sz_tcp_key_write_timeout;
extern char*  g_sz_tcp_key_opt;
extern char*  g_sz_tcp_key_noneblock;
extern char*  g_sz_tcp_key_read_stat;
extern char*  g_sz_tcp_key_write_stat;


void*		stx_gethostbyname(const char* hostname,hostent* remotehost);
void*		stx_inet_ntoa(in_addr addr,char* buf,size_t i_size);

char*		create_http_opt(const char* url,const char* ua,const char* header);
STX_RESULT  split_http_opt(const char* url, char** url1, char** ua,char** header);


THEE		stx_io_tcp_create_key(char* sz_stream,b32 b_edit);
void		stx_io_tcp_close_key(THEE h);
STX_RESULT	stx_io_tcp_read_key(THEE h,char* buf, u32* i_len);

STX_RESULT	stx_io_tcp_set_server_ip(THEE h,const char* sz_ip,u32 i_port);
STX_RESULT	stx_io_tcp_set_bind_ip(THEE h,const char* sz_ip,u32 i_port);
STX_RESULT	stx_io_tcp_get_server_ip(THEE h, char* sz_ip, size_t i_size,u32* i_port);
STX_RESULT	stx_io_tcp_get_bind_ip(THEE h,char* sz_ip,size_t i_size,u32* i_port);


STX_RESULT	stx_io_tcp_set_connect_timeout(THEE h,u64 i_usec);
STX_RESULT	stx_io_tcp_set_wait_timeout(THEE h,u64 i_usec);
STX_RESULT	stx_io_tcp_set_read_timeout(THEE h,u64 i_usec);
STX_RESULT	stx_io_tcp_set_write_timeout(THEE h,u64 i_usec);
STX_RESULT	stx_io_tcp_set_opt(THEE h,u32 i_opt);
STX_RESULT	stx_io_tcp_set_read_stat(THEE h);
STX_RESULT	stx_io_tcp_set_write_stat(THEE h);
STX_RESULT	stx_io_tcp_set_noneblock(THEE h);


STX_RESULT	stx_io_tcp_get_connect_timeout(THEE h,u64* i_val);
STX_RESULT	stx_io_tcp_get_wait_timeout(THEE h,u64* i_val );
STX_RESULT	stx_io_tcp_get_read_timeout(THEE h,u64* i_val );
STX_RESULT	stx_io_tcp_get_write_timeout(THEE h,u64* i_val );
STX_RESULT	stx_io_tcp_get_opt(THEE h,u32* i_val);
STX_RESULT	stx_io_tcp_get_read_stat(THEE h,b32* i_val);
STX_RESULT	stx_io_tcp_get_write_stat(THEE h,b32* i_val);
STX_RESULT	stx_io_tcp_get_noneblock(THEE h,b32* i_val);



void		  stx_io_tcp_make_string( char* sz_ip, uint32_t i_port, char* sz_param , size_t i_size);
STX_RESULT	  stx_io_tcp_string_parse( char* sz_param, char* sz_ip, size_t i_ip_size,uint32_t* i_port);
STX_RESULT	  stx_io_tcp_make_open_string( char* sz_bind, char* sz_remote, char* sz_param );
STX_RESULT	  stx_io_tcp_open_string_parse( char* sz_param, char** sz_bind, char** sz_remote );
STX_RESULT	  stx_io_tcp_read_stream(stx_xio* h_tcp,stx_xio* h_stream,size_t i_len);


stx_xio*	  stx_create_io_tcp();




#if defined( __cplusplus )
}
#endif

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
stx_inline u32 split_string_pass(char* param, char* sz_tag, char* sz_unit, u32 i_size )
{
	u32	val;

	u32 i;
	u32 const i_limit = i_size - 1;

	for( i = 0; i < i_limit; i ++) {

		val = (u32) param[i];
		if( !val ) {
			sz_unit[i] = 0;
			return i_limit;
		}
		if( val == (u32)sz_tag[0] ) {
			sz_unit[i] = 0;
			return i+1;
		}

		sz_unit[i] = val;
	} // for( i = 0; i < i_limit; i ++) {

	if( i == i_limit ) {
		return 0;
	}

	return i+1;
}

#endif /*   __STX_IO_TCP_H__2008_06_21  */

