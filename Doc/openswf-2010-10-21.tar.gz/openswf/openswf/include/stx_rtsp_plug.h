/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-11
***********************************************************************************/
#ifndef __STX_RTSP_PROT_H__
#define __STX_RTSP_PROT_H__

#include "stx_async_plugin.h"
#include "stx_prop_def.h"
#include "stx_protocol.h"


#if defined( __cplusplus )
extern "C" {
#endif


	// {6A174A96-818A-40a4-83F0-E7DBB65EF08A}
	DECLARE_XGUID( STX_CLSID_RtspProtocol,0x6a174a96, 0x818a, 0x40a4, 0x83, 0xf0, 0xe7, 0xdb, 0xb6, 0x5e, 0xf0, 0x8a);
	extern char* g_sz_StreamX_RtspProtocol;
	STX_COM(stx_rtsp_prot);
	STX_API CREATE_STX_COM_DECL(stx_base_plugin,stx_rtsp_prot,char* sz_dbg);



#if defined( __cplusplus )
}
#endif


#endif // __STX_RTSP_PROT_H__