/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/
#ifndef __MOV_IO_STREAM_H__2008_06_21
#define __MOV_IO_STREAM_H__2008_06_21


#include "stx_base_type.h"

#include "stx_io.h"


#if defined( __cplusplus )
extern "C" {
#endif

typedef struct stx_io_stream stx_io_stream;

#ifdef __USE_STX_DEBUG__
stx_xio*  create_stx_io_stream(THEE hinst,const char* file,s32 line);
#else
stx_xio*  create_stx_io_stream(THEE hinst);
#endif


#if defined( __cplusplus )
}
#endif

#endif /*   __MOV_IO_STREAM_H__2008_06_21 */ 
