/***********************************************************************************/
//STREAMX FRAMEWORK SOURCE;
//AUTHOR: JIN LONG BAO
//CREATE TIME:2008-06
/***********************************************************************************/

#if !defined( __BASE_CLASS_H__)
#define __BASE_CLASS_H__


#include "base_interf.h"
#include "stx_hash.h"
#include "stx_mutex.h"


#if defined( __cplusplus )
extern "C" {
#endif

	/*}}}com helper**********************************************************************/
	STX_INTERF(stx_com_helper);
	STX_INTERF(stx_com_map_ctx);
	STX_INTERF(stx_com_map);

	struct stx_com_map_ctx {
		stx_gid		iid;
		char		iid_name[64];
	};

	struct stx_com_map {
		stx_gid*	iid;
		char		iid_name[64];
	};

	#define STX_COM_MAP_BEGIN(SCOM) \
	static stx_com_map SCOM ## _interf_map[] = { {&STX_GID_NULL,},

		// TO DO , add other type;
	#define STX_COM_MAP_ITEM(a) { &a,""#a,},

	#define STX_COM_MAP_END() };

	/*}}}com helper**********************************************************************/



	/*{{{stream type**********************************************************************/

	#define STREAM_TYPE_MAP_BEGIN(NAME) \
		static stx_reg_stream_ctx NAME[] = { {&STX_GID_NULL,&STX_GID_NULL,},

		// TO DO , add other type;
	#define STREAM_TYPE_MAP_ITEM(a,b,c) { &a,&b,""#a,""#b, c },

	#define STREAM_TYPE_MAP_END() };
	/*}}}stream type**********************************************************************/


	/*{{{stx_msg**********************************************************************/
	typedef struct stx_msg_data stx_msg_data;
	struct stx_msg_data {
		stx_gid*		msg_gid;
		STX_RESULT		(*msg_entry)( STX_HANDLE, stx_base_message* );
	};

#define STX_MSG_MAX		128
#define	STX_MSG			static 
#define	STX_MSG_PROC	static

#define STX_MSG_PROC_DECLARE(msgproc)  STX_MSG_PROC STX_RESULT msgproc(STX_HANDLE h, stx_base_message* p_msg );
#define STX_PURE_MSG_PROC_DECLARE(msgproc)  STX_RESULT (*msgproc)(STX_HANDLE h,stx_base_message* p_msg);

#define	STX_MSG_ENTRY	static
#define STX_MSG_ENTRY_DECLARE(entry)  STX_MSG_ENTRY STX_RESULT entry(STX_HANDLE h, stx_base_message* p_msg );

#define	ON_STX_MSG(msg_gid,msg_entry) { &msg_gid, msg_entry },

#define	STX_BEGIN_MSG_MAP(the_msg_data)	\
	STX_MSG stx_msg_data the_msg_data[] = { ON_STX_MSG(STX_GID_NULL,STX_NULL)

#define STX_END_MSG_MAP		};

#define STX_DISPATCH_MSG( h, p_msg,the_msg_data ) \
	{\
		s32				i_idx;				\
		stx_msg_cnt		*msn;				\
		msn = p_msg->get_msg_cnt(p_msg);	\
		for( i_idx = 1; i_idx < FF_ARRAY_ELEMS(the_msg_data); i_idx ++ ) {\
			if( IS_EQUAL_GID(*((the_msg_data)[i_idx].msg_gid),msn->msg_gid) ){\
				return the_msg_data[i_idx].msg_entry(h,p_msg);\
			}\
		}\
		return STX_OK;\
	}

#define STX_DISPATCH_MSG_PROC( proc,the_msg_data ) \
	STX_MSG_PROC STX_RESULT proc( STX_HANDLE h, stx_base_message* p_msg  )\
	{\
	STX_DISPATCH_MSG( h, p_msg,the_msg_data  )	\
	}



#define	STX_BEGIN_MSG_RESPONSE_MAP(the_msg_response)	\
	STX_BEGIN_MSG_MAP(the_msg_response)

#define STX_END_MSG_RESPONSE_MAP		};

#define STX_RESPONSE_MSG( h, p_msg,the_msg_response ) \
	STX_DISPATCH_MSG( h, p_msg,the_msg_response )

#define STX_RESPONSE_MSG_PROC( proc,the_msg_response ) \
	STX_DISPATCH_MSG_PROC( proc,the_msg_response )

	/*}}}stx_msg**********************************************************************/


	/*{{{stx_base_com**********************************************************************/
#define stx_base_com_funcdecl(PREFIX) \
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## query_interf( STX_HANDLE h, stx_gid gid, STX_HANDLE* pp_interf ){\
		STX_MAP_THE(stx_base_com);\
		return the->query_interf(the,gid,pp_interf);\
	}\
	STX_PURE s32 PREFIX ## _xxx_ ## add_ref( STX_HANDLE h ){\
		STX_MAP_THE(stx_base_com);\
		return the->add_ref(the);\
	}\
	STX_PURE s32 PREFIX ## _xxx_ ## release( STX_HANDLE h ){\
		STX_MAP_THE(stx_base_com);\
		return the->release(the);\
	}

#define stx_base_com_vtinit(vt,PREFIX) \
	STX_VT_INIT(vt,PREFIX,query_interf);\
	STX_VT_INIT(vt,PREFIX,add_ref);\
	STX_VT_INIT(vt,PREFIX,release)

#define stx_base_com_data_default()					\
	s32 i_ref;\
	b32 b_inst;

#define stx_base_com_funcimp_default(SCOM,PREFIX)		DEFAULT_CODE

#define stx_base_com_create_default(vt,PREFIX,CLS,CAT,NAME)		\
	stx_base_com_vtinit(vt,PREFIX)

#define stx_base_com_release_default(SCOM)				DEFAULT_CODE

#define stx_base_com_release_begin(SCOM)				DEFAULT_CODE

#define stx_base_com_release_end(SCOM)					DEFAULT_CODE

#define stx_base_com_query_default(SCOM,vt)				DEFAULT_CODE

	/*}}}stx_base_com**********************************************************************/



	/*{{{**********************************************************************/

#define stx_base_message_funcdecl(PREFIX) \
	stx_base_com_funcdecl(PREFIX ## _ ## com)\
	STX_PURE STX_RESULT		PREFIX ## _xxx_ ## set_msg_src(STX_HANDLE h, stx_gid cls_gid );\
	STX_PURE STX_RESULT		PREFIX ## _xxx_ ## set_msg_dest(STX_HANDLE h, stx_gid cls_gid );\
	STX_PURE STX_RESULT		PREFIX ## _xxx_ ## set_msg_type(STX_HANDLE h, u32 i_type );\
	STX_PURE STX_RESULT		PREFIX ## _xxx_ ## set_msg_name(STX_HANDLE h, char* sz_name );\
	STX_PURE STX_RESULT		PREFIX ## _xxx_ ## set_msg_text(STX_HANDLE h, char* sz_txt );\
	STX_PURE void			PREFIX ## _xxx_ ## set_msg_cnt( STX_HANDLE h, stx_msg_cnt* p_cnt );\
	STX_PURE void			PREFIX ## _xxx_ ## set_msg_time_out(STX_HANDLE h, u32 i_wait_time);\
	STX_PURE void			PREFIX ## _xxx_ ## set_msg_close( STX_HANDLE h);\
	STX_PURE b32			PREFIX ## _xxx_ ## is_msg_closed( STX_HANDLE h);\
	STX_PURE STX_RESULT		PREFIX ## _xxx_ ## wait(STX_HANDLE h );\
	STX_PURE stx_gid		PREFIX ## _xxx_ ## get_msg_src(STX_HANDLE h );\
	STX_PURE stx_gid		PREFIX ## _xxx_ ## get_msg_dest(STX_HANDLE h );\
	STX_PURE u32			PREFIX ## _xxx_ ## get_msg_type(STX_HANDLE h );\
	STX_PURE char*			PREFIX ## _xxx_ ## get_msg_name(STX_HANDLE h );\
	STX_PURE char*			PREFIX ## _xxx_ ## get_msg_text(STX_HANDLE h );\
	STX_PURE stx_msg_cnt*	PREFIX ## _xxx_ ## get_msg_cnt( STX_HANDLE h );\
	STX_PURE u32			PREFIX ## _xxx_ ## get_msg_time_out(STX_HANDLE h );\
	STX_PURE void			PREFIX ## _xxx_ ## signal(STX_HANDLE h);\
	STX_PURE STX_RESULT		PREFIX ## _xxx_ ## set_msg_buf(STX_HANDLE h, u8* buf, s32 i_len );\
	STX_PURE u8*			PREFIX ## _xxx_ ## get_msg_buf(STX_HANDLE h, s32* i_len );\
	STX_PURE STX_RESULT		PREFIX ## _xxx_ ## set_stack(STX_HANDLE h );\
	STX_PURE STX_HANDLE		PREFIX ## _xxx_ ## get_stack(STX_HANDLE h )

#define stx_base_message_vtinit(vt,PREFIX) \
	STX_VT_INIT(vt,PREFIX,set_msg_src);\
	STX_VT_INIT(vt,PREFIX,set_msg_dest);\
	STX_VT_INIT(vt,PREFIX,set_msg_type);\
	STX_VT_INIT(vt,PREFIX,set_msg_name);\
	STX_VT_INIT(vt,PREFIX,set_msg_text);\
	STX_VT_INIT(vt,PREFIX,set_msg_cnt);\
	STX_VT_INIT(vt,PREFIX,set_msg_time_out);\
	STX_VT_INIT(vt,PREFIX,set_msg_close);\
	STX_VT_INIT(vt,PREFIX,is_msg_closed);\
	STX_VT_INIT(vt,PREFIX,wait);\
	STX_VT_INIT(vt,PREFIX,get_msg_src);\
	STX_VT_INIT(vt,PREFIX,get_msg_dest);\
	STX_VT_INIT(vt,PREFIX,get_msg_type);\
	STX_VT_INIT(vt,PREFIX,get_msg_name);\
	STX_VT_INIT(vt,PREFIX,get_msg_text);\
	STX_VT_INIT(vt,PREFIX,get_msg_cnt);\
	STX_VT_INIT(vt,PREFIX,get_msg_time_out);\
	STX_VT_INIT(vt,PREFIX,signal);\
	STX_VT_INIT(vt,PREFIX,set_msg_buf);\
	STX_VT_INIT(vt,PREFIX,get_msg_buf);\
	STX_VT_INIT(vt,PREFIX,set_stack);\
	STX_VT_INIT(vt,PREFIX,get_stack)

#define stx_base_message_data_default()			\
	stx_base_com_data_default()

#define stx_base_message_funcimp_default(SCOM,PREFIX)	\
	stx_base_com_funcimp_default(SCOM,PREFIX ## _ ## com )\

#define stx_base_message_create_default(vt,PREFIX,CLS,CAT,NAME)	\
	stx_base_com_create_default(vt,PREFIX ## _ ## com,CLS,CAT,NAME);\
	stx_base_message_vtinit(vt,PREFIX)


#define stx_base_message_release_default(SCOM)		\
	stx_base_com_release_default(SCOM)\

#define stx_base_message_release_begin(SCOM) \
	stx_base_com_release_begin(SCOM)\

#define stx_base_message_release_end(SCOM) \
	stx_base_com_release_end(SCOM)\


#define stx_base_message_query_default(SCOM,vt)		\
	if( IS_EQUAL_GID(gid,STX_IID_Message) ) {\
		the->i_ref ++;\
		*pp_interf = (void*)&vt;\
		return STX_OK;\
	}\
	stx_base_com_query_default(SCOM,vt )\

	/*}}}**********************************************************************/





	/*{{{**********************************************************************/
#define stx_base_plugin_funcdecl(PREFIX) \
	stx_base_com_funcdecl(PREFIX ## _ ## com)\
	STX_PURE void				PREFIX ## _xxx_ ## set_user_data(STX_HANDLE h, STX_HANDLE h_data);\
	STX_PURE STX_HANDLE			PREFIX ## _xxx_ ## get_user_data(STX_HANDLE h);\
	STX_PURE STX_RESULT			PREFIX ## _xxx_ ## set_property(STX_HANDLE h,stx_xio* h_xio);\
	STX_PURE STX_RESULT			PREFIX ## _xxx_ ## get_property(STX_HANDLE h,stx_xio* h_xio);\
	STX_PURE STX_RESULT			PREFIX ## _xxx_ ## set_gbd( STX_HANDLE h, stx_base_graph_builder* h_gbd );\
	STX_PURE stx_base_graph_builder*	PREFIX ## _xxx_ ## get_gbd( STX_HANDLE h);\
	STX_PURE void				PREFIX ## _xxx_ ## set_ssrc( STX_HANDLE h, stx_sync_source* h_ssrc );\
	STX_PURE stx_sync_source*	PREFIX ## _xxx_ ## get_ssrc( STX_HANDLE h);\
	STX_PURE void				PREFIX ## _xxx_ ## set_parent( STX_HANDLE h, stx_base_plugin* p_parent );\
	STX_PURE stx_base_plugin*	PREFIX ## _xxx_ ## get_parent( STX_HANDLE h );\
	STX_PURE STX_RESULT			PREFIX ## _xxx_ ## set_name( STX_HANDLE h, const char* sz_name);\
	STX_PURE char*				PREFIX ## _xxx_ ## get_name( STX_HANDLE h);\
	STX_PURE void    			PREFIX ## _xxx_ ## set_clsid( STX_HANDLE h, stx_gid clsid);\
	STX_PURE stx_gid			PREFIX ## _xxx_ ## get_clsid( STX_HANDLE h);\
	STX_PURE void   			PREFIX ## _xxx_ ## set_catid( STX_HANDLE h,stx_gid catid);\
	STX_PURE stx_gid			PREFIX ## _xxx_ ## get_catid( STX_HANDLE h);\
	STX_PURE void   			PREFIX ## _xxx_ ## set_insid( STX_HANDLE h,stx_gid insid);\
	STX_PURE stx_gid			PREFIX ## _xxx_ ## get_insid( STX_HANDLE h);\
	STX_PURE STX_RESULT			PREFIX ## _xxx_ ## set_clsid_name( STX_HANDLE h, const char* sz_name);\
	STX_PURE char*				PREFIX ## _xxx_ ## get_clsid_name( STX_HANDLE h);\
	STX_PURE STX_RESULT			PREFIX ## _xxx_ ## set_catid_name( STX_HANDLE h,const char* sz_name);\
	STX_PURE char*				PREFIX ## _xxx_ ## get_catid_name( STX_HANDLE h);\
	STX_PURE STX_RESULT			PREFIX ## _xxx_ ## send_msg( STX_HANDLE h, stx_base_message* p_msg );\
	STX_PURE STX_RESULT			PREFIX ## _xxx_ ## run(STX_HANDLE h, stx_sync_inf* h_sync );\
	STX_PURE stx_com_status		PREFIX ## _xxx_ ## get_status(STX_HANDLE h);\
	STX_PURE void				PREFIX ## _xxx_ ## set_status(STX_HANDLE h,stx_com_status em_status);\
	STX_PURE STX_RESULT			PREFIX ## _xxx_ ## start(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync);\
	STX_PURE STX_RESULT			PREFIX ## _xxx_ ## stop(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync);\
	STX_PURE STX_RESULT			PREFIX ## _xxx_ ## flush(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync);\
	STX_PURE stx_gid			PREFIX ## _xxx_ ## get_uuid( STX_HANDLE h);\
	STX_PURE STX_RESULT			PREFIX ## _xxx_ ## reg_key(THEE h, stx_gid keyid,s32 i_len);\
	STX_PURE void				PREFIX ## _xxx_ ## rem_key(THEE h, stx_gid keyid);\
	STX_PURE STX_RESULT			PREFIX ## _xxx_ ## write_key(THEE h, stx_gid keyid,u8* p_data,s32 i_len);\
	STX_PURE u8*				PREFIX ## _xxx_ ## read_key(THEE h, stx_gid keyid,s32* i_len)

#define stx_base_plugin_vtinit(vt,PREFIX) \
	STX_VT_INIT(vt,PREFIX,set_user_data );\
	STX_VT_INIT(vt,PREFIX,get_user_data );\
	STX_VT_INIT(vt,PREFIX,set_property);\
	STX_VT_INIT(vt,PREFIX,get_property);\
	STX_VT_INIT(vt,PREFIX,set_gbd);\
	STX_VT_INIT(vt,PREFIX,get_gbd);\
	STX_VT_INIT(vt,PREFIX,set_ssrc);\
	STX_VT_INIT(vt,PREFIX,get_ssrc);\
	STX_VT_INIT(vt,PREFIX,set_parent);\
	STX_VT_INIT(vt,PREFIX,get_parent);\
	STX_VT_INIT(vt,PREFIX,set_name);\
	STX_VT_INIT(vt,PREFIX,get_name);\
	STX_VT_INIT(vt,PREFIX,set_clsid);\
	STX_VT_INIT(vt,PREFIX,get_clsid);\
	STX_VT_INIT(vt,PREFIX,set_catid);\
	STX_VT_INIT(vt,PREFIX,get_catid);\
	STX_VT_INIT(vt,PREFIX,set_insid);\
	STX_VT_INIT(vt,PREFIX,get_insid);\
	STX_VT_INIT(vt,PREFIX,set_clsid_name);\
	STX_VT_INIT(vt,PREFIX,get_clsid_name);\
	STX_VT_INIT(vt,PREFIX,set_catid_name);\
	STX_VT_INIT(vt,PREFIX,get_catid_name);\
	STX_VT_INIT(vt,PREFIX,send_msg);\
	STX_VT_INIT(vt,PREFIX,run);\
	STX_VT_INIT(vt,PREFIX,get_status);\
	STX_VT_INIT(vt,PREFIX,set_status);\
	STX_VT_INIT(vt,PREFIX,start);\
	STX_VT_INIT(vt,PREFIX,stop);\
	STX_VT_INIT(vt,PREFIX,flush);\
	STX_VT_INIT(vt,PREFIX,get_uuid);\
	STX_VT_INIT(vt,PREFIX,reg_key);\
	STX_VT_INIT(vt,PREFIX,rem_key);\
	STX_VT_INIT(vt,PREFIX,write_key);\
	STX_VT_INIT(vt,PREFIX,read_key)

#define stx_base_plugin_data_default()				\
	stx_base_com_data_default()						\
	STX_HANDLE				h_key_;					\
	STX_HANDLE				h_data;					\
	stx_com_status			em_status;				\
	stx_base_graph_builder*	h_gbd;					\
	stx_sync_source*		h_ssrc;					\
	stx_gid					cls_gid;				\
	stx_gid					cat_gid;				\
	stx_gid					ins_gid;				\
	stx_gid					uu_gid;					\
	stx_base_plugin*		p_parent;				\
	char*					sz_clsid_name;			\
	char*					sz_catid_name;			\
	char*					sz_name;				\
	THEE					h_mutex_;


#define stx_base_plugin_funcimp_default(SCOM,PREFIX)	\
	stx_base_com_funcimp_default(SCOM,PREFIX ## _ ## com )\
	STX_PURE void PREFIX ## _xxx_ ## set_status(STX_HANDLE h,stx_com_status em_status){\
		STX_MAP_THE(SCOM);\
		the->em_status = em_status;\
	}\
	STX_PURE stx_com_status PREFIX ## _xxx_ ## get_status(STX_HANDLE h){\
		STX_MAP_THE(SCOM);\
		return the->em_status;\
	}\
	STX_PURE void       PREFIX ## _xxx_ ## set_user_data(STX_HANDLE h, STX_HANDLE h_data){\
		STX_MAP_THE(SCOM);\
		the->h_data = h_data;\
	}\
	STX_PURE STX_HANDLE PREFIX ## _xxx_ ## get_user_data(STX_HANDLE h){\
		STX_MAP_THE(SCOM);\
		return the->h_data;\
	}\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## set_gbd( STX_HANDLE h, stx_base_graph_builder* h_gbd ){\
		STX_MAP_THE(SCOM);\
		the->h_gbd = h_gbd;\
		{\
			stx_base_plugin* plug_ = NULL;\
			XCALL(query_interf,((stx_base_com*)h),STX_IID_BasePlugin,(void**)&plug_);\
			XCALL(release,plug_);\
			return XCALL(reg_plug,h_gbd,plug_);\
		}\
	}\
	STX_PURE stx_base_graph_builder* PREFIX ## _xxx_ ## get_gbd( STX_HANDLE h ){\
		STX_MAP_THE(SCOM);\
		if(the->h_gbd){\
			the->h_gbd->add_ref(the->h_gbd);\
		}\
		return the->h_gbd;\
	}\
	STX_PURE void PREFIX ## _xxx_ ## set_ssrc( STX_HANDLE h, stx_sync_source* h_ssrc ){\
		STX_MAP_THE(SCOM);\
		the->h_ssrc = h_ssrc;\
	}\
	STX_PURE stx_sync_source* PREFIX ## _xxx_ ## get_ssrc( STX_HANDLE h ){\
		STX_MAP_THE(SCOM);\
		the->h_ssrc->add_ref(the->h_ssrc);\
		return the->h_ssrc;\
	}\
	STX_PURE void PREFIX ## _xxx_ ## set_parent( STX_HANDLE h, stx_base_plugin* p_parent ){\
		STX_MAP_THE(SCOM);\
		the->p_parent = p_parent;\
	}\
	STX_PURE stx_base_plugin* PREFIX ## _xxx_ ## get_parent( STX_HANDLE h ){\
		STX_MAP_THE(SCOM);\
		the->p_parent->add_ref(the->p_parent);\
		return the->p_parent;\
	}\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## set_name( STX_HANDLE h, const char* sz_name){\
		STX_MAP_THE(SCOM);\
		if( !sz_name ) {\
			return STX_FAIL;\
		}\
		if( the->sz_name ){\
			stx_free(the->sz_name);\
		}\
		the->sz_name = xstrdup(sz_name);\
		if( !the->sz_name ) {\
			return STX_FAIL;\
		}\
		return STX_OK;	\
	}\
	STX_PURE char* PREFIX ## _xxx_ ## get_name( STX_HANDLE h){\
		STX_MAP_THE(SCOM);\
		return the->sz_name;\
	}\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## set_clsid_name( STX_HANDLE h, const char* sz_name){\
		STX_MAP_THE(SCOM);\
		if( !sz_name ) {\
			return STX_FAIL;\
		}\
		if( the->sz_clsid_name ){\
			stx_free(the->sz_clsid_name);\
		}\
		the->sz_clsid_name = xstrdup(sz_name);\
		if( !the->sz_clsid_name ) {\
			return STX_FAIL;\
		}\
		return STX_OK;	\
	}\
	STX_PURE char* PREFIX ## _xxx_ ## get_clsid_name( STX_HANDLE h){\
		STX_MAP_THE(SCOM);\
		return the->sz_clsid_name;\
	}\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## set_catid_name( STX_HANDLE h, const char* sz_name){\
		STX_MAP_THE(SCOM);\
		if( !sz_name ) {\
			return STX_FAIL;\
		}\
		if( the->sz_catid_name ){\
			stx_free(the->sz_catid_name);\
		}\
		the->sz_catid_name = xstrdup(sz_name);\
		if( !the->sz_catid_name ) {\
			return STX_FAIL;\
		}\
		return STX_OK;	\
	}\
	STX_PURE char* PREFIX ## _xxx_ ## get_catid_name( STX_HANDLE h){\
		STX_MAP_THE(SCOM);\
		return the->sz_catid_name;\
	}\
	STX_PURE void PREFIX ## _xxx_ ## set_clsid( STX_HANDLE h, stx_gid clsid){\
		STX_MAP_THE(SCOM);\
		the->cls_gid = clsid;\
	}\
	STX_PURE stx_gid PREFIX ## _xxx_ ## get_clsid( STX_HANDLE h){\
		STX_MAP_THE(SCOM);\
		return the->cls_gid;\
	}\
	STX_PURE void PREFIX ## _xxx_ ## set_catid( STX_HANDLE h,stx_gid catid){\
		STX_MAP_THE(SCOM);\
		the->cat_gid = catid;\
	}\
	STX_PURE stx_gid PREFIX ## _xxx_ ## get_catid( STX_HANDLE h){\
		STX_MAP_THE(SCOM);\
		return the->cat_gid;\
	}\
	STX_PURE void PREFIX ## _xxx_ ## set_insid( STX_HANDLE h, stx_gid insid){\
		STX_MAP_THE(SCOM);\
		the->ins_gid = insid;\
	}\
	STX_PURE stx_gid PREFIX ## _xxx_ ## get_insid( STX_HANDLE h){\
		STX_MAP_THE(SCOM);\
		return the->ins_gid;\
	}\
	STX_PURE stx_gid PREFIX ## _xxx_ ## get_uuid( STX_HANDLE h){\
		STX_MAP_THE(SCOM);\
		return the->uu_gid;\
	}\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## reg_key( THEE h, stx_gid keyid,s32 i_len){\
		char sz_gid[64];\
		STX_MAP_THE(SCOM);\
		binary_to_string(16,keyid.data,sz_gid);\
		return stx_hash_add_ex_byname(the->h_key_,NULL,i_len,sz_gid);\
	}\
	STX_PURE void PREFIX ## _xxx_ ## rem_key( THEE h, stx_gid keyid){\
		char sz_gid[64];\
		STX_MAP_THE(SCOM);\
		binary_to_string(16,keyid.data,sz_gid);\
		stx_hash_rem_byname(the->h_key_,sz_gid);\
	}\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## write_key(THEE h, stx_gid keyid,u8* p_data,s32 i_len){\
		char		sz_gid[64];\
		STX_RESULT	i_err;\
		STX_MAP_THE(SCOM);\
		stx_waitfor_mutex(the->h_mutex_,INFINITE);\
		binary_to_string(16,keyid.data,sz_gid);\
		i_err = stx_hash_write_ex_byname(the->h_key_,p_data,i_len,sz_gid);\
		stx_release_mutex(the->h_mutex_);\
		return i_err;\
	}\
	STX_PURE u8* PREFIX ## _xxx_ ## read_key(THEE h, stx_gid keyid, s32* i_len){\
		char	sz_gid[64];\
		u8*		p;	\
		STX_MAP_THE(SCOM);\
		stx_waitfor_mutex(the->h_mutex_,INFINITE);\
		binary_to_string(16,keyid.data,sz_gid);\
		p = stx_hash_find_ex_byname(the->h_key_,sz_gid,i_len);\
		stx_release_mutex(the->h_mutex_);\
		return p;\
	}


#define stx_base_plugin_create_default(vt,PREFIX,CLS,CAT,NAME)			\
	stx_base_com_create_default(vt,PREFIX ## _ ## com,CLS,CAT,NAME);\
	stx_base_plugin_vtinit(vt,PREFIX);\
	the->h_mutex_ = stx_create_mutex(NULL,0,NULL);\
	if( !the->h_mutex_){\
		break;\
	}\
	if( STX_OK != vt.set_name(&vt,NAME)) {\
		break;\
	}\
	if( STX_OK != vt.set_catid_name(&vt,""#CAT)) {\
		break;\
	}\
	if( STX_OK != vt.set_clsid_name(&vt,""#CLS)) {\
		break;\
	}\
	the->h_key_ = stx_hash_create(128);\
	if( !the->h_key_) {\
		break;\
	}\
	the->cls_gid = CLS;\
	the->cat_gid = CAT;\
	the->ins_gid = stx_gid_create();\
	the->uu_gid = the->ins_gid


#define stx_base_plugin_release_default(SCOM) \
	if( the->h_gbd ){\
		stx_base_plugin* plug_ = NULL;\
		XCALL(query_interf,((stx_base_com*)h),STX_IID_BasePlugin,(void**)&plug_);\
		the->i_ref = 0;\
		XCALL(unreg_plug,the->h_gbd,plug_);/**/\
		XCALL(release,the->h_gbd);\
	}\
	SAFE_XDELETE(the->h_ssrc);\
	if( the->h_key_ ) {\
		stx_hash_close(the->h_key_);\
	}\
	if( the->sz_name ) {\
		stx_free(the->sz_name);\
	}\
	if( the->sz_clsid_name ) {\
		stx_free(the->sz_clsid_name);\
	}\
	if( the->sz_catid_name ) {\
		stx_free(the->sz_catid_name);\
	}\
	if( the->h_mutex_ ) {\
		stx_close_mutex(the->h_mutex_);\
		the->h_mutex_ = NULL;\
	}\
	stx_base_com_release_default(SCOM)\

#define stx_base_plugin_release_begin(SCOM)			\
	stx_base_com_release_begin(SCOM)\

#define stx_base_plugin_release_end(SCOM)			\
	stx_base_com_release_end(SCOM)\


#define stx_base_plugin_query_default(SCOM,vt)	\
	if( IS_EQUAL_GID(gid,STX_IID_BasePlugin) ) {\
		the->i_ref ++;\
		*pp_interf = (void*)&vt;\
		return STX_OK;\
	}\
	stx_base_com_query_default(SCOM,vt)\

/*}}}**********************************************************************/




/*{{{**********************************************************************/

#define stx_base_graph_funcdecl(PREFIX) \
	stx_base_plugin_funcdecl(PREFIX ## _ ## plug);\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## connect(STX_HANDLE h, stx_base_pin* p_out,stx_base_pin* p_in );\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## rend_file( STX_HANDLE h, char* sz_file_name );\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## rend_pin( STX_HANDLE h, stx_base_pin* p_out );\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## rend( STX_HANDLE h );\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## enum_plugin( STX_HANDLE h, size_t* i_index, stx_base_plugin** pp_plugin );\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## add_plugin( STX_HANDLE h, stx_base_plugin* p_plugin );\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## remove_plugin( STX_HANDLE h, const char* sz_name );\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## find_plugin( STX_HANDLE h, stx_base_plugin** pp_plugin,const char* sz_name );\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## add_source(\
		STX_HANDLE h, char* sz_file_name, stx_base_com** pp_src );\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## find_source( STX_HANDLE h, stx_base_com** pp_plugin,stx_media_type_inf media_inf );\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## find_render( STX_HANDLE h, stx_base_com** pp_plugin,stx_media_type_inf media_inf );\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## connect_direct(\
	STX_HANDLE h, stx_base_pin* p_out,stx_base_pin* p_in, stx_media_type* p_mt );\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## disconnect(STX_HANDLE h, stx_base_pin* p_pin)

#define stx_base_graph_vtinit(vt,PREFIX) \
	STX_VT_INIT(vt,PREFIX,connect);\
	STX_VT_INIT(vt,PREFIX,rend_file);\
	STX_VT_INIT(vt,PREFIX,rend_pin);\
	STX_VT_INIT(vt,PREFIX,rend);\
	STX_VT_INIT(vt,PREFIX,enum_plugin);\
	STX_VT_INIT(vt,PREFIX,add_plugin);\
	STX_VT_INIT(vt,PREFIX,remove_plugin);\
	STX_VT_INIT(vt,PREFIX,find_plugin);\
	STX_VT_INIT(vt,PREFIX,add_source);\
	STX_VT_INIT(vt,PREFIX,find_source);\
	STX_VT_INIT(vt,PREFIX,find_render);\
	STX_VT_INIT(vt,PREFIX,connect_direct);\
	STX_VT_INIT(vt,PREFIX,disconnect)

#define stx_base_graph_data_default()			\
	stx_base_plugin_data_default()

#define stx_base_graph_funcimp_default(SCOM,PREFIX)			\
	stx_base_plugin_funcimp_default(SCOM,PREFIX ## _ ## plug )\

#define stx_base_graph_create_default(vt,PREFIX,CLS,CAT,NAME)		\
	stx_base_plugin_create_default(vt,PREFIX ## _ ## plug,CLS,CAT,NAME); \
	stx_base_graph_vtinit(vt,PREFIX)

#define stx_base_graph_release_default(SCOM)			\
	stx_base_plugin_release_default(SCOM)\

#define stx_base_graph_release_begin(SCOM)			\
	stx_base_plugin_release_begin(SCOM)\

#define stx_base_graph_release_end(SCOM)			\
	stx_base_plugin_release_end(SCOM)\

#define stx_base_graph_query_default(SCOM,vt)			\
	if( IS_EQUAL_GID(gid,STX_IID_FilterGraph) ) {\
		the->i_ref ++;\
		*pp_interf = (void*)&vt;\
		return STX_OK;\
	}\
	stx_base_plugin_query_default(SCOM,vt)\

/*}}}**********************************************************************/



/*{{{**********************************************************************/

#define stx_base_graph_builder_funcdecl(PREFIX) \
	stx_base_plugin_funcdecl(PREFIX ## _ ## plug);\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## create_graph(THEE h,stx_base_graph** h_graph);\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## detach_graph(THEE h,stx_base_graph* h_graph);\
	STX_PURE s32		PREFIX ## _xxx_ ## get_max_subtask(THEE h);\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## enum_ssrc(THEE h,s32* i_idx,stx_sync_source** hh);\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## alloc_ssrc( \
		THEE h,b32 b_cpu,stx_sync_source* h_ori,s32 i_ssrc,stx_sync_source* hh_alloc[]);\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## reg_plug(THEE h,stx_base_plugin* plug);\
	STX_PURE void		PREFIX ## _xxx_ ## unreg_plug(THEE h,stx_base_plugin* plug);\
	STX_PURE u32		PREFIX ## _xxx_ ## get_occupy(THEE h)


#define stx_base_graph_builder_vtinit(vt,PREFIX) \
	STX_VT_INIT(vt,PREFIX,create_graph);\
	STX_VT_INIT(vt,PREFIX,detach_graph);\
	STX_VT_INIT(vt,PREFIX,get_max_subtask);\
	STX_VT_INIT(vt,PREFIX,enum_ssrc);\
	STX_VT_INIT(vt,PREFIX,alloc_ssrc);\
	STX_VT_INIT(vt,PREFIX,reg_plug);\
	STX_VT_INIT(vt,PREFIX,unreg_plug);\
	STX_VT_INIT(vt,PREFIX,get_occupy)

#define stx_base_graph_builder_data_default()			\
	stx_base_plugin_data_default()

#define stx_base_graph_builder_funcimp_default(SCOM,PREFIX)			\
	stx_base_plugin_funcimp_default(SCOM,PREFIX ## _ ## plug )\

#define stx_base_graph_builder_create_default(vt,PREFIX,CLS,CAT,NAME)		\
	stx_base_plugin_create_default(vt,PREFIX ## _ ## plug,CLS,CAT,NAME); \
	stx_base_graph_builder_vtinit(vt,PREFIX)

#define stx_base_graph_builder_release_default(SCOM)			\
	stx_base_plugin_release_default(SCOM)\

#define stx_base_graph_builder_release_begin(SCOM)			\
	stx_base_plugin_release_begin(SCOM)\

#define stx_base_graph_builder_release_end(SCOM)			\
	stx_base_plugin_release_end(SCOM)\

#define stx_base_graph_builder_query_default(SCOM,vt)			\
	if( IS_EQUAL_GID(gid,STX_IID_GraphBuilder) ) {\
		the->i_ref ++;\
		*pp_interf = (void*)&vt;\
		return STX_OK;\
	}\
	stx_base_plugin_query_default(SCOM,vt)\

/*}}}**********************************************************************/

/*{{{**********************************************************************/

#define stx_media_type_funcdecl(PREFIX) \
	stx_base_com_funcdecl(PREFIX ## _ ## com)\
	STX_PURE void			PREFIX ## _xxx_ ## set_type( STX_HANDLE h, stx_gid gid_type );\
	STX_PURE stx_gid		PREFIX ## _xxx_ ## get_type( STX_HANDLE h);\
	STX_PURE void 			PREFIX ## _xxx_ ## set_subtype( STX_HANDLE h, stx_gid gid_sub_type );\
	STX_PURE stx_gid		PREFIX ## _xxx_ ## get_subtype( STX_HANDLE h);\
	STX_PURE STX_RESULT		PREFIX ## _xxx_ ## get_header( STX_HANDLE h , void** pp_hdr, s32* i_len );\
	STX_PURE STX_RESULT		PREFIX ## _xxx_ ## set_header( STX_HANDLE h, void* p_hdr, s32 i_len );\
	STX_PURE void			PREFIX ## _xxx_ ## set_type_name( STX_HANDLE h, const char* sz_name );\
	STX_PURE const char*	PREFIX ## _xxx_ ## get_type_name( STX_HANDLE h);\
	STX_PURE void			PREFIX ## _xxx_ ## set_subtype_name( STX_HANDLE h, const char* sz_name );\
	STX_PURE const char*	PREFIX ## _xxx_ ## get_subtype_name( STX_HANDLE h)

#define stx_media_type_vtinit(vt,PREFIX) \
	STX_VT_INIT(vt,PREFIX,set_type);\
	STX_VT_INIT(vt,PREFIX,get_type);\
	STX_VT_INIT(vt,PREFIX,set_subtype);\
	STX_VT_INIT(vt,PREFIX,get_subtype);\
	STX_VT_INIT(vt,PREFIX,get_header);\
	STX_VT_INIT(vt,PREFIX,set_header);\
	STX_VT_INIT(vt,PREFIX,set_type_name);\
	STX_VT_INIT(vt,PREFIX,get_type_name);\
	STX_VT_INIT(vt,PREFIX,set_subtype_name);\
	STX_VT_INIT(vt,PREFIX,get_subtype_name)

#define stx_media_type_data_default()			\
	stx_base_com_data_default()

#define stx_media_type_funcimp_default(SCOM,PREFIX)			\
	stx_base_com_funcimp_default(SCOM,PREFIX ## _ ## com )\

#define stx_media_type_create_default(vt,PREFIX,CLS,CAT,NAME)		\
	stx_base_com_create_default(vt,PREFIX ## _ ## com,CLS,CAT,NAME);\
	stx_media_type_vtinit(vt,PREFIX)

#define stx_media_type_release_default(SCOM)			\
	stx_base_com_release_default(SCOM)\

#define stx_media_type_release_begin(SCOM)			\
	stx_base_com_release_begin(SCOM)\

#define stx_media_type_release_end(SCOM)			\
	stx_base_com_release_end(SCOM)\

#define stx_media_type_query_default(SCOM,vt)			\
	if( IS_EQUAL_GID(gid,STX_IID_MediaType) ) {\
		the->i_ref ++;\
		*pp_interf = (void*)&vt;\
		return STX_OK;\
	}\
	stx_base_com_query_default(SCOM,vt)\

/*}}}**********************************************************************/

/*{{{**********************************************************************/

#define stx_media_data_funcdecl(PREFIX) \
	stx_base_com_funcdecl(PREFIX ## _ ## com)\
	STX_PURE size_t		PREFIX ## _xxx_ ## get_buf_len( STX_HANDLE h);\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## resize( STX_HANDLE h, size_t i_new_size );\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## get_data( STX_HANDLE h, void** pp_data, size_t* i_data_size );\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## set_data_len( STX_HANDLE h, size_t i_len );\
	STX_PURE size_t		PREFIX ## _xxx_ ## get_data_len( STX_HANDLE h);\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## set_time( STX_HANDLE h,s64 i_pts,s64 i_dts );\
	STX_PURE s64		PREFIX ## _xxx_ ## get_time( STX_HANDLE h, s64* i_dts );\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## set_duration( STX_HANDLE h, s64 i_duration);\
	STX_PURE s64		PREFIX ## _xxx_ ## get_duration( STX_HANDLE h );\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## set_flags( STX_HANDLE h, size_t i_flags );\
	STX_PURE size_t		PREFIX ## _xxx_ ## get_flags( STX_HANDLE h );\
	STX_PURE s32		PREFIX ## _xxx_ ## incr( THEE h );\
	STX_PURE s32		PREFIX ## _xxx_ ## decr( THEE h )

#define stx_media_data_vtinit(vt,PREFIX) \
	STX_VT_INIT(vt,PREFIX,get_buf_len);\
	STX_VT_INIT(vt,PREFIX,resize);\
	STX_VT_INIT(vt,PREFIX,get_data);\
	STX_VT_INIT(vt,PREFIX,set_data_len);\
	STX_VT_INIT(vt,PREFIX,get_data_len);\
	STX_VT_INIT(vt,PREFIX,set_time);\
	STX_VT_INIT(vt,PREFIX,get_time);\
	STX_VT_INIT(vt,PREFIX,set_duration);\
	STX_VT_INIT(vt,PREFIX,get_duration);\
	STX_VT_INIT(vt,PREFIX,set_flags);\
	STX_VT_INIT(vt,PREFIX,get_flags);\
	STX_VT_INIT(vt,PREFIX,incr);\
	STX_VT_INIT(vt,PREFIX,decr)

#define stx_media_data_data_default()			\
	stx_base_com_data_default();\
	s32 i_dref

#define stx_media_data_funcimp_default(SCOM,PREFIX)			\
	stx_base_com_funcimp_default(SCOM,PREFIX ## _ ## com )\
	STX_PURE s32 PREFIX ## _xxx_ ## incr(THEE h){\
		STX_MAP_THE(SCOM);\
		the->i_dref ++; \
		return the->i_dref;\
	}\
	STX_PURE s32 PREFIX ## _xxx_ ## decr(THEE h){\
		STX_MAP_THE(SCOM);\
		the->i_dref --; \
		return the->i_dref;\
	}

#define stx_media_data_create_default(vt,PREFIX,CLS,CAT,NAME)		\
	stx_base_com_create_default(vt,PREFIX ## _ ## com,CLS,CAT,NAME); \
	stx_media_data_vtinit(vt,PREFIX)

#define stx_media_data_release_default(SCOM)			\
	stx_base_com_release_default(SCOM)\

#define stx_media_data_release_begin(SCOM)			\
	stx_base_com_release_begin(SCOM)\

#define stx_media_data_release_end(SCOM)			\
	stx_base_com_release_end(SCOM)\

#define stx_media_data_query_default(SCOM,vt)			\
	if( IS_EQUAL_GID(gid,STX_IID_MediaData) ) {\
		the->i_ref ++;\
		*pp_interf = (void*)&vt;\
		return STX_OK;\
	}\
	stx_base_com_query_default(SCOM,vt)\

/*}}}**********************************************************************/

/*{{{**********************************************************************/

#define stx_media_data_allocator_funcdecl(PREFIX) \
	stx_base_com_funcdecl(PREFIX ## _ ## com)\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## set_param( STX_HANDLE h, void* param, s32 i_len );\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## get_param( STX_HANDLE h, void* param , s32* i_len );\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## reset(STX_HANDLE h);\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## get_media_data( STX_HANDLE h, stx_media_data** pp_mda, s32 i_wait );\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## free_media_data( STX_HANDLE h, stx_media_data* p_mda )

#define stx_media_data_allocator_vtinit(vt,PREFIX) \
	STX_VT_INIT(vt,PREFIX,set_param);\
	STX_VT_INIT(vt,PREFIX,get_param);\
	STX_VT_INIT(vt,PREFIX,reset);\
	STX_VT_INIT(vt,PREFIX,get_media_data);\
	STX_VT_INIT(vt,PREFIX,free_media_data)

#define stx_media_data_allocator_data_default()			\
	stx_base_com_data_default()

#define stx_media_data_allocator_funcimp_default(SCOM,PREFIX)			\
	stx_base_com_funcimp_default(SCOM,PREFIX ## _ ## com )\

#define stx_media_data_allocator_create_default(vt,PREFIX,CLS,CAT,NAME)		\
	stx_base_com_create_default(vt,PREFIX ## _ ## com,CLS,CAT,NAME); \
	stx_media_data_allocator_vtinit(vt,PREFIX)

#define stx_media_data_allocator_release_default(SCOM)			\
	stx_base_com_release_default(SCOM)\

#define stx_media_data_allocator_release_begin(SCOM)			\
	stx_base_com_release_begin(SCOM)\

#define stx_media_data_allocator_release_end(SCOM)			\
	stx_base_com_release_end(SCOM)\

#define stx_media_data_allocator_query_default(SCOM,vt)			\
	if( IS_EQUAL_GID(gid,STX_IID_MemAllocator) ) {\
		the->i_ref ++;\
		*pp_interf = (void*)&vt;\
		return STX_OK;\
	}\
	stx_base_com_query_default(SCOM,vt)\

/*}}}**********************************************************************/



/*{{{**********************************************************************/

#define stx_base_pin_funcdecl(PREFIX) \
	stx_base_plugin_funcdecl(PREFIX ## _ ## plug);\
	STX_PURE STX_BOOL		 PREFIX ## _xxx_ ## is_connected( THEE h ,stx_base_pin** pp_pin);\
	STX_PURE STX_RESULT		 PREFIX ## _xxx_ ## connect( THEE h, stx_base_pin* p_pin );\
	STX_PURE STX_RESULT		 PREFIX ## _xxx_ ## break_connect( THEE h );\
	STX_PURE stx_media_type* PREFIX ## _xxx_ ## get_media_type( THEE h );\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## set_media_type( THEE h, stx_media_type* p_mtype );\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## receive(THEE h, stx_media_data** pp_mdat,stx_sync_inf* h_sync);\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## deliver(THEE h, stx_media_data* p_mdat,stx_sync_inf* h_sync);\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## get_media_data( \
		THEE h, stx_media_data** pp_mda, s32 i_wait );\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## release_media_data( \
		THEE h, stx_media_data* p_mdat );\
	STX_PURE void PREFIX ## _xxx_ ## set_parent( THEE h, stx_base_plugin* p_parent )


#define stx_base_pin_vtinit(vt,PREFIX) \
	STX_VT_INIT(vt,PREFIX,is_connected);\
	STX_VT_INIT(vt,PREFIX,connect);\
	STX_VT_INIT(vt,PREFIX,break_connect);\
	STX_VT_INIT(vt,PREFIX,get_media_type);\
	STX_VT_INIT(vt,PREFIX,set_media_type);\
	STX_VT_INIT(vt,PREFIX,receive);\
	STX_VT_INIT(vt,PREFIX,deliver);\
	STX_VT_INIT(vt,PREFIX,get_media_data);\
	STX_VT_INIT(vt,PREFIX,release_media_data);\
	STX_VT_INIT(vt,PREFIX,set_parent)


#define stx_base_pin_data_default()			\
	stx_base_plugin_data_default() \
	stx_base_filter*	p_flt;


#define stx_base_pin_funcimp_default(SCOM,PREFIX)			\
	STX_PURE void PREFIX ## _xxx_ ## set_parent( STX_HANDLE h, stx_base_plugin* p_parent ){\
		STX_RESULT i_err;\
		STX_MAP_THE(SCOM);\
		the->p_parent = p_parent;\
		i_err = p_parent->query_interf(p_parent,STX_IID_BaseFilter,(void**)&the->p_flt);\
		if( STX_OK != i_err ) {\
			return;\
		}\
		the->p_flt->release(the->p_flt); /* decrease the filter's ref counter;*/\
	}\
	stx_base_plugin_funcimp_default(SCOM,PREFIX ## _ ## plug ) \


#define stx_base_pin_create_default(vt,PREFIX,CLS,CAT,NAME)		\
	stx_base_plugin_create_default(vt,PREFIX ## _ ## plug,CLS,CAT,NAME); \
	stx_base_pin_vtinit(vt,PREFIX)

#define stx_base_pin_release_default(SCOM)			\
	stx_base_plugin_release_default(SCOM)\

#define stx_base_pin_release_begin(SCOM)			\
	stx_base_plugin_release_begin(SCOM)\

#define stx_base_pin_release_end(SCOM)			\
	stx_base_plugin_release_end(SCOM)\

#define stx_base_pin_query_default(SCOM,vt)			\
	if( IS_EQUAL_GID(gid,STX_IID_BasePin) ) {\
		the->i_ref ++;\
		*pp_interf = (void*)&vt;\
		return STX_OK;\
	}\
	stx_base_plugin_query_default(SCOM,vt)\

/*}}}**********************************************************************/


/*{{{**********************************************************************/

#define stx_output_pin_funcdecl(PREFIX) \
	stx_base_pin_funcdecl(PREFIX ## _ ## pin);\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## set_mem_allocator( STX_HANDLE h, stx_media_data_allocator* p_alloc );\
	STX_PURE stx_media_data_allocator* PREFIX ## _xxx_ ## get_mem_allocator( STX_HANDLE h )

#define stx_output_pin_vtinit(vt,PREFIX) \
	STX_VT_INIT(vt,PREFIX,set_mem_allocator);\
	STX_VT_INIT(vt,PREFIX,get_mem_allocator)

#define stx_output_pin_data_default()			\
	stx_base_pin_data_default()

#define stx_output_pin_funcimp_default(SCOM,PREFIX)			\
	stx_base_pin_funcimp_default(SCOM,PREFIX ## _ ## pin )\


#define stx_output_pin_create_default(vt,PREFIX,CLS,CAT,NAME)		\
	stx_base_pin_create_default(vt,PREFIX ## _ ## pin,CLS,CAT,NAME); \
	stx_output_pin_vtinit(vt,PREFIX)

#define stx_output_pin_release_default(SCOM)			\
	stx_base_pin_release_default(SCOM)\

#define stx_output_pin_release_begin(SCOM)			\
	stx_base_pin_release_begin(SCOM)\

#define stx_output_pin_release_end(SCOM)			\
	stx_base_pin_release_end(SCOM)\

#define stx_output_pin_query_default(SCOM,vt)			\
	if( IS_EQUAL_GID(gid,STX_IID_OutputPin) ) {\
		the->i_ref ++;\
		*pp_interf = (void*)&vt;\
		return STX_OK;\
	}\
	stx_base_pin_query_default(SCOM,vt)\

/*}}}**********************************************************************/



/*{{{**********************************************************************/
// TO DO , add other type;
#define MEDIA_TYPE_MAP_ITEM(a,b) { &a,&b,&sz_ ## a, &sz_ ## b},

#define MEDIA_TYPE_MAP_BEGIN(SCOM,NAME) \
	static stx_media_type_map SCOM ## NAME[] = { MEDIA_TYPE_MAP_ITEM(STX_GID_NULL,STX_GID_NULL)

#define MEDIA_TYPE_MAP_END() };

#define INPUT_MEDIA_TYPE_MAP_NAME(SCOM) SCOM ## _input_media_type_map
#define OUTPUT_MEDIA_TYPE_MAP_NAME(SCOM) SCOM ## _output_media_type_map

#define STX_INPUT_MEDIA_TYPE_MAP_BEGIN(SCOM) MEDIA_TYPE_MAP_BEGIN(SCOM,_input_media_type_map)
#define STX_INPUT_MEDIA_TYPE_MAP_END() MEDIA_TYPE_MAP_END()


#define STX_OUTPUT_MEDIA_TYPE_MAP_BEGIN(SCOM) MEDIA_TYPE_MAP_BEGIN(SCOM,_output_media_type_map)
#define STX_OUTPUT_MEDIA_TYPE_MAP_END() MEDIA_TYPE_MAP_END()



#define stx_base_filter_funcdecl(PREFIX) \
	stx_base_plugin_funcdecl(PREFIX ## _ ## plug);\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## enum_input_pin(THEE h,s32* i_index,stx_base_pin** pp_pin);\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## enum_output_pin(THEE h,s32* i_index,stx_base_pin** pp_pin);\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## enum_input_media_type(THEE h,s32* i_index,stx_media_type_inf* p_inf );\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## check_input_media_type(THEE h,stx_media_type* p_mtype );\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## set_input_media_type(THEE h, stx_media_type* p_mtype );\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## enum_output_media_type(THEE h,s32* i_index,stx_media_type_inf* p_inf );\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## check_output_media_type(THEE h,stx_media_type* p_mtype );\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## set_output_media_type(THEE h,stx_media_type* p_mtype );\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## new_segment( THEE h );\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## deliver(\
		STX_HANDLE			h, \
		stx_base_pin*		h_pin, \
		stx_media_data*		p_mdat,stx_sync_inf* h_sync \
		);\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## receive( \
		STX_HANDLE			h, \
		stx_base_pin*		h_pin, \
		stx_media_data**	pp_mdat,stx_sync_inf* h_sync\
		)
								
#define stx_base_filter_vtinit(vt,PREFIX) \
	STX_VT_INIT(vt,PREFIX,enum_input_pin);\
	STX_VT_INIT(vt,PREFIX,enum_output_pin);\
	STX_VT_INIT(vt,PREFIX,enum_input_media_type);\
	STX_VT_INIT(vt,PREFIX,check_input_media_type);\
	STX_VT_INIT(vt,PREFIX,set_input_media_type);\
	STX_VT_INIT(vt,PREFIX,enum_output_media_type);\
	STX_VT_INIT(vt,PREFIX,check_output_media_type);\
	STX_VT_INIT(vt,PREFIX,set_output_media_type);\
	STX_VT_INIT(vt,PREFIX,new_segment);\
	STX_VT_INIT(vt,PREFIX,deliver);\
	STX_VT_INIT(vt,PREFIX,receive)

#define  BLANK_PIN  ((stx_base_pin*)0xff)
#define  BLANK_OUTPUTPIN  ((stx_output_pin*)0xff)
#define  BLANK_DATA  ((stx_media_data*)0xff)


#define stx_base_filter_data_default()			\
	stx_base_plugin_data_default()


#define enum_media_type_func(SCOM,PREFIX,MAP_NAME,FUNC_NAME) \
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## FUNC_NAME(STX_HANDLE h,s32* i_index,stx_media_type_inf* p_inf )\
	{\
		STX_MAP_THE(SCOM);\
		if( !i_index ) {\
			return STX_ERR_INVALID_PARAM;\
		}\
		{\
			s32 idx;\
			const s32 i_size = ( sizeof( SCOM ## MAP_NAME ) / sizeof(SCOM ## MAP_NAME[0]) ) - 1;\
			if( !p_inf ) {\
				*i_index = i_size;\
				return STX_OK;\
			}\
			idx = *i_index;\
			if( idx >= 0 && idx < i_size ) {\
				p_inf->major_type = * SCOM ## MAP_NAME[idx+1].major_type ;\
				p_inf->sub_type = * SCOM ## MAP_NAME[idx+1].sub_type ;\
				p_inf->major_type_name = SCOM ## MAP_NAME[idx+1].major_type_name;\
				p_inf->sub_type_name = SCOM ## MAP_NAME[idx+1].sub_type_name;\
				return STX_OK;\
			}\
			return STX_ERR_INVALID_PARAM;	\
		}\
	}

#define stx_base_filter_funcimp_default(SCOM,PREFIX)			\
	stx_base_plugin_funcimp_default(SCOM,PREFIX ## _ ## plug )\
	enum_media_type_func(SCOM,PREFIX,_input_media_type_map,enum_input_media_type)\
	enum_media_type_func(SCOM,PREFIX,_output_media_type_map,enum_output_media_type)\


#define stx_base_filter_create_default(vt,PREFIX,CLS,CAT,NAME)		\
	stx_base_plugin_create_default(vt,PREFIX ## _ ## plug,CLS,CAT,NAME); \
	stx_base_filter_vtinit(vt,PREFIX)

#define stx_base_filter_release_default(SCOM)			\
	stx_base_plugin_release_default(SCOM)

#define stx_base_filter_release_begin(SCOM)			\
	stx_base_plugin_release_begin(SCOM)\

#define stx_base_filter_release_end(SCOM)			\
	stx_base_plugin_release_end(SCOM)\


#define stx_base_filter_query_default(SCOM,vt)			\
	if( IS_EQUAL_GID(gid,STX_IID_BaseFilter) ) {\
		the->i_ref ++;\
		*pp_interf = (void*)&vt;\
		return STX_OK;\
	}\
	stx_base_plugin_query_default(SCOM,vt)\

/*}}}**********************************************************************/


/*{{{**********************************************************************/

#define stx_base_control_funcdecl(PREFIX) \
	stx_base_com_funcdecl(PREFIX ## _ ## com)\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## get_caps(STX_HANDLE h,stx_xio* h_xio);\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## get_status(STX_HANDLE h,u32* i_status);\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## play(STX_HANDLE h);\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## pause(STX_HANDLE h);\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## resume(STX_HANDLE h);\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## set(STX_HANDLE h,u32 i_flag,size_t i_set);\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## stop(STX_HANDLE h);\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## next(STX_HANDLE h);\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## prev(STX_HANDLE h);\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## step(STX_HANDLE h)

#define stx_base_control_vtinit(vt,PREFIX) \
	STX_VT_INIT(vt,PREFIX,get_caps);\
	STX_VT_INIT(vt,PREFIX,get_status);\
	STX_VT_INIT(vt,PREFIX,play);\
	STX_VT_INIT(vt,PREFIX,pause);\
	STX_VT_INIT(vt,PREFIX,resume);\
	STX_VT_INIT(vt,PREFIX,set);\
	STX_VT_INIT(vt,PREFIX,stop);\
	STX_VT_INIT(vt,PREFIX,next);\
	STX_VT_INIT(vt,PREFIX,prev);\
	STX_VT_INIT(vt,PREFIX,step)

#define stx_base_control_data_default()			\
	stx_base_com_data_default()

#define stx_base_control_funcimp_default(SCOM,PREFIX)			\
	stx_base_com_funcimp_default(SCOM,PREFIX ## _ ## com )\

#define stx_base_control_create_default(vt,PREFIX,CLS,CAT,NAME)		\
	stx_base_com_create_default(vt,PREFIX ## _ ## com,CLS,CAT,NAME); \
	stx_base_control_vtinit(vt,PREFIX)

#define stx_base_control_release_default(SCOM)			\
	stx_base_com_release_default(SCOM)\

#define stx_base_control_release_begin(SCOM)			\
	stx_base_com_release_begin(SCOM)\

#define stx_base_control_release_end(SCOM)			\
	stx_base_com_release_end(SCOM)\

#define stx_base_control_query_default(SCOM,vt)			\
	if( IS_EQUAL_GID(gid,STX_IID_BaseControl) ) {\
		the->i_ref ++;\
		*pp_interf = (void*)&vt;\
		return STX_OK;\
	}\
	stx_base_com_query_default(SCOM,vt)\

/*}}}**********************************************************************/

/*{{{**********************************************************************/
#define stx_speed_control_funcdecl(PREFIX) \
	stx_base_com_funcdecl(PREFIX ## _ ## com)\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## get_caps(STX_HANDLE h,stx_xio* h_xio);\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## set_speed(STX_HANDLE h, f64 r_speed );\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## get_speed(STX_HANDLE h, f64* r_speed );\

#define stx_speed_control_vtinit(vt,PREFIX) \
	STX_VT_INIT(vt,PREFIX,get_caps);\
	STX_VT_INIT(vt,PREFIX,set_speed);\
	STX_VT_INIT(vt,PREFIX,get_speed)

#define stx_speed_control_data_default()			\
	stx_base_com_data_default()

#define stx_speed_control_funcimp_default(SCOM,PREFIX)			\
	stx_base_com_funcimp_default(SCOM,PREFIX ## _ ## com )\

#define stx_speed_control_create_default(vt,PREFIX,CLS,CAT,NAME)		\
	stx_base_com_create_default(vt,PREFIX ## _ ## com,CLS,CAT,NAME); \
	stx_speed_control_vtinit(vt,PREFIX)

#define stx_speed_control_release_default(SCOM)			\
	stx_base_com_release_default(SCOM)\

#define stx_speed_control_release_begin(SCOM)			\
	stx_base_com_release_begin(SCOM)\

#define stx_speed_control_release_end(SCOM)			\
	stx_base_com_release_end(SCOM)\

#define stx_speed_control_query_default(SCOM,vt)			\
	if( IS_EQUAL_GID(gid,STX_IID_SpeedControl) ) {\
		the->i_ref ++;\
		*pp_interf = (void*)&vt;\
		return STX_OK;\
	}\
	stx_base_com_query_default(SCOM,vt)\

/*}}}**********************************************************************/

/*{{{**********************************************************************/
#define stx_base_source_funcdecl(PREFIX) \
	stx_base_com_funcdecl(PREFIX ## _ ## com)\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## load_stream(STX_HANDLE h, const char* sz_stream,stx_sync_inf* h_sync);\
	STX_PURE void       PREFIX ## _xxx_ ## close_stream(STX_HANDLE h);\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## set_pos(STX_HANDLE h,s64 i_pos);\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## get_pos(STX_HANDLE h,s64 *i_pos);\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## get_size(STX_HANDLE h,s64 *i_size)

#define stx_base_source_vtinit(vt,PREFIX) \
	STX_VT_INIT(vt,PREFIX,load_stream);\
	STX_VT_INIT(vt,PREFIX,close_stream);\
	STX_VT_INIT(vt,PREFIX,set_pos);\
	STX_VT_INIT(vt,PREFIX,get_pos);\
	STX_VT_INIT(vt,PREFIX,get_size)

#define stx_base_source_data_default()			\
	stx_base_com_data_default()

#define stx_base_source_funcimp_default(SCOM,PREFIX)			\
	stx_base_com_funcimp_default(SCOM,PREFIX ## _ ## com )\

#define stx_base_source_create_default(vt,PREFIX,CLS,CAT,NAME)		\
	stx_base_com_create_default(vt,PREFIX ## _ ## com,CLS,CAT,NAME); \
	stx_base_source_vtinit(vt,PREFIX)

#define stx_base_source_release_default(SCOM)			\
	stx_base_com_release_default(SCOM)\

#define stx_base_source_release_begin(SCOM)			\
	stx_base_com_release_begin(SCOM)\

#define stx_base_source_release_end(SCOM)			\
	stx_base_com_release_end(SCOM)\

#define stx_base_source_query_default(SCOM,vt)			\
	if( IS_EQUAL_GID(gid,STX_IID_FileSource) ) {\
		the->i_ref ++;\
		*pp_interf = (void*)&vt;\
		return STX_OK;\
	}\
	stx_base_com_query_default(SCOM,vt)\


/*}}}**********************************************************************/

/*{{{**********************************************************************/
#define stx_media_info_funcdecl(PREFIX) \
	stx_base_com_funcdecl(PREFIX ## _ ## com)\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## get_desc(STX_HANDLE h, s32* i_len, char** sz_desc );\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## get_statistic(STX_HANDLE h, s32* i_len, char** sz_desc );\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## get_total_time(STX_HANDLE h,s64 *i_time);\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## get_current_time(STX_HANDLE h,s64 *i_time);\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## time_to_pos(STX_HANDLE h,s64 i_time,offset_t * pos );\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## pos_to_time(STX_HANDLE h, offset_t pos ,s64* i_time )

#define stx_media_info_vtinit(vt,PREFIX) \
	STX_VT_INIT(vt,PREFIX,get_desc);\
	STX_VT_INIT(vt,PREFIX,get_statistic);\
	STX_VT_INIT(vt,PREFIX,get_total_time);\
	STX_VT_INIT(vt,PREFIX,get_current_time);\
	STX_VT_INIT(vt,PREFIX,time_to_pos);\
	STX_VT_INIT(vt,PREFIX,pos_to_time)

#define stx_media_info_data_default()			\
	stx_base_com_data_default()

#define stx_media_info_funcimp_default(SCOM,PREFIX)			\
	stx_base_com_funcimp_default(SCOM,PREFIX ## _ ## com )\

#define stx_media_info_create_default(vt,PREFIX,CLS,CAT,NAME)		\
	stx_base_com_create_default(vt,PREFIX ## _ ## com,CLS,CAT,NAME); \
	stx_media_info_vtinit(vt,PREFIX)

#define stx_media_info_release_default(SCOM)			\
	stx_base_com_release_default(SCOM)\

#define stx_media_info_release_begin(SCOM)			\
	stx_base_com_release_begin(SCOM)\

#define stx_media_info_release_end(SCOM)			\
	stx_base_com_release_end(SCOM)\

#define stx_media_info_query_default(SCOM,vt)			\
	if( IS_EQUAL_GID(gid,STX_IID_MediaInfo) ) {\
		the->i_ref ++;\
		*pp_interf = (void*)&vt;\
		return STX_OK;\
	}\
	stx_base_com_query_default(SCOM,vt)\

/*}}}**********************************************************************/


/*{{{**********************************************************************/
#define stx_base_render_funcdecl(PREFIX) \
	stx_base_filter_funcdecl(PREFIX ## _ ## flt);\
	STX_PURE s64		PREFIX ## _xxx_ ## get_current_time( STX_HANDLE h );\
	STX_PURE void		PREFIX ## _xxx_ ## set_start_time( STX_HANDLE h, s64 i_start );\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## reset(STX_HANDLE h);\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## get_device_num(STX_HANDLE h,s32* i_num );\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## enum_device(STX_HANDLE h,s32 i_idx, STX_HANDLE* pp_dev );\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## set_device(STX_HANDLE h,s32 i_idx )

#define stx_base_render_vtinit(vt,PREFIX) \
	STX_VT_INIT(vt,PREFIX,get_current_time);\
	STX_VT_INIT(vt,PREFIX,set_start_time);\
	STX_VT_INIT(vt,PREFIX,reset);\
	STX_VT_INIT(vt,PREFIX,get_device_num);\
	STX_VT_INIT(vt,PREFIX,enum_device);\
	STX_VT_INIT(vt,PREFIX,set_device)

#define stx_base_render_data_default()			\
	stx_base_filter_data_default()

#define stx_base_render_funcimp_default(SCOM,PREFIX)			\
	stx_base_filter_funcimp_default(SCOM,PREFIX ## _ ## flt )\

#define stx_base_render_create_default(vt,PREFIX,CLS,CAT,NAME)		\
	stx_base_filter_create_default(vt,PREFIX ## _ ## flt,CLS,CAT,NAME ); \
	stx_base_render_vtinit(vt,PREFIX)

#define stx_base_render_release_default(SCOM)			\
	stx_base_filter_release_default(SCOM)\

#define stx_base_render_release_begin(SCOM)			\
	stx_base_filter_release_begin(SCOM)\

#define stx_base_render_release_end(SCOM)			\
	stx_base_filter_release_end(SCOM)\

#define stx_base_render_query_default(SCOM,vt)			\
	if( IS_EQUAL_GID(gid,STX_IID_BaseRender ) ) {\
		the->i_ref ++;\
		*pp_interf = (void*)&vt;\
		return STX_OK;\
	}\
	stx_base_filter_query_default(SCOM,vt)\

/*}}}**********************************************************************/

/*{{{**********************************************************************/
#define stx_audio_render_funcdecl(PREFIX) \
	stx_base_render_funcdecl(PREFIX ## _ ## rnd);\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## set_channels( STX_HANDLE h, s32 i_channels);\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## get_channels( STX_HANDLE h, s32* i_channels);\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## set_volume( STX_HANDLE h, s32 i_volume );\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## get_volume( STX_HANDLE h, s32* i_volume )

#define stx_audio_render_vtinit(vt,PREFIX) \
	STX_VT_INIT(vt,PREFIX,set_channels);\
	STX_VT_INIT(vt,PREFIX,get_channels);\
	STX_VT_INIT(vt,PREFIX,set_volume);\
	STX_VT_INIT(vt,PREFIX,get_volume)

#define stx_audio_render_data_default()			\
	stx_base_render_data_default()

#define stx_audio_render_funcimp_default(SCOM,PREFIX)			\
	stx_base_render_funcimp_default(SCOM,PREFIX ## _ ## rnd )\

#define stx_audio_render_create_default(vt,PREFIX,CLS,CAT,NAME)		\
	stx_base_render_create_default(vt,PREFIX ## _ ## rnd,CLS,CAT,NAME); \
	stx_audio_render_vtinit(vt,PREFIX)

#define stx_audio_render_release_default(SCOM)			\
	stx_base_render_release_default(SCOM)\

#define stx_audio_render_release_begin(SCOM)			\
	stx_base_render_release_begin(SCOM)\

#define stx_audio_render_release_end(SCOM)			\
	stx_base_render_release_end(SCOM)\

#define stx_audio_render_query_default(SCOM,vt)			\
	if( IS_EQUAL_GID(gid,STX_IID_AudioRender ) ) {\
		the->i_ref ++;\
		*pp_interf = (void*)&vt;\
		return STX_OK;\
	}\
	stx_base_render_query_default(SCOM,vt)\

/*}}}**********************************************************************/


/*{{{**********************************************************************/
#define stx_video_render_funcdecl(PREFIX) \
	stx_base_render_funcdecl(PREFIX ## _ ## rnd);\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## set_video_window( STX_HANDLE h, stx_base_plugin* p_video_window );\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## set_color_key( STX_HANDLE h, u32 i_color_key);\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## set_src_rect(STX_HANDLE h, STX_RECT rect );\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## set_dst_rect(STX_HANDLE h, STX_RECT rect );\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## hide(STX_HANDLE h);\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## show(STX_HANDLE h);\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## update(STX_HANDLE h)

#define stx_video_render_vtinit(vt,PREFIX) \
	STX_VT_INIT(vt,PREFIX,set_video_window);\
	STX_VT_INIT(vt,PREFIX,set_color_key);\
	STX_VT_INIT(vt,PREFIX,set_src_rect);\
	STX_VT_INIT(vt,PREFIX,set_dst_rect);\
	STX_VT_INIT(vt,PREFIX,hide);\
	STX_VT_INIT(vt,PREFIX,show);\
	STX_VT_INIT(vt,PREFIX,update)

#define stx_video_render_data_default()			\
	stx_base_render_data_default()

#define stx_video_render_funcimp_default(SCOM,PREFIX)			\
	stx_base_render_funcimp_default(SCOM,PREFIX ## _ ## rnd )\

#define stx_video_render_create_default(vt,PREFIX,CLS,CAT,NAME)		\
	stx_base_render_create_default(vt,PREFIX ## _ ## rnd,CLS,CAT,NAME); \
	stx_video_render_vtinit(vt,PREFIX)

#define stx_video_render_release_default(SCOM)			\
	stx_base_render_release_default(SCOM)\

#define stx_video_render_release_begin(SCOM)			\
	stx_base_render_release_begin(SCOM)\

#define stx_video_render_release_end(SCOM)			\
	stx_base_render_release_end(SCOM)\

#define stx_video_render_query_default(SCOM,vt)			\
	if( IS_EQUAL_GID(gid,STX_IID_VideoRender ) ) {\
		the->i_ref ++;\
		*pp_interf = (void*)&vt;\
		return STX_OK;\
	}\
	stx_base_render_query_default(SCOM,vt)\

/*}}}**********************************************************************/


/*{{{**********************************************************************/
#define stx_stream_writer_funcdecl(PREFIX) \
	stx_base_filter_funcdecl(PREFIX ## _ ## flt);\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## set_stream_name(STX_HANDLE h, const char* sz_name );\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## set_stream( STX_HANDLE h, stx_xio* p_output )

#define stx_stream_writer_vtinit(vt,PREFIX) \
	STX_VT_INIT(vt,PREFIX,set_stream_name);\
	STX_VT_INIT(vt,PREFIX,set_stream)

#define stx_stream_writer_data_default()			\
	stx_base_filter_data_default()

#define stx_stream_writer_funcimp_default(SCOM,PREFIX)			\
	stx_base_filter_funcimp_default(SCOM,PREFIX ## _ ## flt )\

#define stx_stream_writer_create_default(vt,PREFIX,CLS,CAT,NAME)		\
	stx_base_filter_create_default(vt,PREFIX ## _ ## flt,CLS,CAT,NAME ); \
	stx_stream_writer_vtinit(vt,PREFIX)

#define stx_stream_writer_release_default(SCOM)			\
	stx_base_filter_release_default(SCOM)\

#define stx_stream_writer_release_begin(SCOM)			\
	stx_base_filter_release_begin(SCOM)\

#define stx_stream_writer_release_end(SCOM)			\
	stx_base_filter_release_end(SCOM)\

#define stx_stream_writer_query_default(SCOM,vt)			\
	if( IS_EQUAL_GID(gid,STX_IID_FileWriter ) ) {\
		the->i_ref ++;\
		*pp_interf = (void*)&vt;\
		return STX_OK;\
	}\
	stx_base_filter_query_default(SCOM,vt)\

/*}}}**********************************************************************/


/*{{{**********************************************************************/
#define stx_stream_parser_funcdecl(PREFIX) \
	stx_base_com_funcdecl(PREFIX ## _ ## com) \
	STX_PURE void		  PREFIX ## _xxx_ ## reset(STX_HANDLE h);\
	STX_PURE void		  PREFIX ## _xxx_ ## flush(STX_HANDLE h);\
	STX_PURE STX_RESULT  PREFIX ## _xxx_ ## parse(\
	/**/STX_HANDLE		h, \
	/**/u8*				buf, \
	/**/size_t			i_len,\
	/**/u8**			buf_ptr); \
	STX_PURE STX_RESULT  PREFIX ## _xxx_ ## get_data(\
	/**/STX_HANDLE		h, \
	/**/stx_media_data*	p_mdat )


#define stx_stream_parser_vtinit(vt,PREFIX) \
	STX_VT_INIT(vt,PREFIX,reset);\
	STX_VT_INIT(vt,PREFIX,flush);\
	STX_VT_INIT(vt,PREFIX,parse);\
	STX_VT_INIT(vt,PREFIX,get_data)

#define stx_stream_parser_data_default()			\
	stx_base_com_data_default()

#define stx_stream_parser_funcimp_default(SCOM,PREFIX)			\
	stx_base_com_funcimp_default(SCOM,PREFIX ## _ ## com )\

#define stx_stream_parser_create_default(vt,PREFIX,CLS,CAT,NAME)		\
	stx_base_com_create_default(vt,PREFIX ## _ ## com,CLS,CAT,NAME); \
	stx_stream_parser_vtinit(vt,PREFIX)

#define stx_stream_parser_release_default(SCOM)			\
	stx_base_com_release_default(SCOM)\

#define stx_stream_parser_release_begin(SCOM)			\
	stx_base_com_release_begin(SCOM)\

#define stx_stream_parser_release_end(SCOM)			\
	stx_base_com_release_end(SCOM)\

#define stx_stream_parser_query_default(SCOM,vt)			\
	if( IS_EQUAL_GID(gid,STX_IID_StreamParser ) ) {\
		the->i_ref ++;\
		*pp_interf = (void*)&vt;\
		return STX_OK;\
	}\
	stx_base_com_query_default(SCOM,vt)\
/*}}}**********************************************************************/




/*{{{**********************************************************************/
#define stx_smart_tee_funcdecl(PREFIX) \
	stx_base_filter_funcdecl(PREFIX ## _ ## flt);\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## set_output_pin_num(STX_HANDLE h, s32 i_num )

#define stx_smart_tee_vtinit(vt,PREFIX) \
	STX_VT_INIT(vt,PREFIX,set_output_pin_num)

#define stx_smart_tee_data_default()			\
	stx_base_filter_data_default()

#define stx_smart_tee_funcimp_default(SCOM,PREFIX)			\
	stx_base_filter_funcimp_default(SCOM,PREFIX ## _ ## flt )\

#define stx_smart_tee_create_default(vt,PREFIX,CLS,CAT,NAME)		\
	stx_base_filter_create_default(vt,PREFIX ## _ ## flt,CLS,CAT,NAME); \
	stx_smart_tee_vtinit(vt,PREFIX)

#define stx_smart_tee_release_default(SCOM)			\
	stx_base_filter_release_default(SCOM)\

#define stx_smart_tee_release_begin(SCOM)			\
	stx_base_filter_release_begin(SCOM)\

#define stx_smart_tee_release_end(SCOM)			\
	stx_base_filter_release_end(SCOM)\

#define stx_smart_tee_query_default(SCOM,vt)			\
	if( IS_EQUAL_GID(gid,STX_IID_SmartTee ) ) {\
		the->i_ref ++;\
		*pp_interf = (void*)&vt;\
		return STX_OK;\
	}\
	stx_base_filter_query_default(SCOM,vt)\

/*}}}**********************************************************************/

/*{{{**********************************************************************/
#define stx_base_player_funcdecl(PREFIX) \
	stx_base_com_funcdecl(PREFIX ## _ ## com)\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## send_cmd( STX_HANDLE h,\
	size_t i_msg, size_t i_wparam, size_t i_lparam, size_t i_ext )

#define stx_base_player_vtinit(vt,PREFIX) \
	stx_base_com_vtinit(vt,PREFIX ## _ ## com);\
	STX_VT_INIT(vt,PREFIX,send_cmd)
/*}}}**********************************************************************/

/*{{{**********************************************************************/
#define stx_base_module_funcdecl(PREFIX) \
	stx_base_plugin_funcdecl(PREFIX ## _ ## plug);\
	STX_PURE s32		PREFIX ## _xxx_ ## get_filter_num(STX_HANDLE h);\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## get_filter_gid(STX_HANDLE h, s32 i_index, stx_gid* p_gid);\
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## create_instance(STX_HANDLE h, stx_gid gid, STX_HANDLE* p_hinst )

#define stx_base_module_vtinit(vt,PREFIX) \
	STX_VT_INIT(vt,PREFIX,get_filter_num );\
	STX_VT_INIT(vt,PREFIX,get_filter_gid );\
	STX_VT_INIT(vt,PREFIX,create_instance)


#define stx_base_module_data_default()			\
	stx_base_plugin_data_default()\

#define stx_base_module_funcimp_default(SCOM,PREFIX)			\
	stx_base_plugin_funcimp_default(SCOM,PREFIX ## _ ## plug )

#define stx_base_module_create_default(vt,PREFIX,CLS,CAT,NAME)		\
	stx_base_plugin_create_default(vt,PREFIX ## _ ## plug,CLS,CAT,NAME); \
	stx_base_module_vtinit(vt,PREFIX)

#define stx_base_module_release_default(SCOM)			\
	stx_base_plugin_release_default(SCOM)

#define stx_base_module_release_begin(SCOM)			\
		stx_base_plugin_release_begin(SCOM)

#define stx_base_module_release_end(SCOM)			\
		stx_base_plugin_release_end(SCOM)

#define stx_base_module_query_default(SCOM,vt)			\
	if( IS_EQUAL_GID(gid,STX_IID_BaseModule) ) {\
		the->i_ref ++;\
		*pp_interf = (void*)&vt;\
		return STX_OK;\
	}\
	stx_base_plugin_query_default(SCOM,vt)\

/*}}}**********************************************************************/


/*{{{**********************************************************************/
#define stx_com_helper_vtdef() \
	stx_base_com_vtdef()\
	_STX_PURE STX_RESULT	(*enum_interf)(STX_HANDLE h, s32* i_index, stx_com_map_ctx* p_ctx );\

struct stx_com_helper{
	stx_com_helper_vtdef()
};

#define stx_com_helper_funcdecl(PREFIX) \
	stx_base_com_funcdecl(PREFIX ## _ ## com)\
	STX_PURE STX_RESULT		PREFIX ## _xxx_ ## enum_interf(STX_HANDLE h, s32* i_index, stx_com_map_ctx* p_ctx)

#define stx_com_helper_vtinit(vt,PREFIX) \
	STX_VT_INIT(vt,PREFIX,enum_interf )

#define stx_com_helper_data_default()			\
	stx_base_com_data_default()

#define stx_com_helper_funcimp_default(SCOM,PREFIX)			\
	stx_base_com_funcimp_default(SCOM,PREFIX ## _ ## com ) \
	STX_PURE STX_RESULT	PREFIX ## _xxx_ ## enum_interf(STX_HANDLE h,s32* i_index,stx_com_map_ctx* p_ctx )\
	{\
		STX_MAP_THE(SCOM);\
		if( !i_index ) {\
			return STX_ERR_INVALID_PARAM;\
		}\
		{\
			s32 idx;\
			const s32 i_size = ( sizeof( SCOM ## _interf_map ) / sizeof(SCOM ## _interf_map[0]) ) - 1;\
			if( !p_ctx ) {\
				*i_index = i_size;\
				return STX_OK;\
			}\
			idx = *i_index;\
			if( idx >= 0 && idx < i_size ) {\
				p_ctx->iid = * SCOM ## _interf_map[idx+1].iid ;\
				stx_strcpy(p_ctx->iid_name,64,SCOM ## _interf_map[idx+1].iid_name);\
				return STX_OK;\
			}\
			return STX_ERR_INVALID_PARAM;	\
		}\
	}

#define stx_com_helper_create_default(vt,PREFIX,CLS,CAT,NAME)		\
	stx_base_com_create_default(vt,PREFIX ## _ ## com,CLS,CAT,NAME); \
	stx_com_helper_vtinit(vt,PREFIX)

#define stx_com_helper_release_default(SCOM)			\
	stx_base_com_release_default(SCOM)

#define stx_com_helper_release_begin(SCOM)			\
	stx_base_com_release_begin(SCOM)

#define stx_com_helper_release_end(SCOM)			\
	stx_base_com_release_end(SCOM)

#define stx_com_helper_query_default(SCOM,vt)			\
	if( IS_EQUAL_GID(gid,STX_IID_StxComHelper) ) {\
		the->i_ref ++;\
		*pp_interf = (void*)&vt;\
		return STX_OK;\
	}\
	stx_base_com_query_default(SCOM,vt)\


/*}}}**********************************************************************/




/***********************************************************************/
#define STX_COM_FUNC_NAME(SCOM,name) __stx_ ## SCOM ## _ ## name

#define STX_COM_FUNC_STRING(SCOM,name) "__stx_" #SCOM "_" #name

#ifdef __USE_GNUC
#	define STX_COM_FUNC_DECL(SCOM,name,args...) __stx_ ## SCOM ## _ ## name(## args)
#else
#	define STX_COM_FUNC_DECL(SCOM,name,...)  __stx_ ## SCOM ## _ ## name(## __VA_ARGS__)
#endif
/***********************************************************************/



/***********************************************************************/
#define STX_COM_SIZE(SCOM)	sizeof_ ## SCOM()
#define STX_NEW_NAME(SCOM)	STX_COM_FUNC_NAME(SCOM,create)

#ifdef __USE_STX_DEBUG__
#	define STX_NEW_TYPE		( stx_base_com* (*) ( THEE,const char*,s32) )
#	define STX_NEW_RPOC(NAME)	stx_base_com* ( * NAME ) ( THEE,const char*,s32)

#	ifdef __USE_GNUC
#		define STX_NEW_DECL(RET,SCOM,args...) \
/**/			RET __stx_ ## SCOM ## _create( THEE hinst,const char* file, s32 line, ## args)
#	else
#		define STX_NEW_DECL(RET,SCOM,...) \
/**/			RET __stx_ ## SCOM ## _create( THEE hinst,const char* file, s32 line, ## __VA_ARGS__)
#	endif

#else

#	define STX_NEW_TYPE		( stx_base_com* (*) ( THEE) )
#	define STX_NEW_RPOC(NAME)	stx_base_com* ( * NAME ) ( THEE)
#	ifdef __USE_GNUC
#		define STX_NEW_DECL(RET,SCOM,args...) \
			RET __stx_ ## SCOM ## _create( THEE hinst,## args)
#	else
#		define STX_NEW_DECL(RET,SCOM,...) \
			RET __stx_ ## SCOM ## _create( THEE hinst,## __VA_ARGS__)
#	endif

#endif

/**/
#ifdef __USE_GNUC
#	define STX_COM(SCOM,args...) \
		STX_INTERF(SCOM);\
		STX_API size_t STX_COM_SIZE(SCOM);\
		STX_API stx_base_com* __stx_ ## SCOM ## _create( THEE hinst,const char* file, s32 line, ## args)
#else
#	define STX_COM(SCOM,...) \
		STX_INTERF(SCOM);\
		STX_API size_t STX_COM_SIZE(SCOM);\
		STX_API stx_base_com* __stx_ ## SCOM ## _create( THEE hinst,const char* file, s32 line,## __VA_ARGS__)
#endif
/***********************************************************************/



/***********************************************************************/
#define STX_COM_BEGIN(SCOM)	\
/**/	struct SCOM{\
/**/		stx_base_com	stx_base_com_vt;	\
/**/		STX_HANDLE		stx_com_helper_the;	\
/**/		stx_com_helper	stx_com_helper_vt
/**/
/**/		// add other member decl;
/**/
#define STX_COM_END() \
/**/	}
/***********************************************************************/


/***********************************************************************/
#ifdef __USE_GNUC
#	define DEBUG_XNEW(SON,HINS,FILE,LINE,args...)  \
/**/	__stx_ ## SON ## _create(HINS,FILE,LINE,## args)

#	ifdef __USE_STX_DEBUG__
#		define XNEW(SON,HINS,args...)  \
/**/			__stx_ ## SON ## _create(HINS, __THIS_FILE__,__LINE__, ## args)
#	else
#		define XNEW(SON,HINS,args...) \
/**/			__stx_ ## SON ## _create(HINS,## args)
#	endif
#else
#	define DEBUG_XNEW(SON,HINS,FILE,LINE,...)  \
/**/		__stx_ ## SON ## _create(HINS,FILE,LINE,## __VA_ARGS__)
#	ifdef __USE_STX_DEBUG__
#		define XNEW(SON,HINS,...)  \
/**/			__stx_ ## SON ## _create(HINS, __THIS_FILE__,__LINE__, ## __VA_ARGS__)
#	else
#		define XNEW(SON,HINS,...) \
/**/			__stx_ ## SON ## _create(HINS,## __VA_ARGS__)
#	endif
#endif





#define XDELETE(h) ((stx_base_com*)h)->release((THEE)h)
#define SAFE_XDELETE(h) if( h )XDELETE(h)
#define SAFE_XDELETE0(h) if( h ) { XDELETE(h); h = NULL; }
/***********************************************************************/


/***********************************************************************/
#ifdef __USE_GNUC
#	ifdef __USE_STX_DEBUG__
#		define STX_NEW_HDR(SCOM,args...) \
/**/		STX_API_IMP STX_NEW_DECL(stx_base_com*,SCOM,## args){\
/**/			STX_RESULT i_stx_err;\
/**/			SCOM* the;\
/**/			the = (SCOM*)hinst;\
/**/			if( !the ){\
/**/				the = (SCOM*)debug_mallocz(sizeof(SCOM),file,line);\
/**/				if( !the) {\
/**/					return NULL;\
/**/				}\
/**/				the->b_inst = TRUE;\
/**/			}\
/**/			else{\
/**/				memset(the,0,sizeof(SCOM));\
/**/			}\
/**/			the->i_ref = 1;\
/**/			the->stx_base_com_vt.query_interf = STX_COM_FUNC_NAME(SCOM,query_interf);\
/**/			the->stx_base_com_vt.add_ref = STX_COM_FUNC_NAME(SCOM,add_ref);\
/**/			the->stx_base_com_vt.release = STX_COM_FUNC_NAME(SCOM,release);\
/**/			STX_SET_THE(stx_com_helper);\
/**/			STX_COM_NEW_DEFAULT(stx_com_helper,the->stx_com_helper_vt,stx_com_helper_vt,DEFAULT_CODE,DEFAULT_CODE,DEFAULT_CODE);\
/**/			i_stx_err = STX_FAIL;\
/**/			do{
#	else
#		define STX_NEW_HDR(SCOM,args...) \
/**/		STX_API_IMP STX_NEW_DECL(stx_base_com*,SCOM,## args){\
/**/			STX_RESULT i_stx_err;\
/**/			SCOM* the;\
/**/			the = (SCOM*)hinst;\
/**/			if( !the ){\
/**/				the = (SCOM*)xmallocz(sizeof(SCOM));\
/**/				if( !the) {\
/**/					return STX_NULL;\
/**/				}\
/**/				the->b_inst = TRUE;\
/**/			}\
/**/			else{\
/**/				memset(the,0,sizeof(SCOM));\
/**/			}\
/**/			the->i_ref = 1;\
/**/			the->stx_base_com_vt.query_interf = STX_COM_FUNC_NAME(SCOM,query_interf);\
/**/			the->stx_base_com_vt.add_ref = STX_COM_FUNC_NAME(SCOM,add_ref);\
/**/			the->stx_base_com_vt.release = STX_COM_FUNC_NAME(SCOM,release);\
/**/			STX_SET_THE(stx_com_helper);\
/**/			STX_COM_NEW_DEFAULT(stx_com_helper,the->stx_com_helper_vt,stx_com_helper_vt,DEFAULT_CODE,DEFAULT_CODE,DEFAULT_CODE);\
/**/			i_stx_err = STX_FAIL;\
/**/			do{
#	endif

#	define STX_NEW_BEGIN(SCOM,args...)\
/**/		STX_API_IMP size_t STX_COM_SIZE(SCOM){ return sizeof(SCOM);}\
/**/		STX_PURE	s32  __stx_ ## SCOM ## _add_ref(STX_HANDLE h){\
/**/				STX_DIRECT_THE(SCOM);\
/**/				the->i_ref ++;\
/**/				return the->i_ref;\
/**/			}\
/**/		STX_PURE	STX_RESULT  __stx_ ## SCOM ## _query_interf(THEE h, stx_gid gid, THEE* pp_interf);\
/**/		STX_PURE	s32  __stx_ ## SCOM ## _release(STX_HANDLE h);\
/**/		STX_COM_FUNC_DECL_DEFAULT(stx_com_helper,stx_com_helper_vt);\
/**/		STX_COM_FUNCIMP_DEFAULT(SCOM,stx_com_helper,stx_com_helper_vt);\
/**/		STX_NEW_HDR(SCOM,## args)

#else

#	ifdef __USE_STX_DEBUG__
#		define STX_NEW_HDR(SCOM,...) \
/**/		STX_API_IMP STX_NEW_DECL(stx_base_com*,SCOM,## __VA_ARGS__){\
/**/			STX_RESULT i_stx_err;\
/**/			SCOM* the;\
/**/			the = (SCOM*)hinst;\
/**/			if( !the ){\
/**/				the = (SCOM*)debug_mallocz(sizeof(SCOM),file,line);\
/**/				if( !the) {\
/**/					return NULL;\
/**/				}\
/**/				the->b_inst = TRUE;\
/**/			}\
/**/			else{\
/**/				memset(the,0,sizeof(SCOM));\
/**/			}\
/**/			the->i_ref = 1;\
/**/			the->stx_base_com_vt.query_interf = STX_COM_FUNC_NAME(SCOM,query_interf);\
/**/			the->stx_base_com_vt.add_ref = STX_COM_FUNC_NAME(SCOM,add_ref);\
/**/			the->stx_base_com_vt.release = STX_COM_FUNC_NAME(SCOM,release);\
/**/			STX_SET_THE(stx_com_helper);\
/**/			STX_COM_NEW_DEFAULT(stx_com_helper,the->stx_com_helper_vt,stx_com_helper_vt,DEFAULT_CODE,DEFAULT_CODE,DEFAULT_CODE);\
/**/			i_stx_err = STX_FAIL;\
/**/			do{
#	else
#		define STX_NEW_HDR(SCOM,...) \
/**/		STX_API_IMP STX_NEW_DECL(stx_base_com*,SCOM,## __VA_ARGS__){\
/**/			STX_RESULT i_stx_err;\
/**/			SCOM* the;\
/**/			the = (SCOM*)hinst;\
/**/			if( !the ){\
/**/				the = (SCOM*)xmallocz(sizeof(SCOM));\
/**/				if( !the) {\
/**/					return STX_NULL;\
/**/				}\
/**/				the->b_inst = TRUE;\
/**/			}\
/**/			else{\
/**/				memset(the,0,sizeof(SCOM));\
/**/			}\
/**/			the->i_ref = 1;\
/**/			the->stx_base_com_vt.query_interf = STX_COM_FUNC_NAME(SCOM,query_interf);\
/**/			the->stx_base_com_vt.add_ref = STX_COM_FUNC_NAME(SCOM,add_ref);\
/**/			the->stx_base_com_vt.release = STX_COM_FUNC_NAME(SCOM,release);\
/**/			STX_SET_THE(stx_com_helper);\
/**/			STX_COM_NEW_DEFAULT(stx_com_helper,the->stx_com_helper_vt,stx_com_helper_vt,DEFAULT_CODE,DEFAULT_CODE,DEFAULT_CODE);\
/**/			i_stx_err = STX_FAIL;\
/**/			do{
#	endif

#	define STX_NEW_BEGIN(SCOM,...)\
/**/		STX_API_IMP size_t STX_COM_SIZE(SCOM){ return sizeof(SCOM);}\
/**/		STX_PURE	s32  __stx_ ## SCOM ## _add_ref(STX_HANDLE h){\
/**/				STX_DIRECT_THE(SCOM);\
/**/				the->i_ref ++;\
/**/				return the->i_ref;\
/**/			}\
/**/		STX_PURE	STX_RESULT  __stx_ ## SCOM ## _query_interf(THEE h, stx_gid gid, THEE* pp_interf);\
/**/		STX_PURE	s32  __stx_ ## SCOM ## _release(STX_HANDLE h);\
/**/		STX_COM_FUNC_DECL_DEFAULT(stx_com_helper,stx_com_helper_vt);\
/**/		STX_COM_FUNCIMP_DEFAULT(SCOM,stx_com_helper,stx_com_helper_vt);\
/**/		STX_NEW_HDR(SCOM,## __VA_ARGS__)

#endif




/**/
/**/	// add other code; 
/**/
#define STX_NEW_END()  \
/**/				i_stx_err = STX_OK;\
/**/			}while(FALSE);\
/**/			if( STX_OK != i_stx_err ) {\
/**/				XDELETE(the);\
/**/				return STX_NULL;\
/**/			}\
/**/			return (stx_base_com*)the; \
/**/		}
/***********************************************************************/

/***********************************************************************/
#define  STX_DELETE_BEGIN(SCOM) \
/**/s32 __stx_ ## SCOM ## _release(STX_HANDLE h)\
/**/{\
/**/	STX_DIRECT_THE(SCOM);\
/**/	the->i_ref --;\
/**/	if( the->i_ref > 0 ) {\
/**/		return the->i_ref;\
/**/	}\
/**/	{
/**/
/**//* add other code; */
/**/
#define STX_DELETE_END(BEGIN,FINAL) \
/**/	}\
/**/	{\
/**/		BEGIN\
/**/		if( the->b_inst ) {\
/**/			stx_free(the);\
/**/		}\
/**/		FINAL\
/**/	}\
/**/	return 0;\
/**/}
/***********************************************************************/

/***********************************************************************/
#define STX_QUERY_BEGIN(SCOM) \
/**/	STX_RESULT __stx_ ## SCOM ## _query_interf(STX_HANDLE h,stx_gid gid, STX_HANDLE* pp_interf)\
/**/	{\
/**/		STX_DIRECT_THE(SCOM);\
/**/		if( IS_EQUAL_GID( gid, STX_IID_BaseCom ) ) {\
/**/			the->i_ref ++;\
/**/			*pp_interf = the;\
/**/			return STX_OK;\
/**/		}\
/**/		stx_com_helper_query_default(SCOM,the->stx_com_helper_vt)
/**/
#define STX_QUERY_END()\
/**/		return STX_ERR_INVALID_PARAM;\
/**/	}
/***********************************************************************/


/***********************************************************************/

#ifdef __USE_GNUC

#	ifdef __USE_STX_DEBUG__

#		define CREATE_STX_COM_DECL(BASE,SCOM,args...) \
/**/BASE* create_ ## SCOM(THEE hinst,const char* file,s32 line, ## args);\
/**/
#		define CREATE_STX_COM_BEGIN(BASE,BASE_GID,SCOM,args...) \
/**/BASE* create_ ## SCOM(THEE hinst,const char* file,s32 line,## args )\
/**/{
/**/
#		define CREATE_STX_COM_END(BASE,BASE_GID,SCOM,args...) \
/**/	STX_RESULT			i_err;\
/**/	stx_base_com*		p;\
/**/	BASE*				pin;\
/**/	i_err = STX_FAIL;\
/**/	p = DEBUG_XNEW(SCOM,hinst,file,line,## args );\
/**/	if( !p ) {\
/**/		return NULL;\
/**/	}\
/**/	pin = NULL;\
/**/	i_err = p->query_interf(p,BASE_GID,(void**)&pin);\
/**/	SAFE_XDELETE(p);\
/**/	if( STX_OK != i_err ) {\
/**/		return NULL;\
/**/	}\
/**/	return pin;\
/**/}
/**/

#	else

#		define CREATE_STX_COM_DECL(BASE,SCOM,args...) \
/**/	BASE* create_ ## SCOM(THEE hinst,## args )
/**/
#		define CREATE_STX_COM_BEGIN(BASE,BASE_GID,SCOM,args...) \
/**/BASE* create_ ## SCOM(THEE hinst,## args )\
/**/{
/**/
#		define CREATE_STX_COM_END(BASE,BASE_GID,SCOM,args...) \
/**/	STX_RESULT			i_err;\
/**/	stx_base_com*		p;\
/**/	BASE*				pin;\
/**/	i_err = STX_FAIL;\
/**/	p = XNEW(SCOM,hinst,## args );\
/**/	if( !p ) {\
/**/		return NULL;\
/**/	}\
/**/	pin = STX_NULL;\
/**/	i_err = p->query_interf(p,BASE_GID,(void**)&pin);\
/**/	SAFE_XDELETE(p);\
/**/	if( STX_OK != i_err ) {\
/**/		return NULL;\
/**/	}\
/**/	return pin;\
/**/}
#	endif

#else

#	ifdef __USE_STX_DEBUG__

#		define CREATE_STX_COM_DECL(BASE,SCOM,...) \
/**/BASE* create_ ## SCOM(THEE hinst,const char* file,s32 line, ## __VA_ARGS__ );\
/**/
#		define CREATE_STX_COM_BEGIN(BASE,BASE_GID,SCOM,...) \
/**/BASE* create_ ## SCOM(THEE hinst,const char* file,s32 line,## __VA_ARGS__ )\
/**/{
/**/
#		define CREATE_STX_COM_END(BASE,BASE_GID,SCOM,...) \
/**/	STX_RESULT			i_err;\
/**/	stx_base_com*		p;\
/**/	BASE*				pin;\
/**/	i_err = STX_FAIL;\
/**/	p = DEBUG_XNEW(SCOM,hinst,file,line,## __VA_ARGS__ );\
/**/	if( !p ) {\
/**/		return NULL;\
/**/	}\
/**/	pin = NULL;\
/**/	i_err = p->query_interf(p,BASE_GID,(void**)&pin);\
/**/	SAFE_XDELETE(p);\
/**/	if( STX_OK != i_err ) {\
/**/		return NULL;\
/**/	}\
/**/	return pin;\
/**/}
/**/

#	else

#		define CREATE_STX_COM_DECL(BASE,SCOM,...) \
/**/	BASE* create_ ## SCOM(THEE hinst,## __VA_ARGS__ )
/**/
#		define CREATE_STX_COM_BEGIN(BASE,BASE_GID,SCOM,...) \
/**/BASE* create_ ## SCOM(THEE hinst,## __VA_ARGS__ )\
/**/{
/**/
#		define CREATE_STX_COM_END(BASE,BASE_GID,SCOM,...) \
/**/	STX_RESULT			i_err;\
/**/	stx_base_com*		p;\
/**/	BASE*				pin;\
/**/	i_err = STX_FAIL;\
/**/	p = XNEW(SCOM,hinst,## __VA_ARGS__ );\
/**/	if( !p ) {\
/**/		return NULL;\
/**/	}\
/**/	pin = STX_NULL;\
/**/	i_err = p->query_interf(p,BASE_GID,(void**)&pin);\
/**/	SAFE_XDELETE(p);\
/**/	if( STX_OK != i_err ) {\
/**/		return NULL;\
/**/	}\
/**/	return pin;\
/**/}
#	endif

#endif


/**/
#define CREATE_STX_COM(BASE,BASE_GID,SCOM) \
/**/CREATE_STX_COM_BEGIN(BASE,BASE_GID,SCOM)\
/**/CREATE_STX_COM_END(BASE,BASE_GID,SCOM)
/**/

/***********************************************************************/



/***********************************************************************/
#define STX_CREATE_MODULE_PROC() \
/**/TFFN_EXPORT	stx_base_module* stx_create_instance(\
/**/		STX_RESULT*				h_result,\
/**/		stx_base_graph_builder* h_gbd,\
/**/		void (*xtrace)(char*),\
/**/		u32 i_flag)
/**/
#define LP_STX_CREATE_MODULE_PROC(A) \
/**/	stx_base_module* (*A)(STX_RESULT*,stx_base_graph_builder*,void (*)(char*),u32)
/**/
#define STX_CREATE_MODULE_PROC_PTR	\
/**/	stx_base_module* (*)(STX_RESULT*,stx_base_graph_builder*,void (*)(char*),u32)
/**/
#define STX_PLUGIN_STRING(SCOM) "StreamX " #SCOM " Plugin"
/***********************************************************************/


/***********************************************************************/
#define STX_MODULE		static		 
/**/
/**/STX_INTERF(stx_module_item);
/**/struct stx_module_item{
/**/	stx_gid* gid;
/**/	STX_NEW_RPOC(proc);
/**/};

#ifdef __USE_STX_DEBUG__
#	define CALL_STX_NEW(A)  A(NULL,__THIS_FILE__,__LINE__)
#else
#	define CALL_STX_NEW(A)  A(NULL)
#endif

/**/
#define STX_MODULE_DECLARE(GID,PROC)	{&GID,STX_NEW_NAME(PROC) },
/**/
#define STX_BEGIN_MODULE_MAP	STX_MODULE stx_module_item the_module_gid[] = { {&STX_GID_NULL,NULL},
/**/
#define STX_MODULE_NUM          ( sizeof( the_module_gid) / sizeof(the_module_gid[0]) - 1)
/**/
#define STX_END_MODULE_MAP() \
/**/};\
/**/STX_COM(stx_module_ctx);\
/**/\
/**/STX_COM_BEGIN(stx_module_ctx);\
/**/\
/**/	STX_PUBLIC(stx_base_module)\
/**/	STX_COM_DATA_DEFAULT(stx_base_module)\
/**/\
/**/STX_COM_END();\
/**/\
/**/STX_COM_FUNC_DECL_DEFAULT(stx_base_module,stx_base_module_vt);\
/**/STX_COM_FUNCIMP_DEFAULT(stx_module_ctx,stx_base_module,stx_base_module_vt);\
/**/STX_PRIVATE STX_RESULT	prev_create_module(void (*xtrace)(char*),u32 i_debug);\
/**/STX_PRIVATE STX_RESULT	post_create_module(stx_base_module *h,STX_RESULT i_err);\
/**/STX_PRIVATE STX_HANDLE	prev_destroy_module(stx_base_module *h);\
/**/STX_PRIVATE void		post_destroy_module(STX_HANDLE h_user);\
/**/STX_COM_MAP_BEGIN(stx_module_ctx)\
/**//**/STX_COM_MAP_ITEM(STX_IID_BaseModule)\
/**/STX_COM_MAP_END()\
/**/\
/**/STX_API_IMP \
/**/STX_NEW_BEGIN(stx_module_ctx) \
/**/{\
/**/	STX_SET_THE(stx_base_module);\
/**/	STX_COM_NEW_DEFAULT(stx_base_module,the->stx_base_module_vt,stx_base_module_vt,\
/**/		STX_GID_NULL,STX_GID_NULL,"stx_base_module");\
/**/}\
/**/STX_NEW_END()\
/**/\
/**/STX_PURE \
/**/STX_QUERY_BEGIN(stx_module_ctx) \
/**/{\
/**/    STX_COM_QUERY_DEFAULT(stx_base_module,the->stx_base_module_vt);\
/**/}\
/**/STX_QUERY_END()\
/**/\
/**/STX_PURE \
/**/STX_DELETE_BEGIN(stx_module_ctx)\
/**/{\
/**/	STX_COM_DELETE_DEFAULT(stx_base_module);\
/**/}\
/**/STX_DELETE_END\
/**/(\
/**/	STX_HANDLE h_user = prev_destroy_module(&the->stx_base_module_vt); \
/**/	STX_COM_DELETE_BEGIN(stx_base_module)\
/**/	,\
/**/	STX_COM_DELETE_END(stx_base_module)\
/**/	post_destroy_module(h_user); \
/**/)\
/**/\
/**/STX_PURE STX_RESULT \
/**/stx_base_module_vt_plug_xxx_get_property(STX_HANDLE h, stx_xio* h_xio)\
/**/{\
/**/	return STX_ERR_NOT_SUPPORT;\
/**/}\
/**/\
/**/STX_PURE STX_RESULT \
/**/stx_base_module_vt_plug_xxx_set_property(STX_HANDLE h, stx_xio* h_xio)\
/**/{\
/**/	return STX_ERR_NOT_SUPPORT;\
/**/}\
/**/\
/**/STX_PURE STX_RESULT \
/**/stx_base_module_vt_plug_xxx_send_msg(STX_HANDLE h, stx_base_message* p_msg)\
/**/{\
/**/	return STX_ERR_NOT_SUPPORT;\
/**/}\
/**/\
/**/STX_PURE STX_RESULT \
/**/stx_base_module_vt_plug_xxx_run(STX_HANDLE h, stx_sync_inf* h_sync )\
/**/{\
/**/	return STX_ERR_NOT_SUPPORT;\
/**/}\
/**/\
/**/\
/**/STX_PURE STX_RESULT \
/**/stx_base_module_vt_plug_xxx_flush(STX_HANDLE h, u32 i_flag,stx_sync_inf* h_sync )\
/**/{\
/**/	return STX_ERR_NOT_SUPPORT;\
/**/}\
/**/\
/**/\
/**/STX_PURE STX_RESULT \
/**/stx_base_module_vt_plug_xxx_start(STX_HANDLE h, u32 i_flag,stx_sync_inf* h_sync )\
/**/{\
/**/	return STX_ERR_NOT_SUPPORT;\
/**/}\
/**/\
/**/\
/**/STX_PURE STX_RESULT \
/**/stx_base_module_vt_plug_xxx_stop(STX_HANDLE h, u32 i_flag,stx_sync_inf* h_sync )\
/**/{\
/**/	return STX_ERR_NOT_SUPPORT;\
/**/}\
/**/\
/**/STX_PURE s32 \
/**/stx_base_module_vt_xxx_get_filter_num(STX_HANDLE h)\
/**/{\
/**/	STX_MAP_THE(stx_module_ctx);\
/**/	return STX_MODULE_NUM;\
/**/}\
/**/\
/**/STX_PURE STX_RESULT \
/**/stx_base_module_vt_xxx_get_filter_gid \
/**/(STX_HANDLE h, s32 i_index, stx_gid* p_gid) \
/**/{\
/**/	STX_MAP_THE(stx_module_ctx);\
/**/	if( i_index < 0  || i_index >= STX_MODULE_NUM  ) { \
/**/		return STX_ERR_INVALID_PARAM;\
/**/	}\
/**/	*p_gid = *the_module_gid[i_index+1].gid;\
/**/	return STX_OK;\
/**/}\
/**/\
/**/STX_PURE STX_RESULT \
/**/stx_base_module_vt_xxx_create_instance \
/**/(STX_HANDLE h, stx_gid gid, STX_HANDLE* p_hinst )\
/**/{\
/**/	STX_RESULT	i_err;\
/**/	STX_HANDLE  h_obj;\
/**/	s32         i; \
/**/	STX_MAP_THE(stx_module_ctx);\
/**/	i_err = STX_FAIL;\
/**/	h_obj = STX_NULL;\
/**/	for( i = 0; i < STX_MODULE_NUM; i ++ ) {\
/**/		if( IS_EQUAL_GID(gid,*the_module_gid[i+1].gid) ) {\
/**/			h_obj = CALL_STX_NEW(the_module_gid[i+1].proc);\
/**/			if( !h_obj ) {\
/**/				return STX_FAIL;\
/**/			}\
/**/			*p_hinst = h_obj;\
/**/			return STX_OK;\
/**/		}\
/**/	}\
/**/	return STX_ERR_FILE_NOT_FOUND;\
/**/}\
/**/\
/**/STX_CREATE_MODULE_PROC()\
/**/{\
/**/	STX_RESULT			i_err;\
/**/	stx_base_module*	the;\
/**/	stx_base_com*		p;\
/**/	p = NULL;\
/**/	the = NULL;\
/**/	do{\
/**/		if( STX_OK != prev_create_module(xtrace,i_flag)){\
/**/			break; \
/**/		}\
/**/		p = XNEW(stx_module_ctx,NULL);\
/**/		if( !p ) {\
/**/			break;\
/**/		}\
/**/		i_err = p->query_interf(p,STX_IID_BaseModule,(void**)&the);\
/**/		if( STX_OK != i_err ) {\
/**/			break;\
/**/		}\
/**/		the->set_gbd(the,h_gbd);\
/**/		h_gbd->add_ref(h_gbd);\
/**/		if( STX_OK != post_create_module(the,STX_OK)){\
/**/			break; \
/**/		}\
/**/		*h_result = STX_OK;\
/**/		SAFE_XDELETE(p);\
/**/		return the;\
/**/	}while(FALSE);\
/**/	SAFE_XDELETE(the);\
/**/	SAFE_XDELETE(p);\
/**/	post_create_module(NULL,STX_FAIL); \
/**/	*h_result = STX_FAIL;\
/**/	return STX_NULL;\
/**/}	
/**/
/***********************************************************************/



/***********************************************************************/
#define stx_base_filter_funcimp_part() \
STX_PURE	STX_RESULT		 \
stx_base_filter_vt_xxx_enum_input_pin \
(STX_HANDLE h,sint32* i_index,stx_base_pin** pp_pin) \
{ \
	return STX_ERR_NOT_SUPPORT; \
} \
STX_PURE	STX_RESULT		 \
stx_base_filter_vt_xxx_enum_output_pin \
(STX_HANDLE h,sint32* i_index,stx_base_pin** pp_pin) \
{ \
	return STX_ERR_NOT_SUPPORT; \
} \
STX_PURE	STX_RESULT		 \
stx_base_filter_vt_xxx_check_input_media_type \
(STX_HANDLE h,stx_media_type* p_mtyp) \
{ \
	return STX_ERR_NOT_SUPPORT; \
} \
STX_PURE	STX_RESULT		 \
stx_base_filter_vt_xxx_check_output_media_type \
(STX_HANDLE h,stx_media_type* p_mtyp) \
{ \
	return STX_ERR_NOT_SUPPORT; \
} \
STX_PURE STX_RESULT  \
stx_base_filter_vt_xxx_set_input_media_type \
( STX_HANDLE h,stx_media_type * p_mtype) \
{ \
	return STX_ERR_NOT_SUPPORT; \
} \
STX_PURE STX_RESULT  \
stx_base_filter_vt_xxx_set_output_media_type \
( STX_HANDLE h,stx_media_type * p_mtype) \
{ \
	return STX_ERR_NOT_SUPPORT; \
} \
STX_PURE	STX_RESULT			 \
stx_base_filter_vt_xxx_new_segment( STX_HANDLE h) \
{ \
	return STX_OK; \
} \
STX_PURE	STX_RESULT			 \
stx_base_filter_vt_xxx_flush(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync) \
{ \
	return STX_OK; \
} \
STX_PURE	STX_RESULT			 \
stx_base_filter_vt_xxx_start(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync) \
{ \
	return STX_OK; \
} \
STX_PURE	STX_RESULT			 \
stx_base_filter_vt_xxx_stop(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync) \
{ \
	return STX_OK; \
} \
STX_PURE STX_RESULT  \
stx_base_filter_vt_xxx_receive \
( \
	STX_HANDLE			h, \
	stx_base_pin*		h_pin,  \
	stx_media_data**	pp_mdat,stx_sync_inf* h_sync \
)\
{ \
	return STX_ERR_NOT_SUPPORT; \
} \
STX_PURE	STX_RESULT		 \
stx_base_filter_vt_xxx_deliver \
( \
	STX_HANDLE			h, \
	stx_base_pin*		h_pin, \
	stx_media_data*		p_mdat,stx_sync_inf* h_sync \
)\
{ \
	return STX_ERR_NOT_SUPPORT; \
}
/***********************************************************************/



#if defined( __cplusplus )
}
#endif



#endif /* __BASE_CLASS_H__ */ 
