/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-06
***********************************************************************************/


#ifndef __STX_GET_BITS_H__
#define __STX_GET_BITS_H__




#ifdef __WIN32_LIB
#	define getbits_inline __inline
#endif

#ifdef __LINUX_LIB
#	define getbits_inline inline
#endif


#define LEASTBITS  32

#define stx_show_bits32(win)	( (win)->nBits1 )

#define stx_get_bits1(win)		stx_get_bits(win,1)
#define stx_flush_bits1(win)	stx_flush_bits(win,1)


typedef struct stx_bits_window  stx_bits_window;


struct stx_bits_window
{
	u32         nBits0;
	u32         nBits1;
	s32         nCurrentBit;
	s32         nRemainedBytes;

	u8          Bytes3[4];
	s32         nTotalBytes;
	s32         size_in_bits;
	s32         nBufferSize;

#ifdef STX64
	u8*         lpCurrentByte;
	u8*         lpBitsPool;
	u8*			lpBitsEnd;
	u64         pad;   // 16 bytes aligned;
#else
	u8*         lpCurrentByte;
	u8*         lpBitsPool;
	u8*			lpBitsEnd;
	u32         pad;   // 16 bytes aligned;
#endif
};


#define stx_show_bits(win,n)	( (win)->nBits1 >> ( 32 - n ) )


#ifdef __LINUX_LIB
getbits_inline u32 
stx_show_bits(stx_bits_window* lpCurBitsWin,s32 n);
#endif




//getbits_inline void 
//stx_clear_bytes(stx_bits_window* lpCurBitsWin);

getbits_inline void 
stx_flush_bits(stx_bits_window* lpCurBitsWin,s32 n);

getbits_inline u32 
stx_get_bits(stx_bits_window* lpCurBitsWin,s32 n);

getbits_inline s32 
stx_get_xbits(stx_bits_window* lpCurBitsWin,s32 n);

getbits_inline s32 
stx_get_sbits(stx_bits_window* lpCurBitsWin,s32 n);

getbits_inline s32 
stx_get_bits_count(stx_bits_window *the);

getbits_inline STX_RESULT 
stx_init_get_bits(stx_bits_window *the,u8 *buffer, s32 bit_size);

getbits_inline STX_RESULT 
stx_dup_get_bits(stx_bits_window *the,stx_bits_window* src);

getbits_inline void 
stx_free_get_bits(stx_bits_window *the );

getbits_inline void 
stx_align_get_bits( stx_bits_window *the);

getbits_inline STX_RESULT 
stx_set_bits_buffer(stx_bits_window *the,s32 i_size);

getbits_inline STX_RESULT 
stx_init_get_bits_inplace(stx_bits_window *the,s32 bit_size);


#if defined( __cplusplus )
extern "C" {
#endif

#if defined( __cplusplus )
}
#endif

#endif // __STX_GET_BITS_H__
