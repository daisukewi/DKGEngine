/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#ifndef __STX_ALL_CODEC_H__
#define __STX_ALL_CODEC_H__



#define STX_MAX_VIDEO_DEPTH				20
#define STX_MAX_AUDIO_DEPTH				128


/*< signal that no header is present(streams are added dynamically) */
#define AVFMTCTX_NOHEADER       0x0001 

#define AVFMT_NOFILE            0x0001
#define AVFMT_NEEDNUMBER        0x0002 /**< needs '%d' in filename */
#define AVFMT_SHOW_IDS          0x0008 /**< show format stream IDs numbers */
#define AVFMT_RAWPICTURE        0x0020 /**< format wants AVPicture structure for raw picture data */
#define AVFMT_GLOBALHEADER      0x0040 /**< format wants global header */
#define AVFMT_NOTIMESTAMPS      0x0080 /**< format does not need / have any timestamps */
#define AVFMT_GENERIC_INDEX     0x0100 /**< use generic index building code */

#define AVSEEK_FLAG_BACKWARD    1 /* seek backward*/

#define AVSEEK_FLAG_BYTE        2 /* seeking based on position in bytes*/
#define AVSEEK_FLAG_ANY         4 /* seek to any frame, even non keyframes*/

#define AVINDEX_KEYFRAME		0x0001
#define AVSEEK_FLAG_SKIP		0x0008 /* used when sort by time code */


#include "stx_async_plugin.h"

#include "stx_gid_def.h"




#if defined( __cplusplus )
extern "C" {
#endif

	/* {E2413885-4044-49b2-B133-A7787293D4FD}*/
	DECLARE_XGUID( MEDIASUBTYPE_SDP_DATA,
	0xe2413885, 0x4044, 0x49b2, 0xb1, 0x33, 0xa7, 0x78, 0x72, 0x93, 0xd4, 0xfd)


	STX_RESULT encode_vd2( STX_VIDEOINFOHEADER2* hdr, s32  i_len, stx_xio* h_stream );

	STX_RESULT decode_vd2( STX_VIDEOINFOHEADER2* hdr, s32* i_len, stx_xio* h_stream );

	STX_RESULT encode_wex( 
		STX_WAVEFORMATEXTENSIBLE* hdr, s32  i_len, stx_xio* h_stream );

	STX_RESULT decode_wex( 
		STX_WAVEFORMATEXTENSIBLE* hdr, s32* i_len, stx_xio* h_stream );


    STX_RESULT load_videoinfoheader2( 
        STX_VIDEOINFOHEADER2* hdr, u8* buf, size_t i_len );

    STX_RESULT save_videoinfoheader2( 
        STX_VIDEOINFOHEADER2* hdr, u8* buf, size_t* i_len );

    STX_RESULT load_wavefomatex( 
        STX_WAVEFORMATEXTENSIBLE* hdr, u8* buf, size_t i_len );

    STX_RESULT save_wavefomatex( 
        STX_WAVEFORMATEXTENSIBLE* hdr, u8* buf, size_t* i_len );

    STX_RESULT aac_config_to_mtype( 
        u8* mtype_hdr, size_t* i_buf_len, u8* buf, size_t i_len );

    STX_RESULT h264_config_to_mtype( 
        u8* mtype_hdr, size_t* i_buf_len, u8* buf, size_t i_len );


	STX_INTERF(mp4AudioSpecificConfig);

	struct mp4AudioSpecificConfig{
		/* Audio Specific Info */
		s8	objectTypeIndex;
		s8	samplingFrequencyIndex;
		s32 samplingFrequency;
		s8	channelsConfiguration;

		/* GA Specific Info */
		s8	frameLengthFlag;
		s8	dependsOnCoreCoder;
		u16 coreCoderDelay;
		s8	extensionFlag;
		s8	aacSectionDataResilienceFlag;
		s8	aacScalefactorDataResilienceFlag;
		s8	aacSpectralDataResilienceFlag;
		s8	epConfig;

		s8	sbr_present_flag;
		s8	forceUpSampling;
	};

	STX_INTERF(faacDecConfiguration);

	struct faacDecConfiguration{
		mp4AudioSpecificConfig	config;
		s8						defObjectType;
		s32						defSampleRate;
		s8						outputFormat;
		s8						downMatrix;
		s8						useOldADTSFormat;
		s8						dontUpSampleImplicitSBR;
	};

	STX_RESULT decode_aac_config_data
		(faacDecConfiguration* hdec,s32 i_len,u8* data);

    STX_RESULT aac_config_to_wavefomatex
		(STX_WAVEFORMATEXTENSIBLE* hdr, size_t* i_size, u8* buf, size_t i_len );

    STX_RESULT h264_config_to_videoinfoheader2
		(STX_VIDEOINFOHEADER2* hdr, size_t* i_size, u8* buf, size_t i_len );


	s32 subfmt_to_rtp_payload_type(stx_gid subfmt);


	/* {CDF574F6-CDD6-406d-8BA0-B4E4C1579121} */
	DECLARE_XGUID( STX_CLSID_AACEncoder,
	0xcdf574f6, 0xcdd6, 0x406d, 0x8b, 0xa0, 0xb4, 0xe4, 0xc1, 0x57, 0x91, 0x21 );
	extern char* g_szStreamX_AACEncoder;
	STX_API	stx_base_filter* create_AAC_encoder();


	/* {CA5CE1FD-784F-455b-9A7A-F9B423B90DA9} */
	DECLARE_XGUID( STX_CLSID_FlvFileSource,
		0xca5ce1fd, 0x784f, 0x455b, 0x9a, 0x7a, 0xf9, 0xb4, 0x23, 0xb9, 0xd, 0xa9 );
	extern char* g_szStreamX_FlvFileSource;
	STX_API	STX_COM(flv_source);

	// {3B9F033E-94FF-449e-85C9-652EA75639DA}
	DECLARE_XGUID( STX_CLSID_FlvFileWriter,
		0x3b9f033e, 0x94ff, 0x449e, 0x85, 0xc9, 0x65, 0x2e, 0xa7, 0x56, 0x39, 0xda);
	extern char* g_szStreamX_FlvFileWriter;
	STX_API	STX_COM(flv_writer);


	/* {E1E8106F-567B-4a7f-93CF-AA7CBD09B007} */
	DECLARE_XGUID( STX_CLSID_Mp4FileSource,
		0xe1e8106f, 0x567b, 0x4a7f, 0x93, 0xcf, 0xaa, 0x7c, 0xbd, 0x9, 0xb0, 0x7 );
	extern char* g_szStreamX_Mp4FileSource;
	STX_API		STX_COM(mp4_source);


	/* {E1E8106F-567B-4a7f-93CF-AA7CBD09B007} */
	DECLARE_XGUID( STX_CLSID_Mp4FileWriter,
		0xe1e8106f, 0x567b, 0x4a7f, 0x93, 0xcf, 0xaa, 0x7c, 0xbd, 0x9, 0xb0, 0x7 );
	extern char* g_szStreamX_Mp4FileWriter;
	STX_API	STX_COM(mp4_file_writer);


	/* {3E292061-EB14-4b30-9114-A33A00B50B02}*/
	DECLARE_XGUID( STX_CLSID_Mpeg4Decoder,
		0x3e292061, 0xeb14, 0x4b30, 0x91, 0x14, 0xa3, 0x3a, 0x0, 0xb5, 0xb, 0x2 );
	extern char* g_szStreamX_Mpeg4Decoder;
	STX_API	STX_COM(mpeg4_decoder);


	// {CF7E80FF-982C-4126-8200-59078947F3BF}
	DECLARE_XGUID( STX_CLSID_CubicResample,
	0xcf7e80ff, 0x982c, 0x4126, 0x82, 0x0, 0x59, 0x7, 0x89, 0x47, 0xf3, 0xbf );
	extern char* g_szStreamX_CubicResample;
	STX_API	STX_COM(CubicResample);


	// {3E6775AD-881B-48b3-BDA9-6956081E241F}
	DECLARE_XGUID( STX_CLSID_VideoRender,
	0x3e6775ad, 0x881b, 0x48b3, 0xbd, 0xa9, 0x69, 0x56, 0x8, 0x1e, 0x24, 0x1f );
	extern char* g_szStreamX_VideoRender;
	STX_API	STX_COM(VideoRender);


	// {042E1975-9B62-409a-B87F-FD2B6513A81C}
	DECLARE_XGUID( STX_CLSID_ActiveMovieWindow,
	0x42e1975, 0x9b62, 0x409a, 0xb8, 0x7f, 0xfd, 0x2b, 0x65, 0x13, 0xa8, 0x1c );
	extern char* g_szStreamX_ActiveMovieWindow;
	STX_API	STX_COM(ActiveMovieWindow);


	/* {8C13BEE7-EF0F-456a-8263-229D6497C193} */
	DECLARE_XGUID( STX_CLSID_x264Encoder,
	0x8c13bee7, 0xef0f, 0x456a, 0x82, 0x63, 0x22, 0x9d, 0x64, 0x97, 0xc1, 0x93 );
	extern char* g_szStreamX_x264Encoder;
	STX_API	STX_COM(x264Encoder);


	// {F69C0EF9-8903-46de-98C3-F6DD9B7FA0F4}
	DECLARE_XGUID( STX_CLSID_TsSource,
	0xf69c0ef9, 0x8903, 0x46de, 0x98, 0xc3, 0xf6, 0xdd, 0x9b, 0x7f, 0xa0, 0xf4);
	extern char* g_szStreamX_TsSource;
	STX_API	STX_COM(ts_source);

	// {464D987A-2D23-4b48-8C88-DED1FE35AE92}
	DECLARE_XGUID( STX_CLSID_Mp3Encoder,
	0x464d987a, 0x2d23, 0x4b48, 0x8c, 0x88, 0xde, 0xd1, 0xfe, 0x35, 0xae, 0x92);
	extern char* g_szStreamX_Mp3Encoder;
	STX_API	STX_COM(mp3_encoder);

	// {27C3CBAB-5DC4-4101-83A4-F45A851B40A2}
	DECLARE_XGUID( STX_CLSID_Mp3Decoder,
	0x27c3cbab, 0x5dc4, 0x4101, 0x83, 0xa4, 0xf4, 0x5a, 0x85, 0x1b, 0x40, 0xa2);
	extern char* g_szStreamX_Mp3Decoder;
	STX_API	STX_COM(mp3_decoder);


	// {83E28F38-46DD-49b1-8B0F-BE513B45D473}
	DECLARE_XGUID( STX_CLSID_Mpeg2Decoder,
	0x83e28f38, 0x46dd, 0x49b1, 0x8b, 0xf, 0xbe, 0x51, 0x3b, 0x45, 0xd4, 0x73);
	extern char* g_szStreamX_Mpeg2Decoder;
	STX_API	STX_COM(mpeg2_decoder);


	// {3F27B4AE-8E59-4fed-8F60-5B816E957B91}
	DECLARE_XGUID( STX_CLSID_AvbDecoder,
	0x3f27b4ae, 0x8e59, 0x4fed, 0x8f, 0x60, 0x5b, 0x81, 0x6e, 0x95, 0x7b, 0x91);
	extern char* g_szStreamX_AvbDecoder;
	STX_API	STX_COM(avb_decoder);

	// {2E8A34F7-B5FE-4543-88FA-10515F2C8F7C}
	DECLARE_XGUID( STX_CLSID_DsoundRender,
	0x2e8a34f7, 0xb5fe, 0x4543, 0x88, 0xfa, 0x10, 0x51, 0x5f, 0x2c, 0x8f, 0x7c );
	extern char* g_szStreamX_DsoundRender;
	STX_API	STX_COM(stx_dsound_render);

	// {75859194-9BB0-4ea8-B2D3-2940B6A6AE33}
	DECLARE_XGUID( STX_CLSID_Valve,
	0x75859194, 0x9bb0, 0x4ea8, 0xb2, 0xd3, 0x29, 0x40, 0xb6, 0xa6, 0xae, 0x33 );
	extern char* g_szStreamX_valve;
	STX_API	STX_COM(stx_valve);


	// {2903CBD0-F91F-4962-B074-F3B1255C9A6D}
	DECLARE_XGUID( STX_CLSID_tcp_source,
	0x2903cbd0, 0xf91f, 0x4962, 0xb0, 0x74, 0xf3, 0xb1, 0x25, 0x5c, 0x9a, 0x6d  );
	extern char* g_szStreamX_tcp_source;
	STX_API	STX_COM(stx_tcp_source);


	// {7B9706F0-D4C1-4f72-800F-D8457D534D4B}
	DECLARE_XGUID( STX_CLSID_tcp_render,
	0x7b9706f0, 0xd4c1, 0x4f72, 0x80, 0xf, 0xd8, 0x45, 0x7d, 0x53, 0x4d, 0x4b );
	extern char* g_szStreamX_tcp_render;
	STX_API	STX_COM(stx_tcp_render);

	// {ADFE85A3-4667-49f8-B518-011D98E0EFE7}
	DECLARE_XGUID( STX_CLSID_h264decoder,
	0xadfe85a3, 0x4667, 0x49f8, 0xb5, 0x18, 0x1, 0x1d, 0x98, 0xe0, 0xef, 0xe7);
	extern char* g_szStreamX_h264decoder;
	STX_API	STX_COM(h264_decoder);



#if defined( __cplusplus )
}
#endif


#endif /* __STX_ALL_CODEC_H__ */ 
