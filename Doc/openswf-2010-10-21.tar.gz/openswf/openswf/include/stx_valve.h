/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-10
***********************************************************************************/

#include "stx_all.h"

#ifndef __STX_VALVE_H__
#define __STX_VALVE_H__

#if defined( __cplusplus )
extern "C" {
#endif

	// {9F2429A6-5F9D-40e4-AD0F-56A6E23BA64C}
	DECLARE_XGUID(STX_IID_ValveCallback,
	0x9f2429a6, 0x5f9d, 0x40e4, 0xad, 0xf, 0x56, 0xa6, 0xe2, 0x3b, 0xa6, 0x4c);


	STX_INTERF(valve_callback);

#define valve_callback_vtdef() \
	stx_base_com_vtdef()\
	_STX_PURE STX_RESULT (*release_media_data)( THEE h, stx_media_data* p_mdat );

	struct valve_callback{
		valve_callback_vtdef()
	};

#define valve_callback_funcdecl(PREFIX) \
	stx_base_com_funcdecl(PREFIX ## _ ## com);\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## release_media_data( THEE h, stx_media_data* p_mdat )

#define valve_callback_vtinit(vt,PREFIX) \
	STX_VT_INIT(vt,PREFIX,release_media_data)

#define valve_callback_data_default()			\
	stx_base_com_data_default()

#define valve_callback_funcimp_default(SCOM,PREFIX)			\
	stx_base_com_funcimp_default(SCOM,PREFIX ## _ ## com )\

#define valve_callback_create_default(vt,PREFIX,CLS,CAT,NAME)		\
	stx_base_com_create_default(vt,PREFIX ## _ ## com,CLS,CAT,NAME); \
	valve_callback_vtinit(vt,PREFIX)

#define valve_callback_release_default(SCOM)			\
	stx_base_com_release_default(SCOM)\

#define valve_callback_release_begin(SCOM)			\
	stx_base_plugin_release_begin(SCOM)\

#define valve_callback_release_end(SCOM)			\
	stx_base_com_release_end(SCOM)\

#define valve_callback_query_default(SCOM,vt)			\
	if( IS_EQUAL_GID(gid,STX_IID_ValveCallback) ) {\
		the->i_ref ++;\
		*pp_interf = (void*)&vt;\
		return STX_OK;\
	}\
	stx_base_com_query_default(SCOM,vt)\


	STX_API	STX_COM(valve_outpin,valve_callback* h_valve);

	STX_API CREATE_STX_COM_DECL(stx_output_pin,valve_outpin,valve_callback* h_valve);



#if defined( __cplusplus )
}
#endif



#endif // __STX_VALVE_H__