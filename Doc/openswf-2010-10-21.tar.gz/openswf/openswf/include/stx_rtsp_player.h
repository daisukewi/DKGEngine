/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/


#ifndef __STX_RTSP_PLAYER_H__
#define __STX_RTSP_PLAYER_H__


#include "stx_async_plugin.h"


#include "stx_gid_def.h"


#if defined( __cplusplus )
extern "C" {
#endif



stx_base_player* create_rtsp_player();



#if defined( __cplusplus )
}
#endif


#endif /* __STX_RTSP_PLAYER_H__ */ 