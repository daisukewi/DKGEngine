

#ifndef __STX_MYSQL_H__
#define __STX_MYSQL_H__

/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#include "stx_ini.h"



#if defined( __cplusplus )
extern "C" {
#endif

	
char*		create_mysql_open_string(const char *DBName, const char *DBSn);


stx_xini*   stx_ini_create_mysql( char* sz_file_name, stx_xio* h_xio, int i_open_flags, int i_type );


#if defined( __cplusplus )
}
#endif



#endif /*   __STX_MYSQL_H__  */ 
