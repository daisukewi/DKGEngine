/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-11
***********************************************************************************/
#ifndef __STX_PROTOCOL_H__
#define __STX_PROTOCOL_H__

#include "stx_async_plugin.h"
#include "stx_prop_def.h"
#include "stx_session.h"

#if defined( __cplusplus )
extern "C" {
#endif



	// {0E6A2048-1CF3-42b7-91C1-F90867800C50}
	DECLARE_XGUID( STX_IID_BaseProtocol,
	0xe6a2048, 0x1cf3, 0x42b7, 0x91, 0xc1, 0xf9, 0x8, 0x67, 0x80, 0xc, 0x50);



	// {914759AF-3F97-41e7-93FE-364FA172FF23}
	DECLARE_XGUID( STX_IID_StxProtCallback,
	0x914759af, 0x3f97, 0x41e7, 0x93, 0xfe, 0x36, 0x4f, 0xa1, 0x72, 0xff, 0x23);

	//
	STX_INTERF(stx_prot_callback);


#define stx_prot_callback_vtdef() \
	stx_base_com_vtdef()\
	_STX_PURE char*			(*get_prot_name)(THEE h);\
	_STX_PURE STX_RESULT	(*enum_method)(THEE h, s32* i_idx, char** method_name);\
	_STX_PURE STX_RESULT	(*filter)\
	(THEE h,stx_base_plugin* ses,stx_xini* h_xini,stx_xio* h_response);\
	_STX_PURE void	(*notify_ses_close)(THEE h,stx_base_plugin* ses);\

	struct stx_prot_callback{
		stx_prot_callback_vtdef()
	};

#define stx_prot_callback_funcdecl(PREFIX) \
	stx_base_com_funcdecl(PREFIX ## _ ## com) \
	STX_PURE char*		PREFIX ## _xxx_ ## get_prot_name(THEE h);\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## enum_method(THEE h, s32* i_idx, char** method_name);\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## filter\
	(THEE h,stx_base_plugin* ses,stx_xini* h_xini,stx_xio* h_response);\
	STX_PURE void		PREFIX ## _xxx_ ## notify_ses_close(THEE h,stx_base_plugin* ses)


#define stx_prot_callback_vtinit(vt,PREFIX) \
	STX_VT_INIT(vt,PREFIX,get_prot_name);\
	STX_VT_INIT(vt,PREFIX,enum_method);\
	STX_VT_INIT(vt,PREFIX,filter);\
	STX_VT_INIT(vt,PREFIX,notify_ses_close)

#define stx_prot_callback_data_default()			\
	stx_base_com_data_default()

#define stx_prot_callback_funcimp_default(SCOM,PREFIX)	\
	stx_base_com_funcimp_default(SCOM,PREFIX ## _ ## com )\

#define stx_prot_callback_create_default(vt,PREFIX,CLS,CAT,NAME)	\
	stx_base_com_create_default(vt,PREFIX ## _ ## com,CLS,CAT,NAME); \
	stx_prot_callback_vtinit(vt,PREFIX)


#define stx_prot_callback_release_default(SCOM)		\
	stx_base_com_release_default(SCOM)\

#define stx_prot_callback_release_begin(SCOM) \
	stx_base_com_release_begin(SCOM)\

#define stx_prot_callback_release_end(SCOM) \
	stx_base_com_release_end(SCOM)\


#define stx_prot_callback_query_default(SCOM,vt)		\
	if( IS_EQUAL_GID(gid,STX_IID_StxProtCallback) ) {\
		the->i_ref ++;\
		*pp_interf = (void*)&vt;\
		return STX_OK;\
	}\
	stx_base_com_query_default(SCOM,vt )\



	// {08EE4BD1-6EEE-49b6-8335-C45A3930D5F3}
	DECLARE_XGUID( STX_CLSID_StxProtocol,
	0x8ee4bd1, 0x6eee, 0x49b6, 0x83, 0x35, 0xc4, 0x5a, 0x39, 0x30, 0xd5, 0xf3);
	extern char* g_sz_StreamX_StxProtocol;

	STX_COM(stx_protocol);
	STX_API CREATE_STX_COM_DECL(stx_base_filter,stx_protocol);

	STX_API s32		get_stx_server_ipport();
	STX_API char*	enum_stx_server_ipport(u16* port,s32 i_idx);


#if defined( __cplusplus )
}
#endif


#endif // __STX_PROTOCOL_H__