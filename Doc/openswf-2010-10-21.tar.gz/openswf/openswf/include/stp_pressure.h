/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#ifndef __STP_PRESURE_H__
#define __STP_PRESURE_H__


#include "base_class.h"


#if defined( __cplusplus )
extern "C" {
#endif


	enum stp_pressure_status{
		em_stp_open,
		em_stp_open_play,
		em_stp_read,
		em_stp_stop,
		em_stp_close,
	};


	//{{ pressure file API;

	STX_RESULT	set_prs_server(stx_xini* h_xini,char* sz_ip,u16 i_port);
	STX_RESULT	set_prs_graph(stx_xini* h_xini,char* sz_graph);
	STX_RESULT	set_prs_connection(stx_xini* h_xini,s32 i_connum);
	STX_RESULT	add_prs_url(stx_xini* h_xini,char* sz_url);

	STX_RESULT  get_prs_server(stx_xini* h_xini,char** sz_ip,u16* i_port);

	// the returned url string must not be freed;
	char*		get_prs_graph(stx_xini* h_xini);

	s32			get_prs_connection(stx_xini* h_xini);

	s32			get_prs_url_num(stx_xini* h_xini);

	// the returned url string must be freed by stx_free;
	char*		get_prs_url(stx_xini* h_xini, s32 i_index);

	// pressure file API }}



	//{{ pressure interface 

	// pressure interface }}




	// {40D91D98-280F-4559-8056-9C1CAC3FC42E}
	DECLARE_XGUID( STX_CLSID_StpPressure,
	0x40d91d98, 0x280f, 0x4559, 0x80, 0x56, 0x9c, 0x1c, 0xac, 0x3f, 0xc4, 0x2e);

	extern char* g_szStreamX_StpPressure;

	STX_API	STX_COM(stp_pressure);

	STX_API CREATE_STX_COM_DECL(stx_stream_writer,stp_pressure);



#if defined( __cplusplus )
}
#endif


#endif /*   __STP_PRESURE_H__  */ 
