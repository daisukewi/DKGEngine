#ifndef __MOV_IO_FILE_H__2008_06_21
#define __MOV_IO_FILE_H__2008_06_21

/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/


#include "stx_base_type.h"

#include "stx_io.h"

#if defined( __cplusplus )
extern "C" {
#endif

STX_RESULT stx_fcopy(const char* src, const char* dst, b32 b_fail_exist);

stx_xio*  stx_create_io_file();



#if defined( __cplusplus )
}
#endif


#endif /*   __MOV_IO_FILE_H__2008_06_21  */ 
