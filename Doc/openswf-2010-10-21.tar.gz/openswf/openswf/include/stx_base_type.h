/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#ifndef __BASE_TYPE_H__2008_06_21
#define __BASE_TYPE_H__2008_06_21



#include "stx_config.h"


#if defined( __cplusplus )
extern "C" {
#endif



/* 
	stx_base_type.h 
	create: 2008-06-21
	author: baojinlong

	��������	LP64	ILP64	LLP64	ILP32	LP32
	char		8		8		8		8		8
	short		16		16		16		16		16 
	int			32		64		32		32		16
	long		64		64		32		32		32
	long long	64		64		64		64		64
	pointer		64		64		64		32		32

	VC and GCC on windows , is  LLP64;
	GCC on linux , is  LP64;
*/ 

typedef 	unsigned char       	uint8;
typedef 	signed char         	sint8;
typedef 	unsigned short      	uint16;
typedef 	signed short        	sint16;
typedef 	unsigned int       		uint32;
typedef 	int         			sint32;

#ifdef __WIN32_LIB
#define _WSPIAPI_COUNTOF(_Array) (sizeof(_Array) / sizeof(_Array[0]))
#define _WINSOCKAPI_   /* Prevent inclusion of winsock.h in windows.h */
#	include <windows.h>
#	include <winsock2.h>
#	include <mswsock.h>
#	include <process.h>
#	include <ws2tcpip.h>
#	include <io.h>
#	include <direct.h>
#	include <errno.h>
#	include <assert.h>

	typedef 	LONGLONG    			sint64;
	typedef 	ULONGLONG  				uint64;

#   define R_OK 0
#   define W_OK 1

	// POSIX errorcodes
#   define ENOTCONN		1002
#   define EADDRINUSE		1004
#   define EINPROGRESS		1007
#   define ENOBUFS			1008
#   define EADDRNOTAVAIL	1009

	// Winsock does not use iovecs
	struct iovec {
		u_long  iov_len; // this is not the POSIX definition, it is rather defined to be
		char FAR*   iov_base; // equivalent to a WSABUF for easy integration into Win32
	};

#else
	typedef 	signed long long    	sint64;
	typedef 	unsigned long long  	uint64;
#endif

typedef 	float               	float32;
typedef 	double              	float64;
typedef 	uint32              	bool32;
typedef 	uint16              	bool16;
typedef 	uint8               	bool8;


/*{{ added : 2009-05-11; */
typedef 	uint8       			u8;
typedef 	sint8         			s8;
typedef 	uint16      			u16;
typedef 	sint16        			s16;
typedef 	uint32		       		u32;
typedef 	sint32		         	s32;
typedef 	sint64    				s64;
typedef 	uint64  				u64;
typedef 	float               	f32;
typedef 	double              	f64;
typedef 	u32              		b32;
typedef 	u16              		b16;
typedef 	u8               		b8;
/*}} */

//{{ added : 2010-07-13; */
typedef 	s16        				f16; //}}


typedef		u64						QWORD;

#if defined (__WIN32_LIB )

#ifndef HAVE_LINUX_TYPE
	typedef     	char              	int8_t;
    typedef	    	__int16			    int16_t;
    typedef	    	__int32			    int32_t;
    typedef	    	__int64			    int64_t;

	typedef     	unsigned char		uint8_t;
	typedef	    	unsigned __int16	uint16_t;
	typedef	    	unsigned __int32	uint32_t;
	typedef	    	unsigned __int64	uint64_t;
#endif

#else

#	include <sys/types.h>
#	include <stdint.h>
#	include <stdarg.h>


    typedef  	    char 				__int8;
    typedef  	    short 				__int16;
    typedef  	    int 				__int32;
    typedef         long long			__int64;

    typedef         uint8				BYTE;
    typedef         uint16				WORD;
    typedef         uint32				DWORD;
    typedef  	    uint32 				BOOL;
#endif


typedef     	uint8_t		u_int8_t;
typedef	    	uint16_t	u_int16_t;
typedef	    	uint32_t	u_int32_t;
typedef	    	uint64_t	u_int64_t;


/* we always use 64 bit file offset; */
typedef		sint64			    offset_t;

typedef		sint32			    STX_LONG;
typedef		sint64			    STX_LONGLONG;
typedef		uint64		        STX_ULONGLONG;
typedef		sint64		        STX_REFERENCE_TIME;
typedef		uint32		        STX_DWORD;
typedef		uint32		        STX_BOOL;
typedef		unsigned char		STX_BYTE;
typedef		unsigned short		STX_WORD;


#ifndef FALSE
	#define FALSE 0
#endif

#ifndef TRUE
	#define TRUE 1
#endif


#ifdef __LINUX_LIB
#	define WAIT_FAILED			(u32)0xFFFFFFFF
#	define WAIT_OBJECT_0		0
#	define WAIT_TIMEOUT			0x00000102
#endif


typedef  s16  DCTELEM;
typedef  s32  DWTELEM;
typedef  s16  IDWTELEM;

#define SEEK_SIZE   8


typedef struct XGUID XGUID;

struct XGUID {          /* size is 16*/
    uint32   Data1;
    uint16   Data2;
    uint16   Data3;
    uint8    Data4[8];
};

typedef union stx_gid stx_gid;

union stx_gid{
	XGUID       guid;
	uint8       data[16];
};

#define IS_EQUAL_GID(A,B)  ( !memcmp((void*)&A,(void*)&B,sizeof(stx_gid) ) ) 


#define MKGID(A) ( *(stx_gid*) &A )


#if defined(__WIN32_LIB)
	#include "basetsd.h"
	#include "io.h"
	typedef SSIZE_T ssize_t;
#endif

typedef     ssize_t             STX_RESULT;

typedef     STX_RESULT          STX_MP4_RESULT;

#define	    STX_OK						0
#define     STX_FAIL					-1

#define     STX_ERR_FATAL				-2
#define     STX_ERR_EXCEP				-3
#define     STX_ERR_IO					-4
#define     STX_ERR_SOCK_LOCAL			-5
#define     STX_ERR_SOCK_REMOTE     	-6
#define     STX_ERR_INVALID_PARAM   	-7
#define     STX_ERR_ACCESS_DENY			-8
#define     STX_ERR_INVALID_RESULT  	-9
#define     STX_ERR_EOF					-10
#define     STX_ERR_BOF					-11
#define     STX_ERR_NOT_IMP				-12
#define     STX_ERR_FILE_NOT_FOUND		-13
#define     STX_ERR_THREAD_RUNING		-14
#define     STX_ERR_CFG					-15
#define     STX_ERR_NOT_SUPPORT			-16
#define     STX_ERR_OBJ_UNINIT			-17
#define     STX_ERR_OBJ_STATUS			-18
#define     STX_ERR_TOOMANY_MODULES 	-19
//#define     STX_ERR_IDLE		    	-20
//#define     STX_ERR_AGAIN		    	-21
#define     STX_ERR_INVALID_MSG	    	-22

#define     STX_ERR_NO_PIN	    		-23
#define     STX_ERR_PIN_NOT_CONNECTED   -24
#define     STX_ERR_NOT_READY			-25

//#define     STX_ERR_WOUNLD_BLOCK	    -26


#define     STX_EOF				        1
#define     STX_BOF				        2
#define     STX_WOUNLD_BLOCK	        3
#define		STX_ECHO					4

//#define	STX_SUSPEND 				5
//#define   STX_MSG_UNKNOWN				6
//#define   STX_DELIVER				    7
//#define	STX_REPEAT					8   // data blocked, and deliver;

#define     STX_MSG_NULL			    9
#define     STX_INCOMPATIBLE			10
#define     STX_NEVER_REACH        		11
#define     STX_REDIRECT			    12
#define     STX_IDLE		    		13
#define     STX_AGAIN		    		14
//#define     STX_CLOSE					15
#define     STX_STOP					16
#define     STX_RESTART					17


#define     STX_NULL    	0

#define	    STX_MP4_OK      	STX_OK  
#define     STX_MP4_FAIL    	STX_FAIL
#define     STX_MP4_EOF     	STX_EOF 
#define     STX_MP4_BOF     	STX_BOF 
#define     STX_MP4_NULL    	STX_NULL


#ifndef INFINITE
#	define INFINITE        ((size_t)-1)  /* Infinite timeout*/
#endif

#define INFINITE64        ((u64)-1)  /* Infinite timeout*/


typedef void*			STX_HANDLE;
typedef STX_HANDLE		THEE;
typedef	STX_HANDLE		STX_MP4_HANDLE;

#define	MAX_STREAMS	20

#ifdef __LINUX_LIB
typedef struct STX_POINT{
	s32 x;
	s32 y;
}STX_POINT;
typedef struct  STX_RECT {
	sint32 left;
	sint32 top;
	sint32 right;
	sint32 bottom;
}STX_RECT;

typedef STX_POINT	POINT;
typedef STX_RECT	RECT;
typedef STX_HANDLE	HWND;
#else
typedef POINT STX_POINT;
typedef RECT STX_RECT;
#endif

typedef struct STX_BITMAPINFOHEADER{
    uint32      biSize;
    sint32      biWidth;
    sint32      biHeight;
    uint16      biPlanes;
    uint16      biBitCount;
    uint32      biCompression;
    uint32      biSizeImage;
    sint32      biXPelsPerMeter;
    sint32      biYPelsPerMeter;
    uint32      biClrUsed;
    uint32      biClrImportant;
} STX_BITMAPINFOHEADER;

#define VIDEOINFOHEADER2_size() 112

typedef struct STX_VIDEOINFOHEADER2 {
    STX_RECT             rcSource;
    STX_RECT             rcTarget;
    uint32               dwBitRate;
    uint32               dwBitErrorRate;
    STX_REFERENCE_TIME   AvgTimePerFrame;

	/* use AMINTERLACE_* defines. Reject connection if undefined bits are not 0*/
    uint32               dwInterlaceFlags;  

	/* use AMCOPYPROTECT_* defines. Reject connection if undefined bits are not 0*/
    uint32               dwCopyProtectFlags; 

	/* X dimension of picture aspect ratio, e.g. 16 for 16x9 display*/
    uint32               dwPictAspectRatioX; 

	/* Y dimension of picture aspect ratio, e.g.  9 for 16x9 display*/
    uint32               dwPictAspectRatioY; 

    union {
		/* use AMCONTROL_* defines, use this from now on*/
       uint32 dwControlFlags;               
 		/* for backward compatibility (was "must be 0";  connection rejected otherwise)*/
       uint32 dwReserved1;                  
    };

	/* must be 0; reject connection otherwise*/
    uint32               dwReserved2; 

    STX_BITMAPINFOHEADER bmiHeader;

} STX_VIDEOINFOHEADER2;

#define SEC2REFTIME(A)		((u64)(A)*10000*1000)
#define REFTIME2SEC(A)		((u64)(A)/(10000*1000))
#define MILISEC2REFTIME(A)	((u64)(A)*10000)
#define REFTIME2MILISEC(A)	((u64)(A)/10000)
#define USEC2REFTIME(A)		((u64)(A)*10)
#define REFTIME2USEC(A)		((u64)(A)/10)
#define PTS2MILISEC(A)      ((u64)(A)/90)
#define MILISEC2PTS(A)      ((u64)(A)*90)
#define PTS2REFTIME(A)      ((u64)(A)*10000/90)
#define REFTIME2PTS(A)      ((u64)(A)*90/10000)

#define WAVE_FORMAT_DOLBY_AC3        0x2000
#define WAVE_FORMAT_DVD_DTS          0x2001
#define WAVE_FORMAT_AAC              0x00FF
#define WAVE_FORMAT_EXAC             0x00FE
#define WAVE_FORMAT_WMA1             0x0160 /* WMA version 1 */
#define WAVE_FORMAT_WMA2             0x0161 /* WMA (v2) 7, 8, 9 Series */
#define WAVE_FORMAT_WMAP             0x0162 /* WMA 9 Professional */
#define WAVE_FORMAT_WMAL             0x0163 /* WMA 9 Lossless */

#define WAVE_FORMAT_MPEGLAYER1		0x0052  /*  added by baojinlong,2009-11-16*/
#define WAVE_FORMAT_MPEGLAYER2		0x0054  /*  added by baojinlong,2009-11-16 */


#if defined (__LINUX_LIB )


	/* WAVE form wFormatTag IDs */
	#define  WAVE_FORMAT_UNKNOWN      0x0000  /*  Microsoft Corporation  */
	#define  WAVE_FORMAT_ADPCM        0x0002  /*  Microsoft Corporation  */
	#define  WAVE_FORMAT_PCM       	0x0001  /*  Microsoft Corporation  */
	#define  WAVE_FORMAT_IEEE_FLOAT    0x0003  /*  Microsoft Corporation  */
	/*  IEEE754: range (+1, -1]  */
	/*  32-bit/64-bit format as defined by */
	/*  MSVC++ float/double type */
	#define  WAVE_FORMAT_IBM_CVSD   0x0005  /*  IBM Corporation  */
	#define  WAVE_FORMAT_ALAW       0x0006  /*  Microsoft Corporation  */
	#define  WAVE_FORMAT_MULAW      0x0007  /*  Microsoft Corporation  */
	#define  WAVE_FORMAT_OKI_ADPCM  0x0010  /*  OKI  */
	#define  WAVE_FORMAT_DVI_ADPCM  0x0011  /*  Intel Corporation  */
	#define  WAVE_FORMAT_IMA_ADPCM  (WAVE_FORMAT_DVI_ADPCM) /*  Intel Corporation  */
	#define  WAVE_FORMAT_MEDIASPACE_ADPCM   0x0012  /*  Videologic  */
	#define  WAVE_FORMAT_SIERRA_ADPCM       0x0013  /*  Sierra Semiconductor Corp  */
	#define  WAVE_FORMAT_G723_ADPCM 0x0014  /*  Antex Electronics Corporation  */
	#define  WAVE_FORMAT_DIGISTD    0x0015  /*  DSP Solutions, Inc.  */
	#define  WAVE_FORMAT_DIGIFIX    0x0016  /*  DSP Solutions, Inc.  */
	#define  WAVE_FORMAT_DIALOGIC_OKI_ADPCM 0x0017  /*  Dialogic Corporation  */
	#define  WAVE_FORMAT_MEDIAVISION_ADPCM  0x0018  /*  Media Vision, Inc. */
	#define  WAVE_FORMAT_YAMAHA_ADPCM       0x0020  /*  Yamaha Corporation of America  */
	#define  WAVE_FORMAT_SONARC     0x0021  /*  Speech Compression  */
	#define  WAVE_FORMAT_DSPGROUP_TRUESPEECH        0x0022  /*  DSP Group, Inc  */
	#define  WAVE_FORMAT_ECHOSC1    0x0023  /*  Echo Speech Corporation  */
	#define  WAVE_FORMAT_AUDIOFILE_AF36     0x0024  /*    */
	#define  WAVE_FORMAT_APTX       0x0025  /*  Audio Processing Technology  */
	#define  WAVE_FORMAT_AUDIOFILE_AF10     0x0026  /*    */
	#define  WAVE_FORMAT_DOLBY_AC2  0x0030  /*  Dolby Laboratories  */
	#define  WAVE_FORMAT_GSM610     0x0031  /*  Microsoft Corporation  */
	#define  WAVE_FORMAT_MSNAUDIO   0x0032  /*  Microsoft Corporation  */
	#define  WAVE_FORMAT_ANTEX_ADPCME       0x0033  /*  Antex Electronics Corporation  */
	#define  WAVE_FORMAT_CONTROL_RES_VQLPC  0x0034  /*  Control Resources Limited  */
	#define  WAVE_FORMAT_DIGIREAL   0x0035  /*  DSP Solutions, Inc.  */
	#define  WAVE_FORMAT_DIGIADPCM  0x0036  /*  DSP Solutions, Inc.  */
	#define  WAVE_FORMAT_CONTROL_RES_CR10   0x0037  /*  Control Resources Limited  */
	#define  WAVE_FORMAT_NMS_VBXADPCM       0x0038  /*  Natural MicroSystems  */
	#define  WAVE_FORMAT_CS_IMAADPCM 0x0039 /* Crystal Semiconductor IMA ADPCM */
	#define  WAVE_FORMAT_ECHOSC3     0x003A /* Echo Speech Corporation */
	#define  WAVE_FORMAT_ROCKWELL_ADPCM     0x003B  /* Rockwell International */
	#define  WAVE_FORMAT_ROCKWELL_DIGITALK  0x003C  /* Rockwell International */
	#define  WAVE_FORMAT_XEBEC      0x003D  /* Xebec Multimedia Solutions Limited */
	#define  WAVE_FORMAT_G721_ADPCM 0x0040  /*  Antex Electronics Corporation  */
	#define  WAVE_FORMAT_G728_CELP  0x0041  /*  Antex Electronics Corporation  */

	#define  WAVE_FORMAT_MPEG       0x0050  /*  Microsoft Corporation  */
	#define  WAVE_FORMAT_MPEGLAYER3 0x0055  /*  ISO/MPEG Layer3 Format Tag */

	#define  WAVE_FORMAT_CIRRUS     0x0060  /*  Cirrus Logic  */
	#define  WAVE_FORMAT_ESPCM      0x0061  /*  ESS Technology  */
	#define  WAVE_FORMAT_VOXWARE    0x0062  /*  Voxware Inc  */
	#define  WAVEFORMAT_CANOPUS_ATRAC       0x0063  /*  Canopus, co., Ltd.  */
	#define  WAVE_FORMAT_G726_ADPCM 0x0064  /*  APICOM  */
	#define  WAVE_FORMAT_G722_ADPCM 0x0065  /*  APICOM      */
	#define  WAVE_FORMAT_DSAT       0x0066  /*  Microsoft Corporation  */
	#define  WAVE_FORMAT_DSAT_DISPLAY       0x0067  /*  Microsoft Corporation  */
	#define  WAVE_FORMAT_SOFTSOUND  0x0080  /*  Softsound, Ltd.      */
	#define  WAVE_FORMAT_RHETOREX_ADPCM     0x0100  /*  Rhetorex Inc  */
	#define  WAVE_FORMAT_CREATIVE_ADPCM     0x0200  /*  Creative Labs, Inc  */
	#define  WAVE_FORMAT_CREATIVE_FASTSPEECH8       0x0202  /*  Creative Labs, Inc  */
	#define  WAVE_FORMAT_CREATIVE_FASTSPEECH10      0x0203  /*  Creative Labs, Inc  */
	#define  WAVE_FORMAT_QUARTERDECK 0x0220 /*  Quarterdeck Corporation  */
	#define  WAVE_FORMAT_FM_TOWNS_SND       0x0300  /*  Fujitsu Corp.  */
	#define  WAVE_FORMAT_BTV_DIGITAL        0x0400  /*  Brooktree Corporation  */
	#define  WAVE_FORMAT_OLIGSM     0x1000  /*  Ing C. Olivetti & C., S.p.A.  */
	#define  WAVE_FORMAT_OLIADPCM   0x1001  /*  Ing C. Olivetti & C., S.p.A.  */
	#define  WAVE_FORMAT_OLICELP    0x1002  /*  Ing C. Olivetti & C., S.p.A.  */
	#define  WAVE_FORMAT_OLISBC     0x1003  /*  Ing C. Olivetti & C., S.p.A.  */
	#define  WAVE_FORMAT_OLIOPR     0x1004  /*  Ing C. Olivetti & C., S.p.A.  */
	#define  WAVE_FORMAT_LH_CODEC   0x1100  /*  Lernout & Hauspie  */
	#define  WAVE_FORMAT_NORRIS     0x1400  /*  Norris Communications, Inc.  */

	//
	//  the WAVE_FORMAT_DEVELOPMENT format tag can be used during the
	//  development phase of a new wave format.  Before shipping, you MUST
	//  acquire an official format tag from Microsoft.
	//
	#define WAVE_FORMAT_DEVELOPMENT         (0xFFFF)

#endif


#define WAVEFORMATEX_size()    18

typedef struct STX_WAVEFORMATEX{
    /* format type */
    uint16    wFormatTag;        
    /* number of channels (i.e. mono, stereo...) */
    uint16    nChannels;         
    /* sample rate */
    uint32    nSamplesPerSec;    
    /* for buffer estimation */
    uint32    nAvgBytesPerSec;   
    /* block size of data */
    uint16    nBlockAlign;       
    /* Number of bits per sample of mono data */
    uint16    wBitsPerSample;    
    /* The count in bytes of the size of extra information (after cbSize) */
    uint16    cbSize;          

} STX_WAVEFORMATEX;


#define WAVEFORMATEXTENS_size()    ( WAVEFORMATEX_size() + 22 )


typedef struct STX_WAVEFORMATEXTENSIBLE{
    STX_WAVEFORMATEX  Format;
    union {
        uint16  wValidBitsPerSample;
        uint16  wSamplesPerBlock;
        uint16  wReserved;
    } Samples;
    uint32      dwChannelMask; 
    stx_gid     SubFormat;
} STX_WAVEFORMATEXTENSIBLE;


#define STX_SPEAKER_FRONT_LEFT             0x1 
#define STX_SPEAKER_FRONT_RIGHT            0x2 
#define STX_SPEAKER_FRONT_CENTER           0x4 
#define STX_SPEAKER_LOW_FREQUENCY          0x8 
#define STX_SPEAKER_BACK_LEFT              0x10 
#define STX_SPEAKER_BACK_RIGHT             0x20 
#define STX_SPEAKER_FRONT_LEFT_OF_CENTER    0x40 
#define STX_SPEAKER_FRONT_RIGHT_OF_CENTER   0x80 
#define STX_SPEAKER_BACK_CENTER            0x100 
#define STX_SPEAKER_SIDE_LEFT              0x200 
#define STX_SPEAKER_SIDE_RIGHT             0x400 
#define STX_SPEAKER_TOP_CENTER             0x800 
#define STX_SPEAKER_TOP_FRONT_LEFT          0x1000 
#define STX_SPEAKER_TOP_FRONT_CENTER        0x2000 
#define STX_SPEAKER_TOP_FRONT_RIGHT         0x4000 
#define STX_SPEAKER_TOP_BACK_LEFT           0x8000 
#define STX_SPEAKER_TOP_BACK_CENTER         0x10000 
#define STX_SPEAKER_TOP_BACK_RIGHT          0x20000 



#define FF_COMPLIANCE_VERY_STRICT   2 ///< Strictly conform to a older more strict version of the spec or reference software.
#define FF_COMPLIANCE_STRICT        1 ///< Strictly conform to all the things in the spec no matter what consequences.
#define FF_COMPLIANCE_NORMAL        0
#define FF_COMPLIANCE_INOFFICIAL   -1 ///< Allow inofficial extensions.
#define FF_COMPLIANCE_EXPERIMENTAL -2 ///< Allow nonstandardized experimental things.

enum emSTX_MP4_FMT{
	emSTX_MP4_FMT_MOV,
	emSTX_MP4_FMT_MP4,
	emSTX_MP4_FMT_3GP,
	emSTX_MP4_FMT_PSP,
};

enum emSTX_MP4_STREAM_TYPE{
	emSTX_MP4_STREAM_VIDEO,
	emSTX_MP4_STREAM_AUDIO,
	emSTX_MP4_STREAM_TS,
	emSTX_MP4_STREAM_SUB,
	emSTX_MP4_STREAM_TXT,
	emSTX_MP4_STREAM_UNKNOWN,
};


/**
* Pixel format. Notes:
*
* PIX_FMT_RGB32 is handled in an endian-specific manner. A RGBA
* color is put together as:
*  (A << 24) | (R << 16) | (G << 8) | B
* This is stored as BGRA on little endian CPU architectures and ARGB on
* big endian CPUs.
*
* When the pixel format is palettized RGB (PIX_FMT_PAL8), the palettized
* image data is stored in AVFrame.data[0]. The palette is transported in
* AVFrame.data[1] and, is 1024 bytes long (256 4-byte entries) and is
* formatted the same as in PIX_FMT_RGB32 described above (i.e., it is
* also endian-specific). Note also that the individual RGB palette
* components stored in AVFrame.data[1] should be in the range 0..255.
* This is important as many custom PAL8 video codecs that were designed
* to run on the IBM VGA graphics adapter use 6-bit palette components.
*/
enum PixelFormat {
	PIX_FMT_NONE= -1,
	PIX_FMT_YUV420P,           /* Planar YUV 4:2:0, 12bpp, (1 Cr & Cb sample per 2x2 Y samples)                                  */
	PIX_FMT_YUYV422,           /* Packed YUV 4:2:2, 16bpp, Y0 Cb Y1 Cr															 */
	PIX_FMT_RGB24,             /* Packed RGB 8:8:8, 24bpp, RGBRGB...															 */
	PIX_FMT_BGR24,             /* Packed RGB 8:8:8, 24bpp, BGRBGR...															 */
	PIX_FMT_YUV422P,           /* Planar YUV 4:2:2, 16bpp, (1 Cr & Cb sample per 2x1 Y samples)									 */
	PIX_FMT_YUV444P,           /* Planar YUV 4:4:4, 24bpp, (1 Cr & Cb sample per 1x1 Y samples)									 */
	PIX_FMT_RGB32,             /* Packed RGB 8:8:8, 32bpp, (msb)8A 8R 8G 8B(lsb), in cpu endianness								 */
	PIX_FMT_YUV410P,           /* Planar YUV 4:1:0,  9bpp, (1 Cr & Cb sample per 4x4 Y samples)									 */
	PIX_FMT_YUV411P,           /* Planar YUV 4:1:1, 12bpp, (1 Cr & Cb sample per 4x1 Y samples)									 */
	PIX_FMT_RGB565,            /* Packed RGB 5:6:5, 16bpp, (msb)   5R 6G 5B(lsb), in cpu endianness								 */
	PIX_FMT_RGB555,            /* Packed RGB 5:5:5, 16bpp, (msb)1A 5R 5G 5B(lsb), in cpu endianness most significant bit to 0	 */
	PIX_FMT_GRAY8,             /*        Y        ,  8bpp																		 */
	PIX_FMT_MONOWHITE,         /*        Y        ,  1bpp, 0 is white, 1 is black												 */
	PIX_FMT_MONOBLACK,         /*        Y        ,  1bpp, 0 is black, 1 is white												 */
	PIX_FMT_PAL8,              /* 8 bit with PIX_FMT_RGB32 palette																 */
	PIX_FMT_YUVJ420P,          /* Planar YUV 4:2:0, 12bpp, full scale (jpeg)													 */
	PIX_FMT_YUVJ422P,          /* Planar YUV 4:2:2, 16bpp, full scale (jpeg)													 */
	PIX_FMT_YUVJ444P,          /* Planar YUV 4:4:4, 24bpp, full scale (jpeg)													 */
	PIX_FMT_XVMC_MPEG2_MC,     /* XVideo Motion Acceleration via common packet passing(xvmc_render.h)							 */
	PIX_FMT_XVMC_MPEG2_IDCT,																									 
	PIX_FMT_UYVY422,           /* Packed YUV 4:2:2, 16bpp, Cb Y0 Cr Y1															 */
	PIX_FMT_UYYVYY411,         /* Packed YUV 4:1:1, 12bpp, Cb Y0 Y1 Cr Y2 Y3													 */
	PIX_FMT_BGR32,             /* Packed RGB 8:8:8, 32bpp, (msb)8A 8B 8G 8R(lsb), in cpu endianness								 */
	PIX_FMT_BGR565,            /* Packed RGB 5:6:5, 16bpp, (msb)   5B 6G 5R(lsb), in cpu endianness								 */
	PIX_FMT_BGR555,            /* Packed RGB 5:5:5, 16bpp, (msb)1A 5B 5G 5R(lsb), in cpu endianness most significant bit to 1	 */
	PIX_FMT_BGR8,              /* Packed RGB 3:3:2,  8bpp, (msb)2B 3G 3R(lsb)													 */
	PIX_FMT_BGR4,              /* Packed RGB 1:2:1,  4bpp, (msb)1B 2G 1R(lsb)													 */
	PIX_FMT_BGR4_BYTE,         /* Packed RGB 1:2:1,  8bpp, (msb)1B 2G 1R(lsb)													 */
	PIX_FMT_RGB8,              /* Packed RGB 3:3:2,  8bpp, (msb)2R 3G 3B(lsb)													 */
	PIX_FMT_RGB4,              /* Packed RGB 1:2:1,  4bpp, (msb)1R 2G 1B(lsb)													 */
	PIX_FMT_RGB4_BYTE,         /* Packed RGB 1:2:1,  8bpp, (msb)1R 2G 1B(lsb)													 */
	PIX_FMT_NV12,              /* Planar YUV 4:2:0, 12bpp, 1 plane for Y and 1 for UV											 */
	PIX_FMT_NV21,              /* as above, but U and V bytes are swapped														 */
																																 
	PIX_FMT_RGB32_1,           /* Packed RGB 8:8:8, 32bpp, (msb)8R 8G 8B 8A(lsb), in cpu endianness								 */
	PIX_FMT_BGR32_1,           /* Packed RGB 8:8:8, 32bpp, (msb)8B 8G 8R 8A(lsb), in cpu endianness								 */
																																 
	PIX_FMT_GRAY16BE,          /*        Y        , 16bpp, big-endian															 */
	PIX_FMT_GRAY16LE,          /*        Y        , 16bpp, little-endian														 */
	PIX_FMT_YUV440P,           /* Planar YUV 4:4:0 (1 Cr & Cb sample per 1x2 Y samples)											 */
	PIX_FMT_YUVJ440P,          /* Planar YUV 4:4:0 full scale (jpeg)															 */
	PIX_FMT_YUVA420P,          /* Planar YUV 4:2:0, 20bpp, (1 Cr & Cb sample per 2x2 Y & A samples)								 */
	PIX_FMT_NB,                /* number of pixel formats, DO NOT USE THIS if you want to link with shared libav* because the number of formats might differ between versions*/
};


enum emSTX_MP4_CODEC_TYPE{
    CODEC_ID_NONE,
    CODEC_ID_MPEG1VIDEO,
    CODEC_ID_MPEG2VIDEO, /* preferred ID for MPEG-1/2 video decoding */
    CODEC_ID_MPEG2VIDEO_XVMC,
    CODEC_ID_H261,
    CODEC_ID_H263,
    CODEC_ID_RV10,
    CODEC_ID_RV20,
    CODEC_ID_MJPEG,
    CODEC_ID_MJPEGB,
    CODEC_ID_LJPEG,
    CODEC_ID_SP5X,
    CODEC_ID_JPEGLS,
    CODEC_ID_MPEG4,
    CODEC_ID_RAWVIDEO,
    CODEC_ID_MSMPEG4V1,
    CODEC_ID_MSMPEG4V2,
    CODEC_ID_MSMPEG4V3,
    CODEC_ID_WMV1,
    CODEC_ID_WMV2,
    CODEC_ID_H263P,
    CODEC_ID_H263I,
    CODEC_ID_FLV1,
    CODEC_ID_SVQ1,
    CODEC_ID_SVQ3,
    CODEC_ID_DVVIDEO,
    CODEC_ID_HUFFYUV,
    CODEC_ID_CYUV,
    CODEC_ID_H264,
    CODEC_ID_INDEO3,
    CODEC_ID_VP3,
    CODEC_ID_THEORA,
    CODEC_ID_ASV1,
    CODEC_ID_ASV2,
    CODEC_ID_FFV1,
    CODEC_ID_4XM,
    CODEC_ID_VCR1,
    CODEC_ID_CLJR,
    CODEC_ID_MDEC,
    CODEC_ID_ROQ,
    CODEC_ID_INTERPLAY_VIDEO,
    CODEC_ID_XAN_WC3,
    CODEC_ID_XAN_WC4,
    CODEC_ID_RPZA,
    CODEC_ID_CINEPAK,
    CODEC_ID_WS_VQA,
    CODEC_ID_MSRLE,
    CODEC_ID_MSVIDEO1,
    CODEC_ID_IDCIN,
    CODEC_ID_8BPS,
    CODEC_ID_SMC,
    CODEC_ID_FLIC,
    CODEC_ID_TRUEMOTION1,
    CODEC_ID_VMDVIDEO,
    CODEC_ID_MSZH,
    CODEC_ID_ZLIB,
    CODEC_ID_QTRLE,
    CODEC_ID_SNOW,
    CODEC_ID_TSCC,
    CODEC_ID_ULTI,
    CODEC_ID_QDRAW,
    CODEC_ID_VIXL,
    CODEC_ID_QPEG,
    CODEC_ID_XVID,
    CODEC_ID_PNG,
    CODEC_ID_PPM,
    CODEC_ID_PBM,
    CODEC_ID_PGM,
    CODEC_ID_PGMYUV,
    CODEC_ID_PAM,
    CODEC_ID_FFVHUFF,
    CODEC_ID_RV30,
    CODEC_ID_RV40,
    CODEC_ID_VC1,
    CODEC_ID_WMV3,
    CODEC_ID_LOCO,
    CODEC_ID_WNV1,
    CODEC_ID_AASC,
    CODEC_ID_INDEO2,
    CODEC_ID_FRAPS,
    CODEC_ID_TRUEMOTION2,
    CODEC_ID_BMP,
    CODEC_ID_CSCD,
    CODEC_ID_MMVIDEO,
    CODEC_ID_ZMBV,
    CODEC_ID_AVS,
    CODEC_ID_SMACKVIDEO,
    CODEC_ID_NUV,
    CODEC_ID_KMVC,
    CODEC_ID_FLASHSV,
    CODEC_ID_CAVS,
    CODEC_ID_JPEG2000,
    CODEC_ID_VMNC,
    CODEC_ID_VP5,
    CODEC_ID_VP6,
    CODEC_ID_VP6F,
    CODEC_ID_TARGA,
    CODEC_ID_DSICINVIDEO,
    CODEC_ID_TIERTEXSEQVIDEO,
    CODEC_ID_TIFF,
    CODEC_ID_GIF,
    CODEC_ID_FFH264,
    CODEC_ID_DXA,
    CODEC_ID_DNXHD,
    CODEC_ID_THP,
    CODEC_ID_SGI,
    CODEC_ID_C93,
    CODEC_ID_BETHSOFTVID,
    CODEC_ID_PTX,
    CODEC_ID_TXD,
    CODEC_ID_VP6A,
    CODEC_ID_AMV,
	CODEC_ID_S263,


    /* various PCM "codecs" */
    CODEC_ID_PCM_S16LE= 0x10000,
    CODEC_ID_PCM_S16BE,
    CODEC_ID_PCM_U16LE,
    CODEC_ID_PCM_U16BE,
    CODEC_ID_PCM_S8,
    CODEC_ID_PCM_U8,
    CODEC_ID_PCM_MULAW,
    CODEC_ID_PCM_ALAW,
    CODEC_ID_PCM_S32LE,
    CODEC_ID_PCM_S32BE,
    CODEC_ID_PCM_U32LE,
    CODEC_ID_PCM_U32BE,
    CODEC_ID_PCM_S24LE,
    CODEC_ID_PCM_S24BE,
    CODEC_ID_PCM_U24LE,
    CODEC_ID_PCM_U24BE,
    CODEC_ID_PCM_S24DAUD,
    CODEC_ID_PCM_ZORK,
	CODEC_ID_PCM_S16LE_PLANAR,

    /* various ADPCM codecs */
    CODEC_ID_ADPCM_IMA_QT= 0x11000,
    CODEC_ID_ADPCM_IMA_WAV,
    CODEC_ID_ADPCM_IMA_DK3,
    CODEC_ID_ADPCM_IMA_DK4,
    CODEC_ID_ADPCM_IMA_WS,
    CODEC_ID_ADPCM_IMA_SMJPEG,
    CODEC_ID_ADPCM_MS,
    CODEC_ID_ADPCM_4XM,
    CODEC_ID_ADPCM_XA,
    CODEC_ID_ADPCM_ADX,
    CODEC_ID_ADPCM_EA,
    CODEC_ID_ADPCM_G726,
    CODEC_ID_ADPCM_CT,
    CODEC_ID_ADPCM_SWF,
    CODEC_ID_ADPCM_YAMAHA,
    CODEC_ID_ADPCM_SBPRO_4,
    CODEC_ID_ADPCM_SBPRO_3,
    CODEC_ID_ADPCM_SBPRO_2,
    CODEC_ID_ADPCM_THP,
    CODEC_ID_ADPCM_IMA_AMV,

    /* AMR */
    CODEC_ID_AMR_NB= 0x12000,
    CODEC_ID_AMR_WB,

    /* RealAudio codecs*/
    CODEC_ID_RA_144= 0x13000,
    CODEC_ID_RA_288,

    /* various DPCM codecs */
    CODEC_ID_ROQ_DPCM= 0x14000,
    CODEC_ID_INTERPLAY_DPCM,
    CODEC_ID_XAN_DPCM,
    CODEC_ID_SOL_DPCM,

    CODEC_ID_MP2= 0x15000,
    CODEC_ID_MP3, /* preferred ID for decoding MPEG audio layer 1, 2 or 3 */
    CODEC_ID_AAC,

    CODEC_ID_MPEG4AAC,

    CODEC_ID_AC3,
    CODEC_ID_DTS,
    CODEC_ID_VORBIS,
    CODEC_ID_DVAUDIO,
    CODEC_ID_WMAV1,
    CODEC_ID_WMAV2,
    CODEC_ID_MACE3,
    CODEC_ID_MACE6,
    CODEC_ID_VMDAUDIO,
    CODEC_ID_SONIC,
    CODEC_ID_SONIC_LS,
    CODEC_ID_FLAC,
    CODEC_ID_MP3ADU,
    CODEC_ID_MP3ON4,
    CODEC_ID_SHORTEN,
    CODEC_ID_ALAC,
    CODEC_ID_WESTWOOD_SND1,
    CODEC_ID_GSM, /* as in Berlin toast format */
    CODEC_ID_QDM2,
    CODEC_ID_COOK,
    CODEC_ID_TRUESPEECH,
    CODEC_ID_TTA,
    CODEC_ID_SMACKAUDIO,
    CODEC_ID_QCELP,
    CODEC_ID_WAVPACK,
    CODEC_ID_DSICINAUDIO,
    CODEC_ID_IMC,
    CODEC_ID_MUSEPACK7,
    CODEC_ID_MLP,
    CODEC_ID_GSM_MS, /* as found in WAV */
    CODEC_ID_ATRAC3,
    CODEC_ID_VOXWARE,
    CODEC_ID_APE,
    CODEC_ID_NELLYMOSER,

    /* subtitle codecs */
    CODEC_ID_DVD_SUBTITLE= 0x17000,
    CODEC_ID_DVB_SUBTITLE,
    CODEC_ID_TEXT,  /* raw UTF-8 text */
    CODEC_ID_XSUB,

	CODEC_ID_MOV_TEXT,

    CODEC_ID_MPEG2TS= 0x20000, /* _FAKE_ codec to indicate a raw MPEG-2 TS
                                * stream (only used by libavformat) */


	CODEC_TYPE_VIDEO = 0x40000,
	CODEC_TYPE_AUDIO,
	CODEC_TYPE_DATA,
	CODEC_TYPE_SUBTITLE,
	CODEC_TYPE_ATTACHMENT,
	CODEC_TYPE_NB,

};


#define M_PI			3.14159265358979323846

#ifdef __WIN32_LIB
#	define INT16_MIN       (-0x7fffi16-1)
#	define INT16_MAX       0x7fffi16
#	define INT32_MIN       (-0x7fffffffi32-1)
#	define INT32_MAX       0x7fffffffi32
#	define UINT32_MAX      0xffffffffui32
#	define INT64_MIN       (-(0x7fffffffffffffffi64)-1)
#	define INT64_MAX	   ( (9223372036854775807i64) )
#	define UINT64_MAX	   ( (0xFFFFFFFFFFFFFFFFui64) )
#endif

#ifndef INT_BIT
#    if INT_MAX != 2147483647
#        define INT_BIT 64
#    else
#        define INT_BIT 32
#    endif
#endif

#ifdef __LINUX_LIB
#	define MAX_PATH 260
#endif

#define FFABS(a) ((a) >= 0 ? (a) : (-(a)))
#define FFSIGN(a) ((a) > 0 ? 1 : -1)

#define FFMAX(a,b) ((a) > (b) ? (a) : (b))
#define FFMIN(a,b) ((a) > (b) ? (b) : (a))
#define FFMAX3(a,b,c) FFMAX(FFMAX(a,b),c)
#define FFMIN3(a,b,c) FFMIN(FFMIN(a,b),c)

#define FFSWAP(type,a,b) do{type SWAP_tmp= b; b= a; a= SWAP_tmp;}while(0)

#define FF_ARRAY_ELEMS(a)		(sizeof(a) / sizeof((a)[0]))


#define AV_NOPTS_VALUE          (sint64)(0x8000000000000000)
#define AV_TIME_BASE            1000000






#define AVPROBE_SCORE_MAX 100               /*max score, half of that is used for file extension based detection*/ 
#define AVPROBE_PADDING_SIZE 32             /* extra allocated bytes at the end of the probe buffer*/

enum AVRounding {
    AV_ROUND_ZERO     = 0, /* round toward zero*/ 
    AV_ROUND_INF      = 1, /* round away from zero*/
    AV_ROUND_DOWN     = 2, /* round toward -infinity*/
    AV_ROUND_UP       = 3, /* round toward +infinity*/
    AV_ROUND_NEAR_INF = 5, /* round to nearest and halfway cases away from zero*/
};

typedef struct AVRational{
    int num; /*numerator*/ 
    int den; /*denominator*/ 
} AVRational;




enum stx_err_cmd {

	STX_ERR_HND_RUN,
	STX_ERR_HND_CLOSE,
	STX_ERR_HND_REPORT,
	STX_ERR_HND_SET_INSIDE_HND,
	STX_ERR_HND_GET_INSIDE_HND,
	STX_ERR_HND_SET_EVENT_HND,
	STX_ERR_HND_GET_EVENT_HND,
	STX_ERR_HND_SET_CANCEL_MODE,
	STX_ERR_HND_GET_CANCEL_MODE,
	STX_ERR_HND_SET_RESULT,
	STX_ERR_HND_GET_RESULT,
	STX_ERR_HND_SET_CODE,
	STX_ERR_HND_GET_CODE,
	STX_ERR_HND_SET_STRING,
	STX_ERR_HND_GET_STRING,
	STX_ERR_HND_WAIT,
	STX_ERR_HND_SIGNAL,
	STX_ERR_HND_GET_USER_DATA,
};


typedef enum emSTX_MP4_STREAM_TYPE emSTX_MP4_STREAM_TYPE;

typedef enum emSTX_MP4_CODEC_TYPE emSTX_MP4_CODEC_TYPE;

typedef enum PixelFormat PixelFormat;

typedef enum stx_err_cmd stx_err_cmd;

typedef struct stx_err_handle    stx_err_handle;

typedef struct stx_err_hnd       stx_err_hnd;



#define XLIV_AGENT  "xliv agent"
#define URL_RDONLY 0
#define URL_WRONLY 1
#define URL_RDWR   2

#ifdef __LINUX_LIB

	char*   _itoa(sint32, char *, sint32);
	char*   _i64toa(sint64, char *, sint32);
	char*   _ui64toa(uint64, char *, sint32);
	sint64  _atoi64(const char *);

#	define STX_SEP "/"
#	define PRId64 "q"

#	ifdef STX64
#		define PRIdPTR "q"
#	else
#		define PRIdPTR ""
#	endif

#else

#	define STX_SEP "\\"
#	define PRId64 "I64"

#	ifdef STX64
#		define PRIdPTR "I64"
#	else
#		define PRIdPTR ""
#	endif

#endif


#if _DEBUG
#	define _SZ_STX_DEBUG  STX_SEP"Debug"
#else
#	define _SZ_STX_DEBUG
#endif

#if defined (__WIN32_LIB )
#	define _SZ_STX_ROOT "C:\\Program Files\\StreamX"
#else
#	define _SZ_STX_ROOT "/usr/StreamX"
#endif // linux


#ifdef STX64
#	define _SZ_STX_PLAT "x64"
#else
#	define _SZ_STX_PLAT "x86"
#endif

#define _SZ_CUR_ROOT _SZ_STX_ROOT _SZ_STX_DEBUG


/***********************************************************************/
#define __STX_ERR_NOT_IMP
/***********************************************************************/

/***********************************************************************/
#define STX_CONSTRUCTOR
/***********************************************************************/

/***********************************************************************/
#define STX_CONSTRUCTOR_IMP
/***********************************************************************/

/***********************************************************************/
#define STX_DESTRUCTOR
/***********************************************************************/

/***********************************************************************/
#define STX_DESTRUCTOR_IMP
/***********************************************************************/


/***********************************************************************/
#define STX_API
/***********************************************************************/

/***********************************************************************/
#define STX_API_IMP
/***********************************************************************/

/***********************************************************************/
#define STX_PRIVATE			static
/***********************************************************************/

/***********************************************************************/
#define _STX_SHARE
/***********************************************************************/

/***********************************************************************/
#define STX_SHARE		static
/***********************************************************************/

/***********************************************************************/
#define STX_SHARE			static
/***********************************************************************/

/***********************************************************************/
#define __STX_PURE(A)
/***********************************************************************/

/***********************************************************************/
#define __STX_PURE_IMP(A)
/***********************************************************************/

/***********************************************************************/
#define __STX_PURE_UNUSED(A)
/***********************************************************************/

/***********************************************************************/
#define _STX_PURE
/***********************************************************************/

/***********************************************************************/
#define STX_PURE		static
/***********************************************************************/


/***********************************************************************/
// use default vt name and THEE name;
#	define STX_PUBLIC(PARENT)   \
		STX_HANDLE	PARENT ## _the;	\
		PARENT		PARENT ## _vt;

// or you can specify a name for PARENT VT and THEE;
#	define __STX_PUBLIC(PARENT,VT) \
		STX_HANDLE	VT ## _the;	\
		PARENT		VT;
/***********************************************************************/

/***********************************************************************/
#define STX_SET_THE(PARENT)			the->PARENT ## _the = (STX_HANDLE)the;
/***********************************************************************/

/***********************************************************************/
#define STX_DECLARE_THE(SON)		SON* the
/***********************************************************************/

/***********************************************************************/
#define STX_DIRECT_THE(SON)	\
	STX_DECLARE_THE(SON);\
	the = (SON*)h
/***********************************************************************/

/***********************************************************************/
#define STX_PEEK_THE(SON,the,h) \
	the = * (  (SON**) ( ( (u8*)h ) - sizeof(void*) ) )
/***********************************************************************/

/***********************************************************************/
#define STX_PEEK_THEN(SON,the,h,n) \
	the = * (  (SON**) ( ( (u8*)h ) - sizeof(void*)*n ) )
/***********************************************************************/

/***********************************************************************/
#define STX_GET_THE(SON) STX_PEEK_THE(SON,the,h)
/***********************************************************************/

/***********************************************************************/
#define STX_GET_THE2(the,SON) \
	the = * (  (SON**) ( ( (u8*)h ) - sizeof(void*)*2 ) )
/***********************************************************************/

/***********************************************************************/
#define STX_MAP_THE(SON)  \
	STX_DECLARE_THE(SON);\
	STX_GET_THE(SON)

#define STX_DECLARE_THE2(SON)		SON* the2
#define STX_MAP_THE2(SON) 			the2 = * (  (SON**) ( ( (u8*)the ) - sizeof(void*) ) )

/***********************************************************************/




#if defined(__WIN32_LIB)
#	define stx_inline		__inline
#	define stx_force_inline __forceinline
#	define stx_fast			__fastcall
#else
#	define stx_inline		inline
#	define stx_force_inline forceinline
#	define stx_fast			fastcall
#endif

struct stx_err_handle{

	_STX_PURE STX_RESULT    (*send_cmd)( 
		stx_err_handle*  h_err, 
		stx_err_cmd      em_cmd, 
		size_t          i_hparam,
		size_t          i_lparam);
};

struct stx_err_hnd{

	stx_err_handle			vt;

	STX_HANDLE			h_this;
};



typedef struct stx_cmd_buf stx_cmd_buf;

struct stx_cmd_buf{

	size_t				i_cmd_buf_len;

	size_t				i_cmd_len;

	STX_BYTE*			cmd_buf;
};

typedef struct stx_cmd_handle stx_cmd_handle;

struct stx_cmd_handle{

	void				(*close)(stx_cmd_handle* hnd);

	void				(*send_cmd)(stx_cmd_handle* hnd,stx_cmd_buf* p_cmd);

	stx_cmd_buf*		(*get_cmd)(stx_cmd_handle* hnd);

	void				(*complete)(stx_cmd_handle* hnd);
};


#ifndef INIT_MEMBER
#	define INIT_MEMBER(A)      memset((void*)&A,0,sizeof(A));
#endif

#define LXRATIO_SCALE       14
#define LXRATIO_COE         (1<<LXRATIO_SCALE)
#define LXRATIO_ROUND       (1<<(LXRATIO_SCALE-1))
#define GET_LXRATIO(W)      ( (W) * LXRATIO_COE )
#define MAKE_LXRATIO(W,H)   ( GET_LXRATIO(W) / H )


//////////////////////////////////////////////////////////////////////////

#define LX_RATIO_4X3        MAKE_LXRATIO(4,3)
#define LX_RATIO_5X3        MAKE_LXRATIO(5,3)
#define LX_RATIO_16X9       MAKE_LXRATIO(16,9)
#define LX_RATIO_16X10      MAKE_LXRATIO(16,10)
#define LX_RATIO_15X9       MAKE_LXRATIO(15,9)
#define LX_RATIO_15X10      MAKE_LXRATIO(15,10)

/* chroma_format */
#define CHROMA420 1
#define CHROMA422 2
#define CHROMA444 3
#define CHROMA420_AYUV 4
#define CHROMA422_AYUV 5
#define CHROMA444_AYUV 6

#define av_const


#define MM_MMX			0x0001 /* standard MMX */
#define MM_MMXEXT		0x0002 /* SSE integer functions or AMD MMX ext */
#define MM_3DNOW		0x0004 /* AMD 3DNOW */
#define MM_SSE			0x0008 /* SSE functions */
#define MM_SSE2			0x0010 /* PIV SSE2 functions */
#define MM_3DNOWEXT		0x0020 /* AMD 3DNowExt */
#define MM_SSE3			0x0040 /* Prescott SSE3 functions */
#define MM_SSSE3		0x0080 /* Conroe SSSE3 functions */
#define MM_SSE41        0x0100
#define MM_SSE42        0x0200
#define MM_SSE4A        0x0400
#define MM_POPCNT       0x0800
extern	s32 mm_support();




/***********************************************************************/
#define STX_INTERF(A)  typedef struct A A
/***********************************************************************/

/***********************************************************************/
#define STX_VT_INIT(vt,PREFIX,funcname) \
	vt.funcname = PREFIX ## _xxx_ ## funcname
/***********************************************************************/

/***********************************************************************/
/**/#define DEFAULT_CODE
/**/#define STX_COM_DATA_DEFAULT(BASE)					BASE ## _data_default()
/**/#define STX_COM_FUNC_DECL_DEFAULT(BASE,PREFIX)			BASE ## _funcdecl(PREFIX)
/**/#define STX_COM_FUNCIMP_DEFAULT(SCOM,BASE,PREFIX)			BASE ## _funcimp_default (SCOM,PREFIX)
/**/#define STX_COM_FUNCIMP_PART(BASE)					BASE ## _funcimp_part()
/**/#define STX_COM_NEW_DEFAULT(BASE,vt,PREFIX,CLS,CAT,NAME)		BASE ## _create_default (vt,PREFIX,CLS,CAT,NAME)
/**/#define STX_COM_DELETE_DEFAULT(BASE)				BASE ## _release_default (BASE)
/**/#define STX_COM_DELETE_BEGIN(BASE)					BASE ## _release_begin (BASE)
/**/#define STX_COM_DELETE_END(BASE)					BASE ## _release_end (BASE)
/**/#define STX_COM_QUERY_DEFAULT(BASE,vt)				BASE ## _query_default (BASE,vt)
/***********************************************************************/



#ifdef __WIN32_LIB
#	define __STX_FILE__     __FILE__
#	define __STX_FUNC__		__FUNCTION__
#	define __STX_LINE__		__LINE__
#	define DECLARE_ALIGNED(n,t,v)      __declspec(align(n)) t v
#	define TFFN_EXPORT
#else
#	define __STX_FILE__     __FILE__
#	define __STX_FUNC__		__PRETTY_FUNCTION__
#	define __STX_LINE__		__LINE__
#	define DECLARE_ALIGNED(n,t,v)		t v __attribute__ ((aligned (n)))
#	define TFFN_EXPORT					extern "C" __attribute__ ((visibility("default")))
#endif


#ifdef __USE_STX_DEBUG__
#	define _MAKE_TRACE3(a)	stx_sprintf(a,sizeof(a),\
	"%s::%s::%d",__STX_FILE__, __STX_FUNC__, __STX_LINE__);
#	define _MAKE_TRACE(a)	stx_sprintf(a,sizeof(a),\
	"%s::%d",__STX_FILE__,__STX_LINE__);
#	define DECL_TRACE		char sz_trace[256];
#	define MAKE_TRACE2		stx_sprintf(sz_trace,sizeof(sz_trace),\
	"%s::%d",__STX_FILE__,__STX_LINE__);
#	define MAP_TRACE		sz_trace 
#	define STX_MAP_TRACE	the->sz_trace 
#	ifdef __USE_GNUC
#		define XCREATE(SCOM,HINST,args...) create_ ## SCOM(HINST,__THIS_FILE__,__LINE__,## args )
#	else
#		define XCREATE(SCOM,HINST,...) create_ ## SCOM(HINST,__THIS_FILE__,__LINE__,## __VA_ARGS__ )
#	endif
#else
#	define _MAKE_TRACE3(a)
#	define _MAKE_TRACE(a)
#	define DECL_TRACE
#	define MAKE_TRACE2
#	define MAP_TRACE		STX_NULL 
#	define STX_MAP_TRACE	STX_NULL 
#	ifdef __USE_GNUC
#		define XCREATE(SCOM,HINST,args...) create_ ## SCOM(HINST,## args)
#	else
#		define XCREATE(SCOM,HINST,...) create_ ## SCOM(HINST,## __VA_ARGS__ )
#	endif
#endif


#define STX_MAKE_TRACE 		_MAKE_TRACE(the->sz_trace)
#define MAKE_TRACE3 		_MAKE_TRACE3(the->sz_trace)


#define DECLARE_ALIGNED_8(t, v) DECLARE_ALIGNED(8, t, v)
#define DECLARE_ALIGNED_16(t, v) DECLARE_ALIGNED(16, t, v)


#define PI 3.14159265359

#define STX_R4(a,b,c,d) ( (a<<6)|(b<<4)|(c<<2)|(d))
#define MKTAG(a,b,c,d) (a | (b << 8) | (c << 16) | (d << 24))
#define MKTAG_EX(a) (a[0] | (a[1] << 8) | (a[2] << 16) | (a[3] << 24))
#define MKTAG_LE(a,b,c,d) (d | (c << 8) | (b << 16) | (a << 24))



#if defined( __cplusplus )
}
#endif

#ifdef __LINUX_LIB
stx_inline void SetRect(RECT* lprc,s32 left,s32 top,s32 right, s32 bottom)
{
	lprc->left = left; lprc->top = top;lprc->right = right; lprc->bottom = bottom;
}
stx_inline b32 PtInRect(STX_RECT* lprc, STX_POINT p)
{
	return p.x <= lprc->right && p.x >= lprc->left &&
		p.y <= lprc->bottom &&	p.y >= lprc->top;
}
#endif // __LINUX_LIB

stx_inline u32 GetWidthFromRatio(u32 dwHeight,u32 dwRatio)
{
	return ( dwHeight * dwRatio + LXRATIO_ROUND ) >> LXRATIO_SCALE;
}
stx_inline u32 GetHeightFromRatio(u32 dwWidth,u32 dwRatio)
{
	return ( dwWidth << LXRATIO_SCALE ) / dwRatio;
}

stx_inline s32 ff_get_fourcc(const char *the)
{
	return (the[0]) + (the[1]<<8) + (the[2]<<16) + (the[3]<<24);
}



#endif /*   __BASE_TYPE_H__2008_06_21   */   
