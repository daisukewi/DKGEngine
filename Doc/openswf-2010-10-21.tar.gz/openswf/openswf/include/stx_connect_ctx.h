

#ifndef __STX_CONNECT_CTX_H__
#define __STX_CONNECT_CTX_H__

/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/


#include "base_interf.h"



#if defined( __cplusplus )
extern "C" {
#endif


STX_API stx_connect_ctx*	stx_connect_ctx_create();


#if defined( __cplusplus )
}
#endif



#endif /* __STX_CONNECT_CTX_H__ */ 