#ifndef __STX_DVD_INTERF_H__
#define __STX_DVD_INTERF_H__

/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/


#include "base_interf.h"



#if defined( __cplusplus )
extern "C" {
#endif


typedef struct stx_dvd_video_frame  stx_dvd_video_frame;

typedef struct stx_dvd_audio_frame stx_dvd_audio_frame;

typedef struct stx_dvd_subtitle_frame  stx_dvd_subtitle_frame;

typedef struct stx_dvd_video_frame_allocator  stx_dvd_video_frame_allocator;

typedef struct stx_dvd_subtitle_frame_allocator  stx_dvd_subtitle_frame_allocator;

typedef struct stx_dvd_control  stx_dvd_control;

typedef struct stx_vcd_control  stx_vcd_control;

typedef struct stx_ts_control  stx_ts_control;

typedef struct stx_dvd_video_render  stx_dvd_video_render;






struct stx_dvd_video_frame{

	stx_media_data		bae_mda;

	/***********************************************************************************

	to do;

	***********************************************************************************/
};

struct stx_dvd_audio_frame{

	stx_media_data		bae_mda;

	/***********************************************************************************

	to do;

	***********************************************************************************/
};


struct stx_dvd_subtitle_frame{

	stx_media_data		bae_mda;

	/***********************************************************************************

	to do;

	***********************************************************************************/
};


struct stx_dvd_video_frame_allocator{

	stx_media_data_allocator  bae_alloc;

	/***********************************************************************************

	to do;

	***********************************************************************************/

};


struct stx_dvd_subtitle_frame_allocator{

	stx_media_data_allocator  bae_alloc;

	/***********************************************************************************

	to do;

	***********************************************************************************/

};

struct stx_dvd_control{

	stx_base_control     bae_ctl;

	/***********************************************************************************

	to do;

	***********************************************************************************/

};


struct stx_vcd_control{

	stx_base_control     bae_ctl;

	/***********************************************************************************

	to do;

	***********************************************************************************/

};



struct stx_ts_control{

	stx_base_control     bae_ctl;

	/***********************************************************************************

	to do;

	***********************************************************************************/

};



struct stx_dvd_video_render{

	stx_base_render		rnd;

	/***********************************************************************************

	to do;

	***********************************************************************************/
};



#if defined( __cplusplus )
}
#endif



#endif /* __STX_DVD_INTERF_H__ */ 

