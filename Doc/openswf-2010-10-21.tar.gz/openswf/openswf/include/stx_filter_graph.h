
#ifndef __STX_FILTER_GRAPH_BASE_H__
#define __STX_FILTER_GRAPH_BASE_H__

/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/


#include "stx_async_plugin.h"


#if defined( __cplusplus )
extern "C" {
#endif

extern char* g_szStreamX_FilterGraph;

STX_API
STX_COM(base_graph);

STX_API
CREATE_STX_COM_DECL(stx_base_graph,base_graph);



#if defined( __cplusplus )
}
#endif


#endif /* __STX_FILTER_GRAPH_BASE_H__ */ 