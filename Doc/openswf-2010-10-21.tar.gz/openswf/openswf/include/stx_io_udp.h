
#ifndef __STX_IO_UDP_H__2008_06_21
#define __STX_IO_UDP_H__2008_06_21



#include "stx_io_tcp.h"


#if defined( __cplusplus )
extern "C" {
#endif


	typedef struct stx_io_udp stx_io_udp;


#ifdef __USE_STX_DEBUG__
	stx_xio*  create_stx_io_udp(THEE hinst,const char* file,s32 line);
#else
	stx_xio*  create_stx_io_udp(THEE hinst);
#endif



#if defined( __cplusplus )
}
#endif


#endif /*   __STX_IO_UDP_H__2008_06_21  */

