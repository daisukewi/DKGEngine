/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/


#ifndef __STX_SERVER_GRAPH_H__
#define __STX_SERVER_GRAPH_H__


#include "stx_async_plugin.h"


#if defined( __cplusplus )
extern "C" {
#endif


STX_INTERF(stx_server_graph);

struct stx_server_graph {

	_STX_PURE	stx_base_com	com;

	_STX_PURE    STX_RESULT		(*add_stream_map)( stx_server_graph h, stx_base_source* h_src );

	_STX_PURE    STX_RESULT		(*rem_stream_mp)( stx_server_graph h, stx_base_source* h_src );

};


STX_API stx_server_graph*		stx_server_graph_create( );





#if defined( __cplusplus )
}
#endif


#endif /* __STX_SERVER_GRAPH_H__ */ 