/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/


#ifndef __STX_MUTEX_H__
#define __STX_MUTEX_H__


#include "stx_base_type.h"

#if defined( __cplusplus )
extern "C" {
#endif



STX_HANDLE	stx_create_mutex(void* security, s32 i_init_owner, char* sz_name);

size_t		stx_waitfor_mutex(STX_HANDLE h_mutex,size_t i_wait_time);

STX_RESULT	stx_release_mutex(STX_HANDLE h_mutex);

void        stx_close_mutex(STX_HANDLE h_mutex);

#if defined( __cplusplus )
}
#endif


#endif /*   __STX_MUTEX_H__  */ 
