
/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#ifndef __STX_IO_BUF_H__
#define __STX_IO_BUF_H__


#include "stx_base_type.h"
#include "stx_io.h"

#if defined( __cplusplus )
extern "C" {
#endif

// read only;

	STX_API stx_xio*  stx_create_io_buf();




#if defined( __cplusplus )
}
#endif


#endif /*   __STX_IO_BUF_H__  */ 
