#ifdef __DEBUG_MB

#include "stx_cpuid.h"

#define xbswap _byteswap_ulong

static void trace_mb_coeff(stx_xio*	hCoeffTxt,s32 mbx,s32 mby, u8* pData[3],s32 nPit[3])
{

	size_t		dwWrite;
	u8*			p;
	s32			i;
	char		szInf[512];

	stx_sprintf(szInf,sizeof(szInf),"mbx = %3d,mby = %3d \r\n",mbx, mby);
	hCoeffTxt->write(hCoeffTxt,szInf,strlen(szInf),&dwWrite);

	p = pData[0];
	for( i = 0; i < 16; i ++ ) {
		stx_sprintf(szInf,sizeof(szInf),"0x%8x ,0x%8x ,0x%8x ,0x%8x \r\n", 
			xbswap(*(u32*)(p)),xbswap(*(u32*)(p+4)),xbswap(*(u32*)(p+8)),xbswap(*(u32*)(p+12)));
		hCoeffTxt->write(hCoeffTxt,szInf,strlen(szInf),&dwWrite);
		p += nPit[0];
	}

	p = pData[1];
	for( i = 0; i < 8; i ++ ) {
		stx_sprintf(szInf,sizeof(szInf),"0x%8x ,0x%8x \r\n", xbswap(*(u32*)(p)),xbswap(*(u32*)(p+4)));
		hCoeffTxt->write(hCoeffTxt,szInf,strlen(szInf),&dwWrite);
		p += nPit[1];
	}

	p = pData[2];
	for( i = 0; i < 8; i ++ ) {
		stx_sprintf(szInf,sizeof(szInf),"0x%8x ,0x%8x \r\n", xbswap(*(u32*)(p)),xbswap(*(u32*)(p+4)));
		hCoeffTxt->write(hCoeffTxt,szInf,strlen(szInf),&dwWrite);
		p += nPit[2];
	}

}

static stx_xio* create_trace_file(char* sz_file,u32 i_flag)
{
	STX_RESULT  i_err;
	stx_xio*	hCoeffTxt;

	hCoeffTxt = stx_create_io_file();
	if( !hCoeffTxt ) {
		assert(0);
		return NULL;
	}

	i_err = hCoeffTxt->open(hCoeffTxt,sz_file,i_flag);
	if( STX_OK != i_err ) {
		assert(0);
		hCoeffTxt->close(hCoeffTxt);
		return NULL;
	}

	return hCoeffTxt;
}

static void trace_frame(VideoFrame* pframe,char* sz_file)
{
	s32			x,y,mx,my;
	u8*			pdata[3];
	stx_xio*	hCoeffTxt;

	hCoeffTxt = create_trace_file(sz_file,O_WRONLY);

	hCoeffTxt->seek(hCoeffTxt,0,SEEK_END);

	mx = pframe->nCodedPictureWidth >> 4;
	my = pframe->nCodedPictureHeight >> 4;

	pdata[0] = pframe->lpData[0];
	pdata[1] = pframe->lpData[1];
	pdata[2] = pframe->lpData[2];

	for( y = 0; y < my; y ++ ){
		for( x = 0; x < mx; x ++ ){
			trace_mb_coeff(hCoeffTxt,x,y,pdata,pframe->nPitch);
			pdata[0] += 16;
			pdata[1] += 8;
			pdata[2] += 8;
		}
		pdata[0] -= pframe->nCodedPictureWidth;
		pdata[1] -= pframe->nCodedPictureWidth>>1;
		pdata[2] -= pframe->nCodedPictureWidth>>1;
		pdata[0] += pframe->nPitch[0]<<4;
		pdata[1] += pframe->nPitch[1]<<3;
		pdata[2] += pframe->nPitch[2]<<3;
	}

	hCoeffTxt->close(hCoeffTxt);

}


#endif // __DEBUG_MB