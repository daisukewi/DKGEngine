/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/
#ifndef __STX_PIN_OUTPUT_H__
#define __STX_PIN_OUTPUT_H__


#include "base_class.h"


#if defined( __cplusplus )
extern "C" {
#endif

STX_COM(output_pin);

STX_API CREATE_STX_COM_DECL(stx_output_pin,output_pin);


#if defined( __cplusplus )
}
#endif


#endif /* __STX_PIN_OUTPUT_H__ */ 