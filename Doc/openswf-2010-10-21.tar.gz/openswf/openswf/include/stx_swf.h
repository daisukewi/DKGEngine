/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/
#ifndef __STX_SWF_H__
#define __STX_SWF_H__

#include "base_class.h"

#if defined( __cplusplus )
extern "C" {
#endif


	// {188FC3DA-A215-4217-B944-2152889E613D}
	DECLARE_XGUID( STX_IID_SwfCanvas,
	0x188fc3da, 0xa215, 0x4217, 0xb9, 0x44, 0x21, 0x52, 0x88, 0x9e, 0x61, 0x3d);

	STX_INTERF(stx_swf_canvas);

#define stx_swf_canvas_vtdef() \
	stx_base_plugin_vtdef() \
	_STX_PURE STX_RESULT (*open)(THEE h, const char* file, s32 oflag );\
	_STX_PURE STX_RESULT (*get_rect)(THEE h, RECT* rec );\
	_STX_PURE STX_RESULT (*enum_button)(THEE h, s32* idx, RECT* rec );\
	_STX_PURE STX_RESULT (*get_button)(THEE h, s32 idx, stx_xio* hio );\
	_STX_PURE STX_RESULT (*push_button)(THEE h, s32 idx );\
	_STX_PURE STX_RESULT (*get_action)(THEE h, s32 idx, s32* i_size, char* url );\

	struct stx_swf_canvas{
		stx_swf_canvas_vtdef()
	};


#define stx_swf_canvas_funcdecl(PREFIX) \
	stx_base_plugin_funcdecl(PREFIX ## _ ## plug); \
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## open(THEE h, const char* file, s32 oflag );\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## get_rect(THEE h, RECT* rec );\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## enum_button(THEE h, s32* idx, RECT* rec );\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## get_button(THEE h, s32 idx, stx_xio* hio );\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## push_button(THEE h, s32 idx);\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## get_action(THEE h, s32 idx, s32* i_size, char* url )


#define stx_swf_canvas_vtinit(vt,PREFIX) \
	STX_VT_INIT(vt,PREFIX,open);\
	STX_VT_INIT(vt,PREFIX,get_rect);\
	STX_VT_INIT(vt,PREFIX,enum_button);\
	STX_VT_INIT(vt,PREFIX,get_button);\
	STX_VT_INIT(vt,PREFIX,push_button);\
	STX_VT_INIT(vt,PREFIX,get_action)

#define stx_swf_canvas_data_default()			\
	stx_base_plugin_data_default()

#define stx_swf_canvas_funcimp_default(SCOM,PREFIX)			\
	stx_base_plugin_funcimp_default(SCOM,PREFIX ## _ ## plug )\

#define stx_swf_canvas_create_default(vt,PREFIX,CLS,CAT,NAME)		\
	stx_base_plugin_create_default(vt,PREFIX ## _ ## plug,CLS,CAT,NAME); \
	stx_swf_canvas_vtinit(vt,PREFIX)

#define stx_swf_canvas_release_default(SCOM)			\
	stx_base_plugin_release_default(SCOM)\

#define stx_swf_canvas_release_begin(SCOM)			\
	stx_base_plugin_release_begin(SCOM)\

#define stx_swf_canvas_release_end(SCOM)			\
	stx_base_plugin_release_end(SCOM)\

#define stx_swf_canvas_query_default(SCOM,vt)			\
	if( IS_EQUAL_GID(gid,STX_IID_SwfCanvas ) ) {\
	/**/the->i_ref ++;\
	/**/*pp_interf = (void*)&vt;\
	/**/return STX_OK;\
	}\
	stx_base_plugin_query_default(SCOM,vt)\



	// {20DD317A-0000-4f3c-980F-386D499AF5D5}
	DECLARE_XGUID( STX_CLSID_SwfCanvas,
	0x20dd317a, 0x0, 0x4f3c, 0x98, 0xf, 0x38, 0x6d, 0x49, 0x9a, 0xf5, 0xd5);

	extern char* g_sz_SwfCanvas;

	STX_COM(stx_swf);

	STX_API CREATE_STX_COM_DECL(stx_swf_canvas, stx_swf);





#if defined( __cplusplus )
}
#endif


#endif // __STX_SWF_H__