/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/
#ifndef __OUTPUT_PIN_WND_H__
#define __OUTPUT_PIN_WND_H__

#include "base_pin_wnd.h"

#if defined( __cplusplus )
extern "C" {
#endif

	STX_INTERF(output_pin_wnd);

	struct output_pin_wnd{
		base_pin_wnd_def();
		stx_output_pin*		m_hOutputPin;
	};


	output_pin_wnd* create_output_pin_wnd(HWND hwnd);



#if defined( __cplusplus )
}
#endif


#endif /* __OUTPUT_PIN_WND_H__ */ 