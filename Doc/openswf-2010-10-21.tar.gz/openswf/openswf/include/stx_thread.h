/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/
#ifndef __STX_THREAD_H__
#define __STX_THREAD_H__

#include "stx_base_type.h"


#if defined( __cplusplus )
extern "C" {
#endif

	typedef struct stx_thread stx_thread;

	struct stx_thread{
		STX_RESULT	(*set_data)(THEE h,THEE h_module,THEE h_dat);
		THEE		(*get_data)(THEE h,THEE h_module);
		u32			(*thread_func)(void*);
		void*		param;
		THEE		h_thread;
		u32			i_thread_id;
		THEE		h_event;
		THEE		h_hash;
		b32			b_started;
	};

	STX_RESULT	thread_init();
	void		thread_free();
	void		SetPersonality(char *user, char* group);

	size_t		get_cur_thread_id();
	stx_thread*	get_cur_thread();
	STX_RESULT	set_main_thread_data(THEE h_module,THEE h_dat);
	THEE		get_main_thread_data(THEE h_module);


STX_HANDLE stx_create_thread (
	void*				SecurityAttributes,
	size_t				StackSize,
	stx_thread*         ThreadParameter,
	u32					CreationFlags,
	u32*				ThreadId
);


unsigned int	stx_wait_thread(STX_HANDLE h_thread,unsigned int wait_flag);
	
void			stx_close_thread(STX_HANDLE h_thread);

STX_RESULT		stx_thread_init
( 	
	STX_HANDLE	hnd, 
	STX_HANDLE	h_proc,
	stx_thread*	param 
);

void			stx_thread_destory(stx_thread* param);


#if defined( __cplusplus )
}
#endif


#endif /*   __STX_THREAD_H__  */ 
