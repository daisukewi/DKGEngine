// rgb_conver.h


#ifndef __STX_RGB_CONVERT_H__
#define __STX_RGB_CONVERT_H__

#include "stx_base_type.h"
#include "stx_cpuid.h"



#if defined( __cplusplus )
extern "C" {
#endif


	void  RGB24_TO_RGB32_LINE_C0(u8* lpSrc,u8* lpDst,s32 nWidth);
	void  RGB24_TO_RGB32_LINE_C(u8* lpSrc,u8* lpDst,s32 nWidth);

#ifndef STX64
	void  RGB24_TO_RGB32_LINE_MMX(u8* lpSrc,u8* lpDst,s32 nWidth);
#endif

	void  RGB24_TO_RGB32_LINE_SSE2(u8* lpSrc,u8* lpDst,s32 nWidth);
	void  RGB24_TO_RGB32_LINE_SSSE3(u8* lpSrc,u8* lpDst,s32 nWidth);
	void  RGB32_TO_RGB24_LINE_C0(u8* lpSrc,u8* lpDst,s32 nWidth);
	void  RGB32_TO_RGB24_LINE_C(u8* lpSrc,u8* lpDst,s32 nWidth);
	void  RGB32_TO_RGB24_LINE_SSE2(u8* lpSrc,u8* lpDst,s32 nWidth);
	void  RGB32_TO_RGB24_LINE_SSSE3(u8* lpSrc,u8* lpDst,s32 nWidth);
	void  RGB24_TO_BGR24_C0(u8* lpSrc,u8* lpDst,s32 nWidth);
	void  RGB24_TO_BGR24_C(u8* lpSrc,u8* lpDst,s32 nWidth);
	void  RGB24_TO_BGR24_SSSE3(u8* lpSrc,u8* lpDst,s32 nWidth);



#if defined( __cplusplus )
}
#endif

#endif //__STX_RGB_CONVERT_H__
