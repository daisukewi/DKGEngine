#ifndef __STX_CUBIC_RESAMPLE_H__
#define __STX_CUBIC_RESAMPLE_H__



#include "stx_all_codec.h"



#if defined( __cplusplus )
extern "C" {
#endif


STX_COM_DECLARE()






#if defined( __cplusplus )
}
#endif

#endif // __STX_CUBIC_RESAMPLE_H__