/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#ifndef __STX_MEM_H__2008_06_21
#define __STX_MEM_H__2008_06_21

#include "stx_base_type.h"

#include "stx_debug.h"

#include "stdio.h"

#include <time.h>


#if defined( __cplusplus )
extern "C" {
#endif


#define STX_DEFAULT_PATH 256

#define SAFE_XFREE(a)	if(a)stx_free(a);
#define SAFE_XFREE0(a)	if(a){	stx_free(a);	a= NULL;	}



/* 
	stx_mem.h 
	create: 2008-06-23
	author: baojinlong
*/ 

int64_t ff_gcd(int64_t a, int64_t b);

int64_t av_rescale_rnd(int64_t a, int64_t b, int64_t c, enum AVRounding rnd);

int64_t av_rescale(int64_t a, int64_t b, int64_t c);

int64_t av_rescale_q(int64_t a, AVRational bq, AVRational cq);

char *debug_strdup(const char *s, const char* file,s32 line);

#ifdef __USE_STX_DEBUG__
	void *smart_malloc( size_t size,const char* sz_dump);
	void *smart_mallocz(size_t size,const char* sz_dump);
	char *smart_strdup(const char *s,const char* sz_dump);
#	define xstrdup(s)			debug_strdup(s,__THIS_FILE__,__LINE__)
#else
#	define smart_malloc(a,b)	xmalloc(a)
#	define smart_mallocz(a,b)	xmallocz(a)
#	define smart_strdup(a,b)	av_strdup(a)
#	define xstrdup(s)			strdup(s)
#endif


extern const uint8 ff_log2_tab[256];



/*!
* \def GET_UTF8(val, GET_BYTE, ERROR)
* converts a UTF-8 character (up to 4 bytes long) to its 32-bit UCS-4 encoded form
* \param val is the output and should be of type uint32. It holds the converted
* UCS-4 character and should be a left value.
* \param GET_BYTE gets UTF-8 encoded bytes from any proper source. It can be
* a function or a statement whose return value or evaluated value is of type
* uint8_t. It will be executed up to 4 times for values in the valid UTF-8 range,
* and up to 7 times in the general case.
* \param ERROR action that should be taken when an invalid UTF-8 byte is returned
* from GET_BYTE. It should be a statement that jumps out of the macro,
* like exit(), goto, return, break, or continue.
*/
#define GET_UTF8(val, GET_BYTE, ERROR)\
    val= GET_BYTE;\
{\
    sint32 ones= 7 - av_log2(val ^ 255);\
    if(ones==1)\
    ERROR\
    val&= 127>>ones;\
    while(--ones > 0){\
    sint32 tmp= GET_BYTE - 128;\
    if(tmp>>6)\
    ERROR\
    val= (val<<6) + tmp;\
    }\
}

/*!
* \def PUT_UTF8(val, tmp, PUT_BYTE)
* converts a 32-bit unicode character to its UTF-8 encoded form (up to 4 bytes long).
* \param val is an input only argument and should be of type uint32. It holds
* a ucs4 encoded unicode character that is to be converted to UTF-8. If
* val is given as a function it's executed only once.
* \param tmp is a temporary variable and should be of type uint8_t. It
* represents an intermediate value during conversion that is to be
* outputted by PUT_BYTE.
* \param PUT_BYTE writes the converted UTF-8 bytes to any proper destination.
* It could be a function or a statement, and uses tmp as the input byte.
* For example, PUT_BYTE could be "*output++ = tmp;" PUT_BYTE will be
* executed up to 4 times for values in the valid UTF-8 range and up to
* 7 times in the general case, depending on the length of the converted
* unicode character.
*/
#define PUT_UTF8(val, tmp, PUT_BYTE)\
{\
    sint32 bytes, shift;\
    uint32 in = val;\
    if (in < 0x80) {\
    tmp = in;\
    PUT_BYTE\
    } else {\
    bytes = (av_log2(in) + 4) / 5;\
    shift = (bytes - 1) * 6;\
    tmp = (256 - (256 >> bytes)) | (in >> shift);\
    PUT_BYTE\
    while (shift >= 6) {\
    shift -= 6;\
    tmp = 0x80 | ((in >> shift) & 0x3f);\
    PUT_BYTE\
    }\
    }\
}



/* IEEE 80 bits extended float */
typedef struct AVExtFloat  {
    uint8_t exponent[2];
    uint8_t mantissa[8];
} AVExtFloat;

double av_int2dbl(int64_t v);
float av_int2flt(int32_t v);
double av_ext2dbl(const AVExtFloat ext);
int64_t av_dbl2int(double d);
int32_t av_flt2int(float d);
AVExtFloat av_dbl2ext(double d);


void *stx_valloc(size_t* size );
void  stx_vfree(void* p,size_t i_size);

void* debug_xlivAlloc( size_t nSize,b32 bZero,s32 nAlign,const char* file,s32 line);

#ifdef __USE_STX_DEBUG__
#	define xlivAlloc(nSize,bZero,nAlign) debug_xlivAlloc(nSize,bZero,nAlign,__THIS_FILE__,__LINE__)
#else
void* xlivAlloc( size_t nSize,b32 bZero,s32 nAlign);
#endif
void  xlivFree(void* p);


void *av_malloc(size_t size );

void *av_mallocz(size_t size );

char *av_strdup(const char *s );

void *av_realloc(void *ptr, size_t old_size,size_t size);


void *av_fast_realloc(void *ptr, size_t *size, size_t min_size);

void av_free(void *ptr);

void av_freep(void *arg);


int	stx_printf(char *fmt,  ...);

int	stx_fprintf(FILE *file, const char *fmt,  ...);

int	stx_snprintf(char *str, size_t size, const char *fmt, ...);


typedef struct tm tm;

size_t		stx_strftime(char *buf, size_t maxsize, const char *format, const tm *timeptr);



void stx_splitpath(    
	const char *path,
	char *drive,
	size_t i_drive_size,
	char *dir,
	size_t i_dir_size,
	char *fname,
	size_t i_fname_size,
	char *ext,
	size_t i_ext_size);

STX_RESULT  stx_mkdir(const char* path);

STX_RESULT  stx_rmdir(const char* path );

STX_RESULT  stx_getenv( 
	size_t* pReturnValue,
	char*	buffer,
	size_t	sizeInBytes,
	const char *varname );



s32		stx_sscanf(const char * src,const char * fmt, ...);

s32		stx_sprintf(char *buffer, size_t i_size, const char *fmt,  ...);

char*	stx_strcpy(char *strDestination,size_t i_size, const char *strSource);
char*	stx_strcpyn(char *strDestination,size_t i_size, const char *strSource);

char*	stx_strncpy(char *strDestination,size_t i_src_size, const char *strSource,size_t i_cpy_size);

char*	stx_strcat(char *strDestination,size_t i_size, const char *strSource);

char*	stx_strncat(char *strDest,const char *strSource,size_t count);

char*	stx_strdup(char* str);

char*	stx_strupr(char* str,size_t i_size);
char*	stx_strlwr(char* str,size_t i_size);

FILE*	stx_fopen( const char *filename,const char *mode );


struct tm*	stx_gmtime (const time_t *, struct tm *result);

struct tm*	stx_localtime (const time_t *, struct tm *result);



#if defined( __cplusplus )
}
#endif


stx_inline sint32 av_log2(uint32 v)
{
    sint32 n = 0;
    if (v & 0xffff0000) {
        v >>= 16;
        n += 16;
    }
    if (v & 0xff00) {
        v >>= 8;
        n += 8;
    }
    n += ff_log2_tab[v];

    return n;
}


#endif /* __STX_MEM_H__2008_06_21*/
