/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-11
***********************************************************************************/
#ifndef __STX_SESSION_H__
#define __STX_SESSION_H__


#include "stx_async_plugin.h"
#include "stx_prop_def.h"

#if defined( __cplusplus )
extern "C" {
#endif


	STX_INTERF(stp_subchannel);

	struct stp_subchannel{
		s32					i_chid;
		stx_xio*			h_data;
		stx_gid				major_type;
		stx_gid				sub_type;
		char*				major_name;
		char*				sub_name;
		s32					i_hdr_size;
		u8*					p_hdr;
		s32					i_idx;
	};


	/*****************************************************************************
	start of stx_protocol interface definition

	|----| |----| |----|
	STX:   FLAG   SIZE

	bytes 0-3, FOURCC TAG, <STX:>
	bytes 4-7, BE32, <FLAG>
	bytes 8-11, BE32, THEE BODY SIZE;

	*****************************************************************************/

#define STX_PROT_LIMIT_TIME	2*60*1000 //(2 minutes, in millisecond)
#define STX_PROT_STOP_TIME	3*1000 //(3 seconds, in millisecond)

#define STX_PROT_HDR_SIZE   12


	// {481DEE52-C8EE-4ecb-803A-A9B822603C67}
	DECLARE_XGUID( STX_IID_BaseSession,
	0x481dee52, 0xc8ee, 0x4ecb, 0x80, 0x3a, 0xa9, 0xb8, 0x22, 0x60, 0x3c, 0x67);

	//
	STX_INTERF(stx_base_session);


#define stx_base_session_vtdef() \
	stx_base_com_vtdef()\
	_STX_PURE STX_RESULT	(*enum_method)(THEE h, s32* i_idx, char** method_name);\
	_STX_PURE stx_gid		(*get_session_id)(THEE h);\
	_STX_PURE STX_RESULT	(*initialize)( \
	STX_HANDLE				h, \
	stx_xio*				h_xio,\
	THEE					h_callback);\

	struct stx_base_session{
		stx_base_session_vtdef()
	};

#define stx_base_session_funcdecl(PREFIX) \
	stx_base_com_funcdecl(PREFIX ## _ ## com) \
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## enum_method(THEE h, s32* i_idx, char** method_name);\
	STX_PURE stx_gid	PREFIX ## _xxx_ ## get_session_id(THEE h);\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## initialize( \
	THEE				h, \
	stx_xio*			h_xio,\
	THEE				h_callback)

#define stx_base_session_vtinit(vt,PREFIX) \
	STX_VT_INIT(vt,PREFIX,enum_method);\
	STX_VT_INIT(vt,PREFIX,get_session_id);\
	STX_VT_INIT(vt,PREFIX,initialize)

#define stx_base_session_data_default()			\
	stx_base_com_data_default()

#define stx_base_session_funcimp_default(SCOM,PREFIX)	\
	stx_base_com_funcimp_default(SCOM,PREFIX ## _ ## com )\

#define stx_base_session_create_default(vt,PREFIX,CLS,CAT,NAME)	\
	stx_base_com_create_default(vt,PREFIX ## _ ## com,CLS,CAT,NAME); \
	stx_base_session_vtinit(vt,PREFIX)


#define stx_base_session_release_default(SCOM)		\
	stx_base_com_release_default(SCOM)\

#define stx_base_session_release_begin(SCOM) \
	stx_base_com_release_begin(SCOM)\

#define stx_base_session_release_end(SCOM) \
	stx_base_com_release_end(SCOM)\


#define stx_base_session_query_default(SCOM,vt)		\
	if( IS_EQUAL_GID(gid,STX_IID_BaseSession) ) {\
		the->i_ref ++;\
		*pp_interf = (void*)&vt;\
		return STX_OK;\
	}\
	stx_base_com_query_default(SCOM,vt )\


	/*****************************************************************************
	end of stx_base_session interface definition
	*****************************************************************************/

	// {ECC1649C-8CAE-4224-8911-C0B0677058E4}
	DECLARE_XGUID( STX_CLSID_StxSession,
	0xecc1649c, 0x8cae, 0x4224, 0x89, 0x11, 0xc0, 0xb0, 0x67, 0x70, 0x58, 0xe4);
	extern char* g_sz_StreamX_StxSession;

	STX_COM(stx_session);
	STX_API CREATE_STX_COM_DECL(stx_base_session,stx_session);


#if defined( __cplusplus )
}
#endif


#endif // __STX_SESSION_H__