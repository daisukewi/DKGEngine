//
/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#ifndef __STX_CPUID_H__
#define __STX_CPUID_H__


#include "stx_base_type.h"



#ifdef __WIN32_LIB
#	include <intrin.h> 
#	include <mmintrin.h>
#	include <mm3dnow.h>
#	include <xmmintrin.h>
#	include <emmintrin.h>
#	include <pmmintrin.h>
#	include <tmmintrin.h>
#	include <smmintrin.h>
#endif // __WIN32_LIB


#ifdef __LINUX_LIB
#	include <mmintrin.h>
#	include <mm3dnow.h>
#	include <xmmintrin.h>
#	include <emmintrin.h>
#	include <pmmintrin.h>
#	include <tmmintrin.h>
#	include <smmintrin.h>
#endif // __LINUX_LIB



#define MM_DECLARE8 \
	__m64 imm0;\
	__m64 imm1;\
	__m64 imm2;\
	__m64 imm3;\
	__m64 imm4;\
	__m64 imm5;\
	__m64 imm6;\
	__m64 imm7

#define XMM_DECLARE8 \
	__m128 ixmm0;\
	__m128 ixmm1;\
	__m128 ixmm2;\
	__m128 ixmm3;\
	__m128 ixmm4;\
	__m128 ixmm5;\
	__m128 ixmm6;\
	__m128 ixmm7

#define XMM_DECLARE16 \
	__m128 ixmm0;\
	__m128 ixmm1;\
	__m128 ixmm2;\
	__m128 ixmm3;\
	__m128 ixmm4;\
	__m128 ixmm5;\
	__m128 ixmm6;\
	__m128 ixmm7;\
	__m128 ixmm8;\
	__m128 ixmm9;\
	__m128 ixmm10;\
	__m128 ixmm11;\
	__m128 ixmm12;\
	__m128 ixmm13;\
	__m128 ixmm14;\
	__m128 ixmm15

#define XMMI_DECLARE8 \
	__m128i ixmm0;\
	__m128i ixmm1;\
	__m128i ixmm2;\
	__m128i ixmm3;\
	__m128i ixmm4;\
	__m128i ixmm5;\
	__m128i ixmm6;\
	__m128i ixmm7

#define XMMI_DECLARE16 \
	__m128i ixmm0;\
	__m128i ixmm1;\
	__m128i ixmm2;\
	__m128i ixmm3;\
	__m128i ixmm4;\
	__m128i ixmm5;\
	__m128i ixmm6;\
	__m128i ixmm7;\
	__m128i ixmm8;\
	__m128i ixmm9;\
	__m128i ixmm10;\
	__m128i ixmm11;\
	__m128i ixmm12;\
	__m128i ixmm13;\
	__m128i ixmm14;\
	__m128i ixmm15


#define XMMD_DECLARE8 \
	__m128d ixmm0;\
	__m128d ixmm1;\
	__m128d ixmm2;\
	__m128d ixmm3;\
	__m128d ixmm4;\
	__m128d ixmm5;\
	__m128d ixmm6;\
	__m128d ixmm7

#define XMMD_DECLARE16 \
	__m128d ixmm0;\
	__m128d ixmm1;\
	__m128d ixmm2;\
	__m128d ixmm3;\
	__m128d ixmm4;\
	__m128d ixmm5;\
	__m128d ixmm6;\
	__m128d ixmm7;\
	__m128d ixmm8;\
	__m128d ixmm9;\
	__m128d ixmm10;\
	__m128d ixmm11;\
	__m128d ixmm12;\
	__m128d ixmm13;\
	__m128d ixmm14;\
	__m128d ixmm15


#define _MM_DECLARE8 \
	__m64 imm0;\
	__m64 imm1;\
	__m64 imm2;\
	__m64 imm3;\
	__m64 imm4;\
	__m64 imm5;\
	__m64 imm6;\
	__m64 imm7;

#define _XMMI_DECLARE8 \
	__m128i ixmm0;\
	__m128i ixmm1;\
	__m128i ixmm2;\
	__m128i ixmm3;\
	__m128i ixmm4;\
	__m128i ixmm5;\
	__m128i ixmm6;\
	__m128i ixmm7;

#define _XMMI_DECLARE16 \
	__m128i ixmm0;\
	__m128i ixmm1;\
	__m128i ixmm2;\
	__m128i ixmm3;\
	__m128i ixmm4;\
	__m128i ixmm5;\
	__m128i ixmm6;\
	__m128i ixmm7;\
	__m128i ixmm8;\
	__m128i ixmm9;\
	__m128i ixmm10;\
	__m128i ixmm11;\
	__m128i ixmm12;\
	__m128i ixmm13;\
	__m128i ixmm14;\
	__m128i ixmm15;

#define XMMF_DECLARE8 \
	__m128 fxmm0;\
	__m128 fxmm1;\
	__m128 fxmm2;\
	__m128 fxmm3;\
	__m128 fxmm4;\
	__m128 fxmm5;\
	__m128 fxmm6;\
	__m128 fxmm7

#define _XMMF_DECLARE8 \
	__m128 fxmm0;\
	__m128 fxmm1;\
	__m128 fxmm2;\
	__m128 fxmm3;\
	__m128 fxmm4;\
	__m128 fxmm5;\
	__m128 fxmm6;\
	__m128 fxmm7;

#define XMMF_DECLARE16 \
	__m128 fxmm0;\
	__m128 fxmm1;\
	__m128 fxmm2;\
	__m128 fxmm3;\
	__m128 fxmm4;\
	__m128 fxmm5;\
	__m128 fxmm6;\
	__m128 fxmm7;\
	__m128 fxmm8;\
	__m128 fxmm9;\
	__m128 fxmm10;\
	__m128 fxmm11;\
	__m128 fxmm12;\
	__m128 fxmm13;\
	__m128 fxmm14;\
	__m128 fxmm15

#define _XMMF_DECLARE16 \
	__m128 fxmm0;\
	__m128 fxmm1;\
	__m128 fxmm2;\
	__m128 fxmm3;\
	__m128 fxmm4;\
	__m128 fxmm5;\
	__m128 fxmm6;\
	__m128 fxmm7;\
	__m128 fxmm8;\
	__m128 fxmm9;\
	__m128 fxmm10;\
	__m128 fxmm11;\
	__m128 fxmm12;\
	__m128 fxmm13;\
	__m128 fxmm14;\
	__m128 fxmm15;

#define XMMR_DECLARE8 \
	__m128d rxmm0;\
	__m128d rxmm1;\
	__m128d rxmm2;\
	__m128d rxmm3;\
	__m128d rxmm4;\
	__m128d rxmm5;\
	__m128d rxmm6;\
	__m128d rxmm7

#define _XMMR_DECLARE8 \
	__m128d rxmm0;\
	__m128d rxmm1;\
	__m128d rxmm2;\
	__m128d rxmm3;\
	__m128d rxmm4;\
	__m128d rxmm5;\
	__m128d rxmm6;\
	__m128d rxmm7;

#define XMMR_DECLARE16 \
	__m128d rxmm0;\
	__m128d rxmm1;\
	__m128d rxmm2;\
	__m128d rxmm3;\
	__m128d rxmm4;\
	__m128d rxmm5;\
	__m128d rxmm6;\
	__m128d rxmm7;\
	__m128d rxmm8;\
	__m128d rxmm9;\
	__m128d rxmm10;\
	__m128d rxmm11;\
	__m128d rxmm12;\
	__m128d rxmm13;\
	__m128d rxmm14;\
	__m128d rxmm15

#define _XMMR_DECLARE16 \
	__m128d rxmm0;\
	__m128d rxmm1;\
	__m128d rxmm2;\
	__m128d rxmm3;\
	__m128d rxmm4;\
	__m128d rxmm5;\
	__m128d rxmm6;\
	__m128d rxmm7;\
	__m128d rxmm8;\
	__m128d rxmm9;\
	__m128d rxmm10;\
	__m128d rxmm11;\
	__m128d rxmm12;\
	__m128d rxmm13;\
	__m128d rxmm14;\
	__m128d rxmm15;


#define CONV_PM64(A)  ( (__m64*)(A) )
#define CONV_M64(A)   *( (__m64*)&(A) )

#define CONV_PXMM(A) ( (__m128*)(A) )
#define CONV_XMM(A)  *( (__m128*)&(A) )

#define CONV_PXMMI(A) ( (__m128i*)(A) )
#define CONV_XMMI(A)  *( (__m128i*)&(A) )

#define CONV_PXMMD(A) ( (__m128d*)(A) )
#define CONV_XMMD(A)  *( (__m128d*)&(A) )



#ifdef __LINUX_LIB
#define x32_01010101			0x01010101UL
#define x32_02020202			0x02020202UL
#define x32_03030303			0x03030303UL
#define x32_0F0F0F0F			0x0F0F0F0FUL
#define x32_7f7f7f7f			0x7f7f7f7fUL
#define x32_80808080			0x80808080UL
#define x32_FCFCFCFC			0xFCFCFCFCUL
#define x32_FEFEFEFE			0xFEFEFEFEUL
#define x64_0101010101010101	0x0101010101010101ULL
#define x64_0202020202020202	0x0202020202020202ULL
#define x64_0303030303030303	0x0303030303030303ULL
#define x64_0F0F0F0F0F0F0F0F	0x0F0F0F0F0F0F0F0FULL
#define x64_7f7f7f7f7f7f7f7f	0x7f7f7f7f7f7f7f7fULL
#define x64_8080808080808080	0x8080808080808080ULL
#define x64_FCFCFCFCFCFCFCFC	0xFCFCFCFCFCFCFCFCULL
#define x64_FEFEFEFEFEFEFEFE	0xFEFEFEFEFEFEFEFEULL
#endif


#ifdef __WIN32_LIB
#   define x32_01010101			0x01010101ui32
#   define x32_02020202			0x02020202ui32
#   define x32_03030303			0x03030303ui32
#   define x32_0F0F0F0F			0x0F0F0F0Fui32
#   define x32_7f7f7f7f			0x7f7f7f7fui32
#   define x32_80808080			0x80808080ui32
#   define x32_FCFCFCFC			0xFCFCFCFCui32
#   define x32_FEFEFEFE			0xFEFEFEFEui32
#   define x64_0101010101010101	0x0101010101010101ui64
#   define x64_0202020202020202	0x0202020202020202ui64
#   define x64_0303030303030303	0x0303030303030303ui64
#   define x64_0F0F0F0F0F0F0F0F	0x0F0F0F0F0F0F0F0Fui64
#   define x64_7f7f7f7f7f7f7f7f	0x7f7f7f7f7f7f7f7fui64
#   define x64_8080808080808080	0x8080808080808080ui64
#   define x64_FCFCFCFCFCFCFCFC	0xFCFCFCFCFCFCFCFCui64
#   define x64_FEFEFEFEFEFEFEFE	0xFEFEFEFEFEFEFEFEui64
#endif // __WIN32_LIB

#ifdef STX64
#	define x_01 x64_0101010101010101
#	define x_7f x64_7f7f7f7f7f7f7f7f
#	define x_fe x64_FEFEFEFEFEFEFEFE
#else
#	define x_01 x32_01010101 
#	define x_7f x32_7f7f7f7f
#	define x_fe x32_FEFEFEFE 
#endif




#ifdef __WIN32_LIB
#	define FAST_RB16(x)	_byteswap_ushort(*(u16*)(x))
#	define FAST_RB32(x) _byteswap_ulong(*(u32*)(x))
#	define FAST_WB32(p,d) *(u32*)(p) = _byteswap_ulong(d)
#	define FAST_RB64(x) _byteswap_uint64(*(u64*)(x))
#	define FAST_RL32(x) *(u32*)(x)
#	define FAST_WL32(p,d) *(u32*)(p) = *(u32*)(d)
#	define FAST_SWAP32(A,B) A = _byteswap_ulong(B);
#elif defined(__LINUX_LIB)
#	define FAST_RB16(x)	__builtin_bswap16(*(u16*)(x))
#	define FAST_RB32(x) __builtin_bswap32(*(u32*)(x))
#	define FAST_WB32(p,d) *(u32*)(p) = __builtin_bswap32(d)
#	define FAST_RB64(x) __builtin_bswap64(*(u64*)(x))
#	define FAST_RL32(x) *(u32*)(x)
#	define FAST_WL32(p,d) *(u32*)(p) = *(u32*)(d)
#	define FAST_SWAP32(A,B) A = __builtin_bswap32(B);
#else

#	define FAST_RB16(x)	((((const uint8*)(x))[0] << 8) | ((const uint8*)(x))[1])

#	define FAST_RB32(x)  ((((uint8*)(x))[0] << 24) | \
	(((uint8*)(x))[1] << 16) | \
	(((uint8*)(x))[2] <<  8) | \
	((uint8*)(x))[3])

#	define FAST_WB32(p, d) do { \
	((uint8*)(p))[3] = (d); \
	((uint8*)(p))[2] = (d)>>8; \
	((uint8*)(p))[1] = (d)>>16; \
	((uint8*)(p))[0] = (d)>>24; } while(0)

#	define FAST_RB64(x)  (((uint64)((const uint8*)(x))[0] << 56) | \
	((uint64)((const uint8*)(x))[1] << 48) | \
	((uint64)((const uint8*)(x))[2] << 40) | \
	((uint64)((const uint8*)(x))[3] << 32) | \
	((uint64)((const uint8*)(x))[4] << 24) | \
	((uint64)((const uint8*)(x))[5] << 16) | \
	((uint64)((const uint8*)(x))[6] <<  8) | \
	(uint64)((const uint8*)(x))[7])

#define FAST_RL32(x) ((((uint8*)(x))[3] << 24) | \
	(((uint8*)(x))[2] << 16) | \
	(((uint8*)(x))[1] <<  8) | \
	((uint8*)(x))[0])

#	define FAST_WL32(p, d) do { \
	((uint8*)(p))[0] = (d); \
	((uint8*)(p))[1] = (d)>>8; \
	((uint8*)(p))[2] = (d)>>16; \
	((uint8*)(p))[3] = (d)>>24; } while(0)

#	define FAST_SWAP32(A,B) \
	A = (B << 16) | ( B >> 16 );\
	A = ( ( A & 0xff00ff00 ) >> 8 ) | ( ( A & 0x00ff00ff ) << 8 );

#endif


#if defined( __cplusplus )
extern "C" {
#endif


extern s32 get_cpu_flag();
extern s32 stx_cpu_cpuid( s32 op, s32 *eax, s32 *ebx, s32 *ecx, s32 *edx );

#ifdef __WIN32_LIB
#	ifndef STX64
		extern u32 stx_cpuid_test();
#	endif
#	define get_rdtsc  __rdtsc
#else
	extern u32 stx_cpuid_test();
	extern u64 get_rdtsc();
#endif

#ifdef __WIN32_LIB
#	pragma warning(disable:4101)
#	pragma  warning(disable:4731)
#endif


#if defined( __cplusplus )
}
#endif

#endif // __STX_CPUID_H__
