/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/

#ifndef __STX_IO_INTERLEAVED_H__
#define __STX_IO_INTERLEAVED_H__


#include "stx_base_type.h"
#include "stx_io.h"
#include "stx_gid_def.h"
#include "base_class.h"



#if defined( __cplusplus )
extern "C" {
#endif


	/*****************************************************************************

	STP packet definition;

	|-|  |-|  |--| [.....] [....]
	ID  FLAG  SIZE DATA    PADDING

	byte 0, CHANNEL ID;
	byte 1, FLAG
	bytes 2-3, BE16, VALID DATA SIZE;
	bytes 4-1499, DATA[SIZE], PADDING[1496-SIZE];

	*****************************************************************************/

#define STP_ID_SYS_RESPONSE			0  // server send response to a request;
#define STP_ID_SYS_MSG				1  // server send message to a client;
#define STP_ID_STREAM_DATA			2  // system stream data;

// 3 to 255, for separate video, audio, text channel;
#define STP_ID_APP					10  // sub stream data, text board,etc.
#define STP_ID_AUDIO				11  // sub stream data, audio;
#define STP_ID_VIDEO				12  // sub stream data, video;


#define STP_FLAG_NORMAL				0x01
#define STP_FLAG_END				0x02
#define STP_FLAG_PAUSE				0x04


	/*****************************************************************************
	AVP packet definition;

	|-|  |-|  |--| [.....] [....]
	FLAG ID   SIZE DATA    PADDING

	byte  0, '$';
	byte  1, CHANNLE ID
	bytes 2-3, BE16, VALID DATA SIZE;
	bytes 4-1499, DATA[SIZE], PADDING[1496-SIZE];

	*****************************************************************************/





	/*****************************************************************************
	interleaved read ...
	*****************************************************************************/






	/*****************************************************************************
	interleaved writer, com interface;
	*****************************************************************************/


	// {F5F2F4EB-CD96-42ec-B357-DAFA5713440B}
	DECLARE_XGUID( STX_IID_InterleavedIo,
	0xf5f2f4eb, 0xcd96, 0x42ec, 0xb3, 0x57, 0xda, 0xfa, 0x57, 0x13, 0x44, 0xb)

	STX_INTERF(stx_interleaved);

#define stx_interleaved_vtdef() \
	stx_base_com_vtdef() \
	_STX_PURE STX_RESULT (*create_channel)(STX_HANDLE h,s32 i_id,stx_xio** hh_xio);\
	_STX_PURE STX_RESULT (*enum_channel)(STX_HANDLE h,s32* i_idx, stx_xio** hh_xio);\
	_STX_PURE STX_RESULT (*pause_channel)(STX_HANDLE h,stx_xio* hh_xio);\
	_STX_PURE STX_RESULT (*resume_channel)(STX_HANDLE h,stx_xio* hh_xio);\
	_STX_PURE STX_RESULT (*flush_all)(STX_HANDLE h );\

	struct stx_interleaved{
		stx_interleaved_vtdef()
	};


#define stx_interleaved_funcdecl(PREFIX) \
	stx_base_com_funcdecl(PREFIX ## _ ## com) \
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## create_channel(STX_HANDLE h,s32 i_id,stx_xio** hh_xio);\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## enum_channel(STX_HANDLE h,s32* i_idx, stx_xio** hh_xio);\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## pause_channel(STX_HANDLE h,stx_xio* hh_xio);\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## resume_channel(STX_HANDLE h,stx_xio* hh_xio);\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## flush_all(STX_HANDLE h)


#define stx_interleaved_vtinit(vt,PREFIX) \
	STX_VT_INIT(vt,PREFIX,create_channel);\
	STX_VT_INIT(vt,PREFIX,enum_channel);\
	STX_VT_INIT(vt,PREFIX,pause_channel);\
	STX_VT_INIT(vt,PREFIX,resume_channel);\
	STX_VT_INIT(vt,PREFIX,flush_all)
	
#define stx_interleaved_data_default()			\
	stx_base_com_data_default()

#define stx_interleaved_funcimp_default(SCOM,PREFIX)			\
	stx_base_com_funcimp_default(SCOM,PREFIX ## _ ## com )\

#define stx_interleaved_create_default(vt,PREFIX,CLS,CAT,NAME)		\
	stx_base_com_create_default(vt,PREFIX ## _ ## com,CLS,CAT,NAME); \
	stx_interleaved_vtinit(vt,PREFIX)

#define stx_interleaved_release_default(SCOM)			\
	stx_base_com_release_default(SCOM)\

#define stx_interleaved_release_begin(SCOM)			\
	stx_base_com_release_begin(SCOM)\

#define stx_interleaved_release_end(SCOM)			\
	stx_base_com_release_end(SCOM)\

#define stx_interleaved_query_default(SCOM,vt)			\
	if( IS_EQUAL_GID(gid,STX_IID_InterleavedIo ) ) {\
	/**/the->i_ref ++;\
	/**/*pp_interf = (void*)&vt;\
	/**/return STX_OK;\
	}\
	stx_base_com_query_default(SCOM,vt)\



	// write only;
	// {E907D4EC-A6A2-475e-8C8D-00F20784BBD4}
	DECLARE_XGUID( STX_CLSID_InterleavedIo,
	0xe907d4ec, 0xa6a2, 0x475e, 0x8c, 0x8d, 0x0, 0xf2, 0x7, 0x84, 0xbb, 0xd4)
	
	extern char* g_sz_InterleavedIo;

	STX_COM(stx_io_int, stx_xio* h_output, s32 i_oflag );

	STX_API CREATE_STX_COM_DECL( stx_interleaved, stx_io_int, stx_xio* h_output, s32 i_oflag );



#if defined( __cplusplus )
}
#endif


#endif /*   __STX_IO_INTERLEAVED_H__  */ 
