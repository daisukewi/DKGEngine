/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-11
***********************************************************************************/

#ifndef __TS_SPLIT_H__
#define __TS_SPLIT_H__


#include "base_class.h"

#include "stx_gid_def.h"

#include "mpegdef.h"

#if defined( __cplusplus )
extern "C" {
#endif


	STX_API	STX_COM(ts_split);

	STX_API	CREATE_STX_COM_DECL(stream_split,ts_split);


#if defined( __cplusplus )
}
#endif


#endif // __TS_SPLIT_H__