/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-11
***********************************************************************************/

#ifndef __PS_SPLIT_H__
#define __PS_SPLIT_H__


#include "ts_split.h"


#if defined( __cplusplus )
extern "C" {
#endif


	STX_API	STX_COM(ps_split);


	STX_API	CREATE_STX_COM_DECL(stream_split,ps_split);



#if defined( __cplusplus )
}
#endif

#endif // __PS_SPLIT_H__