/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-11
***********************************************************************************/
#include "stx_io.h"
#include "stx_io_stream.h"
#include "stx_os.h"
#include "stx_mem.h"
#include "stx_debug.h"


#include "ps_split.h"

#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif
/********************************************/
#define __GET_BITS_INC__
#include "get_bits.h"
#include "get_bits.c"
/********************************************/


/*****************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
*****************************************************************************************/
static s64 ts_get_time_code(stx_bits_window* const pStream)
{
	s32 pts32,pts3130,pts2915,pts1400;

	pts32 = stx_get_bits(pStream,1);

	pts3130 = stx_get_bits(pStream,2);

	stx_get_bits(pStream,1);

	pts2915 = stx_get_bits(pStream,15);

	stx_get_bits(pStream,1);

	pts1400 = stx_get_bits(pStream,15);

	stx_get_bits(pStream,1);

	return ( (s64)pts32 << 32 ) + (pts3130 << 30) + (pts2915 << 15) + pts1400;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API_IMP
CREATE_STX_COM(stream_split,STX_IID_StreamSplit,ps_split);


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_COM_BEGIN(ps_split);
/**/
/**/STX_PUBLIC(stream_split)
/**/STX_COM_DATA_DEFAULT(stream_split)
/**/
/**/STX_PUBLIC(ts_control)
/**/
/**/stx_xio*	h_stream;
/**/stx_gid		gidInputType;
/**/
STX_COM_END();



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_COM_FUNC_DECL_DEFAULT(stream_split,stream_split_vt);
STX_COM_FUNCIMP_DEFAULT(ps_split,stream_split,stream_split_vt);

STX_COM_FUNC_DECL_DEFAULT(ts_control,ts_control_vt);
STX_COM_FUNCIMP_DEFAULT(ts_split,ts_control,ts_control_vt);


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE: local routines
***************************************************************************/



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_COM_MAP_BEGIN(ps_split)
/**/STX_COM_MAP_ITEM(STX_IID_StreamSplit)
/**/STX_COM_MAP_ITEM(STX_IID_PsControl)
STX_COM_MAP_END()

STX_NEW_BEGIN(ps_split)
{
	STX_SET_THE(stream_split);
	STX_COM_NEW_DEFAULT(stream_split,the->stream_split_vt,stream_split_vt,
		DEFAULT_CODE,DEFAULT_CODE,DEFAULT_CODE);

	STX_SET_THE(ts_control);
	STX_COM_NEW_DEFAULT(ts_control,the->ts_control_vt,ts_control_vt,
		DEFAULT_CODE,DEFAULT_CODE,DEFAULT_CODE);

}
STX_NEW_END()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_DELETE_BEGIN(ps_split)
{

	STX_COM_DELETE_DEFAULT(stream_split);
}
STX_DELETE_END
(
STX_COM_DELETE_BEGIN(stream_split)
,
STX_COM_DELETE_END(stream_split)
)

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_QUERY_BEGIN(ps_split)
{
	// do not use ts control default query macro;
	if( IS_EQUAL_GID(STX_IID_PsControl,gid) ) {
		the->i_ref ++;
		*pp_interf = (void*)&the->ts_control_vt;
		return STX_OK;
	}

	STX_COM_QUERY_DEFAULT(stream_split,the->stream_split_vt);

}
STX_QUERY_END()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT ts_control_vt_xxx_enum_input_type
(STX_HANDLE h,s32 *i_idx,stx_media_type_inf *p_inf)
{
	STX_MAP_THE(ps_split);

	if( !i_idx ) {
		return STX_ERR_INVALID_PARAM;
	}

	if( ! p_inf ){
		*i_idx = 2;
		return STX_OK;
	}

	{
		s32 const idx = *i_idx;

		if( idx < 0 || idx > 1 ) {
			return STX_ERR_INVALID_PARAM;
		}

		p_inf->major_type = MEDIATYPE_Stream;

		if( 0 == idx ) {
			p_inf->sub_type = MEDIASUBTYPE_MPEG2_PROGRAM;
		}
		else {
			p_inf->sub_type = MEDIASUBTYPE_MPEG1System;
		}

		binary_to_string(sizeof(stx_gid),(u8*)&p_inf->major_type,*p_inf->major_type_name);
		binary_to_string(sizeof(stx_gid),(u8*)&p_inf->sub_type,*p_inf->sub_type_name);

		return STX_OK;

	} // block

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
ts_control_vt_xxx_set_input_type(STX_HANDLE h,s32 i_idx)
{
	STX_MAP_THE(ps_split);

	if( i_idx < 0 || i_idx > 1 ) {
		return STX_ERR_INVALID_PARAM;
	}

	if( 0 == i_idx ) {
		the->gidInputType = MEDIASUBTYPE_MPEG2_PROGRAM;
	}
	else {
		the->gidInputType = MEDIASUBTYPE_MPEG1System;
	}

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT ts_control_vt_xxx_enum_channel
(STX_HANDLE h,s32 *i_idx,ts_channel_inf *p_inf)
{
	STX_MAP_THE(ps_split);

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT ts_control_vt_xxx_enum_selected_channel
(STX_HANDLE h,s32 *i_idx,ts_channel_inf *p_inf)
{
	STX_MAP_THE(ps_split);

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT ts_control_vt_xxx_select_channel
(STX_HANDLE h,s32 i_idx,b32 b_select)
{
	STX_MAP_THE(ps_split);

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE void stream_split_vt_xxx_reset(STX_HANDLE h)
{
	STX_MAP_THE(ps_split);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stream_split_vt_xxx_get_type
(STX_HANDLE h,s32* pid,stx_gid* major_type,stx_gid* sub_type)
{
	STX_MAP_THE(ps_split);
	{
		return STX_OK;
	}
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stream_split_vt_xxx_get_time
(STX_HANDLE h,s64* pts, s64* dts )
{
	STX_MAP_THE(ps_split);
	{
		return STX_OK;
	}
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stream_split_vt_xxx_get_data
(STX_HANDLE h,stx_media_data* p_mdat)
{
	STX_RESULT		i_err;
	stx_io_op_param	inf;
	u8*				buf;
	size_t			i_size;

	STX_MAP_THE(ps_split);

	i_err = the->h_stream->get(the->h_stream,
		STX_IO_READ_P,&inf);

	if( STX_OK != i_err ) {
		return STX_FAIL;
	}

	i_size = p_mdat->get_buf(p_mdat,&buf);
	if( i_size < inf.i_available_data ) {
		i_err = p_mdat->resize(p_mdat,(size_t)inf.i_available_data);
	}

	i_err = p_mdat->get_data(p_mdat,&buf,&i_size);
	if( STX_OK != i_err ) {
		return STX_FAIL;
	}

	memcpy(buf,inf.buf,(size_t)inf.i_available_data);

	p_mdat->set_data(p_mdat,buf,(size_t)inf.i_available_data);

	the->h_stream->clear(the->h_stream);

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stream_split_vt_xxx_parse
(
 /**/STX_HANDLE			h, \
 /**/u8*				buf,
 /**/size_t				i_len,
 /**/u8**				pp_data, 
 /**/size_t*			i_data
)
{
	STX_RESULT		i_err;
	stx_io_op_param	inf;

	STX_MAP_THE(ps_split);


	return STX_OK;
}

