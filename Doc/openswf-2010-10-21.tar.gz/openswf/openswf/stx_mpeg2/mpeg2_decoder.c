/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/
#include "stdio.h"
#include "stdlib.h"
#include "fcntl.h"
#include "memory.h"
#include "string.h"


#if defined (__WIN32_LIB)
#	include "time.h"
#	include "time.inl"
#else
#	include <time.h>
#endif /* #if defined (__WIN32_LIB) */


#include "stx_all.h"

#include "video/video_decoder.h"
#include "video/frame_decoder.h"

#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif


static void mpeg2_decoder_notify(THEE h);
static STX_RESULT mpeg2_decoder_reset(THEE h);



STX_INPUT_MEDIA_TYPE_MAP_BEGIN(mpeg2_decoder)
/**/MEDIA_TYPE_MAP_ITEM(MEDIATYPE_Video,MEDIASUBTYPE_MPEG2_VIDEO)
STX_INPUT_MEDIA_TYPE_MAP_END()

STX_OUTPUT_MEDIA_TYPE_MAP_BEGIN(mpeg2_decoder)
/**/MEDIA_TYPE_MAP_ITEM(MEDIATYPE_Video,MEDIASUBTYPE_LxVideoFrame)
STX_OUTPUT_MEDIA_TYPE_MAP_END()

/*{{{filter definition; **********************************/
STX_COM_BEGIN(mpeg2_decoder);
/*base filter; */
/**/STX_PUBLIC(stx_base_filter)
/**/STX_COM_DATA_DEFAULT(stx_base_filter)
/**/
/*other members; */
/**/stx_output_pin*		p_output_pin;
/**/stx_base_pin*		p_input_pin;
/**/STX_HANDLE			h_task;
/**/video_decoder*		the2;
/**/stx_media_data*		p_mdat_in;
/**/THEE				h_stack;
/**/b32					b_subdec;
/**/s32					iTaskNum;
/**/s32					iTaskMode;
/**/THEE				h_mutex;
/**/
STX_COM_END();
/*}}*******************************************************/



/*{{{STX_PURE*******************************************************/
STX_COM_FUNC_DECL_DEFAULT(stx_base_filter,stx_base_filter_vt);
STX_COM_FUNCIMP_DEFAULT(mpeg2_decoder,stx_base_filter,stx_base_filter_vt);
/*}}}STX_PURE*******************************************************/


/*{{{STX_MSG_PROC_DECLARE***************************************************/
STX_MSG_PROC_DECLARE(dispatch_msg)
STX_MSG_PROC_DECLARE(response_msg)
/*}}}***********************************************************************/


/*{{{STX_MSG_ENTRY_DECLARE**************************************************/
STX_MSG_ENTRY_DECLARE(on_play)
STX_MSG_ENTRY_DECLARE(on_pause)
STX_MSG_ENTRY_DECLARE(on_resume)
STX_MSG_ENTRY_DECLARE(on_stop)
STX_MSG_ENTRY_DECLARE(at_play)
STX_MSG_ENTRY_DECLARE(at_pause)
STX_MSG_ENTRY_DECLARE(at_resume)
STX_MSG_ENTRY_DECLARE(at_stop)
STX_MSG_ENTRY_DECLARE(at_BreakPin)

/*}}}***********************************************************************/


/*{{{STX_BEGIN_MSG_MAP******************************************************/
STX_BEGIN_MSG_MAP(the_msg_data)
/* to do : add msg process entry here; */
/**/ON_STX_MSG(STX_MSG_Play,on_play)
/**/ON_STX_MSG(STX_MSG_Pause,on_pause)
/**/ON_STX_MSG(STX_MSG_Resume,on_resume)
/**/ON_STX_MSG(STX_MSG_Stop,on_stop)
STX_END_MSG_MAP
/*}}}***********************************************************************/

/*{{{STX_DISPATCH_MSG_PROC**************************************************/
STX_DISPATCH_MSG_PROC( dispatch_msg ,the_msg_data)
/*}}}***********************************************************************/


/*{{{STX_BEGIN_MSG_RESPONSE_MAP*********************************************/
STX_BEGIN_MSG_RESPONSE_MAP(the_msg_response)
/* to do : add msg process entry here; */
/**/ON_STX_MSG(STX_MSG_Play,at_play)
/**/ON_STX_MSG(STX_MSG_Pause,at_pause)
/**/ON_STX_MSG(STX_MSG_Resume,at_resume)
/**/ON_STX_MSG(STX_MSG_Stop,at_stop)
/**/ON_STX_MSG(STX_MSG_BreakPin,at_BreakPin)
STX_END_MSG_RESPONSE_MAP
/*}}}***********************************************************************/


/*{{{STX_RESPONSE_MSG_PROC**************************************************/
STX_RESPONSE_MSG_PROC( response_msg,the_msg_response )
/*}}}***********************************************************************/


STX_PRIVATE STX_RESULT create_subtask(mpeg2_decoder* the);

STX_PRIVATE STX_RESULT  stx_m2v_init_inputpin(mpeg2_decoder* the);
STX_PRIVATE void stx_m2v_close_inputpin(mpeg2_decoder* the);

STX_PRIVATE STX_RESULT  stx_m2v_init_outputpin(mpeg2_decoder* the);
STX_PRIVATE void stx_m2v_close_outputpin(mpeg2_decoder* the);

STX_PRIVATE void stop_decoder(mpeg2_decoder* the);


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE: imp the constructor;
***************************************************************************/
STX_COM_MAP_BEGIN(mpeg2_decoder)
/**/STX_COM_MAP_ITEM(STX_IID_BaseFilter)
STX_COM_MAP_END()

STX_NEW_BEGIN(mpeg2_decoder)
{
	STX_SET_THE(stx_base_filter);
	STX_COM_NEW_DEFAULT(stx_base_filter, the->stx_base_filter_vt, stx_base_filter_vt,
		STX_CLSID_Mpeg2Decoder,STX_CATEGORY_IntermediateFilter,g_szStreamX_Mpeg2Decoder);

	the->the2 = (video_decoder*)xlivAlloc( sizeof(video_decoder),TRUE,16);
	if( !the->the2){
		break;
	}
	if(STX_OK != mpeg2_video_decode_initialize(the->the2) ) {
		break;
	}

	if( STX_OK != stx_m2v_init_inputpin(the) ) {
		break;
	}

	if( STX_OK != stx_m2v_init_outputpin(the) ) {
		break;
	}

	the->h_stack = stx_stack_create();
	if( !the->h_stack ) {
		break;
	}
}
STX_NEW_END()
// }}imp the constructor;


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API_IMP 
STX_QUERY_BEGIN(mpeg2_decoder)
{
	STX_COM_QUERY_DEFAULT(stx_base_filter,the->stx_base_filter_vt);
}
STX_QUERY_END()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API_IMP	 
STX_DELETE_BEGIN(mpeg2_decoder)
{
	stx_m2v_close_inputpin(the);

	stx_m2v_close_outputpin(the);

	stop_decoder(the);

	if( the->h_stack ) {
		stx_stack_close(the->h_stack);
		the->h_stack = NULL;
	}

	STX_COM_DELETE_DEFAULT(stx_base_filter);
}
STX_DELETE_END
(
 STX_COM_DELETE_BEGIN(stx_base_filter)
 ,
 STX_COM_DELETE_END(stx_base_filter)
 )

 /***************************************************************************
 RETURN VALUE:
 INPUT:
 OUTPUT:
 NOTE:stx_lxvidf_alloc_create
 ***************************************************************************/
STX_PRIVATE STX_RESULT  stx_m2v_init_outputpin(mpeg2_decoder* the)
{
	STX_RESULT					i_err;
	stx_mda_alloc_base_param	prop;
	stx_mem_alloc_base*			palloc;

	i_err = STX_FAIL;
	palloc = STX_NULL;

	do{

		the->p_output_pin = XCREATE(output_pin,NULL);
		if( !the->p_output_pin ) {
			break;
		}
		XCALL(set_parent,the->p_output_pin,(stx_base_plugin*)&the->stx_base_filter_vt);

		palloc = XCREATE(vfrm_alloc,NULL);
		if( !palloc ) {
			break;
		}

		// max b frames + 2; so 8 is enough;
		prop.i_mda_num = 8; 
		prop.i_mda_size = 0; 

		i_err = palloc->set_param(palloc,&prop,sizeof(prop));

		if( STX_OK != i_err ) {
			break;
		}

		i_err = the->p_output_pin->set_mem_allocator(the->p_output_pin,palloc);
		if( STX_OK != i_err ) {
			break;
		}

		the->the2->h_output_pin = the->p_output_pin;

		i_err = STX_OK;

	}while(FALSE);

	SAFE_XDELETE( palloc);

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
**************************************************************************/
STX_PRIVATE void stx_m2v_close_outputpin(mpeg2_decoder* the)
{
	SAFE_XDELETE(the->p_output_pin);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:stx_lxvidf_alloc_create
***************************************************************************/
STX_PRIVATE STX_RESULT stx_m2v_init_inputpin(mpeg2_decoder* the)
{
	the->p_input_pin = XCREATE(stx_input_pin,NULL);
	if( !the->p_input_pin ) {
		return STX_FAIL;
	}
	the->p_input_pin->set_parent(the->p_input_pin,(stx_base_plugin *)&the->stx_base_filter_vt);
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE void stx_m2v_close_inputpin(mpeg2_decoder* the)
{
	SAFE_XDELETE(the->p_input_pin);
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_get_property
(STX_HANDLE h,stx_xio* h_xio)
{
	STX_MAP_THE(mpeg2_decoder);
	{
		STX_RESULT	i_err;
		stx_xini*	h_xini;
		THEE		h_TaskNum;
		THEE		h_TaskMode;

		i_err = STX_FAIL;
		h_xini = NULL;


		do{

			i_err = stx_ini_create(NULL,h_xio,STX_INI_READ_WRITE|STX_INI_NO_COMMENT,0, &h_xini);
			if( STX_OK != i_err ) {
				break;
			}

			i_err = h_xini->create_key(h_xini,NULL,"thread num","0",&h_TaskNum);
			if(STX_OK != i_err ) {
				break;
			}
			i_err = h_xini->write_int32(h_xini,h_TaskNum,the->iTaskNum);
			if(STX_OK != i_err ) {
				break;
			}
			i_err = h_xini->create_key(h_xini,NULL,"thread mode","0",&h_TaskMode);
			if(STX_OK != i_err ) {
				break;
			}
			i_err = h_xini->write_int32(h_xini,h_TaskMode,the->iTaskMode);
			if(STX_OK != i_err ) {
				break;
			}

			i_err = STX_OK;

		}while(FALSE);

		if( h_xini ) {
			h_xini->close(h_xini);
		}

		return i_err;
	}

	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_set_property
(STX_HANDLE h,stx_xio* h_xio)
{
	STX_MAP_THE(mpeg2_decoder);
	{
		STX_RESULT	i_err;
		stx_xini*	h_xini;
		THEE		h_TaskNum;
		THEE		h_TaskMode;

		i_err = STX_FAIL;
		h_xini = NULL;


		do{

			i_err = stx_ini_create(NULL,h_xio,STX_INI_READ_ONLY|STX_INI_NO_COMMENT,0, &h_xini);
			if( STX_OK != i_err ) {
				break;
			}

			i_err = h_xini->create_key(h_xini,NULL,"thread num","0",&h_TaskNum);
			if(STX_OK == i_err ) {
				i_err = h_xini->read_int32(h_xini,h_TaskNum,&the->iTaskNum);
				if(STX_OK != i_err ) {
					break;
				}
			}
			i_err = h_xini->create_key(h_xini,NULL,"thread mode","0",&h_TaskMode);
			if(STX_OK == i_err ) {
				i_err = h_xini->read_int32(h_xini,h_TaskMode,&the->iTaskMode);
				if(STX_OK != i_err ) {
					break;
				}
			}

			i_err = STX_OK;

		}while(FALSE);

		if( h_xini ) {
			h_xini->close(h_xini);
		}

		return i_err;
	}

	return STX_ERR_NOT_SUPPORT;
}




/***************************************************************************
RETURN VALUE:
STX_OK : deliver success;
STX_WOUNLD_BLOCK, need to re-deliver this media data again;
other value is failed;
INPUT:
OUTPUT:
NOTE: push mode use only;
***************************************************************************/

enum{
	em_m2vdec_start,
	em_m2vdec_bot,
	em_m2vdec_submid,
	em_m2vdec_subend,
	em_m2vdec_subreset,
	em_m2vdec_rend_top,
	em_m2vdec_rend_bot,
	em_m2vdec_end,
};

STX_PURE STX_RESULT stx_base_filter_vt_xxx_deliver
(
 STX_HANDLE			h,
 stx_base_pin*		h_pin, // which input pin;
 stx_media_data*	p_mdat, // output media data;
 stx_sync_inf*		h_sync 
 )
{
	STX_MAP_THE(mpeg2_decoder);
	the->p_mdat_in = p_mdat;
	stx_stack_push(the->h_stack,em_m2vdec_start);
	RESET_XENTRY(h_sync,h);
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static void mpeg2_decoder_notify(THEE h)
{
	STX_DIRECT_THE(mpeg2_decoder);
	{
		video_decoder* const	the2 = the->the2;

		stx_waitfor_mutex(the->h_mutex,INFINITE);
		the2->nThrCount ++;
		if( the2->nThrCount == the2->g_nFrmDecoderNum ) {
			the->h_ssrc->reset_task(the->h_ssrc,the->h_task,0,0);
		}
		//stx_log("subtask return number:%d\r\n",the2->nThrCount);
		stx_release_mutex(the->h_mutex);
	}
}
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static STX_RESULT mpeg2_decoder_reset(THEE h)
{
	STX_DIRECT_THE(mpeg2_decoder);
	{

		STX_RESULT				i_err;
		stx_base_message*		p_msg;
		stx_msg_cnt*			p_cnt;

		do{

			p_msg = NULL;
			i_err = STX_FAIL;


			// first time run;
			p_msg = XCREATE(base_msg,NULL,NULL);
			if( !p_msg ) {
				break;
			}
			p_msg->set_msg_type(p_msg,STX_MSG_TYPE_DOWNSTREAM);
			p_cnt = p_msg->get_msg_cnt(p_msg);
			p_cnt->msg_gid = STX_MSG_RESET_TIME;

			i_err = the->p_output_pin->send_msg(the->p_output_pin,p_msg);
			if( STX_OK != i_err ) {
				break;
			}

			if( !p_msg->is_msg_closed(p_msg) ) {
				i_err = STX_FAIL;
				break;
			}

		}while(FALSE);

		SAFE_XDELETE(p_msg);

		return i_err;
	}
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
#define RESET_SUBTASK \
{\
	s32 k; \
	the2->nThrCount = 0;\
	for( k = 0; k < the2->g_nFrmDecoderNum; k ++ ) {\
		frame_decoder* const fdec = the2->ppFrameCtx[k];\
		stx_sync_source* const hssrc = fdec->h_ssrc;\
		hssrc->xresume(hssrc,fdec->h_task);\
	}\
	h_sync->i_result |= STX_SUBTASK; \
	RESET_XENTRY(h_sync,h);		\
}

static u64 g_last = 0;


static STX_RESULT stx_base_filter_vt_plug_xxx_run
( STX_HANDLE h,stx_sync_inf* h_sync)
{
	STX_MAP_THE(mpeg2_decoder);
	{
		STX_RESULT				i_err;
		s32						i;
		size_t*					h_status;
		size_t					i_status;

		video_decoder* const	the2 = the->the2;


		if( !the->h_task ) {
			the->h_task = h_sync->h_task;
			i_err = create_subtask(the);
			if( STX_OK != i_err ) {
				return i_err;
			}
		}

		if( the->h_task != h_sync->h_task ) {
			for( i = 0; i < the2->g_nFrmDecoderNum; i ++ ) {
				if( h_sync->h_task == the2->h_subtask[i] ) {
					return mpeg2_video_decode_frame(the2,the2->ppFrameCtx[i],h_sync);
				} //if( h_sync->h_task == h_ctx->h_subtask ) {
			} // for( i = 0; i < h_decode->g_nFrmDecoderNum; i ++ ) {
		}

		h_status = stx_stack_pop(the->h_stack);
		if( !h_status ){
			return STX_FAIL;
		}
		i_status = *h_status;

		if( em_m2vdec_end == i_status ) {
			return STX_OK;
		}


		if( em_m2vdec_rend_top == i_status ) {

			assert(the2->p_output_data );

			if( the2->bUpGrade ) {
				the2->p_upgrade_data = the2->p_output_data;
				XCALL(incr,the2->p_upgrade_data);
			}

			RESET_XENTRY(h_sync,h);
			i_err = XCALL(deliver,the->p_output_pin,the2->p_output_data,h_sync);
			if( i_err < 0 ) {
				XCALL(release_media_data,the->p_output_pin,the2->p_output_data);
				the2->p_output_data = NULL;
				return i_err;
			}
			the2->p_output_data = NULL;
			// stack status pushed by prev status;
			return i_err;

		} // if( em_m2vdec_rend_top == i_status ) {


		if( em_m2vdec_rend_bot == i_status ) {

			assert(the2->p_upgrade_data);

			// set upgrade picture attr;
			i_err = XCALL(query_interf,the2->p_upgrade_data,STX_IID_LxVideoFrame,(void**)&the2->lpUpGradeFrame);
			if( STX_OK != i_err ) {
				return i_err;
			}
			XCALL(release,the2->p_upgrade_data);
			// set it as upgrade picture;
			vfrmSetUpGradeDisplay(the2->lpUpGradeFrame,TRUE);

			// we have call incr before;
			XCALL(release_media_data,the->p_output_pin,the2->p_upgrade_data);

			i_err = XCALL(deliver,the->p_output_pin,the2->p_upgrade_data,h_sync);
			if( i_err < 0 ) {
				XCALL(release_media_data,the->p_output_pin,the2->p_upgrade_data);
				the2->p_upgrade_data = NULL;
				return i_err;
			}
			the2->p_upgrade_data = NULL;

			// stack status pushed by prev status;
			return i_err;

		} // if( em_m2vdec_upgrade == i_status ) {


		if( em_m2vdec_start == i_status ) {

			size_t		i_data_len;
			u8*			data_buf;

			i_err = STX_FAIL;
			i_data_len = 0;
			data_buf = NULL;

			if( !the->p_mdat_in ) { // last picture;

				i_err = OutputLastFrameOfSequence(the2);
				if( i_err < 0 ){
					return i_err;
				}

				if( the2->p_output_data ) { // deliver new data;

					// upgrade
					// if have upgrade picture ?
					if( the2->p_upgrade_data ) {
						stx_stack_push(the->h_stack,em_m2vdec_end);
						stx_stack_push(the->h_stack,em_m2vdec_rend_bot); // this time upgrade picture;
						stx_stack_push(the->h_stack,em_m2vdec_rend_top); // this time picture;
						stx_stack_push(the->h_stack,em_m2vdec_rend_bot); // last upgrade picture;
						return STX_AGAIN;
					}

					if( the2->bUpGrade ) {
						stx_stack_push(the->h_stack,em_m2vdec_end);
						stx_stack_push(the->h_stack,em_m2vdec_rend_bot); // this time upgrade picture;
						stx_stack_push(the->h_stack,em_m2vdec_rend_top); // this time picture;
						return STX_AGAIN;
					}

					stx_stack_push(the->h_stack,em_m2vdec_end);
					stx_stack_push(the->h_stack,em_m2vdec_rend_top); // this time picture;
					return STX_AGAIN;
				}

				if( the2->p_upgrade_data ) {
					stx_stack_push(the->h_stack,em_m2vdec_end);
					stx_stack_push(the->h_stack,em_m2vdec_rend_bot); // last upgrade picture;
					return STX_AGAIN;
				}

				return STX_OK;

			}// if( !the->p_mdat_in ) {

			i_err = the->p_mdat_in->get_data(the->p_mdat_in,(void**)&data_buf,&i_data_len);
			if( STX_OK != i_err ){
				return i_err;
			}

			the2->vdat.vdr.PresentTimeStamp = REFTIME2PTS( XCALL(get_time,the->p_mdat_in,NULL) );

			i_err = mpeg2_video_decode_start(the2, data_buf,(s32)i_data_len );
			if( i_err <= 0 ){
				XCALL(release_media_data,the->p_input_pin,the->p_mdat_in);
				the->p_mdat_in = NULL;
				return i_err;
			}

			if( STX_REPEAT == i_err ) {

				assert(the2->p_output_data);

				// data not consumed;  repeat frame only;
				xlog("repeat output video frame\r\n");

				// upgrade
				// if have upgrade picture ?
				if( the2->p_upgrade_data ) {
					stx_stack_push(the->h_stack,em_m2vdec_start);
					stx_stack_push(the->h_stack,em_m2vdec_rend_top); // this time picture;
					stx_stack_push(the->h_stack,em_m2vdec_rend_bot); // last upgrade picture;
					return STX_AGAIN;
				}
				stx_stack_push(the->h_stack,em_m2vdec_start);
				stx_stack_push(the->h_stack,em_m2vdec_rend_top); // this time picture;
				return STX_AGAIN;

			} // if( STX_REPEAT == i_err ) {

			XCALL(release_media_data,the->p_input_pin,the->p_mdat_in);
			the->p_mdat_in = NULL;

// 			{
// 				char sz[64];
// 				binary_to_string(16,data_buf,sz);
// 				xlog("video decoder, frame data:%s\r\n",sz);
// 			}

			if( the2->g_nFrmDecoderNum >  1 ) {
				stx_stack_push(the->h_stack,em_m2vdec_submid); // switch to other branch;
				// let main task return to ssrc, and wait for sub-task over;
				RESET_SUBTASK;
				return STX_OK;
			}

			// no subtask, single thread;
			{
				// call frame decode TOP;
				frame_decoder* const h_ctx = the2->ppFrameCtx[0];
				h_ctx->h_ssrc = h_sync->h_ssrc;
				h_ctx->h_task = h_sync->h_task;
				i_err = video_subdecode(the2,h_ctx,h_sync);
				if( STX_OK != i_err ) {
					return i_err;
				}
			}

			if( the2->bUpGrade && the2->p_upgrade_data ) {
				// if have upgrade picture ?
				stx_stack_push(the->h_stack,em_m2vdec_bot);
				stx_stack_push(the->h_stack,em_m2vdec_rend_bot); // last upgrade picture;
				return STX_AGAIN;
			}// if( the2->bUpGrade ) {

			// no upgrade picture, continue to second pass decode;
			i_status = em_m2vdec_bot;

		} // if( em_m2vdec_start == i_status ) {


		if( em_m2vdec_bot == i_status ) {

			if( the2->bUpGrade && FRAME_PICTURE == the2->vdat.bsw.pic_cod_ext.nPictureStructure) {
				// call frame decode BOT;
				frame_decoder* const h_ctx = the2->ppFrameCtx[0];
				h_ctx->h_ssrc = h_sync->h_ssrc;
				h_ctx->h_task = h_sync->h_task;
				i_err = video_subdecode(the2,h_ctx,h_sync);
				if( STX_OK != i_err ) {
					return i_err;
				}
			}

			// gather output;
			i_err = mpeg2_video_decode_end(the2);
			if( STX_OK != i_err ) {
				return i_err;
			}

			if( the2->p_output_data ) {
				//stx_log("have output video frame, time code =%"PRId64"d\r\n", 
				//	REFTIME2MILISEC(the2->p_output_data->get_time(the2->p_output_data,NULL) ) );
				stx_stack_push(the->h_stack,em_m2vdec_end);
				stx_stack_push(the->h_stack,em_m2vdec_rend_top);
				return STX_AGAIN;
			} // if( the2->p_output_data ) {

			return i_err;

		} // if( em_m2vdec_bot == i_status ) {

		// multiple task branch;

		if( em_m2vdec_submid == i_status ) {  
			
			// after subtask decode top;

			if( the2->bUpGrade ){

				if( FRAME_PICTURE == the2->vdat.bsw.pic_cod_ext.nPictureStructure ) {
					// if have upgrade picture ?
					if( the2->p_upgrade_data ) {
						stx_stack_push(the->h_stack,em_m2vdec_subend);	 // to finish decode at last;
						stx_stack_push(the->h_stack,em_m2vdec_subreset); // second to reset subtask;
						stx_stack_push(the->h_stack,em_m2vdec_rend_bot); // first rend last upgrade picture;
						return STX_AGAIN;
					}

					// no upgrade picture, reset the subtask;
					h_sync->i_result |= STX_SUBTASK; 
					RESET_XENTRY(h_sync,h);
					RESET_SUBTASK;
					return STX_OK;
				}

				// field picture,
				// if have upgrade picture ?
				if( the2->p_upgrade_data ) {
					stx_stack_push(the->h_stack,em_m2vdec_subend);	 // to finish decode at last;
					stx_stack_push(the->h_stack,em_m2vdec_rend_bot); // first rend last upgrade picture;
					return STX_AGAIN;
				}

			} // if( the2->bUpGrade ){

			// if not need do upgrade, mpeg2_video_decode_frame will decode whole frame;

			i_status = em_m2vdec_subend;

		} // if( em_m2vdec_subtop == i_status ) {


		if( em_m2vdec_subend == i_status ) {

			// subtask + upgrade + subtask over;

			// gather output;
			i_err = mpeg2_video_decode_end(the2);
			if( STX_OK != i_err ) {
				return i_err;
			}

			if( the2->p_output_data ) {

/*
				u64 t = the2->p_output_data->get_time(the2->p_output_data,NULL);
				t = REFTIME2MILISEC(t);
				if( g_last ){
					stx_log("have output video frame, time code =%"PRId64"d\r\n", t - g_last );
				}
				g_last = t;
*/

				stx_stack_push(the->h_stack,em_m2vdec_end);
				stx_stack_push(the->h_stack,em_m2vdec_rend_top);
				return STX_AGAIN;
			} // if( the2->p_output_data ) {

			return i_err;
		}

		if( em_m2vdec_subreset == i_status ) {
			// reset the subtask, continue to do decode;
			h_sync->i_result |= STX_SUBTASK; 
			RESET_XENTRY(h_sync,h);						
			RESET_SUBTASK;
			return STX_OK;
		}

	} // block;

	// should be never reach;
	return STX_FAIL;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_enum_input_pin
(STX_HANDLE h,s32* i_index,stx_base_pin** pp_pin)
{
	STX_MAP_THE(mpeg2_decoder);

	if( !i_index ) {
		return STX_ERR_INVALID_PARAM;
	}

	if( !pp_pin) {
		*i_index = 1;
		return STX_OK;
	}

	if( *i_index != 0 ) {
		return STX_ERR_INVALID_PARAM;
	}

	*pp_pin = the->p_input_pin;

	the->p_input_pin->add_ref(the->p_input_pin);

	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_enum_output_pin
(STX_HANDLE h, s32* i_index, stx_base_pin** pp_pin )
{
	STX_MAP_THE(mpeg2_decoder);

	if( !i_index ) {
		return STX_ERR_INVALID_PARAM;
	}

	if( !pp_pin ) {
		*i_index = 1;
		return STX_OK;
	}

	if( *i_index != 0 ) {
		return STX_ERR_INVALID_PARAM;
	}

	*pp_pin = (stx_base_pin*)the->p_output_pin;

	the->p_output_pin->add_ref(the->p_output_pin);

	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_check_input_media_type
( STX_HANDLE h,stx_media_type* p_mtyp )
{
	stx_gid major_type;
	stx_gid sub_type;

	STX_MAP_THE(mpeg2_decoder);

	major_type = p_mtyp->get_type(p_mtyp);

	if(	! is_compatible_gid(major_type,MEDIATYPE_Video) ) {
		return STX_ERR_INVALID_PARAM;
	}

	sub_type = p_mtyp->get_subtype(p_mtyp);

	if(	!is_compatible_gid(sub_type,MEDIASUBTYPE_MPEG2_VIDEO) ){

		return STX_ERR_INVALID_PARAM;
	}

	{
		STX_VIDEOINFOHEADER2*	vd2;
		s32						i_size;
		STX_RESULT				i_err;

		i_err = p_mtyp->get_header(p_mtyp,&vd2,&i_size);
		if( STX_OK != i_err ) {
			return i_err;
		}

		if( i_size < sizeof(STX_VIDEOINFOHEADER2)) {
			return STX_ERR_INVALID_PARAM;
		}

		if( vd2->bmiHeader.biWidth == 0 || vd2->bmiHeader.biHeight == 0 ) {
			return STX_ERR_INVALID_PARAM;
		}
	}

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_check_output_media_type
( STX_HANDLE h,stx_media_type* p_mtyp )
{
	stx_gid				major_type;
	stx_gid				sub_type;

	STX_MAP_THE(mpeg2_decoder);

	major_type = p_mtyp->get_type(p_mtyp);

	if(	! is_compatible_gid(major_type,MEDIATYPE_Video) ) {
		return STX_ERR_INVALID_PARAM;
	}

	sub_type = p_mtyp->get_subtype(p_mtyp);

	if(	!is_compatible_gid(sub_type,MEDIASUBTYPE_LxVideoFrame) ) {
		return STX_ERR_INVALID_PARAM;
	}

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_set_input_media_type
( STX_HANDLE h, stx_media_type* p_media_type )
{

	STX_RESULT			i_err;
	stx_base_pin*		p_input_pin;

	//stx_gid				major_type;
	//stx_gid				sub_type;

	stx_base_filter*    h_flt;

	STX_MAP_THE(mpeg2_decoder);

	h_flt = &the->stx_base_filter_vt;


	/*initialize the m4v_dec internal buffers ??? */

	i_err = h_flt->check_input_media_type(h_flt,p_media_type);
	if( STX_OK != i_err ) {
		return i_err;
	}

	p_input_pin = the->p_input_pin;

	i_err = p_input_pin->set_media_type(p_input_pin,p_media_type);
	if( STX_OK != i_err ) {
		return i_err;
	}

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_set_output_media_type
( STX_HANDLE h, stx_media_type* p_media_type )
{
	STX_RESULT			i_err;
	stx_base_filter*    h_flt;
	void*				hdr;
	s32					i_size;
	stx_media_type*		p_mtype;
	stx_media_type*		p_mtype_in;

	STX_MAP_THE(mpeg2_decoder);

	h_flt = &the->stx_base_filter_vt;

	i_err = h_flt->check_output_media_type(h_flt,p_media_type);
	if( STX_OK != i_err ) {
		return i_err;
	}


	// if not use the LxVideoFrame, the output media type's the header
	// should be decided by decoder;

	// set output pin media type

	i_err = STX_FAIL;

	do{
		p_mtype_in = the->p_input_pin->get_media_type(the->p_input_pin);
		if( !p_mtype_in ) {
			break;
		}

		p_mtype = XCREATE(base_media_type,NULL,p_media_type);
		if( !p_mtype ) {
			break;
		}

		i_err = p_mtype_in->get_header(p_mtype_in,&hdr,&i_size);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = p_mtype->set_header(p_mtype,hdr,i_size);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = the->p_output_pin->set_media_type(the->p_output_pin,p_mtype);

	}while(FALSE);

	SAFE_XDELETE(p_mtype);
	SAFE_XDELETE(p_mtype_in);

	return i_err;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_new_segment( STX_HANDLE h)
{
	STX_MAP_THE(mpeg2_decoder);

	return STX_ERR_NOT_IMP;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_flush
(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	STX_MAP_THE(mpeg2_decoder);

	// reset decoder internal data
	stx_stack_reset(the->h_stack);
	the->b_subdec = FALSE;
	the->the2->nThrCount = 0;
	
	return the->p_output_pin->flush(the->p_output_pin,i_flag,h_sync);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_start
(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	STX_MAP_THE(mpeg2_decoder);

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_stop
(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	STX_MAP_THE(mpeg2_decoder);
	{
		video_decoder* const the2 = the->the2;

		// first should stop all the subtask;
		if( the2->g_nFrmDecoderNum > 1 ) {
			s32 i,j;
			for ( i = 0,j = 0; i < the2->g_nFrmDecoderNum ; i ++ ) {
				frame_decoder* const pctx = the2->ppFrameCtx[i];
				if( pctx->b_exit) {
					j ++;
				}
				else {
					stx_sync_source* const hssrc = pctx->h_ssrc;
					pctx->b_stop = TRUE;
					hssrc->xresume(hssrc,pctx->h_task);
				}
			}
			if( j < the2->g_nFrmDecoderNum ){
				return STX_WOUNLD_BLOCK;
			}
		}// if( the2->g_nFrmDecoderNum > 1 ) {

		return XCALL(stop,the->p_output_pin,i_flag,h_sync);

	}

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_receive
(
 STX_HANDLE			h,
 stx_base_pin*		h_pin, // which input pin;
 stx_media_data**	pp_mdat, // output media data;
 stx_sync_inf*		h_sync 
 )
{
	return STX_ERR_NOT_SUPPORT;
}



/***************************************************************************
STX_PURE STX_RESULT send_msg( STX_HANDLE h, stx_base_message* p_msg )
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_send_msg
( STX_HANDLE h, stx_base_message* p_msg )
{
	STX_RESULT			i_err;
	u32					i_type;

	STX_MAP_THE(mpeg2_decoder);

	i_err = dispatch_msg(h,p_msg);
	if( i_err < 0 || p_msg->is_msg_closed(p_msg) ) {
		return i_err;
	}

	i_type = p_msg->get_msg_type(p_msg);

	if( i_type & STX_MSG_TYPE_DOWNSTREAM && the->p_output_pin) {
		i_err = the->p_output_pin->send_msg(the->p_output_pin,p_msg);
	}
	else if( i_type & STX_MSG_TYPE_UPSTREAM && the->p_input_pin ) {
		i_err = the->p_input_pin->send_msg(the->p_input_pin,p_msg);
	}

	if( i_err < 0 || p_msg->is_msg_closed(p_msg) ) {
		return i_err;
	}

	return response_msg(h,p_msg);
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT on_pause( STX_HANDLE h, stx_base_message* p_msg )
{
	STX_MAP_THE(mpeg2_decoder);

	/* to do: add your msg control code here; */

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT on_resume(STX_HANDLE h, stx_base_message* p_msg )
{
	STX_MAP_THE(mpeg2_decoder);

	/* to do: add your msg control code here; */
	return STX_OK;
}

/***************************************************************************
RETURN VALUE: 
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT on_play(STX_HANDLE h,stx_base_message* p_msg )
{
	return STX_OK;
}

/***************************************************************************
RETURN VALUE: 
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT create_subtask(mpeg2_decoder* the)
{
	STX_RESULT				i_err;
	s32						i,i_max;

	video_decoder* const the2 = the->the2;

	i_err = STX_FAIL;

	do{

		the->h_mutex = stx_create_mutex(NULL,0,NULL);
		if( !the->h_mutex ) {
			break;
		}

		i_max = stx_get_cpu_num();
		if( the->iTaskNum ) {
 			if( the->iTaskNum <= i_max*2 ){
 				i_max = the->iTaskNum;
 			}
		}
		if( i_max < 1 ) {
			i_max = 1;
		}

		if( the->iTaskMode > 0 && i_max > 1 ){
			video_subdecode = mp_video_subdecode;
		}
		else{
			video_subdecode = mpeg2_video_subdecode;
		}

		// initialize the decode context;
		if( i_max > 1 ) {
			the2->g_nFrmDecoderNum = i_max;
		}
		else {
			the2->g_nFrmDecoderNum = 1;
			i_max = 1;
		}

		the2->notify = mpeg2_decoder_notify;
		the2->h_notify = the;

		the2->ppFrameCtx = (frame_decoder**)xmallocz(sizeof(frame_decoder*)*i_max);
		if( !the2->ppFrameCtx ) {
			break;
		}
		the2->h_subtask = (THEE*)xmallocz(sizeof(THEE)*i_max);
		if( !the2->h_subtask ) {
			break;
		}

		for( i = 0; i < i_max; i ++ ) {

			the2->ppFrameCtx[i] = create_frame_decoder(the2);
			if( !the2->ppFrameCtx[i] ) {
				break;
			}

		} // for( i = 0; i < i_max; i ++ ) {

		the2->ppFrameCtx[0]->b_main = TRUE;
		the2->ppFrameCtx[0]->ta = 100;


		if( i_max > 1 ) {

			i_err = the->h_ssrc->reg_subtask(the->h_ssrc,the->h_task,i_max, the2->h_subtask,0);
			if( STX_OK != i_err ) {
				break;
			}

			for( i = 0; i < i_max; i ++ ) {
				the2->ppFrameCtx[i]->tb = 500;
			}

			for( i = 0; i < i_max; i ++ ) {
				THEE const htk = the2->h_subtask[i];
				the2->ppFrameCtx[i]->h_task = htk;
				the2->ppFrameCtx[i]->h_ssrc = the->h_ssrc->task2ssrc(the->h_ssrc,htk);
				the->h_ssrc->reset_task(the->h_ssrc,htk,0,0);
			}

		} // if( i_max > 1 ) {

		i_err = STX_OK;

	}while(FALSE);

	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE void stop_decoder( mpeg2_decoder* the )
{
	video_decoder* const h_vdec = the->the2;

	if( h_vdec ) {

		close_mp_buffer(h_vdec);

		if( h_vdec->ppFrameCtx ) {

			s32 i;

			// close sub task handle;
			the->h_ssrc->unreg_subtask(the->h_ssrc,the->h_task);

			for( i = 0; i < h_vdec->g_nFrmDecoderNum; i ++ ) {
				if( h_vdec->ppFrameCtx[i] ){
					// close frame decoder;
					if( h_vdec->ppFrameCtx[i]) {
						close_frame_decoder(h_vdec->ppFrameCtx[i]);
					}
				}//if( h_vdec->ppFrameCtx[i] ){
			}// for( i = 0; i < h_vdec->g_nFrmDecoderNum; i ++ ) {

			stx_free(h_vdec->ppFrameCtx);
			h_vdec->ppFrameCtx = NULL;

		} // if( the->ppFrameCtx ) {

		if( h_vdec->h_subtask){
			stx_free(h_vdec->h_subtask);
		}

		mpeg2_video_decode_cleanup(h_vdec);

		xlivFree(h_vdec );

		the->the2  = NULL;

	} // if( h_vdec ) {

	if( the->h_mutex ) {
		stx_close_mutex(the->h_mutex);
		the->h_mutex = NULL;
	}

}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT on_stop(STX_HANDLE h, stx_base_message* p_msg )
{
	STX_MAP_THE(mpeg2_decoder);

	/* to do: add your msg control code here; */
	stop_decoder(the);

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_ENTRY STX_RESULT 
at_BreakPin(STX_HANDLE h, stx_base_message* p_msg )
{
	STX_MAP_THE(mpeg2_decoder);

	if( the->p_input_pin ) {
		the->p_input_pin->break_connect(the->p_input_pin);
	}

	if( the->p_output_pin ) {
		the->p_output_pin->break_connect(the->p_output_pin);
	}

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT 
at_play(STX_HANDLE h, stx_base_message* p_msg )
{
	STX_MAP_THE(mpeg2_decoder);

	/* to do: add your msg control code here; */


	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT 
at_stop(STX_HANDLE h, stx_base_message* p_msg )
{
	STX_MAP_THE(mpeg2_decoder);

	/* to do: add your msg control code here; */


	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT 
at_pause( STX_HANDLE h, stx_base_message* p_msg )
{
	STX_MAP_THE(mpeg2_decoder);

	/* to do: add your msg control code here; */


	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT 
at_resume(STX_HANDLE h, stx_base_message* p_msg )
{
	STX_MAP_THE(mpeg2_decoder);

	/* to do: add your msg control code here; */

	return STX_OK;
}


