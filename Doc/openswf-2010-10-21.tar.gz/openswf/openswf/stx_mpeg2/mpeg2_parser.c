/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-11
***************************************************************************/


#include "mpeg2_parser.h"

#include "stx_io.h"
#include "stx_io_stream.h"
#include "stx_os.h"
#include "stx_mem.h"
#include "stx_debug.h"

#include "stx_cpuid.h"


#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API_IMP
CREATE_STX_COM(stx_stream_parser,STX_IID_StreamParser,mpeg2_parser);


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_COM_BEGIN(mpeg2_parser);
/**/STX_PUBLIC(stx_stream_parser)
/**/STX_COM_DATA_DEFAULT(stx_stream_parser)
/**/stx_xio*	h_stream;
/**/b32			b_sequence_header;
/**/b32			b_have_header;
/**/u32			i_header;
/**/b32			b_start;
STX_COM_END();

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_COM_FUNC_DECL_DEFAULT(stx_stream_parser,stx_stream_parser_vt);
STX_COM_FUNCIMP_DEFAULT(mpeg2_parser,stx_stream_parser,stx_stream_parser_vt);


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT	combine_init(mpeg2_parser* the);
STX_PRIVATE void		combine_cleanup(mpeg2_parser* the);



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_COM_MAP_BEGIN(mpeg2_parser)
/**/STX_COM_MAP_ITEM(STX_IID_StreamParser)
STX_COM_MAP_END()

STX_NEW_BEGIN(mpeg2_parser)
{
	STX_SET_THE(stx_stream_parser);
	STX_COM_NEW_DEFAULT(stx_stream_parser,the->stx_stream_parser_vt,stx_stream_parser_vt,
		DEFAULT_CODE,DEFAULT_CODE,DEFAULT_CODE);

	if( STX_OK != combine_init(the) ) {
		break;
	}

}
STX_NEW_END()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_DELETE_BEGIN(mpeg2_parser)
{
	//
	combine_cleanup(the);

	STX_COM_DELETE_DEFAULT(stx_stream_parser);
}
STX_DELETE_END
(
	STX_COM_DELETE_BEGIN(stx_stream_parser)
	,
	STX_COM_DELETE_END(stx_stream_parser)
)

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_QUERY_BEGIN(mpeg2_parser)
{
	STX_COM_QUERY_DEFAULT(stx_stream_parser,the->stx_stream_parser_vt);
}
STX_QUERY_END()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT combine_init(mpeg2_parser* the)
{
	the->h_stream = XCREATE(stx_io_stream,NULL);
	if( !the->h_stream ) {
		return STX_FAIL;
	}
	stx_stream_parser_vt_xxx_reset(&the->stx_stream_parser_vt);
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE void combine_cleanup(mpeg2_parser* the)
{
	if( the->h_stream ) {
		the->h_stream->close(the->h_stream);
		the->h_stream = NULL;
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE void 
stx_stream_parser_vt_xxx_reset(STX_HANDLE h)
{
	STX_MAP_THE(mpeg2_parser);
	the->h_stream->clear(the->h_stream);
	the->b_sequence_header = FALSE;
	the->b_have_header = FALSE;
	the->b_start = FALSE;
	the->i_header = -1;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE void 
stx_stream_parser_vt_xxx_flush(STX_HANDLE h)
{
	STX_MAP_THE(mpeg2_parser);
	the->h_stream->clear(the->h_stream);
	the->b_have_header = FALSE;
	the->b_start = FALSE;
	the->i_header = -1;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_stream_parser_vt_xxx_get_data
(STX_HANDLE h,stx_media_data* p_mdat)
{
	STX_RESULT		i_err;
	stx_io_op_param	inf;
	u8*				buf;
	size_t			i_size;

	STX_MAP_THE(mpeg2_parser);

	i_err = the->h_stream->get(the->h_stream,STX_IO_READ_P,&inf);

	if( STX_OK != i_err ) {
		return STX_FAIL;
	}

	i_size = p_mdat->get_buf(p_mdat,&buf);
	if( i_size < inf.i_available_data ) {
		i_err = p_mdat->resize(p_mdat,(size_t)inf.i_available_data);
	}

	i_err = p_mdat->get_data(p_mdat,&buf,&i_size);
	if( STX_OK != i_err ) {
		return STX_FAIL;
	}

	memcpy(buf,inf.buf,(size_t)inf.i_available_data);

	p_mdat->set_data(p_mdat,buf,(size_t)inf.i_available_data);

	the->h_stream->clear(the->h_stream);

	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_stream_parser_vt_xxx_parse
(
	STX_HANDLE		h, 
	u8*				buf, 
	size_t			i_len,
	u8**			buf_ptr
)
{
	STX_RESULT		i_err;
	s32				i,j;
	size_t			i_write;
	s32				i_data;
	u32				i_end_code;


	STX_MAP_THE(mpeg2_parser);

	if( !i_len ) {
		if( !the->b_have_header ) {
			return STX_OK;
		}
		i_end_code = 0xb7100000; // SEQUENCE_END_CODE
		buf = (u8*)&i_end_code;
		i_len = sizeof(u32);
	}//if( !i_len ) {


	i = 0;

	if(!the->b_have_header){

		for(i = 0; i<(s32)i_len; i++){

			the->i_header = (the->i_header<<8) | buf[i];

			if( 0x1b3 == the->i_header || (0x100 == the->i_header && the->b_sequence_header)){
				i++;
				the->b_have_header = TRUE;
				the->b_sequence_header = 0x1b3 == the->i_header;
				the->b_start = TRUE;
				break;

			}//if(0x100 == state && the->b_sequence_header ) {

		}//for(i=0; i<i_len; i++){

	}//if(!vop_found){

	if(!the->b_have_header){
		return STX_OK;
	}

	if( the->b_start ) {
		// save header; 
		the->b_start = FALSE;
		i_end_code = the->i_header;
		FAST_SWAP32(i_end_code,i_end_code);
		i_err = the->h_stream->write(the->h_stream,&i_end_code,4,&i_write);
		if( STX_OK != i_err ) {
			return i_err;
		}
		//xlog("state = %x\r\n",the->i_header);
	}


	for( j = i; j < (s32)i_len; j ++ ){

		the->i_header = (the->i_header<<8) | buf[j];

		if( 0x0100 == the->i_header || 0x01b3 == the->i_header || 0x01b7 == the->i_header ){

			i_data = j+1-i; // 

			if( i_data > 4 ) {

				// data 
				i_err = the->h_stream->write(the->h_stream,buf+i,i_data-4,&i_write);
				if( STX_OK != i_err ) {
					return i_err;
				}
			}

			*buf_ptr = buf + j + 1;

			the->b_start = TRUE;

			return STX_EOF;

		}//if( 0x01b3 ==  || 0x0100 ==  || 0x01b7 == ){

	}//for( j = i; j<i_len; j++){

	// frame end not found, write out all data;
	the->h_stream->write(the->h_stream,buf+i,i_len-i,&i_write);
	*buf_ptr = buf + i_len;

	return STX_OK;
}

