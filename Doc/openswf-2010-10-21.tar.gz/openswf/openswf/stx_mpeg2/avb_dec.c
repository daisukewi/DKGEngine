/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-11
***********************************************************************************/
#include "stdio.h"
#include "stdlib.h"
#include "fcntl.h"
#include "memory.h"
#include "string.h"
#include "assert.h"


#if defined (__WIN32_LIB)
#	include "time.h"
#	include "time.inl"
#else
#	include <time.h>
#endif /* #if defined (__WIN32_LIB) */


#include "stx_all.h"
#include "stx_sync_source.h"
#include "xdisk_loop.h"

#include "stx_avb.h"
#include "stx_audio_mixor.h"
#include "stx_cpuid.h"

#include "video/video_decoder.h"

#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif

enum avb_dec_status {
	em_avb_stop_task,
	em_avb_stop_flt,
	em_avb_stop_pin,
	em_avb_stop_io,
	em_avb_stop_msg,
};


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API_IMP 
CREATE_STX_COM(stx_base_com,STX_IID_BaseFilter,avb_decoder);



STX_INPUT_MEDIA_TYPE_MAP_BEGIN(avb_decoder)
/**/MEDIA_TYPE_MAP_ITEM(MEDIATYPE_File,MEDIASUBTYPE_Avb)
STX_INPUT_MEDIA_TYPE_MAP_END()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_OUTPUT_MEDIA_TYPE_MAP_BEGIN(avb_decoder)
/**/MEDIA_TYPE_MAP_ITEM(MEDIATYPE_Audio,MEDIASUBTYPE_PCM)
/**/MEDIA_TYPE_MAP_ITEM(MEDIATYPE_Video,MEDIASUBTYPE_LxVideoFrame)
STX_OUTPUT_MEDIA_TYPE_MAP_END()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
**************************************************************************/
STX_COM_BEGIN(avb_decoder);
/**/
/* base source; */
/**/STX_PUBLIC( stx_base_source )
/**/
/* base filter; */
/**/STX_PUBLIC( stx_base_filter)
/**/STX_COM_DATA_DEFAULT(stx_base_filter)
/**/
/* base graph control;*/
/**/STX_PUBLIC( stx_base_control)
/**/
/* base media information; */
/**/STX_PUBLIC( stx_media_info)
/**/
/* other members; */
/**/
/**/STX_HANDLE					h_task;
/**/STX_HANDLE					h_mutex;
/**/
/**/STX_HANDLE					m_hAvbFile;
/**/b32							m_bEOF;
/**/LxAvbHdr*					m_pAvbHdr;
/**/LxAvbAtomVidHdr*			m_pVdr;
/**/LxAvbAtomAudHdr*			m_pAdr;
/**/s32							m_nHdrBufSize;
/**/u8*							m_pHdrBuf;
/**/
/**/s64							m_nAudTimeCode;
/**/s32							m_nAudSampleBufSize;
/**/s32							m_nAudSampleSize;
/**/s32							m_nMaxAudSampleSize;
/**/u8*							m_pAudSampleBuf;
/**/u8*							m_pAudSampleBufPtr;
/**/
/**/s64							m_nVidTimeCode;
/**/s32							m_nVidSampleBufSize;
/**/s32							m_nVidSampleSize;
/**/u8*							m_pVidSampleBuf;
/**/u8*							m_pVidSampleBufPtr;
/**/
/**/sint32						i_max_pin;
/**/sint32						i_output_pin;
/**/sint32						i_audio_idx;
/**/sint32						i_video_idx;
/**/stx_base_pin**				pp_input_pin;
/**/stx_output_pin**			pp_output_pin;
/**/
/**/s32							i_video_buf_num;
/**/xloop*						p_video_loop;
/**/sint64						i_buffered_video_time;
/**/sint64						i_video_interval;
/**/
/**/char*						sz_file_name;
/**/sint64						i_file_size;
/**/sint64						i_file_time;
/**/sint64						i_start_time;
/**/sint64						i_start_sample_time;
/**/sint64						i_last_sample_time;
/**/
/**/StxAudioMixor*				hMixor;
/**/StxAudMixFx*				pFx;
/**/
/**/STX_HANDLE					h_stack;
/**/
STX_COM_END();


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_COM_FUNC_DECL_DEFAULT(stx_media_info,stx_media_info_vt);
STX_COM_FUNC_DECL_DEFAULT(stx_base_control,stx_base_control_vt);
STX_COM_FUNC_DECL_DEFAULT(stx_base_filter,stx_base_filter_vt);
STX_COM_FUNC_DECL_DEFAULT(stx_base_source,stx_base_source_vt);

STX_COM_FUNCIMP_DEFAULT(avb_decoder,stx_media_info,stx_media_info_vt);
STX_COM_FUNCIMP_DEFAULT(avb_decoder,stx_base_control,stx_base_control_vt);
STX_COM_FUNCIMP_DEFAULT(avb_decoder,stx_base_filter,stx_base_filter_vt);
STX_COM_FUNCIMP_DEFAULT(avb_decoder,stx_base_source,stx_base_source_vt);


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT on_load_stream(avb_decoder* the,STX_RESULT i_result );

STX_PRIVATE void release_output_pin(avb_decoder* the);

STX_PRIVATE STX_RESULT deliver_media_sample
(avb_decoder* the,s32 i_pin,stx_media_data* p_mdat,stx_sync_inf* h_sync);

STX_PRIVATE	STX_RESULT init_preload_stream(avb_decoder* the);
STX_PRIVATE	STX_RESULT release_preload_stream(avb_decoder* the);
STX_PRIVATE	STX_RESULT reset_all_preload_stream(avb_decoder* the);
STX_PRIVATE	STX_RESULT reset_preload_stream(xloop* p_loop, stx_output_pin* p_pin );

STX_PRIVATE STX_RESULT run_proc( avb_decoder* the , stx_sync_inf* h_sync );

STX_PRIVATE STX_RESULT	AvbFmtOpen(avb_decoder* the ,char* szFileName);
STX_PRIVATE void		AvbFmtClose(avb_decoder* the);
STX_PRIVATE STX_RESULT	init_video_outputpin(avb_decoder* the);
STX_PRIVATE STX_RESULT	init_audio_outputpin(avb_decoder* the);

STX_PRIVATE STX_RESULT 
AvbReadSample(avb_decoder* the,stx_media_data** pp_mdat,s32* i_idx);


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

/*{{{STX_MSG_ENTRY_DECLARE**************************************************/
/* to do : add msg proc entry  declaration here; */
/**/STX_MSG_ENTRY_DECLARE(on_play)
/**/STX_MSG_ENTRY_DECLARE(on_pause)
/**/STX_MSG_ENTRY_DECLARE(on_resume)
/**/STX_MSG_ENTRY_DECLARE(on_stop)
/**/STX_MSG_ENTRY_DECLARE(at_BreakPin)
/**/STX_MSG_ENTRY_DECLARE(at_play)
/**/STX_MSG_ENTRY_DECLARE(at_pause)
/**/STX_MSG_ENTRY_DECLARE(at_resume)
/**/STX_MSG_ENTRY_DECLARE(at_stop)
/**/STX_MSG_ENTRY_DECLARE(on_auto_stop)
/**/STX_MSG_ENTRY_DECLARE(on_app_stop)
/*}}}***********************************************************************/



/*{{{STX_BEGIN_MSG_MAP******************************************************/
STX_BEGIN_MSG_MAP(the_msg_data)
/* to do : add msg proc entry name here; */
/**/ON_STX_MSG(STX_MSG_Play,on_play)
/**/ON_STX_MSG(STX_MSG_Pause,on_pause)
/**/ON_STX_MSG(STX_MSG_Resume,on_resume)
/**/ON_STX_MSG(STX_MSG_Stop,on_stop)
/**/ON_STX_MSG(STX_MSG_AutoStop,on_auto_stop)
/**/ON_STX_MSG(STX_MSG_AppStop,on_app_stop)
STX_END_MSG_MAP
/*}}}***********************************************************************/


/*{{{STX_BEGIN_MSG_RESPONSE_MAP*********************************************/
STX_BEGIN_MSG_RESPONSE_MAP(the_msg_response)
/**//* to do : add msg process entry name here; */
/**/ON_STX_MSG(STX_MSG_Play,at_play)
/**/ON_STX_MSG(STX_MSG_Pause,at_pause)
/**/ON_STX_MSG(STX_MSG_Resume,at_resume)
/**/ON_STX_MSG(STX_MSG_Stop,at_stop)
/**/ON_STX_MSG(STX_MSG_BreakPin,at_BreakPin)
STX_END_MSG_RESPONSE_MAP
/*}}}***********************************************************************/


/*{{{STX_DISPATHCH_MSG_PROC*************************************************/
STX_DISPATCH_MSG_PROC( dispatch_msg,the_msg_data )
/*}}}***********************************************************************/


/*{{{STX_RESPONSE_MSG_PROC**************************************************/
STX_RESPONSE_MSG_PROC( response_msg,the_msg_response )
/*}}}***********************************************************************/




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_COM_MAP_BEGIN(avb_decoder)
/**/STX_COM_MAP_ITEM(STX_IID_FileSource)
/**/STX_COM_MAP_ITEM(STX_IID_BaseFilter)
/**/STX_COM_MAP_ITEM(STX_IID_BaseControl)
/**/STX_COM_MAP_ITEM(STX_IID_MediaInfo)
STX_COM_MAP_END()


STX_API_IMP	
STX_NEW_BEGIN(avb_decoder)
{
	s32 mmflag;

	STX_SET_THE(stx_base_source);
	STX_COM_NEW_DEFAULT(stx_base_source,the->stx_base_source_vt,stx_base_source_vt,
		STX_CLSID_AvbDecoder,STX_CATEGORY_FileSource,g_szStreamX_AvbDecoder);

	STX_SET_THE(stx_base_filter);
	STX_COM_NEW_DEFAULT(stx_base_filter,the->stx_base_filter_vt,stx_base_filter_vt,
		STX_CLSID_AvbDecoder,STX_CATEGORY_FileSource,g_szStreamX_AvbDecoder);

	STX_SET_THE(stx_base_control);
	STX_COM_NEW_DEFAULT(stx_base_control,the->stx_base_control_vt,stx_base_control_vt,
		STX_CLSID_AvbDecoder,STX_CATEGORY_FileSource,g_szStreamX_AvbDecoder);

	STX_SET_THE(stx_media_info);
	STX_COM_NEW_DEFAULT(stx_media_info,the->stx_media_info_vt,stx_media_info_vt,
		STX_CLSID_AvbDecoder,STX_CATEGORY_FileSource,g_szStreamX_AvbDecoder);

	the->h_mutex = stx_create_mutex(NULL,0,NULL);
	if( !the->h_mutex ) {
		break;
	}

	the->i_video_idx = -1;
	the->i_audio_idx = -1;

	mmflag = mm_support();
	the->hMixor = CreateStxAudioMixor(mmflag);
	if(!the->hMixor){
		break;
	}

	the->pFx = (StxAudMixFx*)xlivAlloc(sizeof(StxAudMixFx),TRUE,16);
	if(!the->pFx){
		break;
	}

}
STX_NEW_END()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE 
STX_QUERY_BEGIN(avb_decoder)
{
	STX_COM_QUERY_DEFAULT(stx_base_source,the->stx_base_source_vt);
	STX_COM_QUERY_DEFAULT(stx_base_filter,the->stx_base_filter_vt);
	STX_COM_QUERY_DEFAULT(stx_base_control,the->stx_base_control_vt);
	STX_COM_QUERY_DEFAULT(stx_media_info,the->stx_media_info_vt);
}
STX_QUERY_END()



/***************************************************************************
STX_PURE sint32 flv_release(STX_HANDLE h)
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE 
STX_DELETE_BEGIN(avb_decoder)
{
	/* todo : release object; */
	{
		stx_base_source* const src = &the->stx_base_source_vt;
		src->close_stream(src);
	}

	if( the->hMixor ) {
		the->hMixor->audiomixor_close(the->hMixor);
		the->hMixor = NULL;
	}

	if( the->pFx ) {
		xlivFree(the->pFx);
		the->pFx = NULL;
	}

	stx_close_mutex(the->h_mutex);

	if( the->h_stack ) {
		stx_stack_close(the->h_stack);
		the->h_stack = NULL;
	}

	STX_COM_DELETE_DEFAULT(stx_base_filter);
}
STX_DELETE_END
(
	STX_COM_DELETE_BEGIN(stx_base_filter)
	,
	STX_COM_DELETE_END(stx_base_filter)
)



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE void stx_base_source_vt_xxx_close_stream(STX_HANDLE h)
{
	STX_MAP_THE(avb_decoder);
	{
		AvbFmtClose(the);

		if( the->sz_file_name ) {
			stx_free( the->sz_file_name );
			the->sz_file_name = STX_NULL;
		}

		release_preload_stream(the);

		release_output_pin(the);

		the->em_status = emStxStatusInit; // ready -> init
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT AvbFmtOpen(avb_decoder* the,char* szFileName)
{
	STX_RESULT	i_err;
	s32			nSize; 

	i_err = AvbDecOpen(&the->m_hAvbFile,szFileName);
	if( STX_OK != i_err ) {
		return i_err;
	}

	nSize = AvbDecGetHdr(the->m_hAvbFile,NULL);
	if( nSize <= 0 ) {
		return STX_FAIL;
	}

	the->m_pAvbHdr = (LxAvbHdr*)xmallocz(nSize);
	AvbDecGetHdr(the->m_hAvbFile,the->m_pAvbHdr);

	nSize = AvbDecGetVidFmt(the->m_hAvbFile,NULL);
	if( nSize <= 0 ) {
		return STX_FAIL;
	}

	the->m_pVdr = (LxAvbAtomVidHdr*)xmallocz(nSize);
	AvbDecGetVidFmt(the->m_hAvbFile,the->m_pVdr);

	nSize = AvbDecGetAudFmt(the->m_hAvbFile,NULL);
	if( nSize <= 0 ) {
		return STX_FAIL;
	}

	the->m_pAdr = (LxAvbAtomAudHdr*)xmallocz(nSize);
	AvbDecGetAudFmt(the->m_hAvbFile,the->m_pAdr);

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE void AvbFmtClose(avb_decoder* the)
{
	if( the->m_hAvbFile ) {
		AvbDecClose(the->m_hAvbFile);
		the->m_hAvbFile = NULL;
	}

	if( the->m_pAvbHdr ) {
		stx_free(the->m_pAvbHdr);
		the->m_pAvbHdr = NULL;
	}

	if( the->m_pAdr ) {
		stx_free(the->m_pAdr);
		the->m_pAdr = NULL;
	}

	if( the->m_pVdr ) {
		stx_free(the->m_pVdr);
		the->m_pVdr = NULL;
	}

	if( the->m_pHdrBuf ) {
		stx_free(the->m_pHdrBuf);
		the->m_pHdrBuf = NULL;
	}

	if( the->m_pAudSampleBuf ) {
		xlivFree(the->m_pAudSampleBuf);
		the->m_pAudSampleBuf = NULL;
	}

	if( the->m_pVidSampleBuf ) {
		xlivFree(the->m_pVidSampleBuf);
		the->m_pVidSampleBuf = NULL;
	}
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT OutputAudioSample
(avb_decoder* the,s32 i_data_size,stx_media_data** pp_mdat,s32* i_idx)
{
	STX_RESULT			i_err;
	stx_output_pin*		pin;
	stx_media_data*		p_mdat;
	s32					idx;
	STX_WAVEFORMATEX*	wex;

	
	p_mdat = NULL;
	idx = the->i_audio_idx;

	pin = the->pp_output_pin[idx];

	if( pin->is_connected(pin,NULL) ) {

		i_err = pin->get_media_data(pin,&p_mdat,INFINITE);
		if( STX_OK != i_err ) {
			goto fail;
		}

		wex = &the->m_pAdr->adr;

		if( wex->nChannels == 1) {
			the->pFx->dwInput = STX_CT;
			the->pFx->wex.Format.nChannels = 1;
			the->pFx->wex.Format.nBlockAlign = 2;
			the->pFx->wex.Format.wBitsPerSample = 16;
		}
		else {
			the->pFx->dwInput = STX_LF|STX_RF;
			the->pFx->wex.Format.nChannels = 2;
			the->pFx->wex.Format.nBlockAlign = 4;
			the->pFx->wex.Format.wBitsPerSample = 16;
		}
		the->pFx->dwOutput = STX_LF|STX_RF;

		the->pFx->dwEffects = LX_AUDMIXFX_ZOOM;

		the->hMixor->audiomixor_transform(the->hMixor,
			the->m_pAudSampleBuf,i_data_size,p_mdat,the->pFx);

		p_mdat->set_time(p_mdat,the->m_nAudTimeCode,the->m_nAudTimeCode);
	}

	the->m_nAudSampleSize -= i_data_size;

	if( the->m_nAudSampleSize ) {
		memmove(the->m_pAudSampleBuf,
			the->m_pAudSampleBuf + i_data_size,
			the->m_nAudSampleSize );
	}

	*pp_mdat = p_mdat;
	*i_idx = idx;

	return STX_OK;

fail:
	if( p_mdat ) {
		pin->release_media_data(pin,p_mdat);
	}

	return i_err;

}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT 
AvbReadSample(avb_decoder* the,stx_media_data** pp_mdat,s32* i_idx)
{

resync:

	if( the->m_nAudSampleSize > the->m_nMaxAudSampleSize ) {

		return OutputAudioSample(the,the->m_nMaxAudSampleSize,pp_mdat,i_idx);
	}

	{
		STX_RESULT		i_err;
		s32				nHdrLen;
		s32				nFrmHdrLen;
		s32				nDataLen;

		LxAvbAtom		hdr;


		s32					idx;
		stx_media_data*		p_mdat;
		LxAvbAtom*			pHdrAtom;
		LxAvbFrmHdr*		pfh;

		if( the->m_bEOF ){

			if( the->m_nAudSampleSize ) {
				return OutputAudioSample(the,the->m_nAudSampleSize,pp_mdat,i_idx);
			}

			return STX_EOF;

		}
		else {


			i_err = AvbRead(the->m_hAvbFile,(u8*)&hdr,LXAVB_ATOM_HDR_SIZE()) ;
			if( STX_OK != i_err ){
				return i_err;
			}

// 			{
// 				char buf[64];
// 				binary_to_string(16,hdr.gid.data,buf);
// 				xlog("%s\r\n",buf);
// 			}

			if( IS_EQUAL_GID(hdr.gid,gidLxAvbStmLst) ) {

				the->m_bEOF = TRUE;

				if( the->m_nAudSampleSize ) {
					return OutputAudioSample(the,the->m_nAudSampleSize,pp_mdat,i_idx);
				}

				return STX_EOF;
			}

		}

		if( IS_EQUAL_GID(hdr.gid,gidLxAvbVidFrm) || IS_EQUAL_GID(hdr.gid,gidLxAvbAudFrm)) {
			nHdrLen = LxAvbAtomFrm_HdrSize() + LXAVB_ATOM_HDR_SIZE() ;             
		} 
		else if( IS_EQUAL_GID(hdr.gid,gidLxAvbStmFrm) ) {
			nHdrLen = LxAvbAtomStmFrm_HdrSize() + LXAVB_ATOM_HDR_SIZE();
		}

		// check header buffer size;
		if( the->m_nHdrBufSize < nHdrLen ) {
			if( the->m_pHdrBuf ) {
				stx_free(the->m_pHdrBuf);
			}
			the->m_pHdrBuf = (u8*)xmallocz(nHdrLen);
			if( !the->m_pHdrBuf) {
				return STX_FAIL;
			}
			the->m_nHdrBufSize = nHdrLen;
		}

		memcpy(the->m_pHdrBuf,&hdr,LXAVB_ATOM_HDR_SIZE());

		nFrmHdrLen = nHdrLen - LXAVB_ATOM_HDR_SIZE();

		i_err = AvbRead(the->m_hAvbFile,
			the->m_pHdrBuf + LXAVB_ATOM_HDR_SIZE(), nFrmHdrLen );
		if( STX_OK != i_err ){
			return i_err;
		}

		nDataLen = (s32)hdr.qwAtomSize - nFrmHdrLen;


		p_mdat = NULL;
		pHdrAtom = (LxAvbAtom*)the->m_pHdrBuf;

		pfh = (LxAvbFrmHdr*)( the->m_pHdrBuf + LXAVB_ATOM_HDR_SIZE() );

		if( IS_EQUAL_GID(gidLxAvbVidFrm,pHdrAtom->gid ) ) {

			VideoFrame*				pframe;
			STX_BITMAPINFOHEADER*	bmi;


			if( the->m_nVidSampleBufSize < nDataLen ) {
				if( the->m_pVidSampleBuf ) {
					xlivFree(the->m_pVidSampleBuf);
				}
				the->m_pVidSampleBuf = (u8*)xlivAlloc(nDataLen,TRUE,16);
				if( !the->m_pVidSampleBuf) {
					return STX_FAIL;
				}
				the->m_nVidSampleBufSize = nDataLen;
			}
			// next read the frame;
			i_err = AvbRead(the->m_hAvbFile,the->m_pVidSampleBuf,nDataLen);
			if( STX_OK != i_err ){
				return i_err;
			}
			the->m_nVidSampleSize = nDataLen; 		


			idx = the->i_video_idx;

			i_err = the->pp_output_pin[idx]->get_media_data(the->pp_output_pin[idx],
				&p_mdat,INFINITE);
			if( STX_OK != i_err ) {
				goto fail;
			}

			i_err = p_mdat->query_interf(p_mdat,STX_IID_LxVideoFrame,(void**)&pframe);
			if( STX_OK != i_err ) {
				goto fail;
			}
			SAFE_XDELETE(p_mdat);

			bmi = &the->m_pVdr->vdr.bmiHeader;

			i_err = vfrmAjustSurfaceSize(pframe,bmi->biWidth,bmi->biHeight,CHROMA420);
			if( STX_OK != i_err ) {
				goto fail;
			}

			pframe->nCodedPictureWidth = bmi->biWidth ;
			pframe->nCodedPictureHeight = bmi->biHeight;

			// fill the video frame attributes;
			pframe->PictureCodingType = I_TYPE;
			pframe->ChromaFormat = CHROMA420;
			pframe->RepeatDisplayTimes = 0;
			pframe->dwFmtFourCC = MKTAG('Y','V','1','2');
			pframe->dwDisplayWhr = bmi->biXPelsPerMeter;
			pframe->dwNvWhr = bmi->biXPelsPerMeter;
			vfrmSetFlags(pframe,0);
			vfrmSetDecoded(pframe,TRUE);    // = TRUE;
			vfrmSetDisplay(pframe,TRUE);    // bDisplay = 1;

			if( pfh->dwFlags & LXAVB_KEY_FRAME ) {
				the->m_nVidTimeCode = pfh->qwTimeCode;
			}
			else {
				the->m_nVidTimeCode += the->m_pVdr->vdr.AvgTimePerFrame;
			}

			p_mdat->set_time(p_mdat,the->m_nVidTimeCode,the->m_nVidTimeCode);

			pframe->PresentTimeStamp =  REFTIME2PTS(the->m_nVidTimeCode);

			//xlog("video time code = %d\r\n", REFTIME2MILISEC(pframe->PresentTimeStamp) );

			// copy data;
			{
				s32 i;

				u8 *src, *dst;

				src = the->m_pVidSampleBuf;
				dst = pframe->lpData[0];

				for( i = 0; i < bmi->biHeight; i ++ ) {
					memcpy(dst,src,bmi->biWidth);
					dst += pframe->nPitch[0];
					src += bmi->biWidth;
				}
				dst = pframe->lpData[2];
				for( i = 0; i < bmi->biHeight>>1; i ++ ) {
					memcpy(dst,src,bmi->biWidth>>1);
					dst += pframe->nPitch[2];
					src += bmi->biWidth>>1;
				}
				dst = pframe->lpData[1];
				for( i = 0; i < bmi->biHeight>>1; i ++ ) {
					memcpy(dst,src,bmi->biWidth>>1);
					dst += pframe->nPitch[1];
					src += bmi->biWidth>>1;
				}

			}

			*pp_mdat = p_mdat;
			*i_idx = idx;

		} 
		else if( IS_EQUAL_GID(gidLxAvbAudFrm,pHdrAtom->gid ) ){

			size_t				i_buf;
			size_t				i_data;
			u8*					buf;
			STX_WAVEFORMATEX*	wex;

			i_buf = nDataLen + the->m_nAudSampleSize;

			if( the->m_nAudSampleBufSize < (s32)i_buf ) {
				if( the->m_pAudSampleBuf ) {
					xlivFree(the->m_pAudSampleBuf);
				}
				the->m_pAudSampleBuf = (u8*)xlivAlloc(i_buf,TRUE,16);
				the->m_nAudSampleBufSize = i_buf;
			}

			// next read the frame;
			i_err = AvbRead(the->m_hAvbFile,the->m_pAudSampleBuf + the->m_nAudSampleSize,nDataLen);
			if( STX_OK != i_err ){
				return i_err;
			}
			the->m_nAudSampleSize += nDataLen; 	

			the->m_nAudTimeCode = pfh->qwTimeCode;

			goto resync;
			
		}
		else {
			assert(FALSE);
		}


		return STX_OK;


fail:
		if( p_mdat ) {
			the->pp_output_pin[idx]->release_media_data(the->pp_output_pin[idx],p_mdat);
		}

		return i_err;

	}


}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT init_audio_outputpin(avb_decoder* the)
{
	STX_RESULT					i_err;
	stx_media_data_allocator*	p_alloc;
	stx_media_type*				p_mtype;
	STX_WAVEFORMATEXTENSIBLE	wex;

	i_err = STX_FAIL;
	p_alloc = NULL;
	p_mtype = NULL;

	// create output pin;
	do{
		stx_output_pin* p;

		p =  XCREATE(output_pin,NULL);
		if( !p ) {
			break;
		}		
		the->pp_output_pin[the->i_audio_idx] = p;
		p->set_parent(p,(stx_base_plugin*)&the->stx_base_filter_vt);

		the->pp_input_pin[the->i_audio_idx] = XCREATE(stx_input_pin,NULL);
		if( !the->pp_input_pin[the->i_audio_idx]) {
			break;
		}
		XCALL(set_parent,the->pp_input_pin[the->i_audio_idx],(stx_base_plugin*)&the->stx_base_filter_vt);

		p_alloc = XCREATE(stx_base_alloc,NULL);
		if( !p_alloc ) {
			break;
		}

		i_err = p->set_mem_allocator(p,p_alloc);
		if( STX_OK != i_err ) {
			break;
		}

		// set header, WAVEFORMATEXTENSIBLE;
		p_mtype = XCREATE(base_media_type,NULL,NULL);
		if( !p_mtype ) {
			i_err = STX_FAIL;
			break;
		}
		p_mtype->set_type(p_mtype,MEDIATYPE_Audio);
		p_mtype->set_subtype(p_mtype,MEDIASUBTYPE_PCM);

		INIT_MEMBER(wex);
		wex.Format = the->m_pAdr->adr;
		wex.dwChannelMask = STX_LF|STX_RF;
		wex.Format.nChannels = 2;

		// reset the member value;
		wex.Format.nAvgBytesPerSec = wex.Format.nSamplesPerSec * 2;   
		
		/* block size of data */
		wex.Format.nBlockAlign = 4;  

		/* Number of bits per sample of mono data */
		wex.Format.wBitsPerSample = 16; 

		/* The count in bytes of the size of extra information (after cbSize) */
		wex.Format.cbSize = sizeof(STX_WAVEFORMATEXTENSIBLE);          
		
		i_err = p_mtype->set_header(p_mtype,&wex,sizeof(STX_WAVEFORMATEXTENSIBLE));
		if( STX_OK != i_err ) {
			break;
		}

		i_err = p->set_media_type(p,p_mtype);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = STX_OK;

	}while(FALSE);

	SAFE_XDELETE(p_mtype);// release
	SAFE_XDELETE(p_alloc);// decrease reference; 

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:stx_lxvidf_alloc_create
***************************************************************************/
STX_PRIVATE STX_RESULT init_video_outputpin(avb_decoder* the)
{
	STX_RESULT					i_err;
	stx_mda_alloc_base_param	prop;
	stx_mem_alloc_base*			palloc;
	stx_media_type*				pmtype;

	i_err = STX_FAIL;
	palloc = NULL;
	pmtype = NULL;

	do{

		stx_output_pin* p;
		
		p =  XCREATE(output_pin,NULL);
		if( !p ) {
			break;
		}		
		the->pp_output_pin[the->i_video_idx] = p;

		p->set_parent(p,(stx_base_plugin*)&the->stx_base_filter_vt);

		the->pp_input_pin[the->i_video_idx] = XCREATE(stx_input_pin,NULL);
		if( !the->pp_input_pin[the->i_video_idx]) {
			break;
		}
		XCALL(set_parent,the->pp_input_pin[the->i_video_idx],(stx_base_plugin*)&the->stx_base_filter_vt);


		palloc = XCREATE(vfrm_alloc,NULL);
		if( !palloc ) {
			break;
		}

		prop.i_mda_num = the->i_video_buf_num;
		prop.i_mda_size = 0;  // check at deliver time;

		i_err = palloc->set_param(palloc,&prop,sizeof(prop));

		if( STX_OK != i_err ) {
			break;
		}

		i_err = p->set_mem_allocator(p,palloc);
		if( STX_OK != i_err ) {
			break;
		}

		// set header, WAVEFORMATEXTENSIBLE;
		pmtype = XCREATE(base_media_type,NULL,NULL);
		if( !pmtype ) {
			i_err = STX_FAIL;
			break;
		}
		pmtype->set_type(pmtype,MEDIATYPE_Video);
		pmtype->set_subtype(pmtype,MEDIASUBTYPE_LxVideoFrame);

		i_err = pmtype->set_header(pmtype,&the->m_pVdr->vdr,VIDEOINFOHEADER2_size());
		if( STX_OK != i_err ) {
			break;
		}

		i_err = p->set_media_type(p,pmtype);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = STX_OK;

	}while(FALSE);

	SAFE_XDELETE( pmtype);// release
	SAFE_XDELETE( palloc);

	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
HTTP: use http stream io;
TCP: use tcp stream io;
UDP: use udp stream io;
else use local file stream io;
***************************************************************************/
STX_PURE STX_RESULT stx_base_source_vt_xxx_load_stream
(STX_HANDLE h, const char* sz_stream,stx_sync_inf* h_sync)
{
	STX_RESULT		i_err;

	STX_MAP_THE(avb_decoder);

	i_err = AvbFmtOpen(the,(char*)sz_stream);
	if( STX_OK != i_err ) {
		return i_err;
	}

	the->pp_input_pin = (stx_base_pin**)xmallocz(sizeof(void*)*2);
	if( !the->pp_input_pin ) {
		return STX_FAIL;
	}

	the->pp_output_pin = (stx_output_pin**)xmallocz(sizeof(void*)*2);
	if( !the->pp_output_pin ) {
		return STX_FAIL;
	}


	the->i_output_pin = 2;
	the->i_video_idx = 0;
	the->i_audio_idx = 1;

	the->i_video_buf_num = (s32)( MILISEC2REFTIME(1000) / the->m_pVdr->vdr.AvgTimePerFrame ); 

	// pcm 16 bit, stero output;
	the->m_nMaxAudSampleSize = 
		the->m_pAdr->adr.nSamplesPerSec * the->m_pAdr->adr.nBlockAlign * MAX_AUDIO_SMAPLE_TIME / 1000;  

	the->m_nAudSampleSize = 0;

	i_err = init_video_outputpin(the);
	if( STX_OK != i_err ) {
		return i_err;
	}

	i_err = init_audio_outputpin(the);
	if( STX_OK != i_err ) {
		return i_err;
	}

	// init internal buffer;
	i_err = init_preload_stream(the);
	if( STX_OK != i_err ) {
		return i_err;
	}

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_run
( STX_HANDLE h , stx_sync_inf* h_sync )
{
	STX_RESULT		i_err;

	STX_MAP_THE(avb_decoder);

	stx_waitfor_mutex(the->h_mutex,INFINITE);

	i_err = run_proc(the,h_sync);

	stx_release_mutex(the->h_mutex);

	return i_err;

}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT run_proc( avb_decoder* the , stx_sync_inf* h_sync )
{
	s32					i;
	STX_RESULT			i_err;
	stx_media_data*		p_mdat;
	s32					i_idx;


	i_err = AvbReadSample(the,&p_mdat,&i_idx);
	if( STX_EOF == i_err ) {
		return deliver_media_sample(the,0,NULL,h_sync);
	}

	if( STX_OK != i_err ) {
		return i_err;
	}

	if( !p_mdat ) {
		RESET_XENTRY(h_sync,&the->stx_base_filter_vt);
		return STX_OK; // continue;
	}

	return deliver_media_sample(the,i_idx,p_mdat,h_sync);

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_enum_input_pin
(STX_HANDLE h, sint32* i_idx, stx_base_pin** pp_pin )
{
	STX_MAP_THE(avb_decoder);

	return 0;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_enum_output_pin
(STX_HANDLE h,sint32* i_idx,stx_base_pin** pp_pin )
{
	STX_MAP_THE(avb_decoder);

	if( !i_idx ) {
		return STX_ERR_INVALID_PARAM;
	}

	if( !pp_pin ) {
		*i_idx = the->i_output_pin;
		return STX_OK;
	}

	{
		s32 idx = *i_idx;

		if( idx < 0 || idx >= the->i_output_pin ) {
			return STX_ERR_INVALID_PARAM;
		}

		{
			stx_output_pin*p = the->pp_output_pin[idx];
			p->add_ref(p);
			*pp_pin = (stx_base_pin *)p;
		}// block

		return STX_OK;
	}// block
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_check_input_media_type
(STX_HANDLE h,stx_media_type* p_mdt)
{
	STX_MAP_THE(avb_decoder);
	{
		STX_RESULT		i_err;
		s32				i;
		s32				n;
		stx_gid			type;
		stx_gid			sub_type;

		stx_media_type_inf	inf;

		stx_base_filter* const h_flt = &the->stx_base_filter_vt;

		type = p_mdt->get_type(p_mdt);
		sub_type = p_mdt->get_subtype(p_mdt);

		i_err = h_flt->enum_input_media_type(h_flt,&n,NULL);
		if( STX_OK != i_err ) {
			return i_err;
		}

		for( i = 0; i < n; i ++ ) {
			i_err = h_flt->enum_input_media_type(h_flt,&i,&inf);
			if( STX_OK != i_err ) {
				return i_err;
			}

			if( !IS_EQUAL_GID(type,inf.major_type) ) {
				continue;
			}

			if( !IS_EQUAL_GID(sub_type,inf.sub_type) ) {
				continue;
			}

			return STX_OK;
		}

	}

	return STX_ERR_NOT_SUPPORT;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_check_output_media_type
(STX_HANDLE h,stx_media_type* p_mdt)
{
	STX_MAP_THE(avb_decoder);

	return STX_ERR_NOT_SUPPORT;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_set_input_media_type
(STX_HANDLE h, stx_media_type* p_media_type )
{
	STX_MAP_THE(avb_decoder);
	{
		STX_RESULT		i_err;

		stx_base_filter* const h_flt = &the->stx_base_filter_vt;

		i_err = h_flt->check_input_media_type(h_flt,p_media_type);
		if( STX_OK != i_err ) {
			return STX_FAIL;
		}

		return STX_OK;
	}

	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_set_output_media_type
(STX_HANDLE h, stx_media_type* p_media_type )
{
	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_base_filter_vt_xxx_new_segment( STX_HANDLE h)
{
	STX_MAP_THE(avb_decoder);

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_start
(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	STX_MAP_THE(avb_decoder);

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_stop
(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	STX_RESULT				i_err;
	s32						i;
	size_t*					p_status;
	enum avb_dec_status		i_status;

	STX_MAP_THE(avb_decoder);

	p_status = stx_stack_pop(the->h_stack);
	if( !p_status ) {
		return STX_FAIL;
	}

	i_status = *p_status;

	if( em_avb_stop_pin == i_status ) {

		p_status = stx_stack_pop(the->h_stack);
		if( !p_status ) {
			return STX_FAIL;
		}
		i = *p_status;

		if( i == the->i_video_idx ) {

			stx_output_pin* p = the->pp_output_pin[i];

			if( p->is_connected(p,NULL) ) {
				i_err = p->stop(p,i_flag,h_sync);
				if( i_err != STX_OK ) {
					stx_stack_push(the->h_stack,i);
					stx_stack_push(the->h_stack,em_avb_stop_pin);
					return i_err;
				}
			}//if( p->is_connected(p,NULL) ) {

			i = the->i_audio_idx;
 
		} // if( i == the->i_video_idx ) {

		if( i == the->i_audio_idx ) {

			stx_output_pin* p = the->pp_output_pin[i];

			if( p->is_connected(p,NULL) ) {
				i_err = p->stop(p,i_flag,h_sync);
				if( i_err != STX_OK ) {
					stx_stack_push(the->h_stack,i);
					stx_stack_push(the->h_stack,em_avb_stop_pin);
					return i_err;
				}
			}//if( p->is_connected(p,NULL) ) {

		} // if( i == the->i_audio_idx ) {

	}// if( em_flv_stop_flush_pin == i_status ) {

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_flush
(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	STX_MAP_THE(avb_decoder);

	the->hMixor->audiomixor_reset(the->hMixor);

	{
		STX_RESULT	i_err;
		s32			i;

		for( i = 0; i < the->i_output_pin; i ++ ) {
			stx_output_pin* pin = the->pp_output_pin[i];
			i_err = pin->flush(pin,i_flag,h_sync);
			if( STX_OK != i_err ) {
				return i_err;
			}
		}

		return STX_OK;
	}
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_receive
(
 STX_HANDLE			h,
 stx_base_pin*		h_pin, // which input pin;
 stx_media_data**	pp_mdat, // output media data;
 stx_sync_inf*		h_sync 
 )
{
	return STX_ERR_NOT_SUPPORT;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_deliver
(
	STX_HANDLE			h,
	stx_base_pin*		h_pin, // which input pin;
	stx_media_data*		p_mdat, // output media data;
	stx_sync_inf*		h_sync 
)
{
	stx_output_pin* pin = (stx_output_pin*)h_sync->h_data;
//	xlog("deliver,*pp_mdat = %x\r\n",*pp_mdat);
	return pin->deliver(pin,p_mdat,h_sync);
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_transform
(
 /**/STX_HANDLE			h, 
 /**/stx_base_pin*		h_pin, 
 /**/stx_media_data*	p_mdat, 
 /**/stx_base_pin**		hh_pin,
 /**/stx_media_data**	pp_mdat, 
 /**/stx_sync_inf*		h_sync
 )
{
	return STX_ECHO;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_get_property
(STX_HANDLE h,stx_xio* h_xio)
{
	return STX_ERR_NOT_SUPPORT;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_set_property
(STX_HANDLE h,stx_xio* h_xio)
{
	return STX_ERR_NOT_SUPPORT;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_send_msg
( STX_HANDLE h, stx_base_message* p_msg )
{
	STX_RESULT	i_err;
	u32			i_type;
	s32			i;

	STX_MAP_THE(avb_decoder);

	do{

		i_err = dispatch_msg(h,p_msg);
		if( i_err < 0 || p_msg->is_msg_closed(p_msg)) {
			break;
		}

		i_type = p_msg->get_msg_type(p_msg);

		if( i_type & STX_MSG_TYPE_DOWNSTREAM ) {

			for( i = 0; i < the->i_output_pin; i ++ ) {
				stx_output_pin* p = the->pp_output_pin[i];
				if( p->is_connected(p,NULL) ) {
					i_err = p->send_msg(p,p_msg);
					if( i_err < 0 || p_msg->is_msg_closed(p_msg)) {
						break;
					}
				}
			} // for( i = 0; i < the->i_output_pin; i ++ ) {
		}
		else if( i_type & STX_MSG_TYPE_UPSTREAM ) {
			stx_base_plugin* h_gph = the->p_parent;
			i_err = h_gph->send_msg(h_gph,p_msg);
		}

		if( i_err < 0 || p_msg->is_msg_closed(p_msg)) {
			break;
		}

		i_err = response_msg(h,p_msg);
		if( i_err < 0 || p_msg->is_msg_closed(p_msg)) {
			break;
		}

		i_err = STX_OK;

	}while(FALSE);

	return i_err;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_source_vt_xxx_set_pos(STX_HANDLE h,sint64 i_pos)
{
	STX_RESULT i_err;

	STX_MAP_THE(avb_decoder);

	i_err = STX_FAIL;


	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_source_vt_xxx_get_pos(STX_HANDLE h,sint64 *i_pos)
{
	STX_RESULT i_err;

	STX_MAP_THE(avb_decoder);

	i_err = STX_FAIL;


	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_source_vt_xxx_get_size(STX_HANDLE h,sint64 *i_size)
{
	STX_RESULT i_err;

	STX_MAP_THE(avb_decoder);

	i_err = STX_FAIL;


	return i_err;
}



/* control; */
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_PURE STX_RESULT stx_base_control_vt_xxx_get_caps
(STX_HANDLE h,stx_xio* h_xio)
{
	STX_MAP_THE(avb_decoder);
	{

		STX_RESULT i_err;
		stx_xini*  h_xini;
		STX_HANDLE h_key;

		i_err = STX_FAIL;
		h_xini = NULL;

		do{

			i_err = stx_ini_create(NULL,h_xio,STX_INI_READ_WRITE|STX_INI_NO_COMMENT,0,&h_xini);
			if(STX_INI_OK != i_err ) {
				break;
			}

			i_err = h_xini->create_key(h_xini,NULL,(char*)g_szCtlCaps_play_stop,(char*)g_szTrue,&h_key);
			if(STX_INI_OK != i_err ) {
				break;
			}

			i_err = h_xini->create_key(h_xini,NULL,(char*)g_szCtlCaps_pause_resume,(char*)g_szTrue,&h_key);
			if(STX_INI_OK != i_err ) {
				break;
			}

			i_err = STX_OK;

		}while(FALSE);

		if( h_xini ) {
			h_xini->close(h_xini);
		}

		return i_err;
	}
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_get_status
(STX_HANDLE h,u32* i_status)
{
	STX_MAP_THE(avb_decoder);

	*i_status = the->em_status;

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_play(STX_HANDLE h)
{
	STX_RESULT			i_err;
	stx_base_plugin*    plug;

	STX_MAP_THE(avb_decoder);

	plug = (stx_base_plugin*)&the->stx_base_filter_vt;

	// first send play message;
	{
		stx_base_message*	p_msg;
		stx_msg_cnt*		cnt;


		p_msg =  XCREATE(base_msg,NULL,NULL);
		if( !p_msg) {
			return STX_FAIL;
		}

		p_msg->set_msg_type(p_msg,STX_MSG_TYPE_DOWNSTREAM);

		do{

			cnt = p_msg->get_msg_cnt(p_msg);
			cnt->msg_gid = STX_MSG_Play;
			i_err = plug->send_msg(plug,p_msg);
			if( i_err < 0 ) {
				break;
			}
			i_err = STX_OK;

		}while(FALSE);

		SAFE_XDELETE(p_msg);

		if( STX_OK != i_err ) {
			return i_err;
		}

	} //

	i_err = the->h_ssrc->reg_task(the->h_ssrc,&the->h_task,plug,TASK_NORMAL);
	if( STX_OK != i_err ) {
		return i_err;
	}

	the->em_status = emStxStatusPlay;
	// active ssrc handle;
	the->h_ssrc->reset_task(the->h_ssrc,the->h_task,0,0);

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_pause(STX_HANDLE h)
{
	// first send pause message;
	STX_RESULT			i_err;
	stx_base_filter*    p_flt;

	STX_MAP_THE(avb_decoder);

	stx_waitfor_mutex(the->h_mutex,INFINITE);

	do{
		i_err = STX_OK;

		if( emStxStatusPause != the->em_status ){
			i_err = STX_WOUNLD_BLOCK;
			break;
		}

		// send pause message;
		{
			stx_base_message*	p_msg;
			stx_msg_cnt*		cnt;

			p_msg=  XCREATE(base_msg,NULL,NULL);
			if( !p_msg) {
				i_err = STX_FAIL;
				break;
			}

			p_msg->set_msg_type(p_msg,STX_MSG_TYPE_DOWNSTREAM);

			cnt = p_msg->get_msg_cnt(p_msg);
			cnt->msg_gid = STX_MSG_Pause;
			p_flt = &the->stx_base_filter_vt;
			i_err = p_flt->send_msg(p_flt,p_msg);
			if( i_err < 0 ) {
				break;
			}

			SAFE_XDELETE(p_msg);

			i_err = STX_OK;

		} // block;

	}while(FALSE);

	stx_release_mutex(the->h_mutex);

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_resume(STX_HANDLE h)
{
	// first send pause message;
	STX_RESULT			i_err;
	stx_base_filter*    p_flt;

	STX_MAP_THE(avb_decoder);

	stx_waitfor_mutex(the->h_mutex,INFINITE);

	do{

		if( emStxStatusPause != the->em_status ){
			i_err = STX_ERR_OBJ_STATUS;
			break;
		}

// 		the->b_pause = FALSE;

		// send resume message;
		{
			stx_base_message*	p_msg;
			stx_msg_cnt*		cnt;

			p_msg=  XCREATE(base_msg,NULL,NULL);
			if( !p_msg) {
				i_err = STX_FAIL;
				break;
			}

			p_msg->set_msg_type(p_msg,STX_MSG_TYPE_DOWNSTREAM);

			cnt = p_msg->get_msg_cnt(p_msg);
			cnt->msg_gid = STX_MSG_Resume;
			p_flt = &the->stx_base_filter_vt;
			i_err = p_flt->send_msg(p_flt,p_msg);
			if( i_err < 0 ) {
				break;
			}

			SAFE_XDELETE(p_msg);

			i_err = STX_OK;

		} // block;

		the->em_status = emStxStatusPlay;

	}while(FALSE);

	stx_release_mutex(the->h_mutex);

	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_set
(STX_HANDLE h,u32 i_flag,size_t i_set)
{
	STX_MAP_THE(avb_decoder);
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_stop(STX_HANDLE h)
{
	STX_RESULT				i_err;
	stx_base_filter*		p_flt;

	enum avb_dec_status		i_status;
	size_t*					p_status;

	STX_MAP_THE(avb_decoder);

	stx_waitfor_mutex(the->h_mutex,INFINITE);

	if( !the->h_stack ) {

		the->h_stack = stx_stack_create();
		if(!the->h_stack ) {
			return STX_FAIL;
		}
		XCALL(set_task_events,the->h_ssrc,the->h_task,ev_stop);
		stx_stack_push(the->h_stack,em_avb_stop_task);

		return STX_WOUNLD_BLOCK;

	} //if( !the->h_stack ) {

	p_flt = &the->stx_base_filter_vt;

	p_status = stx_stack_pop(the->h_stack);
	if( !p_status ) {
		return STX_FAIL;
	}

	i_status = *p_status;


	do{
		i_err = STX_OK;

		if( em_avb_stop_task == i_status ) {

			if( emStxStatusStop != the->em_status ){
				stx_stack_push(the->h_stack,em_avb_stop_task);
				i_err = STX_WOUNLD_BLOCK;
				break;
			}

			i_status = em_avb_stop_flt;

			stx_stack_push(the->h_stack,0);
			stx_stack_push(the->h_stack,em_avb_stop_pin);

		} // if( em_flv_stop_task == i_status ) {

		// must be emStxStatusStop

		// stop data;
		if( em_avb_stop_flt == i_status ) {

			stx_sync_inf sync_inf = {0};

			i_err = p_flt->stop(p_flt,0,&sync_inf);
			if( STX_OK != i_err ) {
				stx_stack_push(the->h_stack,em_avb_stop_flt);
				return i_err;
			}

		} // if( em_avb_stop_data == i_status ) {


		{

			stx_base_message*	p_msg = NULL;
			stx_msg_cnt*		cnt;

			// unreg ssrc handle;
			the->h_ssrc->unreg_task(the->h_ssrc,the->h_task);

			// send stop message;
			i_err = STX_FAIL;
			p_msg=  XCREATE(base_msg,NULL,NULL);
			if( !p_msg) {
				break;
			}

			p_msg->set_msg_type(p_msg,STX_MSG_TYPE_DOWNSTREAM);

			cnt = p_msg->get_msg_cnt(p_msg);
			cnt->msg_gid = STX_MSG_Stop;
			i_err = p_flt->send_msg(p_flt,p_msg);
			SAFE_XDELETE(p_msg);
			if( i_err < 0 ) {
				break;
			}

			the->em_status = emStxStatusInit;

			stx_stack_close(the->h_stack);
			the->h_stack = NULL;
			i_err = STX_OK;

		} // 


	}while(FALSE);

	stx_release_mutex(the->h_mutex);

	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_next(STX_HANDLE h)
{
	STX_RESULT i_err;

	STX_MAP_THE(avb_decoder);

	i_err = STX_FAIL;


	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_prev(STX_HANDLE h)
{
	STX_RESULT i_err;

	STX_MAP_THE(avb_decoder);

	i_err = STX_FAIL;


	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_step(STX_HANDLE h)
{
	STX_RESULT i_err;

	STX_MAP_THE(avb_decoder);

	i_err = STX_FAIL;

	return i_err;
}

/* media info; */
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_media_info_vt_xxx_get_desc
(STX_HANDLE h, sint32* i_len, char** sz_desc )
{
	STX_RESULT i_err;

	STX_MAP_THE(avb_decoder);

	i_err = STX_FAIL;


	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_media_info_vt_xxx_get_total_time
(STX_HANDLE h,sint64 *i_time)
{
	STX_MAP_THE(avb_decoder);

	*i_time = the->i_file_time;

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_media_info_vt_xxx_get_statistic
(STX_HANDLE h,s32 * i_size,char ** pp_sz )
{
	return STX_ERR_NOT_IMP;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_media_info_vt_xxx_get_current_time
(STX_HANDLE h,sint64 *i_time)
{
	STX_RESULT i_err;

	STX_MAP_THE(avb_decoder);

	i_err = STX_FAIL;


	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_media_info_vt_xxx_time_to_pos
(STX_HANDLE h,sint64 i_time,offset_t * pos )
{
	STX_RESULT i_err;

	STX_MAP_THE(avb_decoder);

	i_err = STX_FAIL;


	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_media_info_vt_xxx_pos_to_time
(STX_HANDLE h, offset_t pos ,sint64* i_time )
{
	STX_RESULT i_err;

	STX_MAP_THE(avb_decoder);

	i_err = STX_FAIL;


	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT on_play(STX_HANDLE h, stx_base_message* p_msg )
{
	STX_MAP_THE(avb_decoder);



	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT on_stop(STX_HANDLE h,stx_base_message* p_msg)
{	
	STX_MAP_THE(avb_decoder);



	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_ENTRY STX_RESULT at_BreakPin(STX_HANDLE h, stx_base_message* p_msg )
{
	STX_MAP_THE(avb_decoder);
	{
		s32 i;
		for( i = 0; i < the->i_output_pin; i ++ ) {
			stx_output_pin* pin = the->pp_output_pin[i];
			if( pin ) {
				pin->break_connect(pin);
			}
		}
	}

	return STX_OK;
}


/***************************************************************************
STX_MSG_PROC STX_RESULT on_pause(STX_HANDLE h, stx_base_message* p_msg )
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT on_pause(STX_HANDLE h, stx_base_message* p_msg)
{
	STX_MAP_THE(avb_decoder);

	return STX_OK;
}

/***************************************************************************
STX_MSG_PROC STX_RESULT on_resume( STX_HANDLE h, stx_base_message* p_msg )
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT on_resume( STX_HANDLE h, stx_base_message* p_msg )
{
	STX_MAP_THE(avb_decoder);

	return STX_OK;
}


/***************************************************************************
STX_MSG_PROC STX_RESULT at_play(STX_HANDLE h, stx_base_message* p_msg )
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT at_play(STX_HANDLE h, stx_base_message* p_msg )
{
	STX_MAP_THE(avb_decoder);

	// source filter status is not correct ;
	return STX_OK;
}

/***************************************************************************
STX_MSG_PROC STX_RESULT at_stop(STX_HANDLE h,stx_base_message* p_msg)
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT at_stop(STX_HANDLE h,stx_base_message* p_msg )
{
	STX_MAP_THE(avb_decoder);
	{
		stx_base_source* h_src;

		h_src = &the->stx_base_source_vt;
		h_src->close_stream(h_src);

		return STX_OK;
	}
}



/***************************************************************************
STX_MSG_PROC STX_RESULT at_pause(STX_HANDLE h, stx_base_message* p_msg )
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT at_pause(STX_HANDLE h, stx_base_message* p_msg )
{
	STX_MAP_THE(avb_decoder);

	// source filter status is not correct ;
	return STX_OK;
}


/***************************************************************************
STX_MSG_PROC STX_RESULT at_resume( STX_HANDLE h, stx_base_message* p_msg )
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT at_resume( STX_HANDLE h, stx_base_message* p_msg )
{
	STX_MAP_THE(avb_decoder);

	return STX_OK;
}






/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE void release_output_pin(avb_decoder* the)
{
	s32 i;

	if( the->pp_output_pin ) {

		stx_base_message* h_msg;

		h_msg =  XCREATE(base_msg,NULL,NULL);
		h_msg->set_msg_type(h_msg,STX_MSG_TYPE_DOWNSTREAM);
		h_msg->get_msg_cnt(h_msg)->msg_gid = STX_MSG_BreakPin;
		stx_base_filter_vt_plug_xxx_send_msg(&the->stx_base_filter_vt,h_msg);
		SAFE_XDELETE(h_msg);

		for( i = 0; i < the->i_output_pin; i ++ ) {
			SAFE_XDELETE(the->pp_input_pin[i]);
			SAFE_XDELETE(the->pp_output_pin[i]);
		}// for( i = 0; i < the->i_output_pin; i ++ ) {

		stx_free(the->pp_input_pin);
		stx_free(the->pp_output_pin);

		the->pp_output_pin = NULL;

	} // if( the->pp_output_pin ) {

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT	deliver_media_sample
(avb_decoder* the,s32 i_pin,stx_media_data* p_mdat,stx_sync_inf* h_sync)
{
	STX_RESULT i_err;
	stx_base_pin* pinput;
	stx_output_pin* pin;
	stx_output_pin* apin;

	if( !p_mdat ) {
		p_mdat = (stx_media_data*)xloopPull( the->p_video_loop );
		if( !p_mdat) {
			return STX_EOF;
		}
		pinput = the->pp_input_pin[i_pin];
		pin = the->pp_output_pin[i_pin];
		apin = the->pp_output_pin[the->i_audio_idx];
	}
	else {
		pinput = the->pp_input_pin[i_pin];
		pin = the->pp_output_pin[i_pin];
		apin = the->pp_output_pin[the->i_audio_idx];
	}

	if( i_pin == the->i_video_idx && the->i_output_pin > 1 ) {

		xloopPush(the->p_video_loop,p_mdat);

		if( xloopIsFull(the->p_video_loop) || the->i_start_time) {
			p_mdat = (stx_media_data*)xloopPull( the->p_video_loop );
			if( !p_mdat) {
				return STX_FAIL;
			}
		}
		else{
			RESET_XENTRY(h_sync,&the->stx_base_filter_vt);
			return STX_OK;
		}

	} //if( i_pin == the->i_video_idx ) {

	RESET_XENTRY(h_sync,&the->stx_base_filter_vt);
	i_err = pin->deliver(pin,p_mdat,h_sync);
	if( i_err < 0 ) {
		XCALL(release_media_data,pinput,p_mdat);
		return i_err;
	}

	the->i_last_sample_time = p_mdat->get_time(p_mdat,NULL);

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE	STX_RESULT reset_all_preload_stream(avb_decoder* the)
{
	if( the->p_video_loop && the->i_video_idx != -1  ) {
		reset_preload_stream( 
			the->p_video_loop,the->pp_output_pin[the->i_video_idx]);
	}

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE	STX_RESULT reset_preload_stream
( xloop* p_loop, stx_output_pin* p_pin )
{

	STX_RESULT			i_err;
	stx_media_data*		p_data;

	for( ; ; ) {

		p_data = (stx_media_data*)xloopPull(p_loop);
		if( !p_data ) {
			break;
		}

		p_data->set_data(p_data,NULL,0);

		i_err = p_pin->release_media_data(p_pin,p_data);
		if( STX_OK != i_err ) {
			return i_err;
		}

	} // for( ; ; ) {

	xloopFlush(p_loop);

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE	STX_RESULT init_preload_stream(avb_decoder* the)
{
	the->p_video_loop = xloopCreate( the->i_video_buf_num );
	if( !the->p_video_loop ) {
		return STX_FAIL;
	}

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE	STX_RESULT release_preload_stream(avb_decoder* the)
{
	reset_all_preload_stream(the);

	if( the->p_video_loop ) {
		xloopRelease(the->p_video_loop);
		the->p_video_loop = STX_NULL;
	}

	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT 
on_load_stream(avb_decoder* the,STX_RESULT i_result )
{
	STX_RESULT			i_err;
	stx_base_message*	p_msg;
	stx_msg_cnt			cnt;
	u32					i_msg_type;
	char				sz_inf[1024];

	p_msg =  XCREATE(base_msg,NULL,NULL);
	if( !p_msg ) {
		return STX_FAIL;
	}

	do{

		cnt.msg_gid = STX_MSG_OnLoadSource;
		cnt.param.i_param[0] = (size_t)i_result;
		cnt.param.i_param[1] = (size_t)&the->stx_base_source_vt;

		p_msg->set_msg_cnt(p_msg,&cnt);

		i_msg_type = STX_MSG_TYPE_UPSTREAM | STX_MSG_TYPE_DIRECT;
		p_msg->set_msg_type(p_msg,i_msg_type);

		if( STX_OK == i_result ) {
			stx_sprintf(sz_inf,sizeof(sz_inf),
				"load stream success. message sender: %s",g_szStreamX_TsSource);
		}
		else {
			stx_sprintf(sz_inf,sizeof(sz_inf),
				"load stream fail. message sender: %s",g_szStreamX_TsSource);
		}

		i_err = p_msg->set_msg_text(p_msg,sz_inf);
		if( STX_OK != i_err ){
			break;
		}

		i_err = the->p_parent->send_msg(the->p_parent,p_msg);
		if( STX_OK != i_err ){
			break;
		}

		i_err = STX_OK;

	}while(FALSE);

	SAFE_XDELETE(p_msg);

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT: 
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT 
on_auto_stop(STX_HANDLE h,stx_base_message* p_msg )
{
	STX_MAP_THE(avb_decoder);
	{
		STX_HANDLE h_stack = p_msg->get_stack(p_msg);

		// push plugin interface pointer;
		stx_stack_push(h_stack,(size_t)&the->stx_base_filter_vt);

		return STX_OK;
	}
}




/***************************************************************************
RETURN VALUE:
INPUT: 
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT 
on_app_stop(STX_HANDLE h,stx_base_message* p_msg )
{
	STX_MAP_THE(avb_decoder);
	{
		stx_msg_cnt* p_cnt = p_msg->get_msg_cnt(p_msg);

		p_msg->set_msg_close(p_msg);

		// must be next stage plugin's problem; send stop message to app handler;
		return stx_base_plugin_stop(
			(stx_base_plugin*)&the->stx_base_filter_vt,
			(STX_RESULT)p_cnt->param.i_param[0],
			FALSE);
	}

}