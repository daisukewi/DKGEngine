/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-11
***********************************************************************************/


#include "stx_all.h"

#include "video/frame_decoder.h"

#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif

extern STX_NEW_DECL(stx_base_com*,mpeg2_decoder);
extern STX_NEW_DECL(stx_base_com*,ts_source);
extern STX_NEW_DECL(stx_base_com*,avb_decoder);


static void mpeg2_lib_init()
{
	u32 mmflag = mm_support();

	video_decoder_initialize(mmflag);

	// audio; ???
}

/*{{{STX_BEGIN_MODULE_MAP******************************************************/
STX_BEGIN_MODULE_MAP
/**/STX_MODULE_DECLARE(STX_CLSID_Mpeg2Decoder,mpeg2_decoder)
/**/STX_MODULE_DECLARE(STX_CLSID_TsSource,ts_source)
/**/STX_MODULE_DECLARE(STX_CLSID_AvbDecoder,avb_decoder)
STX_END_MODULE_MAP()
/*}}}**************************************************************************/


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
***************************************************************************/
STX_PRIVATE STX_RESULT prev_create_module(void (*xtrace)(char*),u32 i_debug)
{
	if( STX_OK != stx_base_init(xtrace,i_debug) ) {
		return STX_FAIL;
	}
	mpeg2_lib_init();
	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
***************************************************************************/
STX_PRIVATE STX_RESULT post_create_module(stx_base_module *h,STX_RESULT i_err)
{
	if( STX_OK == i_err && h ){
		return STX_OK;
	}
	stx_base_cleanup();
	return STX_FAIL;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
***************************************************************************/
STX_PRIVATE STX_HANDLE prev_destroy_module(stx_base_module *h)
{
	return NULL;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
***************************************************************************/
STX_PRIVATE void post_destroy_module(STX_HANDLE h_user)
{
	stx_base_cleanup();
}
