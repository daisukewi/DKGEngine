/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-11
***********************************************************************************/

#ifndef  __MPEGDEF_H__
#define  __MPEGDEF_H__


#include "base_class.h"
#include "stx_io.h"



#if 0
#define xlog stx_log
#else
#define xlog(fmt,...)
#endif


#define NOTIMECODE_SCALE                18


#define LXPES_READ_COUNT                2048
#define LXPES_END_CODE                  0xFE
#define LXPES_END_DWORD                 0xFE010000

#define LXPES_PACK_START_CODE           0xBA
#define LXPES_PRIVATE_STREAM1           0xBD
#define LXPES_PRIVATE_STREAM2           0xBF

#define LXPES_AUDIO_MIN                 0xC0
#define LXPES_AUDIO_MPEG1_MAX           0xCF
#define LXPES_AUDIO_MPEG2_MIN           0xD0
#define LXPES_AUDIO_MAX                 0xDF

#define LXPES_VIDEO_MIN                 0xE0
#define LXPES_VIDEO_MAX                 0xEF
#define LXPES_SYSTEM_HEADER_START_CODE  0xBB


//{ mpeg standard tagment;
#define _PICTURE_START_CODE              0x00
#define _SLICE_START_CODE_MIN            0x01
#define _SLICE_START_CODE_MAX            0xAF
#define _USER_DATA_START_CODE            0xB2
#define _SEQUENCE_HEADER_CODE            0xB3
#define _SEQUENCE_ERROR_CODE             0xB4
#define _EXTENSION_START_CODE            0xB5
#define _SEQUENCE_END_CODE               0xB7
#define _GROUP_START_CODE                0xB8
#define _SYSTEM_START_CODE_MIN           0xB9
#define _SYSTEM_START_CODE_MAX           0xFF

#define _ISO_END_CODE                    0xB9
#define _PACK_START_CODE                 0xBA
#define _SYSTEM_START_CODE               0xBB
#define _PROGRAM_STREAM_MAP              0xBC


#define SEQUENCE_EXTENSION_ID                    1
#define SEQUENCE_DISPLAY_EXTENSION_ID            2
#define QUANT_MATRIX_EXTENSION_ID                3
#define COPYRIGHT_EXTENSION_ID                   4
#define SEQUENCE_SCALABLE_EXTENSION_ID           5
#define PICTURE_DISPLAY_EXTENSION_ID             7
#define PICTURE_CODING_EXTENSION_ID              8
#define PICTURE_SPATIAL_SCALABLE_EXTENSION_ID    9
#define PICTURE_TEMPORAL_SCALABLE_EXTENSION_ID  10


STX_INTERF(LxVidSequence);
STX_INTERF(LxPstdData);
STX_INTERF(LxSystemHeader);
STX_INTERF(LxTsPidUnit);
STX_INTERF(TsHeaderData);
STX_INTERF(TsAdaptationData);
STX_INTERF(LxTsPgrInf);

STX_INTERF(TsPgrAssTab);
STX_INTERF(TsConditionAssInf);
STX_INTERF(TsAdaptationData);
STX_INTERF(TsPgrMapTab);


struct LxVidSequence
{
	s32 nHorizontalSize             ;    // 11
	s32 nVerticalSize               ;    // 23
	s32 nAspectRatioInformation     ;    // 27
	s32 nFrameRateCode              ;    // 31 4
	s32 nBitRateValue               ;    // 49;
	s32 market_bit                  ;    // 50;
	s32 nVbvBufferSizeCode          ;    // 60;
	s32 bConstrainedParametersFlag  ;    // 61
	s32 bMPEG2Flag                  ;
	s32 nProfileAndLevelIndication  ;
	s32 bProgressiveSequence        ;
	s32 nChromaFormat               ;
	s32 nHorizontalSizeExtension    ;
	s32 nVerticalSizeExtension      ;
	s32 nBitRateExtension           ;
	s32 nVbvBufferSizeExtension     ;
	s32 bLowDelay                   ;
	s32 nFrameRateExtensionN        ;
	s32 nFrameRateExtensionD        ;


	s64 s64TotalFrame;
	s64 s64TotalTime;
	s64 s64CurPts;
	s64 s64TimeStep;
};

struct LxPstdData
{
	s32          stream_id;
	s32          P_STD_buffer_bound_scale;
	s32          P_STD_buffer_size_bound;
	LxPstdData*  lpNext;
};

struct LxSystemHeader
{
	s32          header_length;
	s32          rate_bound;
	s32          audio_bound;
	s32          fixed_flag;
	s32          CSPS_flag;
	s32          system_audio_lock_flag;
	s32          system_video_lock_flag;
	s32          video_bound;
	s32          packet_rate_restriction_flag;
	LxPstdData*  lpPSTD;
};



#define MPEG_MAX_STREAMS      128
#define MPEG_PIDMAX           32    

#define TS_SYNC_CODE          0x47
#define TSPACKET_DEFAULTSIZE  188
#define TS_PAYLOAD_FLAG       1
#define TS_ADAPTATION_FLAG    2

#define TS_STM_VIDEO     1
#define TS_STM_AUDIO     2
#define TS_STM_UNKNOWN   3

#define TS_MAKE_PID( tspid,stm_id,sub_id)   ( (  tspid << 16 ) | (stm_id << 8) | sub_id )

struct LxTsPidUnit{
	s64				qwSts;   // system clock reference;
	s64				qwDts;

	s64				qwPts;

	stx_gid			gidType;
	stx_gid			gidSubType;

	u32				dwStreamId;
	u32				dwSubStmId;
	s32             nPid;
	s32             continuity_counters;
	s32             transport_priority;

	s32             nPesPackLength;
	LxTsPidUnit*    lpNext;
	s32             nChnIdx;
	s32             pad;   // struct 16 bytes align packing;
};


enum emTsPidType{
	emProgramAssociationTab, emConditionalAccessTab, emPes, emNull,
};


struct TsHeaderData
{
	LxTsPidUnit*    pFirstVideoProgram;
	LxTsPidUnit*    pFirstAudioProgram;

	s32             total_programs;
	s32             current_timecode;
	s32             current_byte;

	s32             transport_error_indicator;
	s32             payload_unit_start_indicator;
	s32             transport_priority;
	s32             pid;
	s32             transport_scrambling_control;
	s32             adaptation_field_control;
	s32             continuity_counter;
	s32             is_padding;
	s32             total_pids;
	s32             adaptation_fields;

	s32             audio_pid;/* Video stream ID being decoded.  -1 = select first ID in stream */
	s32             video_pid;/* Audio stream ID being decoded.  -1 = select first ID in stream */
	s32             audio_num;
	s32             video_num;

	s32             program_association_tables;
};


struct TsAdaptationData
{
	s64		dts_next_au;	
	s64		program_clock_reference_base;
	s64		original_program_clock_reference_base;

	s32      length;
	s32      discontinuity_indicator ;
	s32      random_access_indicator ;
	s32      elementry_stream_priority_indicator;
	s32      pcr_flag;
	s32      opcr_flag;
	s32      splicing_point_flag;
	s32      transport_private_data_flag;
	s32      adaptation_field_extension_flag;
	s32      splice_countdown;
	s32      transport_private_data_length;
	s32      adaptation_field_extension_length;
	s32      ltw_flag;
	s32      piecewise_rate_flag;
	s32      seamless_splice_flag;
	s32      ltw_valid_flag;
	s32      ltw_offset;
	s32      piecewise_rate;
	s32      splice_type;
	s32      program_clock_reference_extension;
	s32      original_program_clock_reference_extension;
};


struct LxTsPgrInf
{
	s32            program_number;
	union{
		s32            network_pid;
		s32            program_map_pid;
	};
	LxTsPgrInf*    lpNext;
	s32            pad;
};



struct TsPgrAssTab
{
	s32          table_id;
	s32          section_syntax_indicator;
	s32          section_length;
	s32          transport_stream_id;

	s32          version_number;
	s32          current_next_indicator;
	s32          section_number;
	s32          last_section_number;

	LxTsPgrInf   PrgInf[44]; // max in ts packet;

	s32          crc_32;
	s32          valid_program_num;
};


struct TsConditionAssInf
{
	s32          table_id;
	s32          section_syntax_indicator;
	s32          section_length;
	s32          version_number;
	s32          current_next_indicator;
	s32          section_number;
	s32          last_section_number;

	// ??
	s32          crc_32;
};



struct TsPgrMapUnit
{
	s32 stream_type;     //		stream_type	8	uimsbf
	//		reserved	3	bslbf
	s32 elementary_PID;  //		elementary_PID	13	uimsnf
	//		reserved	4	bslbf
	s32 ES_info_length;  //		ES_info_length	12	uimsbf

	s32 pad;

};



struct TsPgrMapTab
{
	s32 table_id;                   //	8	uimsbf
	s32 section_syntax_indicator;   //	1	bslbf
	//'0'	1	bslbf
	//reserved	2	bslbf
	s32 section_length;             //	12	uimsbf
	s32 program_number;             //	16	uimsbf
	//reserved	2	bslbf
	s32 version_number;             //	5	uimsbf
	s32 current_next_indicator;     //	1	bslbf
	s32 section_number;             //	8	uimsbf
	s32 last_section_number;        //	8	uimsbf
	//reserved	3	bslbf
	s32 PCR_PID;                    //	13	uimsbf
	//reserved	4	bslbf
	s32 program_info_length;        //	12	uimsbf
	s32 CRC_32;                     //	32	rpchof
};



/*
Table 2-36 -- Stream type assignments
Value	Description
0x00	ITU-T | ISO/IEC Reserved
0x01	ISO/IEC 11172 Video
0x02	ITU-T Rec. H.262 | ISO/IEC 13818-2 Video or ISO/IEC 11172-2 constrained parameter video stream
0x03	ISO/IEC 11172 Audio
0x04	ISO/IEC 13818-3 Audio
0x05	ITU-T Rec. H.222.0 | ISO/IEC 13818-1 private_sections
0x06	ITU-T Rec. H.222.0 | ISO/IEC 13818-1 PES packets containing private data
0x07	ISO/IEC 13522 MHEG
0x08	ITU-T Rec. H.222.0 | ISO/IEC 13818-1 Annex A DSM CC
0x09	ITU-T Rec. H.222.1
0x0A	ISO/IEC 13818-6 type A
0x0B	ISO/IEC 13818-6 type B
0x0C	ISO/IEC 13818-6 type C
0x0D	ISO/IEC 13818-6 type D
0x0E	ISO/IEC 13818-1 auxiliary
0x0F-0x7F	ITU-T Rec. H.222.0 | ISO/IEC 13818-1 Reserved
0x80-0xFF	User Private
*/
enum emStreamType
{
	emReserved = 0x00, em11172_Video = 0x01, em13818_Video = 0x02, em11172_Audio = 0x03,
	em13818_Audio = 0x04, em13818_Private = 0x05, emPes_Private = 0x06, em13522_MHEG = 0x07,
	em13818_DSM = 0x08, emH222_1 = 0x09, em13818_6A = 0x0a, em13818_6B = 0x0b, em13818_6C = 0x0c,
	em13818_6D = 0x0d, em13818_Aux = 0x0e, em13818_ReMin = 0x0f, em13818_ReMax = 0x7f, 
	emUserPrivateMin = 0x80, emUserPrivateMax = 0xff,
};

#define TS_PID_PAT          0x0000
#define TS_PID_CAT          0x0001
#define TS_PID_NORM_MIN     0x0010
#define TS_PID_NORM_MAX     0x1ffe
#define TS_PID_NULL         0x1fff

#define TS_TID_PAT          0
#define TS_TID_CAT          1
#define TS_TID_PMT          2
#define TS_TID_PVT          3

 
typedef enum emStreamType emStreamType;
typedef enum emTsPidType emTsPidType;

/******************************************************************************/
//{{ pes.h

typedef s16 TimeStamp27;

STX_INTERF(TimeStamp90);
STX_INTERF(TrickMode);
STX_INTERF(PESExtension);
STX_INTERF(PES);

struct TimeStamp90{
	s32 bit32;
	s32 bits0_31;
};


// stream_id values 
enum emPesStreamId{
	id_program_stream_map = 188,
	id_private_stream_1,
	id_padding_stream,
	id_private_stream_2,
	id_audio_stream_0 = 192,
	id_video_stream_0 = 224,
	id_ECM = 256,
	id_EMM,
	id_DSMCC,
	id_MHEG,
	id_private_0,
	id_program_stream_dir = 511
};

#define NOLENGTH -1



struct PES{
	s32				stream_id;		                // see table above
	s32				PES_packet_length;	            // NULL or calculated
	s32				PES_header_length;	    // NULL or calculated
	char			scrambling_code;		    // (S,0) - Scrambled
	char			priority_code;		    // (H,L) - High or Low
	char			alignment_indicator_code;    // (A,0) - Aligned
	char			copyright_code;		    // (C,0) - Copyrighted
	char			original_code;		    // (O,C) - Original or Copy

	s64				s64DTS;
	s64				s64PTS;
	s64				s64ESCR;
	TimeStamp90*	pDTS;		    // may be NULL
	TimeStamp90*	pPTS;		    // may be NULL
	TimeStamp27*	pESCR;		    // may be NULL
	s32				pES_rate;	    // may be 0

	b32				bTrickMode;
	TrickMode*		trick_mode;	    // may be NULL
	char			additional_copy_info;	    // 7 bit copy info or NULL
	s32				previous_CRC;		    // 16 bit CRC or NULL
	b32				bPesExt;
	PESExtension*	extension;	    // may be NULL
	s32				number_stuffing_bytes;	    // 0..32
	char*			file_name;		    // for test files
};

//}} pes.h
/******************************************************************************/





STX_INTERF(ts_channel_inf);
struct ts_channel_inf{
	s32			i_pid;
	b32			b_selected;
	stx_gid		major_type;
	stx_gid		sub_type;
};
STX_INTERF(ts_control);

#define ts_control_func_vtdef() \
	stx_base_com_vtdef()\
	_STX_PURE STX_RESULT (*enum_input_type)(STX_HANDLE h, s32* i_idx, stx_media_type_inf* p_inf);\
	_STX_PURE STX_RESULT (*set_input_type)(STX_HANDLE h, s32 i_idx);\
	_STX_PURE STX_RESULT (*enum_channel)(STX_HANDLE h, s32* i_idx, ts_channel_inf* p_inf);\
	_STX_PURE STX_RESULT (*select_channel)(STX_HANDLE h, s32 i_idx,b32 b_select);\
	_STX_PURE STX_RESULT (*enum_selected_channel)(STX_HANDLE h, s32* i_idx, ts_channel_inf* p_inf);\

struct ts_control{
	ts_control_func_vtdef()
};

#define ts_control_funcdecl(PREFIX) \
	stx_base_com_funcdecl(PREFIX ## _ ## com)\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## enum_input_type(STX_HANDLE h, s32* i_idx, stx_media_type_inf* p_inf);\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## set_input_type(STX_HANDLE h, s32 i_idx);\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## enum_channel(STX_HANDLE h, s32* i_idx, ts_channel_inf* p_inf);\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## select_channel(STX_HANDLE h, s32 i_idx,b32 b_select);\
	STX_PURE STX_RESULT PREFIX ## _xxx_ ## enum_selected_channel(STX_HANDLE h, s32* i_idx, ts_channel_inf* p_inf)

#define ts_control_vtinit(vt,PREFIX) \
	STX_VT_INIT(vt,PREFIX,enum_input_type);\
	STX_VT_INIT(vt,PREFIX,set_input_type);\
	STX_VT_INIT(vt,PREFIX,enum_channel);\
	STX_VT_INIT(vt,PREFIX,select_channel);\
	STX_VT_INIT(vt,PREFIX,enum_selected_channel)

#define ts_control_data_default()			\
	stx_base_com_data_default()

#define ts_control_funcimp_default(SCOM,PREFIX)			\
	stx_base_com_funcimp_default(SCOM,PREFIX ## _ ## com )\

#define ts_control_create_default(vt,PREFIX,CLS,CAT,NAME)		\
	stx_base_com_create_default(vt,PREFIX ## _ ## com,CLS,CAT,NAME);\
	ts_control_vtinit(vt,PREFIX)

#define ts_control_release_default(SCOM)			\
	stx_base_com_release_default(SCOM)\

#define ts_control_release_begin(SCOM)			\
	stx_base_com_release_begin(SCOM)\

#define ts_control_release_end(SCOM)			\
	stx_base_com_release_end(SCOM)\

#define ts_control_query_default(SCOM,vt)			\
	if( IS_EQUAL_GID(gid,STX_IID_TsControl) ) {\
	the->i_ref ++;\
	*pp_interf = (void*)&vt;\
	return STX_OK;\
	}\
	stx_base_com_query_default(SCOM,vt)\




/*****************************************************************************
*****************************************************************************/
// {DF6A0196-CCBF-43d2-B816-94205F59EE43}
DECLARE_XGUID( STX_IID_StreamSplit,
0xdf6a0196, 0xccbf, 0x43d2, 0xb8, 0x16, 0x94, 0x20, 0x5f, 0x59, 0xee, 0x43);

STX_INTERF(stream_split);

#define stream_split_vtdef() \
	stx_base_com_vtdef() \
	_STX_PURE void		  (*reset)(STX_HANDLE h);\
	_STX_PURE STX_RESULT  (*parse)(\
	/**/STX_HANDLE			h, \
	/**/u8*					buf, \
	/**/size_t				i_len, \
	/**/u8**				pp_data, \
	/**/size_t*				i_data); \
	_STX_PURE STX_RESULT  (*get_type)(\
	/**/STX_HANDLE			h, \
	/**/s32*				pid, \
	/**/stx_gid*			major_type,\
	/**/stx_gid*			sub_type);\
	_STX_PURE STX_RESULT  (*get_time)(\
	/**/STX_HANDLE			h, \
	/**/s64*				pts,\
	/**/s64*				dts);\


struct stream_split{
	stream_split_vtdef()
};

#define stream_split_funcdecl(PREFIX) \
	stx_base_com_funcdecl(PREFIX ## _ ## com) \
	STX_PURE void		  PREFIX ## _xxx_ ## reset(STX_HANDLE h);\
	STX_PURE STX_RESULT  PREFIX ## _xxx_ ## parse(\
	/**/STX_HANDLE			h, \
	/**/u8*					buf, \
	/**/size_t				i_len, \
	/**/u8**				pp_data, \
	/**/size_t*				i_data); \
	STX_PURE STX_RESULT  PREFIX ## _xxx_ ## get_type(\
	/**/STX_HANDLE		h, \
	/**/s32*			pid, \
	/**/stx_gid*		major_type,\
	/**/stx_gid*		sub_type);\
	STX_PURE STX_RESULT  PREFIX ## _xxx_ ## get_time(\
	/**/STX_HANDLE			h, \
	/**/s64*				pts,\
	/**/s64*				dts)


#define stream_split_vtinit(vt,PREFIX) \
	STX_VT_INIT(vt,PREFIX,reset);\
	STX_VT_INIT(vt,PREFIX,parse);\
	STX_VT_INIT(vt,PREFIX,get_type);\
	STX_VT_INIT(vt,PREFIX,get_time)

#define stream_split_data_default()			\
	stx_base_com_data_default()

#define stream_split_funcimp_default(SCOM,PREFIX)			\
	stx_base_com_funcimp_default(SCOM,PREFIX ## _ ## com )\

#define stream_split_create_default(vt,PREFIX,CLS,CAT,NAME)		\
	stx_base_com_create_default(vt,PREFIX ## _ ## com,CLS,CAT,NAME); \
	stream_split_vtinit(vt,PREFIX)

#define stream_split_release_default(SCOM)			\
	stx_base_com_release_default(SCOM)\

#define stream_split_release_begin(SCOM)			\
	stx_base_com_release_begin(SCOM)\

#define stream_split_release_end(SCOM)			\
	stx_base_com_release_end(SCOM)\

#define stream_split_query_default(SCOM,vt)			\
	if( IS_EQUAL_GID(gid,STX_IID_StreamSplit ) ) {\
	/**/the->i_ref ++;\
	/**/*pp_interf = (void*)&vt;\
	/**/return STX_OK;\
	}\
	stx_base_com_query_default(SCOM,vt)\



STX_INTERF(sar_table);

struct sar_table{
	s32   asr;
	u32 ratio;
};

static sar_table sartab[]=
{
	{0,(16384*4/3)},
	{1,(16384*4/3)},
	{2,(16384*4/3)},
	{3,(16384*16/9)},
	{4,(u32)(16384*2.210)},
	{5,(16384*4/3)},
	{6,(16384*4/3)},
	{7,(16384*4/3)},
	{8,(16384*4/3)},
	{9,(16384*4/3)},
	{10,(16384*4/3)},
	{11,(16384*4/3)},
	{12,(16384*4/3)},
	{13,(16384*4/3)},
	{14,(16384*4/3)},
	{15,(16384*4/3)}
};


STX_INTERF(vfrate);
struct vfrate{
	s32 frame_rate;
	s32 clock;
};

static vfrate rate_table[16]=
{
	{29970,33},  // 0
	{23976,40},
	{24000,40},
	{25000,40},
	{29970,33},
	{30000,33},
	{50000,20},
	{59940,16},
	{60000,16},
	{29970,33},  // 9
	{29970,33},  // 10
	{29970,33},  // 11
	{29970,33},  // 12
	{29970,33},  // 13
	{29970,33},  // 14
	{29970,33},  // 15
};



#define __QUANT_TABLE

#define VID_DROP_GOP_LIMIT 110
#define VID_DROP_LIMIT     95

//<<
#define ENABLE_DX2
#define AUTODECTECT_DX2
//>>

#define LX_VIDACC_AGP              1
#define LX_VIDACC_AGPRGB16         (1<<1)
#define LX_VIDACC_AGPRGB16TYPE     (1<<2)
#define LX_VIDACC_AGPSUFTYPE       (1<<3)
#define LX_VIDACC_SUFSIZE          (1<<4)
#define LX_VIDACC_DEINTERLACE      (1<<5)
#define LX_VIDACC_DEINTERLACETYPE  (1<<6)
#define LX_VIDACC_SHARP            (1<<7)
#define LX_VIDACC_SHARPTYPE        (1<<8)
#define LX_VIDACC_SMOOTH           (1<<9)
#define LX_VIDACC_SMOOTHTYPE       (1<<10)
#define LX_VIDACC_HIGHPRECESION    (1<<11)
#define LX_VIDACC_CLEARTYPESUBPIC  (1<<12)
#define LX_VIDACC_HYPERBUFFER      (1<<13)
#define LX_VIDACC_DUALCORE         (1<<14)
#define LX_VIDACC_HALFYUV          (1<<15)
#define LX_VIDACC_DOUBLE_FREQ      (1<<16)
#define LX_VIDACC_ROTATE           (1<<17)

//#define LX_AUDACC_80X87      (1<<13)

STX_INTERF(LxVidAccSet);

struct LxVidAccSet{

	u32			dwSize;
	u32			dwFlags;

	u32			bUseAGP;       // user settings;
	u32			bPreferRgb16;  // user settings;
	u32			dwRgb16Type;   // system test results;

	u32			dwAGPSufType;
	s32			nMaxWidth;     // system test results;
	s32			nMaxHeight;    // system test results;

#define LX_DEINTERLACE_DISABLE      1
#define LX_DEINTERLACE_FORCE        2
#define LX_DEINTERLACE_AUTOSELECT   3
	u32			dwUseDeinterlacing;

#define LX_DEINTERLACE_FIELD_BLUR                   1
#define LX_DEINTERLACE_FIELD_MOTION_DETECT          2
#define LX_DEINTERLACE_FIELD_MOTION_DETECT_EX       3
#define LX_DEINTERLACE_FIELD_MOTION_DETECT_LIGHT    4
	u32			dwDeinterlaceType;

	u32			bUseSharpping;     // dvd/vcd use;
	u32			dwSharpType;

	u32			bUseSmoothing;    // vcd use;
	u32			dwSmoothType;

	u32			bUseTopField;
	u32			bUpGrade;
	u32			dwRotateTheta;       // 2008-04-02, baojinlong;

	u32			bUseVbvAdjust;    // adjust vido and audio syncronizing;
	u32			nVbvBufferSize;

	u32			bUseIDCT32;
	u32			bUseClearTypeSubpicture;

	b32         bHaveMMX;
	b32         bHaveMMXPlus;
	b32         bHaveSSE;
	b32         bHaveSSE2;
	b32         bHaveSSE3;
	b32         bHave3Dnow;
	b32         bHaveEnhanced3Dnow;
	b32         bHaveHTT;
	b32         bHaveSSE4;           // 2008-03-27, baojinlong;

	u32			dwCpuNum;
};



#endif // __MPEGDEF_H__