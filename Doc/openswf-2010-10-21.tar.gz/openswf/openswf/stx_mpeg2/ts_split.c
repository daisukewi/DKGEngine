/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-11
***********************************************************************************/
#include "ts_split.h"

#include "stx_io.h"
#include "stx_io_stream.h"
#include "stx_os.h"
#include "stx_mem.h"
#include "stx_debug.h"



#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif

/********************************************/
#define __GET_BITS_INC__
#include "get_bits.h"
#include "get_bits.c"
/********************************************/



/*****************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
*****************************************************************************************/
static s64 ts_get_time_code(stx_bits_window* const pStream)
{
	s32 pts32,pts3130,pts2915,pts1400;

	pts32 = stx_get_bits(pStream,1);

	pts3130 = stx_get_bits(pStream,2);

	stx_get_bits(pStream,1);

	pts2915 = stx_get_bits(pStream,15);

	stx_get_bits(pStream,1);

	pts1400 = stx_get_bits(pStream,15);

	stx_get_bits(pStream,1);

	return ( (s64)pts32 << 32 ) + (pts3130 << 30) + (pts2915 << 15) + pts1400;
}

// {DF6A0196-CCBF-43d2-B816-94205F59EE43}
DEFINE_XGUID( STX_IID_StreamSplit,
0xdf6a0196, 0xccbf, 0x43d2, 0xb8, 0x16, 0x94, 0x20, 0x5f, 0x59, 0xee, 0x43);



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API_IMP
CREATE_STX_COM(stream_split,STX_IID_StreamSplit,ts_split);


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_COM_BEGIN(ts_split);
/**/
/**/STX_PUBLIC(stream_split)
/**/STX_COM_DATA_DEFAULT(stream_split)
/**/
/**/STX_PUBLIC(ts_control)
/**/
/**/stx_bits_window		bitstream;
/**/TsHeaderData		Header;
/**/TsAdaptationData	Adaptation; 
/**/TsPgrAssTab			PgrAssTab;
/**/TsConditionAssInf	CAssTab;
/**/TsPgrMapTab			MapTab;
/**/PES					pes;
/**/stx_gid				output_type;
/**/u32					dwCurAudStmId;
/**/LxTsPidUnit*		pCurrent;
/**/
STX_COM_END();

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_COM_FUNC_DECL_DEFAULT(stream_split,stream_split_vt);
STX_COM_FUNCIMP_DEFAULT(ts_split,stream_split,stream_split_vt);

STX_COM_FUNC_DECL_DEFAULT(ts_control,ts_control_vt);
STX_COM_FUNCIMP_DEFAULT(ts_split,ts_control,ts_control_vt);


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT		TsProgramAssTab(ts_split* the);
STX_PRIVATE STX_RESULT		TsConditionAssTab(ts_split* the);
STX_PRIVATE STX_RESULT		TsProgramMapSec(ts_split* the);
STX_PRIVATE STX_RESULT		TsPrivateSec(ts_split* the);
STX_PRIVATE STX_RESULT		ReadAdaptation(ts_split* the, s32 Type);
STX_PRIVATE void			ReleasePidList(ts_split* the);
STX_PRIVATE void			FlushPidList(ts_split* the);
STX_PRIVATE LxTsPidUnit*	TsAddPid(ts_split* the,stx_gid gidType);
STX_PRIVATE LxTsPidUnit*	TsGetPid(ts_split* the,s32 nPid);
STX_PRIVATE LxTsPidUnit*	TsReadPesHeader(ts_split* the,s32 nLen);



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_COM_MAP_BEGIN(ts_split)
/**/STX_COM_MAP_ITEM(STX_IID_StreamSplit)
/**/STX_COM_MAP_ITEM(STX_IID_TsControl)
STX_COM_MAP_END()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_NEW_BEGIN(ts_split)
{
	STX_SET_THE(stream_split);
	STX_COM_NEW_DEFAULT(stream_split,the->stream_split_vt,stream_split_vt,
		DEFAULT_CODE,DEFAULT_CODE,DEFAULT_CODE);

	STX_SET_THE(ts_control);
	STX_COM_NEW_DEFAULT(ts_control,the->ts_control_vt,ts_control_vt,
		DEFAULT_CODE,DEFAULT_CODE,DEFAULT_CODE);

}
STX_NEW_END()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_DELETE_BEGIN(ts_split)
{

	ReleasePidList(the);

	//stx_free_get_bits(&the->bitstream);

	STX_COM_DELETE_DEFAULT(stream_split);
}
STX_DELETE_END
(
STX_COM_DELETE_BEGIN(stream_split)
,
STX_COM_DELETE_END(stream_split)
)

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_QUERY_BEGIN(ts_split)
{
	STX_COM_QUERY_DEFAULT(stream_split,the->stream_split_vt);
	STX_COM_QUERY_DEFAULT(ts_control,the->ts_control_vt);
}
STX_QUERY_END()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
ts_control_vt_xxx_enum_input_type
(STX_HANDLE h,s32 *i_idx,stx_media_type_inf *p_inf)
{
	STX_MAP_THE(ts_split);

	if( !i_idx ) {
		return STX_ERR_INVALID_PARAM;
	}

	if( ! p_inf ){
		*i_idx = 1;
		return STX_OK;
	}

	{
		s32 const idx = *i_idx;

		if( idx != 0 ) {
			return STX_ERR_INVALID_PARAM;
		}

		p_inf->major_type = MEDIATYPE_Stream;
		p_inf->sub_type = MEDIASUBTYPE_MPEG2_TRANSPORT;

		binary_to_string(sizeof(stx_gid),(u8*)&MEDIATYPE_Stream,*p_inf->major_type_name);
		binary_to_string(sizeof(stx_gid),(u8*)&MEDIASUBTYPE_MPEG2_TRANSPORT,*p_inf->sub_type_name);

		return STX_OK;

	} // block

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT ts_control_vt_xxx_set_input_type
(STX_HANDLE h,s32 i_idx)
{
	STX_MAP_THE(ts_split);

	if( i_idx != 0 ) {
		return STX_ERR_INVALID_PARAM;
	}

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT ts_control_vt_xxx_enum_channel
(STX_HANDLE h,s32 *i_idx, ts_channel_inf *p_inf )
{
	STX_MAP_THE(ts_split);

	if( !i_idx ) {
		return STX_ERR_INVALID_PARAM;
	}

	{

		LxTsPidUnit*	lpProgram;
		s32				nNum;

		nNum = 0;
		lpProgram = the->Header.pFirstVideoProgram;
		while( lpProgram ) {
			nNum ++;
			lpProgram = lpProgram->lpNext;
		}

		if( ! p_inf ){
			*i_idx = nNum;
			return STX_OK;
		}

		{
			s32 const idx = *i_idx;

			if( idx < 0 || idx >= nNum ) {
				return STX_ERR_INVALID_PARAM;
			}

			nNum = 0;
			lpProgram = the->Header.pFirstVideoProgram;

			while( lpProgram ) {

				if( nNum == idx ) {

					if( lpProgram->nPid == the->Header.video_pid ||
					lpProgram->nPid == the->Header.audio_pid 
					){
						p_inf->b_selected = TRUE;
					}
					else {
						p_inf->b_selected = FALSE;
					}

					p_inf->i_pid = lpProgram->nPid;
					p_inf->major_type = lpProgram->gidType;
					p_inf->sub_type = lpProgram->gidSubType;

					return STX_OK;

				} // if( nNum == idx ) {

				nNum ++;
				lpProgram = lpProgram->lpNext;

			} //while( lpProgram ) {

		} // block

	} // block

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT ts_control_vt_xxx_enum_selected_channel
(STX_HANDLE h,s32 *i_idx,ts_channel_inf *p_inf)
{
	STX_MAP_THE(ts_split);

	if( !i_idx ) {
		return STX_ERR_INVALID_PARAM;
	}

	{

		LxTsPidUnit*	lpProgram;
		s32				nNum;

		nNum = 0;
		lpProgram = the->Header.pFirstVideoProgram;
		while( lpProgram ) {
			if( lpProgram->nPid == the->Header.video_pid ||
			lpProgram->nPid == the->Header.audio_pid 
			){
				nNum ++;
			}
			lpProgram = lpProgram->lpNext;
		}

		if( ! p_inf ){
			*i_idx = nNum;
			return STX_OK;
		}

		{
			s32 const idx = *i_idx;

			if( idx < 0 || idx >= nNum ) {
				return STX_ERR_INVALID_PARAM;
			}

			nNum = 0;
			lpProgram = the->Header.pFirstVideoProgram;

			while( lpProgram ) {

				if( lpProgram->nPid == the->Header.video_pid ||
					lpProgram->nPid == the->Header.audio_pid ){

					if( nNum == idx ) {

						p_inf->b_selected = TRUE;
						p_inf->i_pid = lpProgram->nPid;
						p_inf->major_type = lpProgram->gidType;
						p_inf->sub_type = lpProgram->gidSubType;

						return STX_OK;

					} // if( nNum == idx ) {

					nNum ++;

				} //if( lpProgram->nPid == 

				lpProgram = lpProgram->lpNext;

			} //while( lpProgram ) {

		} // block

	} // block

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT ts_control_vt_xxx_select_channel
(STX_HANDLE h,s32 i_idx,b32 b_select)
{
	STX_MAP_THE(ts_split);
	{
		LxTsPidUnit*	lpProgram;
		s32				nNum;

		nNum = 0;
		lpProgram = the->Header.pFirstVideoProgram;

		while( lpProgram ) {

			if( lpProgram->nPid == i_idx ){

				if( b_select ){

					if( IS_EQUAL_GID(lpProgram->gidType,MEDIATYPE_Video) ) {
						the->Header.video_pid = lpProgram->nPid;
					}
					else if( IS_EQUAL_GID(lpProgram->gidType,MEDIATYPE_Audio) ) {
						the->Header.audio_pid = lpProgram->nPid;
					}
				}
				else{
					if( lpProgram->nPid == the->Header.video_pid ){
						the->Header.video_pid = -1;
					}
					else if( lpProgram->nPid == the->Header.audio_pid ){
						the->Header.audio_pid = -1;
					}
					
				}//else{

				FlushPidList(the);
				return STX_OK;

			} // if( lpProgram->nPid == i_idx ){

			lpProgram = lpProgram->lpNext;

		} // while( lpProgram ) {

	} // block


	return STX_OK;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stream_split_vt_xxx_get_type
(STX_HANDLE h,s32* pid,stx_gid* major_type,stx_gid* sub_type)
{
	STX_MAP_THE(ts_split);

	*pid = the->pCurrent->nPid;
	*major_type = the->pCurrent->gidType;
	*sub_type = the->pCurrent->gidSubType;

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stream_split_vt_xxx_get_time
(STX_HANDLE h,s64* pts, s64* dts )
{
	STX_MAP_THE(ts_split);
	{
		LxTsPidUnit* p = the->pCurrent;

		if( p->qwPts == -1 ) {
			*pts = p->qwSts;
		}
		else{
			*pts = p->qwPts;
		}

		*dts = p->qwDts;

		return STX_OK;
	}
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT get_channel_data
(LxTsPidUnit* p, u8* data, size_t i_len, stx_media_data* p_mdat)
{
	STX_RESULT			i_err;
	u8*					buf;
	size_t				i_size;

	if( p_mdat->get_buf(p_mdat,&buf) < i_len ) {
		i_err = p_mdat->resize(p_mdat,i_len);
		if( STX_OK != i_err ) {
			return STX_FAIL;
		}
	}

	i_err = p_mdat->get_data(p_mdat,&buf,&i_size);
	if( STX_OK != i_err ) {
		return STX_FAIL;
	}

	memcpy(buf,data,i_len);

	p_mdat->set_data(p_mdat,buf,i_len);

	if( p->qwPts == -1 ) {
		p_mdat->set_time(p_mdat,p->qwSts,p->qwDts);
	}
	else{
		p_mdat->set_time(p_mdat,p->qwPts,p->qwDts);
	}

	return STX_OK;
}



/*****************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
*****************************************************************************************/
STX_PRIVATE LxTsPidUnit* TsReadPesHeader(ts_split* the,s32 nLen)
{
	LxTsPidUnit* lpPid;

	s32 i,j,k;

	s32 stm_id, sub_id, nHeaderLen;
	s32 nPackLen;
	s32 code;

	stx_gid gidPackType;
	stx_gid gidPackSubType;

	s32 nPrivData;
	s32 number_stuffing_bytes;

	s64 qwDts = -1;
	s64 qwPts = -1;

	stx_bits_window* const pStream = &the->bitstream;

	if( stx_show_bits(pStream,24) != 0x01 ) {  // maybe a table;
		return NULL;
	}

	stx_get_bits(pStream,24);
	stm_id = stx_get_bits(pStream,8);

	nPackLen = stx_get_bits(pStream,16);

	code = stx_show_bits(pStream,8);

	if( 0x02 ==  (code>>6) ){

		s32 pts_flag, dts_flag, escr_flag, esrate_flag, trick_mode_flag,
			pes_extension_flag, additional_copy_flag, crc_flag;

		s32 nHeaderDataLen = 9;

		the->output_type = MEDIATYPE_MPEG2_PES;

		stx_get_bits(pStream,8);

		// read 8 flags
		pts_flag = stx_get_bits(pStream,1);		
		dts_flag = stx_get_bits(pStream,1);  
		escr_flag = stx_get_bits(pStream,1);		
		esrate_flag = stx_get_bits(pStream,1);
		trick_mode_flag = stx_get_bits(pStream,1);	
		additional_copy_flag = stx_get_bits(pStream,1);
		crc_flag = stx_get_bits(pStream,1);		
		pes_extension_flag = stx_get_bits(pStream,1);  	
		nHeaderLen = stx_get_bits(pStream,8);// read PES_header_data_length 

		// read optional fields 
		if ( pts_flag  && !dts_flag ){

			stx_get_bits(pStream,4);
			qwPts = ts_get_time_code(pStream);
			nHeaderDataLen += 5;

		}
		else if ( pts_flag  && dts_flag ){		// read pts,dts
			stx_get_bits(pStream,4);
			qwPts = ts_get_time_code(pStream);
			stx_get_bits(pStream,4);
			qwDts = ts_get_time_code(pStream);
			nHeaderDataLen += 10;
		}

		// read escr
		if (escr_flag == 1){
			stx_get_bits(pStream,24);                 
			stx_get_bits(pStream,24);                 
			nHeaderDataLen += 6;
		}

		// read es_rate
		if (esrate_flag == 1){
			stx_get_bits(pStream,24);                 
			nHeaderDataLen += 3;
		}

		// read DSM_trick_mode
		if (the->pes.bTrickMode == 1)	{
			stx_get_bits(pStream,8);                  
			nHeaderDataLen += 1;
		}

		// read additional_copy_info
		if (additional_copy_flag == 1)	{
			stx_get_bits(pStream,8);
			nHeaderDataLen += 1;
		}

		// read previous_PES_packet_CRC
		if ( crc_flag == 1){
			stx_get_bits(pStream,16);
			nHeaderDataLen += 2;
		}

		// read PES extension fields
		if ( pes_extension_flag == 1)	{

			char PES_extension_field_flag;
			char PES_private_data_flag;
			char pack_header_field_flag;
			char pp_seq_counter_flag;
			char P_STD_buffer_flag;
			s32  nLen = 1;

			PES_private_data_flag = stx_get_bits(pStream,1);
			pack_header_field_flag = stx_get_bits(pStream,1);
			pp_seq_counter_flag = stx_get_bits(pStream,1);
			P_STD_buffer_flag = stx_get_bits(pStream,1);

			stx_get_bits(pStream,3);
			
			PES_extension_field_flag = stx_get_bits(pStream,1);

			if (PES_private_data_flag == 1) {
				for (i = 0; i < 4; i++) {
					stx_get_bits(pStream,32);
				}
				nLen += 16;
			}

			if (pack_header_field_flag == 1)    {
				s32 pack_field_length = stx_get_bits(pStream,8);
				for (j = 0; j < pack_field_length; j++) {
					stx_get_bits(pStream,8);
				}
				nLen += pack_field_length + 1;
			}

			if (pp_seq_counter_flag == 1)    {
				stx_get_bits(pStream,16);
				nLen += 2;
			}

			if (P_STD_buffer_flag == 1)  {
				stx_get_bits(pStream,16);
				nLen += 2;
			}

			if (PES_extension_field_flag == 1)  {
				s32 PES_extension_field_length;
				stx_get_bits(pStream,1);
				PES_extension_field_length = stx_get_bits(pStream,7);
				for (k = 0; k < PES_extension_field_length; k++){
					stx_get_bits(pStream,8);
				}
				nLen += PES_extension_field_length + 1;
			}

			nHeaderDataLen += nLen;
		}

		// skip the stuffing bytes.  N.B. the "9" added to PES_header_length
		number_stuffing_bytes = nHeaderLen + 9 - nHeaderDataLen;

		for (i = 0; i < number_stuffing_bytes; i++){
			stx_get_bits(pStream,8);
		}

	}
	else {  // mpeg one;

		the->output_type = MEDIASUBTYPE_MPEG1Payload;
		nHeaderLen = 0;

		if( 0xff == code ){
			while( 0xff == ( code = stx_show_bits(pStream,8) ) ){
				stx_get_bits(pStream,8);// ship mpeg1 pack header;
				nHeaderLen ++;
			}
		}

		code = stx_show_bits(pStream,2);

		if( code == 0x01 )	{
			stx_get_bits(pStream,16); /* skip STD_buffer_scale */
			nHeaderLen += 2;
		}

		code = stx_show_bits(pStream,4) & 0x03;

		if( code == 0x02 ){ // pts;
			stx_get_bits(pStream,4);
			qwPts = ts_get_time_code(pStream);
			nHeaderLen += 5;

		}
		else if( code == 0x03 ){  // pts and dts;
			stx_get_bits(pStream,4);
			qwPts = ts_get_time_code(pStream);
			stx_get_bits(pStream,4);
			qwDts = ts_get_time_code(pStream);
			nHeaderLen += 10;

		}
		else if( code == 0 ){  // no pts and dts;
			stx_get_bits(pStream,8);
			nHeaderLen ++;
		}	
	}	

	nPrivData = IS_EQUAL_GID(the->output_type, MEDIATYPE_MPEG2_PES) ? 3 : 0;

	if( ( stm_id >> 4) == 0x0e ){   // video 
		sub_id = 0;
		gidPackType = MEDIATYPE_Video;
		gidPackSubType = MEDIASUBTYPE_MPEG2_VIDEO;
	}
	else if( stm_id >= LXPES_AUDIO_MIN && stm_id <= LXPES_AUDIO_MAX ){   // audio
		gidPackType = MEDIATYPE_Audio;
		if( stx_show_bits(pStream,16) == 0x0b77 ){
			gidPackSubType = MEDIASUBTYPE_DOLBY_AC3;
			sub_id = 0x80;
		}
		else{
			gidPackSubType = MEDIASUBTYPE_MPEG1Audio;
			sub_id = 0;
		}
	}
	else if( stm_id == 0xbd ){ // private stream 1;

		sub_id = stx_show_bits(pStream,8);

		gidPackType = MEDIATYPE_Audio;
		gidPackSubType = MEDIASUBTYPE_DOLBY_AC3;
//		TRACE1("ts ac3 pack subid = 0x%X \n",sub_id);
		sub_id = 0x80;   // in ts, different stream with different pid;		
	}
	else {
		return NULL;
	}


	if ( ( lpPid = TsGetPid(the,the->Header.pid) ) == NULL ) {

		lpPid = TsAddPid(the,gidPackType);

		if( IS_EQUAL_GID(gidPackType,MEDIATYPE_Video) ){
			lpPid->nChnIdx = the->Header.video_num ++;
		}
		else if( IS_EQUAL_GID(gidPackType,MEDIATYPE_Audio) ) {
			lpPid->nChnIdx = the->Header.audio_num ++;
		}

		//<< static attribute;
		lpPid->nPid = the->Header.pid;
		lpPid->gidType = gidPackType;
		lpPid->gidSubType = gidPackSubType;
		lpPid->dwStreamId = stm_id;
		lpPid->dwSubStmId = sub_id;
		//>>

		the->Header.total_pids ++;
//		TRACE1(" TS new pid = 0x%X\n",lpPid->nPid);
//		TRACE1(" new program pack type = 0x%X  \n",  TS_MAKE_PID(m_TsHeader.pid,stm_id,sub_id) );
	}

	//<< updating when every pack;
	if( qwDts >= 0 ) {
		lpPid->qwDts = qwDts;
	}
	if( qwPts >= 0 ) {
		lpPid->qwPts = qwPts;
	}
	lpPid->qwSts = the->Adaptation.program_clock_reference_base;
	lpPid->continuity_counters = the->Header.continuity_counter;
	lpPid->transport_priority = the->Header.transport_priority;
	//>>

	return lpPid;
}





/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stream_split_vt_xxx_parse
(
 /**/STX_HANDLE			h, \
 /**/u8*				buf,
 /**/size_t				i_len,
 /**/u8**				pp_data, 
 /**/size_t*			i_data
)
{
	STX_RESULT		i_err;
	stx_io_op_param	inf;


	STX_MAP_THE(ts_split);
	{

		stx_bits_window* const pStream = &the->bitstream;


		if( i_len != TSPACKET_DEFAULTSIZE ) {
			return STX_OK;
			//return STX_ERR_INVALID_PARAM;
		}

		i_err = stx_direct_get_bits(pStream,buf,i_len*8);
		if( STX_OK != i_err ) {
			return i_err;
		}

		if( TS_SYNC_CODE != stx_get_bits(pStream,8) ) {
			return STX_OK;
			//return STX_ERR_INVALID_PARAM;
		}

		the->Header.transport_error_indicator = stx_get_bits(pStream,1);
		the->Header.payload_unit_start_indicator = stx_get_bits(pStream,1);
		the->Header.transport_priority = stx_get_bits(pStream,1);

		the->Header.pid = stx_get_bits(pStream,13);

		the->Header.transport_scrambling_control = stx_get_bits(pStream,2);
		the->Header.adaptation_field_control = stx_get_bits(pStream,2);
		the->Header.continuity_counter = stx_get_bits(pStream,4);               // 3


		//TRACE1("m_TsHeader.pid = %d\n",m_TsHeader.pid);
		if ( the->Header.pid == 0x1fff ) {		//�շ���
			return STX_OK;
		}

		if( the->Header.pid == TS_PID_PAT ) {
			TsProgramAssTab(the);
		}
		else if( the->Header.pid == TS_PID_CAT ) {
			// conditional access table;
			TsConditionAssTab(the);
		}
		else if( the->Header.pid >= 0x10 && the->Header.pid <= 0x1ffe ) {  

			s32 nLen = TSPACKET_DEFAULTSIZE - 4;

			if( the->Header.adaptation_field_control & TS_ADAPTATION_FLAG ){
				if( STX_OK != ReadAdaptation(the,the->Header.adaptation_field_control) ){
					return STX_OK;  // error found in ts stream; discard it;
				}
				//TRACE1("adaptation length = %d\n",m_Adaptation.length);
				nLen -= the->Adaptation.length;
			}

			if( the->Header.adaptation_field_control & TS_PAYLOAD_FLAG  && nLen ) {

				size_t			i_data_len,i_write;
				u8*				p_data;
				LxTsPidUnit*	lpProgram;

				//m_TsHeader.video_pid = 34;  // test;

				if( the->Header.payload_unit_start_indicator ){

					/* update pid */
					lpProgram =  TsReadPesHeader(the,nLen);    // if is valid pes stream;
					if( !lpProgram ) {
						return STX_OK;
					}

					if( ! the->Header.video_pid ) {
						if( IS_EQUAL_GID(lpProgram->gidType,MEDIATYPE_Video) ){
							the->Header.video_pid = the->Header.pid;
						}
					}

					if( ! the->Header.audio_pid ) {
//						if( IS_EQUAL_GID(lpProgram->gidType,MEDIATYPE_Audio) ) {
						if( IS_EQUAL_GID(lpProgram->gidSubType,MEDIASUBTYPE_MPEG1Audio) ) {
							the->Header.audio_pid = the->Header.pid;
							the->dwCurAudStmId = lpProgram->dwSubStmId;
						}
					}

				} // if( m_TsHeader.payload_unit_start_indicator ){
				else if ( NULL == ( lpProgram =  TsGetPid(the,the->Header.pid))) {   
					// if is the exist program ;
					return STX_OK;
				}

				if( the->Header.pid != the->Header.video_pid && the->Header.pid != the->Header.audio_pid ) {
					return STX_OK;
				}

				if( pStream->nCurrentBit < 0 ) {
					// have error;
					return STX_OK; // treat as blank packet;
				}

				// maybe pes header use some data;
				p_data = pStream->lpCurrentByte - ( pStream->nCurrentBit >> 3); 
				//stx_assert(p_data <= pStream->lpCurrentByte);
				i_data_len = pStream->lpBitsEnd - p_data;

				if( i_data_len ) {
					*pp_data = p_data;
					*i_data = i_data_len;
					the->pCurrent = lpProgram;
					return STX_BOF;
				} // if( i_data_len ) {

				// blank packet;
				return STX_OK;
				
			} // if( the->Header.adaptation_field_control & TS_PAYLOAD_FLAG  && nLen ) {

		} // else if( the->Header.pid >= 0x10 && the->Header.pid <= 0x1ffe ) {  

		return STX_OK;

	} // block

}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE void stream_split_vt_xxx_reset(STX_HANDLE h)
{
	STX_MAP_THE(ts_split);

	ReleasePidList(the);
}


/*****************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
*****************************************************************************************/
STX_PRIVATE STX_RESULT ReadAdaptation(ts_split* the, s32 Type)
{
	s32 i,length;

	stx_bits_window* const pStream = &the->bitstream;

	the->Header.adaptation_fields ++;

	memset(&the->Adaptation,0,sizeof(the->Adaptation));

	the->Adaptation.length = stx_get_bits(pStream,8) + 1;

	if( Type == TS_ADAPTATION_FLAG ){
		if ( the->Adaptation.length > 183 ){
			return STX_FAIL;
		}
	}
	else{
		if ( the->Adaptation.length > 182 ){
			return STX_FAIL;
		}
	}

	length = the->Adaptation.length;

	if( the->Adaptation.length > 0 )	{

		the->Adaptation.discontinuity_indicator = stx_get_bits(pStream,1);
		the->Adaptation.random_access_indicator = stx_get_bits(pStream,1);
		the->Adaptation.elementry_stream_priority_indicator = stx_get_bits(pStream,1);
		the->Adaptation.pcr_flag = stx_get_bits(pStream,1);
		the->Adaptation.opcr_flag = stx_get_bits(pStream,1);
		the->Adaptation.splicing_point_flag = stx_get_bits(pStream,1);
		the->Adaptation.transport_private_data_flag = stx_get_bits(pStream,1);
		the->Adaptation.adaptation_field_extension_flag = stx_get_bits(pStream,1);

		length -= 2;

		if(the->Adaptation.pcr_flag)	{  
			the->Adaptation.program_clock_reference_base = stx_get_bits(pStream,16);
			the->Adaptation.program_clock_reference_base <<= 16;
			the->Adaptation.program_clock_reference_base |= stx_get_bits(pStream,17);
			stx_get_bits(pStream,6);
			the->Adaptation.program_clock_reference_extension = stx_get_bits(pStream,9);

//			m_qwTime = (m_Adaptation.program_clock_reference_base + 
//				m_Adaptation.program_clock_reference_extension / 300 ) / 90000;
			length -= 6;
		}

		if( the->Adaptation.opcr_flag ) {   // 
			the->Adaptation.original_program_clock_reference_base = stx_get_bits(pStream,16);
			the->Adaptation.original_program_clock_reference_base <<= 16;
			the->Adaptation.original_program_clock_reference_base |= stx_get_bits(pStream,17);
			stx_get_bits(pStream,6);
			the->Adaptation.original_program_clock_reference_extension = stx_get_bits(pStream,9);
			length -= 6;
		}

		if( the->Adaptation.splicing_point_flag ) {   // 
			length -= 1;
			the->Adaptation.splice_countdown = stx_get_bits(pStream,8);
		}

		if(the->Adaptation.transport_private_data_flag ) {  // 
			the->Adaptation.transport_private_data_length = stx_get_bits(pStream,8);
			for( i = 0; i < the->Adaptation.transport_private_data_length; i ++ ) {
				stx_get_bits(pStream,8);
			}
			length -= the->Adaptation.transport_private_data_length + 1;
		}

		if( the->Adaptation.adaptation_field_extension_flag ) {  // 

			the->Adaptation.adaptation_field_extension_length = stx_get_bits(pStream,8);

			the->Adaptation.ltw_flag = stx_get_bits(pStream,1);
			the->Adaptation.piecewise_rate_flag = stx_get_bits(pStream,1);
			the->Adaptation.seamless_splice_flag = stx_get_bits(pStream,1);
			stx_get_bits(pStream,5);
			if(the->Adaptation.ltw_flag ){
				the->Adaptation.ltw_valid_flag = stx_get_bits(pStream,1);
				the->Adaptation.ltw_offset = stx_get_bits(pStream,1);
			}
			if(the->Adaptation.piecewise_rate_flag ){
				stx_get_bits(pStream,2);
				the->Adaptation.piecewise_rate = stx_get_bits(pStream,22);
			}

			if(the->Adaptation.seamless_splice_flag){
				the->Adaptation.splice_type = stx_get_bits(pStream,4);
				the->Adaptation.dts_next_au = stx_get_bits(pStream,3);
				the->Adaptation.dts_next_au <<= 30;
				stx_get_bits(pStream,1);
				the->Adaptation.dts_next_au += stx_get_bits(pStream,15) << 15;
				stx_get_bits(pStream,1);
				the->Adaptation.dts_next_au += stx_get_bits(pStream,15);
				stx_get_bits(pStream,1);
			}

			length -= the->Adaptation.adaptation_field_extension_length + 1;

		} // if( m_Adaptation.adaptation_field_extension_flag ) {  

		for( i = 0; i < length ; i ++ ) {
			stx_get_bits(pStream,8);
		}
	}

	return STX_OK;
}


/*****************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
*****************************************************************************************/
STX_PRIVATE STX_RESULT TsProgramAssTab(ts_split* the)
{
	s32 len,i,j;

	stx_bits_window* const pStream = &the->bitstream;

	//	TRACE1("TS pid = %d\n",m_TsHeader.pid);

	the->Header.program_association_tables ++;                        // 184;

	the->PgrAssTab.table_id = stx_get_bits(pStream,8); ;                  //-1;
	the->PgrAssTab.section_syntax_indicator = stx_get_bits(pStream,1);
	stx_get_bits(pStream,1);
	stx_get_bits(pStream,2);
	the->PgrAssTab.section_length = stx_get_bits(pStream,12);              //-3;

	the->PgrAssTab.transport_stream_id = stx_get_bits(pStream,16);         //-5;

	stx_get_bits(pStream,2);
	the->PgrAssTab.version_number = stx_get_bits(pStream,5);               //
	the->PgrAssTab.current_next_indicator = stx_get_bits(pStream,1);       //-6;
	the->PgrAssTab.section_number = stx_get_bits(pStream,8);               //-7;
	the->PgrAssTab.last_section_number = stx_get_bits(pStream,8);          //-8;

	len = ( the->PgrAssTab.section_length - 8 ) >> 2;
	len = len > 44 ? 44 : len;

	memset(&the->PgrAssTab.PrgInf[0],0,sizeof(LxTsPgrInf)*44);

	j = 0;

	for( i = 0; i < len; i ++ ) {

		s32 program_number;
		s32 network_pid;

		program_number = stx_get_bits(pStream,16);
		stx_get_bits(pStream,3);
		network_pid = stx_get_bits(pStream,13);

		if( program_number && network_pid >= 0x10 && network_pid <= 0x1ffe ) {

			if ( network_pid != the->PgrAssTab.PrgInf[j].network_pid || program_number != the->PgrAssTab.PrgInf[j].program_number )  {

				the->PgrAssTab.PrgInf[j].program_number = program_number;
				the->PgrAssTab.PrgInf[j].network_pid = network_pid;

//				TRACE2(" program = %d, id = %d \n",m_TsPgrAssTab.PrgInf[j].program_number, m_TsPgrAssTab.PrgInf[j].network_pid );
				j ++;

			} // if ( network_pid != the->PgrAssTab.

		}//if( program_number && network_pid

	} // for( i = 0; i < len; i ++ ) {

	the->PgrAssTab.valid_program_num = j + 1;
	the->PgrAssTab.crc_32 = stx_get_bits(pStream,32);

	return 0;
}

/*****************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
*****************************************************************************************/
STX_PRIVATE STX_RESULT TsConditionAssTab(ts_split* the)
{
	stx_bits_window* const pStream = &the->bitstream;

	the->CAssTab.table_id = stx_get_bits(pStream,8);

	the->CAssTab.section_syntax_indicator = stx_get_bits(pStream,1);
	stx_get_bits(pStream,1);
	stx_get_bits(pStream,2);
	the->CAssTab.section_length = stx_get_bits(pStream,12);
	stx_get_bits(pStream,18);
	the->CAssTab.version_number = stx_get_bits(pStream,5);
	the->CAssTab.current_next_indicator = stx_get_bits(pStream,1);
	the->CAssTab.section_number = stx_get_bits(pStream,8);
	the->CAssTab.last_section_number = stx_get_bits(pStream,8);

	// descriptor;

	the->CAssTab.crc_32 = stx_get_bits(pStream,32);

	return 0;
}



/*****************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
*****************************************************************************************/
STX_PRIVATE STX_RESULT TsProgramMapSec(ts_split* the)
{
	s32 i;

	stx_bits_window* const pStream = &the->bitstream;

	the->MapTab.table_id = stx_get_bits(pStream,8);

	the->CAssTab.section_syntax_indicator = stx_get_bits(pStream,1);
	stx_get_bits(pStream,1); // 0
	stx_get_bits(pStream,2); // reserved;

	the->MapTab.section_length = stx_get_bits(pStream,12);

	the->MapTab.program_number = stx_get_bits(pStream,16);   // 2

	stx_get_bits(pStream,2);
	the->MapTab.version_number = stx_get_bits(pStream,5);
	the->MapTab.current_next_indicator = stx_get_bits(pStream,1);  // 3;
	the->MapTab.section_number = stx_get_bits(pStream,8);
	the->MapTab.last_section_number = stx_get_bits(pStream,8);     // 5;
	stx_get_bits(pStream,3);
	the->MapTab.PCR_PID = stx_get_bits(pStream,13);                // 7;
	stx_get_bits(pStream,4);

	the->MapTab.program_info_length = stx_get_bits(pStream,12);    // 9;

	for( i = 0; i < the->MapTab.program_info_length; i += 4 ){
		stx_get_bits(pStream,32);  // descriptor;
	}

//	int len = m_TsMapTab.section_length - m_TsMapTab.program_info_length - 13;
//
//	for( i = 0; i < len; i ++ ) {
//
//	}

	the->MapTab.CRC_32 = stx_get_bits(pStream,32);   // 4;


	return 0;
}


/*****************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
*****************************************************************************************/
STX_PRIVATE STX_RESULT TsPrivateSec(ts_split* the)
{
	return 0;
}



/*****************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
*****************************************************************************************/
STX_PRIVATE LxTsPidUnit* TsGetPid(ts_split* the,s32 nPid)
{
	if( the->Header.pFirstVideoProgram ){
		LxTsPidUnit* lpProgram = the->Header.pFirstVideoProgram;
		for(;;){
			if( !lpProgram ) {
				break;
			}
			if( lpProgram->nPid == nPid ){
				return lpProgram;
			}
			lpProgram = lpProgram->lpNext;
		}
	}

	if( the->Header.pFirstAudioProgram ){
		LxTsPidUnit* lpProgram = the->Header.pFirstAudioProgram;
		for(;;){
			if( !lpProgram ) {
				break;
			}
			if( lpProgram->nPid == nPid ){
				return lpProgram;
			}
			lpProgram = lpProgram->lpNext;
		}
		return NULL;
	}

	return NULL;
}



/*****************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
*****************************************************************************************/
STX_PRIVATE LxTsPidUnit* TsAddPid(ts_split* the,stx_gid gidType)
{
	LxTsPidUnit* lpNew;

	lpNew = (LxTsPidUnit*)smart_mallocz(sizeof(LxTsPidUnit),
		"tsparser.c::TsAddPid::lpNew");
	if( ! lpNew ) {
		return NULL;
	}

	if( IS_EQUAL_GID(gidType,MEDIATYPE_Video)  ) {
		if( ! the->Header.pFirstVideoProgram ){
			the->Header.pFirstVideoProgram = lpNew;
			return lpNew;
		}
	}
	else if( IS_EQUAL_GID(gidType,MEDIATYPE_Audio) ){
		if( ! the->Header.pFirstAudioProgram ) {
			the->Header.pFirstAudioProgram = lpNew;
			return lpNew;
		}
	}
	else{
		goto fail;
	}

	{
		LxTsPidUnit* lpProgram = 
			IS_EQUAL_GID(gidType,MEDIATYPE_Video) ? \
			the->Header.pFirstVideoProgram : the->Header.pFirstAudioProgram;

		while( lpProgram->lpNext){
			lpProgram = lpProgram->lpNext;
		}
		lpProgram->lpNext = lpNew;
	}

	return lpNew;

fail:

	if( lpNew ) {
		stx_free(lpNew);
	}

	return NULL;
}

/*****************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
*****************************************************************************************/
STX_PRIVATE void FlushPidList(ts_split* the)
{
}


/*****************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
*****************************************************************************************/
STX_PRIVATE void  ReleasePidList(ts_split* the)
{
	if( the->Header.pFirstVideoProgram ) {

		LxTsPidUnit* lpProgram = the->Header.pFirstVideoProgram;

		while( lpProgram ){
			LxTsPidUnit* lpNext = lpProgram->lpNext;
			stx_free(lpProgram);
			lpProgram = lpNext;
		}

		the->Header.pFirstVideoProgram = NULL;
	}

	if( the->Header.pFirstAudioProgram ) {

		LxTsPidUnit* lpProgram = the->Header.pFirstAudioProgram;

		while( lpProgram ){
			LxTsPidUnit* lpNext = lpProgram->lpNext;
			stx_free(lpProgram);
			lpProgram = lpNext;
		}

		the->Header.pFirstAudioProgram = NULL;
	}

	the->Header.video_num = 0;
	the->Header.audio_num = 0;
	the->Header.total_pids = 0;
}

