/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-11
***********************************************************************************/
#ifndef __FORMAT_PARSE_H__
#define __FORMAT_PARSE_H__


#include "stx_base_type.h"


#if defined( __cplusplus )
extern "C" {
#endif

	STX_RESULT parse_mpeg1_video(u8* buf, s32 i_len, STX_VIDEOINFOHEADER2* vd2 );

	STX_RESULT parse_mpeg1_audio(u8* buf, s32 i_len, STX_WAVEFORMATEXTENSIBLE* wex );


	STX_RESULT parse_mpeg2_video(u8* buf, s32 i_len, STX_VIDEOINFOHEADER2* vd2 );

	STX_RESULT parse_pcm_audio(u8* buf, s32 i_len, STX_WAVEFORMATEXTENSIBLE* wex );

	STX_RESULT parse_ac3_audio(u8* buf, s32 i_len, STX_WAVEFORMATEXTENSIBLE* wex );

	STX_RESULT parse_dts_audio(u8* buf, s32 i_len, STX_WAVEFORMATEXTENSIBLE* wex );


#if defined( __cplusplus )
}
#endif

#endif // __FORMAT_PARSE_H__




