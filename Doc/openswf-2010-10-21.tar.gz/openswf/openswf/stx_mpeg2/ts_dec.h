/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-11
***********************************************************************************/
#ifndef __STX_TS_DEC_H__
#define __STX_TS_DEC_H__


#include "stx_all_codec.h"


#if defined( __cplusplus )
extern "C" {
#endif
/**/

STX_API CREATE_STX_COM_DECL(stx_base_com,ts_source);

/**/
#if defined( __cplusplus )
}
#endif


#endif // __STX_TS_DEC_H__
