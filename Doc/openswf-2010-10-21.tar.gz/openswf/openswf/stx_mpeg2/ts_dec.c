/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-11
***********************************************************************************/

#include "ts_dec.h"

#include "stx_all.h"
#include "stx_cpuid.h"
#include "stx_sync_source.h"

#include "ps_split.h"
#include "mpeg2_parser.h"
#include "mpa1_parser.h"
#include "format_parse.h"


#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API_IMP 
CREATE_STX_COM(stx_base_com,STX_IID_BaseFilter,ts_source);



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

enum ts_status{
	em_ts_file_header,
	em_ts_flush,
	em_ts_packet_header,
	em_ts_packet,
};
typedef enum ts_status ts_status;


#define TS_PREFETCH_SIZE TSPACKET_DEFAULTSIZE*200

#define TS_PREFETCH(i_size,em_status) \
	if( !the->i_prefetch_data ) {\
		XCALL(clear,the->h_stream);\
		the->b_prefetch = TRUE;\
		the->i_prefetch_pos += the->i_prefetch_size;\
		the->i_prefetch_size = i_size;\
		the->em_ts_status = em_status;\
	}


#define TS_RESET_PREFECTH(i_pos,i_size,em_status) \
	XCALL(clear,the->h_stream);\
	the->i_prefetch_data = 0;\
	the->b_prefetch = TRUE;\
	the->i_prefetch_pos = i_pos;\
	the->i_prefetch_size = i_size;\
	the->em_ts_status = em_status

#define TS_INIT_LIMIT 2*1024*1024


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

#define INPUT_MPEG2_TS		0
#define INPUT_MPEG2_PS		1
#define INPUT_MPEG2_VIDEO	2
#define INPUT_MPEG1_SYS     3


STX_INPUT_MEDIA_TYPE_MAP_BEGIN(ts_source)
/**/MEDIA_TYPE_MAP_ITEM(MEDIATYPE_Stream,MEDIASUBTYPE_MPEG2_TRANSPORT)
/**/MEDIA_TYPE_MAP_ITEM(MEDIATYPE_Stream,MEDIASUBTYPE_MPEG2_PROGRAM)
/**/MEDIA_TYPE_MAP_ITEM(MEDIATYPE_Stream,MEDIASUBTYPE_MPEG2_VIDEO)
/**/MEDIA_TYPE_MAP_ITEM(MEDIATYPE_Stream,MEDIASUBTYPE_MPEG1System)
STX_INPUT_MEDIA_TYPE_MAP_END()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_OUTPUT_MEDIA_TYPE_MAP_BEGIN(ts_source)
/**/MEDIA_TYPE_MAP_ITEM(MEDIATYPE_Video,MEDIASUBTYPE_MPEG1Video)
/**/MEDIA_TYPE_MAP_ITEM(MEDIATYPE_Video,MEDIASUBTYPE_MPEG2_VIDEO)
/**/MEDIA_TYPE_MAP_ITEM(MEDIATYPE_Video,MEDIASUBTYPE_H264)
/**/MEDIA_TYPE_MAP_ITEM(MEDIATYPE_Audio,MEDIASUBTYPE_PCM)
/**/MEDIA_TYPE_MAP_ITEM(MEDIATYPE_Audio,MEDIASUBTYPE_DOLBY_AC3)
/**/MEDIA_TYPE_MAP_ITEM(MEDIATYPE_Audio,MEDIASUBTYPE_DOLBY_AC3_SPDIF)
/**/MEDIA_TYPE_MAP_ITEM(MEDIATYPE_Audio,MEDIASUBTYPE_DTS)
/**/MEDIA_TYPE_MAP_ITEM(MEDIATYPE_Audio,MEDIASUBTYPE_MPEG1Audio_Layer1)
/**/MEDIA_TYPE_MAP_ITEM(MEDIATYPE_Audio,MEDIASUBTYPE_MPEG1Audio_Layer2)
STX_OUTPUT_MEDIA_TYPE_MAP_END()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_INTERF(ts_output_ctx);
struct ts_output_ctx{
	b32						b_active;
	s32						pid;
	stx_base_pin*			p_input_pin;
	stx_output_pin*			p_output_pin;
	stx_media_type*			p_output_type;
	stx_stream_parser*		h_parser;
};


STX_COM_BEGIN(ts_source);
/**/
/* base source; */
/**/STX_PUBLIC( stx_base_source )
/**/
/* base filter; */
/**/STX_PUBLIC( stx_base_filter)
/**/STX_COM_DATA_DEFAULT(stx_base_filter)
/**/
/* base graph control;*/
/**/STX_PUBLIC( stx_base_control)
/**/
/* base media information; */
/**/STX_PUBLIC( stx_media_info)
/**/
/* other members; */
/**/STX_RESULT	(*init_prefetch)(ts_source* the);
/**/STX_RESULT	(*prefetch_stream)(ts_source* the, stx_sync_inf* h_sync);
/**/STX_RESULT	(*initialize_stream)(ts_source* the, stx_sync_inf* h_sync);
/**/STX_RESULT	(*dispatch_stream)(ts_source* the, stx_sync_inf* h_sync);
/**/
/**/STX_HANDLE					h_task;
/**/STX_HANDLE					h_mutex;
/**/
/**/ts_control*					h_ctrl;
/**/stream_split*				h_split;
/**/
/**/u32							i_input_type;
/**/
/**/ts_status					em_ts_status;
/**/ts_status					em_next_status;
/**/b32							b_init_pin;
/**/b32							b_flush;
/**/b32							b_end;
/**/s32							i_next_prefetch_size;
/**/
/**/b32							b_prefetch;
/**/s32							i_prefetch_size;
/**/stx_base_plugin*			h_http_plugin;
/**/stx_xio*					h_stream;
/**/stx_xio*					h_header_stream;
/**/offset_t					i_header_stream_start_pos;
/**/offset_t					i_header_stream_end_pos;
/**/
/**/sint32						i_max_pin;
/**/sint32						i_output_pin;
/**/ts_output_ctx**				pp_output_ctx;
/**/stx_media_data*				p_mdat;
/**/sint32						i_audio_idx;
/**/sint32						i_video_idx;
/**/sint32						i_audio_num;
/**/sint32						i_video_num;
/**/
/**/sint64						i_max_buffer_time;
/**/
/**/xloop*						p_audio_loop;
/**/sint64						i_buffered_audio_time;
/**/xloop*						p_video_loop;
/**/sint64						i_buffered_video_time;
/**/sint64						i_video_interval;
/**/
/**/char*						sz_file_name;
/**/sint64						i_file_size;
/**/sint64						i_file_time;
/**/s64							i_start_time;
/**/s64							i_start_sample_time;
/**/s64							i_last_sample_time;
/**/s64							i_stream_pos;
/**/s64							i_prefetch_pos;
/**/stx_xio*					p_file_io;
/**/b32							b_opened;
/**/ByteIOContext				pb;
/**/s64							i_limit;
/**/
/**/char*						prefetch_ptr;
/**/s32							i_prefetch_data;
/**/
/**/u8*							parse_buf;
/**/s32							parse_data;
/**/
/**/b32							b_stream;
/**/THEE						h_stop;
/**/
/**/
STX_COM_END();


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_COM_FUNC_DECL_DEFAULT(stx_media_info,stx_media_info_vt);
STX_COM_FUNC_DECL_DEFAULT(stx_base_control,stx_base_control_vt);
STX_COM_FUNC_DECL_DEFAULT(stx_base_filter,stx_base_filter_vt);
STX_COM_FUNC_DECL_DEFAULT(stx_base_source,stx_base_source_vt);

STX_COM_FUNCIMP_DEFAULT(ts_source,stx_media_info,stx_media_info_vt);
STX_COM_FUNCIMP_DEFAULT(ts_source,stx_base_control,stx_base_control_vt);
STX_COM_FUNCIMP_DEFAULT(ts_source,stx_base_filter,stx_base_filter_vt);
STX_COM_FUNCIMP_DEFAULT(ts_source,stx_base_source,stx_base_source_vt);


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT 
on_load_stream(ts_source* the,STX_RESULT i_result );

STX_PRIVATE void		release_output_pin(ts_source* the);

STX_PRIVATE STX_RESULT  init_prefetch(ts_source* the);
STX_PRIVATE STX_RESULT	prefetch_stream(ts_source* the, stx_sync_inf* h_sync);
STX_PRIVATE STX_RESULT	init_stream(ts_source* the, stx_sync_inf* h_sync);

STX_PRIVATE STX_RESULT  ts_prefetch_stream(ts_source* the, stx_sync_inf* h_sync);
STX_PRIVATE STX_RESULT  init_ts_prefetch(ts_source* the);
STX_PRIVATE STX_RESULT	init_ts_stream(ts_source* the, stx_sync_inf* h_sync);
STX_PRIVATE STX_RESULT	dispatch_ts_stream(ts_source* the, stx_sync_inf* h_sync);

STX_PRIVATE STX_RESULT	init_ps_stream(ts_source* the, stx_sync_inf* h_sync);
STX_PRIVATE STX_RESULT	dispatch_ps_stream(ts_source* the, stx_sync_inf* h_sync);

STX_PRIVATE STX_RESULT	init_vs_stream(ts_source* the, stx_sync_inf* h_sync);
STX_PRIVATE STX_RESULT	dispatch_vs_stream(ts_source* the, stx_sync_inf* h_sync);

STX_PRIVATE STX_RESULT	init_ss_stream(ts_source* the, stx_sync_inf* h_sync);
STX_PRIVATE STX_RESULT	dispatch_ss_stream(ts_source* the, stx_sync_inf* h_sync);

STX_PRIVATE STX_RESULT	deliver_media_sample
	(ts_source* the,s32 i_pin,stx_media_data* p_mdat,stx_sync_inf* h_sync);

STX_PRIVATE	STX_RESULT init_preload_stream(ts_source* the);
STX_PRIVATE	STX_RESULT release_preload_stream(ts_source* the);
STX_PRIVATE	STX_RESULT reset_all_preload_stream(ts_source* the);
STX_PRIVATE	STX_RESULT reset_preload_stream(xloop* p_loop, stx_output_pin* p_pin );


STX_PRIVATE STX_RESULT run_proc( ts_source* the , stx_sync_inf* h_sync );
STX_PRIVATE STX_RESULT ctrl_stop(ts_source* the);



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

/*{{{STX_MSG_ENTRY_DECLARE**************************************************/
/* to do : add msg proc entry  declaration here; */
/**/STX_MSG_ENTRY_DECLARE(on_play)
/**/STX_MSG_ENTRY_DECLARE(on_pause)
/**/STX_MSG_ENTRY_DECLARE(on_resume)
/**/STX_MSG_ENTRY_DECLARE(on_stop)
/**/STX_MSG_ENTRY_DECLARE(at_BreakPin)
/**/STX_MSG_ENTRY_DECLARE(at_play)
/**/STX_MSG_ENTRY_DECLARE(at_pause)
/**/STX_MSG_ENTRY_DECLARE(at_resume)
/**/STX_MSG_ENTRY_DECLARE(at_stop)
/**/STX_MSG_ENTRY_DECLARE(on_auto_stop)
/**/STX_MSG_ENTRY_DECLARE(on_app_stop)
/*}}}***********************************************************************/



/*{{{STX_BEGIN_MSG_MAP******************************************************/
STX_BEGIN_MSG_MAP(the_msg_data)
/* to do : add msg proc entry name here; */
/**/ON_STX_MSG(STX_MSG_Play,on_play)
/**/ON_STX_MSG(STX_MSG_Pause,on_pause)
/**/ON_STX_MSG(STX_MSG_Resume,on_resume)
/**/ON_STX_MSG(STX_MSG_Stop,on_stop)
/**/ON_STX_MSG(STX_MSG_AutoStop,on_auto_stop)
/**/ON_STX_MSG(STX_MSG_AppStop,on_app_stop)
STX_END_MSG_MAP
/*}}}***********************************************************************/


/*{{{STX_BEGIN_MSG_RESPONSE_MAP*********************************************/
STX_BEGIN_MSG_RESPONSE_MAP(the_msg_response)
/**//* to do : add msg process entry name here; */
/**/ON_STX_MSG(STX_MSG_Play,at_play)
/**/ON_STX_MSG(STX_MSG_Pause,at_pause)
/**/ON_STX_MSG(STX_MSG_Resume,at_resume)
/**/ON_STX_MSG(STX_MSG_Stop,at_stop)
/**/ON_STX_MSG(STX_MSG_BreakPin,at_BreakPin)
STX_END_MSG_RESPONSE_MAP
/*}}}***********************************************************************/


/*{{{STX_DISPATHCH_MSG_PROC*************************************************/
STX_DISPATCH_MSG_PROC( dispatch_msg,the_msg_data )
/*}}}***********************************************************************/


/*{{{STX_RESPONSE_MSG_PROC**************************************************/
STX_RESPONSE_MSG_PROC( response_msg,the_msg_response )
/*}}}***********************************************************************/




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_COM_MAP_BEGIN(ts_source)
/**/STX_COM_MAP_ITEM(STX_IID_FileSource)
/**/STX_COM_MAP_ITEM(STX_IID_BaseFilter)
/**/STX_COM_MAP_ITEM(STX_IID_BaseControl)
/**/STX_COM_MAP_ITEM(STX_IID_MediaInfo)
STX_COM_MAP_END()


STX_API_IMP	
STX_NEW_BEGIN(ts_source)
{
	STX_RESULT i_err;

	STX_SET_THE(stx_base_source);
	STX_COM_NEW_DEFAULT(stx_base_source,the->stx_base_source_vt,stx_base_source_vt,
		STX_CLSID_TsSource,STX_CATEGORY_FileSource,g_szStreamX_TsSource);

	STX_SET_THE(stx_base_filter);
	STX_COM_NEW_DEFAULT(stx_base_filter,the->stx_base_filter_vt,stx_base_filter_vt,
		STX_CLSID_TsSource,STX_CATEGORY_FileSource,g_szStreamX_TsSource);

	STX_SET_THE(stx_base_control);
	STX_COM_NEW_DEFAULT(stx_base_control,the->stx_base_control_vt,stx_base_control_vt,
		STX_CLSID_TsSource,STX_CATEGORY_FileSource,g_szStreamX_TsSource);

	STX_SET_THE(stx_media_info);
	STX_COM_NEW_DEFAULT(stx_media_info,the->stx_media_info_vt,stx_media_info_vt,
		STX_CLSID_TsSource,STX_CATEGORY_FileSource,g_szStreamX_TsSource);

	the->h_mutex = stx_create_mutex(NULL,0,NULL);
	if( !the->h_mutex ) {
		break;
	}

	the->p_mdat = stx_media_data_base_create(NULL);
	if( !the->p_mdat ) {
		break;
	}


	the->i_video_idx = -1;
	the->i_audio_idx = -1;

	the->i_max_pin = 8;
	the->pp_output_ctx = (ts_output_ctx**)xmallocz( sizeof(ts_output_ctx*)*8);
	if( !the->pp_output_ctx ) {
		break;
	}

	the->i_limit = TS_INIT_LIMIT;

	the->init_prefetch = init_prefetch;
	the->prefetch_stream = prefetch_stream;
	the->initialize_stream = init_stream;
}
STX_NEW_END()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE 
STX_QUERY_BEGIN(ts_source)
{
	STX_COM_QUERY_DEFAULT(stx_base_source,the->stx_base_source_vt);
	STX_COM_QUERY_DEFAULT(stx_base_filter,the->stx_base_filter_vt);
	STX_COM_QUERY_DEFAULT(stx_base_control,the->stx_base_control_vt);
	STX_COM_QUERY_DEFAULT(stx_media_info,the->stx_media_info_vt);
}
STX_QUERY_END()



/***************************************************************************
STX_PURE sint32 flv_release(STX_HANDLE h)
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE 
STX_DELETE_BEGIN(ts_source)
{
	/* todo : release object; */
	{
		stx_base_source* const src = &the->stx_base_source_vt;
		src->close_stream(src);
	}

	stx_close_mutex(the->h_mutex);

	SAFE_XDELETE(the->p_mdat);
	SAFE_XDELETE(the->h_ctrl);
	SAFE_XDELETE(the->h_split);

	SAFE_CALL(stx_stack_close,the->h_stop);

	STX_COM_DELETE_DEFAULT(stx_base_filter);
}
STX_DELETE_END
(
STX_COM_DELETE_BEGIN(stx_base_filter)
,
STX_COM_DELETE_END(stx_base_filter)
)



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE void stx_base_source_vt_xxx_close_stream(STX_HANDLE h)
{
	STX_MAP_THE(ts_source);
	{

		SAFE_CLOSEXIO(the->p_file_io);
		SAFE_CLOSEXIO(the->h_header_stream);
		SAFE_CLOSEXIO(the->h_stream);
		SAFE_XDELETE(the->h_http_plugin);

		release_output_pin(the);

		if( the->sz_file_name ) {
			stx_free( the->sz_file_name );
			the->sz_file_name = STX_NULL;
		}

		release_preload_stream(the);

		the->b_opened = FALSE;

		the->em_status = emStxStatusInit; // ready -> init
	}

}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
HTTP: use http stream io;
TCP: use tcp stream io;
UDP: use udp stream io;
else use local file stream io;
***************************************************************************/
STX_PURE STX_RESULT stx_base_source_vt_xxx_load_stream
(STX_HANDLE h, const char* sz_stream,stx_sync_inf* h_sync)
{
	s32				i;
	STX_RESULT		i_err;

	STX_MAP_THE(ts_source);


	if( !the->b_opened ) {

		if( !the->p_file_io  ) {

			char sz_prot[8];

			if( strlen(sz_stream) < 6 ) {
				return STX_ERR_INVALID_PARAM;
			}

			the->sz_file_name = xstrdup(sz_stream);
			if( !the->sz_file_name ) {
				return STX_FAIL;
			}


			the->h_stream = XCREATE(stx_io_stream,NULL);
			if( !the->h_stream ) {
				return STX_FAIL;
			}

			the->h_header_stream = XCREATE(stx_io_stream,NULL);
			if( !the->h_header_stream ) {
				return STX_FAIL;
			}

			memcpy(sz_prot,sz_stream,4);
			sz_prot[4] = 0;
			stx_strupr(sz_prot,5);

			if( !strcmp(sz_prot,"HTTP") ) {  // url;

				the->b_stream = TRUE;

				the->h_http_plugin = XCREATE(stx_io_as,NULL);
				if( !the->h_http_plugin ) {
					return STX_FAIL;
				}
				i_err = the->h_http_plugin->query_interf(the->h_http_plugin,STX_IID_BaseIo,(void**)&the->p_file_io);
				if( STX_OK != i_err ) {
					return i_err;
				}
				the->h_http_plugin->set_ssrc(the->h_http_plugin,the->h_ssrc);
				i_err = the->p_file_io->open(the->p_file_io,sz_stream,O_RDONLY);
				if( STX_WOUNLD_BLOCK == i_err ) {
					h_sync->i_idle = MILISEC2REFTIME(100);
				}
				if( STX_OK != i_err ) {
					return i_err;
				}

			}
			else {
				// the input stream is local file;
				the->p_file_io = stx_create_io_file();
				if( !the->p_file_io ) {
					return STX_FAIL;
				}
				i_err = the->p_file_io->open(the->p_file_io,sz_stream,O_RDONLY );
				if( STX_OK != i_err ) {
					return i_err;
				}
				the->i_file_size = the->p_file_io->size(the->p_file_io);
				the->p_file_io->seek(the->p_file_io,0,SEEK_SET);

			}// file;

		} // if( !the->p_file_io ) {
		else{

			// use open to test it ;
			i_err = the->p_file_io->open(the->p_file_io,sz_stream,O_RDONLY);
			if( STX_WOUNLD_BLOCK == i_err ) {
				h_sync->i_idle = MILISEC2REFTIME(100);
			}
			if( STX_OK != i_err ) {
				return i_err;
			}
		}

		the->b_opened = TRUE;
		the->b_init_pin = TRUE;

		if( the->i_file_size > 0 ) {
			if( the->i_limit > the->i_file_size ) {
				the->i_limit = the->i_file_size;
			}
		} // if( the->i_file_size ) {

		// init internal buffer;
		i_err = init_preload_stream(the);
		if( STX_OK != i_err ) {
			return i_err;
		}

	} // if( !the->b_opened ) {

	{

		s64 t0 = stx_get_microsec();

		for( ; ; ) {

			// prefetch data; 
			if( the->b_prefetch  ) {

				//xlog("time = %"PRId64"d\r\n", stx_get_microsec() );
				//xlog("current pos = %d\r\n",the->i_prefetch_pos); // 1271655

				do{
					i_err = the->prefetch_stream(the,h_sync);
				}while(STX_AGAIN == i_err);

				if( STX_OK != i_err ) {
					return i_err;
				}

			} // if( the->b_prefetch ) {


			i_err = the->initialize_stream(the,h_sync);
			if( i_err < 0  ) {
				return i_err;
			}

			if( !the->b_init_pin ) {

				s32 i;

				for( i = 0; i < the->i_output_pin; i ++ ) {
					stx_stream_parser* par = the->pp_output_ctx[i]->h_parser;
					par->reset(par);
				}

				the->i_header_stream_start_pos = 0;
				the->i_header_stream_end_pos = the->h_header_stream->size(the->h_header_stream);

				if( the->i_input_type == INPUT_MPEG2_TS ) {
					// reset prefetch pos and size;
					TS_RESET_PREFECTH(0,TS_PREFETCH_SIZE,em_ts_packet);
				}

				if( h_sync->i_flags == CALL_TYPE_AS ) { // notify user pear;
					i_err = on_load_stream(the,STX_OK);
					if( STX_OK != i_err ) {
						return i_err;
					}
				}

				xlog("stream open time = %"PRId64"d microsecond;\r\n", stx_get_microsec() - t0 );

				return STX_OK;  // load stream success;

			} // if( !the->b_init_pin ) {

			// STX_AGAIN, continue to do prefetch;

		} // for( ; ;) {

		// never reach;
		return i_err;

	}

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_run
( STX_HANDLE h , stx_sync_inf* h_sync )
{
	STX_RESULT		i_err;

	STX_MAP_THE(ts_source);

	stx_waitfor_mutex(the->h_mutex,INFINITE);

	i_err = run_proc(the,h_sync);

	stx_release_mutex(the->h_mutex);

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT run_proc( ts_source* the , stx_sync_inf* h_sync )
{
	s32				i;
	STX_RESULT		i_err;

	for( ; ; ) {

		// if have no audio sample, first video sample rend time;
		// or first audio sample rend time;

		// prefetch data; 
		if( the->b_prefetch  ) {

			do{
				i_err = the->prefetch_stream(the,h_sync);
			}while(STX_AGAIN == i_err);

			if( STX_OK != i_err ) {  // stream over;
				return i_err;
			} //if( STX_EOF == i_err ) {

		} // if( the->b_prefetch ) {


		i_err = the->dispatch_stream(the,h_sync);

		if( STX_ERR_PIN_NOT_CONNECTED == i_err  ) { // ignore ;
			return STX_OK;
		}

		if( i_err < 0  || STX_EOF == i_err ) {
			return i_err;
		}

		if( STX_IDLE == i_err || STX_WOUNLD_BLOCK == i_err ) {
			return i_err;
		}

		// deliver sample ???
		if( h_sync->i_result & STX_DELIVER ) {
			return STX_OK;
		}

		// STX_AGAIN, continue to do prefetch;

	} // for( ; ;) {

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_enum_input_pin
(STX_HANDLE h, sint32* i_idx, stx_base_pin** pp_pin )
{
	STX_MAP_THE(ts_source);

	return 0;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_enum_output_pin
(STX_HANDLE h,sint32* i_idx,stx_base_pin** pp_pin )
{
	STX_MAP_THE(ts_source);

	if( !i_idx ) {
		return STX_ERR_INVALID_PARAM;
	}

	if( !pp_pin ) {
		*i_idx = the->i_output_pin;
		return STX_OK;
	}

	{
		s32 idx = *i_idx;

		if( idx < 0 || idx >= the->i_output_pin ) {
			return STX_ERR_INVALID_PARAM;
		}

		{
			stx_output_pin*p = the->pp_output_ctx[idx]->p_output_pin;
			p->add_ref(p);
			*pp_pin = (stx_base_pin *)p;
		}// block

		return STX_OK;
	}// block
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_check_input_media_type
(STX_HANDLE h,stx_media_type* p_mdt)
{
	STX_MAP_THE(ts_source);
	{
		STX_RESULT		i_err;
		s32				i;
		s32				n;
		stx_gid			type;
		stx_gid			sub_type;

		stx_media_type_inf	inf;

		stx_base_filter* const h_flt = &the->stx_base_filter_vt;

		type = p_mdt->get_type(p_mdt);
		sub_type = p_mdt->get_subtype(p_mdt);

		i_err = h_flt->enum_input_media_type(h_flt,&n,NULL);
		if( STX_OK != i_err ) {
			return i_err;
		}

		for( i = 0; i < n; i ++ ) {
			i_err = h_flt->enum_input_media_type(h_flt,&i,&inf);
			if( STX_OK != i_err ) {
				return i_err;
			}
			
			if( !is_compatible_gid(type,inf.major_type) ) {
				continue;
			}

			if( !is_compatible_gid(sub_type,inf.sub_type) ) {
				continue;
			}

			return STX_OK;
		}

	}

	return STX_ERR_NOT_SUPPORT;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_check_output_media_type
(STX_HANDLE h,stx_media_type* p_mdt)
{
	STX_MAP_THE(ts_source);

	return STX_ERR_NOT_SUPPORT;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_set_input_media_type
(STX_HANDLE h, stx_media_type* p_media_type )
{
	STX_MAP_THE(ts_source);
	{
		STX_RESULT		i_err;
		stx_gid			type;
		stx_gid			sub_type;

		stx_base_filter* const h_flt = &the->stx_base_filter_vt;

		i_err = h_flt->check_input_media_type(h_flt,p_media_type);
		if( STX_OK != i_err ) {
			return STX_FAIL;
		}

		sub_type = p_media_type->get_subtype(p_media_type);

		if( IS_EQUAL_GID(sub_type,MEDIASUBTYPE_MPEG2_TRANSPORT)) {
			the->i_input_type = INPUT_MPEG2_TS;
			the->init_prefetch = init_ts_prefetch;
			the->prefetch_stream = ts_prefetch_stream;
			the->dispatch_stream = dispatch_ts_stream;
			the->initialize_stream = init_ts_stream;
		}
		else if(IS_EQUAL_GID(sub_type,MEDIASUBTYPE_MPEG2_PROGRAM)) {
			the->i_input_type = INPUT_MPEG2_PS;
			the->init_prefetch = init_ts_prefetch;  // TMP
			the->prefetch_stream = prefetch_stream;
			the->dispatch_stream = dispatch_ps_stream;
			the->initialize_stream = init_ps_stream;

			// reset the spliter and channel control;
		}
		else if(IS_EQUAL_GID(sub_type,MEDIASUBTYPE_MPEG2_VIDEO)) {
			the->i_input_type = INPUT_MPEG2_VIDEO;
			the->init_prefetch = init_ts_prefetch;// TMP
			the->prefetch_stream = prefetch_stream;
			the->dispatch_stream = dispatch_vs_stream;
			the->initialize_stream = init_vs_stream;
			// reset the spliter and channel control;
		}
		else {
			the->i_input_type = INPUT_MPEG1_SYS;
			the->init_prefetch = init_ts_prefetch;// TMP
			the->prefetch_stream = prefetch_stream;
			the->dispatch_stream = dispatch_ss_stream;
			the->initialize_stream = init_ss_stream;
			// reset the spliter and channel control;
		}

		return STX_OK;
	}

	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_set_output_media_type
(STX_HANDLE h, stx_media_type* p_media_type )
{
	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_base_filter_vt_xxx_new_segment( STX_HANDLE h)
{
	STX_MAP_THE(ts_source);

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_flush
(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	STX_MAP_THE(ts_source);

	{
		STX_RESULT	i_err;
		s32			i;

		for( i = 0; i < the->i_output_pin; i ++ ) {
			stx_output_pin* pin = the->pp_output_ctx[i]->p_output_pin;
			i_err = pin->flush(pin,i_flag,h_sync);
			if( STX_OK != i_err ) {
				return i_err;
			}
		}

		return STX_OK;
	}
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_start
(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	STX_MAP_THE(ts_source);

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_stop
(STX_HANDLE h,u32 i_flag,stx_sync_inf* h_sync)
{
	STX_RESULT			i_err;
	size_t				i;
	size_t				i_status;
	size_t*				p_status;

	STX_MAP_THE(ts_source);

	p_status = stx_stack_pop(the->h_stop);
	if( !p_status ) {
		return STX_FAIL;
	}
	i_status = *p_status;

	for( i = i_status; i < (size_t)the->i_output_pin; i++ ) {

		stx_output_pin* p = the->pp_output_ctx[i]->p_output_pin;

		if( p->is_connected(p,NULL) ) {
			i_err = p->stop(p,i_flag,h_sync);
			if( i_err != STX_OK ) {
				stx_stack_push(the->h_stop,i);
				return i_err;
			}

		}//if( p->is_connected(p,NULL) ) {

	}//for( i = *p_status; i < the->i_output_pin; i++ ) {

	return STX_OK;

}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_receive
(
 STX_HANDLE			h,
 stx_base_pin*		h_pin, // which input pin;
 stx_media_data**	pp_mdat, // output media data;
 stx_sync_inf*		h_sync 
 )
{
	return STX_ERR_NOT_SUPPORT;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_deliver
(
	STX_HANDLE			h,
	stx_base_pin*		h_pin, // which input pin;
	stx_media_data*		p_mdat, // output media data;
	stx_sync_inf*		h_sync 
)
{
	stx_output_pin* pin = (stx_output_pin*)h_sync->h_data;
	//xlog("deliver,*pp_mdat = %x\r\n",*pp_mdat);
	return pin->deliver(pin,p_mdat,h_sync);
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_xxx_transform
(
 /**/STX_HANDLE			h, 
 /**/stx_base_pin*		h_pin, 
 /**/stx_media_data*	p_mdat, 
 /**/stx_base_pin**		hh_pin,
 /**/stx_media_data**	pp_mdat, 
 /**/stx_sync_inf*		h_sync
)
{
	return STX_ECHO;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_get_property
(STX_HANDLE h,stx_xio* h_xio)
{
	return STX_ERR_NOT_SUPPORT;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_set_property
(STX_HANDLE h,stx_xio* h_xio)
{
	return STX_ERR_NOT_SUPPORT;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_filter_vt_plug_xxx_send_msg
( STX_HANDLE h, stx_base_message* p_msg )
{
	STX_RESULT	i_err;

	STX_MAP_THE(ts_source);

	do{
		u32			i_type;
		s32			i;

		i_err = dispatch_msg(h,p_msg);
		if( i_err < 0 || p_msg->is_msg_closed(p_msg)) {
			break;
		}

		i_type = p_msg->get_msg_type(p_msg);

		if( i_type & STX_MSG_TYPE_DOWNSTREAM ) {

			for( i = 0; i < the->i_output_pin; i ++ ) {
				stx_output_pin* p = the->pp_output_ctx[i]->p_output_pin;
				if( p->is_connected(p,NULL) ) {
					i_err = p->send_msg(p,p_msg);
					if( i_err < 0 || p_msg->is_msg_closed(p_msg)) {
						break;
					}
				}
			} // for( i = 0; i < the->i_output_pin; i ++ ) {
		}
		else if( i_type & STX_MSG_TYPE_UPSTREAM ) {
			stx_base_plugin* h_gph = the->p_parent;
			i_err = h_gph->send_msg(h_gph,p_msg);
		}

		if( i_err < 0 || p_msg->is_msg_closed(p_msg)) {
			break;
		}

		i_err = response_msg(h,p_msg);
		if( i_err < 0 || p_msg->is_msg_closed(p_msg)) {
			break;
		}

		i_err = STX_OK;

	}while(FALSE);

	return i_err;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_source_vt_xxx_set_pos(STX_HANDLE h,sint64 i_pos)
{
	STX_RESULT i_err;

	STX_MAP_THE(ts_source);

	i_err = STX_FAIL;


	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_source_vt_xxx_get_pos(STX_HANDLE h,sint64 *i_pos)
{
	STX_RESULT i_err;

	STX_MAP_THE(ts_source);

	i_err = STX_FAIL;


	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_source_vt_xxx_get_size(STX_HANDLE h,sint64 *i_size)
{
	STX_RESULT i_err;

	STX_MAP_THE(ts_source);

	i_err = STX_FAIL;


	return i_err;
}



/* control; */
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_PURE STX_RESULT stx_base_control_vt_xxx_get_caps
(STX_HANDLE h,stx_xio* h_xio)
{
	STX_MAP_THE(ts_source);
	{

		STX_RESULT i_err;
		stx_xini*  h_xini;
		STX_HANDLE h_key;

		i_err = STX_FAIL;
		h_xini = NULL;

		do{

			i_err = stx_ini_create(NULL,h_xio,STX_INI_READ_WRITE|STX_INI_NO_COMMENT,0,&h_xini);
			if(STX_INI_OK != i_err ) {
				break;
			}

			i_err = h_xini->create_key(h_xini,NULL,(char*)g_szCtlCaps_play_stop,(char*)g_szTrue,&h_key);
			if(STX_INI_OK != i_err ) {
				break;
			}

			i_err = h_xini->create_key(h_xini,NULL,(char*)g_szCtlCaps_pause_resume,(char*)g_szTrue,&h_key);
			if(STX_INI_OK != i_err ) {
				break;
			}

			i_err = STX_OK;

		}while(FALSE);

		if( h_xini ) {
			h_xini->close(h_xini);
		}

		return i_err;
	}
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_get_status
(STX_HANDLE h,u32* i_status)
{
	STX_MAP_THE(ts_source);

	*i_status = the->em_status;

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_play(STX_HANDLE h)
{
	STX_RESULT			i_err;
	stx_base_plugin*    plug;

	STX_MAP_THE(ts_source);

	plug = (stx_base_plugin*)&the->stx_base_filter_vt;

	// first send play message;
	{
		stx_base_message*	p_msg;
		stx_msg_cnt*		cnt;


		p_msg = XCREATE(base_msg,NULL,NULL);
		if( !p_msg) {
			return STX_FAIL;
		}

		p_msg->set_msg_type(p_msg,STX_MSG_TYPE_DOWNSTREAM);

		do{

			cnt = p_msg->get_msg_cnt(p_msg);
			cnt->msg_gid = STX_MSG_Play;
			i_err = plug->send_msg(plug,p_msg);
			if( i_err < 0 ) {
				break;
			}
			i_err = STX_OK;

		}while(FALSE);

		SAFE_XDELETE(p_msg);

		if( STX_OK != i_err ) {
			return i_err;
		}

	} //

	i_err = the->h_ssrc->reg_task(the->h_ssrc,&the->h_task,plug,TASK_NORMAL);
	if( STX_OK != i_err ) {
		return i_err;
	}

	the->em_status = emStxStatusPlay;
	// active ssrc handle;
	the->h_ssrc->reset_task(the->h_ssrc,the->h_task,0,0);

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_pause(STX_HANDLE h)
{
	// first send pause message;
	STX_RESULT			i_err;
	stx_base_filter*    p_flt;

	STX_MAP_THE(ts_source);

	stx_waitfor_mutex(the->h_mutex,INFINITE);

	do{
		i_err = STX_OK;

		if( emStxStatusPause != the->em_status ){
			i_err = STX_WOUNLD_BLOCK;
			break;
		}

		// send pause message;
		{
			stx_base_message*	p_msg;
			stx_msg_cnt*		cnt;

			p_msg=  XCREATE(base_msg,NULL,NULL);
			if( !p_msg) {
				i_err = STX_FAIL;
				break;
			}

			p_msg->set_msg_type(p_msg,STX_MSG_TYPE_DOWNSTREAM);

			cnt = p_msg->get_msg_cnt(p_msg);
			cnt->msg_gid = STX_MSG_Pause;
			p_flt = &the->stx_base_filter_vt;
			i_err = p_flt->send_msg(p_flt,p_msg);
			if( i_err < 0 ) {
				break;
			}

			SAFE_XDELETE(p_msg);

			i_err = STX_OK;

		} // block;

	}while(FALSE);

	stx_release_mutex(the->h_mutex);

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_resume(STX_HANDLE h)
{
	// first send pause message;
	STX_RESULT			i_err;
	stx_base_filter*    p_flt;

	STX_MAP_THE(ts_source);

	stx_waitfor_mutex(the->h_mutex,INFINITE);

	do{

		if( emStxStatusPause != the->em_status ){
			i_err = STX_ERR_OBJ_STATUS;
			break;
		}

		// send resume message;
		{
			stx_base_message*	p_msg;
			stx_msg_cnt*		cnt;

			p_msg=  XCREATE(base_msg,NULL,NULL);
			if( !p_msg) {
				i_err = STX_FAIL;
				break;
			}

			p_msg->set_msg_type(p_msg,STX_MSG_TYPE_DOWNSTREAM);

			cnt = p_msg->get_msg_cnt(p_msg);
			cnt->msg_gid = STX_MSG_Resume;
			p_flt = &the->stx_base_filter_vt;
			i_err = p_flt->send_msg(p_flt,p_msg);
			if( i_err < 0 ) {
				break;
			}

			SAFE_XDELETE(p_msg);

			i_err = STX_OK;

		} // block;

		the->em_status = emStxStatusPlay;

	}while(FALSE);

	stx_release_mutex(the->h_mutex);

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_set
(STX_HANDLE h,u32 i_flag,size_t i_set)
{
	STX_MAP_THE(ts_source);
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
enum { em_stop_task,em_stop_pin,em_stop_io, em_stop_msg};

STX_PRIVATE STX_RESULT ctrl_stop(ts_source* the)
{
	STX_RESULT			i_err;
	stx_base_filter*    p_flt;
	size_t				i_status;
	size_t*				p_status;

	i_err = STX_OK;
	p_flt = &the->stx_base_filter_vt;


	if( !the->h_stop ) {
		the->h_stop = stx_stack_create();
		if(!the->h_stop ) {
			return STX_FAIL;
		}
		the->h_ssrc->set_task_events(the->h_ssrc,the->h_task,ev_stop);
		stx_stack_push(the->h_stop,em_stop_task);
	} //if( !the->h_stack ) {

	p_status = stx_stack_pop(the->h_stop);
	if( !p_status ) {
		return STX_FAIL;
	}

	i_status = *p_status;

	if( em_stop_task == i_status ) {
		if( emStxStatusStop != the->em_status ){
			stx_stack_push(the->h_stop,i_status);
			return STX_WOUNLD_BLOCK;
		}
		stx_stack_push(the->h_stop,0);
		i_status = em_stop_pin;
	} // if( em_stop_task == i_status ) {


	if( em_stop_pin == i_status ) {
		stx_sync_inf sync_inf = {0};
		i_err = p_flt->stop(p_flt,0,&sync_inf); 
		if( STX_OK != i_err ) {
			if( STX_WOUNLD_BLOCK == i_err || STX_IDLE == i_err ){
				stx_stack_push(the->h_stop,i_status);
			}
			return i_err;
		}
		i_status = em_stop_io;
	} // if( em_stop_pin == i_status ) {

	if( em_stop_io == i_status ) {

		stx_base_message*	p_msg;
		stx_msg_cnt*		cnt;

		// check as io;
		if( the->h_http_plugin ) {
			i_err = the->p_file_io->stop(the->p_file_io);
			if( STX_OK != i_err ) {
				stx_stack_push(the->h_stop,i_status);
				return i_err;
			}
		}


		// send stop message;
		do{

			i_err = STX_FAIL;
			p_msg =  XCREATE(base_msg,NULL,NULL);
			if( !p_msg) {
				break;
			}

			p_msg->set_msg_type(p_msg,STX_MSG_TYPE_DOWNSTREAM);

			cnt = p_msg->get_msg_cnt(p_msg);
			cnt->msg_gid = STX_MSG_Stop;
			i_err = p_flt->send_msg(p_flt,p_msg);

			if( STX_OK != i_err ) {
				break;
			}

			stx_stack_close(the->h_stop);
			the->h_stop = NULL;

			the->em_status = emStxStatusReady;

		}while(FALSE); // block

		SAFE_XDELETE(p_msg);

		// unreg ssrc handle;
		the->h_ssrc->unreg_task(the->h_ssrc,the->h_task);

	} // if( em_stop_io == i_status ) {

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_stop(STX_HANDLE h)
{
	STX_RESULT			i_err;
	STX_MAP_THE(ts_source);

	stx_waitfor_mutex(the->h_mutex,INFINITE);
	i_err = ctrl_stop(the);
	stx_release_mutex(the->h_mutex);

	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_next(STX_HANDLE h)
{
	STX_RESULT i_err;

	STX_MAP_THE(ts_source);

	i_err = STX_FAIL;


	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_prev(STX_HANDLE h)
{
	STX_RESULT i_err;

	STX_MAP_THE(ts_source);

	i_err = STX_FAIL;


	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_control_vt_xxx_step(STX_HANDLE h)
{
	STX_RESULT i_err;

	STX_MAP_THE(ts_source);

	i_err = STX_FAIL;

	return i_err;
}

/* media info; */
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_media_info_vt_xxx_get_desc
(STX_HANDLE h, sint32* i_len, char** sz_desc )
{
	STX_RESULT i_err;

	STX_MAP_THE(ts_source);

	i_err = STX_FAIL;


	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_media_info_vt_xxx_get_total_time
(STX_HANDLE h,sint64 *i_time)
{
	STX_MAP_THE(ts_source);

	*i_time = the->i_file_time;

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_media_info_vt_xxx_get_statistic
(STX_HANDLE h,s32 * i_size,char ** pp_sz )
{
	return STX_ERR_NOT_IMP;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_media_info_vt_xxx_get_current_time
(STX_HANDLE h,sint64 *i_time)
{
	STX_RESULT i_err;

	STX_MAP_THE(ts_source);

	i_err = STX_FAIL;


	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_media_info_vt_xxx_time_to_pos
(STX_HANDLE h,sint64 i_time,offset_t * pos )
{
	STX_RESULT i_err;

	STX_MAP_THE(ts_source);

	i_err = STX_FAIL;


	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_media_info_vt_xxx_pos_to_time
(STX_HANDLE h, offset_t pos ,sint64* i_time )
{
	STX_RESULT i_err;

	STX_MAP_THE(ts_source);

	i_err = STX_FAIL;


	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT on_play(STX_HANDLE h, stx_base_message* p_msg )
{
	STX_MAP_THE(ts_source);



	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT on_stop(STX_HANDLE h,stx_base_message* p_msg)
{	
	STX_MAP_THE(ts_source);



	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_ENTRY STX_RESULT at_BreakPin(STX_HANDLE h, stx_base_message* p_msg )
{
	STX_MAP_THE(ts_source);
	{
		s32 i;
		for( i = 0; i < the->i_output_pin; i ++ ) {
			if( the->pp_output_ctx[i] ) {
				stx_output_pin* pin = the->pp_output_ctx[i]->p_output_pin;
				if( pin ) {
					pin->break_connect(pin);
				}
			}
		}
	}

	return STX_OK;
}


/***************************************************************************
STX_MSG_PROC STX_RESULT on_pause(STX_HANDLE h, stx_base_message* p_msg )
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT on_pause(STX_HANDLE h, stx_base_message* p_msg)
{
	STX_MAP_THE(ts_source);

	return STX_OK;
}

/***************************************************************************
STX_MSG_PROC STX_RESULT on_resume( STX_HANDLE h, stx_base_message* p_msg )
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT on_resume( STX_HANDLE h, stx_base_message* p_msg )
{
	STX_MAP_THE(ts_source);

	return STX_OK;
}


/***************************************************************************
STX_MSG_PROC STX_RESULT at_play(STX_HANDLE h, stx_base_message* p_msg )
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT at_play(STX_HANDLE h, stx_base_message* p_msg )
{
	STX_MAP_THE(ts_source);

	// source filter status is not correct ;
	return STX_OK;
}

/***************************************************************************
STX_MSG_PROC STX_RESULT at_stop(STX_HANDLE h,stx_base_message* p_msg)
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT at_stop(STX_HANDLE h,stx_base_message* p_msg )
{

	STX_MAP_THE(ts_source);
	{
		stx_base_source* h_src;

		h_src = &the->stx_base_source_vt;
		h_src->close_stream(h_src);

		return STX_OK;
	}

}



/***************************************************************************
STX_MSG_PROC STX_RESULT at_pause(STX_HANDLE h, stx_base_message* p_msg )
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT at_pause(STX_HANDLE h, stx_base_message* p_msg )
{
	STX_MAP_THE(ts_source);

	// source filter status is not correct ;
	return STX_OK;
}


/***************************************************************************
STX_MSG_PROC STX_RESULT at_resume( STX_HANDLE h, stx_base_message* p_msg )
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT at_resume( STX_HANDLE h, stx_base_message* p_msg )
{
	STX_MAP_THE(ts_source);

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT init_ps_stream(ts_source* the, stx_sync_inf* h_sync)
{
	return STX_ERR_NOT_IMP;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT init_vs_stream(ts_source* the, stx_sync_inf* h_sync)
{
	return STX_ERR_NOT_IMP;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT init_ss_stream(ts_source* the, stx_sync_inf* h_sync)
{
	return STX_ERR_NOT_IMP;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT dispatch_ps_stream(ts_source* the, stx_sync_inf* h_sync)
{
	return STX_ERR_NOT_IMP;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT dispatch_vs_stream(ts_source* the, stx_sync_inf* h_sync)
{
	return STX_ERR_NOT_IMP;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT dispatch_ss_stream(ts_source* the, stx_sync_inf* h_sync)
{
	return STX_ERR_NOT_IMP;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT init_media_type
(ts_source* the, s32 i_idx,u8* buf,size_t i_data)
{
	STX_RESULT		i_err;
	ts_output_ctx*	pctx;
	u8*				buf_ptr;
	u8*				buf_format;
	size_t			i_data_format;
	stx_gid			sub_type;


	pctx = the->pp_output_ctx[i_idx];
	buf_ptr = buf;

	for( ; ; ) {

		buf = buf_ptr;

		i_err = pctx->h_parser->parse(pctx->h_parser,buf,i_data,&buf_ptr);
		if( STX_EOF != i_err ) {
			return i_err;
		}

		// try to get format;
		i_err = pctx->h_parser->get_data(pctx->h_parser,the->p_mdat);
		if( STX_OK != i_err ) {
			return i_err;
		}

		sub_type = pctx->p_output_type->get_subtype(pctx->p_output_type);

		// debug;
// 		if( !IS_EQUAL_GID(MEDIASUBTYPE_MPEG2_VIDEO,sub_type) ) { // mpeg2 video;
// 			return STX_OK;
// 		}

		if( IS_EQUAL_GID(MEDIASUBTYPE_MPEG2_VIDEO,sub_type) ) { // mpeg2 video;

			STX_VIDEOINFOHEADER2 vd2;

			i_err = the->p_mdat->get_data(the->p_mdat,&buf_format,&i_data_format);
			if( STX_OK != i_err ) {
				return i_err;
			}

			INIT_MEMBER(vd2);
			i_err = parse_mpeg2_video(buf_format,i_data_format,&vd2);

			the->p_mdat->set_data(the->p_mdat,NULL,0);

			if( STX_OK != i_err ) {
				return i_err;
			}

			i_err = pctx->p_output_type->set_header(pctx->p_output_type,&vd2,sizeof(vd2));
			if( STX_OK != i_err ) {
				return i_err;
			}

			// set media type;
			i_err = pctx->p_output_pin->set_media_type(pctx->p_output_pin,pctx->p_output_type);
			if( STX_OK != i_err ) {
				return i_err;
			}

			the->i_video_num ++;

			if( the->i_video_num == 1 ) {
				pctx->b_active = TRUE;
			}

		}
		else if(IS_EQUAL_GID(MEDIASUBTYPE_MPEG1Audio,sub_type)){ // mpeg1 audio

			STX_WAVEFORMATEXTENSIBLE wex;

			i_err = the->p_mdat->get_data(the->p_mdat,&buf_format,&i_data_format);
			if( STX_OK != i_err ) {
				return i_err;
			}

			INIT_MEMBER(wex);
			i_err = parse_mpeg1_audio(buf_format,i_data_format,&wex);

			the->p_mdat->set_data(the->p_mdat,NULL,0);

			if( STX_OK != i_err ) {
				return i_err;
			}

			i_err = pctx->p_output_type->set_header(pctx->p_output_type,&wex,sizeof(wex));
			if( STX_OK != i_err ) {
				return i_err;
			}

			// set media type;
			i_err = pctx->p_output_pin->set_media_type(pctx->p_output_pin,pctx->p_output_type);
			if( STX_OK != i_err ) {
				return i_err;
			}

			the->i_audio_num ++;

			if( the->i_audio_num == 1 ) {
				pctx->b_active = TRUE;
			}

		} // else { // mpeg1 audio;

		if( buf_ptr - buf == i_data ) {

			return STX_OK;
		}

		i_data -= (buf_ptr - buf);

	} // for( ; ; ) {

	// never reach;
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT	init_stream(ts_source* the, stx_sync_inf* h_sync)
{

	STX_RESULT		i_err;


	do{
		the->i_input_type = INPUT_MPEG2_TS;

		if( INPUT_MPEG2_TS == the->i_input_type ) {

			the->init_prefetch = init_ts_prefetch;
			the->prefetch_stream = ts_prefetch_stream;
			the->dispatch_stream = dispatch_ts_stream;
			the->initialize_stream = init_ts_stream;
			the->h_split = XCREATE(ts_split,NULL);
			if( !the->h_split) {
				i_err = STX_FAIL;
				break;
			}
		} // if( INPUT_MPEG2_TS == the->i_input_type ){

		i_err = the->h_split->query_interf(the->h_split,STX_IID_TsControl,(void**)&the->h_ctrl);
		if( STX_OK != i_err ) {
			break;
		}

		// ok;

	}while(FALSE);

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT 
init_ts_stream(ts_source* the, stx_sync_inf* h_sync)
{
	STX_RESULT		i_err;
	stx_gid			major_type,sub_type;
	s32				i,pid;
	ByteIOContext*	pb;

	u8*				buf;
	size_t			i_data;

	ts_output_ctx*  h_ctx;


	INIT_BYTEIO_DIRECT(the->pb,TSPACKET_DEFAULTSIZE,the->prefetch_ptr);
	the->prefetch_ptr += TSPACKET_DEFAULTSIZE;
	the->i_prefetch_data -= TSPACKET_DEFAULTSIZE;

	// if data not enough , < 188 bytes, stream is end;
	if( the->b_end && the->i_prefetch_data < TSPACKET_DEFAULTSIZE ) {
		return STX_EOF;
	}

	pb = &the->pb;
	i_err = the->h_split->parse(the->h_split,pb->buffer,pb->buffer_size,&buf,&i_data);
	if( i_err < 0 ) {
		return i_err;
	}

	if( STX_OK == i_err ) {
		// read next packet;
		TS_PREFETCH(TS_PREFETCH_SIZE,em_ts_packet);
		return STX_AGAIN;
	}

	// STX_BOF,

	// get type;
	the->h_split->get_type(the->h_split,&pid,&major_type,&sub_type);

	if( !IS_EQUAL_GID(MEDIASUBTYPE_MPEG2_VIDEO,sub_type) 
//		&& !IS_EQUAL_GID(MEDIASUBTYPE_MPEG1Audio,sub_type) 
	) {

		// clear data;
		the->h_split->reset(the->h_split);

		TS_PREFETCH(TS_PREFETCH_SIZE,em_ts_packet);
		return STX_AGAIN;
	}

	h_ctx = NULL;

	for( i = 0; i < the->i_output_pin; i ++ ) {

		if( the->pp_output_ctx[i]->pid == pid ) {

			stx_media_type* ptype;
			void*			hdr;
			s32				i_len;

			h_ctx = the->pp_output_ctx[i];
			
			ptype = h_ctx->p_output_type;

			i_err = ptype->get_header(ptype,&hdr,&i_len);

			if( STX_OK != i_err ) {

				//xlog("init_media_type\r\n");

				// if the media type header not initialized;
				i_err = init_media_type(the,i,buf,i_data);
				if( STX_OK != i_err ) {
					return i_err;
				}

			} // if( STX_OK != i_err ) {

			break;

		} // if( the->pp_output_ctx[i]->pid == pid ) {

	} // for( i = 0; i < the->i_output_pin; i ++ ) {


	if( ! h_ctx  ) { // new pid;

		stx_mda_alloc_base_param	prop;
		stx_mem_alloc_base*			palloc;

		i_err = STX_FAIL;
		palloc = STX_NULL;

		xlog("new pid = %d\r\n",pid);

		do{

			if( the->i_output_pin >= the->i_max_pin ) {

				ts_output_ctx** pp;

				the->i_max_pin += 16;

				pp = (ts_output_ctx**)xmallocz(sizeof(ts_output_ctx*)*the->i_max_pin);
				if( !pp) {
					break;
				}

				if( the->pp_output_ctx ) {
					s32 j;
					for( j = 0; j < the->i_output_pin; j ++ ) {
						pp[j] = the->pp_output_ctx[j];
					}
					stx_free(the->pp_output_ctx);
				}

				the->pp_output_ctx = pp;			 

			} // if( the->i_output_pin >= the->i_max_pin ) {


			// if is new type, add output pin;
			h_ctx = (ts_output_ctx*)xmallocz(sizeof(ts_output_ctx));
			if( !h_ctx ) {
				break;
			}

			h_ctx->pid = pid;

			// create input pin;
			h_ctx->p_input_pin = XCREATE(stx_input_pin,NULL);
			if( !h_ctx->p_input_pin ) {
				break;
			}
			h_ctx->p_input_pin->set_parent(h_ctx->p_input_pin,(stx_base_plugin*)&the->stx_base_filter_vt);

			// create output pin;
			h_ctx->p_output_pin = XCREATE(output_pin,NULL);
			if( !h_ctx->p_output_pin ) {
				break;
			}
			h_ctx->p_output_pin->set_parent(h_ctx->p_output_pin,(stx_base_plugin*)&the->stx_base_filter_vt);

			palloc = XCREATE(stx_base_alloc,NULL);
			if( !palloc ) {
				break;
			}

			prop.i_mda_num = 30; 
			prop.i_mda_size = 64*1024; 

			i_err = palloc->set_param(palloc,&prop,sizeof(prop));
			if( STX_OK != i_err ) {
				break;
			}

			i_err = h_ctx->p_output_pin->set_mem_allocator(h_ctx->p_output_pin,palloc);
			if( STX_OK != i_err ) {
				break;
			}

			i_err = STX_FAIL;

			// create media type;
			h_ctx->p_output_type = XCREATE(base_media_type,NULL,NULL);
			if( !h_ctx->p_output_type){
				break;
			}
			h_ctx->p_output_type->set_type(h_ctx->p_output_type,major_type);
			h_ctx->p_output_type->set_subtype(h_ctx->p_output_type,sub_type);

			// create stream parser;
			if( IS_EQUAL_GID(MEDIASUBTYPE_MPEG2_VIDEO,sub_type) ) {
				h_ctx->h_parser = XCREATE(mpeg2_parser,NULL);
			}
			else {
				h_ctx->h_parser = XCREATE(mpa1_parser,NULL);
			}
			if( !h_ctx->h_parser ) {
				i_err = STX_FAIL;
				break;
			}

			i_err = STX_OK;

		}while(FALSE);


		SAFE_XDELETE(palloc);

		if( STX_OK != i_err ){
			if( h_ctx ) {
				SAFE_XDELETE(h_ctx->p_input_pin);
				SAFE_XDELETE(h_ctx->p_output_pin);
				SAFE_XDELETE(h_ctx->p_output_type);
				SAFE_XDELETE(h_ctx->h_parser);
				stx_free(h_ctx);
			}
			return STX_FAIL;
		}//if( STX_OK != i_err ){

		the->pp_output_ctx[the->i_output_pin++] = h_ctx;

		i_err = init_media_type(the,i,buf,i_data);
		if( STX_OK != i_err ) {
			return i_err;
		}

	} // if( ! h_ctx  ) {


	{// 2 MB data limit;
		
		if( the->i_prefetch_pos >= the->i_limit || ( the->i_video_num && the->i_audio_num ) ) { 
			// decide maximize data size to prefetch;
			// if parsed data enough, close b_init_pin flag, return;

			the->b_init_pin = FALSE;
			return STX_OK;

		}//if( the->i_prefetch_pos >= i_limit ) {

	}// block

	TS_PREFETCH(TS_PREFETCH_SIZE,em_ts_packet);

	return STX_AGAIN;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT 
dispatch_ts_stream(ts_source* the, stx_sync_inf* h_sync)
{
	STX_RESULT		i_err;
	stx_gid			major_type,sub_type;
	s32				i,pid;
	u8*				buf;
	ByteIOContext*	pb;


	if( !the->parse_data ) {

		INIT_BYTEIO_DIRECT(the->pb,TSPACKET_DEFAULTSIZE,the->prefetch_ptr);
		the->prefetch_ptr += TSPACKET_DEFAULTSIZE;
		the->i_prefetch_data -= TSPACKET_DEFAULTSIZE;

		// if data not enough , < 188 bytes, stream is end;
		if( the->b_end && the->i_prefetch_data < TSPACKET_DEFAULTSIZE ) {
			return deliver_media_sample(the,0,NULL,h_sync);
		}

		//
		pb = &the->pb;
		i_err = the->h_split->parse(the->h_split,pb->buffer,pb->buffer_size,
			&the->parse_buf,&the->parse_data);
		if( i_err < 0 ) {
			return i_err;
		}

		if( STX_OK == i_err ) {
			// read next packet;
			TS_PREFETCH(TS_PREFETCH_SIZE,em_ts_packet);
			return STX_AGAIN;
		}

	} // if( !the->parse_data ) {

	// get type;
	the->h_split->get_type(the->h_split,&pid,&major_type,&sub_type);

	buf = the->parse_buf;


	for( i = 0 ; i < the->i_output_pin; i ++ ) {

		ts_output_ctx*		pctx = the->pp_output_ctx[i];
		stx_media_type*		ptype = pctx->p_output_type;

		stx_gid				out_sub_type = ptype->get_subtype(ptype);


		if( pctx->b_active && pctx->pid == pid ) {

			// mpeg2 ps arrange;
			stx_gid				out_major_type;

			stx_stream_parser*	h_parser = pctx->h_parser;
			stx_output_pin*		pin = pctx->p_output_pin;

			out_major_type = ptype->get_type(ptype);

			i_err = h_parser->parse(h_parser,buf,the->parse_data,&the->parse_buf);
			if( i_err < 0 ) {
				return i_err;
			}
			if( STX_OK == i_err ) {
				the->parse_data = 0;
				TS_PREFETCH(TS_PREFETCH_SIZE,em_ts_packet);
				return STX_AGAIN;
			}

			the->parse_data -= (the->parse_buf - buf);

			if( STX_EOF == i_err ) {  // deliver media sample;
				
				stx_media_data* p_mdat;

				i_err = pin->get_media_data(pin,&p_mdat,INFINITE);
				if( STX_OK != i_err ) {
					return i_err;
				}

				//xlog("ts_dec::get media data::%x\r\n",p_mdat);

				i_err = h_parser->get_data(h_parser,p_mdat);
				if( STX_OK != i_err ) {
					return i_err;
				}

				// get time code, set time code;
				{
					s64 pts,dts;
					pts = 0;
					dts = 0;
					the->h_split->get_time(the->h_split,&pts,&dts);
					p_mdat->set_time(p_mdat,PTS2REFTIME(pts),PTS2REFTIME(dts));
				}

				i_err = deliver_media_sample(the,i,p_mdat,h_sync);
				if( i_err < 0 ) {
					return i_err;
				}

			} //if( STX_EOF == i_err ) {

			break;

		} // if( pctx->b_active && pctx->pid == pid ) {

	}// for( i = 0 ; i < the->i_output_pin; i ++ ) {

	if( i == the->i_output_pin ) {
		the->parse_data = 0;
	}

	if( !the->parse_data ) {
		TS_PREFETCH(TS_PREFETCH_SIZE,em_ts_packet);
	}

	return i_err;

}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT prefetch_stream(ts_source* the, stx_sync_inf* h_sync)
{
	STX_RESULT		i_err;
	stx_io_op_fetch	inf;
	size_t			i_read;
	offset_t		i_pos;


	if( ! the->b_init_pin ) {

		if( the->i_prefetch_pos >= the->i_header_stream_start_pos && 
			the->i_prefetch_pos + the->i_prefetch_size <= the->i_header_stream_end_pos ) {

				// test write buffer size;get write buffer address;
				INIT_MEMBER(inf);
				inf.i_max = (u32)the->i_prefetch_size;
				inf.i_op = (u32)the->i_prefetch_size;
				i_err = XCALL(get,the->h_stream,STX_IO_PREWRITE,&inf);
				if( STX_OK != i_err ) {
					// buf not enough ???
					return i_err;
				}

				// seek to correct position;
				i_pos = the->i_prefetch_pos - the->i_header_stream_start_pos;
				the->h_header_stream->seek(the->h_header_stream,i_pos,SEEK_SET);

				// direct read data into write stream buffer;
				i_err = the->h_header_stream->read(the->h_header_stream,inf.buf,the->i_prefetch_size,&i_read);
				if( STX_OK != i_err ) {
					return i_err;
				}

				// flush data;
				if( the->b_flush ) {
					the->b_flush = FALSE;
					the->i_prefetch_pos += the->i_prefetch_size;
					the->i_prefetch_size = the->i_next_prefetch_size;
					the->em_ts_status = the->em_next_status;
					return STX_AGAIN;
				}

				the->b_prefetch = FALSE;

				//INIT_BYTEIO_DIRECT(the->pb,the->i_prefetch_size,inf.buf);
				the->prefetch_ptr = inf.buf;
				the->i_prefetch_data = the->i_prefetch_size;

				return STX_OK;

		} //if( the->i_packet_pos >=

	} // if( ! the->b_init_pin ) {

	// test read data;
	INIT_MEMBER(inf);
	inf.i_op = (u32)the->i_prefetch_size;
	i_err = XCALL(get,the->p_file_io,STX_IO_PREFETCH,&inf);
	if( STX_OK != i_err ) {
		return i_err;
	}

	// if not enough data, return and wait some time;
	if( inf.i_data < inf.i_op ) {

		s64 i_idle = 10;// set default 10 ms;

		if( inf.i_pos + inf.i_data == inf.i_size ) {
			the->i_prefetch_size = (size_t)inf.i_data;
			the->b_end = TRUE;
		}

		if( inf.i_rate ){
			i_idle = (s64)(inf.i_op - inf.i_data);
			i_idle = i_idle * 1000  / inf.i_rate ;
		}

		if( i_idle > 100 ) {
			i_idle = 100;
		}
		if( i_idle < 10 ) {
			i_idle = 10;
		}

		h_sync->i_idle =  MILISEC2REFTIME( i_idle ); 
		return STX_WOUNLD_BLOCK;

	} // if( inf.i_available_data < the->i_prefetch_size ) {

	// get write stream buffer pointer;
	INIT_MEMBER(inf);
	inf.i_max = (u32)the->i_prefetch_size; // avoid buffer overflow;
	inf.i_op = (u32)the->i_prefetch_size;
	i_err = XCALL(get,the->h_stream,STX_IO_PREWRITE,&inf);
	if( STX_OK != i_err ) {
		return i_err;
	}

	// read data directly into write stream buffer;
	do{
		i_err = the->p_file_io->read(the->p_file_io,inf.buf,the->i_prefetch_size,&i_read);

	}while(STX_AGAIN == i_err);

	if( STX_OK != i_err ) {
		return i_err;
	}
	if( (s32)i_read < the->i_prefetch_size ) {
		return STX_EOF;
	}
	the->i_stream_pos += i_read;

	// flush data; need not decode;
	if( the->b_flush ) {
		the->b_flush = FALSE;
		the->i_prefetch_pos += the->i_prefetch_size;
		the->i_prefetch_size = the->i_next_prefetch_size;
		the->em_ts_status = the->em_next_status;
		return STX_AGAIN;
	}

	if( the->b_init_pin ) {// save data at the h_header_stream;
		size_t i_write;
		i_err = the->h_header_stream->write(the->h_header_stream,inf.buf,i_read,&i_write );
		if( STX_OK != i_err ){
			return i_err;
		}
	}

	the->b_prefetch = FALSE;

	//INIT_BYTEIO_DIRECT(the->pb,the->i_prefetch_size,inf.buf);
	the->prefetch_ptr = inf.buf;
	the->i_prefetch_data = the->i_prefetch_size;

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT  init_prefetch(ts_source* the)
{
	STX_RESULT		i_err;
	stx_io_op_param	inf;


	// test read buffer size;
	INIT_MEMBER(inf);
	inf.i_buf_size = TS_PREFETCH_SIZE;
	i_err = the->p_file_io->set(the->p_file_io,STX_XIO_SET_BUF_SIZE,&inf);
	if( STX_OK != i_err ) {
		return i_err;
	}

	// test write buffer size;
	INIT_MEMBER(inf);
	inf.i_buf_size = TS_PREFETCH_SIZE;
	i_err = the->h_stream->set(the->h_stream,STX_XIO_SET_BUF_SIZE,&inf);
	if( STX_OK != i_err ) {
		return i_err;
	}

	TS_RESET_PREFECTH(0,TS_PREFETCH_SIZE,em_ts_packet);

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT  init_ts_prefetch(ts_source* the)
{
	STX_RESULT		i_err;
	stx_io_op_param	inf;


	// test read buffer size;
	INIT_MEMBER(inf);
	inf.i_buf_size = TS_PREFETCH_SIZE;
	i_err = the->p_file_io->set(the->p_file_io,STX_XIO_SET_BUF_SIZE,&inf);
	if( STX_OK != i_err ) {
		return i_err;
	}

	// test write buffer size;
	INIT_MEMBER(inf);
	inf.i_buf_size = TS_PREFETCH_SIZE;
	i_err = the->h_stream->set(the->h_stream,STX_XIO_SET_BUF_SIZE,&inf);
	if( STX_OK != i_err ) {
		return i_err;
	}

	TS_RESET_PREFECTH(0,TS_PREFETCH_SIZE,em_ts_packet);

	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT ts_prefetch_stream(ts_source* the, stx_sync_inf* h_sync)
{
	STX_RESULT		i_err;
	stx_io_op_fetch	inf;
	size_t			i_read;
	offset_t		i_pos;


	if( ! the->b_init_pin ) {

		if( the->i_prefetch_pos >= the->i_header_stream_start_pos && 
			the->i_prefetch_pos + the->i_prefetch_size <= the->i_header_stream_end_pos ) {

				// test write buffer size;get write buffer address;
				INIT_MEMBER(inf);
				inf.i_max = (u32)the->i_prefetch_size;
				inf.i_op = (u32)the->i_prefetch_size;
				i_err = XCALL(get,the->h_stream,STX_IO_PREWRITE,&inf);
				if( STX_OK != i_err ) {
					// buf not enough ???
					return i_err;
				}

				// seek to correct position;
				i_pos = the->i_prefetch_pos - the->i_header_stream_start_pos;
				the->h_header_stream->seek(the->h_header_stream,i_pos,SEEK_SET);

				// direct read data into write stream buffer;
				i_err = the->h_header_stream->read(the->h_header_stream,inf.buf,the->i_prefetch_size,&i_read);
				if( STX_OK != i_err ) {
					return i_err;
				}

				// flush data;
				if( the->b_flush ) {
					the->b_flush = FALSE;
					the->i_prefetch_pos += the->i_prefetch_size;
					the->i_prefetch_size = the->i_next_prefetch_size;
					the->em_ts_status = the->em_next_status;
					return STX_AGAIN;
				}

				the->b_prefetch = FALSE;

				//INIT_BYTEIO_DIRECT(the->pb,the->i_prefetch_size,inf.buf);
				the->prefetch_ptr = inf.buf;
				the->i_prefetch_data = the->i_prefetch_size;

				return STX_OK;

		} //if( the->i_packet_pos >=

	} // if( ! the->b_init_pin ) {

	// test read data;
	INIT_MEMBER(inf);
	inf.i_op = (u32)the->i_prefetch_size;
	i_err = XCALL(get,the->p_file_io,STX_IO_PREFETCH,&inf);
	if( STX_OK != i_err ) {
		return i_err;
	}

	// if not enough data, return and wait some time;
	if( inf.i_data < inf.i_op ) {

		s64 i_idle = 10;// set default 10 ms;

		if( inf.i_pos + inf.i_data == inf.i_size ) {
			the->i_prefetch_size = (size_t)inf.i_data;
			the->b_end = TRUE;
		}

		if( inf.i_rate ){
			i_idle = (s64)(inf.i_op - inf.i_data);
			i_idle = i_idle * 1000  / inf.i_rate ;
		}

		if( i_idle > 100 ) {
			i_idle = 100;
		}
		if( i_idle < 10 ) {
			i_idle = 10;
		}

		h_sync->i_idle =  MILISEC2REFTIME( i_idle ); 
		return STX_WOUNLD_BLOCK;

	} // if( inf.i_available_data < the->i_prefetch_size ) {

	// get write stream buffer pointer;
	INIT_MEMBER(inf);
	inf.i_max = (u32)the->i_prefetch_size; // avoid buffer overflow;
	inf.i_op = (u32)the->i_prefetch_size;
	i_err = XCALL(get,the->h_stream,STX_IO_PREWRITE,&inf);
	if( STX_OK != i_err ) {
		return i_err;
	}

	// read data directly into write stream buffer;
	do{
		i_err = the->p_file_io->read(the->p_file_io,inf.buf,the->i_prefetch_size,&i_read);

	}while(STX_AGAIN == i_err);

	if( STX_OK != i_err ) {
		return i_err;
	}
	if( (s32)i_read < the->i_prefetch_size ) {
		return STX_EOF;
	}
	the->i_stream_pos += i_read;

	// flush data; need not decode;
	if( the->b_flush ) {
		the->b_flush = FALSE;
		the->i_prefetch_pos += the->i_prefetch_size;
		the->i_prefetch_size = the->i_next_prefetch_size;
		the->em_ts_status = the->em_next_status;
		return STX_AGAIN;
	}

	if( the->b_init_pin ) {// save data at the h_header_stream;
		size_t i_write;
		i_err = the->h_header_stream->write(the->h_header_stream,inf.buf,i_read,&i_write );
		if( STX_OK != i_err ){
			return i_err;
		}
	}

	the->b_prefetch = FALSE;

	//INIT_BYTEIO_DIRECT(the->pb,the->i_prefetch_size,inf.buf);
	the->prefetch_ptr = inf.buf;
	the->i_prefetch_data = the->i_prefetch_size;

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE void release_output_pin(ts_source* the)
{
	s32 i;

	if( the->pp_output_ctx ) {

		stx_base_message* h_msg;

		h_msg =  XCREATE(base_msg,NULL,NULL);
		h_msg->set_msg_type(h_msg,STX_MSG_TYPE_DOWNSTREAM);
		h_msg->get_msg_cnt(h_msg)->msg_gid = STX_MSG_BreakPin;
		stx_base_filter_vt_plug_xxx_send_msg(&the->stx_base_filter_vt,h_msg);
		SAFE_XDELETE(h_msg);

		for( i = 0; i < the->i_output_pin; i ++ ) {

			ts_output_ctx* p = the->pp_output_ctx[i];

			if( p ) {
				SAFE_XDELETE(p->p_input_pin);
				SAFE_XDELETE(p->p_output_pin);
				SAFE_XDELETE(p->p_output_type);
				SAFE_XDELETE(p->h_parser);
				stx_free(p);
			} //if( p ) {
		}// for( i = 0; i < the->i_output_pin; i ++ ) {

		stx_free(the->pp_output_ctx);

		the->pp_output_ctx = NULL;

		the->i_output_pin = 0;
		the->i_max_pin = 0;

	} // if( the->pp_output_ctx ) {

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT	deliver_media_sample
(ts_source* the,s32 i_pin,stx_media_data* p_mdat,stx_sync_inf* h_sync)
{
	STX_RESULT		i_err;
	stx_base_pin*	p_input;
	stx_output_pin* pin;

	if( !p_mdat ) {
		p_mdat = (stx_media_data*)xloopPull( the->p_video_loop );
		if( !p_mdat) {
			return STX_EOF;
		}
		p_input = the->pp_output_ctx[the->i_video_idx]->p_input_pin;
		pin = the->pp_output_ctx[the->i_video_idx]->p_output_pin;
	}
	else {
		p_input = the->pp_output_ctx[i_pin]->p_input_pin;
		pin = the->pp_output_ctx[i_pin]->p_output_pin;
	}
	
	if( !pin->is_connected(pin,NULL) ) {
		h_sync->i_result |= STX_DELIVER;
		RESET_XENTRY(h_sync,&the->stx_base_filter_vt);
		return STX_OK;
	}

	if( i_pin == the->i_video_idx && the->i_output_pin > 1 ) {

		xloopPush(the->p_video_loop,p_mdat);

		if( xloopIsFull(the->p_video_loop) || the->i_start_time) {
			p_mdat = (stx_media_data*)xloopPull( the->p_video_loop );
			if( !p_mdat) {
				return STX_FAIL;
			}
		}
		else{ // wait for enough video startup delay time;
			return STX_AGAIN;
		}

	} //if( i_pin == the->i_video_idx && the->i_output_pin > 1 ) {

	RESET_XENTRY(h_sync,&the->stx_base_filter_vt);
	i_err = XCALL(deliver,pin,p_mdat,h_sync);
	if( i_err < 0 ) {
		XCALL(release_media_data,pin,p_mdat);
		return i_err;
	}
	the->i_last_sample_time = p_mdat->get_time(p_mdat,NULL);
	h_sync->i_result |= STX_DELIVER;
	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE	STX_RESULT reset_all_preload_stream(ts_source* the)
{
	if( the->p_video_loop && the->i_video_idx != -1  ) {
		reset_preload_stream( the->p_video_loop,
			the->pp_output_ctx[the->i_video_idx]->p_output_pin);
	}

	if( the->p_audio_loop && the->i_audio_idx != -1 ) {
		reset_preload_stream( the->p_audio_loop,
			the->pp_output_ctx[the->i_audio_idx]->p_output_pin);
	}

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE	STX_RESULT reset_preload_stream
( xloop* p_loop, stx_output_pin* p_pin )
{

	STX_RESULT			i_err;

	stx_media_data*		p_data;

	for( ; ; ) {

		p_data = (stx_media_data*)xloopPull(p_loop);
		if( !p_data ) {
			break;
		}

		p_data->set_data(p_data,NULL,0);

		i_err = p_pin->release_media_data(p_pin,p_data);
		if( STX_OK != i_err ) {
			return i_err;
		}
	} // for( ; ; ) {

	xloopFlush(p_loop);

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE	STX_RESULT init_preload_stream(ts_source* the)
{
	the->p_audio_loop = xloopCreate( STX_MAX_AUDIO_DEPTH );
	if( !the->p_audio_loop ) {
		return STX_FAIL;
	}

	the->p_video_loop = xloopCreate( STX_MAX_VIDEO_DEPTH );
	if( !the->p_video_loop ) {
		return STX_FAIL;
	}

	if( STX_OK != the->init_prefetch(the) ) {
		return STX_FAIL;
	}

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE	STX_RESULT release_preload_stream(ts_source* the)
{
	reset_all_preload_stream(the);

	if( the->p_audio_loop ) {
		xloopRelease(the->p_audio_loop);
		the->p_audio_loop = STX_NULL;
	}

	if( the->p_video_loop ) {
		xloopRelease(the->p_video_loop);
		the->p_video_loop = STX_NULL;
	}

	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT 
on_load_stream(ts_source* the,STX_RESULT i_result )
{
	STX_RESULT			i_err;
	stx_base_message*	p_msg;
	stx_msg_cnt			cnt;
	u32					i_msg_type;
	char				sz_inf[1024];

	p_msg =  XCREATE(base_msg,NULL,NULL);
	if( !p_msg ) {
		return STX_FAIL;
	}

	do{

		cnt.msg_gid = STX_MSG_OnLoadSource;
		cnt.param.i_param[0] = (size_t)i_result;
		cnt.param.i_param[1] = (size_t)&the->stx_base_source_vt;

		p_msg->set_msg_cnt(p_msg,&cnt);

		i_msg_type = STX_MSG_TYPE_UPSTREAM | STX_MSG_TYPE_DIRECT;
		p_msg->set_msg_type(p_msg,i_msg_type);

		if( STX_OK == i_result ) {
			stx_sprintf(sz_inf,sizeof(sz_inf),
				"load stream success. message sender: %s",g_szStreamX_TsSource);
		}
		else {
			stx_sprintf(sz_inf,sizeof(sz_inf),
				"load stream fail. message sender: %s",g_szStreamX_TsSource);
		}

		i_err = p_msg->set_msg_text(p_msg,sz_inf);
		if( STX_OK != i_err ){
			break;
		}

		i_err = the->p_parent->send_msg(the->p_parent,p_msg);
		if( STX_OK != i_err ){
			break;
		}

		i_err = STX_OK;

	}while(FALSE);

	SAFE_XDELETE(p_msg);

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT: 
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT 
on_auto_stop(STX_HANDLE h,stx_base_message* p_msg )
{

	STX_MAP_THE(ts_source);
	{
		STX_HANDLE h_stack = p_msg->get_stack(p_msg);

		// push plugin interface pointer;
		stx_stack_push(h_stack,(size_t)&the->stx_base_filter_vt);

		return STX_OK;
	}
}




/***************************************************************************
RETURN VALUE:
INPUT: 
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_PROC STX_RESULT 
on_app_stop(STX_HANDLE h,stx_base_message* p_msg )
{
	STX_MAP_THE(ts_source);
	{
		stx_msg_cnt* p_cnt = p_msg->get_msg_cnt(p_msg);

		p_msg->set_msg_close(p_msg);

		// must be as io; send stop message to app handler;
		return stx_base_plugin_stop(
			(stx_base_plugin*)&the->stx_base_filter_vt,
			(STX_RESULT)p_cnt->param.i_param[0],
			FALSE);
	}

}