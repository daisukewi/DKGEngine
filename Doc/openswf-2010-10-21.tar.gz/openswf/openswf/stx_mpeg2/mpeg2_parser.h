/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-11
***********************************************************************************/

#ifndef __MPEG2_PARSER_H__
#define __MPEG2_PARSER_H__


#include "base_class.h"


#if defined( __cplusplus )
extern "C" {
#endif


	STX_API	STX_COM(mpeg2_parser);


	STX_API	CREATE_STX_COM_DECL(stx_stream_parser,mpeg2_parser);



#if defined( __cplusplus )
}
#endif

#endif // __MPEG2_PARSER_H__