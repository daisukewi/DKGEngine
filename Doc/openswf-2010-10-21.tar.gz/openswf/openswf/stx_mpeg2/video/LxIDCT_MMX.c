// LxIDCT_MMX.cpp: implementation of the LxIDCT_MMX class.
//
//////////////////////////////////////////////////////////////////////

#include "LxIDCT.h"
#include "LxIDCT_MMX.h"

#include "stx_cpuid.h"

/******************************************
idct begin
*******************************************/


#define BITS_INV_ACC 4 // 4 or 5 for IEEE
#define SHIFT_INV_ROW 16 - BITS_INV_ACC
#define SHIFT_INV_COL 1 + BITS_INV_ACC

//#define SHIFT_PREIDCT 13
//#define SHIFT_LEFT (16-SHIFT_PREIDCT)

// const s16 RND_INV_ROW = 1024 * (6 - BITS_INV_ACC); //1 << (SHIFT_INV_ROW-1)
// const s16 RND_INV_COL = 16 * (BITS_INV_ACC - 3); // 1 << (SHIFT_INV_COL-1)
// const s16 RND_INV_CORR = RND_INV_COL - 1; // correction -1.0 and round

#define  RND_INV_ROW (1024 * (6 - BITS_INV_ACC)) //1 << (SHIFT_INV_ROW-1)
#define  RND_INV_COL ( 16 * (BITS_INV_ACC - 3))  // 1 << (SHIFT_INV_COL-1)
#define  RND_INV_CORR ( RND_INV_COL - 1) // correction -1.0 and round

#define PI 3.14159265359


DECLARE_ALIGNED_16( static s16, i_adder_128[8] ) =
{128,128,128,128,128,128,128,128}; // 

DECLARE_ALIGNED_16( static s16, one_corr[8] ) =
{
	1, 1, 1, 1, 1, 1, 1, 1,
};

DECLARE_ALIGNED_16( static s16, round_inv_row[8] ) =
{
	RND_INV_ROW, 0, RND_INV_ROW, 0, 0, 0, 0, 0
};

DECLARE_ALIGNED_16( static s16, round_inv_col[8] ) =
{
	RND_INV_COL, RND_INV_COL, RND_INV_COL, RND_INV_COL,
	RND_INV_COL, RND_INV_COL, RND_INV_COL, RND_INV_COL
};

DECLARE_ALIGNED_16( static s16, round_inv_corr[8] ) =
{
	RND_INV_CORR, RND_INV_CORR, RND_INV_CORR, RND_INV_CORR,
	RND_INV_CORR, RND_INV_CORR, RND_INV_CORR, RND_INV_CORR
};

DECLARE_ALIGNED_16( static s16, tg_1_16[8] ) =
{
	13036, 13036, 13036, 13036,
	13036, 13036, 13036, 13036
}; // tg * (2<<16) + 0.5

DECLARE_ALIGNED_16( static s16, tg_2_16[8] ) =
{
	27146, 27146, 27146, 27146,
	27146, 27146, 27146, 27146
}; // tg * (2<<16) + 0.5

DECLARE_ALIGNED_16( static s16, tg_3_16[8] ) =
{
	-21746, -21746, -21746, -21746,
	-21746, -21746, -21746, -21746
}; // tg * (2<<16) + 0.5

DECLARE_ALIGNED_16( static s16, cos_4_16[8] ) =
{
	-19195, -19195, -19195, -19195,
	-19195, -19195, -19195, -19195
}; // cos * (2<<16) + 0.5


//-----------------------------------------------------------------------------
// Table for rows 0,4 - constants are multiplied on cos_4_16
DECLARE_ALIGNED_16( static s16, tab_i[] ) =
//static s16 tab_i_04[] = 
{
	16384,21407,16384,8867, //movq -> w05 w04 w01 w00
		16384, 8867, -16384, -21407, // w07 w06 w03 w02
		16384, -8867, 16384, -21407, // w13 w12 w09 w08
		-16384, 21407, 16384, -8867, // w15 w14 w11 w10
		22725, 19266, 19266, -4520, // w21 w20 w17 w16
		12873, 4520, -22725, -12873, // w23 w22 w19 w18
		12873, -22725, 4520, -12873, // w29 w28 w25 w24
		//4520, 19266, 19266, -22725}; // w31 w30 w27 w26
		4520, 19266, 19266, -22725,
		// Table for rows 1,7 - constants are multiplied on cos_1_16
		//static s16 tab_i_17[] = 
		//{
		22725, 29692, 22725, 12299, //movq -> w05 w04 w01 w00
		22725, 12299, -22725, -29692, // w07 w06 w03 w02
		22725, -12299, 22725, -29692, // w13 w12 w09 w08
		-22725, 29692, 22725, -12299, // w15 w14 w11 w10
		31521, 26722, 26722, -6270, // w21 w20 w17 w16
		17855, 6270, -31521, -17855, // w23 w22 w19 w18
		17855, -31521, 6270, -17855, // w29 w28 w25 w24
		//6270, 26722, 26722, -31521}; // w31 w30 w27 w26
		6270, 26722, 26722, -31521,//}; // w31 w30 w27 w26
		// Table for rows 2,6 - constants are multiplied on cos_2_16
		//static s16 tab_i_26[] = 
		//{
		21407, 27969, 21407, 11585, //movq -> w05 w04 w01 w00
		21407, 11585, -21407, -27969, // w07 w06 w03 w02
		21407, -11585, 21407, -27969, // w13 w12 w09 w08
		-21407, 27969, 21407, -11585, // w15 w14 w11 w10
		29692, 25172, 25172, -5906, // w21 w20 w17 w16
		16819, 5906, -29692, -16819, // w23 w22 w19 w18
		16819, -29692, 5906, -16819, // w29 w28 w25 w24
		//5906, 25172, 25172, -29692}; // w31 w30 w27 w26
		5906, 25172, 25172, -29692,//}; // w31 w30 w27 w26
		// Table for rows 3,5 - constants are multiplied on cos_3_16
		//static s16 tab_i_35[] =
		//{
		19266, 25172, 19266, 10426, //movq -> w05 w04 w01 w00
		19266, 10426, -19266, -25172, // w07 w06 w03 w02
		19266, -10426, 19266, -25172, // w13 w12 w09 w08
		-19266, 25172, 19266, -10426, // w15 w14 w11 w10
		26722, 22654, 22654, -5315, // w21 w20 w17 w16
		15137, 5315, -26722, -15137, // w23 w22 w19 w18
		15137, -26722, 5315, -15137, // w29 w28 w25 w24
		//5315, 22654, 22654, -26722}; // w31 w30 w27 w26
		5315, 22654, 22654, -26722,//}; // w31 w30 w27 w26
		// 04
		16384,21407,16384,8867, //movq -> w05 w04 w01 w00
		16384, 8867, -16384, -21407, // w07 w06 w03 w02
		16384, -8867, 16384, -21407, // w13 w12 w09 w08
		-16384, 21407, 16384, -8867, // w15 w14 w11 w10
		22725, 19266, 19266, -4520, // w21 w20 w17 w16
		12873, 4520, -22725, -12873, // w23 w22 w19 w18
		12873, -22725, 4520, -12873, // w29 w28 w25 w24
		//4520, 19266, 19266, -22725}; // w31 w30 w27 w26
		4520, 19266, 19266, -22725,
		//35
		19266, 25172, 19266, 10426, //movq -> w05 w04 w01 w00
		19266, 10426, -19266, -25172, // w07 w06 w03 w02
		19266, -10426, 19266, -25172, // w13 w12 w09 w08
		-19266, 25172, 19266, -10426, // w15 w14 w11 w10
		26722, 22654, 22654, -5315, // w21 w20 w17 w16
		15137, 5315, -26722, -15137, // w23 w22 w19 w18
		15137, -26722, 5315, -15137, // w29 w28 w25 w24
		//5315, 22654, 22654, -26722}; // w31 w30 w27 w26
		5315, 22654, 22654, -26722,//}; // w31 w30 w27 w26
		//26
		21407, 27969, 21407, 11585, //movq -> w05 w04 w01 w00
		21407, 11585, -21407, -27969, // w07 w06 w03 w02
		21407, -11585, 21407, -27969, // w13 w12 w09 w08
		-21407, 27969, 21407, -11585, // w15 w14 w11 w10
		29692, 25172, 25172, -5906, // w21 w20 w17 w16
		16819, 5906, -29692, -16819, // w23 w22 w19 w18
		16819, -29692, 5906, -16819, // w29 w28 w25 w24
		//5906, 25172, 25172, -29692}; // w31 w30 w27 w26
		5906, 25172, 25172, -29692,//}; // w31 w30 w27 w26
		//17
		22725, 29692, 22725, 12299, //movq -> w05 w04 w01 w00
		22725, 12299, -22725, -29692, // w07 w06 w03 w02
		22725, -12299, 22725, -29692, // w13 w12 w09 w08
		-22725, 29692, 22725, -12299, // w15 w14 w11 w10
		31521, 26722, 26722, -6270, // w21 w20 w17 w16
		17855, 6270, -31521, -17855, // w23 w22 w19 w18
		17855, -31521, 6270, -17855, // w29 w28 w25 w24
		//6270, 26722, 26722, -31521}; // w31 w30 w27 w26
		6270, 26722, 26722, -31521}; // w31 w30 w27 w26
	
	//-----------------------------------------------------------------------------

#ifndef __LXIDCT_INTRINSIC

		
#define DCT_8_INV_ROW __asm{\
	__asm   movq mm4, mm0               /* 2 ; x3 x2 x1 x0*/\
	__asm   punpcklwd  mm0,mm0          /* 1100*/\
	__asm   punpckhwd  mm4,mm4          /* 3322 */\
	__asm   movq       mm2,mm0        \
	__asm   punpcklwd  mm0,mm4        /*2020*/\
	__asm   punpckhwd  mm2,mm4        /*3131*/\
	__asm   movq mm3, [esi]           	/* 3 ; w05 w04 w01 w00*/\
	__asm   movq mm4, qword ptr [esi+8] /* 4 ; w07 w06 w03 w02*/ \
	__asm   movq mm6, mm1 /* 5 ; x7 x6 x5 x4*/ \
	__asm   punpcklwd mm1,mm1    \
	__asm   punpckhwd mm6,mm6    \
	__asm   movq      mm5,mm1    \
	__asm   punpcklwd  mm1,mm6   /*6464*/\
	__asm   punpckhwd  mm5,mm6   /*7575*/\
	__asm   pmaddwd mm3, mm0 /* x2*w05+x0*w04 x2*w01+x0*w00*/ \
	__asm   movq mm6, [esi+32] /* 6 ; w21 w20 w17 w16*/ \
	__asm   pmaddwd mm4, mm1 /* x6*w07+x4*w06 x6*w03+x4*w02*/ \
	__asm   movq mm7, [esi+40] /* 7 ; w23 w22 w19 w18*/ \
	__asm   pmaddwd mm6, mm2 /* x3*w21+x1*w20 x3*w17+x1*w16*/ \
	__asm   pmaddwd mm7, mm5 /* x7*w23+x5*w22 x7*w19+x5*w18*/ \
	__asm   paddd mm3, qword ptr round_inv_row /* +rounder */ \
	__asm   pmaddwd mm0, qword ptr [esi+16] /* x2*w13+x0*w12 x2*w09+x0*w08*/ \
	__asm   paddd mm3, mm4 /* 4 ; a1=sum(even1) a0=sum(even0)*/ \
	__asm   pmaddwd mm1, qword ptr [esi+24] /* x6*w15+x4*w14 x6*w11+x4*w10*/ \
	__asm   movq mm4, mm3 /* 4 ; a1 a0 */ \
	__asm   pmaddwd mm2, qword ptr [esi+48] /* x3*w29+x1*w28 x3*w25+x1*w24*/ \
	__asm   paddd mm6, mm7 /* 7 ; b1=sum(odd1) b0=sum(odd0)*/ \
	__asm   pmaddwd mm5, qword ptr [esi+56] /* x7*w31+x5*w30 x7*w27+x5*w26*/ \
	__asm   paddd mm3, mm6 /* a1+b1 a0+b0*/ \
	__asm   paddd mm0, [round_inv_row] /* +rounder*/ \
	__asm   psrad mm3, SHIFT_INV_ROW /* y1=a1+b1 y0=a0+b0*/ \
	__asm   paddd mm0, mm1 /* 1 ; a3=sum(even3) a2=sum(even2)*/ \
	__asm   psubd mm4, mm6 /* 6 ; a1-b1 a0-b0 */ \
	__asm   movq mm7, mm0 /* 7 ; a3 a2 */ \
	__asm   paddd mm2, mm5 /* 5 ; b3=sum(odd3) b2=sum(odd2)*/ \
	__asm   paddd mm0, mm2 /* a3+b3 a2+b2*/ \
	__asm   psubd mm7, mm2 /* 2 ; a3-b3 a2-b2*/ \
	__asm   psrad mm4, SHIFT_INV_ROW /* y6=a1-b1 y7=a0-b0*/ \
	__asm   psrad mm7, SHIFT_INV_ROW /* y4=a3-b3 y5=a2-b2*/ \
	__asm   psrad mm0, SHIFT_INV_ROW /* y3=a3+b3 y2=a2+b2*/ \
	__asm   packssdw mm7, mm4 /* 4 ; y6 y7 y4 y5*/ \
	__asm   packssdw mm3, mm0 /* 0 ; y3 y2 y1 y0*/ \
	__asm   movq     mm6,mm7 \
	__asm   pslld    mm6,16  /* 7_5_*/ \
	__asm   psrld    mm7,16  /* _6_4*/\
	__asm   por      mm7,mm6 /* y7 y6 y5 y4*/\
		}
#else

#define DCT_8_INV_ROW \
	imm4 = imm0;               /* 2 ; x3 x2 x1 x0*/\
	imm0 = _m_punpcklwd( imm0,imm0 );          /* 1100*/\
	imm4 = _m_punpckhwd( imm4,imm4 );           /* 3322 */\
	imm2 = imm0;        \
	imm0 = _m_punpcklwd(  imm0,imm4 );       /*2020*/\
	imm2 = _m_punpckhwd(  imm2,imm4 );       /*3131*/\
	imm3 = *CONV_PM64(ptab_i);           	/* 3 ; w05 w04 w01 w00*/\
	imm4 = *CONV_PM64(ptab_i+4);				/* 4 ; w07 w06 w03 w02*/ \
	imm6 = imm1;							/* 5 ; x7 x6 x5 x4*/ \
	imm1 = _m_punpcklwd( imm1,imm1);    \
	imm6 = _m_punpckhwd( imm6,imm6);    \
	imm5 = imm1;    \
	imm1 = _m_punpcklwd(  imm1,imm6);   /*6464*/\
	imm5 = _m_punpckhwd(  imm5,imm6);   /*7575*/\
	imm3 = _m_pmaddwd(imm3, imm0);		/* x2*w05+x0*w04 x2*w01+x0*w00*/ \
	imm6 = *CONV_PM64(ptab_i+16);			/* 6 ; w21 w20 w17 w16*/ \
	imm4 = _m_pmaddwd(imm4, imm1);			/* x6*w07+x4*w06 x6*w03+x4*w02*/ \
	imm7 = *CONV_PM64(ptab_i+20);			/* 7 ; w23 w22 w19 w18*/ \
	imm6 = _m_pmaddwd( imm6, imm2); /* x3*w21+x1*w20 x3*w17+x1*w16*/ \
	imm7 = _m_pmaddwd( imm7, imm5); /* x7*w23+x5*w22 x7*w19+x5*w18*/ \
	imm3 = _m_paddd  ( imm3, *CONV_PM64(&round_inv_row)); /* +rounder */ \
	imm0 = _m_pmaddwd( imm0, *CONV_PM64(ptab_i+8)); /* x2*w13+x0*w12 x2*w09+x0*w08*/ \
	imm3 = _m_paddd  ( imm3, imm4); /* 4 ; a1=sum(even1) a0=sum(even0)*/ \
	imm1 = _m_pmaddwd( imm1, *CONV_PM64(ptab_i+12)); /* x6*w15+x4*w14 x6*w11+x4*w10*/ \
	imm4 = imm3; /* 4 ; a1 a0 */ \
	imm2 = _m_pmaddwd( imm2, *CONV_PM64(ptab_i+24)); /* x3*w29+x1*w28 x3*w25+x1*w24*/ \
	imm6 = _m_paddd  ( imm6, imm7); /* 7 ; b1=sum(odd1) b0=sum(odd0)*/ \
	imm5 = _m_pmaddwd( imm5, *CONV_PM64(ptab_i+28)); /* x7*w31+x5*w30 x7*w27+x5*w26*/ \
	imm3 = _m_paddd( imm3, imm6); /* a1+b1 a0+b0*/ \
	imm0 = _m_paddd( imm0, *CONV_PM64(&round_inv_row) ); /* +rounder*/ \
	imm3 = _m_psradi( imm3, SHIFT_INV_ROW); /* y1=a1+b1 y0=a0+b0*/ \
	imm0 = _m_paddd( imm0, imm1); /* 1 ; a3=sum(even3) a2=sum(even2)*/ \
	imm4 = _m_psubd( imm4, imm6); /* 6 ; a1-b1 a0-b0 */ \
	imm7 = imm0; /* 7 ; a3 a2 */ \
	imm2 = _m_paddd( imm2, imm5); /* 5 ; b3=sum(odd3) b2=sum(odd2)*/ \
	imm0 = _m_paddd( imm0, imm2); /* a3+b3 a2+b2*/ \
	imm7 = _m_psubd( imm7, imm2); /* 2 ; a3-b3 a2-b2*/ \
	imm4 = _m_psradi( imm4, SHIFT_INV_ROW); /* y6=a1-b1 y7=a0-b0*/ \
	imm7 = _m_psradi( imm7, SHIFT_INV_ROW); /* y4=a3-b3 y5=a2-b2*/ \
	imm0 = _m_psradi( imm0, SHIFT_INV_ROW); /* y3=a3+b3 y2=a2+b2*/ \
	imm7 = _m_packssdw( imm7, imm4); /* 4 ; y6 y7 y4 y5*/ \
	imm3 = _m_packssdw( imm3, imm0); /* 0 ; y3 y2 y1 y0*/ \
	imm6 = imm7; \
	imm6 = _m_pslldi(imm6,16);  /* 7_5_*/ \
	imm7 = _m_psrldi(imm7,16);  /* _6_4*/\
	imm7 = _m_por  (imm7,imm6); /* y7 y6 y5 y4*/

#endif


#ifndef __LXIDCT_INTRINSIC
		
#define DCT_8_INV_COL_4 __asm{ \
	__asm movq mm1, qword ptr [tg_3_16] /* 1 ; tg_3_16 */ \
	__asm movq mm2, mm0 /* 2 ; x5 */ \
	__asm movq mm3, qword ptr [edx+3*16] /* 3 ; x3 */ \
	__asm pmulhw mm0, mm1 /* x5*tg_3_16 */ \
	__asm movq mm4, qword ptr [edx+7*16] /* 4 ; x7 */ \
	__asm pmulhw mm1, mm3 /* x3*tg_3_16 */ \
	__asm movq mm5, qword ptr tg_1_16 /* 5 ; tg_1_16 */ \
	__asm movq mm6, mm4 /*; 6 ; x7 */ \
	__asm pmulhw mm4, mm5 /* x7*tg_1_16 */ \
	__asm paddsw mm0, mm2 /* x5*tg_3_16 */ \
	__asm pmulhw mm5, [edx+1*16] /* x1*tg_1_16 */ \
	__asm paddsw mm1, mm3 /* x3*tg_3_16 */ \
	__asm movq mm7, qword ptr [edx+6*16] /* 7 ; x6 */ \
	__asm paddsw mm0, mm3 /* 3 ; tm765 = x5*tg_3_16+x3 */ \
	__asm movq mm3, qword ptr tg_2_16 /* 3 ; tg_2_16 */ \
	__asm psubsw mm2, mm1 /* 1 ; tm465 = x5-x3*tg_3_16 */ \
	__asm pmulhw mm7, mm3 /* x6*tg_2_16 */ \
	__asm movq mm1, mm0 /* 1 ; tm765 */ \
	__asm pmulhw mm3, [edx+2*16] /* x2*tg_2_16 */ \
	__asm psubsw mm5, mm6 /* 6 ; tp465 = x1*tg_1_16-x7 */ \
	__asm paddsw mm4, [edx+1*16] /* tp765 = x1+x7*tg_1_16 */ \
	__asm paddsw mm0, mm4 /* t7 = tp765 + tm765 */ \
	__asm paddsw mm0, qword ptr one_corr /* correction t7 +1.0 */ \
	__asm psubsw mm4, mm1 /* 1 ; tp65 = tp765 - tm765 */ \
	__asm paddsw mm7, [edx+2*16] /* tm03 = x2+x6*tg_2_16 */ \
	__asm movq mm6, mm5 /* 6 ; tp465 */ \
	__asm psubsw mm3, [edx+6*16] /* tm12 = x2*tg_2_16-x6 */ \
	__asm psubsw mm5, mm2 /* tm65 = tp465 - tm465 */ \
	__asm paddsw mm5, qword ptr one_corr /* correction tm65 +1.0 */ \
	__asm paddsw mm6, mm2 /* 2 ; t4 = tp465 + tm465 */ \
	__asm movq [edx+7*16], mm0 /* 0 ; save t7 in y7 (tmp) */ \
	__asm movq mm1, mm4 /* 1 ; tp65 */ \
	__asm movq mm2, qword ptr cos_4_16 /* 2 ; cos_4_16 */ \
	__asm paddsw mm4, mm5 /* tp65 + tm65 */ \
	__asm movq mm0, qword ptr cos_4_16 /* 0 ; cos_4_16 */ \
	__asm pmulhw mm2, mm4 /* (tp65 + tm65)*cos_4_16 */ \
	__asm movq [edx+3*16], mm6 /* 6 ; save t4 in y3 (tmp) */ \
	__asm psubsw mm1, mm5 /* 5 ; tp65 - tm65 */ \
	__asm movq mm6, [edx] /* 6 ; x0 */ \
	__asm pmulhw mm0, mm1 /* (tp65 - tm65)*cos_4_16 */ \
	__asm movq mm5, [edx+4*16] /* 5 ; x4 */ \
	__asm paddsw mm4, mm2 /* 2 ; t6 = (tp65 + tm65)*cos_4_16 */ \
	__asm por mm4, qword ptr one_corr /* correction t6 +0.5 */ \
	__asm paddsw mm5, mm6 /* tp03 = x0 + x4 */ \
	__asm psubsw mm6, [edx+4*16] /* tp12 = x0 - x4 */ \
	__asm paddsw mm0, mm1 /* 1 ; t5 = (tp65 - tm65)*cos_4_16 */ \
	__asm por mm0, qword ptr one_corr /* correction t5 +0.5 */ \
	__asm movq mm2, mm5 /* 2 ; tp03 */ \
	__asm paddsw mm5, mm7 /* t0 = tp03 + tm03 */ \
	__asm movq mm1, mm6 /* 1 ; tp12 */ \
	__asm paddsw mm5, qword ptr round_inv_col /* t0 + rounder */ \
	__asm psubsw mm2, mm7 /* 7 ; t3 = tp03 - tm03 */ \
	__asm movq mm7, [edx+7*16] /* t7 */ \
	__asm paddsw mm6, mm3 /* t1 = tp12 + tm12 */ \
	__asm paddsw mm6, qword ptr round_inv_col /* t1 + rounder */ \
	__asm paddsw mm7, mm5 /* t0 + t7 */ \
	__asm psraw mm7, SHIFT_INV_COL /* y0 = t0 + t7 */ \
	__asm psubsw mm1, mm3 /* 3 ; t2 = tp12 - tm12 */ \
	__asm paddsw mm2, qword ptr round_inv_corr /* correction t3 -1.0 +rounder */ \
	__asm movq mm3, mm6 /* 3 ; t1 */ \
	__asm paddsw mm1, qword ptr round_inv_corr /* correction t2 -1.0 +rounder */ \
	__asm paddsw mm6, mm4 /* t1 + t6 */ \
	__asm movq [edx], mm7 /* 7 ; save y0 */ \
	__asm psraw mm6, SHIFT_INV_COL /* y1 = t1 + t6 */ \
	__asm movq mm7, mm1 /* 7 ; t2 */ \
	__asm paddsw mm1, mm0 /* t2 + t5 */ \
	__asm movq [edx+1*16], mm6 /* 6 ; save y1 */ \
	__asm psraw mm1, SHIFT_INV_COL /* y2 = t2 + t5 */ \
	__asm movq mm6, [edx+3*16] /* 6 ; t4 */ \
	__asm psubsw mm7, mm0 /* 0 ; t2 - t5 */ \
	__asm paddsw mm6, mm2 /* t3 + t4 */ \
	__asm psubsw mm2, [edx+3*16] /* t3 - t4 */ \
	__asm psraw mm7, SHIFT_INV_COL /* y5 = t2 - t5 */ \
	__asm movq [edx+2*16], mm1 /* 1 ; save y2 */ \
	__asm psraw mm6, SHIFT_INV_COL /* y3 = t3 + t4 */ \
	__asm psubsw mm5, [edx+7*16] /* t0 - t7 */ \
	__asm psraw mm2, SHIFT_INV_COL /* y4 = t3 - t4 */ \
	__asm movq [edx+3*16], mm6 /* 6 ; save y3 */ \
	__asm psubsw mm3, mm4 /* 4 ; t1 - t6 */ \
	__asm movq [edx+4*16], mm2 /* 2 ; save y4 */ \
	__asm psraw mm3, SHIFT_INV_COL /* y6 = t1 - t6 */ \
	__asm movq [edx+5*16], mm7 /* 7 ; save y5 */ \
	__asm psraw mm5, SHIFT_INV_COL /* y7 = t0 - t7 */ \
	__asm movq [edx+6*16], mm3 /* 3 ; save y6 */ \
	__asm movq [edx+7*16], mm5 /* 5 ; save y7 */ \
}

#else

#define DCT_8_INV_COL_4(blk)  \
	imm1 = *CONV_PM64(tg_3_16); /* 1 ; tg_3_16 */ \
	imm2 = imm0; /* 2 ; x5 */ \
	imm3 = *CONV_PM64(blk+3*8); /* 3 ; x3 */ \
	imm0 = _m_pmulhw(imm0, imm1);  /* x5*tg_3_16 */ \
	imm4 = *CONV_PM64(blk+7*8); /* 4 ; x7 */ \
	imm1 = _m_pmulhw(imm1, imm3); /* x3*tg_3_16 */ \
	imm5 = *CONV_PM64(tg_1_16); /* 5 ; tg_1_16 */ \
	imm6 = imm4; /*; 6 ; x7 */ \
	imm4 = _m_pmulhw (imm4, imm5); /* x7*tg_1_16 */ \
	imm0 = _m_paddsw (imm0, imm2); /* x5*tg_3_16 */ \
	imm5 = _m_pmulhw (imm5, *CONV_PM64(blk+1*8) ); /* x1*tg_1_16 */ \
	imm1 = _m_paddsw (imm1, imm3); /* x3*tg_3_16 */ \
	imm7 = *CONV_PM64(blk+6*8); /* 7 ; x6 */ \
	imm0 = _m_paddsw(imm0, imm3);  /* 3 ; tm765 = x5*tg_3_16+x3 */ \
	imm3 = *CONV_PM64(tg_2_16); /* 3 ; tg_2_16 */ \
	imm2 = _m_psubsw (imm2, imm1); /* 1 ; tm465 = x5-x3*tg_3_16 */ \
	imm7 = _m_pmulhw (imm7, imm3); /* x6*tg_2_16 */ \
	imm1 = imm0; /* 1 ; tm765 */ \
	imm3 = _m_pmulhw (imm3, *CONV_PM64(blk+2*8) ); /* x2*tg_2_16 */ \
	imm5 = _m_psubsw (imm5, imm6); /* 6 ; tp465 = x1*tg_1_16-x7 */ \
	imm4 = _m_paddsw (imm4, *CONV_PM64(blk+1*8) ); /* tp765 = x1+x7*tg_1_16 */ \
	imm0 = _m_paddsw (imm0, imm4); /* t7 = tp765 + tm765 */ \
	imm0 = _m_paddsw (imm0, *CONV_PM64(one_corr) ); /* correction t7 +1.0 */ \
	imm4 = _m_psubsw (imm4, imm1); /* 1 ; tp65 = tp765 - tm765 */ \
	imm7 = _m_paddsw (imm7, *CONV_PM64(blk+2*8) ); /* tm03 = x2+x6*tg_2_16 */ \
	imm6 = imm5; /* 6 ; tp465 */ \
	imm3 = _m_psubsw (imm3, *CONV_PM64(blk+6*8) ); /* tm12 = x2*tg_2_16-x6 */ \
	imm5 = _m_psubsw (imm5, imm2); /* tm65 = tp465 - tm465 */ \
	imm5 = _m_paddsw (imm5, *CONV_PM64(one_corr) ); /* correction tm65 +1.0 */ \
	imm6 = _m_paddsw (imm6, imm2); /* 2 ; t4 = tp465 + tm465 */ \
	*CONV_PM64(blk+7*8) = imm0; /* 0 ; save t7 in y7 (tmp) */ \
	imm1 = imm4; /* 1 ; tp65 */ \
	imm2 = *CONV_PM64(cos_4_16); /* 2 ; cos_4_16 */ \
	imm4 = _m_paddsw (imm4, imm5); /* tp65 + tm65 */ \
	imm0 = *CONV_PM64(cos_4_16); /* 0 ; cos_4_16 */ \
	imm2 = _m_pmulhw (imm2, imm4); /* (tp65 + tm65)*cos_4_16 */ \
	*CONV_PM64(blk+3*8) = imm6; /* 6 ; save t4 in y3 (tmp) */ \
	imm1 = _m_psubsw (imm1, imm5); /* 5 ; tp65 - tm65 */ \
	imm6 = *CONV_PM64(blk); /* 6 ; x0 */ \
	imm0 = _m_pmulhw (imm0, imm1); /* (tp65 - tm65)*cos_4_16 */ \
	imm5 = *CONV_PM64(blk+4*8) ; /* 5 ; x4 */ \
	imm4 = _m_paddsw (imm4, imm2); /* 2 ; t6 = (tp65 + tm65)*cos_4_16 */ \
	imm4 = _m_por (imm4, *CONV_PM64(one_corr)); /* correction t6 +0.5 */ \
	imm5 = _m_paddsw (imm5, imm6); /* tp03 = x0 + x4 */ \
	imm6 = _m_psubsw (imm6, *CONV_PM64(blk+4*8) ); /* tp12 = x0 - x4 */ \
	imm0 = _m_paddsw (imm0, imm1); /* 1 ; t5 = (tp65 - tm65)*cos_4_16 */ \
	imm0 = _m_por (imm0, *CONV_PM64(one_corr)); /* correction t5 +0.5 */ \
	imm2 = imm5;/* 2 ; tp03 */ \
	imm5 = _m_paddsw (imm5, imm7); /* t0 = tp03 + tm03 */ \
	imm1 = imm6; /* 1 ; tp12 */ \
	imm5 = _m_paddsw (imm5, *CONV_PM64(round_inv_col)); /* t0 + rounder */ \
	imm2 = _m_psubsw (imm2, imm7); /* 7 ; t3 = tp03 - tm03 */ \
	imm7 =  *CONV_PM64(blk+7*8); /* t7 */ \
	imm6 = _m_paddsw (imm6, imm3); /* t1 = tp12 + tm12 */ \
	imm6 = _m_paddsw (imm6, *CONV_PM64(round_inv_col)); /* t1 + rounder */ \
	imm7 = _m_paddsw (imm7, imm5); /* t0 + t7 */ \
	imm7 = _m_psrawi (imm7, SHIFT_INV_COL); /* y0 = t0 + t7 */ \
	imm1 = _m_psubsw (imm1, imm3); /* 3 ; t2 = tp12 - tm12 */ \
	imm2 = _m_paddsw (imm2, *CONV_PM64(round_inv_corr)); /* correction t3 -1.0 +rounder */ \
	imm3 = imm6; /* 3 ; t1 */ \
	imm1 = _m_paddsw (imm1, *CONV_PM64(round_inv_corr)); /* correction t2 -1.0 +rounder */ \
	imm6 = _m_paddsw (imm6, imm4); /* t1 + t6 */ \
	*CONV_PM64(blk) = imm7; /* 7 ; save y0 */ \
	imm6 = _m_psrawi (imm6, SHIFT_INV_COL); /* y1 = t1 + t6 */ \
	imm7 = imm1; /* 7 ; t2 */ \
	imm1 = _m_paddsw (imm1, imm0); /* t2 + t5 */ \
	*CONV_PM64(blk+1*8) = imm6; /* 6 ; save y1 */ \
	imm1 = _m_psrawi (imm1, SHIFT_INV_COL); /* y2 = t2 + t5 */ \
	imm6 = *CONV_PM64(blk+3*8); /* 6 ; t4 */ \
	imm7 = _m_psubsw (imm7, imm0); /* 0 ; t2 - t5 */ \
	imm6 = _m_paddsw (imm6, imm2); /* t3 + t4 */ \
	imm2 = _m_psubsw (imm2, *CONV_PM64(blk+3*8) ); /* t3 - t4 */ \
	imm7 = _m_psrawi (imm7, SHIFT_INV_COL); /* y5 = t2 - t5 */ \
	*CONV_PM64(blk+2*8) = imm1; /* 1 ; save y2 */ \
	imm6 = _m_psrawi (imm6, SHIFT_INV_COL); /* y3 = t3 + t4 */ \
	imm5 = _m_psubsw (imm5, *CONV_PM64(blk+7*8) ); /* t0 - t7 */ \
	imm2 = _m_psrawi (imm2, SHIFT_INV_COL); /* y4 = t3 - t4 */ \
	*CONV_PM64(blk+3*8) = imm6; /* 6 ; save y3 */ \
	imm3 = _m_psubsw (imm3, imm4); /* 4 ; t1 - t6 */ \
	*CONV_PM64(blk+4*8) = imm2; /* 2 ; save y4 */ \
	imm3 = _m_psrawi (imm3, SHIFT_INV_COL); /* y6 = t1 - t6 */ \
	*CONV_PM64(blk+5*8) = imm7; /* 7 ; save y5 */ \
	imm5 = _m_psrawi (imm5, SHIFT_INV_COL); /* y7 = t0 - t7 */ \
	*CONV_PM64(blk+6*8) = imm3; /* 3 ; save y6 */ \
	*CONV_PM64(blk+7*8) = imm5; /* 5 ; save y7 */

#endif


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void idct_mmx_col(s16* blk)
{
#ifndef __LXIDCT_INTRINSIC
	__asm{
		mov       edx,blk
		movq      mm0, qword ptr [edx+80] /* 0 /* x5 */
		DCT_8_INV_COL_4
		movq      mm0, qword ptr [edx+88] /* 0 /* x5 */
		add       edx, 8
		DCT_8_INV_COL_4
		emms
	}
#else
	MM_DECLARE8;
	s32 i;
	s16* p = blk;

	imm0 = *CONV_PM64(p+5*8);
	DCT_8_INV_COL_4(p)

	p += 4;
	imm0 = *CONV_PM64(p+5*8);
	DCT_8_INV_COL_4(p)

	_m_empty();
#endif
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void idct_mmx(s16* blk, LxIdctInf* pos)
{
#ifndef __LXIDCT_INTRINSIC
	__asm
	{
		mov        edx, [blk]
		lea        esi, [tab_i]
		mov        ecx,8
			
tag_idct_row:	    
		movq       mm0, [edx]
        movq       mm1, [edx+8]
		DCT_8_INV_ROW
		movq      [edx],mm3
		add       edx,16
		add       esi,64
		movq      [edx-8],mm7
		dec       ecx
		jnz       tag_idct_row
	}
#else

	MM_DECLARE8;
	s32		i;
	s16*	p = blk;
	s16*	ptab_i = tab_i;

	for ( i = 0; i < 8; i ++ ) {
		imm0 = *CONV_PM64(p);
		imm1 = *CONV_PM64(p+4);
		DCT_8_INV_ROW
		*CONV_PM64(p) = imm3;
		*CONV_PM64(p+4) = imm7;
		p += 8;
		ptab_i += 32;
	}

#endif

	_m_empty();
	idct_mmx_col(blk);
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void adder_128_mmx(s16 *blk,u8* dst,s32 pit)
{
#ifndef __LXIDCT_INTRINSIC
	__asm
	{
		mov       ecx,[blk]
		mov       eax,[pit]
		mov       edi,[dst]
		movq      mm0,[i_adder_128]
		movq      mm1,[ecx]
		movq      mm2,[ecx+8]
		paddsw    mm1,mm0
		paddsw    mm2,mm0
		movq      mm3,[ecx+16]
		movq      mm4,[ecx+24]
		paddsw    mm3,mm0
		paddsw    mm4,mm0
		packuswb  mm1,mm2
		packuswb  mm3,mm4
		movq      [edi],mm1
		add       ecx,32
		movq      [edi+eax],mm3
		add       edi,eax
		add       edi,eax
		movq      mm1,[ecx]
		movq      mm2,[ecx+8]
		paddsw    mm1,mm0
		paddsw    mm2,mm0
		movq      mm3,[ecx+16]
		movq      mm4,[ecx+24]
		paddsw    mm3,mm0
		paddsw    mm4,mm0
		packuswb  mm1,mm2
		packuswb  mm3,mm4
		movq      [edi],mm1
		add       ecx,32
		movq      [edi+eax],mm3
		add       edi,eax
		add       edi,eax
		movq      mm1,[ecx]
		movq      mm2,[ecx+8]
		paddsw    mm1,mm0
		paddsw    mm2,mm0
		movq      mm3,[ecx+16]
		movq      mm4,[ecx+24]
		paddsw    mm3,mm0
		paddsw    mm4,mm0
		packuswb  mm1,mm2
		packuswb  mm3,mm4
		movq      [edi],mm1
		add       ecx,32
		movq      [edi+eax],mm3
		add       edi,eax
		add       edi,eax
		movq      mm1,[ecx]
		movq      mm2,[ecx+8]
		paddsw    mm1,mm0
		paddsw    mm2,mm0
		movq      mm3,[ecx+16]
		movq      mm4,[ecx+24]
		paddsw    mm3,mm0
		paddsw    mm4,mm0
		packuswb  mm1,mm2
		packuswb  mm3,mm4
		movq      [edi],mm1
		movq      [edi+eax],mm3
		emms
	}
#else
	MM_DECLARE8;

	imm0 = *CONV_PM64(&i_adder_128);
	imm1 = *CONV_PM64(blk);
	imm2 = *CONV_PM64(blk+4);
	imm1 = _m_paddsw(imm1,imm0);
	imm2 = _m_paddsw(imm2,imm0);
	imm3 = *CONV_PM64(blk+8);
	imm4 = *CONV_PM64(blk+12);
    imm1 = _m_packuswb(imm1,imm2);
	imm3 = _m_packuswb(imm3,imm4);
	
#endif
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void idct_sparse_dc_mmx(s16* blk)
{
#ifndef __LXIDCT_INTRINSIC
	__asm
	{
		mov          esi,[blk]
		movsx        eax,word ptr[esi]   // blk[0]
		add          eax,4
		sar          eax,3
		movd         mm0,eax
		punpcklwd    mm0,mm0
		punpckldq    mm0,mm0
		movq         [esi],mm0
		movq         [esi+8],mm0
		movq         [esi+16],mm0
		movq         [esi+24],mm0
		movq         [esi+32],mm0
		movq         [esi+40],mm0
		movq         [esi+48],mm0
		movq         [esi+56],mm0
		movq         [esi+64],mm0
		movq         [esi+72],mm0
		movq         [esi+80],mm0
		movq         [esi+88],mm0
		movq         [esi+96],mm0
		movq         [esi+104],mm0
		movq         [esi+112],mm0
		movq         [esi+120],mm0
		emms
	}
#else

#endif
}


DECLARE_ALIGNED_16( static s32, g_AcRound0[4] ) 
= {
	IDCT_TAB_ROUND0,IDCT_TAB_ROUND0,IDCT_TAB_ROUND0,IDCT_TAB_ROUND0,
};

DECLARE_ALIGNED_16( static s32, g_DcRound1[4] ) 
= {
	IDCT_TAB_DC_ROUND1,IDCT_TAB_DC_ROUND1,IDCT_TAB_DC_ROUND1,IDCT_TAB_DC_ROUND1,
};


/***********************************************************************
***********************************************************************/
DECLARE_ALIGNED_16( static s16, g_AcRound1[8] ) 
= {
	IDCT_TAB_MMX_RD1,	IDCT_TAB_MMX_RD1,
	IDCT_TAB_MMX_RD1,	IDCT_TAB_MMX_RD1,
	IDCT_TAB_MMX_RD1,	IDCT_TAB_MMX_RD1,
	IDCT_TAB_MMX_RD1,	IDCT_TAB_MMX_RD1,
};

/***********************************************************************
***********************************************************************/
#ifndef __LXIDCT_INTRINSIC

#define LX_AC(edi,i,RC) \
__asm		movq         mm5,[IDCT_TAB_COL+edx+8*i]  \
__asm		movq         mm4,mm5                     \
__asm		pmulhw       mm5,mm0                     \
__asm		pmulhw       mm4,mm2                     \
__asm		paddsw       mm5,mm7                     \
__asm		paddsw       mm4,mm7                     \
__asm		psraw        mm5,RC                      \
__asm		psraw        mm4,RC                      \
__asm		movq         [edi+16*i],mm5              \
__asm		movq         [edi+16*i+8],mm4

#else

#endif

/***********************************************************************
idct_sparse_ac_mmx������ͨ��1�� MMX����
����ֵ���ޡ�
������
block, �������������DCTϵ��������ڴ��ַ��
dst��������������DCTϵ��������ڴ��ַ��
pos��������������ݽṹ��ַ�����DCTϵ���ķ������ݣ�
***********************************************************************/
void idct_sparse_ac_mmx(s16* blk, LxIdctInf* pos)
{
	u32 const dwRowMask = GET_ROW_MASK(pos->dwColMask);
	u32 const dwColMask = GET_COL_MASK(pos->dwColMask);

	s32 hnc = g_RowPos[dwColMask];
	s32 vnc = g_RowPos[dwRowMask];

	s32 np = hnc*8 + vnc ;
	if( 0 == np ) {
		idct_sparse_dc_mmx(blk);
		return;
	}
	
#ifndef __LXIDCT_INTRINSIC
	__asm
	{
		movq         mm7,[g_DcRound1]
		mov          edi,[blk]
		mov          edx,[np]
		movq         mm6,[g_AcRound0]
		movzx        eax,WORD PTR[edi+edx*2]
		mov          edx,[vnc]
		movd         mm5,eax 
		mov          eax,[hnc]
		test         eax,eax
		cmove        ecx,edx
		cmovne       ecx,eax
		shl          ecx,5	

		test         eax,eax

		punpckldq    mm5,mm5 
		movq         mm0,[IDCT_TAB+ecx]
		movq         mm1,[IDCT_TAB+ecx+8]
		pmaddwd      mm0,mm5
		pmaddwd      mm1,mm5
		paddd        mm0,mm6
		paddd        mm1,mm6
		psrad        mm0,IDCT_TAB_RC0
		psrad        mm1,IDCT_TAB_RC0

		je           ac_hdc

		test         edx,edx

		movq         mm2,[IDCT_TAB+ecx+16]
		movq         mm3,[IDCT_TAB+ecx+24]
		pmaddwd      mm2,mm5
		pmaddwd      mm3,mm5
		paddd        mm2,mm6
		paddd        mm3,mm6
		psrad        mm2,IDCT_TAB_RC0
		psrad        mm3,IDCT_TAB_RC0

		je           ac_vdc

		shl          edx,6                  // IDCT_TAB_COL[i];
		packssdw     mm0,mm1
		packssdw     mm2,mm3
		movq         mm7,[g_AcRound1]
		LX_AC(edi,0,IDCT_TAB_MMX_RC1)
		LX_AC(edi,1,IDCT_TAB_MMX_RC1)
		LX_AC(edi,2,IDCT_TAB_MMX_RC1)
		LX_AC(edi,3,IDCT_TAB_MMX_RC1)
		LX_AC(edi,4,IDCT_TAB_MMX_RC1)
		LX_AC(edi,5,IDCT_TAB_MMX_RC1)
		LX_AC(edi,6,IDCT_TAB_MMX_RC1)
		LX_AC(edi,7,IDCT_TAB_MMX_RC1)
		emms
		jmp          over 

ac_vdc:
		paddd        mm0,mm7
		paddd        mm1,mm7
		psrad        mm0,IDCT_TAB_DC_RC1
		psrad        mm1,IDCT_TAB_DC_RC1
		paddd        mm2,mm7
		paddd        mm3,mm7
		psrad        mm2,IDCT_TAB_DC_RC1
		psrad        mm3,IDCT_TAB_DC_RC1
		packssdw     mm0,mm1 // 3210;
		packssdw     mm2,mm3 // 7654;
		movq         [edi],mm0 
		movq         [edi+8],mm2
		movq         [edi+1*16],mm0 
		movq         [edi+1*16+8],mm2
		movq         [edi+2*16],mm0 
		movq         [edi+2*16+8],mm2
		movq         [edi+3*16],mm0 
		movq         [edi+3*16+8],mm2
		movq         [edi+4*16],mm0 
		movq         [edi+4*16+8],mm2
		movq         [edi+5*16],mm0 
		movq         [edi+5*16+8],mm2
		movq         [edi+6*16],mm0 
		movq         [edi+6*16+8],mm2
		movq         [edi+7*16],mm0 
		movq         [edi+7*16+8],mm2
		emms
		jmp          over 

ac_hdc:
		movq         mm2,[IDCT_TAB+ecx+16]
		movq         mm3,[IDCT_TAB+ecx+24]
		pmaddwd      mm2,mm5
		pmaddwd      mm3,mm5
		paddd        mm2,mm6
		paddd        mm3,mm6
		psrad        mm2,IDCT_TAB_RC0
		psrad        mm3,IDCT_TAB_RC0

		paddd        mm0,mm7
		paddd        mm1,mm7
		psrad        mm0,IDCT_TAB_DC_RC1
		psrad        mm1,IDCT_TAB_DC_RC1
		paddd        mm2,mm7
		paddd        mm3,mm7
		psrad        mm2,IDCT_TAB_DC_RC1
		psrad        mm3,IDCT_TAB_DC_RC1
		packssdw     mm0,mm1 // 3210;
		packssdw     mm2,mm3 // 7654;
		movq         mm1,mm0
		movq         mm3,mm2

		punpcklwd    mm0,mm0   // 1100
		punpckhwd    mm1,mm1   // 3322
		movq         mm4,mm0 
		movq         mm6,mm1 
		punpckldq    mm0,mm0  // 0000
		punpckhdq    mm4,mm4  // 1111
		movq         [edi],mm0 
		movq         [edi+8],mm0
		movq         [edi+1*16],mm4 
		movq         [edi+1*16+8],mm4
		punpckldq    mm1,mm1  // 2222
		punpckhdq    mm6,mm6  // 3333
		movq         [edi+2*16],mm1 
		movq         [edi+2*16+8],mm1
		movq         [edi+3*16],mm6 
		movq         [edi+3*16+8],mm6

		punpcklwd    mm2,mm2   // 5544
		punpckhwd    mm3,mm3  // 7766
		movq         mm5,mm2 
		movq         mm7,mm3
		punpckldq    mm2,mm2  // 4444
		punpckhdq    mm5,mm5  // 5555
		movq         [edi+4*16],mm2 
		movq         [edi+4*16+8],mm2
		movq         [edi+5*16],mm5 
		movq         [edi+5*16+8],mm5
		punpckldq    mm3,mm3  // 6666
		punpckhdq    mm7,mm7  // 7777
		movq         [edi+6*16],mm3 
		movq         [edi+6*16+8],mm3
		movq         [edi+7*16],mm7 
		movq         [edi+7*16+8],mm7		
		emms
over:
	}

#else

#endif

}


static void idct_intel_mmx_row_short_1( s16* blk, LxIdctInf* pos ) ;
static void idct_intel_mmx_col_short_1( s16* blk, LxIdctInf* pos ) ;
static void idct_intel_mmx_row_short_2( s16* blk, LxIdctInf* pos ) ;
static void idct_intel_mmx_col_short_2( s16* blk, LxIdctInf* pos ) ;
static void idct_intel_mmx_row_short_3( s16* blk, LxIdctInf* pos ) ;

//DECLARE_ALIGNED_16( static s16, g_mmxAcTmp[8*8] ) ;


#ifndef __LXIDCT_INTRINSIC

#define IDCT_8_INV_COL_1 __asm{\
	__asm	movsx      eax, WORD ptr [edi + edx*2 ]       \
	__asm   movsx      ecx, WORD ptr [edi + edx*2 + 16*2] \
	__asm	movd       mm0,eax                            \
	__asm	movd       mm1,ecx                            \
	__asm	movzx      eax, WORD ptr [edi + edx*2 + 16*4] \
	__asm	punpcklwd  mm0,mm1    /* 20*/                 \
	__asm   movzx      ecx, WORD ptr [edi + edx*2 + 16*6] \
	__asm	movd       mm1,eax                            \
	__asm	movd       mm2,ecx                            \
	__asm	movzx      eax, WORD ptr [edi + edx*2 + 16*1] \
	__asm	punpcklwd  mm1,mm2     /* 64*/                \
	__asm   movzx      ecx, WORD ptr [edi + edx*2 + 16*3] \
	__asm	movd       mm2,eax                            \
	__asm	movd       mm3,ecx                            \
	__asm	movzx      eax, WORD ptr [edi + edx*2 + 16*5] \
	__asm	punpcklwd  mm2,mm3     /* 31*/                \
	__asm   movzx      ecx, WORD ptr [edi + edx*2 + 16*7] \
	__asm	movd       mm5,eax                            \
	__asm	movd       mm3,ecx                            \
	__asm   punpckldq  mm0,mm0    /*2020*/           \
	__asm   punpcklwd  mm5,mm3    /*75*/             \
	__asm   movq       mm3, qword ptr [esi]           	/* 3 ; w05 w04 w01 w00*/\
	__asm   punpckldq  mm1,mm1    /*6464*/           \
	__asm   movq       mm4, qword ptr [esi+8] /* 4 ; w07 w06 w03 w02*/ \
	__asm   punpckldq  mm2,mm2    /*3131*/           \
	__asm   movq       mm6, [esi+32] /* 6 ; w21 w20 w17 w16*/ \
	__asm   punpckldq  mm5,mm5    /*7575*/           \
	__asm   pmaddwd    mm3, mm0 /* x2*w05+x0*w04 x2*w01+x0*w00*/ \
	__asm   pmaddwd    mm4, mm1 /* x6*w07+x4*w06 x6*w03+x4*w02*/ \
	__asm   movq       mm7, [esi+40] /* 7 ; w23 w22 w19 w18*/ \
	__asm   pmaddwd    mm6, mm2 /* x3*w21+x1*w20 x3*w17+x1*w16*/ \
	__asm   pmaddwd    mm7, mm5 /* x7*w23+x5*w22 x7*w19+x5*w18*/ \
	__asm   paddd      mm3, qword ptr round_inv_row /* +rounder */ \
	__asm   pmaddwd    mm0, qword ptr [esi+16] /* x2*w13+x0*w12 x2*w09+x0*w08*/ \
	__asm   paddd      mm3, mm4 /* 4 ; a1=sum(even1) a0=sum(even0)*/ \
	__asm   pmaddwd    mm1, qword ptr [esi+24] /* x6*w15+x4*w14 x6*w11+x4*w10*/ \
	__asm   movq       mm4, mm3 /* 4 ; a1 a0 */ \
	__asm   pmaddwd    mm2, qword ptr [esi+48] /* x3*w29+x1*w28 x3*w25+x1*w24*/ \
	__asm   paddd      mm6, mm7 /* 7 ; b1=sum(odd1) b0=sum(odd0)*/ \
	__asm   pmaddwd    mm5, qword ptr [esi+56] /* x7*w31+x5*w30 x7*w27+x5*w26*/ \
	__asm   paddd      mm3, mm6 /* a1+b1 a0+b0*/ \
	__asm   paddd      mm0, [round_inv_row] /* +rounder*/ \
	__asm   psrad      mm3, SHIFT_INV_ROW /* y1=a1+b1 y0=a0+b0*/ \
	__asm   paddd      mm0, mm1 /* 1 ; a3=sum(even3) a2=sum(even2)*/ \
	__asm   psubd      mm4, mm6 /* 6 ; a1-b1 a0-b0 */ \
	__asm   movq       mm7, mm0 /* 7 ; a3 a2 */ \
	__asm   paddd      mm2, mm5 /* 5 ; b3=sum(odd3) b2=sum(odd2)*/ \
	__asm   paddd      mm0, mm2 /* a3+b3 a2+b2*/ \
	__asm   psubd      mm7, mm2 /* 2 ; a3-b3 a2-b2*/ \
	__asm   psrad      mm4, SHIFT_INV_ROW /* y6=a1-b1 y7=a0-b0*/ \
	__asm   psrad      mm7, SHIFT_INV_ROW /* y4=a3-b3 y5=a2-b2*/ \
	__asm   psrad      mm0, SHIFT_INV_ROW /* y3=a3+b3 y2=a2+b2*/ \
	__asm   packssdw   mm7, mm4 /* 4 ; y6 y7 y4 y5*/ \
	__asm   packssdw   mm3, mm0 /* 0 ; y3 y2 y1 y0*/ \
	__asm   movq       mm6,mm7 \
	__asm   pslld      mm6,16  /* 7_5_*/ \
	__asm   psrld      mm7,16  /* _6_4*/\
	__asm   por        mm7,mm6 /* y7 y6 y5 y4*/\
		}
#else


#endif


#ifndef __LXIDCT_INTRINSIC

#define IDCT_8_INV_ROW __asm{\
	__asm   movq       mm4,mm0          /* 2 ; x3 x2 x1 x0*/\
	__asm   punpcklwd  mm0,mm0          /* 1100*/\
	__asm   punpckhwd  mm4,mm4          /* 3322 */\
	__asm   movq       mm2,mm0        \
	__asm   punpcklwd  mm0,mm4        /*2020*/\
	__asm   punpckhwd  mm2,mm4        /*3131*/\
	__asm   movq       mm3, qword ptr [esi]           	/* 3 ; w05 w04 w01 w00*/\
	__asm   movq       mm4, qword ptr [esi+8] /* 4 ; w07 w06 w03 w02*/ \
	__asm   movq       mm6, mm1 /* 5 ; x7 x6 x5 x4*/ \
	__asm   punpcklwd  mm1,mm1    \
	__asm   punpckhwd  mm6,mm6    \
	__asm   movq       mm5,mm1    \
	__asm   punpcklwd  mm1,mm6   /*6464*/\
	__asm   punpckhwd  mm5,mm6   /*7575*/\
	__asm   pmaddwd    mm3, mm0 /* x2*w05+x0*w04 x2*w01+x0*w00*/ \
	__asm   movq       mm6, [esi+32] /* 6 ; w21 w20 w17 w16*/ \
	__asm   pmaddwd    mm4, mm1 /* x6*w07+x4*w06 x6*w03+x4*w02*/ \
	__asm   movq       mm7, [esi+40] /* 7 ; w23 w22 w19 w18*/ \
	__asm   pmaddwd    mm6, mm2 /* x3*w21+x1*w20 x3*w17+x1*w16*/ \
	__asm   pmaddwd    mm7, mm5 /* x7*w23+x5*w22 x7*w19+x5*w18*/ \
	__asm   paddd      mm3, qword ptr round_inv_row /* +rounder */ \
	__asm   pmaddwd    mm0, qword ptr [esi+16] /* x2*w13+x0*w12 x2*w09+x0*w08*/ \
	__asm   paddd      mm3, mm4 /* 4 ; a1=sum(even1) a0=sum(even0)*/ \
	__asm   pmaddwd    mm1, qword ptr [esi+24] /* x6*w15+x4*w14 x6*w11+x4*w10*/ \
	__asm   movq       mm4, mm3 /* 4 ; a1 a0 */ \
	__asm   pmaddwd    mm2, qword ptr [esi+48] /* x3*w29+x1*w28 x3*w25+x1*w24*/ \
	__asm   paddd      mm6, mm7 /* 7 ; b1=sum(odd1) b0=sum(odd0)*/ \
	__asm   pmaddwd    mm5, qword ptr [esi+56] /* x7*w31+x5*w30 x7*w27+x5*w26*/ \
	__asm   paddd      mm3, mm6 /* a1+b1 a0+b0*/ \
	__asm   paddd      mm0, [round_inv_row] /* +rounder*/ \
	__asm   psrad      mm3, SHIFT_INV_ROW /* y1=a1+b1 y0=a0+b0*/ \
	__asm   paddd      mm0, mm1 /* 1 ; a3=sum(even3) a2=sum(even2)*/ \
	__asm   psubd      mm4, mm6 /* 6 ; a1-b1 a0-b0 */ \
	__asm   movq       mm7, mm0 /* 7 ; a3 a2 */ \
	__asm   paddd      mm2, mm5 /* 5 ; b3=sum(odd3) b2=sum(odd2)*/ \
	__asm   paddd      mm0, mm2 /* a3+b3 a2+b2*/ \
	__asm   psubd      mm7, mm2 /* 2 ; a3-b3 a2-b2*/ \
	__asm   psrad      mm4, SHIFT_INV_ROW /* y6=a1-b1 y7=a0-b0*/ \
	__asm   psrad      mm7, SHIFT_INV_ROW /* y4=a3-b3 y5=a2-b2*/ \
	__asm   psrad      mm0, SHIFT_INV_ROW /* y3=a3+b3 y2=a2+b2*/ \
	__asm   packssdw   mm7, mm4 /* 4 ; y6 y7 y4 y5*/ \
	__asm   packssdw   mm3, mm0 /* 0 ; y3 y2 y1 y0*/ \
	__asm   movq       mm6,mm7 \
	__asm   pslld      mm6,16  /* 7_5_*/ \
	__asm   psrld      mm7,16  /* _6_4*/\
	__asm   por        mm7,mm6 /* y7 y6 y5 y4*/\
		}
#else

#endif


#ifndef __LXIDCT_INTRINSIC

#define IDCT_8_INV_COL_4 __asm{ \
	__asm movq mm1, qword ptr [tg_3_16] /* 1 ; tg_3_16 */ \
	__asm movq mm2, mm0 /* 2 ; x5 */ \
	__asm movq mm3, qword ptr [edx+3*16] /* 3 ; x3 */ \
	__asm pmulhw mm0, mm1 /* x5*tg_3_16 */ \
	__asm movq mm4, qword ptr [edx+7*16] /* 4 ; x7 */ \
	__asm pmulhw mm1, mm3 /* x3*tg_3_16 */ \
	__asm movq mm5, qword ptr tg_1_16 /* 5 ; tg_1_16 */ \
	__asm movq mm6, mm4 /*; 6 ; x7 */ \
	__asm pmulhw mm4, mm5 /* x7*tg_1_16 */ \
	__asm paddsw mm0, mm2 /* x5*tg_3_16 */ \
	__asm pmulhw mm5, [edx+1*16] /* x1*tg_1_16 */ \
	__asm paddsw mm1, mm3 /* x3*tg_3_16 */ \
	__asm movq mm7, qword ptr [edx+6*16] /* 7 ; x6 */ \
	__asm paddsw mm0, mm3 /* 3 ; tm765 = x5*tg_3_16+x3 */ \
	__asm movq mm3, qword ptr tg_2_16 /* 3 ; tg_2_16 */ \
	__asm psubsw mm2, mm1 /* 1 ; tm465 = x5-x3*tg_3_16 */ \
	__asm pmulhw mm7, mm3 /* x6*tg_2_16 */ \
	__asm movq mm1, mm0 /* 1 ; tm765 */ \
	__asm pmulhw mm3, [edx+2*16] /* x2*tg_2_16 */ \
	__asm psubsw mm5, mm6 /* 6 ; tp465 = x1*tg_1_16-x7 */ \
	__asm paddsw mm4, [edx+1*16] /* tp765 = x1+x7*tg_1_16 */ \
	__asm paddsw mm0, mm4 /* t7 = tp765 + tm765 */ \
	__asm paddsw mm0, qword ptr one_corr /* correction t7 +1.0 */ \
	__asm psubsw mm4, mm1 /* 1 ; tp65 = tp765 - tm765 */ \
	__asm paddsw mm7, [edx+2*16] /* tm03 = x2+x6*tg_2_16 */ \
	__asm movq mm6, mm5 /* 6 ; tp465 */ \
	__asm psubsw mm3, [edx+6*16] /* tm12 = x2*tg_2_16-x6 */ \
	__asm psubsw mm5, mm2 /* tm65 = tp465 - tm465 */ \
	__asm paddsw mm5, qword ptr one_corr /* correction tm65 +1.0 */ \
	__asm paddsw mm6, mm2 /* 2 ; t4 = tp465 + tm465 */ \
	__asm movq [edx+7*16], mm0 /* 0 ; save t7 in y7 (tmp) */ \
	__asm movq mm1, mm4 /* 1 ; tp65 */ \
	__asm movq mm2, qword ptr cos_4_16 /* 2 ; cos_4_16 */ \
	__asm paddsw mm4, mm5 /* tp65 + tm65 */ \
	__asm movq mm0, qword ptr cos_4_16 /* 0 ; cos_4_16 */ \
	__asm pmulhw mm2, mm4 /* (tp65 + tm65)*cos_4_16 */ \
	__asm movq [edx+3*16], mm6 /* 6 ; save t4 in y3 (tmp) */ \
	__asm psubsw mm1, mm5 /* 5 ; tp65 - tm65 */ \
	__asm movq mm6, [edx] /* 6 ; x0 */ \
	__asm pmulhw mm0, mm1 /* (tp65 - tm65)*cos_4_16 */ \
	__asm movq mm5, [edx+4*16] /* 5 ; x4 */ \
	__asm paddsw mm4, mm2 /* 2 ; t6 = (tp65 + tm65)*cos_4_16 */ \
	__asm por mm4, qword ptr one_corr /* correction t6 +0.5 */ \
	__asm paddsw mm5, mm6 /* tp03 = x0 + x4 */ \
	__asm psubsw mm6, [edx+4*16] /* tp12 = x0 - x4 */ \
	__asm paddsw mm0, mm1 /* 1 ; t5 = (tp65 - tm65)*cos_4_16 */ \
	__asm por mm0, qword ptr one_corr /* correction t5 +0.5 */ \
	__asm movq mm2, mm5 /* 2 ; tp03 */ \
	__asm paddsw mm5, mm7 /* t0 = tp03 + tm03 */ \
	__asm movq mm1, mm6 /* 1 ; tp12 */ \
	__asm paddsw mm5, qword ptr round_inv_col /* t0 + rounder */ \
	__asm psubsw mm2, mm7 /* 7 ; t3 = tp03 - tm03 */ \
	__asm movq mm7, [edx+7*16] /* t7 */ \
	__asm paddsw mm6, mm3 /* t1 = tp12 + tm12 */ \
	__asm paddsw mm6, qword ptr round_inv_col /* t1 + rounder */ \
	__asm paddsw mm7, mm5 /* t0 + t7 */ \
	__asm psraw mm7, SHIFT_INV_COL /* y0 = t0 + t7 */ \
	__asm psubsw mm1, mm3 /* 3 ; t2 = tp12 - tm12 */ \
	__asm paddsw mm2, qword ptr round_inv_corr /* correction t3 -1.0 +rounder */ \
	__asm movq mm3, mm6 /* 3 ; t1 */ \
	__asm paddsw mm1, qword ptr round_inv_corr /* correction t2 -1.0 +rounder */ \
	__asm paddsw mm6, mm4 /* t1 + t6 */ \
	__asm movq [edi], mm7 /* 7 ; save y0 */ \
	__asm psraw mm6, SHIFT_INV_COL /* y1 = t1 + t6 */ \
	__asm movq mm7, mm1 /* 7 ; t2 */ \
	__asm paddsw mm1, mm0 /* t2 + t5 */ \
	__asm movq [edi+1*16], mm6 /* 6 ; save y1 */ \
	__asm psraw mm1, SHIFT_INV_COL /* y2 = t2 + t5 */ \
	__asm movq mm6, [edx+3*16] /* 6 ; t4 */ \
	__asm psubsw mm7, mm0 /* 0 ; t2 - t5 */ \
	__asm paddsw mm6, mm2 /* t3 + t4 */ \
	__asm psubsw mm2, [edx+3*16] /* t3 - t4 */ \
	__asm psraw mm7, SHIFT_INV_COL /* y5 = t2 - t5 */ \
	__asm movq [edi+2*16], mm1 /* 1 ; save y2 */ \
	__asm psraw mm6, SHIFT_INV_COL /* y3 = t3 + t4 */ \
	__asm psubsw mm5, [edx+7*16] /* t0 - t7 */ \
	__asm psraw mm2, SHIFT_INV_COL /* y4 = t3 - t4 */ \
	__asm movq [edi+3*16], mm6 /* 6 ; save y3 */ \
	__asm psubsw mm3, mm4 /* 4 ; t1 - t6 */ \
	__asm movq [edi+4*16], mm2 /* 2 ; save y4 */ \
	__asm psraw mm3, SHIFT_INV_COL /* y6 = t1 - t6 */ \
	__asm movq [edi+5*16], mm7 /* 7 ; save y5 */ \
	__asm psraw mm5, SHIFT_INV_COL /* y7 = t0 - t7 */ \
	__asm movq [edi+6*16], mm3 /* 3 ; save y6 */ \
	__asm movq [edi+7*16], mm5 /* 5 ; save y7 */ \
}
#else

#endif


/***********************************************************************
***********************************************************************/
#define IDCT_TAB_MMX_DC_RC1  5
#define IDCT_TAB_MMX_DC_RD1  (1<<(IDCT_TAB_MMX_DC_RC1-1))

DECLARE_ALIGNED_16( static s16, g_mmxDcRd1[8] ) 
//__declspec (align(16)) static s16 g_mmxDcRd1[8] 
= {
	IDCT_TAB_MMX_DC_RD1,IDCT_TAB_MMX_DC_RD1,
	IDCT_TAB_MMX_DC_RD1,IDCT_TAB_MMX_DC_RD1,
	IDCT_TAB_MMX_DC_RD1,IDCT_TAB_MMX_DC_RD1,
	IDCT_TAB_MMX_DC_RD1,IDCT_TAB_MMX_DC_RD1,
};

/***********************************************************************
right;
***********************************************************************/
#define IDCT_TAB_MMX_AC_RC1  3
#define IDCT_TAB_MMX_AC_RD1  (1<<(IDCT_TAB_MMX_AC_RC1-1))

DECLARE_ALIGNED_16( static s16, g_mmxAcRd1[8] ) 
//__declspec (align(16)) static s16 g_mmxAcRd1[8] 
= {
	IDCT_TAB_MMX_AC_RD1,IDCT_TAB_MMX_AC_RD1,
	IDCT_TAB_MMX_AC_RD1,IDCT_TAB_MMX_AC_RD1,
	IDCT_TAB_MMX_AC_RD1,IDCT_TAB_MMX_AC_RD1,
	IDCT_TAB_MMX_AC_RD1,IDCT_TAB_MMX_AC_RD1,
};


/***********************************************************************
idct_intel_mmx_row_short_1������ͨ��2��������1���ϵ�MMX�Ż���
����ֵ���ޡ�
������
block, �������������DCTϵ��������ڴ��ַ��
***********************************************************************/
stx_inline void idct_intel_mmx_row_short_1(s16* blk,LxIdctInf* pos ) 
{
#ifndef __LXIDCT_INTRINSIC
	__asm{
		mov          edx, [pos]
		mov          edx, [edx]LxIdctInf.dwColMask
		mov          edi, [blk]
		shr          edx, 24                 // row mask;
		mov          edx, [g_RowPos + edx*4]   // pos;	
		shl          edx, 4
		movq         mm0, [edi + edx ]
        movq         mm1, [edi + edx + 8]
		lea          esi, tab_i                // only use first row;
		shl          edx, 2
		IDCT_8_INV_ROW
		jz           ver_dc

		movq         mm0,mm3
		movq         mm2,mm7

		movq         mm7,[g_mmxAcRd1]
		LX_AC(edi,0,IDCT_TAB_MMX_AC_RC1)
		LX_AC(edi,1,IDCT_TAB_MMX_AC_RC1)
		LX_AC(edi,2,IDCT_TAB_MMX_AC_RC1)
		LX_AC(edi,3,IDCT_TAB_MMX_AC_RC1)
		LX_AC(edi,4,IDCT_TAB_MMX_AC_RC1)
		LX_AC(edi,5,IDCT_TAB_MMX_AC_RC1)
		LX_AC(edi,6,IDCT_TAB_MMX_AC_RC1)
		LX_AC(edi,7,IDCT_TAB_MMX_AC_RC1)

		emms
		jmp          over 

ver_dc:  // 30 clock;
		movq         mm0,mm3
		movq         mm3,mm7
		movq         mm1, mmword ptr [g_mmxDcRd1]
		paddsw       mm0,mm1
		paddsw       mm3,mm1
		psraw        mm0,IDCT_TAB_MMX_DC_RC1
		psraw        mm3,IDCT_TAB_MMX_DC_RC1
		movq         [edi],mm0
		movq         [edi+8],mm3
		movq         [edi+16*1],mm0
		movq         [edi+16*1+8],mm3
		movq         [edi+16*2],mm0
		movq         [edi+16*2+8],mm3
		movq         [edi+16*3],mm0
		movq         [edi+16*3+8],mm3
		movq         [edi+16*4],mm0
		movq         [edi+16*4+8],mm3
		movq         [edi+16*5],mm0
		movq         [edi+16*5+8],mm3
		movq         [edi+16*6],mm0
		movq         [edi+16*6+8],mm3
		movq         [edi+16*7],mm0
		movq         [edi+16*7+8],mm3
		emms
over:
	}

#else


#endif

}



/***********************************************************************
***********************************************************************/
#ifndef __LXIDCT_INTRINSIC

#define LX_AC_T(mm0,mm3,i) \
__asm		movq         mm3,mm0                            \
__asm		pmulhw       mm0,mm4                            \
__asm		pmulhw       mm3,mm5                            \
__asm		paddsw       mm0,mm6                            \
__asm		paddsw       mm3,mm6                            \
__asm		psraw        mm0,IDCT_TAB_MMX_AC_RC1            \
__asm		psraw        mm3,IDCT_TAB_MMX_AC_RC1            \
__asm		movq         [edi+i*16],mm0                     \
__asm		movq         [edi+i*16+8],mm3

#else

#endif


/***********************************************************************
idct_mmx_col_short_1������ͨ��2��������1���ϵ�MMX�Ż���
����ֵ���ޡ�
������
block, �������������DCTϵ��������ڴ��ַ��
***********************************************************************/
static void idct_intel_mmx_col_short_1(s16* blk,LxIdctInf* pos )
{
#ifndef __LXIDCT_INTRINSIC
	__asm{
		mov          edx, [pos]
		mov          edi, [blk]
		mov          edx, [edx]LxIdctInf.dwColMask
		and          edx, 0xff
		lea          esi, tab_i     // only use first row;
		mov          edx, [g_RowPos+edx*4]
		test         edx, edx
		IDCT_8_INV_COL_1
		jz           hor_dc

// mm0,3210; mm2, 7654;
		shl          edx,4         // table position;
		movq         mm0,mm3
		movq         mm2,mm7
		movq         mm6,[g_mmxAcRd1]
		movq         mm1,mm0
		movq         mm4,mmword ptr [IDCT_TAB_ROW+edx] 
		punpcklwd    mm0,mm0   // 1100;
		punpckhwd    mm1,mm1   // 3322;
		movq         mm5,mmword ptr [IDCT_TAB_ROW+edx+8] 

		movq         mm7,mm0
		punpckldq    mm0,mm0   // 0000;
		punpckhdq    mm7,mm7   // 1111;		
		LX_AC_T(mm0,mm3,0)
		LX_AC_T(mm7,mm3,1)

		movq         mm0,mm1
		punpckldq    mm1,mm1   // 2222;
		punpckhdq    mm0,mm0   // 3333;
		LX_AC_T(mm1,mm3,2)
		LX_AC_T(mm0,mm3,3)

		movq         mm0,mm2
		punpcklwd    mm0,mm0   // 
		punpckhwd    mm2,mm2   // 

		movq         mm7,mm0
		punpckldq    mm0,mm0   // 
		punpckhdq    mm7,mm7   // 	
		LX_AC_T(mm0,mm3,4)
		LX_AC_T(mm7,mm3,5)

		movq         mm0,mm2
		punpckldq    mm2,mm2   // 
		punpckhdq    mm0,mm0   // 
		LX_AC_T(mm2,mm3,6)
		LX_AC_T(mm0,mm3,7)

		emms
		jmp          over 

hor_dc:
		movq         mm0,mm3
		movq         mm2,mm7
		movq         mm6, mmword ptr [g_mmxDcRd1]
		paddsw       mm0, mm6
		paddsw       mm2, mm6
		psraw        mm0, IDCT_TAB_MMX_DC_RC1
		psraw        mm2, IDCT_TAB_MMX_DC_RC1

		movq         mm1,mm0
		movq         mm3,mm2

		punpcklwd    mm0,mm0   // 1100
		punpckhwd    mm1,mm1   // 3322
		movq         mm4,mm0 
		movq         mm6,mm1 
		punpckldq    mm0,mm0  // 0000
		punpckhdq    mm4,mm4  // 1111
		movq         [edi],mm0 
		movq         [edi+8],mm0
		movq         [edi+1*16],mm4 
		movq         [edi+1*16+8],mm4
		punpckldq    mm1,mm1  // 2222
		punpckhdq    mm6,mm6  // 3333
		movq         [edi+2*16],mm1 
		movq         [edi+2*16+8],mm1
		movq         [edi+3*16],mm6 
		movq         [edi+3*16+8],mm6

		punpcklwd    mm2,mm2   // 5544
		punpckhwd    mm3,mm3  // 7766
		movq         mm5,mm2 
		movq         mm7,mm3
		punpckldq    mm2,mm2  // 4444
		punpckhdq    mm5,mm5  // 5555
		movq         [edi+4*16],mm2 
		movq         [edi+4*16+8],mm2
		movq         [edi+5*16],mm5 
		movq         [edi+5*16+8],mm5
		punpckldq    mm3,mm3  // 6666
		punpckhdq    mm7,mm7  // 7777
		movq         [edi+6*16],mm3 
		movq         [edi+6*16+8],mm3
		movq         [edi+7*16],mm7 
		movq         [edi+7*16+8],mm7		
		emms
over:
	}

#else


#endif

}



/***********************************************************************
***********************************************************************/
#define IDCT_TAB_MMX_AC_RC2  ( IDCT_TAB_MMX_SCALE + BITS_INV_ACC )
#define IDCT_TAB_MMX_AC_RD2  (1<<(IDCT_TAB_MMX_AC_RC2-1))

DECLARE_ALIGNED_16( static s32, g_mmxAcRd2[4] ) 
= {
	IDCT_TAB_MMX_AC_RD2,IDCT_TAB_MMX_AC_RD2,
	IDCT_TAB_MMX_AC_RD2,IDCT_TAB_MMX_AC_RD2,
};

/***********************************************************************
***********************************************************************/
#ifndef __LXIDCT_INTRINSIC
	
#define LX_AC_2(edi,i,RC) \
	__asm		movq         mm4,[IDCT_TAB_COL+ecx+8*i]  \
	__asm       punpcklwd    mm4,[IDCT_TAB_COL+edx+8*i]  \
	__asm		movq         mm5,mm4                     \
	__asm		movq         mm6,mm4                     \
	__asm		pmaddwd      mm4,mm0                     \
	__asm		pmaddwd      mm5,mm1                     \
	__asm       paddd        mm4,mm7                     \
    __asm       paddd        mm5,mm7                     \
	__asm       psrad        mm4,RC                      \
	__asm       psrad        mm5,RC                      \
	__asm       packssdw     mm4,mm5                     \
	__asm       movq         mm5,mm6                     \
	__asm		movq         [edi+16*i],mm4              \
	__asm		pmaddwd      mm5,mm2                     \
	__asm		pmaddwd      mm6,mm3                     \
	__asm       paddd        mm5,mm7                     \
    __asm       paddd        mm6,mm7                     \
	__asm       psrad        mm5,RC                      \
	__asm       psrad        mm6,RC                      \
	__asm       packssdw     mm5,mm6                     \
	__asm		movq         [edi+16*i+8],mm5
#else

#endif


/***********************************************************************
idct_intel_mmx_row_short_2 ����ͨ��2��������2���ϵ�MMX�Ż���
����ֵ���ޡ�
������
block, �������������DCTϵ��������ڴ��ַ��
dst��������������DCTϵ��������ڴ��ַ��
nRow0�������������һ�������е�λ�ã�
nRow1������������ڶ��������е�λ�ã�
***********************************************************************/
stx_inline void idct_intel_mmx_row_short_2(s16* blk,LxIdctInf* pos  ) 
{
#ifndef __LXIDCT_INTRINSIC
	__asm{
		mov          edx, [pos]
		mov          edx, [edx]LxIdctInf.dwColMask
		mov          eax, [blk]
		shr          edx, 24
		mov          edx, [g_RowPos+edx*4]
		mov          ecx, edx
		shr          edx, 3
		and          ecx, 7
		shl          ecx, 4
		shl          edx, 4
		lea          esi, tab_i                // only use first row;

		movq         mm0, [eax + ecx ]
        movq         mm1, [eax + ecx + 8]
		IDCT_8_INV_ROW
		movq         [eax + ecx ],mm3
		movq         [eax + ecx +8],mm7

		movq         mm0, [eax + edx ]
        movq         mm1, [eax + edx + 8]
		IDCT_8_INV_ROW
		movq         mm0,[eax + ecx]     // a3210
		movq         mm2,[eax + ecx + 8] // a7654
		movq         mm1,mm0
		shl          ecx,2
		punpcklwd    mm0,mm3  // b1 a1 b0 a0  mm0
		punpckhwd    mm1,mm3  // b3 a3 b2 a2  mm1
		movq         mm3,mm2
		shl          edx,2
		punpcklwd    mm2,mm7  // b5 a5 b4 a4  mm2
		punpckhwd    mm3,mm7  // b7 a7 b6 a6  mm3
		movq         mm7,[g_mmxAcRd2]

		LX_AC_2(eax,0,IDCT_TAB_MMX_AC_RC2)
		LX_AC_2(eax,1,IDCT_TAB_MMX_AC_RC2)
		LX_AC_2(eax,2,IDCT_TAB_MMX_AC_RC2)
		LX_AC_2(eax,3,IDCT_TAB_MMX_AC_RC2)
		LX_AC_2(eax,4,IDCT_TAB_MMX_AC_RC2)
		LX_AC_2(eax,5,IDCT_TAB_MMX_AC_RC2)
		LX_AC_2(eax,6,IDCT_TAB_MMX_AC_RC2)
		LX_AC_2(eax,7,IDCT_TAB_MMX_AC_RC2)
		emms
	}
#else

#endif
}

/***********************************************************************
***********************************************************************/
#ifndef __LXIDCT_INTRINSIC

#define LX_AC_T2(i) \
__asm       movq         mm1,mm0                            \
__asm       movq         mm2,mm0                            \
__asm		pmaddwd      mm0,mm4                            \
__asm		pmaddwd      mm1,mm5                            \
__asm       paddd        mm0,mm3                            \
__asm       paddd        mm1,mm3                            \
__asm       psrad        mm0,IDCT_TAB_MMX_AC_RC2            \
__asm       psrad        mm1,IDCT_TAB_MMX_AC_RC2            \
__asm       packssdw     mm0,mm1                            \
__asm       movq         mm1,mm2                            \
__asm		movq         [edi+i*16],mm0                     \
__asm		pmaddwd      mm1,mm6                            \
__asm		pmaddwd      mm2,mm7                            \
__asm       paddd        mm1,mm3                            \
__asm       paddd        mm2,mm3                            \
__asm       psrad        mm1,IDCT_TAB_MMX_AC_RC2            \
__asm       psrad        mm2,IDCT_TAB_MMX_AC_RC2            \
__asm       packssdw     mm1,mm2                            \
__asm		movq         [edi+i*16+8],mm1

#else

#endif


/***********************************************************************
idct_intel_mmx_col_short_2 ����ͨ��2��������2���ϵ�MMX�Ż���
����ֵ���ޡ�
������
block, �������������DCTϵ��������ڴ��ַ��
dst��������������DCTϵ��������ڴ��ַ��
nCol0�������������һ�������е�λ�ã�
nCol1������������ڶ��������е�λ�ã�
g_mmxAcTmp����ʱ���ݻ��壻
***********************************************************************/

static void idct_intel_mmx_col_short_2(s16* blk,LxIdctInf* pos ) 
{

#ifndef __LXIDCT_INTRINSIC
	u64 g_mmxAcTmp[24];
	__asm{
		push         ebx 

		lea			eax,[g_mmxAcTmp]
		add         eax,15
		and			eax,~15
		push		eax

		mov          ebx, [pos]
		mov          edi, [blk]
		mov          ebx, [ebx]LxIdctInf.dwColMask
		and          ebx, 0xff
		mov          ebx, [g_RowPos+ebx*4]

		mov          edx, ebx
		and          edx, 7
		lea          esi, tab_i
		IDCT_8_INV_COL_1
		pop			eax
		mov          edx, ebx
		movq         [eax],mm3
		shr          edx, 3
		movq         [eax+8],mm7
		push		eax
		IDCT_8_INV_COL_1
		pop			eax
		movq         mm0,[eax]
		movq         mm2,[eax+8]
		movq         mm1,mm0
		punpcklwd    mm0,mm3  //
		punpckhwd    mm1,mm3  //
		movq         [eax],mm0     // save 10 ba; 
		movq         [eax+8],mm1   // save 32 ba;
		movq         mm3,mm2
		mov          ecx,ebx
		punpcklwd    mm2,mm7  //
		punpckhwd    mm3,mm7  //
		and          ecx, 7
		movq         [eax+16],mm2  // save 54 ba; 
		movq         [eax+24],mm3  // save 76 ba;

		shl          ecx,4
		shl          edx,4         // table position;
		movq         mm4,mmword ptr [IDCT_TAB_ROW+ecx] 
		movq         mm6,mmword ptr [IDCT_TAB_ROW+edx] 
		movq         mm5,mm4
		punpcklwd    mm4,mm6
		punpckhwd    mm5,mm6
		movq         mm6,mmword ptr [IDCT_TAB_ROW+ecx+8]
		movq         mm1,mmword ptr [IDCT_TAB_ROW+edx+8] 
		movq         mm7,mm6
		punpcklwd    mm6,mm1
		punpckhwd    mm7,mm1

		punpckldq    mm0,mm0 
		movq         mm3,[g_mmxAcRd2]
		LX_AC_T2(0)

		movq         mm0,[eax]
		punpckhdq    mm0,mm0 
		LX_AC_T2(1)

		movq         mm0,[eax+8]
		punpckldq    mm0,mm0 
		LX_AC_T2(2)

		movq         mm0,[eax+8]
		punpckhdq    mm0,mm0 
		LX_AC_T2(3)

		movq         mm0,[eax+16]
		punpckldq    mm0,mm0 
		LX_AC_T2(4)

		movq         mm0,[eax+16]
		punpckhdq    mm0,mm0 
		LX_AC_T2(5)

		movq         mm0,[eax+24]
		punpckldq    mm0,mm0 
		LX_AC_T2(6)

		movq         mm0,[eax+24]
		punpckhdq    mm0,mm0 
		LX_AC_T2(7)
		pop          ebx 
		emms
	}
#else

#endif

}



/***********************************************************************
idct_mmx_row_short_3������ͨ��2��������3�����ϵ�MMX�Ż���
����ֵ���ޡ�
������
block, �������������DCTϵ��������ڴ��ַ��
dst��������������DCTϵ��������ڴ��ַ��
nRow������������ܷ����е���Ŀ��
dwPos,���������ÿ�������е�λ�á�
***********************************************************************/
static void idct_intel_mmx_row_short_3(s16* blk, LxIdctInf* pos) 
{
#ifndef __LXIDCT_INTRINSIC
	__asm{
		mov          eax, [pos]
		push         ebx 
		mov          eax, [eax]LxIdctInf.dwColMask
		mov          edi, [blk]
		shr          eax, 24                     // row mask;
		lea          ebx, [tab_i]
		mov          ecx, [g_RowPos+eax*4]       // row pos;
		movzx        eax, BYTE PTR[g_RowNz+eax]  // row num;

next_row:
		mov          edx, ecx
		mov          esi, ebx 
		and          edx, 7
		shl          edx, 6
		shr          ecx, 3
		add          esi, edx 
		shr          edx, 2
		dec          eax
		movq         mm0, [edi + edx ]
        movq         mm1, [edi + edx + 8]
		DCT_8_INV_ROW
		movq         [edi + edx],mm3
		movq         [edi + edx +8],mm7
		jnz          next_row
		pop          ebx 
	}
#else

#endif

	_m_empty();
	idct_mmx_col(blk);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void idct_mmx_ex(s16* blk,LxIdctInf* pos)
{

	DWORD const dwRowMask = GET_ROW_MASK(pos->dwColMask);
	DWORD const dwRowNum = g_RowNz[dwRowMask];
	DWORD const dwColMask = GET_COL_MASK(pos->dwColMask);
	DWORD const dwColNum = g_RowNz[dwColMask];

	if( dwRowNum == 1 && dwColNum == 1 ) {
		idct_sparse_ac_mmx(blk,pos );// ����ͨ��0,1��
		return;
	}

	// ������ͨ��2��

	// ����Ƿ����ݶ���һ���ϣ�
	if( 1 == dwRowNum ) {   // all the nz data in one row; 90/110/140;
		idct_intel_mmx_row_short_1( blk, pos );
		return;
	}

	// ����Ƿ����ݶ���һ���ϣ�	

	if( 1 == dwColNum ) {   // all the nz data in one col; 90/110/140;
		idct_intel_mmx_col_short_1( blk, pos );
		return;
	}

	if( dwRowNum <= 6   ) {  // RIGHT;
		idct_intel_mmx_row_short_3(blk,pos);
		return;
	}

	idct_mmx(blk,pos);  // 340 clock + branch penalty 30; 370;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void intel_idct_mmx_init( idct_proc_entry entry[8][8])
{
	s32 i,j;

	for( i = 0; i < 8; i ++ ) {

		for( j = 0; j < 8; j ++ ) {

			entry[i][j] = idct_mmx;

			if( i == 0 && j == 0  ) {
				entry[i][j] = idct_sparse_ac_mmx;    // hybrid idct;
			}
			else if( i == 0 ){
				entry[i][j] = idct_intel_mmx_row_short_1;  // hybrid idct;
			}
			else if( j == 0 ) {
				entry[i][j] = idct_intel_mmx_col_short_1;  // hybrid idct;
			}
			else if( i == 1 ) {
				entry[i][j] = idct_intel_mmx_row_short_2;  // 
			}
			else if( j == 1 ) {
				entry[i][j] = idct_intel_mmx_col_short_2;  // hybrid idct;
			}
			else if( i <= 5 ) {
				entry[i][j] = idct_intel_mmx_row_short_3;
			}
		}
	}
}




////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  start of intel idct sse2 version;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static void idct_intel_sse2_row_short_1(s16* blk,LxIdctInf* pos) ;
static void idct_intel_sse2_col_short_1(s16* blk,LxIdctInf* pos) ;
static void idct_intel_sse2_row_short_2(s16* blk,LxIdctInf* pos ) ;
static void idct_intel_sse2_col_short_2(s16* blk, LxIdctInf* pos ) ;
static void idct_intel_sse2_row_short_3(s16* blk, LxIdctInf* pos ) ;

#ifndef __LXIDCT_INTRINSIC
// 30 lines;
#define IDCT_8_INV_ROW_SSE2 __asm{\
	__asm   movdqa     xmm3, xmmword ptr [esi]      /* 4 ; w07 w06 w03 w02  3 ; w05 w04 w01 w00*/\
	__asm   pshuflw    xmm0, xmm0,0xD8  /* 11011000 7654 3120 */\
	__asm   pshufhw    xmm0, xmm0,0xD8  /* 11011000 7564 3120 */\
	__asm   pshufd     xmm0, xmm0,0xD8  /* 11011000 75 31 64 20 */\
	__asm   movdqa     xmm6, xmmword ptr [esi+32] /* 7 ; w23 w22 w19 w18  6 ; w21 w20 w17 w16*/ \
	__asm   pshufd     xmm1, xmm0,0x50  /* 01010000 64 64 20 20 */\
	__asm   pshufd     xmm0, xmm0,0xfa  /* 11111010 75 75 31 31 */\
	__asm   pmaddwd    xmm3, xmm1                 /* x6*w07+x4*w06 x6*w03+x4*w02 x2*w05+x0*w04 x2*w01+x0*w00 */  \
	__asm   pmaddwd    xmm6, xmm0                 /* x7*w23+x5*w22 x7*w19+x5*w18 x3*w21+x1*w20 x3*w17+x1*w16 */  \
	__asm   movdqa     xmm2, xmm3  \
    __asm   punpcklqdq xmm3, xmm6  /* x3*w21+x1*w20 x3*w17+x1*w16  x2*w05+x0*w04 x2*w01+x0*w00 */  \
	__asm   punpckhqdq xmm2, xmm6  /* x7*w23+x5*w22 x7*w19+x5*w18  x6*w07+x4*w06 x6*w03+x4*w02 */  \
	__asm   pmaddwd    xmm1, xmmword ptr [esi+16] /* x6*w15+x4*w14 x6*w11+x4*w10 x2*w13+x0*w12 x2*w09+x0*w08 */  \
	__asm   paddd      xmm3, xmmword ptr [round_inv_row] /* +rounder */ \
	__asm   pmaddwd    xmm0, xmmword ptr [esi+48] /* x7*w31+x5*w30 x7*w27+x5*w26 x3*w29+x1*w28 x3*w25+x1*w24 */  \
	__asm   movdqa     xmm4, xmm1  /**/\
	__asm   punpcklqdq xmm1, xmm0  /* x3*w29+x1*w28 x3*w25+x1*w24 x2*w13+x0*w12 x2*w09+x0*w08 */\
	__asm   punpckhqdq xmm4, xmm0  /* x7*w31+x5*w30 x7*w27+x5*w26 x6*w15+x4*w14 x6*w11+x4*w10 */\
	__asm   paddd      xmm3, xmm2  /* 7 ; b1=sum(odd1) b0=sum(odd0) 4 ; a1=sum(even1) a0=sum(even0)*/ \
	__asm   paddd      xmm1, xmm4  /* 5 ; b3=sum(odd3) b2=sum(odd2) 1 ; a3=sum(even3) a2=sum(even2)*/ \
	__asm   movdqa     xmm0, xmm3  /**/\
	__asm   punpcklqdq xmm3, xmm1  /* a3 a2 a1 a0 */\
	__asm   punpckhqdq xmm0, xmm1  /* b3 b2 b1 b0 */\
	__asm   movdqa     xmm2, xmm3  /**/\
	__asm   paddd      xmm3, xmm0  /* a3 + b3, a2 + b2, a1 + b1, a0 + b0 */\
	__asm   psubd      xmm2, xmm0  /* a3 - b3, a2 - b2, a1 - b1, a0 - b0 */\
	__asm   psrad      xmm3, SHIFT_INV_ROW /* y3=a3+b3 y2=a2+b2 y1=a1+b1 y0=a0+b0*/ \
	__asm   psrad      xmm2, SHIFT_INV_ROW /* y4=a3-b3 y5=a2-b2 y6=a1-b1 y7=a0-b0*/ \
	__asm   pshufd     xmm2, xmm2,0x1b    /* 00011011 */ \
	__asm   packssdw   xmm3, xmm2 /* y7 y6 y5 y4 y3 y2 y1 y0 */\
		}
#else


#endif


#ifndef __LXIDCT_INTRINSIC

#define IDCT_8_INV_COL_4_SSE2  __asm{ \
	__asm movdqa  xmm0, xmmword ptr [ecx+5*16] /* 5 ; x5 */ \
	__asm movdqa  xmm1, xmmword ptr [tg_3_16] /* 1 ; tg_3_16 */ \
	__asm movdqa  xmm2, xmm0 /* 2 ; x5 */ \
	__asm movdqa  xmm3, xmmword ptr [ecx+3*16] /* 3 ; x3 */ \
	__asm pmulhw  xmm0, xmm1 /* x5*tg_3_16 */ \
	__asm movdqa  xmm4, xmmword ptr [ecx+7*16] /* 4 ; x7 */ \
	__asm pmulhw  xmm1, xmm3 /* x3*tg_3_16 */ \
	__asm movdqa  xmm5, xmmword ptr tg_1_16 /* 5 ; tg_1_16 */ \
	__asm movdqa  xmm6, xmm4 /*; 6 ; x7 */ \
	__asm pmulhw  xmm4, xmm5 /* x7*tg_1_16 */ \
	__asm paddsw  xmm0, xmm2 /* x5*tg_3_16 */ \
	__asm pmulhw  xmm5, [ecx+1*16] /* x1*tg_1_16 */ \
	__asm paddsw  xmm1, xmm3 /* x3*tg_3_16 */ \
	__asm movdqa  xmm7, xmmword ptr [ecx+6*16] /* 7 ; x6 */ \
	__asm paddsw  xmm0, xmm3 /* 3 ; tm765 = x5*tg_3_16+x3 */ \
	__asm movdqa  xmm3, xmmword ptr tg_2_16 /* 3 ; tg_2_16 */ \
	__asm psubsw  xmm2, xmm1 /* 1 ; tm465 = x5-x3*tg_3_16 */ \
	__asm pmulhw  xmm7, xmm3 /* x6*tg_2_16 */ \
	__asm movdqa  xmm1, xmm0 /* 1 ; tm765 */ \
	__asm pmulhw  xmm3, [ecx+2*16] /* x2*tg_2_16 */ \
	__asm psubsw  xmm5, xmm6 /* 6 ; tp465 = x1*tg_1_16-x7 */ \
	__asm paddsw  xmm4, [ecx+1*16] /* tp765 = x1+x7*tg_1_16 */ \
	__asm paddsw  xmm0, xmm4 /* t7 = tp765 + tm765 */ \
	__asm paddsw  xmm0, xmmword ptr one_corr /* correction t7 +1.0 */ \
	__asm psubsw  xmm4, xmm1 /* 1 ; tp65 = tp765 - tm765 */ \
	__asm paddsw  xmm7, [ecx+2*16] /* tm03 = x2+x6*tg_2_16 */ \
	__asm movdqa  xmm6, xmm5 /* 6 ; tp465 */ \
	__asm psubsw  xmm3, [ecx+6*16] /* tm12 = x2*tg_2_16-x6 */ \
	__asm psubsw  xmm5, xmm2 /* tm65 = tp465 - tm465 */ \
	__asm paddsw  xmm5, xmmword ptr one_corr /* correction tm65 +1.0 */ \
	__asm paddsw  xmm6, xmm2 /* 2 ; t4 = tp465 + tm465 */ \
	__asm movdqa  [ecx+7*16], xmm0 /* 0 ; save t7 in y7 (tmp) */ \
	__asm movdqa  xmm1, xmm4 /* 1 ; tp65 */ \
	__asm movdqa  xmm2, xmmword ptr cos_4_16 /* 2 ; cos_4_16 */ \
	__asm paddsw  xmm4, xmm5 /* tp65 + tm65 */ \
	__asm movdqa  xmm0, xmmword ptr cos_4_16 /* 0 ; cos_4_16 */ \
	__asm pmulhw  xmm2, xmm4 /* (tp65 + tm65)*cos_4_16 */ \
	__asm movdqa  [ecx+3*16], xmm6 /* 6 ; save t4 in y3 (tmp) */ \
	__asm psubsw  xmm1, xmm5 /* 5 ; tp65 - tm65 */ \
	__asm movdqa  xmm6, [ecx] /* 6 ; x0 */ \
	__asm pmulhw  xmm0, xmm1 /* (tp65 - tm65)*cos_4_16 */ \
	__asm movdqa  xmm5, [ecx+4*16] /* 5 ; x4 */ \
	__asm paddsw  xmm4, xmm2 /* 2 ; t6 = (tp65 + tm65)*cos_4_16 */ \
	__asm por     xmm4, xmmword ptr one_corr /* correction t6 +0.5 */ \
	__asm paddsw  xmm5, xmm6 /* tp03 = x0 + x4 */ \
	__asm psubsw  xmm6, [ecx+4*16] /* tp12 = x0 - x4 */ \
	__asm paddsw  xmm0, xmm1 /* 1 ; t5 = (tp65 - tm65)*cos_4_16 */ \
	__asm por     xmm0, xmmword ptr one_corr /* correction t5 +0.5 */ \
	__asm movdqa  xmm2, xmm5 /* 2 ; tp03 */ \
	__asm paddsw  xmm5, xmm7 /* t0 = tp03 + tm03 */ \
	__asm movdqa  xmm1, xmm6 /* 1 ; tp12 */ \
	__asm paddsw  xmm5, xmmword ptr round_inv_col /* t0 + rounder */ \
	__asm psubsw  xmm2, xmm7 /* 7 ; t3 = tp03 - tm03 */ \
	__asm movdqa  xmm7, [ecx+7*16] /* t7 */ \
	__asm paddsw  xmm6, xmm3 /* t1 = tp12 + tm12 */ \
	__asm paddsw  xmm6, xmmword ptr round_inv_col /* t1 + rounder */ \
	__asm paddsw  xmm7, xmm5 /* t0 + t7 */ \
	__asm psraw   xmm7, SHIFT_INV_COL /* y0 = t0 + t7 */ \
	__asm psubsw  xmm1, xmm3 /* 3 ; t2 = tp12 - tm12 */ \
	__asm paddsw  xmm2, xmmword ptr round_inv_corr /* correction t3 -1.0 +rounder */ \
	__asm movdqa  xmm3, xmm6 /* 3 ; t1 */ \
	__asm paddsw  xmm1, xmmword ptr round_inv_corr /* correction t2 -1.0 +rounder */ \
	__asm paddsw  xmm6, xmm4 /* t1 + t6 */ \
	__asm movdqa  [ecx], xmm7 /* 7 ; save y0 */ \
	__asm psraw   xmm6, SHIFT_INV_COL /* y1 = t1 + t6 */ \
	__asm movdqa  xmm7, xmm1 /* 7 ; t2 */ \
	__asm paddsw  xmm1, xmm0 /* t2 + t5 */ \
	__asm movdqa  [ecx+1*16], xmm6 /* 6 ; save y1 */ \
	__asm psraw   xmm1, SHIFT_INV_COL /* y2 = t2 + t5 */ \
	__asm movdqa  xmm6, [ecx+3*16] /* 6 ; t4 */ \
	__asm psubsw  xmm7, xmm0 /* 0 ; t2 - t5 */ \
	__asm paddsw  xmm6, xmm2 /* t3 + t4 */ \
	__asm psubsw  xmm2, [ecx+3*16] /* t3 - t4 */ \
	__asm psraw   xmm7, SHIFT_INV_COL /* y5 = t2 - t5 */ \
	__asm movdqa  [ecx+2*16], xmm1 /* 1 ; save y2 */ \
	__asm psraw   xmm6, SHIFT_INV_COL /* y3 = t3 + t4 */ \
	__asm psubsw  xmm5, [ecx+7*16] /* t0 - t7 */ \
	__asm psraw   xmm2, SHIFT_INV_COL /* y4 = t3 - t4 */ \
	__asm movdqa  [ecx+3*16], xmm6 /* 6 ; save y3 */ \
	__asm psubsw  xmm3, xmm4 /* 4 ; t1 - t6 */ \
	__asm movdqa  [ecx+4*16], xmm2 /* 2 ; save y4 */ \
	__asm psraw   xmm3, SHIFT_INV_COL /* y6 = t1 - t6 */ \
	__asm movdqa  [ecx+5*16], xmm7 /* 7 ; save y5 */ \
	__asm psraw   xmm5, SHIFT_INV_COL /* y7 = t0 - t7 */ \
	__asm movdqa  [ecx+6*16], xmm3 /* 3 ; save y6 */ \
	__asm movdqa  [ecx+7*16], xmm5 /* 5 ; save y7 */ \
}
#else

#endif


#ifndef __LXIDCT_INTRINSIC

#define LX_AC_SSE2(edi,i0,i1) \
__asm		movq         xmm5,mmword ptr [IDCT_TAB_COL+edx+8*i0]  \
__asm		movq         xmm6,mmword ptr [IDCT_TAB_COL+edx+8*i1]  \
__asm		punpcklqdq   xmm5,xmm5              \
__asm		punpcklqdq   xmm6,xmm6              \
__asm		pmulhw       xmm5,xmm0              \
__asm		pmulhw       xmm6,xmm0              \
__asm		paddsw       xmm5,xmm7              \
__asm		paddsw       xmm6,xmm7              \
__asm		psraw        xmm5,IDCT_TAB_MMX_AC_RC1  \
__asm		psraw        xmm6,IDCT_TAB_MMX_AC_RC1  \
__asm		movdqa       [edi+16*i0],xmm5       \
__asm		movdqa       [edi+16*i1],xmm6

#else

#endif


/***********************************************************************
***********************************************************************/
#ifndef __LXIDCT_INTRINSIC
#define LX_AC_T_SSE2(xmm0,xmm3,i,j) \
__asm		pmulhw       xmm0,xmm4                           \
__asm		pmulhw       xmm3,xmm4                           \
__asm		paddsw       xmm0,xmm6                           \
__asm		paddsw       xmm3,xmm6                           \
__asm		psraw        xmm0,IDCT_TAB_MMX_AC_RC1            \
__asm		psraw        xmm3,IDCT_TAB_MMX_AC_RC1            \
__asm		movdqa       [edi+i*16],xmm0                     \
__asm		movdqa       [edi+j*16],xmm3  
#else

#endif

/***********************************************************************
***********************************************************************/
#ifndef __LXIDCT_INTRINSIC
#define LX_AC_2_SSE2(edi,i,RC) \
__asm		movq         xmm4,mmword ptr [IDCT_TAB_COL+ecx+8*i]  \
__asm       movq         xmm5,mmword ptr [IDCT_TAB_COL+edx+8*i]  \
__asm       punpcklwd    xmm4,xmm5                     \
__asm		movdqa       xmm5,xmm4                     \
__asm		pmaddwd      xmm4,xmm0                     \
__asm		pmaddwd      xmm5,xmm2                     \
__asm       paddd        xmm4,xmm7                     \
__asm       paddd        xmm5,xmm7                     \
__asm       psrad        xmm4,RC                       \
__asm       psrad        xmm5,RC                       \
__asm       packssdw     xmm4,xmm5                     \
__asm		movdqa       [edi+16*i],xmm4            

#else

#endif



/***********************************************************************
***********************************************************************/
#ifndef __LXIDCT_INTRINSIC
#define LX_AC_T2_SSE2(i,j) \
__asm       movdqa       xmm1,xmm0                            \
__asm       movdqa       xmm7,xmm6                            \
__asm		pmaddwd      xmm0,xmm4                            \
__asm		pmaddwd      xmm1,xmm5                            \
__asm       paddd        xmm0,xmm3                            \
__asm       paddd        xmm1,xmm3                            \
__asm       psrad        xmm0,IDCT_TAB_MMX_AC_RC2             \
__asm       psrad        xmm1,IDCT_TAB_MMX_AC_RC2             \
__asm		pmaddwd      xmm6,xmm4                            \
__asm		pmaddwd      xmm7,xmm5                            \
__asm       paddd        xmm6,xmm3                            \
__asm       paddd        xmm7,xmm3                            \
__asm       psrad        xmm6,IDCT_TAB_MMX_AC_RC2             \
__asm       psrad        xmm7,IDCT_TAB_MMX_AC_RC2             \
__asm       packssdw     xmm0,xmm1                            \
__asm       packssdw     xmm6,xmm7                            \
__asm		movdqa       [edi+i*16],xmm0         \
__asm		movdqa       [edi+j*16],xmm6      

#else

#endif


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void idct_intel_col_sse2(s16* src)
{
#ifndef __LXIDCT_INTRINSIC
	__asm{
		mov ecx,[src]
		IDCT_8_INV_COL_4_SSE2
	}
#else

#endif
}
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void idct_intel_sse2(s16* blk,LxIdctInf* pos )
{
#ifndef __LXIDCT_INTRINSIC
	__asm
	{
		mov        edx, [blk]
		lea        esi, [tab_i]
		mov        ecx,8
		sub        edx,16
		sub        esi,64
			
idct_row:	    
		add        edx,16
		add        esi,64
		dec        ecx
		movdqa     xmm0, [edx]
		IDCT_8_INV_ROW_SSE2
		movdqa     [edx],xmm3
		jg         idct_row
	}
#else

#endif

	idct_intel_col_sse2(blk);
}
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

stx_inline void idct_intel_sse2_row_short_1(s16* blk, LxIdctInf* pos) 
{
#ifndef __LXIDCT_INTRINSIC
	__asm{
		mov          edx, [pos]
		mov          edx, [edx]LxIdctInf.dwColMask
		mov          edi, [blk]
		shr          edx, 24                 // row mask;
		mov          edx, [g_RowPos + edx*4]   // pos;	
		shl          edx,  4
		lea          esi,  tab_i
		movdqa       xmm0, [edi + edx ]

		shl          edx,2
		IDCT_8_INV_ROW_SSE2
		jz           ver_dc

		movdqa       xmm0,xmm3
		movdqa       xmm7,[g_mmxAcRd1]
		LX_AC_SSE2(edi,0,1)
		LX_AC_SSE2(edi,2,3)
		LX_AC_SSE2(edi,4,5)
		LX_AC_SSE2(edi,6,7)
		jmp          over 

ver_dc:  // 30 clock;
		paddsw       xmm3,mmword ptr [g_mmxDcRd1]
		psraw        xmm3,IDCT_TAB_MMX_DC_RC1
		movdqa       [edi],xmm3
		movdqa       [edi+16*1],xmm3
		movdqa       [edi+16*2],xmm3
		movdqa       [edi+16*3],xmm3
		movdqa       [edi+16*4],xmm3
		movdqa       [edi+16*5],xmm3
		movdqa       [edi+16*6],xmm3
		movdqa       [edi+16*7],xmm3
over:
	}

#else

#endif

}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

stx_inline void idct_intel_sse2_col_short_1(s16* blk, LxIdctInf* pos ) 
{
#ifndef __LXIDCT_INTRINSIC
	__asm{
		mov          edx, [pos]
		mov          edx, [edx]LxIdctInf.dwColMask
		mov          esi, [blk]
		and          edx, 0xff
		mov          edx, [g_RowPos+edx*4]
		mov          edi, esi
		IDCT_CHW_SSE2_LOAD_COL
		lea          esi, tab_i
		shl          edx,4         // IDCT_TAB_ROW table position;
		IDCT_8_INV_ROW_SSE2
		jz           hor_dc

		movdqa       xmm1,xmm3
		movdqa       xmm6,[g_mmxAcRd1]
		movdqa       xmm0,xmm1
		movdqa       xmm4,xmmword ptr [IDCT_TAB_ROW+edx] 
		punpcklwd    xmm0,xmm0   // 33221100;
		punpckhwd    xmm1,xmm1   // 77665544;

		movdqa       xmm2,xmm0
		punpckldq    xmm2,xmm2   // 11110000;
		movdqa       xmm3,xmm2 
		punpcklqdq   xmm2,xmm2   // 00000000;		
		punpckhqdq   xmm3,xmm3   // 11111111;		
		LX_AC_T_SSE2(xmm2,xmm3,0,1)

		movdqa       xmm2,xmm0
		punpckhdq    xmm2,xmm2   // 33332222;
		movdqa       xmm3,xmm2 
		punpcklqdq   xmm2,xmm2   // 22222222;		
		punpckhqdq   xmm3,xmm3   // 33333333;		
		LX_AC_T_SSE2(xmm2,xmm3,2,3)

		movdqa       xmm2,xmm1
		punpckldq    xmm2,xmm2   // 11110000;
		movdqa       xmm3,xmm2 
		punpcklqdq   xmm2,xmm2   // 00000000;		
		punpckhqdq   xmm3,xmm3   // 11111111;		
		LX_AC_T_SSE2(xmm2,xmm3,4,5)

		movdqa       xmm2,xmm1
		punpckhdq    xmm2,xmm2   // 33332222;
		movdqa       xmm3,xmm2 
		punpcklqdq   xmm2,xmm2   // 22222222;		
		punpckhqdq   xmm3,xmm3   // 33333333;		
		LX_AC_T_SSE2(xmm2,xmm3,6,7)
		jmp          over 

hor_dc:
		movdqa       xmm1, xmm3 
		paddsw       xmm1, xmmword ptr [g_mmxDcRd1]
		psraw        xmm1, IDCT_TAB_MMX_DC_RC1
		movdqa       xmm0,xmm1
		punpcklwd    xmm0,xmm0   // 33221100
		punpckhwd    xmm1,xmm1   // 77665544
		movdqa       xmm2,xmm0
		movdqa       xmm3,xmm1
		punpckldq    xmm0,xmm0   // 11110000
		punpckhdq    xmm2,xmm2   // 33332222
		punpckldq    xmm1,xmm1   // 55554444
		punpckhdq    xmm3,xmm3   // 77776666
		movdqa       xmm4,xmm0
		punpcklqdq   xmm0,xmm0
		punpckhqdq   xmm4,xmm4
		movdqa       [edi],xmm0 
		movdqa       [edi+1*16],xmm4 
		movdqa       xmm5,xmm2
		punpcklqdq   xmm2,xmm2
		punpckhqdq   xmm5,xmm5
		movdqa       [edi+2*16],xmm2
		movdqa       [edi+3*16],xmm5 
		movdqa       xmm4,xmm1
		punpcklqdq   xmm1,xmm1
		punpckhqdq   xmm4,xmm4
		movdqa       [edi+4*16],xmm1
		movdqa       [edi+5*16],xmm4 
		movdqa       xmm5,xmm3
		punpcklqdq   xmm3,xmm3
		punpckhqdq   xmm5,xmm5
		movdqa       [edi+6*16],xmm3
		movdqa       [edi+7*16],xmm5 
over:
	}
#else

#endif
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

stx_inline void idct_intel_sse2_row_short_2(s16* blk,LxIdctInf* pos) 
{
#ifndef __LXIDCT_INTRINSIC
	__asm{
		mov          edx, [pos]
		mov          edx, [edx]LxIdctInf.dwColMask
		mov          eax, [blk]
		shr          edx, 24
		mov          edx, [g_RowPos+edx*4]

		mov          ecx, edx
		shr          edx, 3
		and          ecx, 7

		shl          ecx, 4
		shl          edx, 4

		movdqa       xmm0, [eax + ecx ]
		lea          esi, tab_i
		shl          ecx,2
		IDCT_8_INV_ROW_SSE2
		movdqa       xmm0, [eax + edx ]
		movdqa       [eax],xmm3
		lea          esi, tab_i
		shl          edx,2
		IDCT_8_INV_ROW_SSE2
		movdqa       xmm0,[eax]
		movdqa       xmm2,xmm0
		punpcklwd    xmm0,xmm3
		punpckhwd    xmm2,xmm3
		movdqa       xmm7,[g_mmxAcRd2]

		LX_AC_2_SSE2(eax,0,IDCT_TAB_MMX_AC_RC2)
		LX_AC_2_SSE2(eax,1,IDCT_TAB_MMX_AC_RC2)
		LX_AC_2_SSE2(eax,2,IDCT_TAB_MMX_AC_RC2)
		LX_AC_2_SSE2(eax,3,IDCT_TAB_MMX_AC_RC2)
		LX_AC_2_SSE2(eax,4,IDCT_TAB_MMX_AC_RC2)
		LX_AC_2_SSE2(eax,5,IDCT_TAB_MMX_AC_RC2)
		LX_AC_2_SSE2(eax,6,IDCT_TAB_MMX_AC_RC2)
		LX_AC_2_SSE2(eax,7,IDCT_TAB_MMX_AC_RC2)
	}

#else

#endif
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

stx_inline void idct_intel_sse2_col_short_2(s16* blk,LxIdctInf* pos ) 
{
#ifndef __LXIDCT_INTRINSIC
	u64 g_mmxAcTmp[24];

	__asm{
		push         ebx 
		mov          ebx, [pos]
		mov          ebx, [ebx]LxIdctInf.dwColMask
		and          ebx, 0xff
		mov          esi, [blk]
		mov          ebx, [g_RowPos+ebx*4]
		mov          edx, ebx
		and          edx, 7

		lea			eax,[g_mmxAcTmp]
		add         eax,15
		and			eax,~15
		push		eax

		IDCT_CHW_SSE2_LOAD_COL
		lea          esi, tab_i
		IDCT_8_INV_ROW_SSE2
		pop			eax
		movdqa       xmmword ptr [eax],xmm3

		mov          esi, [blk]
		mov          edx, ebx
		shr          edx, 3
		push		eax
		IDCT_CHW_SSE2_LOAD_COL
		lea          esi, tab_i
		mov          ecx, ebx
		and          ecx, 7
		IDCT_8_INV_ROW_SSE2

		pop			eax
		movdqa       xmm0, xmmword ptr [eax]
		mov          edi, [blk]
		movdqa       xmm2,xmm0
		punpcklwd    xmm0,xmm3  //
		punpckhwd    xmm2,xmm3  //
		movdqa       [eax],xmm0     // save 3210 ba; 
		movdqa       [eax+16],xmm2   // save 7654 ba;

		shl          ecx,4
		shl          edx,4         // table position;
		movdqa       xmm4,xmmword ptr [IDCT_TAB_ROW+ecx] 
		movdqa       xmm6,xmmword ptr [IDCT_TAB_ROW+edx] 
		movdqa       xmm5,xmm4
		punpcklwd    xmm4,xmm6
		punpckhwd    xmm5,xmm6
		movdqa       xmm3,xmmword ptr [g_mmxAcRd2]

		punpckldq    xmm0,xmm0    //
		movdqa       xmm6,xmm0
		punpcklqdq   xmm0,xmm0 
		punpckhqdq   xmm6,xmm6 
		LX_AC_T2_SSE2(0,1)

		movdqa       xmm0,[eax]
		punpckhdq    xmm0,xmm0 
		movdqa       xmm6,xmm0
		punpcklqdq   xmm0,xmm0 
		punpckhqdq   xmm6,xmm6 
		LX_AC_T2_SSE2(2,3)

		movdqa       xmm0,[eax+16]
		punpckldq    xmm0,xmm0    //
		movdqa       xmm6,xmm0
		punpcklqdq   xmm0,xmm0 
		punpckhqdq   xmm6,xmm6 
		LX_AC_T2_SSE2(4,5)

		movdqa       xmm0,[eax+16]
		punpckhdq    xmm0,xmm0    //
		movdqa       xmm6,xmm0
		punpcklqdq   xmm0,xmm0 
		punpckhqdq   xmm6,xmm6 
		LX_AC_T2_SSE2(6,7)
		pop          ebx 
	}
#else

#endif
}


/***********************************************************************
idct_intel_sse2_row_short_3, ����ͨ��3��������3�����ϵ�SSE2�Ż���
����ֵ���ޡ�
������
block, �������������DCTϵ��������ڴ��ַ��
dst��������������DCTϵ��������ڴ��ַ��
nRow������������ܷ����е���Ŀ��
dwPos,���������ÿ�������е�λ�á�
***********************************************************************/
stx_inline void idct_intel_sse2_row_short_3(s16* blk, LxIdctInf* pos) 
{
#ifndef __LXIDCT_INTRINSIC
	__asm{
		mov          eax, [pos]
		mov          eax, [eax]LxIdctInf.dwColMask
		shr          eax, 24                     // row mask;
		mov          edi, [blk]
		mov          ecx, [g_RowPos+eax*4]       // row pos;
		movzx        eax, BYTE PTR[g_RowNz+eax]  // row num;

next_row:
		mov          edx, ecx
		and          edx, 7
		shr          ecx, 3
		shl          edx, 4
		movdqa       xmm0, [edi + edx ]
		shl          edx, 2
		lea          esi, tab_i
		add          esi, edx 
		shr          edx, 2
		dec          eax
		IDCT_8_INV_ROW_SSE2
		movdqa       [edi + edx],xmm3
		jg           next_row
	}
#else

#endif

	idct_intel_col_sse2(blk);
}


/***********************************************************************
void idct_sse2_ex(s16* block,s16* dst, LxIdctInf* pos )
����ͨ����MMX�Ż���
����ֵ���ޡ�
������
block, �������������DCTϵ��������ڴ��ַ��
dst��������������DCTϵ��������ڴ��ַ��
pos��������������ݽṹ��ַ�����DCTϵ���ķ�������
***********************************************************************/

void idct_sse2_ex(s16* blk, LxIdctInf* pos )
{
	DWORD const dwRowMask = GET_ROW_MASK(pos->dwColMask);
	DWORD const dwRowNum = g_RowNz[dwRowMask];
	DWORD const dwColMask = GET_COL_MASK(pos->dwColMask);
	DWORD const dwColNum = g_RowNz[dwColMask];

	if( dwRowNum == 1 && dwColNum == 1 ) {
		idct_sparse_ac_sse2(blk,pos );// ����ͨ��0,1��
		return;
	}

	// ����Ƿ����ݶ���һ���ϣ�
	if( 1 == dwRowNum ) {   // all the nz data in one row; 
		idct_intel_sse2_row_short_1( blk,pos );
		return;
	}

	// ����Ƿ����ݶ���һ���ϣ�	
	if( 1 == dwColNum ) {   // all the nz data in one col; 
		idct_intel_sse2_col_short_1( blk, pos );
		return;
	}

	if( 2 == dwRowNum ) { 
		idct_intel_sse2_row_short_2( blk,pos );
		return;
	}

	if( 2 == dwColNum ) {   
		idct_intel_sse2_col_short_2(blk,pos ); 
		return;
	}

	if( 6 >= dwRowNum ) { // only do valid rows;
		idct_intel_sse2_row_short_3(blk,pos);
		return;
	}

	idct_intel_sse2(blk,pos); 
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void intel_idct_sse2_init( idct_proc_entry entry[8][8] )
{
	s32 i,j;

	for( i = 0; i < 8; i ++ ) {

		for( j = 0; j < 8; j ++ ) {

			entry[i][j] = idct_intel_sse2;

 			if( i == 0 && j == 0 ) {
 				entry[i][j] = idct_sparse_ac_sse2;
 				continue;
 			}

			if( i == 0 ) {
				entry[i][j] = idct_intel_sse2_row_short_1;
				continue;
			}

			if( j == 0 ) {
				entry[i][j] = idct_intel_sse2_col_short_1;
				continue;
			}

			if( i == 1 ) {
				entry[i][j] = idct_intel_sse2_row_short_2;
				continue;
			}

			if( j == 1 ) {
				entry[i][j] = idct_intel_sse2_col_short_2;
				continue;
			}

			if( i <= 3 ) {
				entry[i][j] = idct_intel_sse2_row_short_3;
				continue;
			}			
		}
	}
}

/******************************************
idct end
*******************************************/