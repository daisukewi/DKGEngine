// LxIDCT.cpp: implementation of the LxIDCT class.
//
//////////////////////////////////////////////////////////////////////


#include "LxIDCT.h"

#include "stx_debug.h"
#include "math.h"

#include "../mpegdef.h"


DECLARE_ALIGNED_16( const s32, IDCT_TAB[8][8] ) =
{
	{2048,	2048,	2048,	2048,	2048,	2048,	2048,	2048,	},
	{2841,	2408,	1609,	565,	-565,	-1609,	-2408,	-2841,	},
	{2676,	1108,	-1108,	-2676,	-2676,	-1108,	1108,	2676,	},
	{2408,	-565,	-2841,	-1609,	1609,	2841,	565,	-2408,	},
	{2048,	-2048,	-2048,	2048,	2048,	-2048,	-2048,	2048,	},
	{1609,	-2841,	565,	2408,	-2408,	-565,	2841,	-1609,	},
	{1108,	-2676,	2676,	-1108,	-1108,	2676,	-2676,	1108,	},
	{565,	-1609,	2408,	-2841,	2841,	-2408,	1609,	-565,	},
};

/***********************************************************************
***********************************************************************/
DECLARE_ALIGNED_16( const s16, IDCT_TAB_ROW[8][8] ) =
{
	{	16384,	16384,	16384,	16384,	16384,	16384,	16384,	16384,	},
	{	22725,	19266,	12873,	4520,	-4520,	-12873,	-19266,	-22725,	},
	{	21407,	8867,	-8867,	-21407,	-21407,	-8867,	8867,	21407,	},
	{	19266,	-4520,	-22725,	-12873,	12873,	22725,	4520,	-19266,	},
	{	16384,	-16384,	-16384,	16384,	16384,	-16384,	-16384,	16384,	},
	{	12873,	-22725,	4520,	19266,	-19266,	-4520,	22725,	-12873,	},
	{	8867,	-21407,	21407,	-8867,	-8867,	21407,	-21407,	8867,	},
	{	4520,	-12873,	19266,	-22725,	22725,	-19266,	12873,	-4520,	},
};

/***********************************************************************
***********************************************************************/
DECLARE_ALIGNED_16( const s16, IDCT_TAB_COL[8][8][4] ) = 
{
	{
		{	16384,	16384,	16384,	16384,	},
		{	16384,	16384,	16384,	16384,	},
		{	16384,	16384,	16384,	16384,	},
		{	16384,	16384,	16384,	16384,	},
		{	16384,	16384,	16384,	16384,	},
		{	16384,	16384,	16384,	16384,	},
		{	16384,	16384,	16384,	16384,	},
		{	16384,	16384,	16384,	16384,	},
	},
	{
		{	22725,	22725,	22725,	22725,	},
		{	19266,	19266,	19266,	19266,	},
		{	12873,	12873,	12873,	12873,	},
		{	4520,	4520,	4520,	4520,	},
		{	-4520,	-4520,	-4520,	-4520,	},
		{	-12873,	-12873,	-12873,	-12873,	},
		{	-19266,	-19266,	-19266,	-19266,	},
		{	-22725,	-22725,	-22725,	-22725,	},
	},
	{
		{	21407,	21407,	21407,	21407,	},
		{	8867,	8867,	8867,	8867,	},
		{	-8867,	-8867,	-8867,	-8867,	},
		{	-21407,	-21407,	-21407,	-21407,	},
		{	-21407,	-21407,	-21407,	-21407,	},
		{	-8867,	-8867,	-8867,	-8867,	},
		{	8867,	8867,	8867,	8867,	},
		{	21407,	21407,	21407,	21407,	},
	},
	{
		{	19266,	19266,	19266,	19266,	},
		{	-4520,	-4520,	-4520,	-4520,	},
		{	-22725,	-22725,	-22725,	-22725,	},
		{	-12873,	-12873,	-12873,	-12873,	},
		{	12873,	12873,	12873,	12873,	},
		{	22725,	22725,	22725,	22725,	},
		{	4520,	4520,	4520,	4520,	},
		{	-19266,	-19266,	-19266,	-19266,	},
	},
	{
		{	16384,	16384,	16384,	16384,	},
		{	-16384,	-16384,	-16384,	-16384,	},
		{	-16384,	-16384,	-16384,	-16384,	},
		{	16384,	16384,	16384,	16384,	},
		{	16384,	16384,	16384,	16384,	},
		{	-16384,	-16384,	-16384,	-16384,	},
		{	-16384,	-16384,	-16384,	-16384,	},
		{	16384,	16384,	16384,	16384,	},
	},
	{
		{	12873,	12873,	12873,	12873,	},
		{	-22725,	-22725,	-22725,	-22725,	},
		{	4520,	4520,	4520,	4520,	},
		{	19266,	19266,	19266,	19266,	},
		{	-19266,	-19266,	-19266,	-19266,	},
		{	-4520,	-4520,	-4520,	-4520,	},
		{	22725,	22725,	22725,	22725,	},
		{	-12873,	-12873,	-12873,	-12873,	},
	},
	{
		{	8867,	8867,	8867,	8867,	},
		{	-21407,	-21407,	-21407,	-21407,	},
		{	21407,	21407,	21407,	21407,	},
		{	-8867,	-8867,	-8867,	-8867,	},
		{	-8867,	-8867,	-8867,	-8867,	},
		{	21407,	21407,	21407,	21407,	},
		{	-21407,	-21407,	-21407,	-21407,	},
		{	8867,	8867,	8867,	8867,	},
	},
	{
		{	4520,	4520,	4520,	4520,	},
		{	-12873,	-12873,	-12873,	-12873,	},
		{	19266,	19266,	19266,	19266,	},
		{	-22725,	-22725,	-22725,	-22725,	},
		{	22725,	22725,	22725,	22725,	},
		{	-19266,	-19266,	-19266,	-19266,	},
		{	12873,	12873,	12873,	12873,	},
		{	-4520,  -4520,	-4520,	-4520,	},
	},
};

DECLARE_ALIGNED_16( const s32, IDCT_TAB_AAN[8*8] ) = 
{
	4096,	4096,	4096,	4096,	4096,	4096,	4096,	4096,	
	4096,	3472,	2320,	815,	-815,	-2320,	-3472,	-4096,	
	4096,	1697,	-1697,	-4096,	-4096,	-1697,	1697,	4096,	
	4096,	-961,	-4832,	-2737,	2737,	4832,	961,	-4096,	
	4096,	-4096,	-4096,	4096,	4096,	-4096,	-4096,	4096,	
	4096,	-7231,	1438,	6130,	-6130,	-1438,	7231,	-4096,	
	4096,	-9889,	9889,	-4096,	-4096,	9889,	-9889,	4096,	
	4096,	-11664,	17457,	-20592,	20592,	-17457,	11664,	-4096,	
};


static s16 iclip[8192]; /* clipping table */
s16* const iclp = iclip+4096;

u32 g_dwBlockInf[64];
u8  g_RowNz[256];
u32 g_RowPos[256];
u32 g_dwColMsk[8];

s32        g_dwByte2Int32[256];
u8*        g_pByAbs;
static u8  g_byAbsVal[512];
static u8  clip[8192];
u8* const  clip_ptr = clip + 4096;

void InitByte2Int32()
{
	s32 i;
	g_pByAbs = g_byAbsVal + 256;

	for( i = 0; i < 256; i ++ ) {
		g_dwByte2Int32[i] = i * 0x01010101;
		g_pByAbs[i] = g_pByAbs[-i] = i;
	}

	for( i = 0; i < 4096; i ++ ) {
		clip[i] = 0;
	}
	for( i = 0; i < 256; i ++ ) {
		clip_ptr[i] = i;
	}
	for( i = 256; i < 4096; i ++ ) {
		clip_ptr[i] = 255;
	}
}



void init_aan_tab();


STX_INTERF(DCT_COE_STA_INF);

struct DCT_COE_STA_INF{
	u64    qwNz;
	u64    qwAll;
	u64    qwDc1;
	u64    qwAc1;
	u64    qwRow1Dc;
	u64    qwCol1Dc;
	u64    qwRow1Ac;
	u64    qwCol1Ac;
	u64    qwRow2;
	u64    qwCol2;
	u64    qwRowNum;
	u64    qwRowDc1;
	u64    qwRowAc1;
	u64    qwRowAc2;
	u32    dwTime;
};


static DCT_COE_STA_INF intra_dct_inf;
static DCT_COE_STA_INF non_intra_dct_inf;

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void dct_coe_statistic(b32 bIntra, LxIdctInf* pos )
{
	DCT_COE_STA_INF* pInf = bIntra ? &intra_dct_inf : &non_intra_dct_inf;

	u32 dwTime = timeGetTime();

	if( !pInf->dwTime ) {
		pInf->dwTime = dwTime;
	}
	else if( dwTime - pInf->dwTime > 30*1000 && bIntra) {

		f32 fDc;
		f32 fAc;
		f32 fRow1Dc;
		f32 fRow1Ac;
		f32 fCol1Dc;
		f32 fCol1Ac;
		f32 fRow2;
		f32 fCol2;
		f32 fRowNz;
		f32 fRowDc;
		f32 fRowAc1;
		f32 fRowAc2;
		f32 fNz;

		//ASSERT(0);

		if( bIntra ) {
			xlog("INTRA DCT:\n");
		}
		else {
			xlog("NON INTRA DCT:\n");
		}

		fDc = (f32)pInf->qwDc1 * 100 / pInf->qwAll;
		xlog("only dc = %f8\n",fDc);

		fAc = (f32)pInf->qwAc1 * 100 / pInf->qwAll;
		xlog("only ac = %f8\n",fAc);

		fRow1Dc = (f32)pInf->qwRow1Dc * 100 / pInf->qwAll;
		xlog("only 1 row , dc  = %f8\n",fRow1Dc);

		fRow1Ac = (f32)pInf->qwRow1Ac * 100 / pInf->qwAll;
		xlog("only 1 row, ac = %f8\n",fRow1Ac);

		fCol1Dc = (f32)pInf->qwCol1Dc * 100 / pInf->qwAll;
		xlog("only 1 col, dc  = %f8\n",fCol1Dc);

		fCol1Ac = (f32)pInf->qwCol1Ac * 100 / pInf->qwAll;
		xlog("only 1 col, ac  = %f8\n",fCol1Ac);

		fRow2 = (f32)pInf->qwRow2 * 100 / pInf->qwAll;
		xlog("only 2 row = %f8\n",fRow2);

		fCol2 = (f32)pInf->qwCol2 * 100 / pInf->qwAll;
		xlog("only 2 col = %f8\n",fCol2);

		fRowNz = (f32) pInf->qwRowNum * 100 / (pInf->qwAll*8);
		xlog("non zero rows  = %f8\n", fRowNz);

		fRowDc = (f32) pInf->qwRowDc1 * 100 / pInf->qwRowNum;
		xlog("valid row, dc = %f8\n",fRowDc);

		fRowAc1 = (f32) pInf->qwRowAc1 * 100 / pInf->qwRowNum;
		xlog("valid row, ac 1 = %f8\n",fRowAc1);

		fRowAc2 = (f32) pInf->qwRowAc2 * 100 / pInf->qwRowNum;
		xlog("valid row, ac 2 = %f8\n",fRowAc2);

		fNz = (f32) pInf->qwNz / pInf->qwAll;
		xlog("average nz = %f8\n",fNz);

		return;
	}

	pInf->qwAll ++;

	pInf->qwNz += GET_NZ_NUM(pos->dwNzInf);

	if( GET_NZ_NUM(pos->dwNzInf) == 1 ) {
		if( GET_NZ_POS(pos->dwNzInf) == 0 ) {
			pInf->qwDc1 ++;
		}
		else {
			pInf->qwAc1 ++;
		}
	}
	else {

		s32    i;
		// ������ͨ��3��

		u32 const dwRowMask = GET_ROW_MASK(pos->dwColMask);
		u32 const dwRowNum = g_RowNz[dwRowMask];
		u32 const dwColMask = GET_COL_MASK(pos->dwColMask);
		u32 const dwColNum = g_RowNz[dwColMask];

		if( 1 == dwRowNum ) {   // all the nz data in one row;
			s32 const nRow = g_RowPos[dwRowMask];
			if( 0 == nRow ) {
				pInf->qwRow1Dc ++;
			}
			else{
				pInf->qwRow1Ac ++;
			}
		}
		else if( 1 == dwColNum ) {   // all the nz data in one col;
			s32 const nCol = g_RowPos[dwColMask];
			if( 0 == nCol ) {
				pInf->qwCol1Dc ++;
			}
			else{
				pInf->qwCol1Ac ++;
			}
		}
		else if( 2 == dwRowNum ) {
			pInf->qwRow2 ++;
		}
		else if( 2 == dwColNum ) {
			pInf->qwCol2 ++;
		}
		else {
			for( i = 0; i < 8; i ++ )	{
				u32 dwRowInf = pos->byRowPos[i];
				u32 dwRowNz = g_RowNz[dwRowInf];
				u32 dwRowPos = g_RowPos[dwRowInf];
				if( dwRowNz == 1 ){
					if( dwRowPos == 0 ) {
						pInf->qwRowDc1 ++;
					}
					else{
						pInf->qwRowAc1 ++;
					}
				}
				else if( dwRowNz == 2 ) {
					pInf->qwRowAc2 ++;
				}
			}
			pInf->qwRowNum += dwRowNum;
		}
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void Initialize_Fast_IDCT()
{
	s32 i;

	InitByte2Int32();

	for (i= -4096; i<4096; i++) {
		iclp[i] = (i<-256) ? -256 : ((i>255) ? 255 : i);
	}

	init_aan_tab();

	
#if 0
	s16 val;

	for( i = 0; i < 8; i ++ ) {
		f64 scale = (i == 0) ? sqrt(0.125) : 0.5;
		TRACE0("{\n");
		for( s32 j = 0; j < 8; j ++ ) {

			f64 s = scale * cos((PI/8.0)*i*(j + 0.5));
			s = s * sqrt(2);

			val = (s16)( (1<<IDCT_TAB_RC) * s + ( s >= 0 ? 0.5 : -0.5) );
			IDCT_TAB[i][j] = val;
			TRACE1("%d,\t",IDCT_TAB[i][j]);

//			val = (s16)(  (1<<IDCT_TAB_MMX_SCALE) * s + ( s >= 0 ? 0.5 : -0.5)  );
//			IDCT_TAB_ROW[i][j] = val;
//			TRACE1("%d,\t",IDCT_TAB_ROW[i][j]);

//			TRACE0("{\t");
//			for( s32 k = 0; k < 4; k ++ ) {
//				IDCT_TAB_COL[i][j][k] = val;
//				TRACE1("%d,\t",val);
//			}
//			TRACE0("},\n");
			Sleep(1);
		}
		TRACE0("},\n");
	}
#endif

	for( i = 0; i < 256; i ++ ) {
		s32 j;
		s32 nz = 0;
		g_RowPos[i] = 0;
		for( j = 0; j < 8; j ++ ) {
			if( i & (1<<j) ){
				g_RowPos[i] |= j<<(nz*3);
				nz ++;
			}
		}
		g_RowNz[i] = nz;
	}
	for( i = 0; i < 8; i ++ ) {
//		g_RowPos[1<<i] = i;
		g_dwColMsk[i] = (1<<i) | (1<<(i+8)) | (1<<(i+16)) | (1<<(i+24));
	}

	for( i = 0; i < 8; i ++ ) {
		s32 j;
		for( j = 0; j < 8; j ++ ) {
			LxNzInf inf;
			inf.byColMask = 1<<j;
			inf.byBlkNz   = 1;
			inf.byBlkNzPos = i*8+j;
			inf.byRowMask = 1<<i;
			g_dwBlockInf[i*8+j] = *(u32*)&inf;
		}
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void adder_128_c(s16 *blk,unsigned char* dst,s32 pit)
{
#define ADD_LINE \
	dst[0] = clip_ptr[ blk[0] + 128];\
	dst[1] = clip_ptr[ blk[1] + 128];\
	dst[2] = clip_ptr[ blk[2] + 128];\
	dst[3] = clip_ptr[ blk[3] + 128];\
	dst[4] = clip_ptr[ blk[4] + 128];\
	dst[5] = clip_ptr[ blk[5] + 128];\
	dst[6] = clip_ptr[ blk[6] + 128];\
	dst[7] = clip_ptr[ blk[7] + 128]
#define NEXT_LINE \
	dst += pit;\
	blk += 8

	ADD_LINE;NEXT_LINE;
	ADD_LINE;NEXT_LINE;
	ADD_LINE;NEXT_LINE;
	ADD_LINE;NEXT_LINE;
	ADD_LINE;NEXT_LINE;	
	ADD_LINE;NEXT_LINE;
	ADD_LINE;NEXT_LINE;
	ADD_LINE;

#undef ADD_LINE
#undef NEXT_LINE
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void idct_sparse_dc( s16* blk )
{
	s32		val32;
	s32*	b32;
	s32		val = blk[0];

	val = iclp[( val + 4 ) >> 3];	
	val32 = (val << 16) | ( val & 0xffff );
	b32 = (s32*)blk;
	b32[0] = b32[1] = b32[2] = b32[3] = b32[4] = b32[5] = b32[6] = b32[7] = val32;
	b32 += 8;
	b32[0] = b32[1] = b32[2] = b32[3] = b32[4] = b32[5] = b32[6] = b32[7] = val32;
	b32 += 8;
	b32[0] = b32[1] = b32[2] = b32[3] = b32[4] = b32[5] = b32[6] = b32[7] = val32;
	b32 += 8;
	b32[0] = b32[1] = b32[2] = b32[3] = b32[4] = b32[5] = b32[6] = b32[7] = val32;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void idct_sparse_ac( s16* blk, LxIdctInf* pos )
{
	s32 tmp[8];  // ;
	s32 i;
	s32 hnc;
	s32 vnc;

	s32 np;
	s32 ac;
	s32 nc;

	u32 const dwRowMask = GET_ROW_MASK(pos->dwColMask);
	u32 const dwColMask = GET_COL_MASK(pos->dwColMask);

	hnc = g_RowPos[dwColMask];
	vnc = g_RowPos[dwRowMask];

	np = hnc*8 + vnc ;
	if( 0 == np ) {
		idct_sparse_dc(blk);
		return;
	}

	ac = blk[ np ];
	nc = hnc ? hnc : vnc;

	tmp[0] = ( ( ac * IDCT_TAB[nc][0] + IDCT_TAB_ROUND0 ) >> IDCT_TAB_RC0 );
	tmp[1] = ( ( ac * IDCT_TAB[nc][1] + IDCT_TAB_ROUND0 ) >> IDCT_TAB_RC0 );
	tmp[2] = ( ( ac * IDCT_TAB[nc][2] + IDCT_TAB_ROUND0 ) >> IDCT_TAB_RC0 );
	tmp[3] = ( ( ac * IDCT_TAB[nc][3] + IDCT_TAB_ROUND0 ) >> IDCT_TAB_RC0 );
	tmp[4] = ( ( ac * IDCT_TAB[nc][4] + IDCT_TAB_ROUND0 ) >> IDCT_TAB_RC0 );
	tmp[5] = ( ( ac * IDCT_TAB[nc][5] + IDCT_TAB_ROUND0 ) >> IDCT_TAB_RC0 );
	tmp[6] = ( ( ac * IDCT_TAB[nc][6] + IDCT_TAB_ROUND0 ) >> IDCT_TAB_RC0 );
	tmp[7] = ( ( ac * IDCT_TAB[nc][7] + IDCT_TAB_ROUND0 ) >> IDCT_TAB_RC0 );

	if( hnc ) {
		// horizontal ac;
		if( vnc ){
			// vertical ac;
			for( i = 0; i < 8; i ++ ) {
				ac = IDCT_TAB[vnc][i];
				blk[0+i*8] = iclp[ ( tmp[0] * ac + IDCT_TAB_ROUND1 ) >> IDCT_TAB_RC1 ];
				blk[1+i*8] = iclp[ ( tmp[1] * ac + IDCT_TAB_ROUND1 ) >> IDCT_TAB_RC1 ];
				blk[2+i*8] = iclp[ ( tmp[2] * ac + IDCT_TAB_ROUND1 ) >> IDCT_TAB_RC1 ];
				blk[3+i*8] = iclp[ ( tmp[3] * ac + IDCT_TAB_ROUND1 ) >> IDCT_TAB_RC1 ];
				blk[4+i*8] = iclp[ ( tmp[4] * ac + IDCT_TAB_ROUND1 ) >> IDCT_TAB_RC1 ];
				blk[5+i*8] = iclp[ ( tmp[5] * ac + IDCT_TAB_ROUND1 ) >> IDCT_TAB_RC1 ];
				blk[6+i*8] = iclp[ ( tmp[6] * ac + IDCT_TAB_ROUND1 ) >> IDCT_TAB_RC1 ];
				blk[7+i*8] = iclp[ ( tmp[7] * ac + IDCT_TAB_ROUND1 ) >> IDCT_TAB_RC1 ];
			}
		}
		else {
			// vertical dc;
			s16 tmp0[8];
#	define LX_DC(i) tmp0[i] = iclp[( tmp[i] + IDCT_TAB_DC_ROUND1 ) >> IDCT_TAB_DC_RC1 ]
			LX_DC(0);LX_DC(1);LX_DC(2);LX_DC(3);
			LX_DC(4);LX_DC(5);LX_DC(6);LX_DC(7);
#	undef  LX_DC
#	define LX_DC(i) \
			*(s32*)(blk+i*8) = *(s32*)(tmp0);     \
			*(s32*)(blk+i*8+2) = *(s32*)(tmp0+2); \
			*(s32*)(blk+i*8+4) = *(s32*)(tmp0+4); \
			*(s32*)(blk+i*8+6) = *(s32*)(tmp0+6);

			LX_DC(0);LX_DC(1);LX_DC(2);LX_DC(3);
			LX_DC(4);LX_DC(5);LX_DC(6);LX_DC(7);
#	undef  LX_DC
		}
	}
	else  {  // pos is at x = 0;
		// vertical ac;
		// horizontal dc;
		s32 val32;
#	define LX_DC(i)  \
	val32 = iclp[( tmp[i] + IDCT_TAB_DC_ROUND1 ) >> IDCT_TAB_DC_RC1];\
	val32 = (val32<<16)|(val32&0xffff);\
	*(s32*)(blk+i*8)   = val32;     \
	*(s32*)(blk+i*8+2) = val32;     \
	*(s32*)(blk+i*8+4) = val32;     \
	*(s32*)(blk+i*8+6) = val32;
			LX_DC(0);LX_DC(1);LX_DC(2);LX_DC(3);
			LX_DC(4);LX_DC(5);LX_DC(6);LX_DC(7);
#	undef  LX_DC
	}
}


static const s16 preSC[64] = {
#if 0
	16384, 22725, 21407, 19266,  16384, 12873, 8867,  4520,
	22725, 31521, 29692, 26722,  22725, 17855, 12299, 6270,
	21407, 29692, 27969, 25172,  21407, 16819, 11585, 5906,
	19266, 26722, 25172, 22654,  19266, 15137, 10426, 5315,
	16384, 22725, 21407, 19266,  16384, 12873, 8867,  4520,
	12873, 17855, 16819, 15137,  25746, 20228, 13933, 7103,
	17734, 24598, 23170, 20853,  17734, 13933, 9597,  4892,
	18081, 25080, 23624, 21261,  18081, 14206, 9785,  4988
#else
	16384,  22725,  21407,  19266,  16384,  12873,    8867,     4520,  
	22725,  31521,  29692,  26722,  22725, 	17855, 	  12299, 	6270, 
	21407, 	29692, 	27969,	25172,	21407,	16819, 	  11585, 	5906, 
	19266,	26722, 	25172, 	22654, 	19266,	15137,	  10426,	5315,
	16384, 	22725, 	21407, 	19266,	16384, 	12873,    8867,	    4520,
	12873, 	17855, 	16819, 	15137,	12873, 	10114,    6967, 	3552, 
	8867,	12299, 	11585, 	10426, 	8867, 	6967,     4799, 	2446, 
	4520,	6270,	5906,	5315,	4520,	3552,     2446,	    1247
#endif
};


// const f64 g_fC1 = 1.0;
// const f64 g_fC2 = 1.8477590650225537; //2 * cos (PI/8);
// const f64 g_fC4 = 1.4142135623730951; //sqrt(2.0);
// const f64 g_fC6 = -9.2559631349317831e+061;//2 * sin (PI/8);
#define g_fC1 1.0
#define g_fC2 1.8477590650225537
#define g_fC4 1.4142135623730951
#define g_fC6 (-9.2559631349317831e+061)

//#define SCALEAAN(x0,i,j)
//#define SCALEAAN(x0,i,j)  x0 = ( x0 * (s32)preSC[i*8+j] ) >> ROLAAN ;
#define SCALEAAN(x0,i,j)  x0 = ( x0 * (s32)preSC[i*8+j] +  ROUNDAAN ) >> ROLAAN ;



/*
	1	1		1			1				1				1			1		1
	1	c2-1	1-c2+c4		c6-c4+c2-1		1-c6+c4-c2		-1-c4+c2	1-c2	-1
	1	-1+c4	-c4+1		-1				-1				-c4+1		-1+c4	1
	1	C6-1	1-c6-c4		-c2+c4+c6-1		1+c2-c4-c6		-1+c4+c6	1-c6	-1
	1	-1		-1			1				1				-1			-1		1
	1	-c6-1	1+c6-c4		C2+c4-c6-1		1-c2-c4+c6		-1+c4-c6	1+c6	-1
	1	-1-c4	C4+1		-1				-1				C4+1		-1-c4	1
	1	-c2-1	1+c2+c4		-c6-c4-c2-1		1+c6+c4+c2		-1-c4-c2	1+c2	-1 
*/
//__declspec (align(16)) const s32 IDCT_TAB_AAN[8*8] = {
//	C1,	C1		,C1			,C1				,C1				,C1			,C1		,C1,
//	C1,	C2-C1	,C1-C2+C4	,C6-C4+C2-C1	,C1-C6+C4-C2	,-C1-C4+C2	,C1-C2	,-C1,
//	C1,	-C1+C4	,-C4+C1		,-C1			,-C1			,-C4+C1		,-C1+C4	,C1,
//	C1,	C6-C1	,C1-C6-C4	,-C2+C4+C6-C1	,C1+C2-C4-C6	,-C1+C4+C6	,C1-C6	,-C1,
//	C1,	-C1		,-C1		,C1				,C1				,-C1		,-C1	,C1,
//	C1,	-C6-C1	,C1+C6-C4	,C2+C4-C6-C1	,C1-C2-C4+C6	,-C1+C4-C6	,C1+C6	,-C1,
//	C1,	-C1-C4	,C4+C1		,-C1			,-C1			,C4+C1		,-C1-C4	,C1,
//	C1,	-C2-C1	,C1+C2+C4	,-C6-C4-C2-C1	,C1+C6+C4+C2	,-C1-C4-C2	,C1+C2	,-C1 
//};
__declspec (align(16)) 
const f64 IDCT_TAB_AAN_D[8*8] = {

	g_fC1,g_fC1,g_fC1,g_fC1,g_fC1,g_fC1,g_fC1,g_fC1,

	g_fC1,	g_fC2-g_fC1	,g_fC1-g_fC2+g_fC4	,g_fC6-g_fC4+g_fC2-g_fC1	,
		g_fC1-g_fC6+g_fC4-g_fC2	,-g_fC1-g_fC4+g_fC2	,g_fC1-g_fC2	,-g_fC1,

	g_fC1,	-g_fC1+g_fC4	,-g_fC4+g_fC1		,-g_fC1			,-g_fC1	,
		-g_fC4+g_fC1		,-g_fC1+g_fC4	,g_fC1,

	g_fC1,	g_fC6-g_fC1	,g_fC1-g_fC6-g_fC4	,-g_fC2+g_fC4+g_fC6-g_fC1	,
		g_fC1+g_fC2-g_fC4-g_fC6	,-g_fC1+g_fC4+g_fC6	,g_fC1-g_fC6	,-g_fC1,

	g_fC1,	-g_fC1		,-g_fC1		,g_fC1				,g_fC1			,
		-g_fC1		,-g_fC1	,g_fC1,

	g_fC1,	-g_fC6-g_fC1	,g_fC1+g_fC6-g_fC4	,g_fC2+g_fC4-g_fC6-g_fC1,
		g_fC1-g_fC2-g_fC4+g_fC6	,-g_fC1+g_fC4-g_fC6	,g_fC1+g_fC6	,-g_fC1,

	g_fC1,	-g_fC1-g_fC4	,g_fC4+g_fC1		,-g_fC1			,-g_fC1	,
		g_fC4+g_fC1		,-g_fC1-g_fC4	,g_fC1,

	g_fC1,	-g_fC2-g_fC1	,g_fC1+g_fC2+g_fC4	,-g_fC6-g_fC4-g_fC2-g_fC1,
		g_fC1+g_fC6+g_fC4+g_fC2	,-g_fC1-g_fC4-g_fC2	,g_fC1+g_fC2	,-g_fC1 
};

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void init_aan_tab()
{
#if 0
	for( s32 i = 0; i < 8; i ++ ) {
		TRACE0("{\n\t");
		for( s32 j = 0; j < 8; j ++ ) {
			s32 s = MAKE_SCALE(IDCT_TAB_AAN_D[i*8+j]);
			TRACE0("{\t");
			for( s32 k = 0; k < 4; k ++ ) {
				TRACE1("%d,\t",s );
				stx_sleep(1);
			}
			TRACE0("},\n\t");	
		}
		TRACE0("},\n");	
	}
#endif
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void idct_aan_presc(s16* src,s16* dst)
{
	s32 i,j;
	for( i = 0; i < 8; i ++ ) {
		for( j = 0; j < 8; j ++ ) {
			dst[i*8+j] = (s16) ( ( (s32)src[i*8+j] * preSC[i*8+j] +  ROUNDAAN ) >> ROLAAN ) ;
		}
	}
}

/*
// do scale here : do scale at decode block = 1470 : 1200;  improve 22%;

	val = ( val * qmat[nQScale][j] ) >> 4;

    qmat[nQScale][j] = ( qmat[nQScale][j] * preSC[j] + ROUNDAAN ) >> ROLAAN ;
*/

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
//  do 80 + 64 times of multiply; fast idct :176;

stx_inline void  idct_aan_row(s16* blk,s32* blk32, s32 i )
{
	s32    x0,x1,x2,x3,x4,x5,x6,x7,xa,xb;
	s32    t0,t1;
	
	x0 = blk[0];
	x1 = blk[1];
	x2 = blk[2];
	x3 = blk[3];
	x4 = blk[4];
	x5 = blk[5];
	x6 = blk[6];
	x7 = blk[7];
	SCALEAAN(x0,i,0);
	SCALEAAN(x4,i,4);
	SCALEAAN(x3,i,3);      
	SCALEAAN(x5,i,5);     
	SCALEAAN(x2,i,2);     
	SCALEAAN(x6,i,6);     
	SCALEAAN(x1,i,1);     
	SCALEAAN(x7,i,7);     
	xa = x0;
	xb = x4;
	x4 = x5 - x3;       
	t1 = x5 + x3;       
	x3 = (x2+x6)<<RC0;  
	x2 = (x2-x6)*C4-x3; 
	t0 = x1 + x7;       
	x6=  x1 - x7;       
	x7=  (t0 + t1)<<RC0;
	x5 = (t0 - t1)*C4;  
	t0=C6*(x4+x6);      
	x4=C6sC2*x4-t0;     
	x6=C6pC2*x6-t0;     
	t0=x6-x7;           
	x1=(xa-xb)<<RC0;      
	t1=t0-x5;           
	x6=(xa+xb)<<RC0;      
	x0=x4-t1;           
	x4=x3+x6;           
	x6-=x3;             
	x3=x1+x2;           
	x5=x1-x2;           
	
	blk32[0] = ( (x4+x7+ROUND0) >> RC00 );
	blk32[1] = ( (x3+t0+ROUND0) >> RC00 );
	blk32[2] = ( (x5-t1+ROUND0) >> RC00 );
	blk32[3] = ( (x6-x0+ROUND0) >> RC00 );
	blk32[4] = ( (x6+x0+ROUND0) >> RC00 );
	blk32[5] = ( (x5+t1+ROUND0) >> RC00 );
	blk32[6] = ( (x3-t0+ROUND0) >> RC00 );
	blk32[7] = ( (x4-x7+ROUND0) >> RC00 );
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

stx_inline void  idct_aan_col( s32* blk32, s16* blk )
{
	s32    x0,x1,x2,x3,x4,x5,x6,x7,xa,xb;
	s32    t0,t1;

	x0 = blk32[0];
	x1 = blk32[8] ;
	x2 = blk32[16];
	x3 = blk32[24];
	x4 = blk32[32];
	x5 = blk32[40];
	x6 = blk32[48];
	x7 = blk32[56];
	xa = x0;
	xb = x4;
	
	x4 = x5 - x3;        
	t1 = x5 + x3;        			
	x3 = (x2+x6)<<RC0;   
	x2 = (x2-x6)*C4-x3;  
	t0 = x1 + x7;        
	x6=  x1 - x7;        
	x7=  (t0 + t1)<<RC0; 
	x5 = (t0 - t1)*C4;   
	t0=C6*(x4+x6);       
	x4=C6sC2*x4-t0;      
	x6=C6pC2*x6-t0;      
	t0=x6-x7;            
	x1=(xa-xb)<<RC0;       
	t1=t0-x5;            
	x6=(xa+xb)<<RC0;       
	x0=x4-t1;            
	x4=x3+x6;            
	x6-=x3;              
	x3=x1+x2;            
	x5=x1-x2;            
	
	blk[0*8] = iclp[ (x4+x7+ROUND1) >> RC1 ];
	blk[1*8] = iclp[ (x3+t0+ROUND1) >> RC1 ];
	blk[2*8] = iclp[ (x5-t1+ROUND1) >> RC1 ];
	blk[3*8] = iclp[ (x6-x0+ROUND1) >> RC1 ];
	blk[4*8] = iclp[ (x6+x0+ROUND1) >> RC1 ];
	blk[5*8] = iclp[ (x5+t1+ROUND1) >> RC1 ];
	blk[6*8] = iclp[ (x3-t0+ROUND1) >> RC1 ];
	blk[7*8] = iclp[ (x4-x7+ROUND1) >> RC1 ];
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void idct_aan(s16* blk, LxIdctInf* pos)
{
	s32    i;
	s32    block32[64];

	for( i = 0; i < 8; i ++ ){
		idct_aan_row(blk+i*8,block32+i*8,i);
	}

	for( i = 0; i < 8; i ++ ){
		idct_aan_col(block32+i,blk+i);
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

stx_inline void idct_aan_bridge_row(s16* blk,s32* blk32, s32 i )
{
	s32    x0,x1,x2,x3,x4,x5,x6,x7,xa,xb;
	s32    t0,t1;
	s32*	p32;

	x0 = blk[0];

	p32 = (s32*)blk;
	
	if ( !(  (x1 = blk[1])  
		|   (p32[1]) 
		|   (p32[2]) 
		|   (p32[3]) ) )
	{
		SCALEAAN(x0,i,0) ;
		
		blk32[0] = blk32[1] = blk32[2] = blk32[3] = 
			blk32[4] = blk32[5] = blk32[6] = blk32[7] = x0 << 2;

		return;
	}

	x2 = blk[2];
	x3 = blk[3];
	x4 = blk[4];
	x5 = blk[5];
	x6 = blk[6];
	x7 = blk[7];
	SCALEAAN(x0,i,0) ;
	SCALEAAN(x4,i,4);
	SCALEAAN(x3,i,3)      
	SCALEAAN(x5,i,5) ;     
	SCALEAAN(x2,i,2)      
	SCALEAAN(x6,i,6) ;     
	SCALEAAN(x1,i,1)      
	SCALEAAN(x7,i,7) ;     

	xa = x0;
	xb = x4;
	x4 = x5 - x3;       
	t1 = x5 + x3;       
	x3 = (x2+x6)<<RC0;  
	x2 = (x2-x6)*C4-x3; 
	t0 = x1 + x7;       
	x6=  x1 - x7;       
	x7=  (t0 + t1)<<RC0;
	x5 = (t0 - t1)*C4;  
	t0=C6*(x4+x6);      
	x4=C6sC2*x4-t0;     
	x6=C6pC2*x6-t0;     
	t0=x6-x7;           
	x1=(xa-xb)<<RC0;      
	t1=t0-x5;           
	x6=(xa+xb)<<RC0;      
	x0=x4-t1;           
	x4=x3+x6;           
	x6-=x3;             
	x3=x1+x2;           
	x5=x1-x2;           
	
	blk32[0] = ( (x4+x7+ROUND0) >> RC00 );
	blk32[1] = ( (x3+t0+ROUND0) >> RC00 );
	blk32[2] = ( (x5-t1+ROUND0) >> RC00 );
	blk32[3] = ( (x6-x0+ROUND0) >> RC00 );
	blk32[4] = ( (x6+x0+ROUND0) >> RC00 );
	blk32[5] = ( (x5+t1+ROUND0) >> RC00 );
	blk32[6] = ( (x3-t0+ROUND0) >> RC00 );
	blk32[7] = ( (x4-x7+ROUND0) >> RC00 );
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

stx_inline void idct_aan_bridge_col(s32* blk32,s16* blk)
{
	s32    x0,x1,x2,x3,x4,x5,x6,x7,xa,xb;
	s32    t0,t1;
	
	if (! ((x1 = blk32[8]  ) 
		| ( x2 = blk32[16] ) 
		| ( x3 = blk32[24] )
		| ( x4 = blk32[32] )
		| ( x5 = blk32[40] )  
		| ( x6 = blk32[48] )
		| ( x7 = blk32[56] ) ) )
	{
		blk[0] = blk[8] = blk[16] = blk[24]
			= blk[32] = blk[40] = blk[48] = blk[56] 
				= iclp[ ( blk32[0] + 64 ) >> 7 ];

		return;
	}

	x0 = blk32[0];
	xa = x0;
	xb = x4;
	
	x4 = x5 - x3;        
	t1 = x5 + x3;        			
	x3 = (x2+x6)<<RC0;   
	x2 = (x2-x6)*C4-x3;  
	t0 = x1 + x7;        
	x6=  x1 - x7;        
	x7=  (t0 + t1)<<RC0; 
	x5 = (t0 - t1)*C4;   
	t0=C6*(x4+x6);       
	x4=C6sC2*x4-t0;      
	x6=C6pC2*x6-t0;      
	t0=x6-x7;            
	x1=(xa-xb)<<RC0;       
	t1=t0-x5;            
	x6=(xa+xb)<<RC0;       
	x0=x4-t1;            
	x4=x3+x6;            
	x6-=x3;              
	x3=x1+x2;            
	x5=x1-x2;            
	
	blk[0*8] = iclp[ (x4+x7+ROUND1) >> RC1 ];
	blk[1*8] = iclp[ (x3+t0+ROUND1) >> RC1 ];
	blk[2*8] = iclp[ (x5-t1+ROUND1) >> RC1 ];
	blk[3*8] = iclp[ (x6-x0+ROUND1) >> RC1 ];
	blk[4*8] = iclp[ (x6+x0+ROUND1) >> RC1 ];
	blk[5*8] = iclp[ (x5+t1+ROUND1) >> RC1 ];
	blk[6*8] = iclp[ (x3-t0+ROUND1) >> RC1 ];
	blk[7*8] = iclp[ (x4-x7+ROUND1) >> RC1 ];

}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void idct_aan_bridge(s16* blk, LxIdctInf* pos )
{
	u32 const dwRowMask = GET_ROW_MASK(pos->dwColMask);
	u32 const dwRowNum = g_RowNz[dwRowMask];
	u32 const dwColMask = GET_COL_MASK(pos->dwColMask);
	u32 const dwColNum = g_RowNz[dwColMask];

	if( dwRowNum == 1 && dwColNum == 1 ) {
		idct_sparse_ac(blk,pos );// ����ͨ��0,1��
		return;
	}

	{
		s32    i;
		s32    block32[64];

		for( i = 0; i < 8; i ++ ){
			idct_aan_bridge_row(blk+i*8,block32+i*8,i);
		}

		for( i = 0; i < 8; i ++ ){
#ifdef AAN_SECOND_FIELD_SPARSE
			idct_aan_bridge_col(block32 + i, blk + i );
#else
			idct_aan_col( block32 + i, blk + i );
#endif
		}

	}
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

stx_inline s32  idct_aan_bridge_ex_row(s16* blk, s32* blk32, s32 i, s32 np)
{
	s32    x0,x1,x2,x3,x4,x5,x6,x7,xa,xb;
	s32    t0,t1;

	s32 const nc = g_RowNz[np];

	if( !nc ) {
		blk32[0] = blk32[1] = blk32[2] = blk32[3] = 
				blk32[4] = blk32[5] = blk32[6] = blk32[7] = 0;

		return 0;
	}

	if( nc == 1 ) {
		s32 const p = g_RowPos[np];
		if( p == 0 ) {
			x0 = blk[0];
			SCALEAAN(x0,i,0);			
			blk32[0] = blk32[1] = blk32[2] = blk32[3] = 
				blk32[4] = blk32[5] = blk32[6] = blk32[7] = x0 << 2;
			blk   += 8;
			blk32 += 8;
			return -1;
		}
#if 1
		x0 = blk[p];
		SCALEAAN(x0,i,p);			
//		blk32[0] = ( x0 * IDCT_TAB_AAN[p*8+0] + ROUND0 ) >> RC00;
		blk32[0] = x0 << 2;
		blk32[1] = ( x0 * IDCT_TAB_AAN[p*8+1] + ROUND0 ) >> RC00;
		blk32[2] = ( x0 * IDCT_TAB_AAN[p*8+2] + ROUND0 ) >> RC00;
		blk32[3] = ( x0 * IDCT_TAB_AAN[p*8+3] + ROUND0 ) >> RC00;
		blk32[4] = ( x0 * IDCT_TAB_AAN[p*8+4] + ROUND0 ) >> RC00;
		blk32[5] = ( x0 * IDCT_TAB_AAN[p*8+5] + ROUND0 ) >> RC00;
		blk32[6] = ( x0 * IDCT_TAB_AAN[p*8+6] + ROUND0 ) >> RC00;
		blk32[7] = ( x0 * IDCT_TAB_AAN[p*8+7] + ROUND0 ) >> RC00;
		return -1;
#endif
	}

#if 0  // speed up 5%; so not used;
	if( 2 == nc ) {
		u32 dwPos = g_RowPos[np];
		s32 p0 = dwPos & 7;
		s32 p1 = dwPos >> 3;
		x0 = blk32[p0];
		x1 = blk32[p1];
		SCALEAAN(x0,i,p0);			
		SCALEAAN(x1,i,p1);			
		blk32[0] = ( x0 + x1 ) << 2 ; 
		blk32[1] = ( x0 * IDCT_TAB_AAN[p0*8+1] + x1 * IDCT_TAB_AAN[p1*8+1] + ROUND0 ) >> RC00;
		blk32[2] = ( x0 * IDCT_TAB_AAN[p0*8+2] + x1 * IDCT_TAB_AAN[p1*8+2] + ROUND0 ) >> RC00;
		blk32[3] = ( x0 * IDCT_TAB_AAN[p0*8+3] + x1 * IDCT_TAB_AAN[p1*8+3] + ROUND0 ) >> RC00;
		blk32[4] = ( x0 * IDCT_TAB_AAN[p0*8+4] + x1 * IDCT_TAB_AAN[p1*8+4] + ROUND0 ) >> RC00;
		blk32[5] = ( x0 * IDCT_TAB_AAN[p0*8+5] + x1 * IDCT_TAB_AAN[p1*8+5] + ROUND0 ) >> RC00;
		blk32[6] = ( x0 * IDCT_TAB_AAN[p0*8+6] + x1 * IDCT_TAB_AAN[p1*8+6] + ROUND0 ) >> RC00;
		blk32[7] = ( x0 * IDCT_TAB_AAN[p0*8+7] + x1 * IDCT_TAB_AAN[p1*8+7] + ROUND0 ) >> RC00;
		return -1;
	}
#endif

	x0 = blk[0];
	SCALEAAN(x0,i,0);
	x1 = blk[1];
	SCALEAAN(x1,i,1);      
	x2 = blk[2];
	SCALEAAN(x2,i,2);      
	x3 = blk[3];
	SCALEAAN(x3,i,3);      
	x4 = blk[4];
	SCALEAAN(x4,i,4);
	x5 = blk[5];
	SCALEAAN(x5,i,5) ;     
	x6 = blk[6];
	SCALEAAN(x6,i,6) ;     
	x7 = blk[7];
	SCALEAAN(x7,i,7) ; 
	
	xa = x0;
	xb = x4;
	x4 = x5 - x3;       
	t1 = x5 + x3;       
	x3 = (x2+x6)<<RC0;  
	x2 = (x2-x6)*C4-x3; 
	t0 = x1 + x7;       
	x6=  x1 - x7;       
	x7=  (t0 + t1)<<RC0;
	x5 = (t0 - t1)*C4;  
	t0=C6*(x4+x6);      
	x4=C6sC2*x4-t0;     
	x6=C6pC2*x6-t0;     
	t0=x6-x7;           
	x1=(xa-xb)<<RC0;      
	t1=t0-x5;           
	x6=(xa+xb)<<RC0;      
	x0=x4-t1;           
	x4=x3+x6;           
	x6-=x3;             
	x3=x1+x2;           
	x5=x1-x2;           
	
	blk32[0] = ( (x4+x7+ROUND0) >> RC00 );
	blk32[1] = ( (x3+t0+ROUND0) >> RC00 );
	blk32[2] = ( (x5-t1+ROUND0) >> RC00 );
	blk32[3] = ( (x6-x0+ROUND0) >> RC00 );
	blk32[4] = ( (x6+x0+ROUND0) >> RC00 );
	blk32[5] = ( (x5+t1+ROUND0) >> RC00 );
	blk32[6] = ( (x3-t0+ROUND0) >> RC00 );
	blk32[7] = ( (x4-x7+ROUND0) >> RC00 );

	return -1;		
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

stx_inline void idct_aan_bridge_ex_col(s32* blk32,s16* blk,s32 np)
{
	s32    x0,x1,x2,x3,x4,x5,x6,x7,xa,xb;
	s32    t0,t1;

	s32 const nc = g_RowNz[np];

	if( !nc ) {
		blk[8*0]=blk[8*1]=blk[8*2]=blk[8*3]=
			blk[8*4]=blk[8*5]=blk[8*6]=blk[8*7] = 0;

		return ;
	}

	if( nc == 1 ) {
		const s32 p = g_RowPos[np];
		if( p == 0 ) {
			blk[8*0] = blk[8*1] = blk[8*2] = blk[8*3] = 
				blk[8*4] = blk[8*5] = blk[8*6] = blk[8*7] = iclp[ ( blk32[0] + 64 ) >> 7 ];

			return;
		}
#if 1
		x0 = blk32[p*8];
//		blk[8*0] = iclp[( x0 * IDCT_TAB_AAN[p*8+0] + ROUND1 ) >> RC1 ];
		blk[8*0] = iclp[( x0 + 64 ) >> 7 ];
		blk[8*1] = iclp[( x0 * IDCT_TAB_AAN[p*8+1] + ROUND1 ) >> RC1 ];
		blk[8*2] = iclp[( x0 * IDCT_TAB_AAN[p*8+2] + ROUND1 ) >> RC1 ];
		blk[8*3] = iclp[( x0 * IDCT_TAB_AAN[p*8+3] + ROUND1 ) >> RC1 ];
		blk[8*4] = iclp[( x0 * IDCT_TAB_AAN[p*8+4] + ROUND1 ) >> RC1 ];
		blk[8*5] = iclp[( x0 * IDCT_TAB_AAN[p*8+5] + ROUND1 ) >> RC1 ];
		blk[8*6] = iclp[( x0 * IDCT_TAB_AAN[p*8+6] + ROUND1 ) >> RC1 ];
		blk[8*7] = iclp[( x0 * IDCT_TAB_AAN[p*8+7] + ROUND1 ) >> RC1 ];

		return ;
#endif 
	}

	x0 = blk32[0];
	x1 = blk32[8] ;
	x2 = blk32[16];
	x3 = blk32[24];
	x4 = blk32[32];
	x5 = blk32[40];
	x6 = blk32[48];
	x7 = blk32[56];

	xa = x0;
	xb = x4;
	
	x4 = x5 - x3;        
	t1 = x5 + x3;        			
	x3 = (x2+x6)<<RC0;   
	x2 = (x2-x6)*C4-x3;  
	t0 = x1 + x7;        
	x6=  x1 - x7;        
	x7=  (t0 + t1)<<RC0; 
	x5 = (t0 - t1)*C4;   
	t0=C6*(x4+x6);       
	x4=C6sC2*x4-t0;      
	x6=C6pC2*x6-t0;      
	t0=x6-x7;            
	x1=(xa-xb)<<RC0;       
	t1=t0-x5;            
	x6=(xa+xb)<<RC0;       
	x0=x4-t1;            
	x4=x3+x6;            
	x6-=x3;              
	x3=x1+x2;            
	x5=x1-x2;            
	
	blk[0*8] = iclp[ (x4+x7+ROUND1) >> RC1 ];
	blk[1*8] = iclp[ (x3+t0+ROUND1) >> RC1 ];
	blk[2*8] = iclp[ (x5-t1+ROUND1) >> RC1 ];
	blk[3*8] = iclp[ (x6-x0+ROUND1) >> RC1 ];
	blk[4*8] = iclp[ (x6+x0+ROUND1) >> RC1 ];
	blk[5*8] = iclp[ (x5+t1+ROUND1) >> RC1 ];
	blk[6*8] = iclp[ (x3-t0+ROUND1) >> RC1 ];
	blk[7*8] = iclp[ (x4-x7+ROUND1) >> RC1 ];
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

#define SCALEAAN_EX(x0,i,j)  x0 = ( x0 * (s32)preSC[i+j*8] +  ROUNDAAN ) >> ROLAAN ;

stx_inline void  idct_aan_bridge_ex_col_first( s16* blk, s32* blk32, s32 i )
{
	s32    x0,x1,x2,x3,x4,x5,x6,x7,xa,xb;
	s32    t0,t1;

	x0 = blk[0*8];
	SCALEAAN_EX(x0,i,0);
	x1 = blk[1*8];
	SCALEAAN_EX(x1,i,1);      
	x2 = blk[2*8];
	SCALEAAN_EX(x2,i,2);      
	x3 = blk[3*8];
	SCALEAAN_EX(x3,i,3);      
	x4 = blk[4*8];
	SCALEAAN_EX(x4,i,4);
	x5 = blk[5*8];
	SCALEAAN_EX(x5,i,5) ;     
	x6 = blk[6*8];
	SCALEAAN_EX(x6,i,6) ;     
	x7 = blk[7*8];
	SCALEAAN_EX(x7,i,7) ; 
	
	xa = x0;
	xb = x4;
	x4 = x5 - x3;       
	t1 = x5 + x3;       
	x3 = (x2+x6)<<RC0;  
	x2 = (x2-x6)*C4-x3; 
	t0 = x1 + x7;       
	x6=  x1 - x7;       
	x7=  (t0 + t1)<<RC0;
	x5 = (t0 - t1)*C4;  
	t0=C6*(x4+x6);      
	x4=C6sC2*x4-t0;     
	x6=C6pC2*x6-t0;     
	t0=x6-x7;           
	x1=(xa-xb)<<RC0;      
	t1=t0-x5;           
	x6=(xa+xb)<<RC0;      
	x0=x4-t1;           
	x4=x3+x6;           
	x6-=x3;             
	x3=x1+x2;           
	x5=x1-x2;           
	
	blk32[0*8] = ( (x4+x7+ROUND0) >> RC00 );
	blk32[1*8] = ( (x3+t0+ROUND0) >> RC00 );
	blk32[2*8] = ( (x5-t1+ROUND0) >> RC00 );
	blk32[3*8] = ( (x6-x0+ROUND0) >> RC00 );
	blk32[4*8] = ( (x6+x0+ROUND0) >> RC00 );
	blk32[5*8] = ( (x5+t1+ROUND0) >> RC00 );
	blk32[6*8] = ( (x3-t0+ROUND0) >> RC00 );
	blk32[7*8] = ( (x4-x7+ROUND0) >> RC00 );
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

stx_inline void idct_aan_bridge_ex_row_short(s32* blk32,s16* blk,s32 p)
{
	s32    x0;

	x0 = blk32[p];
//	blk[0] = iclp[( x0 * IDCT_TAB_AAN[p*8+0] + ROUND1 ) >> RC1 ];
	blk[0] = iclp[( x0 + 64 ) >> 7 ];
	blk[1] = iclp[( x0 * IDCT_TAB_AAN[p*8+1] + ROUND1 ) >> RC1 ];
	blk[2] = iclp[( x0 * IDCT_TAB_AAN[p*8+2] + ROUND1 ) >> RC1 ];
	blk[3] = iclp[( x0 * IDCT_TAB_AAN[p*8+3] + ROUND1 ) >> RC1 ];
	blk[4] = iclp[( x0 * IDCT_TAB_AAN[p*8+4] + ROUND1 ) >> RC1 ];
	blk[5] = iclp[( x0 * IDCT_TAB_AAN[p*8+5] + ROUND1 ) >> RC1 ];
	blk[6] = iclp[( x0 * IDCT_TAB_AAN[p*8+6] + ROUND1 ) >> RC1 ];
	blk[7] = iclp[( x0 * IDCT_TAB_AAN[p*8+7] + ROUND1 ) >> RC1 ];
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

stx_inline void idct_aan_bridge_ex_row_short2(s32* blk32,s16* blk,s32 p0,s32 p1)
{
	s32    x0,x1;

	x0 = blk32[p0];
	x1 = blk32[p1];
//	blk[0] = iclp[( x0 * IDCT_TAB_AAN[p0*8+0] + 
//		x1 * IDCT_TAB_AAN[p1*8+0] + ROUND1 ) >> RC1 ];
	blk[0] = iclp[( x0 + x1  + 64 ) >> 7 ]; 

	blk[1] = iclp[( x0 * IDCT_TAB_AAN[p0*8+1] + 
		x1 * IDCT_TAB_AAN[p1*8+1] + ROUND1 ) >> RC1 ];
	blk[2] = iclp[( x0 * IDCT_TAB_AAN[p0*8+2] + 
		x1 * IDCT_TAB_AAN[p1*8+2] + ROUND1 ) >> RC1 ];
	blk[3] = iclp[( x0 * IDCT_TAB_AAN[p0*8+3] + 
		x1 * IDCT_TAB_AAN[p1*8+3] + ROUND1 ) >> RC1 ];
	blk[4] = iclp[( x0 * IDCT_TAB_AAN[p0*8+4] + 
		x1 * IDCT_TAB_AAN[p1*8+4] + ROUND1 ) >> RC1 ];
	blk[5] = iclp[( x0 * IDCT_TAB_AAN[p0*8+5] + 
		x1 * IDCT_TAB_AAN[p1*8+5] + ROUND1 ) >> RC1 ];
	blk[6] = iclp[( x0 * IDCT_TAB_AAN[p0*8+6] + 
		x1 * IDCT_TAB_AAN[p1*8+6] + ROUND1 ) >> RC1 ];
	blk[7] = iclp[( x0 * IDCT_TAB_AAN[p0*8+7] + 
		x1 * IDCT_TAB_AAN[p1*8+7] + ROUND1 ) >> RC1 ];
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

stx_inline void idct_aan_bridge_ex_col_short(s32* blk32,s16* blk,s32 p)
{
	s32    x0;

	x0 = blk32[p*8];
//	blk[0*8] = iclp[( x0 * IDCT_TAB_AAN[p*8+0] + ROUND1 ) >> RC1 ];
	blk[0*8] = iclp[( x0 + 64 ) >> 7 ];
	blk[1*8] = iclp[( x0 * IDCT_TAB_AAN[p*8+1] + ROUND1 ) >> RC1 ];
	blk[2*8] = iclp[( x0 * IDCT_TAB_AAN[p*8+2] + ROUND1 ) >> RC1 ];
	blk[3*8] = iclp[( x0 * IDCT_TAB_AAN[p*8+3] + ROUND1 ) >> RC1 ];
	blk[4*8] = iclp[( x0 * IDCT_TAB_AAN[p*8+4] + ROUND1 ) >> RC1 ];
	blk[5*8] = iclp[( x0 * IDCT_TAB_AAN[p*8+5] + ROUND1 ) >> RC1 ];
	blk[6*8] = iclp[( x0 * IDCT_TAB_AAN[p*8+6] + ROUND1 ) >> RC1 ];
	blk[7*8] = iclp[( x0 * IDCT_TAB_AAN[p*8+7] + ROUND1 ) >> RC1 ];
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

stx_inline void idct_aan_bridge_ex_col_short2(s32* blk32,s16* blk,s32 p0,s32 p1)
{
	s32    x0,x1;

	x0 = blk32[p0*8];
	x1 = blk32[p1*8];

//	blk[0*8] = iclp[( x0 * IDCT_TAB_AAN[p0*8+0] + x1 * IDCT_TAB_AAN[p1*8+0] + ROUND1 ) >> RC1 ];
	blk[0*8] = iclp[( x0 + x1 + 64) >> 7 ];

	blk[1*8] = iclp[( x0 * IDCT_TAB_AAN[p0*8+1] + x1 * IDCT_TAB_AAN[p1*8+1] + ROUND1 ) >> RC1 ];
	blk[2*8] = iclp[( x0 * IDCT_TAB_AAN[p0*8+2] + x1 * IDCT_TAB_AAN[p1*8+2] + ROUND1 ) >> RC1 ];
	blk[3*8] = iclp[( x0 * IDCT_TAB_AAN[p0*8+3] + x1 * IDCT_TAB_AAN[p1*8+3] + ROUND1 ) >> RC1 ];
	blk[4*8] = iclp[( x0 * IDCT_TAB_AAN[p0*8+4] + x1 * IDCT_TAB_AAN[p1*8+4] + ROUND1 ) >> RC1 ];
	blk[5*8] = iclp[( x0 * IDCT_TAB_AAN[p0*8+5] + x1 * IDCT_TAB_AAN[p1*8+5] + ROUND1 ) >> RC1 ];
	blk[6*8] = iclp[( x0 * IDCT_TAB_AAN[p0*8+6] + x1 * IDCT_TAB_AAN[p1*8+6] + ROUND1 ) >> RC1 ];
	blk[7*8] = iclp[( x0 * IDCT_TAB_AAN[p0*8+7] + x1 * IDCT_TAB_AAN[p1*8+7] + ROUND1 ) >> RC1 ];
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

stx_inline void row_all_zero(s16* blk, s32* blk32, s32 i, s32 np)
{
	blk32[0] = blk32[1] = blk32[2] = blk32[3] = 
			blk32[4] = blk32[5] = blk32[6] = blk32[7] = 0;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

stx_inline void row_short_1(s16* blk, s32* blk32, s32 i, s32 p )
{
	s32 x0;
	p = g_RowPos[p];
	if( p == 0 ) {
		x0 = blk[0];
		SCALEAAN(x0,i,0);			
		blk32[0] = blk32[1] = blk32[2] = blk32[3] = 
			blk32[4] = blk32[5] = blk32[6] = blk32[7] = x0 << 2;
		return ;
	}

	x0 = blk[p];
	SCALEAAN(x0,i,p);			
	blk32[0] = x0 << 2;
//	blk32[0] = ( x0 * IDCT_TAB_AAN[p*8+0] + ROUND0 ) >> RC00;
#define SHORT_CUT(i) blk32[i] = ( x0 * IDCT_TAB_AAN[p*8+i]  + ROUND0 ) >> RC00
	SHORT_CUT(1);
	SHORT_CUT(2);
	SHORT_CUT(3);
	SHORT_CUT(4);
	SHORT_CUT(5);
	SHORT_CUT(6);
	SHORT_CUT(7);
#undef  SHORT_CUT 
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

stx_inline void row_short_2(s16* blk, s32* blk32, s32 i, s32 np )
{
	u32 p = g_RowPos[np];
	s32 p0 = p & 7;
	s32 p1 = p >> 3;
	s32 x0 = blk[p0];
	s32 x1 = blk[p1];
	SCALEAAN(x0,i,p0);			
	SCALEAAN(x1,i,p1);			
	blk32[0] = ( x0 + x1 ) << 2 ; 
#define SHORT_CUT(i) blk32[i] = ( x0 * IDCT_TAB_AAN[p0*8+i] + x1 * IDCT_TAB_AAN[p1*8+i] + ROUND0 ) >> RC00
	SHORT_CUT(1);
	SHORT_CUT(2);
	SHORT_CUT(3);
	SHORT_CUT(4);
	SHORT_CUT(5);
	SHORT_CUT(6);
	SHORT_CUT(7);
#undef  SHORT_CUT 
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

static void row_normal(s16* blk, s32* blk32, s32 i, s32 np )
{
	s32    x0,x1,x2,x3,x4,x5,x6,x7,xa,xb;
	s32    t0,t1;

	x0 = blk[0];
	SCALEAAN(x0,i,0);
	x1 = blk[1];
	SCALEAAN(x1,i,1);      
	x2 = blk[2];
	SCALEAAN(x2,i,2);      
	x3 = blk[3];
	SCALEAAN(x3,i,3);      
	x4 = blk[4];
	SCALEAAN(x4,i,4);
	x5 = blk[5];
	SCALEAAN(x5,i,5) ;     
	x6 = blk[6];
	SCALEAAN(x6,i,6) ;     
	x7 = blk[7];
	SCALEAAN(x7,i,7) ; 
	
	xa = x0;
	xb = x4;
	x4 = x5 - x3;       
	t1 = x5 + x3;       
	x3 = (x2+x6)<<RC0;  
	x2 = (x2-x6)*C4-x3; 
	t0 = x1 + x7;       
	x6=  x1 - x7;       
	x7=  (t0 + t1)<<RC0;
	x5 = (t0 - t1)*C4;  
	t0=C6*(x4+x6);      
	x4=C6sC2*x4-t0;     
	x6=C6pC2*x6-t0;     
	t0=x6-x7;           
	x1=(xa-xb)<<RC0;      
	t1=t0-x5;           
	x6=(xa+xb)<<RC0;      
	x0=x4-t1;           
	x4=x3+x6;           
	x6-=x3;             
	x3=x1+x2;           
	x5=x1-x2;           
	
	blk32[0] = ( (x4+x7+ROUND0) >> RC00 );
	blk32[1] = ( (x3+t0+ROUND0) >> RC00 );
	blk32[2] = ( (x5-t1+ROUND0) >> RC00 );
	blk32[3] = ( (x6-x0+ROUND0) >> RC00 );
	blk32[4] = ( (x6+x0+ROUND0) >> RC00 );
	blk32[5] = ( (x5+t1+ROUND0) >> RC00 );
	blk32[6] = ( (x3-t0+ROUND0) >> RC00 );
	blk32[7] = ( (x4-x7+ROUND0) >> RC00 );

	return;		
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

typedef void (*aan_row_entry) ( s16* , s32*, s32, s32);

static aan_row_entry  row_entry[9] = {
	row_all_zero,
	row_short_1,
	row_short_2,
	row_normal, row_normal, row_normal, row_normal, row_normal,row_normal,
};



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void idct_aan_bridge_ex(s16* blk, LxIdctInf* pos )
{
	s32    i;
	s32    block32[64];

	u32 const dwRowMask = GET_ROW_MASK(pos->dwColMask);
	u32 const dwRowNum = g_RowNz[dwRowMask];
	u32 const dwColMask = GET_COL_MASK(pos->dwColMask);
	u32 const dwColNum = g_RowNz[dwColMask];

	if( dwRowNum == 1 && dwColNum == 1 ) {
		idct_sparse_ac(blk,pos );// ����ͨ��0,1��
		return;
	}


	// ������ͨ��3��

	if( 1 == dwRowNum ) {   // all the nz data in one row;
		s32 const nRow = g_RowPos[dwRowMask];
		idct_aan_row(blk+nRow*8,block32+nRow*8,nRow);
		if( 0 == nRow ) {
			// vertical dc;
			s16 tmp0[8];
#	define LX_DC(i) tmp0[i] = iclp[( block32[i] + 64 ) >> 7 ]
			LX_DC(0);LX_DC(1);LX_DC(2);LX_DC(3);
			LX_DC(4);LX_DC(5);LX_DC(6);LX_DC(7);
#	undef  LX_DC
#	define LX_DC(i) \
			*(s32*)(blk+i*8)   = *(s32*)(tmp0);     \
			*(s32*)(blk+i*8+2) = *(s32*)(tmp0+2);   \
			*(s32*)(blk+i*8+4) = *(s32*)(tmp0+4);   \
			*(s32*)(blk+i*8+6) = *(s32*)(tmp0+6);
			LX_DC(0);LX_DC(1);LX_DC(2);LX_DC(3);
			LX_DC(4);LX_DC(5);LX_DC(6);LX_DC(7);
#	undef  LX_DC

			return;
		}

		for( i = 0; i < 8; i ++ )	{
			idct_aan_bridge_ex_col_short(block32 + i, blk + i, nRow );
		}

		return;
	}
	
	if( 1 == dwColNum ) {   // all the nz data in one col;
		s32 const nCol = g_RowPos[dwColMask];
		idct_aan_bridge_ex_col_first( blk + nCol, block32 + nCol,nCol);

		if( 0 == nCol ) {
			s32 val32;
#	define LX_DC(i)  \
			val32 = iclp[ ( block32[i*8] + 64 ) >> 7 ];\
			val32 = (val32<<16)|(val32&0xffff);\
			*(s32*)(blk+i*8)   = val32;     \
			*(s32*)(blk+i*8+2) = val32;     \
			*(s32*)(blk+i*8+4) = val32;     \
			*(s32*)(blk+i*8+6) = val32;
			LX_DC(0);LX_DC(1);LX_DC(2);LX_DC(3);
			LX_DC(4);LX_DC(5);LX_DC(6);LX_DC(7);
#	undef  LX_DC
			return;
		}

		for( i = 0; i < 8; i ++ )	{
			idct_aan_bridge_ex_row_short( block32 + i*8, blk + i*8, nCol);
		}
		return;
	}
	
	if( 2 == dwRowNum ) {
		u32 dwPos = g_RowPos[dwRowMask];
		s32 nRow0 = dwPos & 7;
		s32 nRow1 = dwPos >> 3;
		idct_aan_row( blk + nRow0*8, block32 + nRow0*8,nRow0);
		idct_aan_row( blk + nRow1*8, block32 + nRow1*8,nRow1);
		for( i = 0; i < 8; i ++ )	{
			idct_aan_bridge_ex_col_short2( block32 + i, blk + i, nRow0, nRow1 );
		}
		return;
	}

	if( 2 == dwColNum ) {
		u32 dwPos = g_RowPos[dwColMask];
		s32 nCol0 = dwPos & 7;
		s32 nCol1 = dwPos >> 3;
		idct_aan_bridge_ex_col_first( blk + nCol0, block32 + nCol0,nCol0);
		idct_aan_bridge_ex_col_first( blk + nCol1, block32 + nCol1,nCol1);

		for( i = 0; i < 8; i ++ )	{
			idct_aan_bridge_ex_row_short2( block32 + i*8, blk + i*8, nCol0, nCol1 );
		}
		return;
	}

// ����ϰ볡�Ŀ���ͨ��3��4�� 
// ʹ����ת���Ĵ�����7%������ʹ��idct_aan_bridge_ex_row��������36%��
	for( i = 0; i < 8; i ++ )	{
//		idct_aan_row( blk + i*8, block32 + i*8, i );
		u32 const dwRowInf = pos->byRowPos[i];
		row_entry[ g_RowNz[dwRowInf] ]( blk + i*8, block32 + i*8, i, dwRowInf );
	}

// ����ǰ���ͨ��0��1��2��3��4 ���ˣ��°볡�Ѿ�û�п���ͨ�����á�
	for( i = 0; i < 8; i ++ )	{
		idct_aan_col(block32+i,blk+i );
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

static void idct_aan_row_short_1(s16* blk,LxIdctInf* pos  )
{
	s32    i;
	s32    block32[64];

	u32 const dwRowMask = GET_ROW_MASK(pos->dwColMask);
	s32 const nRow = g_RowPos[dwRowMask];
	idct_aan_row(blk+nRow*8,block32+nRow*8,nRow);
	if( 0 == nRow ) {
		// vertical dc;
		s16 tmp0[8];
#	define LX_DC(i) tmp0[i] = iclp[( block32[i] + 64 ) >> 7 ]
		LX_DC(0);LX_DC(1);LX_DC(2);LX_DC(3);
		LX_DC(4);LX_DC(5);LX_DC(6);LX_DC(7);
#	undef  LX_DC
#	define LX_DC(i) \
		*(s32*)(blk+i*8)   = *(s32*)(tmp0);     \
		*(s32*)(blk+i*8+2) = *(s32*)(tmp0+2);   \
		*(s32*)(blk+i*8+4) = *(s32*)(tmp0+4);   \
		*(s32*)(blk+i*8+6) = *(s32*)(tmp0+6);
		LX_DC(0);LX_DC(1);LX_DC(2);LX_DC(3);
		LX_DC(4);LX_DC(5);LX_DC(6);LX_DC(7);
#	undef  LX_DC

		return;
	}

	for( i = 0; i < 8; i ++ )	{
		idct_aan_bridge_ex_col_short(block32 + i, blk + i, nRow );
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

static void idct_aan_col_short_1(s16* blk,LxIdctInf* pos  )
{
	s32    i;
	s32    block32[64];
	
	u32 const dwColMask = GET_COL_MASK(pos->dwColMask);

	s32 const nCol = g_RowPos[dwColMask];
	idct_aan_bridge_ex_col_first( blk + nCol, block32 + nCol,nCol);

	if( 0 == nCol ) {
		s32 val32;
#	define LX_DC(i)  \
		val32 = iclp[ ( block32[i*8] + 64 ) >> 7 ];\
		val32 = (val32<<16)|(val32&0xffff);\
		*(s32*)(blk+i*8)   = val32;     \
		*(s32*)(blk+i*8+2) = val32;     \
		*(s32*)(blk+i*8+4) = val32;     \
		*(s32*)(blk+i*8+6) = val32;
		LX_DC(0);LX_DC(1);LX_DC(2);LX_DC(3);
		LX_DC(4);LX_DC(5);LX_DC(6);LX_DC(7);
#	undef  LX_DC
		return;
	}

	for( i = 0; i < 8; i ++ )	{
		idct_aan_bridge_ex_row_short( block32 + i*8, blk + i*8, nCol);
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

static void idct_aan_row_short_2(s16* blk,LxIdctInf* pos  )
{
	s32    i;
	s32    block32[64];

	u32 const dwRowMask = GET_ROW_MASK(pos->dwColMask);

	u32 dwPos = g_RowPos[dwRowMask];
	s32 nRow0 = dwPos & 7;
	s32 nRow1 = dwPos >> 3;
	idct_aan_row( blk + nRow0*8, block32 + nRow0*8,nRow0);
	idct_aan_row( blk + nRow1*8, block32 + nRow1*8,nRow1);
	for( i = 0; i < 8; i ++ )	{
		idct_aan_bridge_ex_col_short2( block32 + i, blk + i, nRow0, nRow1 );
	}	
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

static void idct_aan_col_short_2(s16* blk,LxIdctInf* pos  )
{
	s32    i;
	s32    block32[64];

	u32 const dwColMask = GET_COL_MASK(pos->dwColMask);

	u32 dwPos = g_RowPos[dwColMask];
	s32 nCol0 = dwPos & 7;
	s32 nCol1 = dwPos >> 3;
	idct_aan_bridge_ex_col_first( blk + nCol0, block32 + nCol0,nCol0);
	idct_aan_bridge_ex_col_first( blk + nCol1, block32 + nCol1,nCol1);

	for( i = 0; i < 8; i ++ )	{
		idct_aan_bridge_ex_row_short2( block32 + i*8, blk + i*8, nCol0, nCol1 );
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

static void idct_aan_row_short_3(s16* blk,LxIdctInf* pos  )
{
	s32    i;
	s32    block32[64];

// ����ϰ볡�Ŀ���ͨ��3��4�� 
// ʹ����ת���Ĵ�����7%������ʹ��idct_aan_bridge_ex_row��������36%��
	for( i = 0; i < 8; i ++ )	{
//		idct_aan_row( blk + i*8, block32 + i*8, i );
		u32 const dwRowInf = pos->byRowPos[i];
		row_entry[ g_RowNz[dwRowInf] ]( blk + i*8, block32 + i*8, i, dwRowInf );
	}

// ����ǰ���ͨ��0��1��2��3��4 ���ˣ��°볡�Ѿ�û�п���ͨ�����á�
	for( i = 0; i < 8; i ++ )	{
		idct_aan_col(block32+i,blk+i );
	}
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void aan_idct_c_init( idct_proc_entry entry[8][8])
{
	s32 i,j;

	for( i = 0; i < 8; i ++ ) {
		for( j = 0; j < 8; j ++ ) {
			if( i == 0 && j == 0 ) {
				entry[i][j] = idct_sparse_ac;
			}
			else if( i == 0 ) {
				entry[i][j] = idct_aan_row_short_1;
			}
			else if( j == 0 ) {
				entry[i][j] = idct_aan_col_short_1;
			}
			else if( j == 1 ) {
				entry[i][j] = idct_aan_col_short_2;
			}
			else  {
				entry[i][j] = idct_aan_row_short_3;
			}
		}
	}		
}
