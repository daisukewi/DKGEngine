/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-11
***********************************************************************************/
#ifndef __VIDEO_DECODER_H__
#define __VIDEO_DECODER_H__


#include "base_interf.h"

#include "stx_video_frame.h"

#include "../mpegdef.h"

#include "get_bits.h"

#include "xdisk_loop.h"


#if defined( __cplusplus )
extern "C" {
#endif


/***************************************************************************************************
/	Integer division with truncation of the result toward zero. For example, 7/4 and -7/-4 are
	truncated to 1 and -7/4 and 7/-4 are truncated to -1.

//	Integer division with rounding to the nearest integer. Half-integer values are rounded away
	from zero unless otherwise specified. For example 3//2 is rounded to 2, and -3//2 is rounded
	to -2.

DIV Integer division with truncation of the result toward minus infinity. For example 3 DIV 2 is
	rounded to 1, and -3 DIV 2 is rounded to -2.

��	Used to denote division in mathematical equations where no truncation or rounding is
	intended.

%	Modulus operator. Defined only for positive numbers
***************************************************************************************************/
static const s32 round_near[2] = {-1,1};

#define DIV_TRUNC_ZERO(A,D)			(A/D)								// /
#define DIV_ARITH(A,D)				(A/D)								// ��
#define DIV_TRUNC_MIN(A,D)			(( A - (A < 0 ) ) / D )				// DIV
#define DIV_TRUNC_MAX(A,D)			(( A + (A > 0 ) ) / D )				// max 
#define DIV_ROUND_NEAR(A,D)         (( A + round_near[A >= 0] ) / D)	// //

#define HALF_PERL(I,V)				(I*2!=V)


//#define VID_DELAY_SKIP   TRUE
#define VID_DELAY_SKIP   FALSE

#define VID_PTFC_ARR_NUM    8


#define MFAILED                     -1
#define VSUCCESS                    1
#define BUSY                        0
#define BACK_DECODE_GOP_SUCCESS     2 

#define SEARCH_GOP            9
#define DECODE_FORWARD        0
#define DECODE_BACKWARD       1
#define DECODE_START		  2
#define DECODE_STILL          3
#define DECODE_FORWARD_1      4
#define DECODE_FORWARD_2      5


#define LX_JUMPRESET          1
#define LX_SYSTEM_RESET       2

#define INIT_SEARCH_MACHINE      100    
#define LOOKFOR_FIRST_I_FRAME    110
#define LOOKFOR_SECOND_I_FRAME   120

#define SEQUENCE_START           0
#define VIDEO_SEQUENCE           10
#define DECODE_GOP_JUMP          15
#define DECODE_GOP_JUMP_1        16
#define DECODE_GOP_0             20
#define DECODE_GOP_0_1           21
#define DECODE_GOP_1             22
#define DECODE_GOP_1_1           23
#define DECODE_GOP_2             24
#define DECODE_GOP_3             25
#define DECODE_GOP_ENDP          27
#define OUTPUT_LAST              30

#define BACK_DECODE_GOP_0        180
#define BACK_DECODE_GOP_START    200
#define BACK_DECODE_GOP_SKIPB    210
#define BACK_DECODE_GOP          220
#define BACK_DECODE_GOP_END_B    230
#define OUTPUT_LAST_GOP          240
	//}

	// mpeg4;
#define VOS_START_CODE  0x1b0
#define VOS_END_CODE    0x1b1

#define PRELOAD_STM_END_CODE    0x1EE
#define PRELOAD_STM_ERR_CODE    0xEE010000

	//{ mpeg standard tagment;
#define PICTURE_START_CODE      0x100
#define SLICE_START_CODE_MIN    0x101
#define SLICE_START_CODE_MAX    0x1AF
#define USER_DATA_START_CODE    0x1B2
#define SEQUENCE_HEADER_CODE    0x1B3
#define SEQUENCE_ERROR_CODE     0x1B4
#define EXTENSION_START_CODE    0x1B5
#define SEQUENCE_END_CODE       0x1B7
#define GROUP_START_CODE        0x1B8
#define SYSTEM_START_CODE_MIN   0x1B9
#define SYSTEM_START_CODE_MAX   0x1FF

#define ISO_END_CODE            0x1B9
#define PACK_START_CODE         0x1BA
#define SYSTEM_START_CODE       0x1BB

#define VIDEO_ELEMENTARY_STREAM 0x1e0

	/* scalable_mode */
#define SC_NONE 0
#define SC_DP   1
#define SC_SPAT 2
#define SC_SNR  3
#define SC_TEMP 4


#if defined(I_TYPE)
#undef I_TYPE
#endif
#if defined(P_TYPE)
#undef P_TYPE
#endif
#if defined(B_TYPE)
#undef B_TYPE
#endif

	/* picture coding type */
#define I_TYPE 1
#define P_TYPE 2
#define B_TYPE 3

#define D_TYPE 4

	/* picture structure */
#define TOP_FIELD     1
#define BOTTOM_FIELD  2
#define FRAME_PICTURE 3


	/* motion_type */
#define MC_FIELD 1
#define MC_FRAME 2

#define MC_16X8  2
#define MC_DMV   3

	/* mv_format */
#define MV_FIELD 0
#define MV_FRAME 1

	/* chroma_format */
#define CHROMA420 1
#define CHROMA422 2
#define CHROMA444 3
#define CHROMA420_AYUV 4
#define CHROMA422_AYUV 5
#define CHROMA444_AYUV 6

	/* extension start code IDs */

#define SEQUENCE_EXTENSION_ID                    1
#define SEQUENCE_DISPLAY_EXTENSION_ID            2
#define QUANT_MATRIX_EXTENSION_ID                3
#define COPYRIGHT_EXTENSION_ID                   4
#define SEQUENCE_SCALABLE_EXTENSION_ID           5
#define PICTURE_DISPLAY_EXTENSION_ID             7
#define PICTURE_CODING_EXTENSION_ID              8
#define PICTURE_SPATIAL_SCALABLE_EXTENSION_ID    9
#define PICTURE_TEMPORAL_SCALABLE_EXTENSION_ID  10
#define ZIG_ZAG                                  0

#define PROFILE_422                             (128+5)
#define MAIN_LEVEL                              8

	/* Layers: used by Verbose_Flag, Verifier_Flag, Stats_Flag, and Trace_Flag */
#define NO_LAYER                                0
#define SEQUENCE_LAYER                          1
#define PICTURE_LAYER                           2
#define SLICE_LAYER                             3    
#define MACROBLOCK_LAYER                        4    
#define BLOCK_LAYER                             5
#define EVENT_LAYER                             6
#define ALL_LAYERS                              7
#define FILENAME_LENGTH                       256
#define MB_WEIGHT                  32
#define MB_CLASS4                  64

#define T_YUV   0
#define T_SIF   1
#define T_TGA   2
#define T_PPM   3
#define T_X11   4
#define T_X11HIQ 5
#define RESERVED -1

#define OBFRSIZE 4096

#define MACROBLOCK_INTRA                        1
#define MACROBLOCK_PATTERN                      2
#define MACROBLOCK_MOTION_BACKWARD              4
#define MACROBLOCK_MOTION_FORWARD               8
#define MACROBLOCK_QUANT                        16
#define SPATIAL_TEMPORAL_WEIGHT_CODE_FLAG       32
#define PERMITTED_SPATIAL_TEMPORAL_WEIGHT_CLASS 64

#define MACROBLOCK_SKIPPED	128
#define MACROBLOCK_FAST_MC  256
	//}  



STX_INTERF(RecCoe);
STX_INTERF(PicHeader);
STX_INTERF(PicCodExt);
STX_INTERF(PicDisplayExt);
STX_INTERF(SliceData);
STX_INTERF(sparse_para);
STX_INTERF(LightCoeff);
STX_INTERF(BitsWindow);
STX_INTERF(VideoInfo);
STX_INTERF(VideoInitAttr);
STX_INTERF(VideoDecoderData);

#define MPF_INTER_BLOCK		0x01
#define MPF_NOT_SKIPPED		0x02

struct RecCoe{
	u8    coey[16*16];
	u8    coeuv[8][64];
};

struct PicHeader{
	/* ISO/IEC 13818-2 section 6.2.3: picture_header() */
	s32 nTemporalReference;
	s32 nPictureCodingType;
	s32 nVbvDelay;
	s32 nFullPelForwardVector;

	s32 nForwardFCode;
	s32 nFullPelBackwardVector;
	s32 nBackwardFCode;
	s32 nPadPicHeader;  // a16 padding;
};

struct PicCodExt{
	/* ISO/IEC 13818-2 section 6.2.3.1: picture_coding_extension() header */
	s32 nFCode[2][2];    // a16;

	s32 nIntraDcPrecision;
	s32 nPictureStructure;
	s32 bTopFieldFirst;
	s32 bFramePredFrameDct;

	s32 bConcealmentMotionVectors;
	s32 nQScaleType;
	s32 nIntraVlcFormat;
	s32 bAlternateScan;

	s32 bRepeatFirstField;
	s32 bChroma420Type;
	s32 bProgressiveFrame;
	s32 bCompositeDisplayFlag;   // a16;
};


struct PicDisplayExt{
	/* ISO/IEC 13818-2 section 6.2.3.3: picture_display_extension() header */
	s32 nFrameCenterHorizontalOffset[3+1];  // a16;
	s32 nFrameCenterVerticalOffset[3+1];    // a16;
};

struct SliceData{
	s32 nQuantizerScale;
	s32 bIntraSlice;
	s32 nPad[2];
};


struct sparse_para{
	u8* dst;
	s32            lx;
};


struct LightCoeff{
	u8        lghy[20][16];  // 320;
	u8        lghu[12][8];   // 106;
	u8        lghv[12][8];   // 106;
	u8        lgpad[1536-432];
};

typedef union MacroBlock MacroBlock;

union MacroBlock{
	s16            coeff[12][64];   // a16  128*12 = 1536;
	//LightCoeff     lgcoeff;
};


struct BitsWindow
{
	//[[ getbits;
	stx_bits_window		bs;
	//]]

	MacroBlock          Macro_Block;

	RecCoe              reccoe;           // a16
	RecCoe              reccoe1;          // a16
	sparse_para         sparse_info[2][12];  // only use first 6 block; 8*2*12, a16;


	///*
	//[[ MacroBlock;
#define YUV_DIT_VID     0
#define YUV_DIT_OUTPUT  1
	s32         nYuvDit[2][2];    // a16;

#define YUV_ADDR_OUTPUT  0
#define YUV_ADDR_PRED    1
	u8*         lpYuvAddr[2][4];    // a16;

	u8*         current_frame[4];       // a16;
	u8*         current_pred_frame[4];  // a16;

	s32         DMV[2][2];       // a16;  
	s32         PMV[2][2][2];    // a16;
	s32         motion_vertical_field_select[2][2];   // a16
	s32         dmvector[2+2];   // 2+2 a16;
	s32         dc_dct_pred[3+1];  // 3 + 1pad; a16;

	s32         nBlockCount;
	s32         nCodedBlockPattern;
	u32			bNewSliceFlag;
	s32         dmv; 

	s32         dct_type;
	s32         macroblock_type;
	s32         motion_type;
	s32         motion_vector_count; 

	s32         mvscale;
	s32         stwtype;
	s32         stwclass;
	s32         mv_format;

	u32         dwMbPosX;  // macroblock position x
	u32         dwMbPosY;  // macrolbock position y
	s32         MBA;
	s32         MBAinc;    // a16;
	//]]
	//*/

	PicHeader            pic_header;
	PicCodExt            pic_cod_ext;
	PicDisplayExt        pic_display_ext;
	SliceData            slice_data;
};




//{ video stream information
struct VideoInfo{
	s32 FlagMPEG2;
	s32 ChromaFormat;
	s32 Width;
	s32 Height;
	s32 aspect_ratio_information;
	s32 frame_rate_code;
	s32 bit_rate_value;
};
//}


struct VideoInitAttr{
	u32 dwFlagQuality;              // if halfmode should use;
	u32 dwFlagAutoDeinterlace;
	u32 dwFlagAutoClearMotionBlur;
	u32 dwFlagEffect;
};




struct VideoDecoderData	{

	//{ input data control
	s64       PresentTimeStamp;
	s64       DecodeTimeStamp;

	s32       NumberStreamPacket;
	s32       NumberGroupOfPicture;
	s32       NumberPresentUnit;
	//}

	void*     ProcessResumeSpliter;

	s32       DecoderMode;
	s32       DecoderState;

	b32       FlagControlChanged;
	b32       FlagDecodePicture;
	u32       FlagDecodePictureData8x;
	u32       FlagDropFieldBFrame;

	b32       FlagFastDecode8X;
	b32       bFastDecode8X;

	//{ drop_frame control
	u32        FlagDropFrame;
	u32        FlagSkipFrame;

	s32        RepeatDisplayTimes;

	s32        CurrentCellPlayTime;
	//}

	b32        FlagEndOfFile;
	b32        FlagClipRectGot;
	b32        FlagHaveBlackEdge;
	s32        TopMacroBlockNumber;
	s32        BotMacroBlockNumber;


	u32       dwWHScale;

	u8*       lpMbPosTabX;
	u8*       lpMbPosTabY;

	s32  top_size;
	s32  bot_size;

	u32				dwTime;	//��ǰ֡���ڵ��ݲ�ʱ��
	void*			pPGC;
	u32				dwCell;
	u32				dwVobuLBN;
	b32				bQuit;	
	b32				bSwitch;
	b32				bSwitchRes;

	u32				dwLoopCount;
};

#define INIT_RESET                     0x01
#define END_RESET                      (1<<1)
#define JUMP_RESET                     (1<<2)
#define SEQ_RESET                      (1<<3)
#define USER_JMP                       (1<<4)
#define USER_STEP                      (1<<5)



STX_INTERF(video_decoder);

STX_INTERF(LxVidDat2);


struct LxVidDat2 {
	//<< data members;>>
	BitsWindow			bsw;

	u16  nIntraQuantizerMatrixTable[128][64];
	u16  nChromaIntraQuantizerMatrixTable[128][64];
	u16  nNonIntraQuantizerMatrixTable[128][64];
	u16  nChromaNonIntraQuantizerMatrixTable[128][64];

	s32   nIntraQuantizerMatrix[64];
	s32   nNonIntraQuantizerMatrix[64];
	s32   nChromaIntraQuantizerMatrix[64];
	s32   nChromaNonIntraQuantizerMatrix[64];

	VideoDecoderData	vdr;
	LxVidAccSet			vidset;

	s32 bAjustChanged;
	s32 bVidSetChanged;
	s64 nLastTimeCode;
	u32 dwStreamReadTime;

	s32 nGopDecTime[16];
	s32 nGopAvgDecTime;
	u32 dwDecodeStartTime;
	u32 dwDecodeEndTime;


	// the push mode decoder;
	u32 dwPtfc;

	/* normative derived variables (as per ISO/IEC 13818-2) */
	s32 nSpatialTemporalWeightCodeTableIndex;
	s32 nPictScal;
	s32 bScalableMode;
	s32 nHorizontalSize;
	s32 nVerticalSize;

	u32 bSecondSlice;
	s32 nPredSlicePit;
	s32 nPredSlicePitUV;
	s32 nOutputSlicePit;
	s32 nOutputSlicePitUV;
	s32 nOutputSliceStep ;
	s32 nOutputSliceStepUV;

	s32 nVBVBufferSize;
	s32 nChromaFormat;

	s32 nCodedPicturePitch;  // decode surface used pitch;
	s32 nCodedPictureWidth;
	s32 nCodedPictureHeight;

	s32 nOutputPictureWidth;
	s32 nOutputPicturePitch;

	s32 nChromaWidth;
	s32 nChromaPitch;
	s32 nChromaHeight;

	s32 nMbWidth;
	s32 nMbHeight;
	s32 nMbSize;
	s32 nBlockCount;

	s32 nBitstreamFramenum;
	s32 nSequenceFramenum;

	s32 bSecondField;
	s32 bSaveFirstField;

	s32 bContinueWork;
	s32 nRepeatCounter;
	s32 dwInputFourCC;

	s32 bDeinterlaceNeeded;
	u32 bHilightExist;

	u32 dwDeinterlaceFlag;
	u32 dwQualityControl;

	s32 nCurrentSliceWidth;
	s32 nCurrentSlicePitch;

	s32 nPredPit;
	s32 nOutputPit;
	s32 nMBAmax;
	s32 bMPEG2Flag;
};

STX_INTERF(rec_mb_info);
STX_INTERF(mc_decoder);
STX_INTERF(frame_decoder);


struct frame_decoder{

	BitsWindow			bsw;
	BitsWindow*			pbsw;

	VideoFrame*			pCurrentPicture;

	mc_decoder*			g_lpMcDecoder;

	LxVidDat2*			g_lpDecoder;
	video_decoder*		h_vdec;

	u32					g_bSecondSlice;
	s32					g_bFaultFlag;

	s32					g_bPriorityBreakPoint;

	b32					g_bSliceFlag;
	s32					g_nCurSlice;
	s32					g_nStartMb;
	s32					g_nEndMb;

	u8*					pSlice;
	u8*					pMb;

	stx_sync_source*	h_ssrc;
	THEE				h_task;
	b32					b_main;
	s32					ta;
	s32					tb;
	u64					rdtsca;
	u64					rdtscb;
	s64					counta;
	s64					countb;
	u8**				ppSlice;
	STX_RESULT			i_err;

	// ctx;
	s32					i_flag;
	s32					i_stage;
	b32					bUpGrade;
	s32					nUpGradeMb;
	s32					i_start;
	s32					i_end;
	b32					b_stop;
	b32					b_exit;
};


struct video_decoder{

	LxVidDat2	vdat;

	s32		m_nPtfcArrNum;
	s32		m_nPtfcArr[32];
	s32		m_nAvgPtfc;
	b32		m_bDropGop;

	s32		m_nPtfc;

	s32		m_nDecBufDepth;

	s64		nCurTimeCode;
	s32		nTimeStep;
	s32		nTimeIncree;
	u32		m_nLastDecodeTime;
	u32		m_nAvgDecodeTime;
	u32		m_nSumTime;
	u32		m_nClock;

	b32			bUpGrade;
	VideoFrame  *lpUpGradeFrame;

	VideoFrame  *lpCurrentPicture;
	VideoFrame  *lpForwardPicture;
	VideoFrame  *lpBackwardPicture;
	VideoFrame  *lpOutputForwardPicture;
	VideoFrame  *lpOutputBackwardPicture;

	u8*        lpCurDecodePtr;

	s32		   NumberGroupOfPicture;

	s32        nTemporalReferenceBase ;
	s32        nTrueFramenumMax  ;
	s32        nTemporalReferenceGOPReset;

	s32        bLoadIntraQuantizerMatrix;
	s32        bLoadNonIntraQuantizerMatrix;
	s32        bLoadChromaIntroQuantizerMatrix;
	s32        bLoadChromaNonIntraQuantizerMatrix;

	s32        bPriorityBreakPoint;

	/* ISO/IEC 13818-2 section 6.3.6 sequence_display_extension() */
	/* output types (Output_Type) */
	/* decoder operation control variables */
	s32 nHiQDither;

	/* decoder operation control flags */
	s32 bFaultFlag;
	s32 bSpatialFlag;
	s32 bDisplayProgressiveFlag;
	s32 bUserDataFlag;

	/* pointers to generic picture buffers */
	s32 nProfile, nLevel;


	f64 fBitRate;
	f64 fFrameRate;
	f32 fBitRateSta;

	s32 bSequenceFrameProgressive;

	s32 bProgressiveSequence;
	s32 nMatrixCoefficients;
	s32 nFrameRateCode;
	s32 nBitRateValue;
	s32 nAspectRatioInformation;
	s32 nVbvBufferSizeCode;
	s32 nProfileAndLevelIndication;

	s64   qwDts;
	s64   qwPts;


	/* ISO/IEC 13818-2 section 6.2.2.5: sequence_scalable_extension() header */
	s32 nLayerId;

	/* ISO/IEC 13818-2 section 6.2.3.6: copyright_extension() header */
	s32 bCopyRightFlag;
	s32 nCopyrightIdentifier;
	s32 bOriginalOrCopy;
	s32 nCopyrightNumber1;
	s32 nCopyrightNumber2;
	s32 nCopyrightNumber3;

	/* ISO/IEC 13818-2 section 6.2.2.6: group_of_pictures_header()  */
	s32 bDropFlag;
	s32 nHour;
	s32 nMinute;
	s32 nSec;
	s32 nFrame;
	s32 bClosedGop;
	s32 bBrokenLink;

	/* layer specific variables (needed for SNR and DP scalability) */
	s32		nDecodeLayer;
	f64		fFrameRateTable[16];
	char	*lpLayerTable[8];
	s32		nTrueFramenum;
	/* non-normative variables derived from normative elements */
	//}

	s32					g_nFrmDecoderNum;
	s32					nThrCount;
	frame_decoder**  ppFrameCtx;

	s32					mp_width;
	THEE				h_mutex;
	u8*					pSliceBuf;
	THEE				h_dec;
	STX_RESULT			mperr;
	xloop*				pFreeSlice;
	xloop*				pDataSlice;
	xloop*				pFreeDecoder;
	s32					a_task_num;
	s32					b_task_num;

	THEE				h_notify;
	void				(*notify)(THEE h);
	THEE*				h_subtask;

	stx_media_data*		p_output_data;
	stx_media_data*		p_upgrade_data;

	stx_output_pin*		h_output_pin;

	s32					i_seqhdr_num;
	s32					i_keyfrm_num;
	s32					i_predfrm_num;

	b32					bResetFlag;
};


typedef frame_decoder frame_decoder;


STX_RESULT mpeg2_video_decode_initialize(video_decoder* the);

void	   mpeg2_video_decode_cleanup(video_decoder* the);

STX_RESULT mpeg2_video_decode_start( video_decoder* the, u8* buf, s32 i_len );

STX_RESULT mpeg2_video_decode_end( video_decoder* the);

STX_RESULT mpeg2_video_decode_frame
(video_decoder* the, frame_decoder* h_ctx, stx_sync_inf* h_sync );

extern STX_RESULT (*video_subdecode)
(video_decoder* the, frame_decoder* h_ctx, stx_sync_inf* h_sync );
STX_RESULT mp_video_subdecode
(video_decoder* the, frame_decoder* h_ctx, stx_sync_inf* h_sync );
STX_RESULT mpeg2_video_subdecode
(video_decoder* the, frame_decoder* h_ctx, stx_sync_inf* h_sync );


STX_RESULT OutputLastFrameOfSequence(video_decoder* the);


void		reset_mp_buffer(video_decoder* the);
void		close_mp_buffer(video_decoder* the);
STX_RESULT	init_mp_buffer(video_decoder* the);

STX_RESULT	get_free_slice(video_decoder* the,THEE h_ctx,u8** ppSlice);
STX_RESULT	get_data_slice(video_decoder* the,THEE h_ctx,u8** ppSlice);
void		add_data_slice(video_decoder* the,THEE h_ctx,u8*  pSlice);
void		add_free_slice(video_decoder* the,THEE h_ctx,u8*  pSlice);


#if defined( __cplusplus )
}
#endif

#endif // __VIDEO_DECODER_H__




