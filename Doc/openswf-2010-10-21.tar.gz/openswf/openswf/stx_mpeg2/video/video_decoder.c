/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-06
***********************************************************************************/
#include "stdio.h"
#include "stdlib.h"
#include "fcntl.h"
#include "memory.h"
#include "string.h"


#if defined (__WIN32_LIB)
#	include "time.h"
#	include "time.inl"
#else
#	include <time.h>
#endif /* #if defined (__WIN32_LIB) */


#include "stx_all.h"

#include "video_decoder.h"
#include "table.h"
#include "frame_decoder.h"


#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif

/********************************************/
#define __GET_BITS_INC__
#include "get_bits.h"
#include "get_bits.c"
/********************************************/




#define get_bits(A)         stx_get_bits((stx_bits_window*)the,A)
#define flush_bits(A)       stx_flush_bits((stx_bits_window*)the,A)
#define get_rid_of_rear()   stx_clear_bytes((stx_bits_window*)the)
#define Headers()           (Get_Hdr(the))

#define Show_Bits(n)		stx_show_bits((stx_bits_window*)the,n)

#define get_bits32()		stx_get_bits((stx_bits_window*)the,32)
#define flush_bits32()		stx_flush_bits((stx_bits_window*)the,32)

#define get_bits1()			stx_get_bits((stx_bits_window*)the,1)
#define flush_bits1()		stx_flush_bits((stx_bits_window*)the,1)


/* align to start of next next_start_code */
#define next_start_code() \
{ \
/* byte align */ \
/**/flush_bits(the->vdat.bsw.bs.nCurrentBit&7); \
/**/while(the->vdat.bsw.bs.nCurrentBit>0){ \
/**//**/if(Show_Bits(24) == 0x01L ) { \
/**//**//**/break; \
/**//**/}\
/**//**/flush_bits(8); \
/**/}\
}


static void      ResetMfDecoder(video_decoder* the);

static void      AdjustBufferSize(video_decoder* the);
static void      AdjustDecodeSpeed(video_decoder* the,b32 bFastMode,s32 nSpeed );

static void      OutputStillFrame(video_decoder* the,b32 bEnd);
static void		 ParseFramePictureFormat(video_decoder* the);
static void		 ParseFieldPictureFormat(video_decoder* the);

static void      ParsePrediction(video_decoder* the);


//{ local    functions
static void			ResetBitsWin(BitsWindow* lpBw);
static STX_RESULT   StartVideoSequence(video_decoder* the);
static void			InitializeFrameAttributes(video_decoder* the); 
static STX_RESULT	DecodePicture (video_decoder* the);
static STX_RESULT   Update_Picture_Buffers(video_decoder* the);
static STX_RESULT   FrameReorder (video_decoder* the); //
static STX_RESULT   next_header(video_decoder* the);

static void         sequence_header (video_decoder* the);
static void         group_of_pictures_header (video_decoder* the);
static void         picture_header (video_decoder* the);
static void         extension_and_user_data (video_decoder* the);
static void         sequence_extension (video_decoder* the);
static void         sequence_display_extension (video_decoder* the);
static void         quant_matrix_extension (video_decoder* the);
static void         sequence_scalable_extension (video_decoder* the);
static void         picture_display_extension (video_decoder* the);
static void         picture_coding_extension (video_decoder* the);

static STX_RESULT   extra_bit_information (video_decoder* the);

static void         copyright_extension (video_decoder* the);
static void         user_data (video_decoder* the);
static void         Update_Temporal_Reference_Tacking_Data (video_decoder* the);

static STX_RESULT   picture_data (video_decoder* the);
static STX_RESULT   DecodeSlice(video_decoder* the);
static STX_RESULT   Get_Hdr(video_decoder* the);

static STX_RESULT   StartOfSlice (video_decoder* the);

static STX_RESULT   SliceHeader ( video_decoder* the);
static STX_RESULT   DecodeMacroblock(video_decoder* the);

static void         Spatial_Prediction (video_decoder* the);
static void         free_mb_table(video_decoder* the);
static void         InitializeSequence(video_decoder* the);
static void         InitializeParameters(video_decoder* the);
static void         init_vdr(video_decoder* the);

static STX_RESULT   init_mb_table(video_decoder* the);

static STX_RESULT   ForwardDecoder(video_decoder* the);
//s32          SearchDecoder(video_decoder* the);
//s32          PlayerBackwardDecoder(video_decoder* the);
//s32          EditorBackwardDecoder(video_decoder* the);

static void			GetMbPos(video_decoder* the);
static void			GetMbPosIntraPred(video_decoder* the);

static void         init_ddct_info(video_decoder* the,BitsWindow* lpBw);

static void         InitializeVideoDecoder(video_decoder* the);
static void         InitializeStream(video_decoder* the);	

static u32			EstDrop(video_decoder* the);
static void         ParseForwardState(video_decoder* the);
static void         ParseEditorBackwardState(video_decoder* the);
static void         ParseSearchState(video_decoder* the);


static s32          Get_P_macroblock_type(video_decoder* the);
static s32          Get_B_macroblock_type(video_decoder* the);
static s32          Get_D_macroblock_type(video_decoder* the);

static s32          Get_I_macroblock_type(video_decoder* the);

static s32          Get_I_Spatial_macroblock_type(video_decoder* the);
static s32          Get_P_Spatial_macroblock_type(video_decoder* the);
static s32          Get_B_Spatial_macroblock_type(video_decoder* the);

static void         macroblock_modes(video_decoder* the);

static void         SkippedMacroblock(video_decoder* the);

// static void         Decode_MPEG1_Intra_Block (video_decoder* the,s32 comp, s32 dc_dct_pred[]);
// static void         Decode_MPEG1_Non_Intra_Block (video_decoder* the,s32 comp);
// static void         Sparse_MPEG2_Intra_Block(video_decoder* the,s32 comp,s32 dc_dct_pred[]);
// static void         Sparse_MPEG2_Non_Intra_Block(video_decoder* the,s32 comp);
// static void         Decode_MPEG2_Intra_Block (video_decoder* the,s32 comp, s32 dc_dct_pred[]);
// static void         Decode_MPEG2_Non_Intra_Block (video_decoder* the,s32 comp);

static s32          Get_macroblock_type(video_decoder* the);
static s32          Get_motion_code(video_decoder* the);
static s32          Get_dmvector(video_decoder* the);
static s32          Get_coded_block_pattern(video_decoder* the);
static s32          Get_macroblock_address_increment(video_decoder* the);
static s32          Get_Luma_DC_dct_diff(video_decoder* the);
static s32          Get_ChromaDC_dct_diff(video_decoder* the);


// end of inline functions declaration }

//{ Interface of LxVidDecoder; move to VidNotify;
static void          StopStill(video_decoder* the);
static void          SetVideoAutoDeinterlace(video_decoder* the,s32 mode); //}
static void          SetVideoDecode8X(video_decoder* the,b32 b8x);
static void          EndVideoDecoder(video_decoder* the);

static void          ResetSequence(video_decoder* the);
static void          ReverseVideoDecoder(video_decoder* the);
static void          SetDropRatio(video_decoder* the,s32 dwDegree);
//}
//}
static void          VidReset(video_decoder* the,u32 dw1);

static STX_RESULT    Initialize(video_decoder* the);
static void          Release(video_decoder* the);



/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************************/

static void SetVideoDecode8X(video_decoder* the,b32 b8x)
{
	the->vdat.vdr.FlagFastDecode8X = b8x;
}
/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************************/

static void StopStill(video_decoder* the)
{
	the->vdat.vdr.RepeatDisplayTimes = 0;
}
/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************************/

static void ResetSequence(video_decoder* the)
{
	InitializeParameters(the);
	the->vdat.vdr.DecoderMode = DECODE_FORWARD;
}


/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************************/
static void FlushBuffer(video_decoder* the)
{
	the->vdat.dwStreamReadTime = 0;
	the->vdat.bsw.bs.nBits0 = 0;
	the->vdat.bsw.bs.nBits1 = 0;
	the->vdat.bsw.bs.nTotalBytes = 0;
	the->vdat.bsw.bs.nCurrentBit = 0;
	the->vdat.bsw.bs.nRemainedBytes = 0;
}

/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************************/
static void InitializeVideoDecoder(video_decoder* the)
{
	memset(&the->vdat,0,sizeof(the->vdat));

	InitializeParameters(the);
	InitializeStream(the);
}





/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************************/

//} end of interface functions;
static void  InitializeParameters(video_decoder* the)
{
	the->bPriorityBreakPoint = 0;
	the->bLoadIntraQuantizerMatrix = 0;
	the->bLoadNonIntraQuantizerMatrix = 0;
	the->bLoadChromaIntroQuantizerMatrix = 0;
	the->bLoadChromaNonIntraQuantizerMatrix = 0;

	the->nTemporalReferenceBase = 0;
	the->nTemporalReferenceGOPReset = 0;

	the->nTrueFramenumMax  = -1;

	the->vdat.bContinueWork = TRUE;
	the->vdat.vdr.DecoderMode = DECODE_FORWARD;
	the->vdat.vdr.DecoderState = DECODE_GOP_1;

	the->vdat.bSecondSlice = 0;
	the->vdat.bMPEG2Flag=0;
	the->vdat.bScalableMode=0;
	the->vdat.nPictScal=0;

	the->vdat.vdr.FlagDecodePicture= FALSE;
	the->vdat.vdr.FlagDecodePictureData8x = 0;
	the->vdat.vdr.FlagDropFieldBFrame = 0;
	the->vdat.vdr.FlagFastDecode8X = 0;

	the->vdat.nRepeatCounter = 0;	
}


/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************************/

static void  init_ddct_info(video_decoder* the,BitsWindow* lpBw)
{
	s32 j;

	lpBw->sparse_info[0][0].dst = lpBw->reccoe.coey;     
	lpBw->sparse_info[0][1].dst = lpBw->reccoe.coey + 8;   
	lpBw->sparse_info[0][2].dst = lpBw->reccoe.coey + 16*8;                      
	lpBw->sparse_info[0][3].dst = lpBw->reccoe.coey + 16*8 + 8;      

	lpBw->sparse_info[1][0].dst = lpBw->reccoe.coey;     	
	lpBw->sparse_info[1][1].dst = lpBw->reccoe.coey + 8; 
	lpBw->sparse_info[1][2].dst = lpBw->reccoe.coey + 16;                        
	lpBw->sparse_info[1][3].dst = lpBw->reccoe.coey + 24;  

	for(j=0;j<4;j++){
		lpBw->sparse_info[0][j].lx = 16;
		lpBw->sparse_info[1][j].lx = 32;
	}

	if( the->vdat.nChromaFormat == CHROMA420 )	{

		lpBw->sparse_info[0][4].dst = lpBw->sparse_info[1][4].dst = lpBw->reccoe.coeuv[0]; 
		lpBw->sparse_info[0][5].dst = lpBw->sparse_info[1][5].dst = lpBw->reccoe.coeuv[1]; 
		lpBw->sparse_info[0][4].lx = 	lpBw->sparse_info[0][5].lx = 
			lpBw->sparse_info[1][4].lx = 	lpBw->sparse_info[1][5].lx = 8;

	}
	else {
		s32 i;
		if(the->vdat.nChromaFormat == CHROMA422 ){
			j = 4;
		}
		else if(the->vdat.nChromaFormat == CHROMA444){
			j = 8;
		}
		for( i = 0; i < j; i ++ ){
			lpBw->sparse_info[0][4+i].dst = lpBw->sparse_info[1][4+i].dst = lpBw->reccoe.coeuv[i]; 
			lpBw->sparse_info[0][4+i].lx = 	lpBw->sparse_info[0][5+i].lx = 8;
			lpBw->sparse_info[1][4+i].lx = 	lpBw->sparse_info[1][5+i].lx = 8;
		}
	}
}
//}

/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************************/

static STX_RESULT  init_mb_table(video_decoder* the)
{
	//{ macro_block pos lookup table

	s32		i, mbx,mbs;
	u8*		pmy;
	u8*		pmx;

	free_mb_table(the);

	mbx = the->vdat.nCodedPictureWidth >> 4;
	mbs = the->vdat.nMbWidth * the->vdat.nMbHeight;

	the->vdat.vdr.top_size = - the->vdat.nCodedPicturePitch*16;             
	// above one row;
	the->vdat.vdr.bot_size = (the->vdat.nCodedPictureHeight + 16) * the->vdat.nCodedPicturePitch;  
	// below one row;

	the->vdat.vdr.lpMbPosTabY = (u8*)xmallocz(mbs*2);
	if( !the->vdat.vdr.lpMbPosTabY ) {
		return STX_FAIL;
	}

	the->vdat.vdr.lpMbPosTabX = (u8*)xmallocz(mbs*2);
	if( !the->vdat.vdr.lpMbPosTabX ) {
		return STX_FAIL;
	}

	pmy = the->vdat.vdr.lpMbPosTabY;
	pmx = the->vdat.vdr.lpMbPosTabX;

	for(i=0;i<mbs;i++)	{
		*pmy++ = (u8)(i/mbx);
		*pmx++ = (u8)(i%mbx);
	}

	return STX_OK;
}

/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************************/

static void  free_mb_table(video_decoder* the)
{
	if(the->vdat.vdr.lpMbPosTabY) {		
		stx_free(the->vdat.vdr.lpMbPosTabY);		
		the->vdat.vdr.lpMbPosTabY = NULL;
	}

	if(the->vdat.vdr.lpMbPosTabX) {		
		stx_free(the->vdat.vdr.lpMbPosTabX);		
		the->vdat.vdr.lpMbPosTabX = NULL;	
	}
}

/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************************/
static void InitializeStream(video_decoder* the)
{
	the->vdat.bSecondField = 0;
	FlushBuffer(the);
}

/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************************/
void reset_mp_buffer(video_decoder* the)
{
	s32 i;
	u8* p = the->pSliceBuf;

	the->mperr = FALSE;
	the->h_dec = NULL;
	the->a_task_num = 0;
	the->b_task_num = 0;

	xloopFlush(the->pFreeSlice);
	xloopFlush(the->pDataSlice);
	xloopFlush(the->pFreeDecoder);

	for( i = 0; i < the->g_nFrmDecoderNum*2 ; i ++ ) {
		xloopPush(the->pFreeSlice,p);
		p += the->mp_width * 2048;
	}

}

/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************************/
void close_mp_buffer(video_decoder* the)
{
	if( the->h_mutex ){
		stx_close_mutex(the->h_mutex);
		the->h_mutex = NULL;
	}

	if( the->pSliceBuf ) {
		xlivFree(the->pSliceBuf);
		the->pSliceBuf = NULL;
	}

	if( the->pFreeSlice ) {
		xloopRelease(the->pFreeSlice);
		the->pFreeSlice = NULL;
	}

	if( the->pDataSlice ) {
		xloopRelease(the->pDataSlice);
		the->pDataSlice = NULL;
	}

	if( the->pFreeDecoder) {
		xloopRelease(the->pFreeDecoder);
		the->pFreeDecoder = NULL;
	}

	the->mp_width = 0;
}


/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************************/
STX_RESULT init_mp_buffer(video_decoder* the)
{
	STX_RESULT i_err;

	if( the->mp_width == the->vdat.nMbWidth ) {
		return STX_OK;
	}

	close_mp_buffer(the);

	do{
		i_err = STX_FAIL;

		// init slice buffer;
		the->h_mutex = stx_create_mutex(NULL,0,NULL);
		if( !the->h_mutex ){
			break;
		}

		the->pSliceBuf = (u8*)xlivAlloc(the->vdat.nMbWidth * 2048 * the->g_nFrmDecoderNum * 2,1,16);
		if( !the->pSliceBuf ) {
			break;
		}

		the->pFreeSlice = xloopCreate(the->g_nFrmDecoderNum*2);
		if( !the->pFreeSlice ) {
			break;
		}
		the->pDataSlice = xloopCreate(the->g_nFrmDecoderNum*2);
		if( !the->pDataSlice ) {
			break;
		}
		the->pFreeDecoder = xloopCreate(the->g_nFrmDecoderNum);
		if( !the->pFreeDecoder ) {
			break;
		}

		i_err = STX_OK;

	}while(FALSE);

	if( STX_OK == i_err ) {
		the->mp_width = the->vdat.nMbWidth;
	}

	return i_err;
}


/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************************/
STX_RESULT	get_free_slice(video_decoder* the,THEE h_ctx,u8** ppSlice)
{
	STX_RESULT	i_err;
	u8			*p;

	frame_decoder* const h = (frame_decoder*)h_ctx;


	for( ; ; ){

		stx_waitfor_mutex(the->h_mutex,INFINITE);

		i_err = STX_WOUNLD_BLOCK;

		p = xloopPull(the->pFreeSlice);

		if( p ) {
			//xlog("subtask :%X get free slice %X\r\n",h_ctx,p);
			*ppSlice = p;
			i_err = STX_OK;
			break;
		}
		
#if 0
		if( the->ppFrameCtx[0]->counta ) {

			s32 i;
			s64 tb;

			for( i = 0; i < the->g_nFrmDecoderNum; i ++ ) {
				if( ! the->ppFrameCtx[i]->countb ) {
					break;
				}
				the->ppFrameCtx[i]->tb = (s32)(the->ppFrameCtx[i]->rdtscb / the->ppFrameCtx[i]->countb);
			}

			if( i == the->g_nFrmDecoderNum ) {

				the->ppFrameCtx[0]->ta = (s32)(the->ppFrameCtx[0]->rdtsca / the->ppFrameCtx[0]->counta);

				tb = 0;
				for( i = 0; i < the->g_nFrmDecoderNum; i ++ ) {
					tb += the->ppFrameCtx[i]->tb;
				}
				tb /= the->g_nFrmDecoderNum;

				stx_log("ta = %d, tb = %d \r\n", the->ppFrameCtx[0]->ta,tb);
			}
		}
#endif

		if( the->mperr ){
			i_err = STX_EOF;
		}
		break;

	} // for( ; ; ) {

	stx_release_mutex(the->h_mutex);

	return i_err;
}


/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************************/
void add_data_slice(video_decoder* the,THEE h_ctx,u8* pSlice)
{
	frame_decoder*	h;
	void*			p;

	stx_waitfor_mutex(the->h_mutex,INFINITE);

	the->mperr = *(STX_RESULT*)pSlice;
	xloopPush(the->pDataSlice,pSlice);

	//xlog("subtask :%X add data slice %X flag = %d \r\n",h_ctx,pSlice, the->mperr );

	for( ; ; ){
		h = (frame_decoder*)xloopTryPull(the->pFreeDecoder);
		if( !h ) {
			break;
		}
		p = xloopPull(the->pDataSlice);
		if( !p && !the->mperr) {
			break;
		}
		xloopPull(the->pFreeDecoder);
		*h->ppSlice = p;
		h->i_err = p ? STX_OK : STX_EOF;
		//stx_log("resume b task(add_data_slice): %X\r\n",h);
		h->h_ssrc->xresume(h->h_ssrc,h->h_task);
	}

	stx_release_mutex(the->h_mutex);
}



/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************************/
STX_RESULT	get_data_slice(video_decoder* the,THEE h_ctx,u8** ppSlice)
{
	STX_RESULT	i_err;
	u8			*p;

	frame_decoder* const h = (frame_decoder*)h_ctx;


	for( ; ; ){

		stx_waitfor_mutex(the->h_mutex,INFINITE);

		p = xloopPull(the->pDataSlice);

		i_err = STX_OK;

		if( p ) {
			//xlog("subtask :%X get data slice %X\r\n",h, p);
			*ppSlice = p;
			break;
		}
		else{

			if( the->mperr ) {
				i_err = STX_EOF;
				break;
			}

			if( h->b_main ) {
				i_err = STX_BOF;
				break;
			}

			h->ppSlice = ppSlice;

			xloopPush(the->pFreeDecoder,h);
			// wait for decode;
			stx_release_mutex(the->h_mutex);

			the->b_task_num ++;
			//stx_log("b task %X suspend %d\r\n",h,the->b_task_num);
			h->h_ssrc->xwait(h->h_ssrc,h->h_task,INFINITE64);
			the->b_task_num --;
			//stx_log("b task %X resumed %d\r\n",h,the->b_task_num);
			return h->i_err;
		}

	} // for( ; ; )

	stx_release_mutex(the->h_mutex);

	return i_err;

}

/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************************/
void add_free_slice(video_decoder* the,THEE h_ctx,u8* pSlice)
{
	//stx_log("before b task :%X free slice %X\r\n",h_ctx, pSlice);
	stx_waitfor_mutex(the->h_mutex,INFINITE);
	xloopPush(the->pFreeSlice,pSlice);
	if( the->h_dec ) {
		frame_decoder* const h = (frame_decoder*)the->h_dec;
		the->h_dec = NULL;
		h->h_ssrc->xresume(h->h_ssrc,h->h_task);
	}
	stx_release_mutex(the->h_mutex);
	//stx_log("after b task :%X free slice\r\n",h_ctx);
}


/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************************/
static void AdjustBufferSize(video_decoder* the)
{
	the->vdat.nCodedPicturePitch = the->vdat.nCodedPictureWidth;
	the->vdat.nChromaPitch = the->vdat.nChromaWidth;
	vfrmGetPitch(&the->vdat.nCodedPicturePitch,&the->vdat.nChromaPitch,the->vdat.nChromaFormat);
	
	// use the nCodedPicturePitch value, so must be seted here;
	init_mb_table(the);

	init_mp_buffer(the);
}

/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************************/
static void InitializeSequence(video_decoder* the)
{
	//s32 cc, size;
	static s32 Table_6_20[3] = {6,8,12};


	the->vdat.vdr.FlagDecodePictureData8x = 0;
	the->vdat.vdr.FlagDropFieldBFrame = 0;
	the->vdat.vdr.FlagFastDecode8X = 0;
	the->vdat.nSequenceFramenum = 0;
	the->vdat.nBitstreamFramenum = 0;


	/* check scalability mode of enhancement layer */

	if (!the->vdat.bMPEG2Flag) {

		the->bProgressiveSequence = 1;
		the->vdat.nChromaFormat = CHROMA420;
		the->nMatrixCoefficients = 5;
		the->vdat.bsw.pic_cod_ext.bProgressiveFrame = 1;
		the->vdat.bsw.pic_cod_ext.nPictureStructure = FRAME_PICTURE;
		the->vdat.bsw.pic_cod_ext.bFramePredFrameDct = 1;
	} // if (!the->vdat.bMPEG2Flag) {

	the->bSequenceFrameProgressive = 1;

	the->vdat.nMbWidth = (the->vdat.nHorizontalSize+15)>>4;

	the->vdat.nMbHeight = (the->vdat.bMPEG2Flag && !the->bProgressiveSequence) ? (( the->vdat.nVerticalSize + 31 ) >>5 ) << 1
		:	(the->vdat.nVerticalSize + 15 ) >> 4;
	the->vdat.nCodedPictureWidth = the->vdat.nMbWidth<<4;
	the->vdat.nCodedPictureHeight = the->vdat.nMbHeight<<4;

	/* ISO/IEC 13818-2 sections 6.1.1.8, 6.1.1.9, and 6.1.1.10 */
	the->vdat.nChromaWidth = 
		(the->vdat.nChromaFormat==CHROMA444) ? the->vdat.nCodedPictureWidth : the->vdat.nCodedPictureWidth>>1;

	the->vdat.nChromaHeight =
		(the->vdat.nChromaFormat!=CHROMA420) ? the->vdat.nCodedPictureHeight : the->vdat.nCodedPictureHeight>>1;

	/* derived based on Table 6-20 in ISO/IEC 13818-2 section 6.3.17 */
	the->vdat.nBlockCount = Table_6_20[the->vdat.nChromaFormat-1];

	the->vdat.nMbSize = the->vdat.nMbWidth * the->vdat.nMbHeight;
	the->vdat.nMBAmax = the->vdat.nMbSize;

	//the->nFrameRateCode = 4;

	the->nTimeStep = 90000000 / rate_table[the->nFrameRateCode].frame_rate;

	the->m_nClock = rate_table[the->nFrameRateCode].clock;

	the->vdat.vdr.FlagDropFrame = 0;

	the->vdat.vdr.RepeatDisplayTimes = 0;
	the->vdat.bSecondField = 0;

	init_ddct_info(the,&the->vdat.bsw);

	AdjustBufferSize(the);

	ResetMfDecoder(the);	

	the->bResetFlag = TRUE;
}

/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************************/

static void AdjustDecodeSpeed(video_decoder* the, b32 bFastMode,s32 nSpeed )
{
	if( bFastMode )	{
		// set the fast mode flag;
		the->vdat.vdr.FlagFastDecode8X = TRUE;

		// goto fast mode at once;
		the->vdat.vdr.bFastDecode8X = TRUE;

		// adjust the clock;
		the->m_nClock = ( the->m_nClock * nSpeed ) >> 5;

		// adjust the gop avg decode time;		

		//		g_pVideoDecoder->Command(LX_CMD_DBFREQ,0,0,0);
	}
	else {
		// the mode swith only could excute at the i frame;
		the->vdat.vdr.FlagFastDecode8X = FALSE;

		// adjust the clock;
		the->m_nClock = rate_table[the->nFrameRateCode].clock;

		// adjust the gop avg decode time;		
	}
}


/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************************/

static u32   EstDrop(video_decoder* the)
{	
	s32 i,nFrameNum;

	b32 bItype = I_TYPE == the->vdat.bsw.pic_header.nPictureCodingType ;
	b32 bBtype = B_TYPE == the->vdat.bsw.pic_header.nPictureCodingType ;

	if( the->vdat.vdr.bFastDecode8X )	{
		the->vdat.vdr.FlagSkipFrame = !bItype ;
		return 0;
	}

	if( the->vdat.nBitstreamFramenum < 3 )	{
		the->vdat.vdr.FlagSkipFrame = FALSE;
		return 0;
	}

	// compute the gop average decode time;

	nFrameNum = the->vdat.nBitstreamFramenum > 16 ? 16 : the->vdat.nBitstreamFramenum;

	for( i = nFrameNum; i > 1; i -- ){	
		the->vdat.nGopDecTime[i-1] = the->vdat.nGopDecTime[i-2];
	}

	the->vdat.nGopDecTime[0] = the->vdat.dwDecodeEndTime ;

	the->vdat.nGopAvgDecTime = 0;

	for( i = 0; i < nFrameNum; i ++ ){	
		the->vdat.nGopAvgDecTime += the->vdat.nGopDecTime[i];
	}

	the->vdat.nGopAvgDecTime >>= 4;  // get the average time;

	the->m_nPtfc = ( the->vdat.nGopAvgDecTime * 100) / ( the->m_nClock ? the->m_nClock : 33) + the->vdat.dwPtfc ;

	for( i = 1; i < VID_PTFC_ARR_NUM; i ++ ){
		the->m_nPtfcArr[i] = the->m_nPtfcArr[i-1];
	}
	the->m_nPtfcArr[0] = the->m_nPtfc;
	nFrameNum = 0;
	the->m_nAvgPtfc = 0;
	for( i = 0 ; i < VID_PTFC_ARR_NUM; i ++ ){
		if( the->m_nPtfcArr[i] ){
			the->m_nAvgPtfc += the->m_nPtfcArr[i];
			nFrameNum ++;
		}
	}

	if( nFrameNum ){
		the->m_nAvgPtfc /= nFrameNum;
	}

	if( the->m_nAvgPtfc > VID_DROP_GOP_LIMIT ){
		if( !the->m_bDropGop && bItype){
			the->m_bDropGop = TRUE;
		}
	}
	else if( the->m_bDropGop && bItype ){
		the->m_bDropGop = FALSE;
		// <<skip the B frames after this I frame;
		if(the->vdat.bsw.pic_cod_ext.nPictureStructure == FRAME_PICTURE){  
			the->vdat.vdr.DecoderState = DECODE_GOP_0;
		}
		else{
			the->vdat.vdr.DecoderState = DECODE_GOP_JUMP_1;
		}//>>
	}

	if( the->m_bDropGop ){
		the->vdat.vdr.FlagSkipFrame =  !bItype;
	}
	else{
		the->vdat.vdr.FlagSkipFrame = (  the->m_nPtfc  > VID_DROP_LIMIT ) && bBtype;
	}

	//	TRACE1("m_nPtfc = %d\n",m_nPtfc);
	//	TRACE1("m_nAvgPtfc = %d\n",m_nAvgPtfc);

	return 0;
}


/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************************/

static void  ParseForwardState(video_decoder* the)
{
	switch(the->vdat.vdr.DecoderState)
	{
	case DECODE_GOP_0:
		if( B_TYPE != the->vdat.bsw.pic_header.nPictureCodingType ){
			the->vdat.vdr.FlagDecodePicture = TRUE;
			the->vdat.vdr.DecoderState =  DECODE_GOP_1 ;
		}
		break;

	case DECODE_GOP_1:
		the->vdat.vdr.FlagDecodePicture = TRUE;
		// if from fast mode goto normal;
		if( the->vdat.vdr.bFastDecode8X && 
			!the->vdat.vdr.FlagFastDecode8X &&
			I_TYPE == the->vdat.bsw.pic_header.nPictureCodingType 
		){
			the->vdat.vdr.bFastDecode8X = FALSE;
			the->vdat.vdr.DecoderState =  DECODE_GOP_0 ;			
		}		
		break;

	case DECODE_GOP_JUMP:

		the->vdat.nSequenceFramenum = 0;
		the->vdat.nBitstreamFramenum = 0;

		if( I_TYPE == the->vdat.bsw.pic_header.nPictureCodingType ){
			the->vdat.vdr.FlagDecodePicture = TRUE;	
			if(the->vdat.bsw.pic_cod_ext.nPictureStructure == FRAME_PICTURE){
				the->vdat.vdr.DecoderState = DECODE_GOP_0;
			}
			else{
				the->vdat.vdr.DecoderState = DECODE_GOP_JUMP_1;
			}
			the->vdat.bSecondField = 0;
		}

		break;

	case DECODE_GOP_JUMP_1:
		the->vdat.vdr.FlagDecodePicture = TRUE;			
		the->vdat.vdr.DecoderState = DECODE_GOP_0 ;
		break;

	default:
		break;
	}
}

/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************************/
static STX_RESULT ForwardDecoder(video_decoder* the)
{ 
	STX_RESULT ret;

	the->vdat.dwDecodeStartTime = timeGetTime(); 
	the->vdat.vdr.FlagDecodePicture = FALSE;

	ret = Get_Hdr(the);

	if( ret < 0 ) {
		// throw data ;
		return ret;
	}

	if( ret == 0 ){

		InitializeSequence(the);

		//		TRACE0("end of seq\n");
		OutputLastFrameOfSequence(the);

		return 0;
	}

	if(	0 == the->vdat.bsw.pic_header.nPictureCodingType || the->vdat.bsw.pic_header.nPictureCodingType > 3 ){
		OutputLastFrameOfSequence(the);
		the->i_keyfrm_num = 0;
		return -1;
	}

	if ( the->vdat.bsw.pic_cod_ext.nPictureStructure == FRAME_PICTURE ){
		the->vdat.bSecondField = 0;
	}

	ParseForwardState(the);

	if( the->vdat.vdr.FlagDecodePicture  ){
		//		TRACE0("decode frame\n");
		DecodePicture(the);
	}

	return 1;
}

/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************************/
#if 0
void OutputStillFrame(video_decoder* the,b32 bEnd)
{
	//	TRACE0("STILL frame!");

	if( !the->vdat.lpPreloadFrameLoop->IsEmpty() ){
		//		TRACE0("OutputStillFrame: have rear frame ; \n" ) ;
		VideoFrame* pFrame;
		DecodePreloadFrame( &pFrame,0,  FORCE_DECODE );
		return;
	}

	if( NULL == ( lpCurrentPicture = lpBackwardPicture ) ) {
		return;
	}

	InitializeFrameAttributes();
	vfrmSetDecoded(lpCurrentPicture,TRUE);    // = TRUE;
	vfrmSetDelay(lpCurrentPicture,FALSE);     // = FALSE;
	vfrmSetInPred(lpCurrentPicture,FALSE);
	vfrmSetUpGradeDisplay(lpCurrentPicture,FALSE);
	vfrmSetHalfWidth(lpCurrentPicture,FALSE); // = FALSE;
	vfrmSetStill(lpCurrentPicture,TRUE);      // = TRUE;
	lpCurrentPicture->PictureCodingType = I_TYPE;
	lpCurrentPicture->RepeatDisplayTimes = 0;
	lpCurrentPicture->RepeatDisplayTimes = 0;

	DVDPrivateData* pDVDPriv = (DVDPrivateData*)( lpBackwardPicture->lpPrivateData );
	pDVDPriv->lpSubInfo = NULL;
	pDVDPriv->bHilightExist = FALSE;
	pDVDPriv->bMixSubpicture = FALSE;
	pDVDPriv->bQuit = FALSE;
	pDVDPriv->bSwitch = FALSE;
	pDVDPriv->bSwitchRes = FALSE;
	pDVDPriv->dwNvVideoRatio = the->vdat.vdr.dwWHScale;  // display using;
	pDVDPriv->CurrentCellPlayTime = the->vdat.vdr.CurrentCellPlayTime;
	pDVDPriv->dwTime = the->vdat.vdr.dwTime;
	pDVDPriv->dwCell = the->vdat.vdr.dwCell;
	pDVDPriv->pPGC = the->vdat.vdr.pPGC;
	pDVDPriv->dwVobuLBN = the->vdat.vdr.dwVobuLBN;
	pDVDPriv->bQuit = the->vdat.vdr.bQuit;
	pDVDPriv->bSwitch = the->vdat.vdr.bSwitch;
	pDVDPriv->bSwitchRes = the->vdat.vdr.bSwitch;
	pDVDPriv->dwLoopCount = the->vdat.vdr.dwLoopCount;

	m_lpVideoBuffer->SendFrame(lpCurrentPicture);	

}
#endif



/***************************************************************************************
***************************************************************************************/
#if 0
s32  StillDecoder()
{
	OutputStillFrame(FALSE);

	/*
	char strstill[256];
	memset(strstill,0,256);
	sprintf(strstill,"%s%X%s","still counter = ",the->vdat.vdr.RepeatDisplayTimes,"\n" );
	OutputDebugString(strstill);
	*/

	the->vdat.vdr.RepeatDisplayTimes -= nTimeStep ;

	if( the->vdat.vdr.RepeatDisplayTimes <= 0 ){
		the->vdat.vdr.RepeatDisplayTimes = 0;
		the->vdat.vdr.PreDecoderMode = the->vdat.vdr.DecoderMode = DECODE_START;
		//		lpVcallback->m_lpPlayControl->LxNvStopStill();
	}

	return 0;
}
#endif

/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************************/

static STX_RESULT  StartVideoSequence(video_decoder* the)
{
	STX_RESULT ret;

	//	TRACE0("seq header \n");

	the->vdat.vdr.FlagDecodePictureData8x = 0;
	the->vdat.vdr.FlagDropFieldBFrame = 0;
	the->vdat.vdr.FlagFastDecode8X = 0;
	the->vdat.nSequenceFramenum = 0;
	the->vdat.nBitstreamFramenum = 0;

	if( 0 ==  (ret = Get_Hdr(the)) )	{
		OutputLastFrameOfSequence(the);
		return 0;
	}

	if( I_TYPE != the->vdat.bsw.pic_header.nPictureCodingType 
		&& the->vdat.bsw.pic_cod_ext.nPictureStructure == FRAME_PICTURE )	{
			the->vdat.bSecondField = 0;
			return 0;
	}

	//	TRACE0("start of seq\n");

	if( ! the->vdat.bSecondField )	{
		InitializeSequence(the);
	}

	//	TRACE0("start seq decode \n");
	DecodePicture(the);
	//	TRACE0("end seq decode \n");

	if( the->vdat.bsw.pic_cod_ext.nPictureStructure != FRAME_PICTURE )	{
		the->vdat.bSecondField = !the->vdat.bSecondField;
	}

	return 1;
}



/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************************/

/* SCALABILITY: add SNR enhancement layer block data to base layer */
/* ISO/IEC 13818-2 section 7.8.3.4: Addition of coefficients from the two layes */

/* limit coefficients to -2048..2047 */
/* ISO/IEC 13818-2 section 7.4.3 and 7.4.4: Saturation and Mismatch control */

/* reuse old picture buffers as soon as they are no longer needed 
based on life-time axioms of MPEG */

STX_RESULT  OutputLastFrameOfSequence(video_decoder* the)
{
	VideoFrame* p;

	if( p = the->lpOutputBackwardPicture ){

		vfrmSetDecoded(p,TRUE);          //
		vfrmSetInPred(the->lpCurrentPicture,FALSE);
		vfrmSetUpGradeDisplay(the->lpCurrentPicture,FALSE);
		vfrmSetEndSeq(p,TRUE);
		vfrmSetSkipAll(p,FALSE);
		vfrmSetDelay(p,FALSE);
		vfrmSetStill(p,FALSE);
		vfrmSetEnd(p,the->vdat.vdr.FlagEndOfFile);
		
		the->p_output_data = (stx_media_data*)p->lpOutput;
		if( the->lpOutputBackwardPicture->PictureCodingType != I_TYPE)	{
			the->nCurTimeCode += the->nTimeStep;
			the->lpOutputBackwardPicture->PresentTimeStamp = the->nCurTimeCode;
		}

		the->lpOutputBackwardPicture = NULL;
		return STX_DELIVER;
	}

	return STX_OK;
}

/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************************/

/*  the traditional mpegdec begin here; */

/* decode one nFrame or field picture */

static STX_RESULT DecodePicture(video_decoder* the)
{	
	STX_RESULT i_err;

	if( ! the->vdat.bSecondField ){
		EstDrop(the);
	}

	Update_Picture_Buffers(the);

	if( the->vdat.bsw.pic_header.nPictureCodingType == B_TYPE ){
		if( !(the->lpForwardPicture && the->lpBackwardPicture) ){
			the->vdat.vdr.FlagSkipFrame = TRUE;
		}
		else if( (!the->lpForwardPicture->lpData[0]) ||	(!the->lpBackwardPicture->lpData[0])){
			the->vdat.vdr.FlagSkipFrame = TRUE;
		}
	}
	else if(the->vdat.bsw.pic_header.nPictureCodingType == P_TYPE ){
		if(!the->lpForwardPicture){
			the->vdat.vdr.FlagSkipFrame = TRUE;
		}
		else if(!the->lpForwardPicture->lpData[0]){
			the->vdat.vdr.FlagSkipFrame = TRUE;
		}
	}

	vfrmSetSkipAll(the->lpCurrentPicture,the->vdat.vdr.FlagSkipFrame);

	if( ! the->vdat.vdr.FlagSkipFrame){
		return picture_data(the);
	}

	return STX_OK;
}

/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************************/

static void  InitializeFrameAttributes(video_decoder* the)  
{
	//{ nFrame coding relevant attributes;
	vfrmSetUpGradeDisplay(the->lpCurrentPicture,FALSE);

	vfrmSetInPred(the->lpCurrentPicture,FALSE);
	vfrmSetPtf(the->lpCurrentPicture,0);
	vfrmSetDecoded(the->lpCurrentPicture,FALSE);

	vfrmSetEnd(the->lpCurrentPicture,FALSE);                       // 
	vfrmSetEndSeq(the->lpCurrentPicture,FALSE);                    // 
	vfrmSetSkipBot(the->lpCurrentPicture,FALSE);                   // 
	vfrmSetSpeedFast(the->lpCurrentPicture,the->vdat.vdr.FlagFastDecode8X);  // 
	vfrmSetDisplay(the->lpCurrentPicture,TRUE);                    // 
	vfrmSetStill(the->lpCurrentPicture,FALSE);                     // 

	if( the->bProgressiveSequence ){
		if( the->vdat.bsw.pic_cod_ext.bRepeatFirstField ){
			the->lpCurrentPicture->nFlagRepeatFrame =  
				( 1 + the->vdat.bsw.pic_cod_ext.bTopFieldFirst ) << 1;
		}
		else{
			the->lpCurrentPicture->nFlagRepeatFrame = 0;
		}
	}
	else if( the->vdat.bsw.pic_cod_ext.bProgressiveFrame ){
		the->lpCurrentPicture->nFlagRepeatFrame = the->vdat.bsw.pic_cod_ext.bRepeatFirstField;
	}
	else{
		the->lpCurrentPicture->nFlagRepeatFrame = 0;
	}

	the->lpCurrentPicture->FrameRateCode = the->nFrameRateCode;  
	the->lpCurrentPicture->nFrameRate = rate_table[the->nFrameRateCode].frame_rate;  
	the->lpCurrentPicture->nClockMiliSecond = rate_table[the->nFrameRateCode].clock;

	the->lpCurrentPicture->BitRate = the->nBitRateValue * 400;

	the->lpCurrentPicture->PictureCodingType = the->vdat.bsw.pic_header.nPictureCodingType;
	the->lpCurrentPicture->PictureStructure = the->vdat.bsw.pic_cod_ext.nPictureStructure;
	the->lpCurrentPicture->ChromaFormat = the->vdat.nChromaFormat;  

	the->lpCurrentPicture->dwDisplayWhr = sartab[the->nAspectRatioInformation].ratio;

	SetRect(&the->lpCurrentPicture->SrcRect,
		0,0,the->vdat.nHorizontalSize,the->vdat.nVerticalSize);

	SetRect(&the->lpCurrentPicture->TargetRect,
		0,0,
		GetWidthFromRatio(the->vdat.nHorizontalSize,the->lpCurrentPicture->dwDisplayWhr),
		the->vdat.nVerticalSize);

	the->lpCurrentPicture->MacroBlockNumber = the->vdat.nMbSize;
	the->lpCurrentPicture->nCodedPictureWidth= the->vdat.nCodedPictureWidth;
	the->lpCurrentPicture->nCodedPictureHeight = the->vdat.nCodedPictureHeight;

	the->lpCurrentPicture->lpForwardPicture = the->lpForwardPicture;
	the->lpCurrentPicture->lpBackwardPicture = the->lpBackwardPicture;
	the->lpCurrentPicture->PictureCodingType = the->vdat.bsw.pic_header.nPictureCodingType;

	//}

	if( the->vdat.bsw.pic_header.nPictureCodingType == I_TYPE)	{
		the->nTimeIncree = 0;
		the->nCurTimeCode = the->vdat.vdr.PresentTimeStamp;
		the->lpCurrentPicture->PresentTimeStamp = the->vdat.vdr.PresentTimeStamp;
	}

	the->vdat.nLastTimeCode = the->nCurTimeCode;

	//{ navigation control data;
	the->lpCurrentPicture->NumberStreamPacket = the->vdat.vdr.NumberStreamPacket; 
	the->lpCurrentPicture->NumberPresentUnit = the->vdat.vdr.NumberPresentUnit;
	the->lpCurrentPicture->dwNvWhr = the->vdat.vdr.dwWHScale;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static STX_RESULT get_output_frame(video_decoder* the,VideoFrame** ppvf)
{
	STX_RESULT			i_err;
	VideoFrame*			p;
	stx_media_data*		p_mdat;

	for( ; ; ) {

		//xlog("get_output_frame\r\n");

		// get media data;
		i_err = XCALL(get_media_data,the->h_output_pin,&p_mdat,0);
		assert(STX_WOUNLD_BLOCK != i_err);

		if( STX_OK != i_err ) {
			return i_err;
		}
		i_err = p_mdat->query_interf(p_mdat,STX_IID_LxVideoFrame,(void**)&p );
		if( STX_OK != i_err ) {
			// quote the video frame interface pointer;
			return i_err;
		}
		// we do getting video frame interface at ff_get_mediat_dat, so need release it;
		p_mdat->release(p_mdat);

		if( !vfrmIsInPred(p) ) {
			break;
		}

		XCALL(release_media_data,the->h_output_pin,p_mdat);

	} // for( ; ; ) {

	// check dimension;
	if( p->nCodedPictureWidth != the->vdat.nCodedPictureWidth
		|| p->nCodedPictureHeight != the->vdat.nCodedPictureHeight 
		){
			i_err = vfrmAjustSurfaceSize(p,
				the->vdat.nCodedPictureWidth,the->vdat.nCodedPictureHeight,CHROMA420);
			if( STX_OK != i_err ) {
				return i_err;
			}
			// re-config the private buffer ;
			vfrmFreeUserData(p);

	} //if( the->lpCurrentPicture->nCod

	// we use this member to save media data interface;
	p->lpOutput = p_mdat;

	if( the->bResetFlag ) {
		the->bResetFlag = 0;
		p_mdat->set_flags(p_mdat,KEY_FRAME|START_FRAME);
	}

	*ppvf = p;

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static STX_RESULT   Update_Picture_Buffers(video_decoder* the)
{
	/*if we use non intra pred frames, 
	need not to do mixing and d-interlacing,
	so use bsw only;*/ 
	STX_RESULT			i_err;

	if( FRAME_PICTURE == the->vdat.bsw.pic_cod_ext.nPictureStructure || the->vdat.bSecondField == 0 ) {

		b32 bFrame;

		i_err = get_output_frame(the,&the->lpCurrentPicture);
		if( STX_OK != i_err ) {
			return i_err;
		}

		bFrame = FRAME_PICTURE == the->vdat.bsw.pic_cod_ext.nPictureStructure;

		if(bFrame){
			the->vdat.nOutputPicturePitch = the->vdat.nCodedPicturePitch;
			the->vdat.nPredSlicePit = (the->vdat.nCodedPicturePitch << 4) - the->vdat.nCodedPictureWidth;
			the->vdat.nPredSlicePitUV = (the->vdat.nCodedPicturePitch << 2) - the->vdat.nChromaWidth;
		}
		else{
			the->vdat.nOutputPicturePitch = the->vdat.nCodedPicturePitch << 1;
			the->vdat.nPredSlicePit = (the->vdat.nCodedPicturePitch << 8) - the->vdat.nCodedPictureWidth;
			the->vdat.nPredSlicePitUV = (the->vdat.nCodedPicturePitch << 4) - the->vdat.nChromaWidth;
		}

		the->vdat.nOutputSlicePit = (the->vdat.nOutputPicturePitch << 4) - the->vdat.nCodedPictureWidth;
		the->vdat.nOutputSlicePitUV = (the->vdat.nOutputPicturePitch << 2) - the->vdat.nChromaWidth;

		if( the->vdat.bsw.pic_header.nPictureCodingType != B_TYPE ){
			if( the->lpForwardPicture ){
				vfrmSetInPred(the->lpForwardPicture,FALSE);
			}

			the->lpForwardPicture = the->lpBackwardPicture;
			the->lpBackwardPicture = the->lpCurrentPicture;
			vfrmSetInPred(the->lpBackwardPicture,TRUE);
			the->lpOutputBackwardPicture = the->lpBackwardPicture;
			the->lpOutputForwardPicture = the->lpForwardPicture;
		} // if( the->vdat.bsw.pic_header.nPictureCodingType != B_TYPE ){

		InitializeFrameAttributes(the);

	} // if( FRAME_PICTURE == the->vdat.

	the->bSequenceFrameProgressive &= the->vdat.bsw.pic_cod_ext.bProgressiveFrame;

	if( the->vdat.bsw.pic_cod_ext.nPictureStructure == FRAME_PICTURE )	{
		the->vdat.nPredPit = the->vdat.nCodedPicturePitch;
		the->vdat.nOutputPit = the->vdat.nCodedPicturePitch;
		the->lpCurrentPicture->DctType = 0;
		the->vdat.bDeinterlaceNeeded = !the->bSequenceFrameProgressive && 
			( the->vdat.vidset.dwUseDeinterlacing != LX_DEINTERLACE_DISABLE );
	}
	else{
		the->vdat.nPredPit = the->vdat.nCodedPicturePitch << 1;
		the->vdat.nOutputPit = the->vdat.nCodedPicturePitch << 1;
		the->lpCurrentPicture->DctType = 1;
		the->vdat.bDeinterlaceNeeded = ( the->vdat.vidset.dwUseDeinterlacing != LX_DEINTERLACE_DISABLE );
	}

	if( BOTTOM_FIELD != the->vdat.bsw.pic_cod_ext.nPictureStructure ){
		the->vdat.bsw.current_frame[0] = the->lpCurrentPicture->lpData[0];
		the->vdat.bsw.current_frame[1] = the->lpCurrentPicture->lpData[1];
		the->vdat.bsw.current_frame[2] = the->lpCurrentPicture->lpData[2];
	}
	else{
		the->vdat.bsw.current_frame[0] = the->lpCurrentPicture->lpData[0] + the->vdat.nCodedPicturePitch;
		the->vdat.bsw.current_frame[1] = the->lpCurrentPicture->lpData[1] + (the->vdat.nCodedPicturePitch >> 1);
		the->vdat.bsw.current_frame[2] = the->lpCurrentPicture->lpData[2] + (the->vdat.nCodedPicturePitch >> 1);
	}

	the->vdat.bsw.current_pred_frame[0] = the->lpBackwardPicture->lpData[0];
	the->vdat.bsw.current_pred_frame[1] = the->lpBackwardPicture->lpData[1];
	the->vdat.bsw.current_pred_frame[2] = the->lpBackwardPicture->lpData[2];

	return STX_OK;
}


/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************************/

static STX_RESULT  FrameReorder(video_decoder* the)
{
	/*  tracking variables to insure proper output in spatial scalability */

	STX_RESULT i_err;

	if( the->vdat.bSecondField || 
		FRAME_PICTURE == the->vdat.bsw.pic_cod_ext.nPictureStructure){

		if ( the->vdat.nSequenceFramenum ){	

			VideoFrame* pOutputFrame;

			if ( B_TYPE == the->vdat.bsw.pic_header.nPictureCodingType) {
				pOutputFrame = the->lpCurrentPicture;
			}
			else{
				pOutputFrame = the->lpOutputForwardPicture;
			}

			pOutputFrame->DctType = !the->bSequenceFrameProgressive;

			the->vdat.nRepeatCounter += pOutputFrame->nFlagRepeatFrame;

			vfrmSetPtf(pOutputFrame,the->m_nPtfc);

			if( pOutputFrame->PictureCodingType != I_TYPE)	{
				the->nCurTimeCode += the->nTimeStep;
				pOutputFrame->PresentTimeStamp = the->nCurTimeCode;
			}

			//stx_log("time code = %"PRId64"d\r\n",pOutputFrame->PresentTimeStamp);

			// have output data;
			the->p_output_data = (stx_media_data*)pOutputFrame->lpOutput;

			the->p_output_data->set_time(the->p_output_data,
				PTS2REFTIME(pOutputFrame->PresentTimeStamp),
				PTS2REFTIME(pOutputFrame->PresentTimeStamp));

			the->p_output_data->set_duration(the->p_output_data,PTS2REFTIME(the->nTimeStep));

			return STX_DELIVER;
		}

		the->vdat.nBitstreamFramenum ++;
		the->vdat.nSequenceFramenum ++;
	}

	return STX_OK;
}

/***************************************************************************************
***************************************************************************************/
static void ResetBitsWin(BitsWindow* lpBw)
{
	lpBw->bNewSliceFlag = TRUE;
	lpBw->MBA = 0; /* macroblock address */
	lpBw->MBAinc = 0;

	lpBw->lpYuvAddr[YUV_ADDR_OUTPUT][0] =  lpBw->current_frame[0];
	lpBw->lpYuvAddr[YUV_ADDR_OUTPUT][1] =  lpBw->current_frame[1];
	lpBw->lpYuvAddr[YUV_ADDR_OUTPUT][2] =  lpBw->current_frame[2];

	lpBw->nYuvDit[YUV_DIT_VID][0] = 0;
	lpBw->nYuvDit[YUV_DIT_VID][1] = 0;
	lpBw->nYuvDit[YUV_DIT_OUTPUT][0] = 0;
	lpBw->nYuvDit[YUV_DIT_OUTPUT][1] = 0;
}

/***************************************************************************************
***************************************************************************************/

static void GetMbPos(video_decoder* the) // when debuged over, use mmx code ;
{
	the->vdat.bsw.dwMbPosX += 16;

	the->vdat.bsw.nYuvDit[YUV_DIT_VID][0] += 16;
	the->vdat.bsw.nYuvDit[YUV_DIT_VID][1] += 8;

	if( (s32)the->vdat.bsw.dwMbPosX == the->vdat.nCodedPictureWidth ){
		the->vdat.bsw.dwMbPosX = 0;
		the->vdat.bsw.dwMbPosY += 16;
		the->vdat.bsw.nYuvDit[YUV_DIT_VID][0] += the->vdat.nOutputSlicePit;
		the->vdat.bsw.nYuvDit[YUV_DIT_VID][1] += the->vdat.nOutputSlicePitUV;
	}

	the->vdat.bsw.lpYuvAddr[YUV_ADDR_OUTPUT][0] =  the->vdat.bsw.current_frame[0] +
		the->vdat.bsw.nYuvDit[YUV_DIT_VID][0] ; 

	the->vdat.bsw.lpYuvAddr[YUV_ADDR_OUTPUT][1] =  the->vdat.bsw.current_frame[1] + 
		the->vdat.bsw.nYuvDit[YUV_DIT_VID][1] ;      

	the->vdat.bsw.lpYuvAddr[YUV_ADDR_OUTPUT][2] =  the->vdat.bsw.current_frame[2] + 
		the->vdat.bsw.nYuvDit[YUV_DIT_VID][1] ;

}


/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************************/
static STX_RESULT picture_data(video_decoder* the)
{
	STX_RESULT	i_err;
	s32			nStart,nStep;
	s32			i;
	s32			nSliceNum;
	b32			bSliceFlag;

	/* number of macroblocks per picture */
	/* field picture has half as mnay macroblocks as nFrame */
	the->vdat.nMBAmax = ( FRAME_PICTURE == the->vdat.bsw.pic_cod_ext.nPictureStructure) ? 
		the->vdat.nMbSize : the->vdat.nMbSize >> 1;

	ResetBitsWin(&the->vdat.bsw);

	if( !the->vdat.bsw.lpYuvAddr[YUV_ADDR_OUTPUT][0] ){
		return STX_OK;
	}

	/*
	set the prediction picture, push the frame data to the decoder interleave ;
	*/

	nSliceNum = the->NumberGroupOfPicture;
	bSliceFlag =  nSliceNum >= ( the->vdat.nMbHeight >> 1 );

	if( bSliceFlag ) {
		nStart = 0;
		nStep = nSliceNum / the->g_nFrmDecoderNum;
	} 
	else {
		nStart = 0;
		nStep = the->vdat.nMbSize / the->g_nFrmDecoderNum;
	}

	the->bUpGrade = vfrmIsUpGradeDisplay(the->lpCurrentPicture) && 
		FRAME_PICTURE == the->vdat.bsw.pic_cod_ext.nPictureStructure ;


	for( i = 0; i < the->g_nFrmDecoderNum; i ++ ) {

		s32 nEnd;

		if( bSliceFlag ) {
			nEnd = i == the->g_nFrmDecoderNum-1 ? nSliceNum : nStart + nStep ;
			the->ppFrameCtx[i]->i_flag = FLAG_SLICE;
			the->ppFrameCtx[i]->i_start = nStart;
			the->ppFrameCtx[i]->i_end = nEnd;
		}
		else{
			nEnd = i == the->g_nFrmDecoderNum-1 ? the->vdat.nMbSize : nStart + nStep ;
			the->ppFrameCtx[i]->i_flag = FLAG_MB;
			the->ppFrameCtx[i]->i_start = nStart;
			the->ppFrameCtx[i]->i_end = nEnd;
		}

		the->ppFrameCtx[i]->bUpGrade = the->bUpGrade;

		if( the->bUpGrade ) {

			if( bSliceFlag ) {
				the->ppFrameCtx[i]->nUpGradeMb = ( ( nStart + nEnd ) * the->vdat.nMbWidth ) >> 1;
			}
			else {
				the->ppFrameCtx[i]->nUpGradeMb = ( nStart + nEnd ) >> 1;
			}

			//xlog("g_nStartMb = %d \n",nStart);
			//xlog("g_nEndMb = %d \n",nEnd);
			//xlog("nUpGradeMb = %d \n",the->ppFrameCtx[i]->nUpGradeMb);

		} // if( bUpGrade ) {

		the->ppFrameCtx[i]->i_flag = 0;
		the->ppFrameCtx[i]->i_stage = FLAG_DEC_FRM_INIT;

		nStart += nStep;

	} //for( i = 0; i < the->g_nFrmDecoderNum; i ++ ) {

	reset_mp_buffer(the);

	return STX_OK;
}


/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************************/
static void  ResetMfDecoder(video_decoder* the)
{
	s32 i;

	for( i = 0; i < the->g_nFrmDecoderNum; i ++ ) {
		update_frame_size(the->ppFrameCtx[i]);
	}
}

/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
decode one non-intra coded MPEG-2 block
***************************************************************************************/
static STX_RESULT Get_Hdr(video_decoder* the)
{
	u32 code;

	for( ; ; ){

		/* look for next_start_code */
		next_start_code();

		if( the->vdat.bsw.bs.nCurrentBit < 32 ) {
			return -1;
		}

		code = get_bits32();

		switch (code)
		{
		case SEQUENCE_HEADER_CODE:
			sequence_header(the);
			return 0;

		case PRELOAD_STM_END_CODE:
		case SEQUENCE_END_CODE:
			return 0;  

		case GROUP_START_CODE:
			group_of_pictures_header(the);
			continue;		

		case PICTURE_START_CODE:
			picture_header(the);
			if( !the->i_seqhdr_num ) {
				return -1;
			}
			if( the->vdat.bsw.pic_header.nPictureCodingType == I_TYPE ) {
				the->i_keyfrm_num ++;
				return 1;			
			}
			if( the->i_keyfrm_num ) {
				if( the->vdat.bsw.pic_header.nPictureCodingType == P_TYPE) {
					the->i_predfrm_num ++;
					return 1;			
				}
				if( the->vdat.bsw.pic_header.nPictureCodingType == B_TYPE) {
					return the->i_predfrm_num ? 1 : -1;
				}
			}
			return -1;

		default:
			break;
		}
	}

	return -1;
}


/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
decode sequence header
***************************************************************************************/
static void  sequence_header(video_decoder* the)
{
	s32 i;
	s32 market_bit;
	s32 bConstrainedParametersFlag;

	the->vdat.nHorizontalSize             = get_bits(12);    // 11
	the->vdat.nVerticalSize               = get_bits(12);    // 23

	the->nAspectRatioInformation     = get_bits(4);     // 27
	the->nFrameRateCode              = get_bits(4);     // 31 4
	the->nBitRateValue               = get_bits(18);    // 49;

	market_bit              = get_bits(1);     // suizhiqiang  50;

	the->nVbvBufferSizeCode          = get_bits(10);    // 60;
	
	bConstrainedParametersFlag  = get_bits(1);     // 61

	if (the->bLoadIntraQuantizerMatrix = get_bits(1)){   // 62;   
	
		for (i=0; i<64; i++){
			the->vdat.nIntraQuantizerMatrix[scan[ZIG_ZAG][i]] = get_bits(8);   // 63 -- 71
		}
	}
	else{
		for (i=0; i<64; i++){
			the->vdat.nIntraQuantizerMatrix[i] = default_intra_quantizer_matrix[i];
		}
	}


	if (the->bLoadNonIntraQuantizerMatrix = get_bits(1))	{
		for (i=0; i<64; i++){
			the->vdat.nNonIntraQuantizerMatrix[scan[ZIG_ZAG][i]] = get_bits(8);
		}
	}
	else{
		for (i=0; i<64; i++){
			the->vdat.nNonIntraQuantizerMatrix[i] = 16;
		}
	}

	/* copy luminance to chroma matrices */
	for (i=0; i<64; i++){
		the->vdat.nChromaIntraQuantizerMatrix[i] =	the->vdat.nIntraQuantizerMatrix[i];
		the->vdat.nChromaNonIntraQuantizerMatrix[i] =	the->vdat.nNonIntraQuantizerMatrix[i];
	}

#ifdef __QUANT_TABLE

	for (i=0; i<128; i++)	{
		s32 j;
		for( j = 0;j < 64;j ++ )	{
			the->vdat.nChromaIntraQuantizerMatrixTable[i][j] =
				the->vdat.nIntraQuantizerMatrixTable[i][j]  = the->vdat.nIntraQuantizerMatrix[j] * i;

			the->vdat.nChromaNonIntraQuantizerMatrixTable[i][j]  =
				the->vdat.nNonIntraQuantizerMatrixTable[i][j] = the->vdat.nNonIntraQuantizerMatrix[j] * i;
		}
	}

#endif

	extension_and_user_data(the);

	the->i_seqhdr_num ++;
}

/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
decode group of pictures header
ISO/IEC 13818-2 section 6.2.2.6
***************************************************************************************/

static void group_of_pictures_header(video_decoder* the)
{
	the->nTemporalReferenceBase = the->nTrueFramenumMax + 1; 	/* *CH* */
	the->nTemporalReferenceGOPReset = 1;

	the->bDropFlag   = get_bits(1);
	the->nHour        = get_bits(5);
	the->nMinute      = get_bits(6);
	get_bits(1);
	the->nSec         = get_bits(6);
	the->nFrame       = get_bits(6);
	the->bClosedGop  = get_bits(1);
	the->bBrokenLink = get_bits(1);

	extension_and_user_data(the);
}



/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
decode picture header
ISO/IEC 13818-2 section 6.2.3
***************************************************************************************/

static void   picture_header(video_decoder* the)
{
	s32 Extra_Information_Byte_Count;

	/* unless later overwritten by picture_spatial_scalable_extension() */
	the->vdat.nPictScal = 0; 

	the->vdat.bsw.pic_header.nTemporalReference  = get_bits(10);

	the->vdat.bsw.pic_header.nPictureCodingType = get_bits(3);

	the->vdat.bsw.pic_header.nVbvDelay           = get_bits(16);

	if (the->vdat.bsw.pic_header.nPictureCodingType == P_TYPE 
		|| the->vdat.bsw.pic_header.nPictureCodingType == B_TYPE)	{

		the->vdat.bsw.pic_header.nFullPelForwardVector = get_bits(1);
		the->vdat.bsw.pic_header.nForwardFCode = get_bits(3);
	}

	if ( the->vdat.bsw.pic_header.nPictureCodingType == B_TYPE ){

		the->vdat.bsw.pic_header.nFullPelBackwardVector = get_bits(1);
		the->vdat.bsw.pic_header.nBackwardFCode = get_bits(3);
	}

	Extra_Information_Byte_Count = extra_bit_information(the);  

	extension_and_user_data(the);

	/* update tracking information used to assist spatial scalability */
	Update_Temporal_Reference_Tacking_Data(the);
}

/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
decode DecodeSlice header
ISO/IEC 13818-2 section 6.2.4
***************************************************************************************/

static STX_RESULT SliceHeader(video_decoder* the)
{
	s32 slice_vertical_position_extension;
	s32 nQuantizerScaleCode;
	s32 slice_picture_id_enable = 0;
	s32 slice_picture_id = 0;
	s32 extra_information_slice = 0;

	slice_vertical_position_extension =
		(the->vdat.bMPEG2Flag && the->vdat.nVerticalSize>2800) ? get_bits(3) : 0;

	if (the->vdat.bScalableMode==SC_DP){
		the->bPriorityBreakPoint = get_bits(7);
	}

	nQuantizerScaleCode = get_bits(5);

	the->vdat.bsw.slice_data.nQuantizerScale =
		the->vdat.bMPEG2Flag ? (the->vdat.bsw.pic_cod_ext.nQScaleType ? 
		Non_Linear_quantizer_scale[nQuantizerScaleCode] : nQuantizerScaleCode<<1) 
		: nQuantizerScaleCode;

	/* slice_id introduced in March 1995 as part of the video corridendum
	(after the IS was drafted in November 1994) */
	if (get_bits(1)){
		//{ this is a optimazition; baojinlong, 2003-10-27
		u32 code = get_bits(8);
		the->vdat.bsw.slice_data.bIntraSlice = code>>7;
		slice_picture_id_enable = (code>>6) & 1;
		slice_picture_id = code & 0x3f;
		//}

		extra_information_slice = extra_bit_information(the);
	}
	else {
		the->vdat.bsw.slice_data.bIntraSlice = 0;
	}

	return slice_vertical_position_extension;
}

/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************************/
static void  copyright_extension(video_decoder* the)
{
	s32 reserved_data;  

	the->bCopyRightFlag =       get_bits(1); 
	the->nCopyrightIdentifier = get_bits(8);
	the->bOriginalOrCopy =     get_bits(1);

	/* reserved */
	reserved_data =        get_bits(7);
	the->nCopyrightNumber1 =   get_bits(20);
	the->nCopyrightNumber2 =   get_bits(22);
	the->nCopyrightNumber3 =   get_bits(22);
}

/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
decode extension and user data
ISO/IEC 13818-2 section 6.2.2.2
***************************************************************************************/
static void  extension_and_user_data(video_decoder* the)
{
	s32 code,ext_ID;

	next_start_code();

	while ( (code = Show_Bits(32)) == EXTENSION_START_CODE || code == USER_DATA_START_CODE ){

		if (code==EXTENSION_START_CODE)	{

			flush_bits32();

			ext_ID = get_bits(4);

			switch (ext_ID)
			{
			case SEQUENCE_EXTENSION_ID:
				sequence_extension(the);
				break;

			case SEQUENCE_DISPLAY_EXTENSION_ID:
				sequence_display_extension(the);
				break;

			case QUANT_MATRIX_EXTENSION_ID:
				quant_matrix_extension(the);
				break;

			case SEQUENCE_SCALABLE_EXTENSION_ID:
				sequence_scalable_extension(the);
				break;

			case PICTURE_DISPLAY_EXTENSION_ID:
				picture_display_extension(the);
				break;

			case PICTURE_CODING_EXTENSION_ID:
				picture_coding_extension(the);
				break;

			case PICTURE_SPATIAL_SCALABLE_EXTENSION_ID:
				next_start_code();
				//picture_spatial_scalable_extension();
				break;

			case PICTURE_TEMPORAL_SCALABLE_EXTENSION_ID:
				next_start_code();
				//picture_temporal_scalable_extension();
				break;

			case COPYRIGHT_EXTENSION_ID:
				copyright_extension(the);
				break;

			default:
				break;
			}

			next_start_code();
		}
		else{
			flush_bits32();
			user_data(the);
		}
	}
}


/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
decode sequence extension
ISO/IEC 13818-2 section 6.2.2.3
***************************************************************************************/
static void   sequence_extension(video_decoder* the)
{
	s32 nHorizontalSizeExtension;
	s32 nVerticalSizeExtension;
	s32 nBitRateExtension;
	s32 nVbvBufferSizeExtension;
	s32 nFrameRateExtensionN;
	s32 nFrameRateExtensionD;

	s32 bLowDelay;

	/* derive bit position for trace */
	the->vdat.bMPEG2Flag = 1;

	the->vdat.bScalableMode = SC_NONE; /* unless overwritten by sequence_scalable_extension() */
	the->nLayerId = 0;                /* unless overwritten by sequence_scalable_extension() */

	the->nProfileAndLevelIndication = get_bits(8);
	the->bProgressiveSequence         = get_bits(1);

	the->vdat.nChromaFormat  = get_bits(2);

	nHorizontalSizeExtension    = get_bits(2);
	nVerticalSizeExtension      = get_bits(2);
	nBitRateExtension           = get_bits(12);

	flush_bits(1);

	nVbvBufferSizeExtension    = get_bits(8);
	bLowDelay					= get_bits(1);
	nFrameRateExtensionN       = get_bits(2);
	nFrameRateExtensionD       = get_bits(5);

	/* the float point is of no use; so delete it; baojinlong. 2003-10-27
	fFrameRate =  fFrameRateTable[nFrameRateCode] *
	( (f64) (nFrameRateExtensionN + 1 ))/
	( (f64) (nFrameRateExtensionD + 1 ));
	*/

	/* special case for 422 nProfile & nLevel must be made */
	if((the->nProfileAndLevelIndication>>7) & 1){  
		/* escape bit of nProfileAndLevelIndication set */
		/* 4:2:2 Profile @ Main Level */
		if((the->nProfileAndLevelIndication&15)==5)	{
			the->nProfile = PROFILE_422;
			the->nLevel   = MAIN_LEVEL;  
		}
	}
	else{
		the->nProfile = the->nProfileAndLevelIndication >> 4;  /* Profile is upper nibble */
		the->nLevel   = the->nProfileAndLevelIndication & 0xF;  /* Level is lower nibble */
	}

	the->vdat.nHorizontalSize = (nHorizontalSizeExtension<<12) | (the->vdat.nHorizontalSize&0x0fff);
	the->vdat.nVerticalSize = (nVerticalSizeExtension<<12) | (the->vdat.nVerticalSize&0x0fff);

	/* ISO/IEC 13818-2 does not define nBitRateValue to be composed of
	* both the original nBitRateValue parsed in sequence_header() and
	* the optional nBitRateExtension in sequence_extension_header(). 
	* However, we use it for bitstream verification purposes. 
	*/

	the->nBitRateValue += (nBitRateExtension << 18);

	// the float point is of no use; so delete it; baojinlong. 2003-10-27	
	//fBitRate = ((f64) nBitRateValue) * 400.0;

	the->nVbvBufferSizeCode += (nVbvBufferSizeExtension << 10);

	/* iso 13818-2
	nVbvBufferSizeCode -- nVbvBufferSizeCode is an 18-bit integer. 
	The lower 10 bits of the integer are in vbv_buffer_size_value 
	and the upper 8 bits are in nVbvBufferSizeExtension.  
	The integer defines the size of the VBV 
	(Video Buffering Verifier, see Annex C)
	buffer needed to decode the sequence. It is defined as:
	B = 16 * 1024 * nVbvBufferSizeCode
	where B is the minimum VBV buffer size in bits required 
	to decode the sequence (see Annex C).
	*/
	// we use the value below, half of nVbvBufferSizeCode ; baojinlong. 2003-10-27;
	the->vdat.nVBVBufferSize = the->nVbvBufferSizeCode << 10;

	// the maxmize size is 4 M bytes;
	the->vdat.nVBVBufferSize = the->vdat.nVBVBufferSize > ( 1 << 22 ) ? (1 << 22) : the->vdat.nVBVBufferSize;

}


/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
decode sequence display extension
***************************************************************************************/
static void  sequence_display_extension(video_decoder* the)
{
	s32 nVideoFormat      = get_bits(3);

	s32 nColorDescription = get_bits(1);

	if (nColorDescription)	{

		s32 nColorPrimaries          = get_bits(8);

		s32 nTransferCharacteristics = get_bits(8);

		the->nMatrixCoefficients     = get_bits(8);
	}

	{
		s32 nDisplayHorizontalSize = get_bits(14);

		s32 marker = get_bits(1);

		s32 nDisplayVerticalSize   = get_bits(14);

	}
}

/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
decode quant matrix entension
ISO/IEC 13818-2 section 6.2.3.2
***************************************************************************************/
static void   quant_matrix_extension(video_decoder* the)
{
	s32 i;


#ifdef __QUANT_TABLE

	s32 j;


	if (the->bLoadIntraQuantizerMatrix = get_bits(1)){
		for (i=0; i<64; i++){
			the->vdat.nChromaIntraQuantizerMatrix[scan[ZIG_ZAG][i]] = 
				the->vdat.nIntraQuantizerMatrix[scan[ZIG_ZAG][i]] = get_bits(8);
		}

		for (i=0; i<128; i++)	{
			for(j=0;j<64;j++)	{
				the->vdat.nChromaIntraQuantizerMatrixTable[i][j] =
					the->vdat.nIntraQuantizerMatrixTable[i][j]  = the->vdat.nIntraQuantizerMatrix[j] * i;
			}
		}
	}

	if (the->bLoadNonIntraQuantizerMatrix = get_bits(1))	{
		for (i=0; i<64; i++)	{
			the->vdat.nChromaNonIntraQuantizerMatrix[scan[ZIG_ZAG][i]] =
				the->vdat.nNonIntraQuantizerMatrix[scan[ZIG_ZAG][i]] = get_bits(8);
		}

		for (i=0; i<128; i++)	{
			for(j=0;j<64;j++)	{
				the->vdat.nChromaNonIntraQuantizerMatrixTable[i][j] =
					the->vdat.nNonIntraQuantizerMatrixTable[i][j]  = the->vdat.nNonIntraQuantizerMatrix[j] * i;
			}
		}
	}

	if (the->bLoadChromaIntroQuantizerMatrix = get_bits(1)){
		for (i=0; i<64; i++) {
			the->vdat.nChromaIntraQuantizerMatrix[scan[ZIG_ZAG][i]] = get_bits(8);
		}

		for (i=0; i<128; i++){
			for(j=0;j<64;j++)	{
				the->vdat.nChromaIntraQuantizerMatrixTable[i][j]  = the->vdat.nChromaIntraQuantizerMatrix[j] * i;
			}
		}
	}

	if (the->bLoadChromaNonIntraQuantizerMatrix = get_bits(1)){
		for (i=0; i<64; i++) {
			the->vdat.nChromaNonIntraQuantizerMatrix[scan[ZIG_ZAG][i]] = get_bits(8);
		}

		for (i=0; i<128; i++)	{
			for(j=0;j<64;j++)	{
				the->vdat.nChromaNonIntraQuantizerMatrixTable[i][j]  = the->vdat.nChromaNonIntraQuantizerMatrix[j] * i;
			}
		}

	}

#else


	if (the->bLoadIntraQuantizerMatrix = get_bits(1)){
		for (i=0; i<64; i++){
			the->vdat.nChromaIntraQuantizerMatrix[scan[ZIG_ZAG][i]]
			= the->vdat.nIntraQuantizerMatrix[scan[ZIG_ZAG][i]]
			= get_bits(8);
		}
	}

	if (the->bLoadNonIntraQuantizerMatrix = get_bits(1)){
		for (i=0; i<64; i++)	{
			the->vdat.nChromaNonIntraQuantizerMatrix[scan[ZIG_ZAG][i]]
			= the->vdat.nNonIntraQuantizerMatrix[scan[ZIG_ZAG][i]]
			= get_bits(8);
		}
	}

	if (the->bLoadChromaIntroQuantizerMatrix = get_bits(1))	{
		for (i=0; i<64; i++) {
			the->vdat.nChromaIntraQuantizerMatrix[scan[ZIG_ZAG][i]] = get_bits(8);
		}

	}

	if (the->bLoadChromaNonIntraQuantizerMatrix = get_bits(1))	{
		for (i=0; i<64; i++) {
			the->vdat.nChromaNonIntraQuantizerMatrix[scan[ZIG_ZAG][i]] = get_bits(8);
		}
	}

#endif

}

/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
decode sequence scalable extension
ISO/IEC 13818-2   section 6.2.2.5
***************************************************************************************/
static void   sequence_scalable_extension(video_decoder* the)
{
	the->vdat.bScalableMode = get_bits(2) + 1; /* add 1 to make SC_DP != SC_NONE */

	the->nLayerId = get_bits(4);
}


/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
decode picture display extension
ISO/IEC 13818-2 section 6.2.3.3.
***************************************************************************************/
static void  picture_display_extension(video_decoder* the)
{
	s32 i;

	s32 number_of_frame_center_offsets;

	if( the->bProgressiveSequence ){

		if( the->vdat.bsw.pic_cod_ext.bRepeatFirstField ){

			if(the->vdat.bsw.pic_cod_ext.bTopFieldFirst)
				number_of_frame_center_offsets = 3;
			else
				number_of_frame_center_offsets = 2;
		}
		else{
			number_of_frame_center_offsets = 1;
		}
	}
	else{

		if( the->vdat.bsw.pic_cod_ext.nPictureStructure != FRAME_PICTURE )	{
			number_of_frame_center_offsets = 1;
		}
		else{
			if(the->vdat.bsw.pic_cod_ext.bRepeatFirstField)
				number_of_frame_center_offsets = 3;
			else
				number_of_frame_center_offsets = 2;
		}
	}

	/* now parse */
	for (i=0; i<number_of_frame_center_offsets; i++)	{

		the->vdat.bsw.pic_display_ext.nFrameCenterHorizontalOffset[i] = get_bits(16);

		get_bits(1);

		the->vdat.bsw.pic_display_ext.nFrameCenterVerticalOffset[i]   = get_bits(16);

		get_bits(1);
	}
}

/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************************/

/* decode picture coding extension */
static void  picture_coding_extension(video_decoder* the)
{
	the->vdat.bsw.pic_cod_ext.nFCode[0][0] = get_bits(4);
	the->vdat.bsw.pic_cod_ext.nFCode[0][1] = get_bits(4);
	the->vdat.bsw.pic_cod_ext.nFCode[1][0] = get_bits(4);
	the->vdat.bsw.pic_cod_ext.nFCode[1][1] = get_bits(4);

	/* added by JDL (17-JUN-97) : for SNR scalability with MPEG1 base layer */

	the->vdat.bsw.pic_cod_ext.nIntraDcPrecision         = get_bits(2);
	the->vdat.bsw.pic_cod_ext.nPictureStructure          = get_bits(2);  
	the->vdat.bsw.pic_cod_ext.bTopFieldFirst            = get_bits(1);
	the->vdat.bsw.pic_cod_ext.bFramePredFrameDct       = get_bits(1);
	the->vdat.bsw.pic_cod_ext.bConcealmentMotionVectors = get_bits(1);
	the->vdat.bsw.pic_cod_ext.nQScaleType           =     get_bits(1);
	the->vdat.bsw.pic_cod_ext.nIntraVlcFormat           = get_bits(1);
	the->vdat.bsw.pic_cod_ext.bAlternateScan         =     get_bits(1);
	the->vdat.bsw.pic_cod_ext.bRepeatFirstField         = get_bits(1);
	the->vdat.bsw.pic_cod_ext.bChroma420Type            = get_bits(1);
	the->vdat.bsw.pic_cod_ext.bProgressiveFrame          = get_bits(1);
	the->vdat.bsw.pic_cod_ext.bCompositeDisplayFlag     = get_bits(1);

	if (the->vdat.bsw.pic_cod_ext.bCompositeDisplayFlag) {
		flush_bits(20);
	}
}

/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************************/
/* decode extra bit information */
/* ISO/IEC 13818-2 section 6.2.3.4. */
static STX_RESULT extra_bit_information(video_decoder* the)
{
	s32 Byte_Count = 0;

	while (get_bits(1))	{
		flush_bits(8);		
		Byte_Count++;
	}

	return(Byte_Count);
}

/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************************/

/* ISO/IEC 13818-2 section 5.3 */
/* Purpose: this function is mainly designed to aid in bitstream conformance
testing.  A simple flush_bits(1) would do */

/* ISO/IEC 13818-2  sections 6.3.4.1 and 6.2.2.2.2 */
static void  user_data(video_decoder* the)
{
	/* skip ahead to the next start code */
	next_start_code();
}

/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************************/

/* introduced in September 1995 to assist Spatial Scalability */
static void  Update_Temporal_Reference_Tacking_Data(video_decoder* the)
{
	static s32 nTemporalReferenceWrap  = 0;
	static s32 temporal_reference_old   = 0;

	if ( the->vdat.bsw.pic_header.nPictureCodingType != B_TYPE
		&& the->vdat.bsw.pic_header.nTemporalReference!=temporal_reference_old) {	

		if (nTemporalReferenceWrap) {
			the->nTemporalReferenceBase += 1024;
			nTemporalReferenceWrap = 0;
		}

		if (the->vdat.bsw.pic_header.nTemporalReference < temporal_reference_old
			&& !the->nTemporalReferenceGOPReset)	{
			nTemporalReferenceWrap = 1;  /* we must have just passed a GOP-Header! */
		}

		temporal_reference_old = the->vdat.bsw.pic_header.nTemporalReference;
		the->nTemporalReferenceGOPReset = 0;
	}

	the->nTrueFramenum = the->nTemporalReferenceBase + the->vdat.bsw.pic_header.nTemporalReference;

	if (nTemporalReferenceWrap && 
		the->vdat.bsw.pic_header.nTemporalReference <= temporal_reference_old)	{
		the->nTrueFramenum += 1024;			
	}

	the->nTrueFramenumMax = (the->nTrueFramenum > the->nTrueFramenumMax) ?  \
		the->nTrueFramenum : the->nTrueFramenumMax;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT mpeg2_video_decode_frame
(video_decoder* the, frame_decoder* h_ctx, stx_sync_inf* h_sync )
{
	STX_RESULT		i_err;

	for( ; ; ) {

		// wait for decode;
		h_sync->h_ssrc->xwait(h_sync->h_ssrc,h_sync->h_task,INFINITE64);

		if( h_ctx->b_stop ) {
			h_ctx->b_exit = TRUE;
			h_sync->i_result |= STX_SUBTASK;
			return STX_OK; // sub task end;
		}

		i_err = video_subdecode(the,h_ctx,h_sync);

		if( STX_OK != i_err ) {
			break;
		}

		the->notify(the->h_notify);

	} // for( ; ; ) {

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT (*video_subdecode)
(video_decoder* the, frame_decoder* h_ctx, stx_sync_inf* h_sync );

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT mp_video_subdecode
(video_decoder* the, frame_decoder* h_ctx, stx_sync_inf* h_sync )
{
	STX_RESULT		i_err;
	BitsWindow*		pbsw;


	if( FLAG_DEC_FRM_INIT == h_ctx->i_stage ){

		//xlog("decode_frame:init\r\n");

		// prepare decode frames;
		set_current_frame(h_ctx, the->lpCurrentPicture);
		set_decode_mb(h_ctx,h_ctx->i_flag,h_ctx->i_start,h_ctx->i_end);

		pbsw = &h_ctx->bsw;

		//<< dup the stream environments >>
		*pbsw = the->vdat.bsw;
		init_ddct_info( the, pbsw ); // << update the dct table >>

		i_err = Mp_DecodeFrame(h_ctx,FLAG_DEC_FRM_INIT,0);
		if( STX_OK != i_err ) {
			return i_err;
		}


		if( h_ctx->bUpGrade ) {
			i_err = Mp_DecodeFrame(h_ctx,FLAG_DEC_FRM_TOP,h_ctx->nUpGradeMb);
			if( STX_OK != i_err ) {
				return i_err;
			}
			h_ctx->i_stage = FLAG_DEC_FRM_BOT;

			return STX_OK;

		} // if( h_ctx->bUpGrade ) {

		//xlog("decode_frame:decode normal\r\n");
		return Mp_DecodeFrame(h_ctx,FLAG_DEC_FRM_TOP,h_ctx->nUpGradeMb);

	} // if( FLAG_DEC_FRM_INIT == h_ctx->i_stage ){


	if( FLAG_DEC_FRM_BOT == h_ctx->i_stage ) {
		return Mp_DecodeFrame(h_ctx,FLAG_DEC_FRM_TOP,h_ctx->nUpGradeMb);
	} // if( FLAG_DEC_FRM_BOT == h_ctx->i_stage ) {

	// never reach;
	return STX_ERR_INVALID_PARAM;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT mpeg2_video_subdecode
(video_decoder* the, frame_decoder* h_ctx, stx_sync_inf* h_sync )
{
	STX_RESULT		i_err;
	BitsWindow*		pbsw;


	if( FLAG_DEC_FRM_INIT == h_ctx->i_stage ){

		//xlog("decode_frame:init\r\n");

		// prepare decode frames;
		set_current_frame(h_ctx, the->lpCurrentPicture);
		set_decode_mb(h_ctx,h_ctx->i_flag,h_ctx->i_start,h_ctx->i_end);

		pbsw = get_decode_window(h_ctx);

		//<< dup the stream environments >>
		*pbsw = the->vdat.bsw;
		init_ddct_info( the, pbsw ); // << update the dct table >>

		i_err = mpeg2_decode_frame(h_ctx,FLAG_DEC_FRM_INIT,0);
		if( STX_OK != i_err ) {
			return i_err;
		}

		if( h_ctx->bUpGrade ) {

			i_err = mpeg2_decode_frame(h_ctx,FLAG_DEC_FRM_TOP,h_ctx->nUpGradeMb);
			if( STX_OK != i_err ) {
				return i_err;
			}

			h_ctx->i_stage = FLAG_DEC_FRM_BOT;

			return STX_OK;

		} // if( h_ctx->bUpGrade ) {

		//xlog("decode_frame:decode normal\r\n");

		i_err = mpeg2_decode_frame(h_ctx,FLAG_DEC_FRM_NORMAL,0);
		if( STX_OK != i_err ) {
			return i_err;
		}

		return STX_OK;

	} // if( FLAG_DEC_FRM_INIT == h_ctx->i_stage ){


	if( FLAG_DEC_FRM_BOT == h_ctx->i_stage ) {

		i_err = mpeg2_decode_frame(h_ctx,FLAG_DEC_FRM_BOT,h_ctx->nUpGradeMb);
		if( STX_OK != i_err ) {
			return i_err;
		}

		return STX_OK;

	} // if( FLAG_DEC_FRM_BOT == h_ctx->i_stage ) {

	// never reach;
	return STX_ERR_INVALID_PARAM;
}


/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************************/
STX_RESULT  mpeg2_video_decode_start( video_decoder* the, u8* buf, s32 i_len )
{
	STX_RESULT i_err;

	if( the->vdat.nRepeatCounter >= 2 )	{

		//g_pVideoDecoder->Command(LX_CMD_DBFREQ,0,0,0);

		//TRACE0(" PAL TO NTSC, repeat; \n");

		the->vdat.nRepeatCounter -= 2 ;

		// get output media data;
		i_err = get_output_frame(the,&the->lpCurrentPicture);
		if( STX_OK != i_err ) {
			return i_err;
		}

		vfrmSetPtf(the->lpCurrentPicture,0);
		vfrmSetInPred(the->lpCurrentPicture,FALSE);

		vfrmSetUpGradeDisplay(the->lpCurrentPicture, !the->vdat.vdr.FlagFastDecode8X && the->vdat.vidset.bUpGrade );

		vfrmSetStill(the->lpCurrentPicture,FALSE);   //
		vfrmSetEnd(the->lpCurrentPicture,FALSE);     //
		vfrmSetEndSeq(the->lpCurrentPicture,FALSE);  //

		vfrmSetDecoded(the->lpCurrentPicture,TRUE);  //
		vfrmSetDisplay(the->lpCurrentPicture,TRUE);  //
		vfrmSetSkipAll(the->lpCurrentPicture,TRUE);  //
		vfrmSetDelay(the->lpCurrentPicture,TRUE);    //

		the->lpCurrentPicture->PictureCodingType = B_TYPE;
		the->lpCurrentPicture->MotionType = MC_FRAME;
		the->lpCurrentPicture->nFrameRate = rate_table[the->nFrameRateCode].frame_rate;  
		the->lpCurrentPicture->nClockMiliSecond = rate_table[the->nFrameRateCode].clock;
		the->lpCurrentPicture->FrameRateCode = the->nFrameRateCode; 
		the->lpCurrentPicture->dwDisplayWhr = sartab[the->nAspectRatioInformation].ratio;

		// output frame;
		the->p_output_data = (stx_media_data*)the->lpCurrentPicture->lpOutput;

		return STX_REPEAT;

	} // if( the->vdat.nRepeatCounter >= 2 )	{


	i_err = stx_init_get_bits((stx_bits_window*)the,buf,i_len*8);
	if(STX_OK != i_err ) {
		return i_err;
	}

	i_err = ForwardDecoder(the);
	if( i_err < 0 || !the->vdat.vdr.FlagDecodePicture ) {
		return STX_OK; // throw current data;
	}

	if( 0 == i_err ){
		VidReset(the,SEQ_RESET);
	}

	return i_err;
}

/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************************/
STX_RESULT  mpeg2_video_decode_end( video_decoder* the)
{
	vfrmSetDecoded(the->lpCurrentPicture,TRUE);

	if( the->vdat.bsw.pic_cod_ext.nPictureStructure != FRAME_PICTURE ){
		the->vdat.bSecondField = !the->vdat.bSecondField;
	}

	the->vdat.dwDecodeEndTime = timeGetTime() - the->vdat.dwDecodeStartTime - the->vdat.dwStreamReadTime;
	the->vdat.dwStreamReadTime = 0;

	FrameReorder(the);

	return STX_OK;
}

//} 

/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************************/
static void VidReset(video_decoder* the,u32 dw1)
{
	if( dw1 & INIT_RESET )	{

		InitializeVideoDecoder(the);

	}
	else { 

		//<< statistic data elements;
		memset(the->vdat.nGopDecTime,0,sizeof(the->vdat.nGopDecTime));
		memset(the->m_nPtfcArr,0,sizeof(the->m_nPtfcArr));
		the->m_nAvgPtfc = 0;
		the->m_nPtfc = 0;
		the->m_bDropGop = FALSE;
		//statistic data elements;  >>

		the->vdat.nRepeatCounter = 0 ; // 25/30 converting;

		if( dw1 & SEQ_RESET ){	
			ResetSequence(the);
		} //if( dw1 & SEQ_RESET ){	

		if( dw1 & JUMP_RESET ){

			the->vdat.vdr.DecoderState = DECODE_GOP_JUMP;
			the->vdat.vdr.RepeatDisplayTimes = 0;

			FlushBuffer(the);

		} // if( dw1 & JUMP_RESET ){

	} //else { 
}




/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************************/
STX_RESULT mpeg2_video_decode_initialize(video_decoder* the)
{	
	INIT_MEMBER(the->qwDts) ;
	INIT_MEMBER(the->qwPts) ;

	//<< const data members
	the->m_nPtfcArrNum = VID_PTFC_ARR_NUM;
	//   const data members >>

	the->nTimeStep = 0;

	memset(the->m_nPtfcArr,0,sizeof(the->m_nPtfcArr));
	the->m_nAvgPtfc = 0;
	the->m_nPtfc = 0;
	the->m_bDropGop = FALSE;

	the->ppFrameCtx = NULL;

	the->lpCurrentPicture =  0;
	the->lpForwardPicture =  0;
	the->lpBackwardPicture =  0;
	the->lpOutputForwardPicture =  0;
	the->lpOutputBackwardPicture =  0;

	InitializeVideoDecoder(the);

	return STX_OK;
}


/***************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************************/
void mpeg2_video_decode_cleanup(video_decoder* the)
{
	free_mb_table(the);

	stx_free_get_bits((stx_bits_window*)the);
}


#undef get_bits
#undef flush_bits
#undef get_rid_of_rear
#undef Headers 

#undef Show_Bits
#undef get_bits32
#undef flush_bits32
#undef next_start_code



