/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-11
***********************************************************************************/
#ifndef __FRAME_DECODER_H__
#define __FRAME_DECODER_H__


#include "video_decoder.h"


#if defined( __cplusplus )
extern "C" {
#endif


#define FLAG_MB     0
#define FLAG_SLICE  1

	void            set_decode_mb(frame_decoder* the,s32 nFlag, s32 nStart,s32 nEnd);
	void			update_frame_size(frame_decoder* the);

	void            set_current_frame(frame_decoder* the,VideoFrame* pCurrentPicture);
	BitsWindow*     get_decode_window(frame_decoder* the);

	frame_decoder*	create_frame_decoder(video_decoder* h_vdec );
	void			close_frame_decoder(frame_decoder* the);

#define FLAG_DEC_FRM_INIT	0
#define FLAG_DEC_FRM_NORMAL 1
#define FLAG_DEC_FRM_TOP    2
#define FLAG_DEC_FRM_BOT	3

	STX_RESULT		mpeg2_decode_frame(frame_decoder* the, s32 i_flag, s32 nUpGradeMb );
	STX_RESULT		Mp_DecodeFrame(frame_decoder* the, s32 i_flag, s32 nUpGradeMb );
	void			video_decoder_initialize(u32 mmflag);


#if defined( __cplusplus )
}
#endif

#endif // __FRAME_DECODER_H__




