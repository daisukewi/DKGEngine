// LxIDCT_MMX32.h: interface for the LxIDCT_MMX32 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LXIDCT_MMX32_H__1956E068_7153_44D6_BEE4_6F8B170FE388__INCLUDED_)
#define AFX_LXIDCT_MMX32_H__1956E068_7153_44D6_BEE4_6F8B170FE388__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000



#endif // !defined(AFX_LXIDCT_MMX32_H__1956E068_7153_44D6_BEE4_6F8B170FE388__INCLUDED_)
