/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-11
***********************************************************************************/
#include "stx_config.h"

#include "mc_decoder.h"

#include "stx_io.h"
#include "stx_io_stream.h"
#include "stx_os.h"
#include "stx_mem.h"
#include "stx_debug.h"

#include "stx_cpuid.h"


#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif



//#define __MCP_INTRINSIC

#ifndef __MCP_INTRINSIC
#define LXAVGB(mm_dst,mm_src,mm_0xfe,mm_0x01,mm_tmp)                       \
	__asm {                                                                    \
	__asm movq       mm_tmp,mm_dst       /* dup dst         ;               */ \
	__asm pand       mm_dst,mm_0xfe      /* bit 15-1 of top 76543210;       */ \
	__asm por        mm_tmp,mm_src       /* src | dst                       */ \
	__asm pand       mm_0xfe,mm_src      /* bit 15-1 of bot 76543210;       */ \
	__asm psrlq      mm_dst,1            /* top 76543210 >> 1;              */ \
	__asm psrlq      mm_0xfe,1           /* bot 76543210 >> 1;              */ \
	__asm pand       mm_0x01,mm_tmp      /* top bit0 | bot bit0;            */ \
	__asm paddusb    mm_dst,mm_0xfe      /* top bit15-1 + bot bit15-1;      */ \
	__asm paddusb    mm_dst,mm_0x01      /* avg 76543210; to mm_dst;        */ \
}
#else
#define LXAVGB(mm_dst,mm_src,mm_0xfe,mm_0x01,mm_tmp)                       \
	mm_tmp = mm_dst;       /* dup dst         ;               */ \
	mm_dst = _m_pand(mm_dst,mm_0xfe);      /* bit 15-1 of top 76543210;       */ \
	mm_tmp = _m_por(mm_tmp,mm_src );      /* src | dst                       */ \
	mm_0xfe = _m_pand(mm_0xfe,mm_src);      /* bit 15-1 of bot 76543210;       */ \
	mm_dst = _m_psrlqi(mm_dst,1);       /* top 76543210 >> 1;              */ \
	mm_0xfe = _m_psrlqi(mm_0xfe,1);      /* bot 76543210 >> 1;              */ \
	mm_0x01 = _m_pand(mm_0x01,mm_tmp);     /* top bit0 | bot bit0;            */ \
	mm_dst = _m_paddusb(mm_dst,mm_0xfe);     /* top bit15-1 + bot bit15-1;      */ \
	mm_dst = _m_paddusb(mm_dst,mm_0x01);     /* avg 76543210; to mm_dst;        */
#endif



#ifndef __MCP_INTRINSIC
#define GET_16_FROM_24(mmshl,mmshr,src,dst)\
	__asm{\
	__asm   movq       mm5,mmshl    \
	__asm   movq       mm6,mmshr    \
	__asm   movq       mm0, [esi + src]rec_mb_info.nTemp        \
	__asm   movq       mm1, [esi + src + 8]rec_mb_info.nTemp    \
	__asm   psrlq      mm0,mm5      \
	__asm   movq       mm3,mm1      \
	__asm   psllq      mm1,mm6      \
	__asm   movq       mm2, [esi + src + 16]rec_mb_info.nTemp    \
	__asm   por        mm0,mm1      \
	__asm   psrlq      mm3,mm5      \
	__asm   movq       [esi + dst ]rec_mb_info.nTemp,mm0    \
	__asm   psllq      mm2,mm6      \
	__asm   por        mm2,mm3      \
	__asm   movq       [esi + dst + 8]rec_mb_info.nTemp,mm2  \
}
#else
#define GET_16_FROM_24(mmshl,mmshr,src,dst)\
	imm5 =	*CONV_PM64(mmshl);    \
	imm6 =	*CONV_PM64(mmshr);    \
	imm0 =	*CONV_PM64((u8*)rmi->nTemp + src );    \
	imm1 =	*CONV_PM64((u8*)rmi->nTemp + src + 8 );    \
	imm0 =	_m_psrlq( imm0,imm5 );     \
	imm3 =	imm1;     \
	imm1 =	_m_psllq( imm1,imm6);      \
	imm2 =	*CONV_PM64((u8*)rmi->nTemp + src + 16 );    \
	imm0 =	_m_por( imm0,imm1);      \
	imm3 =	_m_psrlq( imm3,imm5);      \
	*CONV_PM64((u8*)rmi->nTemp + dst ) = imm0;    \
	imm2 = _m_psllq( imm2,imm6);      \
	imm2 = _m_por( imm2,imm3);      \
	*CONV_PM64((u8*)rmi->nTemp + dst + 8 ) = imm2;
#endif



//{ private functions called by s32erface function rec_mb();

STX_PRIVATE void rec_mb_frfr(mc_decoder* the,s32 vx,s32 vy, 
				 u8* refy,
				 u8* refv,
				 u8* refu);

STX_PRIVATE void rec_mb_frfr_top(mc_decoder* the,s32 vx,s32 vy, 
					 u8* refy,
					 u8* refv,
					 u8* refu);

STX_PRIVATE void rec_mb_frfr_bot(mc_decoder* the,s32 vx,s32 vy, 
					 u8* refy,
					 u8* refv,
					 u8* refu);

STX_PRIVATE void rec_mb_frfi(mc_decoder* the,s32 vx0,s32 vy0,
				 s32 vx1,s32 vy1,
				 s32 vs0,s32 vs1,
				 u8* refy,
				 u8* refv,
				 u8* refu);

STX_PRIVATE void rec_mb_frfi_top(mc_decoder* the,s32 vx0,s32 vy0,
					 s32 vx1,s32 vy1,
					 s32 vs0,s32 vs1,
					 u8* refy,
					 u8* refv,
					 u8* refu);

STX_PRIVATE void rec_mb_frfi_bot(mc_decoder* the,s32 vx0,s32 vy0,
					 s32 vx1,s32 vy1,
					 s32 vs0,s32 vs1,
					 u8* refy,
					 u8* refv,
					 u8* refu);


STX_PRIVATE void rec_mb_fifi(mc_decoder* the,s32 vx,
				 s32 vy,
				 s32 vs,
				 u8* refy,
				 u8* refv,
				 u8* refu);

STX_PRIVATE void rec_mb_2frfr(mc_decoder* the);
STX_PRIVATE void rec_mb_2frfr_top(mc_decoder* the);
STX_PRIVATE void rec_mb_2frfr_bot(mc_decoder* the);

STX_PRIVATE void rec_mb_2frfi(mc_decoder* the);
STX_PRIVATE void rec_mb_2frfi_top(mc_decoder* the);
STX_PRIVATE void rec_mb_2frfi_bot(mc_decoder* the);

STX_PRIVATE void rec_mb_2fifi(mc_decoder* the);

/* reconstruct macroblock of p frame or b frame only use forward prediction*/
STX_PRIVATE void rec_mb_p(mc_decoder* the); 

/* reconstruct macroblock of b frame*/
STX_PRIVATE void rec_mb_b(mc_decoder* the); 

/* reconstruct macroblock of b frame only use backward prediction*/
STX_PRIVATE void rec_mb_bb(mc_decoder* the);

/* reconstruct macroblock of b frame o use biprediction*/
STX_PRIVATE void rec_mb_2(mc_decoder* the);

STX_PRIVATE void Dual_Prime_Arithmetic
(
	mc_decoder* the,
	s32 DMV[][2], 
	s32 *dmvector, 
	s32 mvx, 
	s32 mvy
);

STX_PRIVATE void rec_mb_frame_dmv(mc_decoder* the);
STX_PRIVATE void rec_mb_frame_dmv_top(mc_decoder* the);
STX_PRIVATE void rec_mb_frame_dmv_bot(mc_decoder* the);
STX_PRIVATE void rec_mb_field_dmv(mc_decoder* the);
STX_PRIVATE void rec_mb_field_16x8(mc_decoder* the);
STX_PRIVATE void rec_mb_field_16x8_forward(mc_decoder* the);
STX_PRIVATE void rec_mb_field_16x8_backward(mc_decoder* the);

//private function; >> 



STX_PRIVATE void  ReleaseBuf(mc_decoder* the);


static void (*rec_avgblock)(rec_mb_info* rmi);
static void (*rec_addblock)(rec_mb_info* rmi);
static void (*rec_2b_1)(rec_mb_info* rmi);

#ifndef STX64	
	static void rec_avgblock_mmx2(rec_mb_info* rmi);
	static void rec_2b_1_mmx2(rec_mb_info* rmi);
	static void pref_2b_1_mmx2(rec_mb_info* rmi);
	static void rec_avgblock_mmx(rec_mb_info* rmi);
	static void rec_addblock_mmx(rec_mb_info* rmi);
	static void rec_2b_1_mmx(rec_mb_info* rmi);
#endif

static void rec_avgblock_sse2(rec_mb_info* rmi);
static void rec_addblock_sse2(rec_mb_info* rmi);
static void rec_2b_1_sse2(rec_mb_info* rmi);

static void rec_avgblock_c(rec_mb_info* rmi);
static void rec_addblock_c(rec_mb_info* rmi);
static void pfrm_rec_2b_1_c(rec_mb_info* rmi);
static void bfrm_rec_2b_1_c(rec_mb_info* rmi);
static void rec_2b_1_c(rec_mb_info* rmi);


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

static u32 g_StwTop[8];
static u32 g_StwBot[8];

static void InitStwTab()
{
	//	stwtop = stwtype%3; /* 0:temporal, 1:(spat+temp)/2, 2:spatial */
	//	stwbot = stwtype/3;

	s32 i;

	for(i = 0; i < 8; i ++ ){
		g_StwTop[i] = i % 3;
		g_StwBot[i] = i / 3;
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static u8 g_McClip[512];
static u8* g_pMcClip;

static void McInitClip()
{
	s32 i;
	g_pMcClip = &g_McClip[128];

	for( i = 0; i < 128; i ++ ){
		g_McClip[i] = 0;
	}
	for( i = 0; i < 256; i ++ ){
		g_pMcClip[i] = i;
	}
	for( i = 0; i < 128; i ++ ){
		g_pMcClip[i+256] = 0xFF;
	}
}


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

#define __MC_ADDALIGN_  TRUE
//#define __MC_ADDALIGN_  FALSE

// do forward alignment in rec_2b_1, rec_2b_2_mov;
// do backward alignment in rec_2b_2f00;

// mov forward mb to coey,coeuv; add block;
// mov forward mb to coey,coeuv; avg backward block to coey,coeuv; add block;


DECLARE_ALIGNED_16( static s64 , rec_msk_0x03[2] ) 
={
	0x0303030303030303,0x0303030303030303			
};

DECLARE_ALIGNED_16(static s64, rec_msk_0x02[2] )
={
	0x0202020202020202,0x0202020202020202			
};

DECLARE_ALIGNED_16(static s64, rec_msk_0x01[2] )
={
	0x0101010101010101,0x0101010101010101			
};

DECLARE_ALIGNED_16(static s64, rec_msk_0xfe[2] )
={
	0xfefefefefefefefe,0xfefefefefefefefe			
};

DECLARE_ALIGNED_16(static s64, rec_msk_0xfc[2] )
={
	0xfcfcfcfcfcfcfcfc,0xfcfcfcfcfcfcfcfc			
};



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void Update
(
 mc_decoder* the,
 s32			nMaxVector,
 s32			nMinVector,
 s32			nWidth,
 s32			nHeight,
 s32			nCodedPicturePitch,
 s32			nChromaPitch,
 s32			nChromaFormat,
 s32			bMPEG2Flag
 )
{
	the->m_nMaxVector = nMaxVector;
	the->m_nMinVector = nMinVector;
	the->m_nWidth = nWidth;
	the->m_nHeight = nHeight;
	the->m_nCodedPicturePitch = nCodedPicturePitch;
	the->m_nChromaPitch = nChromaPitch;
	the->m_nChromaFormat = nChromaFormat;
	the->m_bMPEG2Flag = bMPEG2Flag;	
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void UpdatePredPicture
( 
	mc_decoder* the,
	VideoFrame* lpBackwardPicture,
	VideoFrame* lpForwardPicture, 
	s32			nOutputPit,
	s32			bSecondField,
	s32			nPictureType,
	s32			bTopFiledFirst,
	s32			nPictureStructure
)
{
	the->m_lpBackwardPicture = lpBackwardPicture;
	the->m_lpForwardPicture = lpForwardPicture;
	the->m_nOutputPit = nOutputPit;
	the->m_bSecondField = bSecondField;

	the->nPictureCodingType = nPictureType;
	the->bTopFieldFirst = bTopFiledFirst;
	the->nPictureStructure = nPictureStructure;
}	


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void init_mc_decoder(u32 mmflag)
{
	InitStwTab();
	McInitClip();

	rec_addblock = rec_addblock_c;
	rec_avgblock = rec_avgblock_c;
	rec_2b_1 = rec_2b_1_c;

	//return;

#ifndef STX64
	if ( mmflag & MM_MMX ) {
		rec_addblock = rec_addblock_mmx;
		rec_avgblock = rec_avgblock_mmx;
		rec_2b_1 = rec_2b_1_mmx;
	} // if ( mmflag & MM_MMX ) {

	if( mmflag & MM_MMXEXT ){
		rec_avgblock = rec_avgblock_mmx2;
		rec_2b_1 = rec_2b_1_mmx2;
	} // if( mmflag & MM_MMXEXT ){
#endif

#if 0
	if( mmflag & MM_SSE2 ){
		rec_addblock = rec_addblock_sse2; 
		rec_avgblock = rec_avgblock_sse2;
		rec_2b_1 = rec_2b_1_sse2;
	} // if( mmflag & MM_SSE2 ){
#endif

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void close_mc_decoder(mc_decoder* the)
{
	xlivFree(the);
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
mc_decoder* create_mc_decoder(frame_decoder* fdec)
{
	mc_decoder* the;
	the = (mc_decoder*)xlivAlloc(sizeof(mc_decoder),TRUE,16);
	if( !the ) {
		return NULL;
	}
	the->reccoe = &fdec->bsw.reccoe;
	the->reccoe1 = &fdec->bsw.reccoe1;
	the->macro_block = &fdec->bsw.Macro_Block;
	return the;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void rec_mb(mc_decoder* the)
{
	if( the->m_bPref ){   // the data prefetch is of no use;
		return;
	}

	//	stwtop = stwtype%3; /* 0:temporal, 1:(spat+temp)/2, 2:spatial */
	//	stwbot = stwtype/3;
	the->m_nStwTop = g_StwTop[the->stwtype];
	the->m_nStwBot = g_StwBot[the->stwtype];
	//	ASSERT( m_nStwTop == 0 );
	//	ASSERT( m_nStwBot == 0 );

	// b frame maybe use fast code;
	the->m_RecInfo.nPictureType = the->nPictureCodingType;  
	the->m_RecInfo.skip_bottom_field_flag = the->bSkipBot;

	if( P_TYPE == the->m_RecInfo.nPictureType ) {
		rec_mb_p(the);
	}
	else if( B_TYPE == the->m_RecInfo.nPictureType ) {
		rec_mb_b(the);
	}
}
//}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void rec_mb_b(mc_decoder* the)
{
	if ( the->macroblock_type & MACROBLOCK_MOTION_FORWARD ){
		if(the->macroblock_type & MACROBLOCK_MOTION_BACKWARD ){
			rec_mb_2(the);/* two directions prediction;*/
		}
		else{
			rec_mb_p(the);/* only forward prediction;*/
		}
	}
	else if(the->macroblock_type & MACROBLOCK_MOTION_BACKWARD)	{
		/* only backward prediction*/
		rec_mb_bb(the);
	}
}
//}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void rec_mb_p(mc_decoder* the)
{
	if (FRAME_PICTURE == the->nPictureStructure ){	
		/*frame picture*/
		if ((MC_FRAME == the->motion_type) 
			|| !(the->macroblock_type & MACROBLOCK_MOTION_FORWARD)
			){
				rec_mb_frfr(
					the,
					(the->PMV[0][0][0]),
					(the->PMV[0][0][1]),
					(the->m_lpForwardPicture->lpData[0]),
					(the->m_lpForwardPicture->lpData[2]),
					(the->m_lpForwardPicture->lpData[1]));

		}
		else if (MC_FIELD == the->motion_type){
			// field-based prediction //
			rec_mb_frfi(
				the,
				(the->PMV[0][0][0]),
				(the->PMV[0][0][1]),
				(the->PMV[1][0][0]),
				(the->PMV[1][0][1]),	
				(the->motion_vertical_field_select[0][0]),
				(the->motion_vertical_field_select[1][0]),
				(the->m_lpForwardPicture->lpData[0]),
				(the->m_lpForwardPicture->lpData[2]),
				(the->m_lpForwardPicture->lpData[1]));

		}
		else if (MC_DMV == the->motion_type)  	{
			// dual prime prediction //
			rec_mb_frame_dmv(the);
		}
	}
	else {
		/*field picture */
		VideoFrame* predframe;
		s32 currentfield = (the->nPictureStructure == BOTTOM_FIELD);
		//determine which frame to use for prediction //
		if ( (the->m_RecInfo.nPictureType == P_TYPE)\
			&& (currentfield != the->motion_vertical_field_select[0][0])\
			&& the->m_bSecondField 
			){

				predframe = the->m_lpBackwardPicture; // same frame //
		}
		else{
			predframe = the->m_lpForwardPicture; // previous frame //   
		}

		if ( (MC_FIELD == the->motion_type)\
			|| !(the->macroblock_type & MACROBLOCK_MOTION_FORWARD)	)  {
				/* if p frame,the macroblock_type must be forward*/
				rec_mb_fifi(the,
					(the->PMV[0][0][0]),
					(the->PMV[0][0][1]),
					(the->motion_vertical_field_select[0][0]),
					(predframe->lpData[0]),
					(predframe->lpData[2]),
					(predframe->lpData[1]));

		}
		else if( MC_16X8 == the->motion_type){
			rec_mb_field_16x8(the);

		}
		else if (MC_DMV == the->motion_type){
			rec_mb_field_dmv(the);
		}
	}
}
//} end of rec_mb_p();


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void rec_mb_bb(mc_decoder* the)
{
	if (FRAME_PICTURE == the->nPictureStructure ) {

		/*frame picture*/
		if (MC_FRAME == the->motion_type) {
			rec_mb_frfr(the,
				(the->PMV[0][1][0]),
				(the->PMV[0][1][1]),
				(the->m_lpBackwardPicture->lpData[0]),
				(the->m_lpBackwardPicture->lpData[2]),
				(the->m_lpBackwardPicture->lpData[1]));
		}
		else if (MC_FIELD == the->motion_type)  {
			// field-based prediction //
			rec_mb_frfi(the,
				(the->PMV[0][1][0]),
				(the->PMV[0][1][1]),
				(the->PMV[1][1][0]),
				(the->PMV[1][1][1]),	
				(the->motion_vertical_field_select[0][1]),
				(the->motion_vertical_field_select[1][1]),
				(the->m_lpBackwardPicture->lpData[0]),
				(the->m_lpBackwardPicture->lpData[2]),
				(the->m_lpBackwardPicture->lpData[1]));
		}
	}
	else {			   
		/*field picture */
		if (MC_FIELD == the->motion_type){
			/**/
			rec_mb_fifi(the,
				(the->PMV[0][1][0]),
				(the->PMV[0][1][1]),
				(the->motion_vertical_field_select[0][1]),
				(the->m_lpBackwardPicture->lpData[0]),
				(the->m_lpBackwardPicture->lpData[2]),
				(the->m_lpBackwardPicture->lpData[1]));
		}
		else if( MC_16X8 == the->motion_type){
			rec_mb_field_16x8(the);
		}
	}
}
//}

#if 0
#	define CHECK_VECTOR(fdi)
#else
#	define CHECK_VECTOR(fdi) \
{\
	if( fdi > the->m_nMaxVector || fdi < the->m_nMinVector ) {\
		/*stx_assert(0);stx_log("min = %d, max = %d, dit = %d\r\n",the->m_nMinVector,the->m_nMaxVector,fdi);*/\
		return; \
	}\
}
#endif


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void rec_mb_frfr
( 
	mc_decoder* the,
	s32			vx,
	s32			vy, 
	u8*			refy,
	u8*			refv,
	u8*			refu
)
{
	if( the->m_nStwTop < 2 ){
		rec_mb_frfr_top(the,vx,vy,refy,refv,refu);
	}

	if( the->m_RecInfo.skip_bottom_field_flag ){
		return;
	}

	if( the->m_nStwBot < 2 ){
		rec_mb_frfr_bot(the,vx,vy,refy,refv,refu);
	}
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void rec_mb_frfr_top
( 
	mc_decoder* the,
	s32			vx,
	s32			vy, 
	u8*			refy,
	u8*			refv,
	u8*			refu
)
{
	s32 xint,yint,fdi,fdiuv;

	/*start address*/
	s32 nDstY,nDstX;

#if __MC_ADDALIGN_

	//  do prediction address 8 bytes align;
	s32 nRear8;
	s32 nForwardLeftAlignBits0;   
	s32 nForwardRightAlignBits0;

	s32 nForwardRightAlignBitsChroma;
	s32 nForwardLeftAlignBitsChroma;   

	b32	bFalign0,bFalign1;
#endif


	xint = DIV_TRUNC_MIN(vx,2);
	yint = DIV_TRUNC_MIN(vy,2);

	nDstY = ( the->dwMbPosY + yint ) * the->m_nCodedPicturePitch;
	nDstX = the->dwMbPosX + xint;
	fdi =  nDstY + nDstX;

	CHECK_VECTOR(fdi)


#if __MC_ADDALIGN_

	//  do prediction address 8 bytes align;
	nRear8 = nDstX & 7;	
	bFalign0 = nRear8 ? FALSE : TRUE; // 
	the->m_RecInfo.bForwardAlign = bFalign0;

	if( nRear8 ){  // not align;
	
		nDstX -= nRear8;  // align;
		nRear8 <<= 3;
		nForwardLeftAlignBits0 = nRear8;
		nForwardRightAlignBits0 = 64 - nRear8;
		fdi =  nDstY + nDstX;  // use the aligned address;

		the->m_RecInfo.nForwardLeftAlignBits0 = nForwardLeftAlignBits0;
		the->m_RecInfo.nForwardLeftAlignBits1 = nForwardLeftAlignBits0 + 8;
		the->m_RecInfo.nForwardRightAlignBits0 = nForwardRightAlignBits0;
		the->m_RecInfo.nForwardRightAlignBits1 = nForwardRightAlignBits0 - 8;
	}
#else
	the->m_RecInfo.bForwardAlign = TRUE;
#endif

	/*odd row*/	
	the->m_RecInfo.fxh = HALF_PERL(xint,vx);
	the->m_RecInfo.fyh = HALF_PERL(yint,vy);

	/*stride*/
	the->m_RecInfo.lfx0 = the->m_nCodedPicturePitch;
	the->m_RecInfo.lfx1 = (the->m_nCodedPicturePitch << 1);
	the->m_RecInfo.forw_mb0 = refy + fdi;
	the->m_RecInfo.ldstx = 32;
	/*address*/
	the->m_RecInfo.dest_mb0 = the->reccoe->coey;
	the->m_RecInfo.w = 16; /*16 pixels*/
	the->m_RecInfo.h = 8;

	rec_2b_1(&the->m_RecInfo); 

	if(the->dct_type){ /*field dct*/
	
		the->m_RecInfo.lblkx = 8; // wave;
		the->m_RecInfo.blk0 = the->macro_block->coeff[0];
		the->m_RecInfo.blk1 = the->macro_block->coeff[1];
		the->m_RecInfo.lfx0 = 32;
		the->m_RecInfo.forw_mb0 = the->reccoe->coey;
		the->m_RecInfo.ldstx = 32;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.w = 16; /*16 pixels*/
		the->m_RecInfo.h = 8;
		rec_addblock(&the->m_RecInfo);
	}
	else{/*frame dct*/
	
		/*top half*/
		the->m_RecInfo.lblkx = 16; // bob;
		the->m_RecInfo.blk0 = the->macro_block->coeff[0];
		the->m_RecInfo.blk1 = the->macro_block->coeff[1];
		the->m_RecInfo.lfx0 = 32;
		the->m_RecInfo.forw_mb0 = the->reccoe->coey;
		the->m_RecInfo.ldstx = 32;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.w = 16; /*16 pixels*/
		the->m_RecInfo.h = 4;
		rec_addblock(&the->m_RecInfo);

		/*bottom half*/
		the->m_RecInfo.lblkx = 16; // bob;
		the->m_RecInfo.blk0 = the->macro_block->coeff[2];
		the->m_RecInfo.blk1 = the->macro_block->coeff[3];
		the->m_RecInfo.lfx0 = 32;
		the->m_RecInfo.forw_mb0 = the->reccoe->coey + 16*8;
		the->m_RecInfo.ldstx = 32;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.w = 16; /*16 pixels*/
		the->m_RecInfo.h = 4;
		rec_addblock(&the->m_RecInfo);
	}

	/*chroma*/	
	if(CHROMA420 == the->m_nChromaFormat ){

		vx = DIV_TRUNC_ZERO(vx,2);
		vy = DIV_TRUNC_ZERO(vy,2);

		xint = DIV_TRUNC_MIN(vx,2);
		yint = DIV_TRUNC_MIN(vy,2);


		/*start address*/
		nDstX = ( the->dwMbPosX >> 1 ) + xint;

		// address align;		
#if __MC_ADDALIGN_
		nRear8 = nDstX & 7;	
		bFalign1 = nRear8 ? FALSE : TRUE;
		the->m_RecInfo.bForwardAlign = bFalign1;
		if( nRear8 ){  // not align;
		
			nDstX -= nRear8;  // align;
			nRear8 <<= 3;
			nForwardLeftAlignBitsChroma = nRear8;
			nForwardRightAlignBitsChroma = 64 - nRear8;
			the->m_RecInfo.nForwardLeftAlignBits0 = nForwardLeftAlignBitsChroma;
			the->m_RecInfo.nForwardLeftAlignBits1 = nForwardLeftAlignBitsChroma + 8;
			the->m_RecInfo.nForwardRightAlignBits0 = nForwardRightAlignBitsChroma;
			the->m_RecInfo.nForwardRightAlignBits1 = nForwardRightAlignBitsChroma - 8;
		}
#endif
		// address align;

		the->m_RecInfo.fxh = HALF_PERL(xint,vx);
		the->m_RecInfo.fyh = HALF_PERL(yint,vy);
		the->m_RecInfo.lfx0 = the->m_nChromaPitch;
		the->m_RecInfo.lfx1 = (the->m_nChromaPitch << 1);
		fdiuv = ((the->dwMbPosY>>1) + yint ) * the->m_nChromaPitch + nDstX;
		the->m_RecInfo.forw_mb0 = refu + fdiuv;
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->reccoe->coeuv[0];
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;/* 8 pixels each block*/

		rec_2b_1(&the->m_RecInfo);

		the->m_RecInfo.lblkx = 16; // bob;
		the->m_RecInfo.blk0 = the->macro_block->coeff[4];
		the->m_RecInfo.lfx0 = 16;
		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[0];
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.w = 8;/* 8 pixels each block*/
		the->m_RecInfo.h = 4;
		rec_addblock(&the->m_RecInfo);

		the->m_RecInfo.lfx0 = the->m_nChromaPitch;
		the->m_RecInfo.lfx1 = (the->m_nChromaPitch << 1);
		the->m_RecInfo.forw_mb0 = refv + fdiuv;
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->reccoe->coeuv[1];
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;/* 8 pixels each block*/

		rec_2b_1(&the->m_RecInfo);

		the->m_RecInfo.lblkx = 16; // bob;
		the->m_RecInfo.blk0 = the->macro_block->coeff[5];
		the->m_RecInfo.lfx0 = 16;
		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[1];
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.w = 8;/* 8 pixels each block*/
		the->m_RecInfo.h = 4;
		rec_addblock(&the->m_RecInfo);

	}

}


//}
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void rec_mb_frfr_bot
(
	mc_decoder* the,
	s32			vx,
	s32			vy, 
	u8*			refy,
	u8*			refv,
	u8*			refu
)
{
	s32 xint,yint,fdi,fdiuv;
	/*start address*/
	s32 nDstY,nDstX;

#if __MC_ADDALIGN_

	//  do prediction address 8 bytes align;
	s32        nRear8;
	s32        nForwardLeftAlignBits0;   
	s32        nForwardRightAlignBits0;
	s32        nForwardRightAlignBitsChroma;
	s32        nForwardLeftAlignBitsChroma;   
	b32       bFalign0,bFalign1;
#endif

	xint = DIV_TRUNC_MIN(vx,2);
	yint = DIV_TRUNC_MIN(vy,2);

	nDstY = ( the->dwMbPosY + yint ) * the->m_nCodedPicturePitch;
	nDstX = the->dwMbPosX + xint;
	fdi =  nDstY + nDstX;

	CHECK_VECTOR(fdi)

#if __MC_ADDALIGN_

	//  do prediction address 8 bytes align;
	nRear8 = nDstX & 7;	
	bFalign0 = nRear8 ? FALSE : TRUE; // 
	the->m_RecInfo.bForwardAlign = bFalign0;
	if( nRear8 ){  // not align;
	
		nDstX -= nRear8;  // align;
		nRear8 <<= 3;
		nForwardLeftAlignBits0 = nRear8;
		nForwardRightAlignBits0 = 64 - nRear8;
		fdi =  nDstY + nDstX;  // use the aligned address;

		the->m_RecInfo.nForwardLeftAlignBits0 = nForwardLeftAlignBits0;
		the->m_RecInfo.nForwardLeftAlignBits1 = nForwardLeftAlignBits0 + 8;
		the->m_RecInfo.nForwardRightAlignBits0 = nForwardRightAlignBits0;
		the->m_RecInfo.nForwardRightAlignBits1 = nForwardRightAlignBits0 - 8;
	}
#else

	the->m_RecInfo.bForwardAlign = TRUE;

#endif

	the->m_RecInfo.fxh = HALF_PERL(xint,vx);
	the->m_RecInfo.fyh = HALF_PERL(yint,vy);

	the->m_RecInfo.lfx0 = the->m_nCodedPicturePitch;
	the->m_RecInfo.lfx1 = (the->m_nCodedPicturePitch << 1);
	the->m_RecInfo.forw_mb0 = refy + fdi + the->m_nCodedPicturePitch;		
	the->m_RecInfo.ldstx = 32;
	the->m_RecInfo.dest_mb0 = the->reccoe->coey + 16;
	the->m_RecInfo.w = 16;/*16 pixels*/
	the->m_RecInfo.h = 8;

	rec_2b_1(&the->m_RecInfo);

	if(the->dct_type) {
		/*field dct*/
		/* even row */
		the->m_RecInfo.lblkx = 8; // wave;
		the->m_RecInfo.blk0 = the->macro_block->coeff[2];
		the->m_RecInfo.blk1 = the->macro_block->coeff[3];
		the->m_RecInfo.lfx0 = 32;
		the->m_RecInfo.forw_mb0 = the->reccoe->coey + 16;
		the->m_RecInfo.ldstx = 32;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.w = 16; /*16 pixels*/
		the->m_RecInfo.h = 8;
		rec_addblock(&the->m_RecInfo);
	}
	else{
		/*frame dct*/
		/*top 4 rows*/
		the->m_RecInfo.lblkx = 16; // bob;
		the->m_RecInfo.blk0 = the->macro_block->coeff[0] + 8;
		the->m_RecInfo.blk1 = the->macro_block->coeff[1] + 8;
		the->m_RecInfo.lfx0 = 32;
		the->m_RecInfo.forw_mb0 = the->reccoe->coey + 16;
		the->m_RecInfo.ldstx = 32;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.w = 16; /*16 pixels*/
		the->m_RecInfo.h = 4;
		rec_addblock(&the->m_RecInfo);
		/*bottom 4 rows */
		the->m_RecInfo.lblkx = 16; // bob;
		the->m_RecInfo.blk0 = the->macro_block->coeff[2] + 8;
		the->m_RecInfo.blk1 = the->macro_block->coeff[3] + 8;
		the->m_RecInfo.lfx0 = 32;
		the->m_RecInfo.forw_mb0 = the->reccoe->coey + 16*8 + 16;
		the->m_RecInfo.ldstx = 32;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.w = 16; /*16 pixels*/
		the->m_RecInfo.h = 4;
		rec_addblock(&the->m_RecInfo);
	}

	/*chroma*/	
	if(CHROMA420 == the->m_nChromaFormat)	{

		vx = DIV_TRUNC_ZERO(vx,2);
		vy = DIV_TRUNC_ZERO(vy,2);
		xint = DIV_TRUNC_MIN(vx,2);
		yint = DIV_TRUNC_MIN(vy,2);

		/*start address*/
		nDstX = ( the->dwMbPosX >> 1 ) + xint;

		// address align;		
#if __MC_ADDALIGN_
		nRear8 = nDstX & 7;	
		bFalign1 = nRear8 ? FALSE : TRUE;
		the->m_RecInfo.bForwardAlign = bFalign1;
		if( nRear8 ) {
			// not align;
			nDstX -= nRear8;  // align;
			nRear8 <<= 3;
			nForwardLeftAlignBitsChroma = nRear8;
			nForwardRightAlignBitsChroma = 64 - nRear8;
			the->m_RecInfo.nForwardLeftAlignBits0 = nForwardLeftAlignBitsChroma;
			the->m_RecInfo.nForwardLeftAlignBits1 = nForwardLeftAlignBitsChroma + 8;
			the->m_RecInfo.nForwardRightAlignBits0 = nForwardRightAlignBitsChroma;
			the->m_RecInfo.nForwardRightAlignBits1 = nForwardRightAlignBitsChroma - 8;
		}
#endif

		the->m_RecInfo.fxh = HALF_PERL(xint,vx);
		the->m_RecInfo.fyh = HALF_PERL(yint,vy);

		/*start address*/
		the->m_RecInfo.lfx0 = the->m_nChromaPitch;
		the->m_RecInfo.lfx1 = (the->m_nChromaPitch << 1);

		// address align;
		fdiuv = ((the->dwMbPosY>>1) + yint ) * the->m_nChromaPitch + nDstX;
		the->m_RecInfo.forw_mb0 = refu + fdiuv + the->m_nChromaPitch;

		the->m_RecInfo.lblkx = 16;
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->reccoe->coeuv[0] + 8;
		the->m_RecInfo.w = 8;   /* 8 pixels each block line*/
		the->m_RecInfo.h = 4;		
		rec_2b_1(&the->m_RecInfo);

		the->m_RecInfo.lblkx = 16; // bob;
		the->m_RecInfo.blk0 = the->macro_block->coeff[4] + 8;
		the->m_RecInfo.lfx0 = 16;
		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[0] + 8;
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.w = 8;/* 8 pixels each block line*/
		the->m_RecInfo.h = 4;
		rec_addblock(&the->m_RecInfo);

		the->m_RecInfo.lfx0 = the->m_nChromaPitch;
		the->m_RecInfo.lfx1 = (the->m_nChromaPitch << 1);
		the->m_RecInfo.forw_mb0 = refv + fdiuv + the->m_nChromaPitch;
		the->m_RecInfo.lblkx = 16;
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->reccoe->coeuv[1] + 8;
		the->m_RecInfo.w = 8;   /* 8 pixels each block line*/
		the->m_RecInfo.h = 4;
		rec_2b_1(&the->m_RecInfo);

		the->m_RecInfo.lblkx = 16; // bob;
		the->m_RecInfo.blk0 = the->macro_block->coeff[5] + 8;
		the->m_RecInfo.lfx0 = 16;
		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[1] + 8;
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.w = 8;/* 8 pixels each block line*/
		the->m_RecInfo.h = 4;
		rec_addblock(&the->m_RecInfo);
	}
}
//}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void rec_mb_frfi
(
	mc_decoder* the,
	s32			vx0,
	s32			vy0,
	s32			vx1,
	s32			vy1,
	s32			vs0,
	s32			vs1,
	u8*			refy,
	u8*			refv,
	u8*			refu
) 
{
	if( the->m_nStwTop < 2 ){
		rec_mb_frfi_top(the,vx0,vy0,vx1,vy1,vs0,vs1,refy,refv,refu);
	}
	if( the->m_RecInfo.skip_bottom_field_flag ){
		return;
	}
	if( the->m_nStwBot < 2 ){
		rec_mb_frfi_bot(the,vx0,vy0,vx1,vy1,vs0,vs1,refy,refv,refu);
	}
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void rec_mb_frfi_top
(
	mc_decoder* the,
	s32			vx0,
	s32			vy0,
	s32			vx1,
	s32			vy1,
	s32			vs0,
	s32			vs1,
	u8*			refy,
	u8*			refv,
	u8*			refu
) 
{
	s32 xint,yint,fdit;
	s32 nDstX ;
	s32 nDstY;

#if __MC_ADDALIGN_
	s32        nRear8;
	s32        nForwardLeftAlignBits0;   
	s32        nForwardRightAlignBits0;
	s32        nForwardRightAlignBitsChroma;
	s32        nForwardLeftAlignBitsChroma;   
	b32       bFalign0,bFalign1;
#endif

	/*top field*/
	xint = DIV_TRUNC_MIN(vx0,2);
	yint = DIV_TRUNC_MIN(vy0,2);

	/* the start address from prediction macroblock*/

	nDstX = the->dwMbPosX + xint;
	nDstY = (the->dwMbPosY + (yint & ~1) ) * the->m_nCodedPicturePitch;
	nDstY += vs0 ? the->m_nCodedPicturePitch:0;
	fdit =  nDstY + nDstX;
	CHECK_VECTOR(fdit)

#if __MC_ADDALIGN_

	nRear8 = nDstX & 7;	
	bFalign0 = nRear8 ? FALSE : TRUE; // 
	the->m_RecInfo.bForwardAlign = bFalign0;
	if( nRear8 ){
		// not align;
		nDstX -= nRear8;  // align;
		nRear8 <<= 3;
		nForwardLeftAlignBits0 = nRear8;
		nForwardRightAlignBits0 = 64 - nRear8;
		the->m_RecInfo.nForwardLeftAlignBits0 = nForwardLeftAlignBits0;
		the->m_RecInfo.nForwardLeftAlignBits1 = nForwardLeftAlignBits0 + 8;
		the->m_RecInfo.nForwardRightAlignBits0 = nForwardRightAlignBits0;
		the->m_RecInfo.nForwardRightAlignBits1 = nForwardRightAlignBits0 - 8;
		fdit = nDstY + nDstX;  // address aligned;
	}

#else
		the->m_RecInfo.bForwardAlign = TRUE;
#endif

	/*field based prediction*/			
	the->m_RecInfo.fxh = HALF_PERL(xint,vx0);
	the->m_RecInfo.fyh = HALF_PERL(yint,vy0);
	the->m_RecInfo.lfx0 = (the->m_nCodedPicturePitch << 1);
	the->m_RecInfo.lfx1 = (the->m_nCodedPicturePitch << 1);
	the->m_RecInfo.forw_mb0 = refy + fdit;
	the->m_RecInfo.ldstx = 32;
	the->m_RecInfo.dest_mb0 = the->reccoe->coey;
	the->m_RecInfo.h = 8;
	the->m_RecInfo.w = 16;

	rec_2b_1(&the->m_RecInfo);

	if(the->dct_type) {
		/*field dct*/
		the->m_RecInfo.lblkx = 8;
		the->m_RecInfo.blk0 = the->macro_block->coeff[0];
		the->m_RecInfo.blk1 = the->macro_block->coeff[1];
		the->m_RecInfo.lfx0 = 32;
		the->m_RecInfo.forw_mb0 = the->reccoe->coey;
		the->m_RecInfo.ldstx = 32;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.h = 8;
		the->m_RecInfo.w = 16;
		rec_addblock(&the->m_RecInfo);
	}
	else{/*frame dct*/
		/* top 4 rows */
		the->m_RecInfo.lblkx =16;
		the->m_RecInfo.blk0 = the->macro_block->coeff[0];
		the->m_RecInfo.blk1 = the->macro_block->coeff[1];
		the->m_RecInfo.lfx0 = 32;
		the->m_RecInfo.forw_mb0 = the->reccoe->coey;
		the->m_RecInfo.ldstx = 32;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 16;
		rec_addblock(&the->m_RecInfo);
		/* bottom 4 rows */
		the->m_RecInfo.lblkx =16;
		the->m_RecInfo.blk0 = the->macro_block->coeff[2];
		the->m_RecInfo.blk1 = the->macro_block->coeff[3];
		the->m_RecInfo.lfx0 = 32;
		the->m_RecInfo.forw_mb0 = the->reccoe->coey + 16*8;
		the->m_RecInfo.ldstx = 32;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 16;
		rec_addblock(&the->m_RecInfo);
	}

	if(CHROMA420 == the->m_nChromaFormat) {

		vx0 = DIV_TRUNC_ZERO(vx0,2);
		vy0 = DIV_TRUNC_ZERO(vy0,2);
		xint = DIV_TRUNC_MIN(vx0,2);
		yint = DIV_TRUNC_MIN(vy0,2);

		nDstY = vs0 ? the->m_nChromaPitch : 0;
		nDstY += ( (the->dwMbPosY >> 1 ) + (yint & ~1) ) * the->m_nChromaPitch;
		nDstX = ( the->dwMbPosX >> 1 ) + xint;

		// address align;		
#if __MC_ADDALIGN_
		nRear8 = nDstX & 7;	
		bFalign1 = nRear8 ? FALSE : TRUE;
		the->m_RecInfo.bForwardAlign = bFalign1;
		if( nRear8 ){  // not align;
		
			nDstX -= nRear8;  // align;
			nRear8 <<= 3;
			nForwardLeftAlignBitsChroma = nRear8;
			nForwardRightAlignBitsChroma = 64 - nRear8;
			the->m_RecInfo.nForwardLeftAlignBits0 = nForwardLeftAlignBitsChroma;
			the->m_RecInfo.nForwardLeftAlignBits1 = nForwardLeftAlignBitsChroma + 8;
			the->m_RecInfo.nForwardRightAlignBits0 = nForwardRightAlignBitsChroma;
			the->m_RecInfo.nForwardRightAlignBits1 = nForwardRightAlignBitsChroma - 8;
		}
#endif


		the->m_RecInfo.fxh = HALF_PERL(xint,vx0);
		the->m_RecInfo.fyh = HALF_PERL(yint,vy0);
		the->m_RecInfo.lfx0 = (the->m_nChromaPitch << 1);
		the->m_RecInfo.lfx1 = (the->m_nChromaPitch << 1);

		/*odd row*/
		fdit = nDstY + nDstX;
		the->m_RecInfo.forw_mb0 = refu + fdit;
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->reccoe->coeuv[0];
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;
		rec_2b_1(&the->m_RecInfo);	
		the->m_RecInfo.lfx0 = 16;
		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[0];
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.lblkx = 16;
		the->m_RecInfo.blk0 = the->macro_block->coeff[4];
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;
		rec_addblock(&the->m_RecInfo);

		the->m_RecInfo.lfx0 = (the->m_nChromaPitch << 1);
		the->m_RecInfo.lfx1 = (the->m_nChromaPitch << 1);
		the->m_RecInfo.forw_mb0 = refv + fdit;
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->reccoe->coeuv[1];
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;
		rec_2b_1(&the->m_RecInfo);			
		the->m_RecInfo.lfx0 = 16;
		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[1];
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.lblkx = 16;
		the->m_RecInfo.blk0 = the->macro_block->coeff[5];
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;
		rec_addblock(&the->m_RecInfo);
	}

}
//}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void rec_mb_frfi_bot
(
	mc_decoder* the,
	s32			vx0,
	s32			vy0,
	s32			vx1,
	s32			vy1,
	s32			vs0,
	s32			vs1,
	u8*			refy,
	u8*			refv,
	u8*			refu
) 
{
	s32 xint,yint,fdib,nDstX,nDstY;

#if __MC_ADDALIGN_
	s32        nRear8;
	s32        nForwardLeftAlignBits0;   
	s32        nForwardRightAlignBits0;
	s32        nForwardRightAlignBitsChroma;
	s32        nForwardLeftAlignBitsChroma;   
	b32       bFalign0,bFalign1;
#endif

	/*bottom field*/
	xint = DIV_TRUNC_MIN(vx1,2);
	yint = DIV_TRUNC_MIN(vy1,2);

	/* start address of macroblock used to do prediction */
	nDstY = (the->dwMbPosY + (yint & ~1) ) * the->m_nCodedPicturePitch;
	nDstY += vs1 ? the->m_nCodedPicturePitch:0;
	nDstX = the->dwMbPosX + xint;

	fdib = nDstY + nDstX;
	CHECK_VECTOR(fdib)

#if __MC_ADDALIGN_

	nRear8 = nDstX & 7;	
	bFalign0 = nRear8 ? FALSE : TRUE; // 
	the->m_RecInfo.bForwardAlign = bFalign0;
	if( nRear8 ){  // not align;
	
		nDstX -= nRear8;  // align;
		nRear8 <<= 3;
		nForwardLeftAlignBits0 = nRear8;
		nForwardRightAlignBits0 = 64 - nRear8;
		the->m_RecInfo.nForwardLeftAlignBits0 = nForwardLeftAlignBits0;
		the->m_RecInfo.nForwardLeftAlignBits1 = nForwardLeftAlignBits0 + 8;
		the->m_RecInfo.nForwardRightAlignBits0 = nForwardRightAlignBits0;
		the->m_RecInfo.nForwardRightAlignBits1 = nForwardRightAlignBits0 - 8;
		fdib =  nDstY + nDstX;  // use the aligned address;
	}
#else
		the->m_RecInfo.bForwardAlign = TRUE;
#endif

	the->m_RecInfo.fxh = HALF_PERL(xint,vx1);
	the->m_RecInfo.fyh = HALF_PERL(yint,vy1);

	the->m_RecInfo.lfx0 = the->m_RecInfo.lfx1 = (the->m_nCodedPicturePitch << 1);
	the->m_RecInfo.forw_mb0 = refy + fdib;
	the->m_RecInfo.ldstx = 32;
	the->m_RecInfo.dest_mb0 = the->reccoe->coey + 16;
	the->m_RecInfo.h=8;
	the->m_RecInfo.w=16;

	rec_2b_1(&the->m_RecInfo);

	if(the->dct_type){ /*field dct*/
	
		the->m_RecInfo.lblkx = 8;
		the->m_RecInfo.blk0 = the->macro_block->coeff[2];
		the->m_RecInfo.blk1 = the->macro_block->coeff[3];
		the->m_RecInfo.lfx0 = 32;
		the->m_RecInfo.forw_mb0 = the->reccoe->coey + 16;
		the->m_RecInfo.ldstx = 32;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.w = 16; /*16 pixels*/
		the->m_RecInfo.h = 8;
		rec_addblock(&the->m_RecInfo);
	}
	else{ /* frame dct */
	
		/*top half*/
		the->m_RecInfo.lblkx = 16; // bob;
		the->m_RecInfo.blk0 = the->macro_block->coeff[0] + 8;
		the->m_RecInfo.blk1 = the->macro_block->coeff[1] + 8;
		the->m_RecInfo.lfx0 = 32;
		the->m_RecInfo.forw_mb0 = the->reccoe->coey + 16;
		the->m_RecInfo.ldstx = 32;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.w = 16; /*16 pixels*/
		the->m_RecInfo.h = 4;
		rec_addblock(&the->m_RecInfo);
		/*bottom half*/
		the->m_RecInfo.lblkx = 16; // bob;
		the->m_RecInfo.blk0 = the->macro_block->coeff[2] + 8;
		the->m_RecInfo.blk1 = the->macro_block->coeff[3] + 8;
		the->m_RecInfo.lfx0 = 32;
		the->m_RecInfo.forw_mb0 = the->reccoe->coey + 16*8 + 16;
		the->m_RecInfo.ldstx = 32;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.w = 16; /*16 pixels*/
		the->m_RecInfo.h = 4;
		rec_addblock(&the->m_RecInfo);
	}

	/*chroma*/
	if(CHROMA420 == the->m_nChromaFormat){

		vx1 = DIV_TRUNC_ZERO(vx1,2);
		vy1 = DIV_TRUNC_ZERO(vy1,2);
		xint = DIV_TRUNC_MIN(vx1,2);
		yint = DIV_TRUNC_MIN(vy1,2);

		nDstX = (the->dwMbPosX>>1) + xint;
		nDstY = ((the->dwMbPosY>>1) + (yint & ~1)) * the->m_nChromaPitch;
		nDstY += vs1 ? the->m_nChromaPitch:0;

#if __MC_ADDALIGN_

		nRear8 = nDstX & 7;	
		bFalign1 = nRear8 ? FALSE : TRUE;
		the->m_RecInfo.bForwardAlign = bFalign1;
		if( nRear8 ){  // not align;
		
			nDstX -= nRear8;  // align;
			nRear8 <<= 3;
			nForwardLeftAlignBitsChroma = nRear8;
			nForwardRightAlignBitsChroma = 64 - nRear8;
			the->m_RecInfo.nForwardLeftAlignBits0 = nForwardLeftAlignBitsChroma;
			the->m_RecInfo.nForwardLeftAlignBits1 = nForwardLeftAlignBitsChroma + 8;
			the->m_RecInfo.nForwardRightAlignBits0 = nForwardRightAlignBitsChroma;
			the->m_RecInfo.nForwardRightAlignBits1 = nForwardRightAlignBitsChroma - 8;
		}
#endif

		the->m_RecInfo.fxh = HALF_PERL(xint,vx1);
		the->m_RecInfo.fyh = HALF_PERL(yint,vy1);
		/* even row */
		the->m_RecInfo.lfx0 = the->m_RecInfo.lfx1 = (the->m_nChromaPitch << 1);
		fdib = nDstY + nDstX;
		the->m_RecInfo.forw_mb0 = refu + fdib;
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->reccoe->coeuv[0] + 8;
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;
		rec_2b_1(&the->m_RecInfo);
		the->m_RecInfo.lfx0 = 16;
		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[0] + 8;
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.lblkx = 16;
		the->m_RecInfo.blk0 = the->macro_block->coeff[4] + 8;
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;
		rec_addblock(&the->m_RecInfo);

		the->m_RecInfo.lfx0 = the->m_RecInfo.lfx1 = (the->m_nChromaPitch << 1);
		the->m_RecInfo.forw_mb0 = refv + fdib;
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->reccoe->coeuv[1] + 8;
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;
		rec_2b_1(&the->m_RecInfo);	
		the->m_RecInfo.lfx0 = 16;
		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[1] + 8;
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.lblkx = 16;
		the->m_RecInfo.blk0 = the->macro_block->coeff[5]+8;
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;
		rec_addblock(&the->m_RecInfo);
	}
}
//}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void rec_mb_fifi
(
	mc_decoder* the,
	s32			vx,
	s32			vy,
	s32			vs,
	u8*			refy,
	u8*			refv,
	u8*			refu
)
{
	s32 xint,yint,fdi;

	s32 nDstY;
	s32 nDstX; 

#if __MC_ADDALIGN_

	s32        nRear8;
	s32        nForwardLeftAlignBits0;   
	s32        nForwardRightAlignBits0;
	s32        nForwardRightAlignBitsChroma;
	s32        nForwardLeftAlignBitsChroma;   
	b32       bFalign0,bFalign1;
#endif

	xint = DIV_TRUNC_MIN(vx,2);
	yint = DIV_TRUNC_MIN(vy,2);

	/*start address*/
	nDstY = (the->dwMbPosY+yint) * (the->m_nCodedPicturePitch*2);
	nDstY += vs ? the->m_nCodedPicturePitch : 0;
	nDstX = the->dwMbPosX + xint;

	fdi = nDstY + nDstX;

	CHECK_VECTOR(fdi)

		//  do prediction address 8 bytes align;


#if __MC_ADDALIGN_

	nRear8 = nDstX & 7;	
	bFalign0 = nRear8 ? FALSE : TRUE; // 
	the->m_RecInfo.bForwardAlign = bFalign0;
	if( nRear8 ){  // not align;
	
		nDstX -= nRear8;  // align;
		nRear8 <<= 3;
		nForwardLeftAlignBits0 = nRear8;
		nForwardRightAlignBits0 = 64 - nRear8;
		the->m_RecInfo.nForwardLeftAlignBits0 = nForwardLeftAlignBits0;
		the->m_RecInfo.nForwardLeftAlignBits1 = nForwardLeftAlignBits0 + 8;
		the->m_RecInfo.nForwardRightAlignBits0 = nForwardRightAlignBits0;
		the->m_RecInfo.nForwardRightAlignBits1 = nForwardRightAlignBits0 - 8;
		fdi =  nDstY + nDstX;  // use the aligned address;
	}

#else
		the->m_RecInfo.bForwardAlign = TRUE;
#endif

	the->m_RecInfo.fxh = HALF_PERL(xint,vx);
	the->m_RecInfo.fyh = HALF_PERL(yint,vy);

	/*top half*/
	the->m_RecInfo.lfx0 = the->m_RecInfo.lfx1 = (the->m_nCodedPicturePitch << 1);
	the->m_RecInfo.forw_mb0 = refy + fdi;
	the->m_RecInfo.ldstx = 16;
	the->m_RecInfo.dest_mb0 = the->reccoe->coey;
	the->m_RecInfo.h=8;
	the->m_RecInfo.w=16;
	rec_2b_1(&the->m_RecInfo); 
	the->m_RecInfo.lblkx = 8; 
	the->m_RecInfo.blk0 = the->macro_block->coeff[0];
	the->m_RecInfo.blk1 = the->macro_block->coeff[1];
	the->m_RecInfo.lfx0 = 16;
	the->m_RecInfo.forw_mb0 = the->reccoe->coey;
	the->m_RecInfo.ldstx = 16;
	the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
	the->m_RecInfo.h=8;
	the->m_RecInfo.w=16;
	rec_addblock(&the->m_RecInfo);

	/*bottom half*/
	the->m_RecInfo.lfx0 = the->m_RecInfo.lfx1 = (the->m_nCodedPicturePitch << 1);
	the->m_RecInfo.forw_mb0 = refy + fdi + (the->m_nCodedPicturePitch << 4);
	the->m_RecInfo.dest_mb0 = the->reccoe->coey + 16*8;
	the->m_RecInfo.h=8;
	the->m_RecInfo.w=16;
	rec_2b_1(&the->m_RecInfo);
	the->m_RecInfo.lblkx = 8; 
	the->m_RecInfo.blk0 = the->macro_block->coeff[2];
	the->m_RecInfo.blk1 = the->macro_block->coeff[3];
	the->m_RecInfo.lfx0 = 16;
	the->m_RecInfo.forw_mb0 = the->reccoe->coey + 16*8;
	the->m_RecInfo.ldstx = 16;
	the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
	the->m_RecInfo.h = 8;
	the->m_RecInfo.w = 16;
	rec_addblock(&the->m_RecInfo);

	if(CHROMA420 == the->m_nChromaFormat)	{	/*chroma*/

		vx = DIV_TRUNC_ZERO(vx,2);
		vy = DIV_TRUNC_ZERO(vy,2);
		xint = DIV_TRUNC_MIN(vx,2);
		yint = DIV_TRUNC_MIN(vy,2);
		the->m_RecInfo.fxh = HALF_PERL(xint,vx);
		the->m_RecInfo.fyh = HALF_PERL(yint,vy);

		nDstY = ((the->dwMbPosY>>1)+yint) * (the->m_nChromaPitch << 1);
		nDstY += vs ? the->m_nChromaPitch : 0;
		nDstX = (the->dwMbPosX>>1) + xint;

		// address align;	

#if __MC_ADDALIGN_

		nRear8 = nDstX & 7;	
		bFalign1 = nRear8 ? FALSE : TRUE;
		the->m_RecInfo.bForwardAlign = bFalign1;
		if( nRear8 ){  // not align;
		
			nDstX -= nRear8;  // align;
			nRear8 <<= 3;
			nForwardLeftAlignBitsChroma = nRear8;
			nForwardRightAlignBitsChroma = 64 - nRear8;
			the->m_RecInfo.nForwardLeftAlignBits0 = nForwardLeftAlignBitsChroma;
			the->m_RecInfo.nForwardLeftAlignBits1 = nForwardLeftAlignBitsChroma + 8;
			the->m_RecInfo.nForwardRightAlignBits0 = nForwardRightAlignBitsChroma;
			the->m_RecInfo.nForwardRightAlignBits1 = nForwardRightAlignBitsChroma - 8;
		}
#endif

		fdi = nDstY + nDstX;

		the->m_RecInfo.lfx0 = the->m_RecInfo.lfx1 =  (the->m_nChromaPitch << 1);
		the->m_RecInfo.forw_mb0 = refu + fdi;
		the->m_RecInfo.ldstx = 8;
		the->m_RecInfo.dest_mb0 = the->reccoe->coeuv[0];
		the->m_RecInfo.h=8;
		the->m_RecInfo.w=8;/* 8 pixels each block*/
		rec_2b_1(&the->m_RecInfo);
		the->m_RecInfo.lblkx = 8;
		the->m_RecInfo.blk0 = the->macro_block->coeff[4];
		the->m_RecInfo.lfx0 = 8;
		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[0];
		the->m_RecInfo.ldstx = 8;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.h=8;
		the->m_RecInfo.w=8;/* 8 pixels each block*/
		rec_addblock(&the->m_RecInfo);


		the->m_RecInfo.lfx0 = the->m_RecInfo.lfx1 =  (the->m_nChromaPitch << 1);
		the->m_RecInfo.forw_mb0 = refv + fdi;
		the->m_RecInfo.lblkx = 8;
		the->m_RecInfo.blk0 = the->macro_block->coeff[5];
		the->m_RecInfo.ldstx = 8;
		the->m_RecInfo.dest_mb0 = the->reccoe->coeuv[1];
		the->m_RecInfo.h=8;
		the->m_RecInfo.w=8;/* 8 pixels each block*/
		rec_2b_1(&the->m_RecInfo);
		the->m_RecInfo.lblkx = 8;
		the->m_RecInfo.blk0 = the->macro_block->coeff[5];
		the->m_RecInfo.lfx0 = 8;
		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[1];
		the->m_RecInfo.ldstx = 8;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.h=8;
		the->m_RecInfo.w=8;/* 8 pixels each block*/
		rec_addblock(&the->m_RecInfo);
	}
}
//}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void rec_mb_2(mc_decoder* the)
{
	if (FRAME_PICTURE == the->nPictureStructure )   {
		if ( MC_FRAME == the->motion_type ) 	{
			/*frame-based prediction*/
			rec_mb_2frfr(the);	
		}
		else if ( MC_FIELD == the->motion_type ) {
			/* field-based prediction */
			rec_mb_2frfi(the);
		}
	} 
	else { // TOP_FIELD or BOTTOM_FIELD //
		rec_mb_2fifi(the);
	}
}
//}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void rec_mb_2frfr(mc_decoder* the)
{
	if( the->m_nStwTop < 2 ){
		rec_mb_2frfr_top(the);
	}
	if( the->m_RecInfo.skip_bottom_field_flag ){
		return;
	}
	if( the->m_nStwBot < 2 ) {
		rec_mb_2frfr_bot(the);
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void rec_mb_2frfr_top(mc_decoder* the)
{
	s32 xint0,xint1,yint0,yint1,fdi,bdi,fdiuv,bdiuv;

	s32 nForwardDstY,nForwardDstX,nBackwardDstY,nBackwardDstX;

#if __MC_ADDALIGN_

	s32        nRear8;
	s32        nForwardLeftAlignBits0;   
	s32        nForwardRightAlignBits0;
	s32        nForwardRightAlignBitsChroma;
	s32        nForwardLeftAlignBitsChroma;   
	b32       bFalign0,bFalign1;

	s32        nBackwardLeftAlignBits0;   
	s32        nBackwardRightAlignBits0;
	s32        nBackwardLeftAlignBitsChroma;   
	s32        nBackwardRightAlignBitsChroma;
	b32       bBalign0,bBalign1;

#endif


	s32 vx0 = the->PMV[0][0][0];
	s32 vy0 = the->PMV[0][0][1];
	s32 vx1 = the->PMV[0][1][0];
	s32 vy1 = the->PMV[0][1][1];

	xint0 = DIV_TRUNC_MIN(vx0,2);
	yint0 = DIV_TRUNC_MIN(vy0,2);

	nForwardDstY = (the->dwMbPosY + yint0) * the->m_nCodedPicturePitch;
	nForwardDstX = the->dwMbPosX + xint0;
	fdi = nForwardDstY + nForwardDstX;

	CHECK_VECTOR(fdi)

	xint1 = DIV_TRUNC_MIN(vx1,2);
	yint1 = DIV_TRUNC_MIN(vy1,2);

	nBackwardDstY = (the->dwMbPosY + yint1) * the->m_nCodedPicturePitch;
	nBackwardDstX = the->dwMbPosX + xint1;
	bdi = nBackwardDstY + nBackwardDstX;

	CHECK_VECTOR(bdi)


#if __MC_ADDALIGN_

	nRear8 = nForwardDstX & 7;	
	bFalign0 = nRear8 ? FALSE : TRUE; // 

	if( nRear8 ){  // not align;
	
		nForwardDstX -= nRear8;  // align;
		nRear8 <<= 3;
		nForwardLeftAlignBits0 = nRear8;
		nForwardRightAlignBits0 = 64 - nRear8;

		fdi =  nForwardDstY + nForwardDstX;  // use the aligned address;
	}

	nRear8 = nBackwardDstX & 7;	
	bBalign0 = nRear8 ? FALSE : TRUE; // 

	if( nRear8 ){  // not align;
	
		nBackwardDstX -= nRear8;  // align;
		nRear8 <<= 3;
		nBackwardLeftAlignBits0 = nRear8;
		nBackwardRightAlignBits0 = 64 - nRear8;
		bdi =  nBackwardDstY + nBackwardDstX;  // use the aligned address;
	}

#else
		the->m_RecInfo.bForwardAlign = TRUE;	
#endif

	/*top field*/
	// forward align;

#if __MC_ADDALIGN_
	if( ! (the->m_RecInfo.bForwardAlign = bFalign0) ){
	
		the->m_RecInfo.nForwardLeftAlignBits0 = nForwardLeftAlignBits0;
		the->m_RecInfo.nForwardLeftAlignBits1 = nForwardLeftAlignBits0 + 8;
		the->m_RecInfo.nForwardRightAlignBits0 = nForwardRightAlignBits0;
		the->m_RecInfo.nForwardRightAlignBits1 = nForwardRightAlignBits0 - 8;
	}
#endif

	the->m_RecInfo.fxh = HALF_PERL(xint0,vx0);
	the->m_RecInfo.fyh = HALF_PERL(yint0,vy0);

	the->m_RecInfo.lfx0 = the->m_nCodedPicturePitch;
	the->m_RecInfo.lfx1 = (the->m_nCodedPicturePitch << 1);
	the->m_RecInfo.h = 8;
	the->m_RecInfo.w = 16;  /*16 pixels*/
	the->m_RecInfo.forw_mb0 = the->m_lpForwardPicture->lpData[0] + fdi;
	the->m_RecInfo.ldstx = 32;
	the->m_RecInfo.dest_mb0 = the->reccoe->coey;

	rec_2b_1(&the->m_RecInfo);       // forward block;

#if __MC_ADDALIGN_
	// backward align;
	if( ! (the->m_RecInfo.bForwardAlign = bBalign0) ){
	
		the->m_RecInfo.nForwardLeftAlignBits0  = nBackwardLeftAlignBits0;
		the->m_RecInfo.nForwardLeftAlignBits1  = nBackwardLeftAlignBits0 + 8;
		the->m_RecInfo.nForwardRightAlignBits0 = nBackwardRightAlignBits0;
		the->m_RecInfo.nForwardRightAlignBits1 = nBackwardRightAlignBits0 - 8;
	}
#endif

	the->m_RecInfo.fxh = HALF_PERL(xint1,vx1);
	the->m_RecInfo.fyh = HALF_PERL(yint1,vy1);

	the->m_RecInfo.lfx0 = the->m_nCodedPicturePitch;
	the->m_RecInfo.lfx1 = (the->m_nCodedPicturePitch << 1);
	the->m_RecInfo.h = 8;
	the->m_RecInfo.w = 16;  /*16 pixels*/
	the->m_RecInfo.forw_mb0 = the->m_lpBackwardPicture->lpData[0] + bdi;
	the->m_RecInfo.ldstx = 32;
	the->m_RecInfo.dest_mb0 = the->reccoe1->coey;

	rec_2b_1(&the->m_RecInfo);       // backward block;

	the->m_RecInfo.forw_mb0 = the->reccoe->coey;
	the->m_RecInfo.back_mb0 = the->reccoe1->coey;
	the->m_RecInfo.lfx0 = 32;
	the->m_RecInfo.h = 8;
	the->m_RecInfo.w = 16;
	rec_avgblock(&the->m_RecInfo);

	if(the->dct_type){/* field dct */
	
		the->m_RecInfo.lfx0 = 32;
		the->m_RecInfo.forw_mb0 = the->reccoe->coey;
		the->m_RecInfo.ldstx = 32;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.lblkx = 8;
		the->m_RecInfo.blk0 = the->macro_block->coeff[0];
		the->m_RecInfo.blk1 = the->macro_block->coeff[1];
		the->m_RecInfo.w = 16; /*16 pixels*/
		the->m_RecInfo.h = 8;
		rec_addblock(&the->m_RecInfo);
	}
	else{ /*frame dct */
	
		/*top 4 rows */
		the->m_RecInfo.lfx0 = 32;
		the->m_RecInfo.forw_mb0 = the->reccoe->coey;
		the->m_RecInfo.ldstx = 32;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.lblkx = 16;
		the->m_RecInfo.blk0 = the->macro_block->coeff[0];
		the->m_RecInfo.blk1 = the->macro_block->coeff[1];
		the->m_RecInfo.w = 16; /*16 pixels*/
		the->m_RecInfo.h = 4;
		rec_addblock(&the->m_RecInfo);	
		/*bottom 4 rows */
		the->m_RecInfo.lfx0 = 32;
		the->m_RecInfo.forw_mb0 = the->reccoe->coey + 16*8;
		the->m_RecInfo.ldstx = 32;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.lblkx = 16;
		the->m_RecInfo.blk0 = the->macro_block->coeff[2];
		the->m_RecInfo.blk1 = the->macro_block->coeff[3];
		the->m_RecInfo.w = 16; /*16 pixels*/
		the->m_RecInfo.h = 4;
		rec_addblock(&the->m_RecInfo);	
	}


	if(CHROMA420 == the->m_nChromaFormat){/*chroma*/

		/*start address*/
		vx0 = DIV_TRUNC_ZERO(vx0,2);
		vy0 = DIV_TRUNC_ZERO(vy0,2);
		xint0 = DIV_TRUNC_MIN(vx0,2);
		yint0 = DIV_TRUNC_MIN(vy0,2);

		nForwardDstY = ((the->dwMbPosY >> 1) + yint0) * the->m_nChromaPitch;
		nForwardDstX = (the->dwMbPosX>>1) + xint0;
		fdiuv = nForwardDstY + nForwardDstX;

		vx1 = DIV_TRUNC_ZERO(vx1,2);
		vy1 = DIV_TRUNC_ZERO(vy1,2);
		xint1 = DIV_TRUNC_MIN(vx1,2);
		yint1 = DIV_TRUNC_MIN(vy1,2);

		nBackwardDstY = ((the->dwMbPosY>>1) + yint1) * the->m_nChromaPitch;
		nBackwardDstX = (the->dwMbPosX>>1) + xint1;
		bdiuv = nBackwardDstY + nBackwardDstX;

#if __MC_ADDALIGN_

		nRear8 = nForwardDstX & 7;	
		bFalign1 = nRear8 ? FALSE : TRUE; // 
		if( nRear8 ){  // not align;
		
			nForwardDstX -= nRear8;  // align;
			nRear8 <<= 3;
			nForwardLeftAlignBitsChroma = nRear8;
			nForwardRightAlignBitsChroma = 64 - nRear8;
			fdiuv =  nForwardDstY + nForwardDstX;  // use the aligned address;
		}

		nRear8 = nBackwardDstX & 7;	
		bBalign1 = nRear8 ? FALSE : TRUE; // 
		if( nRear8 ){  // not align;
		
			nBackwardDstX -= nRear8;  // align;
			nRear8 <<= 3;
			nBackwardLeftAlignBitsChroma = nRear8;
			nBackwardRightAlignBitsChroma = 64 - nRear8;
			bdiuv =  nBackwardDstY + nBackwardDstX;  // use the aligned address;
		}

		if( ! (the->m_RecInfo.bForwardAlign = bFalign1) ){
		
			the->m_RecInfo.nForwardLeftAlignBits0 = nForwardLeftAlignBitsChroma;
			the->m_RecInfo.nForwardLeftAlignBits1 = nForwardLeftAlignBitsChroma + 8;
			the->m_RecInfo.nForwardRightAlignBits0 = nForwardRightAlignBitsChroma;
			the->m_RecInfo.nForwardRightAlignBits1 = nForwardRightAlignBitsChroma - 8;
		}
#endif

		the->m_RecInfo.fxh = HALF_PERL(xint0,vx0);
		the->m_RecInfo.fyh = HALF_PERL(yint0,vy0);
		the->m_RecInfo.lfx0 = the->m_nChromaPitch;
		the->m_RecInfo.lfx1 = (the->m_nChromaPitch << 1);
		the->m_RecInfo.w = 8;/* 8 pixels each block*/
		the->m_RecInfo.h = 4;
		the->m_RecInfo.forw_mb0 = the->m_lpForwardPicture->lpData[1] + fdiuv;
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->reccoe->coeuv[0];
		rec_2b_1(&the->m_RecInfo);       // forward block u;

		the->m_RecInfo.w = 8;/* 8 pixels each block*/
		the->m_RecInfo.h = 4;
		the->m_RecInfo.forw_mb0 = the->m_lpForwardPicture->lpData[2] + fdiuv;
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->reccoe->coeuv[1];
		rec_2b_1(&the->m_RecInfo);       // forward block v;

#if __MC_ADDALIGN_
		if( ! (the->m_RecInfo.bForwardAlign = bBalign1) ){
		
			the->m_RecInfo.nForwardLeftAlignBits0  = nBackwardLeftAlignBitsChroma;
			the->m_RecInfo.nForwardLeftAlignBits1  = nBackwardLeftAlignBitsChroma + 8;
			the->m_RecInfo.nForwardRightAlignBits0 = nBackwardRightAlignBitsChroma;
			the->m_RecInfo.nForwardRightAlignBits1 = nBackwardRightAlignBitsChroma - 8;
		}
#endif

		the->m_RecInfo.fxh = HALF_PERL(xint1,vx1);
		the->m_RecInfo.fyh = HALF_PERL(yint1,vy1);
		the->m_RecInfo.lfx0 = the->m_nChromaPitch;
		the->m_RecInfo.lfx1 = (the->m_nChromaPitch << 1);
		the->m_RecInfo.w = 8;/* 8 pixels each block*/
		the->m_RecInfo.h = 4;
		the->m_RecInfo.forw_mb0 = the->m_lpBackwardPicture->lpData[1] + bdiuv;
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->reccoe1->coeuv[0];
		rec_2b_1(&the->m_RecInfo);       // backward block u;

		the->m_RecInfo.w = 8;/* 8 pixels each block*/
		the->m_RecInfo.h = 4;
		the->m_RecInfo.forw_mb0 = the->m_lpBackwardPicture->lpData[2] + bdiuv;
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->reccoe1->coeuv[1];
		rec_2b_1(&the->m_RecInfo);       // backward block v;

		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[0];
		the->m_RecInfo.back_mb0 = the->reccoe1->coeuv[0];
		the->m_RecInfo.lfx0 = 16;
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;
		rec_avgblock(&the->m_RecInfo);

		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[1];
		the->m_RecInfo.back_mb0 = the->reccoe1->coeuv[1];
		the->m_RecInfo.lfx0 = 16;
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;
		rec_avgblock(&the->m_RecInfo);

		the->m_RecInfo.lfx0 = 16;
		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[0];
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.lblkx = 16;
		the->m_RecInfo.blk0 = the->macro_block->coeff[4];
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;
		rec_addblock(&the->m_RecInfo);

		the->m_RecInfo.lfx0 = 16;
		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[1];
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.lblkx = 16;
		the->m_RecInfo.blk0 = the->macro_block->coeff[5];
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;
		rec_addblock(&the->m_RecInfo);
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void rec_mb_2frfr_bot(mc_decoder* the)
{
	s32 xint0,xint1,yint0,yint1,fdi,bdi,fdiuv,bdiuv;

	s32 nForwardDstY,nForwardDstX,nBackwardDstY,nBackwardDstX;

#if __MC_ADDALIGN_

	s32 nRear8;
	s32 nForwardLeftAlignBits0;   
	s32 nForwardRightAlignBits0;
	s32 nForwardRightAlignBitsChroma;
	s32 nForwardLeftAlignBitsChroma;   
	b32 bFalign0,bFalign1;

	s32 nBackwardLeftAlignBits0;   
	s32 nBackwardRightAlignBits0;
	s32 nBackwardLeftAlignBitsChroma;   
	s32 nBackwardRightAlignBitsChroma;
	b32 bBalign0,bBalign1;

#endif

	s32 vx0 = the->PMV[0][0][0];
	s32 vy0 = the->PMV[0][0][1];
	s32 vx1 = the->PMV[0][1][0];
	s32 vy1 = the->PMV[0][1][1];

	xint0 = DIV_TRUNC_MIN(vx0,2);
	yint0 = DIV_TRUNC_MIN(vy0,2);

	nForwardDstY = (the->dwMbPosY + yint0) * the->m_nCodedPicturePitch;
	nForwardDstX = the->dwMbPosX + xint0;
	fdi = nForwardDstY + nForwardDstX;

	CHECK_VECTOR(fdi)

	xint1 = DIV_TRUNC_MIN(vx1,2);
	yint1 = DIV_TRUNC_MIN(vy1,2);

	nBackwardDstY = (the->dwMbPosY + yint1) * the->m_nCodedPicturePitch;
	nBackwardDstX = the->dwMbPosX + xint1;
	bdi = nBackwardDstY + nBackwardDstX;

	CHECK_VECTOR(bdi)


#if __MC_ADDALIGN_

	nRear8 = nForwardDstX & 7;	
	bFalign0 = nRear8 ? FALSE : TRUE; // 

	if( nRear8 ){  // not align;
		nForwardDstX -= nRear8;  // align;
		nRear8 <<= 3;
		nForwardLeftAlignBits0 = nRear8;
		nForwardRightAlignBits0 = 64 - nRear8;
		fdi =  nForwardDstY + nForwardDstX;  // use the aligned address;
	}

	nRear8 = nBackwardDstX & 7;	
	bBalign0 = nRear8 ? FALSE : TRUE; // 

	if( nRear8 ){  // not align;
		nBackwardDstX -= nRear8;  // align;
		nRear8 <<= 3;
		nBackwardLeftAlignBits0 = nRear8;
		nBackwardRightAlignBits0 = 64 - nRear8;
		bdi =  nBackwardDstY + nBackwardDstX;  // use the aligned address;
	}

#else
	the->m_RecInfo.bForwardAlign = TRUE;	
#endif


	/* bottom field*/
#if __MC_ADDALIGN_

	if( ! (the->m_RecInfo.bForwardAlign = bFalign0) ){
	
		the->m_RecInfo.nForwardLeftAlignBits0 = nForwardLeftAlignBits0;
		the->m_RecInfo.nForwardLeftAlignBits1 = nForwardLeftAlignBits0 + 8;
		the->m_RecInfo.nForwardRightAlignBits0 = nForwardRightAlignBits0;
		the->m_RecInfo.nForwardRightAlignBits1 = nForwardRightAlignBits0 - 8;
	}

#endif

	the->m_RecInfo.fxh = HALF_PERL(xint0,vx0);
	the->m_RecInfo.fyh = HALF_PERL(yint0,vy0);
	the->m_RecInfo.lfx0 = the->m_nCodedPicturePitch;
	the->m_RecInfo.lfx1 = (the->m_nCodedPicturePitch << 1);
	the->m_RecInfo.h = 8;
	the->m_RecInfo.w = 16;  /*16 pixels*/
	the->m_RecInfo.forw_mb0 = the->m_lpForwardPicture->lpData[0] + fdi + the->m_nCodedPicturePitch;
	the->m_RecInfo.ldstx = 32;
	the->m_RecInfo.dest_mb0 = the->reccoe->coey + 16;

	rec_2b_1(&the->m_RecInfo);       // forward block;

#if __MC_ADDALIGN_
	// backward align;
	if( ! (the->m_RecInfo.bForwardAlign = bBalign0 )){
	
		the->m_RecInfo.nForwardLeftAlignBits0  = nBackwardLeftAlignBits0;
		the->m_RecInfo.nForwardLeftAlignBits1  = nBackwardLeftAlignBits0 + 8;
		the->m_RecInfo.nForwardRightAlignBits0 = nBackwardRightAlignBits0;
		the->m_RecInfo.nForwardRightAlignBits1 = nBackwardRightAlignBits0 - 8;
	}
#endif

	the->m_RecInfo.fxh = HALF_PERL(xint1,vx1);
	the->m_RecInfo.fyh = HALF_PERL(yint1,vy1);
	the->m_RecInfo.lfx0 = the->m_nCodedPicturePitch;
	the->m_RecInfo.lfx1 = (the->m_nCodedPicturePitch << 1);
	the->m_RecInfo.h = 8;
	the->m_RecInfo.w = 16;  /*16 pixels*/
	the->m_RecInfo.forw_mb0 = the->m_lpBackwardPicture->lpData[0] + bdi + the->m_nCodedPicturePitch;
	the->m_RecInfo.ldstx = 32;
	the->m_RecInfo.dest_mb0 = the->reccoe1->coey + 16;

	rec_2b_1(&the->m_RecInfo);       // backward block;

	the->m_RecInfo.forw_mb0 = the->reccoe->coey + 16;
	the->m_RecInfo.back_mb0 = the->reccoe1->coey + 16;
	the->m_RecInfo.lfx0 = 32;
	the->m_RecInfo.h = 8;
	the->m_RecInfo.w = 16;
	rec_avgblock(&the->m_RecInfo);

	if(the->dct_type){/* field dct */
	
		the->m_RecInfo.lfx0 = 32;
		the->m_RecInfo.forw_mb0 = the->reccoe->coey + 16;
		the->m_RecInfo.ldstx = 32;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.lblkx = 8;
		the->m_RecInfo.blk0 = the->macro_block->coeff[2];
		the->m_RecInfo.blk1 = the->macro_block->coeff[3];
		the->m_RecInfo.w = 16; /*16 pixels*/
		the->m_RecInfo.h = 8;
		rec_addblock(&the->m_RecInfo);
	}
	else{ /*frame dct */
	
		/*top 4 rows*/
		the->m_RecInfo.lfx0 = 32;
		the->m_RecInfo.forw_mb0 = the->reccoe->coey + 16;
		the->m_RecInfo.ldstx = 32;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.lblkx = 16;
		the->m_RecInfo.blk0 = the->macro_block->coeff[0] + 8;
		the->m_RecInfo.blk1 = the->macro_block->coeff[1] + 8;
		the->m_RecInfo.w = 16; /*16 pixels*/
		the->m_RecInfo.h = 4;
		rec_addblock(&the->m_RecInfo);	

		the->m_RecInfo.lfx0 = 32;
		the->m_RecInfo.forw_mb0 = the->reccoe->coey + 16*8 + 16;
		the->m_RecInfo.ldstx = 32;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.lblkx = 16;
		the->m_RecInfo.blk0 = the->macro_block->coeff[2] + 8;
		the->m_RecInfo.blk1 = the->macro_block->coeff[3] + 8;
		the->m_RecInfo.w = 16; /*16 pixels*/
		the->m_RecInfo.h = 4;
		rec_addblock(&the->m_RecInfo);	
	}	

	if(CHROMA420 == the->m_nChromaFormat)	{	/*chroma*/

		/*start address*/
		vx0 = DIV_TRUNC_ZERO(vx0,2);
		vy0 = DIV_TRUNC_ZERO(vy0,2);
		xint0 = DIV_TRUNC_MIN(vx0,2);
		yint0 = DIV_TRUNC_MIN(vy0,2);

		nForwardDstY = ((the->dwMbPosY >> 1) + yint0) * the->m_nChromaPitch;
		nForwardDstX = (the->dwMbPosX>>1) + xint0;
		fdiuv = nForwardDstY + nForwardDstX;

		vx1 = DIV_TRUNC_ZERO(vx1,2);
		vy1 = DIV_TRUNC_ZERO(vy1,2);
		xint1 = DIV_TRUNC_MIN(vx1,2);
		yint1 = DIV_TRUNC_MIN(vy1,2);

		nBackwardDstY = ((the->dwMbPosY>>1) + yint1) * the->m_nChromaPitch;
		nBackwardDstX = (the->dwMbPosX>>1) + xint1;
		bdiuv = nBackwardDstY + nBackwardDstX;

#if __MC_ADDALIGN_

		nRear8 = nForwardDstX & 7;	
		bFalign1 = nRear8 ? FALSE : TRUE; // 
		if( nRear8 ){  // not align;
		
			nForwardDstX -= nRear8;  // align;
			nRear8 <<= 3;
			nForwardLeftAlignBitsChroma = nRear8;
			nForwardRightAlignBitsChroma = 64 - nRear8;
			fdiuv =  nForwardDstY + nForwardDstX;  // use the aligned address;
		}

		nRear8 = nBackwardDstX & 7;	
		bBalign1 = nRear8 ? FALSE : TRUE; // 
		if( nRear8 ){  // not align;
		
			nBackwardDstX -= nRear8;  // align;
			nRear8 <<= 3;
			nBackwardLeftAlignBitsChroma = nRear8;
			nBackwardRightAlignBitsChroma = 64 - nRear8;
			bdiuv =  nBackwardDstY + nBackwardDstX;  // use the aligned address;
		}

		if( ! (the->m_RecInfo.bForwardAlign = bFalign1))	{
			the->m_RecInfo.nForwardLeftAlignBits0 = nForwardLeftAlignBitsChroma;
			the->m_RecInfo.nForwardLeftAlignBits1 = nForwardLeftAlignBitsChroma + 8;
			the->m_RecInfo.nForwardRightAlignBits0 = nForwardRightAlignBitsChroma;
			the->m_RecInfo.nForwardRightAlignBits1 = nForwardRightAlignBitsChroma - 8;
		}
#endif

		the->m_RecInfo.fxh = HALF_PERL(xint0,vx0);
		the->m_RecInfo.fyh = HALF_PERL(yint0,vy0);
		the->m_RecInfo.lfx0 = the->m_nChromaPitch;
		the->m_RecInfo.lfx1 = (the->m_nChromaPitch << 1);
		the->m_RecInfo.w = 8;/* 8 pixels each block*/
		the->m_RecInfo.h = 4;
		the->m_RecInfo.forw_mb0 = the->m_lpForwardPicture->lpData[1] + fdiuv + the->m_nChromaPitch;
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->reccoe->coeuv[0] + 8;

		rec_2b_1(&the->m_RecInfo);       // forward block u;

		the->m_RecInfo.w = 8;/* 8 pixels each block*/
		the->m_RecInfo.h = 4;
		the->m_RecInfo.forw_mb0 = the->m_lpForwardPicture->lpData[2] + fdiuv + the->m_nChromaPitch;
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->reccoe->coeuv[1] + 8;

		rec_2b_1(&the->m_RecInfo);       // forward block v;

#if __MC_ADDALIGN_
		if( ! (the->m_RecInfo.bForwardAlign = bBalign1) )	{
			the->m_RecInfo.nForwardLeftAlignBits0  = nBackwardLeftAlignBitsChroma;
			the->m_RecInfo.nForwardLeftAlignBits1  = nBackwardLeftAlignBitsChroma + 8;
			the->m_RecInfo.nForwardRightAlignBits0 = nBackwardRightAlignBitsChroma;
			the->m_RecInfo.nForwardRightAlignBits1 = nBackwardRightAlignBitsChroma - 8;
		}
#endif

		the->m_RecInfo.fxh = HALF_PERL(xint1,vx1);
		the->m_RecInfo.fyh = HALF_PERL(yint1,vy1);
		the->m_RecInfo.lfx0 = the->m_nChromaPitch;
		the->m_RecInfo.lfx1 = (the->m_nChromaPitch << 1);
		the->m_RecInfo.w = 8;/* 8 pixels each block*/
		the->m_RecInfo.h = 4;
		the->m_RecInfo.forw_mb0 = the->m_lpBackwardPicture->lpData[1] + bdiuv + the->m_nChromaPitch;
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->reccoe1->coeuv[0] + 8;

		rec_2b_1(&the->m_RecInfo);       // backward block u;

		the->m_RecInfo.w = 8;/* 8 pixels each block*/
		the->m_RecInfo.h = 4;
		the->m_RecInfo.forw_mb0 = the->m_lpBackwardPicture->lpData[2] + bdiuv + the->m_nChromaPitch;
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->reccoe1->coeuv[1] + 8;

		rec_2b_1(&the->m_RecInfo);       // backward block v;

		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[0] + 8;
		the->m_RecInfo.back_mb0 = the->reccoe1->coeuv[0] + 8;
		the->m_RecInfo.lfx0 = 16;
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;
		rec_avgblock(&the->m_RecInfo);

		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[1] + 8;
		the->m_RecInfo.back_mb0 = the->reccoe1->coeuv[1] + 8;
		the->m_RecInfo.lfx0 = 16;
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;
		rec_avgblock(&the->m_RecInfo);

		the->m_RecInfo.lfx0 = 16;
		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[0] + 8;
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.lblkx = 16;
		the->m_RecInfo.blk0 = the->macro_block->coeff[4] + 8;
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;
		rec_addblock(&the->m_RecInfo);

		the->m_RecInfo.lfx0 = 16;
		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[1] + 8;
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.lblkx = 16;
		the->m_RecInfo.blk0 = the->macro_block->coeff[5] + 8;
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;
		rec_addblock(&the->m_RecInfo);

	}

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void rec_mb_2frfi(mc_decoder* the)
{
	if( the->m_nStwTop < 2 ){
		rec_mb_2frfi_top(the);
	}
	if( the->m_RecInfo.skip_bottom_field_flag ){
		return;
	}
	if( the->m_nStwBot < 2 ) {
		rec_mb_2frfi_bot(the);
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void rec_mb_2frfi_top(mc_decoder* the)
{
	s32 xint0,xint1,yint0,yint1,fdi,bdi,fdiuv,bdiuv;

	s32 nForwardDstY,nForwardDstX,nBackwardDstY,nBackwardDstX;
	s32 vx0,vy0,vx1,vy1;

#if __MC_ADDALIGN_
	s32 nRear8;
	s32 nForwardLeftAlignBits0;   
	s32 nForwardRightAlignBits0;
	s32 nForwardLeftAlignBitsChroma;   
	s32 nForwardRightAlignBitsChroma;
	b32 bFalign0,bFalign1;

	s32 nBackwardLeftAlignBits0;   
	s32 nBackwardRightAlignBits0;
	s32 nBackwardLeftAlignBitsChroma;   
	s32 nBackwardRightAlignBitsChroma;
	b32 bBalign0,bBalign1;
#endif

	vx0 = the->PMV[0][0][0];
	vy0 = the->PMV[0][0][1];
	vx1 = the->PMV[0][1][0];
	vy1 = the->PMV[0][1][1];

	xint0 = DIV_TRUNC_MIN(vx0,2);
	yint0 = DIV_TRUNC_MIN(vy0,2);

	/* the start address of prediction macroblock*/
	nForwardDstY = ( the->dwMbPosY + (yint0 & ~1)) * the->m_nCodedPicturePitch;
	nForwardDstY += the->motion_vertical_field_select[0][0] ? the->m_nCodedPicturePitch:0;
	nForwardDstX = the->dwMbPosX + xint0;
	fdi = nForwardDstY + nForwardDstX;

	CHECK_VECTOR(fdi)

	xint1 = DIV_TRUNC_MIN(vx1,2);
	yint1 = DIV_TRUNC_MIN(vy1,2);

	nBackwardDstY = (the->dwMbPosY+(yint1&~1))*the->m_nCodedPicturePitch;
	nBackwardDstY += the->motion_vertical_field_select[0][1] ? the->m_nCodedPicturePitch:0;
	nBackwardDstX = the->dwMbPosX + xint1;
	bdi = nBackwardDstY + nBackwardDstX;

	CHECK_VECTOR(bdi)



#if __MC_ADDALIGN_

	nRear8 = nForwardDstX & 7;	
	bFalign0 = nRear8 ? FALSE : TRUE; // 

	if( nRear8 ){  // not align;
	
		nForwardDstX -= nRear8;  // align;
		fdi =  nForwardDstY + nForwardDstX;  // use the aligned address;
		nRear8 <<= 3;
		nForwardLeftAlignBits0 = nRear8;
		nForwardRightAlignBits0 = 64 - nRear8;		
	}

	nRear8 = nBackwardDstX & 7;	
	bBalign0 = nRear8 ? FALSE : TRUE; // 

	if( nRear8 ){  // not align;
	
		nBackwardDstX -= nRear8;  // align;
		bdi =  nBackwardDstY + nBackwardDstX;  // use the aligned address;
		nRear8 <<= 3;
		nBackwardLeftAlignBits0 = nRear8;
		nBackwardRightAlignBits0 = 64 - nRear8;
	}

#else

		the->m_RecInfo.bForwardAlign = TRUE;

#endif

#if __MC_ADDALIGN_
	if( ! (the->m_RecInfo.bForwardAlign = bFalign0) )	{
		the->m_RecInfo.nForwardLeftAlignBits0 = nForwardLeftAlignBits0;
		the->m_RecInfo.nForwardLeftAlignBits1 = nForwardLeftAlignBits0 + 8;
		the->m_RecInfo.nForwardRightAlignBits0 = nForwardRightAlignBits0;
		the->m_RecInfo.nForwardRightAlignBits1 = nForwardRightAlignBits0 - 8;
	}
#endif

	the->m_RecInfo.fxh = HALF_PERL(xint0,vx0);
	the->m_RecInfo.fyh = HALF_PERL(yint0,vy0);
	the->m_RecInfo.lfx0 = 
		the->m_RecInfo.lfx1 = (the->m_nCodedPicturePitch << 1);	 
	the->m_RecInfo.h = 8;
	the->m_RecInfo.w = 16;  /*16 pixels*/
	the->m_RecInfo.forw_mb0 = the->m_lpForwardPicture->lpData[0] + fdi;
	the->m_RecInfo.ldstx = 32;
	the->m_RecInfo.dest_mb0 = the->reccoe->coey;

	rec_2b_1(&the->m_RecInfo);       // forward block;

#if __MC_ADDALIGN_
	// backward align;
	if( ! (the->m_RecInfo.bForwardAlign = bBalign0) )	{
		the->m_RecInfo.nForwardLeftAlignBits0  = nBackwardLeftAlignBits0;
		the->m_RecInfo.nForwardLeftAlignBits1  = nBackwardLeftAlignBits0 + 8;
		the->m_RecInfo.nForwardRightAlignBits0 = nBackwardRightAlignBits0;
		the->m_RecInfo.nForwardRightAlignBits1 = nBackwardRightAlignBits0 - 8;
	}
#endif

	the->m_RecInfo.fxh = HALF_PERL(xint1,vx1);
	the->m_RecInfo.fyh = HALF_PERL(yint1,vy1);
	the->m_RecInfo.lfx0 = 
		the->m_RecInfo.lfx1 = (the->m_nCodedPicturePitch << 1);	 
	the->m_RecInfo.h = 8;
	the->m_RecInfo.w = 16;  /*16 pixels*/
	the->m_RecInfo.forw_mb0 = the->m_lpBackwardPicture->lpData[0] + bdi;
	the->m_RecInfo.ldstx = 32;
	the->m_RecInfo.dest_mb0 = the->reccoe1->coey;

	rec_2b_1(&the->m_RecInfo);       // backward block;

	the->m_RecInfo.forw_mb0 = the->reccoe->coey;
	the->m_RecInfo.back_mb0 = the->reccoe1->coey;
	the->m_RecInfo.lfx0 = 32;
	the->m_RecInfo.h = 8;
	the->m_RecInfo.w = 16;
	rec_avgblock(&the->m_RecInfo);

	if(the->dct_type) 	{	/*field dct*/
		the->m_RecInfo.lfx0 = 32;
		the->m_RecInfo.forw_mb0 = the->reccoe->coey;
		the->m_RecInfo.ldstx = 32;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.lblkx = 8;
		the->m_RecInfo.blk0 = the->macro_block->coeff[0];
		the->m_RecInfo.blk1 = the->macro_block->coeff[1];
		the->m_RecInfo.w = 16; /*16 pixels*/
		the->m_RecInfo.h = 8;
		rec_addblock(&the->m_RecInfo);

	}
	else{ /* frame dct */		
		/* top half macroblock*/
		the->m_RecInfo.lfx0 = 32;
		the->m_RecInfo.forw_mb0 = the->reccoe->coey;
		the->m_RecInfo.ldstx = 32;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.lblkx = 16;
		the->m_RecInfo.blk0 = the->macro_block->coeff[0];
		the->m_RecInfo.blk1 = the->macro_block->coeff[1];
		the->m_RecInfo.w = 16; /*16 pixels*/
		the->m_RecInfo.h = 4;
		rec_addblock(&the->m_RecInfo);	
		/*bottom 4 rows */
		the->m_RecInfo.lfx0 = 32;
		the->m_RecInfo.forw_mb0 = the->reccoe->coey + 16*8;
		the->m_RecInfo.ldstx = 32;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.lblkx = 16;
		the->m_RecInfo.blk0 = the->macro_block->coeff[2];
		the->m_RecInfo.blk1 = the->macro_block->coeff[3];
		the->m_RecInfo.w = 16; /*16 pixels*/
		the->m_RecInfo.h = 4;
		rec_addblock(&the->m_RecInfo);	
	}

	/*chroma*/

	if(CHROMA420 == the->m_nChromaFormat)	{

		/* the start address of prediction macroblock*/
		vx0 = DIV_TRUNC_ZERO(vx0,2);
		vy0 = DIV_TRUNC_ZERO(vy0,2);
		xint0 = DIV_TRUNC_MIN(vx0,2);
		yint0 = DIV_TRUNC_MIN(vy0,2);

		nForwardDstY = ((the->dwMbPosY>>1)+(yint0&~1))*the->m_nChromaPitch;
		nForwardDstY += the->motion_vertical_field_select[0][0] ? the->m_nChromaPitch:0;
		nForwardDstX = (the->dwMbPosX>>1) + xint0;

		fdiuv = nForwardDstY + nForwardDstX;

		vx1 = DIV_TRUNC_ZERO(vx1,2);
		vy1 = DIV_TRUNC_ZERO(vy1,2);
		xint1 = DIV_TRUNC_MIN(vx1,2);
		yint1 = DIV_TRUNC_MIN(vy1,2);

		nBackwardDstY = ((the->dwMbPosY>>1)+(yint1&~1))*the->m_nChromaPitch;
		nBackwardDstY += the->motion_vertical_field_select[0][1] ? the->m_nChromaPitch:0;
		nBackwardDstX = (the->dwMbPosX>>1) + xint1; 

		bdiuv = nBackwardDstY + nBackwardDstX;

#if __MC_ADDALIGN_

		nRear8 = nForwardDstX & 7;	
		bFalign1 = nRear8 ? FALSE : TRUE; // 

		if( nRear8 ){  // not align;
		
			nForwardDstX -= nRear8;  // align;
			fdiuv =  nForwardDstY + nForwardDstX;  // use the aligned address;
			nRear8 <<= 3;
			nForwardLeftAlignBitsChroma = nRear8;
			nForwardRightAlignBitsChroma = 64 - nRear8;
		}

		if( ! (the->m_RecInfo.bForwardAlign = bFalign1 ))	{
			the->m_RecInfo.nForwardLeftAlignBits0 = nForwardLeftAlignBitsChroma;
			the->m_RecInfo.nForwardLeftAlignBits1 = nForwardLeftAlignBitsChroma + 8;
			the->m_RecInfo.nForwardRightAlignBits0 = nForwardRightAlignBitsChroma;
			the->m_RecInfo.nForwardRightAlignBits1 = nForwardRightAlignBitsChroma - 8;
		}
#else
		the->m_RecInfo.bForwardAlign = TRUE;
#endif


		the->m_RecInfo.fxh = HALF_PERL(xint0,vx0);
		the->m_RecInfo.fyh = HALF_PERL(yint0,vy0);
		the->m_RecInfo.lfx0 = 
			the->m_RecInfo.lfx1 = (the->m_nChromaPitch << 1);
		the->m_RecInfo.w = 8;/* 8 pixels each block*/
		the->m_RecInfo.h = 4;
		the->m_RecInfo.forw_mb0 = the->m_lpForwardPicture->lpData[1] + fdiuv;
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->reccoe->coeuv[0];

		rec_2b_1(&the->m_RecInfo);       // forward block u;

		the->m_RecInfo.w = 8;/* 8 pixels each block*/
		the->m_RecInfo.h = 4;
		the->m_RecInfo.forw_mb0 = the->m_lpForwardPicture->lpData[2] + fdiuv;
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->reccoe->coeuv[1];

		rec_2b_1(&the->m_RecInfo);       // forward block v;

#if __MC_ADDALIGN_
		nRear8 = nBackwardDstX & 7;	
		bBalign1 = nRear8 ? FALSE : TRUE; // 

		if( nRear8 ){  // not align;
		
			nBackwardDstX -= nRear8;  // align;
			bdiuv =  nBackwardDstY + nBackwardDstX;  // use the aligned address;
			nRear8 <<= 3;
			nBackwardLeftAlignBitsChroma = nRear8;
			nBackwardRightAlignBitsChroma = 64 - nRear8;
		}

		if( ! (the->m_RecInfo.bForwardAlign = bBalign1) )	{
			the->m_RecInfo.nForwardLeftAlignBits0  = nBackwardLeftAlignBitsChroma;
			the->m_RecInfo.nForwardLeftAlignBits1  = nBackwardLeftAlignBitsChroma + 8;
			the->m_RecInfo.nForwardRightAlignBits0 = nBackwardRightAlignBitsChroma;
			the->m_RecInfo.nForwardRightAlignBits1 = nBackwardRightAlignBitsChroma - 8;
		}
#endif

		the->m_RecInfo.fxh = HALF_PERL(xint1,vx1);
		the->m_RecInfo.fyh = HALF_PERL(yint1,vy1);
		/*stride*/
		the->m_RecInfo.lfx0 = the->m_RecInfo.lfx1 = (the->m_nChromaPitch << 1);
		the->m_RecInfo.w = 8;/* 8 pixels each block*/
		the->m_RecInfo.h = 4;
		the->m_RecInfo.forw_mb0 = the->m_lpBackwardPicture->lpData[1] + bdiuv;
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->reccoe1->coeuv[0];

		rec_2b_1(&the->m_RecInfo);       // backward block u;

		the->m_RecInfo.w = 8;/* 8 pixels each block*/
		the->m_RecInfo.h = 4;
		the->m_RecInfo.forw_mb0 = the->m_lpBackwardPicture->lpData[2] + bdiuv;
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->reccoe1->coeuv[1];

		rec_2b_1(&the->m_RecInfo);       // backward block v;

		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[0];
		the->m_RecInfo.back_mb0 = the->reccoe1->coeuv[0];
		the->m_RecInfo.lfx0 = 16;
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;
		rec_avgblock(&the->m_RecInfo);

		the->m_RecInfo.lfx0 = 16;
		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[0];
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.lblkx = 16;
		the->m_RecInfo.blk0 = the->macro_block->coeff[4];
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;
		rec_addblock(&the->m_RecInfo);

		the->m_RecInfo.lfx0 = 16;
		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[1];
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.lblkx = 16;
		the->m_RecInfo.blk0 = the->macro_block->coeff[5];
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;
		rec_addblock(&the->m_RecInfo);
	}

}
//}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void rec_mb_2frfi_bot(mc_decoder* the)
{
	s32 xint0,xint1,yint0,yint1,fdi,bdi,fdiuv,bdiuv;

	s32 nForwardDstY,nForwardDstX,nBackwardDstY,nBackwardDstX;
	s32 vx0,vy0,vx1,vy1;

#if __MC_ADDALIGN_
	s32 nRear8;
	s32 nForwardLeftAlignBits0;   
	s32 nForwardRightAlignBits0;
	s32 nForwardRightAlignBitsChroma;
	s32 nForwardLeftAlignBitsChroma;   
	b32 bFalign0,bFalign1;

	s32 nBackwardLeftAlignBits0;   
	s32 nBackwardRightAlignBits0;
	s32 nBackwardLeftAlignBitsChroma;   
	s32 nBackwardRightAlignBitsChroma;
	b32 bBalign0,bBalign1;
#endif

	vx0 = the->PMV[1][0][0];
	vy0 = the->PMV[1][0][1];
	vx1 = the->PMV[1][1][0];
	vy1 = the->PMV[1][1][1];

	xint0 = DIV_TRUNC_MIN(vx0,2);
	yint0 = DIV_TRUNC_MIN(vy0,2);
	/*bottom field*/

	/* the start address of prediction macroblock*/

	nForwardDstY = (the->dwMbPosY+(yint0&~1))*the->m_nCodedPicturePitch;
	nForwardDstY += the->motion_vertical_field_select[1][0] ? the->m_nCodedPicturePitch:0;
	nForwardDstX = the->dwMbPosX + xint0;
	fdi = nForwardDstY + nForwardDstX;
	CHECK_VECTOR(fdi)

	/* the start address of prediction macroblock*/
	xint1 = DIV_TRUNC_MIN(vx1,2);
	yint1 = DIV_TRUNC_MIN(vy1,2);

	nBackwardDstY = (the->dwMbPosY+(yint1&~1))*the->m_nCodedPicturePitch;
	nBackwardDstY += the->motion_vertical_field_select[1][1] ? the->m_nCodedPicturePitch:0;
	nBackwardDstX = the->dwMbPosX + xint1;
	bdi = nBackwardDstY + nBackwardDstX;
	CHECK_VECTOR(bdi)

#if __MC_ADDALIGN_

	nRear8 = nForwardDstX & 7;	
	bFalign0 = nRear8 ? FALSE : TRUE; // 

	if( nRear8 ){  // not align;
	
		nForwardDstX -= nRear8;  // align;
		nRear8 <<= 3;
		nForwardLeftAlignBits0 = nRear8;
		nForwardRightAlignBits0 = 64 - nRear8;
		fdi =  nForwardDstY + nForwardDstX;  // use the aligned address;
	}

	nRear8 = nBackwardDstX & 7;	
	bBalign0 = nRear8 ? FALSE : TRUE; // 
	if( nRear8 ){  // not align;
	
		nBackwardDstX -= nRear8;  // align;
		nRear8 <<= 3;
		nBackwardLeftAlignBits0 = nRear8;
		nBackwardRightAlignBits0 = 64 - nRear8;
		bdi =  nBackwardDstY + nBackwardDstX;  // use the aligned address;
	}

	if( ! (the->m_RecInfo.bForwardAlign = bFalign0) )	{
		the->m_RecInfo.nForwardLeftAlignBits0 = nForwardLeftAlignBits0;
		the->m_RecInfo.nForwardLeftAlignBits1 = nForwardLeftAlignBits0 + 8;
		the->m_RecInfo.nForwardRightAlignBits0 = nForwardRightAlignBits0;
		the->m_RecInfo.nForwardRightAlignBits1 = nForwardRightAlignBits0 - 8;
	}
#else
	the->m_RecInfo.bForwardAlign = TRUE;
#endif

	the->m_RecInfo.fxh = HALF_PERL(xint0,vx0);
	the->m_RecInfo.fyh = HALF_PERL(yint0,vy0);
	the->m_RecInfo.lfx0 = 
		the->m_RecInfo.lfx1 = (the->m_nCodedPicturePitch << 1);
	the->m_RecInfo.h = 8;
	the->m_RecInfo.w = 16;  /*16 pixels*/
	the->m_RecInfo.forw_mb0 = the->m_lpForwardPicture->lpData[0] + fdi;
	the->m_RecInfo.ldstx = 32;
	the->m_RecInfo.dest_mb0 = the->reccoe->coey + 16;

	rec_2b_1(&the->m_RecInfo);       // forward block;

#if __MC_ADDALIGN_
	// backward align;
	if( ! (the->m_RecInfo.bForwardAlign = bBalign0) ){
	
		the->m_RecInfo.nForwardLeftAlignBits0  = nBackwardLeftAlignBits0;
		the->m_RecInfo.nForwardLeftAlignBits1  = nBackwardLeftAlignBits0 + 8;
		the->m_RecInfo.nForwardRightAlignBits0 = nBackwardRightAlignBits0;
		the->m_RecInfo.nForwardRightAlignBits1 = nBackwardRightAlignBits0 - 8;
	}
#endif

	the->m_RecInfo.fxh = HALF_PERL(xint1,vx1);
	the->m_RecInfo.fyh = HALF_PERL(yint1,vy1);
	the->m_RecInfo.lfx0 = 
		the->m_RecInfo.lfx1 = (the->m_nCodedPicturePitch << 1);
	the->m_RecInfo.h = 8;
	the->m_RecInfo.w = 16;  /*16 pixels*/
	the->m_RecInfo.forw_mb0 = the->m_lpBackwardPicture->lpData[0] + bdi ;
	the->m_RecInfo.ldstx = 32;
	the->m_RecInfo.dest_mb0 = the->reccoe1->coey + 16;
	rec_2b_1(&the->m_RecInfo);       // backward block;

	the->m_RecInfo.forw_mb0 = the->reccoe->coey + 16;
	the->m_RecInfo.back_mb0 = the->reccoe1->coey + 16;
	the->m_RecInfo.lfx0 = 32;
	the->m_RecInfo.h = 8;
	the->m_RecInfo.w = 16;
	rec_avgblock(&the->m_RecInfo);

	if(the->dct_type) {	/*field dct*/
		the->m_RecInfo.lfx0 = 32;
		the->m_RecInfo.forw_mb0 = the->reccoe->coey + 16;
		the->m_RecInfo.ldstx = 32;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.lblkx = 8;
		the->m_RecInfo.blk0 = the->macro_block->coeff[2];
		the->m_RecInfo.blk1 = the->macro_block->coeff[3];
		the->m_RecInfo.w = 16; /*16 pixels*/
		the->m_RecInfo.h = 8;
		rec_addblock(&the->m_RecInfo);
	}
	else{ /* frame dct */		
	
		/*top half*/
		the->m_RecInfo.lfx0 = 32;
		the->m_RecInfo.forw_mb0 = the->reccoe->coey + 16;
		the->m_RecInfo.ldstx = 32;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.lblkx = 16;
		the->m_RecInfo.blk0 = the->macro_block->coeff[0] + 8;
		the->m_RecInfo.blk1 = the->macro_block->coeff[1] + 8;
		the->m_RecInfo.w = 16; /*16 pixels*/
		the->m_RecInfo.h = 4;
		rec_addblock(&the->m_RecInfo);	

		the->m_RecInfo.lfx0 = 32;
		the->m_RecInfo.forw_mb0 = the->reccoe->coey + 16*8 + 16;
		the->m_RecInfo.ldstx = 32;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.lblkx = 16;
		the->m_RecInfo.blk0 = the->macro_block->coeff[2] + 8;
		the->m_RecInfo.blk1 = the->macro_block->coeff[3] + 8;
		the->m_RecInfo.w = 16; /*16 pixels*/
		the->m_RecInfo.h = 4;
		rec_addblock(&the->m_RecInfo);	
	}

	/*chroma*/
	if( CHROMA420 == the->m_nChromaFormat )	{

		/* the start address of prediction macroblock*/
		vx0 = DIV_TRUNC_ZERO(vx0,2);
		vy0 = DIV_TRUNC_ZERO(vy0,2);
		xint0 = DIV_TRUNC_MIN(vx0,2);
		yint0 = DIV_TRUNC_MIN(vy0,2);

		nForwardDstY = ((the->dwMbPosY>>1)+(yint0&~1))*the->m_nChromaPitch;
		nForwardDstY += the->motion_vertical_field_select[1][0] ? the->m_nChromaPitch:0;
		nForwardDstX =  (the->dwMbPosX>>1) + xint0;
		fdiuv = nForwardDstY + nForwardDstX;

		vx1 = DIV_TRUNC_ZERO(vx1,2);
		vy1 = DIV_TRUNC_ZERO(vy1,2);
		xint1 = DIV_TRUNC_MIN(vx1,2);
		yint1 = DIV_TRUNC_MIN(vy1,2);

		nBackwardDstY =  ((the->dwMbPosY>>1)+(yint1&~1))*the->m_nChromaPitch;
		nBackwardDstY += the->motion_vertical_field_select[1][1] ? the->m_nChromaPitch:0;
		nBackwardDstX = (the->dwMbPosX>>1) + xint1;
		bdiuv = nBackwardDstY + nBackwardDstX;

#if __MC_ADDALIGN_

		nRear8 = nForwardDstX & 7;	
		bFalign1 = nRear8 ? FALSE : TRUE; // 
		if( nRear8 ){  // not align;
		
			nForwardDstX -= nRear8;  // align;
			nRear8 <<= 3;
			nForwardLeftAlignBitsChroma = nRear8;
			nForwardRightAlignBitsChroma = 64 - nRear8;
			fdiuv =  nForwardDstY + nForwardDstX;  // use the aligned address;
		}


		if( ! (the->m_RecInfo.bForwardAlign = bFalign1) )	{
			the->m_RecInfo.nForwardLeftAlignBits0 = nForwardLeftAlignBitsChroma;
			the->m_RecInfo.nForwardLeftAlignBits1 = nForwardLeftAlignBitsChroma + 8;
			the->m_RecInfo.nForwardRightAlignBits0 = nForwardRightAlignBitsChroma;
			the->m_RecInfo.nForwardRightAlignBits1 = nForwardRightAlignBitsChroma - 8;
		}
#endif

		the->m_RecInfo.fxh = HALF_PERL(xint0,vx0);
		the->m_RecInfo.fyh = HALF_PERL(yint0,vy0);
		the->m_RecInfo.lfx0 =  (the->m_nChromaPitch << 1);
		the->m_RecInfo.lfx1 =  (the->m_nChromaPitch << 1);
		the->m_RecInfo.w = 8;/* 8 pixels each block*/
		the->m_RecInfo.h = 4;
		the->m_RecInfo.forw_mb0 = the->m_lpForwardPicture->lpData[1] + fdiuv;
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->reccoe->coeuv[0] + 8;
		rec_2b_1(&the->m_RecInfo);       // forward block u;

		the->m_RecInfo.w = 8;/* 8 pixels each block*/
		the->m_RecInfo.h = 4;
		the->m_RecInfo.forw_mb0 = the->m_lpForwardPicture->lpData[2] + fdiuv;
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->reccoe->coeuv[1] + 8;

		rec_2b_1(&the->m_RecInfo);       // forward block v;

#if __MC_ADDALIGN_

		nRear8 = nBackwardDstX & 7;	
		bBalign1 = nRear8 ? FALSE : TRUE; // 

		if( nRear8 ){  // not align;
		
			nBackwardDstX -= nRear8;  // align;
			nRear8 <<= 3;
			nBackwardLeftAlignBitsChroma = nRear8;
			nBackwardRightAlignBitsChroma = 64 - nRear8;
			bdiuv =  nBackwardDstY + nBackwardDstX;  // use the aligned address;
		}

		if( ! (the->m_RecInfo.bForwardAlign = bBalign1 ))		{
			the->m_RecInfo.nForwardLeftAlignBits0  = nBackwardLeftAlignBitsChroma;
			the->m_RecInfo.nForwardLeftAlignBits1  = nBackwardLeftAlignBitsChroma + 8;
			the->m_RecInfo.nForwardRightAlignBits0 = nBackwardRightAlignBitsChroma;
			the->m_RecInfo.nForwardRightAlignBits1 = nBackwardRightAlignBitsChroma - 8;
		}
#endif

		the->m_RecInfo.fxh = HALF_PERL(xint1,vx1);
		the->m_RecInfo.fyh = HALF_PERL(yint1,vy1);
		the->m_RecInfo.lfx0 =  (the->m_nChromaPitch << 1);
		the->m_RecInfo.lfx1 =  (the->m_nChromaPitch << 1);
		the->m_RecInfo.w = 8;/* 8 pixels each block*/
		the->m_RecInfo.h = 4;
		the->m_RecInfo.forw_mb0 = the->m_lpBackwardPicture->lpData[1] + bdiuv;
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->reccoe1->coeuv[0] + 8;

		rec_2b_1(&the->m_RecInfo);       // backward block u;

		the->m_RecInfo.w = 8;/* 8 pixels each block*/
		the->m_RecInfo.h = 4;
		the->m_RecInfo.forw_mb0 = the->m_lpBackwardPicture->lpData[2] + bdiuv;
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->reccoe1->coeuv[1] + 8;

		rec_2b_1(&the->m_RecInfo);       // backward block v;

		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[0] + 8;
		the->m_RecInfo.back_mb0 = the->reccoe1->coeuv[0] + 8;
		the->m_RecInfo.lfx0 = 16;
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;
		rec_avgblock(&the->m_RecInfo);

		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[1] + 8;
		the->m_RecInfo.back_mb0 = the->reccoe1->coeuv[1] + 8;
		the->m_RecInfo.lfx0 = 16;
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;
		rec_avgblock(&the->m_RecInfo);

		the->m_RecInfo.lfx0 = 16;
		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[0] + 8;
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.lblkx = 16;
		the->m_RecInfo.blk0 = the->macro_block->coeff[4] + 8;
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;
		rec_addblock(&the->m_RecInfo);

		the->m_RecInfo.lfx0 = 16;
		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[1] + 8;
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.lblkx = 16;
		the->m_RecInfo.blk0 = the->macro_block->coeff[5] + 8;
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;
		rec_addblock(&the->m_RecInfo);
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void rec_mb_2fifi(mc_decoder* the)
{
	s32 xint0,xint1,yint0,yint1,fdi,bdi,fdiuv,bdiuv;

	s32 nForwardDstY,nForwardDstX,nBackwardDstY,nBackwardDstX;
	s32 vx0,vy0,vx1,vy1;

#if __MC_ADDALIGN_

	s32 nRear8;
	s32 nForwardLeftAlignBits0;   
	s32 nForwardRightAlignBits0;
	s32 nForwardRightAlignBitsChroma;
	s32 nForwardLeftAlignBitsChroma;   
	b32	bFalign0,bFalign1;

	s32 nBackwardLeftAlignBits0;   
	s32 nBackwardRightAlignBits0;
	s32 nBackwardLeftAlignBitsChroma;   
	s32 nBackwardRightAlignBitsChroma;
	b32 bBalign0,bBalign1;

#endif

	vx0 = the->PMV[0][0][0];
	vy0 = the->PMV[0][0][1];
	vx1 = the->PMV[0][1][0];
	vy1 = the->PMV[0][1][1];

	xint0 = DIV_TRUNC_MIN(vx0,2);
	yint0 = DIV_TRUNC_MIN(vy0,2);

	/*start address*/

	nForwardDstY = (the->dwMbPosY+yint0)*(the->m_nCodedPicturePitch << 1);
	nForwardDstY += the->motion_vertical_field_select[0][0] ? the->m_nCodedPicturePitch : 0;
	nForwardDstX = the->dwMbPosX + xint0;
	fdi = nForwardDstY + nForwardDstX;

	CHECK_VECTOR(fdi)

	xint1 = DIV_TRUNC_MIN(vx1,2);
	yint1 = DIV_TRUNC_MIN(vy1,2);

	nBackwardDstY =  (the->dwMbPosY+yint1)*(the->m_nCodedPicturePitch << 1);
	nBackwardDstY += the->motion_vertical_field_select[0][1] ? the->m_nCodedPicturePitch : 0;
	nBackwardDstX = the->dwMbPosX + xint1;
	bdi = nBackwardDstY + nBackwardDstX;

	CHECK_VECTOR(bdi)

#if __MC_ADDALIGN_

	nRear8 = nForwardDstX & 7;	
	bFalign0 = nRear8 ? FALSE : TRUE; // 

	if( nRear8 ){  // not align;
	
		nForwardDstX -= nRear8;  // align;
		nRear8 <<= 3;
		nForwardLeftAlignBits0 = nRear8;
		nForwardRightAlignBits0 = 64 - nRear8;
		fdi =  nForwardDstY + nForwardDstX;  // use the aligned address;
	}


	nRear8 = nBackwardDstX & 7;	
	bBalign0 = nRear8 ? FALSE : TRUE; // 

	if( nRear8 ){  // not align;
	
		nBackwardDstX -= nRear8;  // align;
		nRear8 <<= 3;
		nBackwardLeftAlignBits0 = nRear8;
		nBackwardRightAlignBits0 = 64 - nRear8;
		bdi =  nBackwardDstY + nBackwardDstX;  // use the aligned address;
	}

#else
	the->m_RecInfo.bForwardAlign = TRUE;
#endif

#if __MC_ADDALIGN_
	if( ! (the->m_RecInfo.bForwardAlign = bFalign0) ){
	
		the->m_RecInfo.nForwardLeftAlignBits0 = nForwardLeftAlignBits0;
		the->m_RecInfo.nForwardLeftAlignBits1 = nForwardLeftAlignBits0 + 8;
		the->m_RecInfo.nForwardRightAlignBits0 = nForwardRightAlignBits0;
		the->m_RecInfo.nForwardRightAlignBits1 = nForwardRightAlignBits0 - 8;
	}
#endif

	the->m_RecInfo.fxh = HALF_PERL(xint0,vx0);
	the->m_RecInfo.fyh = HALF_PERL(yint0,vy0);
	the->m_RecInfo.lfx0 =	the->m_RecInfo.lfx1 =  (the->m_nCodedPicturePitch << 1);
	the->m_RecInfo.h = 16;
	the->m_RecInfo.w = 16;  /*16 pixels*/
	the->m_RecInfo.forw_mb0 = the->m_lpForwardPicture->lpData[0] + fdi;
	the->m_RecInfo.ldstx = 16;
	the->m_RecInfo.dest_mb0 = the->reccoe->coey;

	rec_2b_1(&the->m_RecInfo);       // forward block;


#if __MC_ADDALIGN_
	// backward align;
	if( ! (the->m_RecInfo.bForwardAlign = bBalign0 )){
	
		the->m_RecInfo.nForwardLeftAlignBits0  = nBackwardLeftAlignBits0;
		the->m_RecInfo.nForwardLeftAlignBits1  = nBackwardLeftAlignBits0 + 8;
		the->m_RecInfo.nForwardRightAlignBits0 = nBackwardRightAlignBits0;
		the->m_RecInfo.nForwardRightAlignBits1 = nBackwardRightAlignBits0 - 8;
	}
#endif

	the->m_RecInfo.fxh = HALF_PERL(xint1,vx1);
	the->m_RecInfo.fyh = HALF_PERL(yint1,vy1);
	the->m_RecInfo.lfx0 =	the->m_RecInfo.lfx1 =  (the->m_nCodedPicturePitch << 1);
	the->m_RecInfo.h = 16;
	the->m_RecInfo.w = 16;  /*16 pixels*/
	the->m_RecInfo.forw_mb0 = the->m_lpBackwardPicture->lpData[0] + bdi;
	the->m_RecInfo.ldstx = 16;
	the->m_RecInfo.dest_mb0 = the->reccoe1->coey;

	rec_2b_1(&the->m_RecInfo);       // backward block;

	the->m_RecInfo.forw_mb0 = the->reccoe->coey;
	the->m_RecInfo.back_mb0 = the->reccoe1->coey;
	the->m_RecInfo.lfx0 = 16;
	the->m_RecInfo.h = 16;
	the->m_RecInfo.w = 16;
	rec_avgblock(&the->m_RecInfo);

	/*top 8 rows */
	the->m_RecInfo.lfx0 = 16;
	the->m_RecInfo.forw_mb0 = the->reccoe->coey;
	the->m_RecInfo.ldstx = 16;
	the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
	the->m_RecInfo.lblkx = 16;
	the->m_RecInfo.blk0 = the->macro_block->coeff[0];
	the->m_RecInfo.blk1 = the->macro_block->coeff[1];
	the->m_RecInfo.w = 16; /*16 pixels*/
	the->m_RecInfo.h = 8;
	rec_addblock(&the->m_RecInfo);	
	/*bottom 8 rows */
	the->m_RecInfo.lfx0 = 16;
	the->m_RecInfo.forw_mb0 = the->reccoe->coey + 16*8;
	the->m_RecInfo.ldstx = 16;
	the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
	the->m_RecInfo.lblkx = 16;
	the->m_RecInfo.blk0 = the->macro_block->coeff[2];
	the->m_RecInfo.blk1 = the->macro_block->coeff[3];
	the->m_RecInfo.w = 16; /*16 pixels*/
	the->m_RecInfo.h = 8;
	rec_addblock(&the->m_RecInfo);	


	/*chroma*/
	if(CHROMA420 == the->m_nChromaFormat)	{

		vx0 = DIV_TRUNC_ZERO(vx0,2);
		vy0 = DIV_TRUNC_ZERO(vy0,2);

		xint0 = DIV_TRUNC_MIN(vx0,2);
		yint0 = DIV_TRUNC_MIN(vy0,2);

		nForwardDstY =  ((the->dwMbPosY>>1)+yint0)*(the->m_nChromaPitch << 1);
		nForwardDstY += the->motion_vertical_field_select[0][0] ? the->m_nChromaPitch:0;
		nForwardDstX = (the->dwMbPosX>>1) + xint0;
		fdiuv = nForwardDstY + nForwardDstX;

		vx1 = DIV_TRUNC_ZERO(vx1,2);
		vy1 = DIV_TRUNC_ZERO(vy1,2);

		xint1 = DIV_TRUNC_MIN(vx1,2);
		yint1 = DIV_TRUNC_MIN(vy1,2);

		nBackwardDstY = ((the->dwMbPosY>>1)+yint1)*(the->m_nChromaPitch << 1);
		nBackwardDstY += the->motion_vertical_field_select[0][1] ? the->m_nChromaPitch : 0;
		nBackwardDstX = (the->dwMbPosX>>1) + xint1; 
		bdiuv = nBackwardDstY + nBackwardDstX;


#if __MC_ADDALIGN_

		nRear8 = nForwardDstX & 7;	
		bFalign1 = nRear8 ? FALSE : TRUE; // 

		if( nRear8 )  {
			// not align;
			nForwardDstX -= nRear8;  // align;
			nRear8 <<= 3;
			nForwardLeftAlignBitsChroma = nRear8;
			nForwardRightAlignBitsChroma = 64 - nRear8;

			fdiuv =  nForwardDstY + nForwardDstX;  // use the aligned address;
		}


		if( ! (the->m_RecInfo.bForwardAlign = bFalign1 ) )	{
			the->m_RecInfo.nForwardLeftAlignBits0 = nForwardLeftAlignBitsChroma;
			the->m_RecInfo.nForwardLeftAlignBits1 = nForwardLeftAlignBitsChroma + 8;
			the->m_RecInfo.nForwardRightAlignBits0 = nForwardRightAlignBitsChroma;
			the->m_RecInfo.nForwardRightAlignBits1 = nForwardRightAlignBitsChroma - 8;
		}
#endif

		the->m_RecInfo.fxh = HALF_PERL(xint0,vx0);
		the->m_RecInfo.fyh = HALF_PERL(yint0,vy0);

		the->m_RecInfo.lfx0 = the->m_RecInfo.lfx1 = (the->m_nChromaPitch << 1);
		the->m_RecInfo.w = 8;/* 8 pixels each block*/
		the->m_RecInfo.h = 8;
		the->m_RecInfo.forw_mb0 = the->m_lpForwardPicture->lpData[1] + fdiuv;
		the->m_RecInfo.ldstx = 8;
		the->m_RecInfo.dest_mb0 = the->reccoe->coeuv[0];

		rec_2b_1(&the->m_RecInfo);       // forward block u;

		the->m_RecInfo.w = 8;/* 8 pixels each block*/
		the->m_RecInfo.h = 8;
		the->m_RecInfo.forw_mb0 = the->m_lpForwardPicture->lpData[2] + fdiuv;
		the->m_RecInfo.ldstx = 8;
		the->m_RecInfo.dest_mb0 = the->reccoe->coeuv[1];

		rec_2b_1(&the->m_RecInfo);       // forward block v;


#if __MC_ADDALIGN_
		nRear8 = nBackwardDstX & 7;	
		bBalign1 = nRear8 ? FALSE : TRUE; // 

		if( nRear8 )  {
			// not align;
			nBackwardDstX -= nRear8;  // align;
			nRear8 <<= 3;
			nBackwardLeftAlignBitsChroma = nRear8;
			nBackwardRightAlignBitsChroma = 64 - nRear8;
			bdiuv =  nBackwardDstY + nBackwardDstX;  // use the aligned address;
		}

		if( ! (the->m_RecInfo.bForwardAlign = bBalign1) ){
		
			the->m_RecInfo.nForwardLeftAlignBits0  = nBackwardLeftAlignBitsChroma;
			the->m_RecInfo.nForwardLeftAlignBits1  = nBackwardLeftAlignBitsChroma + 8;
			the->m_RecInfo.nForwardRightAlignBits0 = nBackwardRightAlignBitsChroma;
			the->m_RecInfo.nForwardRightAlignBits1 = nBackwardRightAlignBitsChroma - 8;
		}
#endif

		the->m_RecInfo.fxh = HALF_PERL(xint1,vx1);
		the->m_RecInfo.fyh = HALF_PERL(yint1,vy1);
		the->m_RecInfo.lfx0 = the->m_RecInfo.lfx1 =	(the->m_nChromaPitch << 1);
		the->m_RecInfo.w = 8;/* 8 pixels each block*/
		the->m_RecInfo.h = 8;
		the->m_RecInfo.forw_mb0 = the->m_lpBackwardPicture->lpData[1] + bdiuv;
		the->m_RecInfo.ldstx = 8;
		the->m_RecInfo.dest_mb0 = the->reccoe1->coeuv[0];

		rec_2b_1(&the->m_RecInfo);       // backward block u;


		the->m_RecInfo.w = 8;/* 8 pixels each block*/
		the->m_RecInfo.h = 8;
		the->m_RecInfo.forw_mb0 = the->m_lpBackwardPicture->lpData[2] + bdiuv;
		the->m_RecInfo.ldstx = 8;
		the->m_RecInfo.dest_mb0 = the->reccoe1->coeuv[1];

		rec_2b_1(&the->m_RecInfo);       // backward block v;

		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[0];
		the->m_RecInfo.back_mb0 = the->reccoe1->coeuv[0];
		the->m_RecInfo.lfx0 = 8;
		the->m_RecInfo.h = 8;
		the->m_RecInfo.w = 8;
		rec_avgblock(&the->m_RecInfo);

		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[1];
		the->m_RecInfo.back_mb0 = the->reccoe1->coeuv[1];
		the->m_RecInfo.lfx0 = 8;
		the->m_RecInfo.h = 8;
		the->m_RecInfo.w = 8;
		rec_avgblock(&the->m_RecInfo);

		the->m_RecInfo.lfx0 = 8;
		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[0];
		the->m_RecInfo.ldstx = 8;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.lblkx = 8;
		the->m_RecInfo.blk0 = the->macro_block->coeff[4];
		the->m_RecInfo.h = 8;
		the->m_RecInfo.w = 8;
		rec_addblock(&the->m_RecInfo);

		the->m_RecInfo.lfx0 = 8;
		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[1];
		the->m_RecInfo.ldstx = 8;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.lblkx = 8;
		the->m_RecInfo.blk0 = the->macro_block->coeff[5];
		the->m_RecInfo.h = 8;
		the->m_RecInfo.w = 8;
		rec_addblock(&the->m_RecInfo);
	}
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
ISO/IEC 13818-2 section 7.6.3.6: Dual prime additional arithmetic
***************************************************************************/
void Dual_Prime_Arithmetic
(
	mc_decoder* the,
	s32			DMV[][2], 
	s32*		dmvector, 
	s32			mvx, 
	s32			mvy
)
{
#if 0
	if (the->nPictureStructure == FRAME_PICTURE)	{

		if (the->bTopFieldFirst)		{
			/* vector for prediction of top field from bottom field */
			DMV[0][0] = ((mvx  +(mvx>0))>>1) + dmvector[0];
			DMV[0][1] = ((mvy  +(mvy>0))>>1) + dmvector[1] - 1;

			/* vector for prediction of bottom field from top field */
			DMV[1][0] = (( mvx*2+mvx + (mvx>0) ) >>1 ) + dmvector[0];
			DMV[1][1] = (( mvy*2+mvy + (mvy>0) ) >>1 ) + dmvector[1] + 1;
		}
		else{
			/* vector for prediction of top field from bottom field */
			DMV[0][0] = ((mvx*2+mvx+(mvx>0))>>1) + dmvector[0];
			DMV[0][1] = ((mvy*2+mvy+(mvy>0))>>1) + dmvector[1] - 1;

			/* vector for prediction of bottom field from top field */
			DMV[1][0] = ((mvx  +(mvx>0))>>1) + dmvector[0];
			DMV[1][1] = ((mvy  +(mvy>0))>>1) + dmvector[1] + 1;
		}
	}
	else{
		/* vector for prediction from field of opposite 'parity' */
		DMV[0][0] = ((mvx+(mvx>0))>>1) + dmvector[0];
		DMV[0][1] = ((mvy+(mvy>0))>>1) + dmvector[1];

		/* correct for vertical field shift */
		DMV[0][1] += the->nPictureStructure == TOP_FIELD ? -1 : 1;
	}
#else

	s32 t;

	if (the->nPictureStructure == FRAME_PICTURE)	{

		if (the->bTopFieldFirst)		{
			/* vector for prediction of top field from bottom field */
			t = mvx;
			DMV[0][0] = DIV_ROUND_NEAR(t,2) + dmvector[0];
			t = mvy;
			DMV[0][1] = DIV_ROUND_NEAR(t,2) + dmvector[1] - 1;

			/* vector for prediction of bottom field from top field */
			t = mvx*2+mvx;
			DMV[1][0] = DIV_ROUND_NEAR(t,2) + dmvector[0];
			t = mvy*2+mvy;
			DMV[1][1] = DIV_ROUND_NEAR(t,2)  + dmvector[1] + 1;
		}
		else{
			/* vector for prediction of top field from bottom field */
			t = mvx*2+mvx;
			DMV[0][0] = DIV_ROUND_NEAR(t,2) + dmvector[0];
			t = mvy*2+mvy;
			DMV[0][1] = DIV_ROUND_NEAR(t,2) + dmvector[1] - 1;

			/* vector for prediction of bottom field from top field */
			t = mvx;
			DMV[1][0] = DIV_ROUND_NEAR(t,2) + dmvector[0];
			t = mvy;
			DMV[1][1] = DIV_ROUND_NEAR(t,2) + dmvector[1] + 1;
		}
	}
	else{
		/* vector for prediction from field of opposite 'parity' */
		t = mvx;
		DMV[0][0] = DIV_ROUND_NEAR(t,2) + dmvector[0];
		t = mvy;
		DMV[0][1] = DIV_ROUND_NEAR(t,2) + dmvector[1];

		/* correct for vertical field shift */
		DMV[0][1] += the->nPictureStructure == TOP_FIELD ? -1 : 1;
	}
#endif
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void rec_mb_frame_dmv(mc_decoder* the)
{
	/* calculate derived motion vectors */
	Dual_Prime_Arithmetic(the,the->DMV,the->dmvector,
		the->PMV[0][0][0],the->PMV[0][0][1]);

	if ( the->m_nStwTop < 2 )  {
		rec_mb_frame_dmv_top(the);
	}

	if( the->m_RecInfo.skip_bottom_field_flag ){
		return;
	}

	if ( the->m_nStwBot < 2 )  {
		rec_mb_frame_dmv_bot(the);
	}

}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void rec_mb_frame_dmv_top(mc_decoder* the)
{
	s32 vx,vy,vs,vd;
	u8 *refy,*refv,*refu;
	s32 xint,yint,fdit;

	s32 nDstX;
	s32 nDstY;

#if __MC_ADDALIGN_
	s32 nRear8;
	s32 nForwardLeftAlignBits0;   
	s32 nForwardRightAlignBits0;
	s32 nForwardRightAlignBitsChroma;
	s32 nForwardLeftAlignBitsChroma;   
	b32 bFalign0,bFalign1;
#endif

	/* predict top field from top field */
	//          form_prediction(forward_reference_frame,0,current_frame,0,
	//            Coded_Picture_Width<<1,Coded_Picture_Width<<1,16,8,bx,by>>1,
	//            PMV[0][0][0],PMV[0][0][1]>>1,0);

	vx = the->PMV[0][0][0];
	vy = the->PMV[0][0][1];

	vs = 0;
	vd = 0;

	refy = the->m_lpForwardPicture->lpData[0];
	refv = the->m_lpForwardPicture->lpData[2];
	refu = the->m_lpForwardPicture->lpData[1];

	/*top field*/
	xint = DIV_TRUNC_MIN(vx,2);
	yint = DIV_TRUNC_MIN(vy,2);

	/* the start address from prediction macroblock*/

	nDstX = the->dwMbPosX + xint;
	nDstY = ( the->dwMbPosY + (yint&~1)) * the->m_nCodedPicturePitch;

	nDstY += vs ? the->m_nCodedPicturePitch:0;
	fdit =  nDstY + nDstX;
	CHECK_VECTOR(fdit)

#if __MC_ADDALIGN_
	nRear8 = nDstX & 7;	
	bFalign0 = nRear8 ? FALSE : TRUE; // 
	the->m_RecInfo.bForwardAlign = bFalign0;
	if( nRear8 ){  // not align;
	
		nDstX -= nRear8;  // align;
		nRear8 <<= 3;
		nForwardLeftAlignBits0 = nRear8;
		nForwardRightAlignBits0 = 64 - nRear8;
		the->m_RecInfo.nForwardLeftAlignBits0 = nForwardLeftAlignBits0;
		the->m_RecInfo.nForwardLeftAlignBits1 = nForwardLeftAlignBits0 + 8;
		the->m_RecInfo.nForwardRightAlignBits0 = nForwardRightAlignBits0;
		the->m_RecInfo.nForwardRightAlignBits1 = nForwardRightAlignBits0 - 8;
		fdit = nDstY + nDstX;  // address aligned;
	}
#else
	the->m_RecInfo.bForwardAlign = TRUE;
#endif

	the->m_RecInfo.fxh = HALF_PERL(xint,vx);
	the->m_RecInfo.fyh = HALF_PERL(yint,vy);
	/*field based prediction*/			
	the->m_RecInfo.lfx0 = (the->m_nCodedPicturePitch << 1);
	the->m_RecInfo.lfx1 = (the->m_nCodedPicturePitch << 1);
	the->m_RecInfo.forw_mb0 = refy + fdit;
	the->m_RecInfo.ldstx = 32;
	the->m_RecInfo.dest_mb0 = the->reccoe->coey;
	the->m_RecInfo.h = 8;
	the->m_RecInfo.w = 16;

	rec_2b_1(&the->m_RecInfo);

	if(CHROMA420 == the->m_nChromaFormat) {

		vx = DIV_TRUNC_ZERO(vx,2);
		vy = DIV_TRUNC_ZERO(vy,2);
		xint = DIV_TRUNC_MIN(vx,2);
		yint = DIV_TRUNC_MIN(vy,2);

		nDstY = vs ? the->m_nChromaPitch : 0;
		nDstY += ( (the->dwMbPosY >> 1 ) + (yint & ~1)) * the->m_nChromaPitch;
		nDstX = ( the->dwMbPosX >> 1 ) + xint;

		// address align;		
#if __MC_ADDALIGN_
		nRear8 = nDstX & 7;	
		bFalign1 = nRear8 ? FALSE : TRUE;
		the->m_RecInfo.bForwardAlign = bFalign1;
		if( nRear8 ){  // not align;
		
			nDstX -= nRear8;  // align;
			nRear8 <<= 3;
			nForwardLeftAlignBitsChroma = nRear8;
			nForwardRightAlignBitsChroma = 64 - nRear8;
			the->m_RecInfo.nForwardLeftAlignBits0 = nForwardLeftAlignBitsChroma;
			the->m_RecInfo.nForwardLeftAlignBits1 = nForwardLeftAlignBitsChroma + 8;
			the->m_RecInfo.nForwardRightAlignBits0 = nForwardRightAlignBitsChroma;
			the->m_RecInfo.nForwardRightAlignBits1 = nForwardRightAlignBitsChroma - 8;
		}
#endif

		fdit = nDstY + nDstX;

		the->m_RecInfo.fxh = HALF_PERL(xint,vx);
		the->m_RecInfo.fyh = HALF_PERL(yint,vy);

		the->m_RecInfo.lfx0 = (the->m_nChromaPitch << 1);
		the->m_RecInfo.lfx1 = (the->m_nChromaPitch << 1);

		/*odd row*/
		the->m_RecInfo.forw_mb0 = refu + fdit;
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->reccoe->coeuv[0];
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;

		rec_2b_1(&the->m_RecInfo);	

		the->m_RecInfo.lfx0 = (the->m_nChromaPitch << 1);
		the->m_RecInfo.lfx1 = (the->m_nChromaPitch << 1);
		the->m_RecInfo.forw_mb0 = refv + fdit;
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->reccoe->coeuv[1];
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;

		rec_2b_1(&the->m_RecInfo);		 

	}

	/* predict and add to top field from bottom field */
	// form_prediction(forward_reference_frame,1,current_frame,0,
	//		Coded_Picture_Width<<1,Coded_Picture_Width<<1,16,8,bx,by>>1,
	//			DMV[0][0],DMV[0][1],1);

	vx = the->DMV[0][0];
	vy = the->DMV[0][1];

	vs = 1;
	vd = 0;

	refy = the->m_lpForwardPicture->lpData[0];
	refv = the->m_lpForwardPicture->lpData[2];
	refu = the->m_lpForwardPicture->lpData[1];

	/*bot field*/
	xint = DIV_TRUNC_MIN(vx,2);
	yint = DIV_TRUNC_MIN(vy,2);

	/* the start address from prediction macroblock */

	nDstX = the->dwMbPosX + xint;
	nDstY = ( the->dwMbPosY + (yint & ~1) ) * the->m_nCodedPicturePitch;
	nDstY += vs ? the->m_nCodedPicturePitch:0;
	fdit =  nDstY + nDstX;
	CHECK_VECTOR(fdit)

#if __MC_ADDALIGN_
	nRear8 = nDstX & 7;	
	bFalign0 = nRear8 ? FALSE : TRUE; // 
	the->m_RecInfo.bForwardAlign = bFalign0;
	if( nRear8 ){  // not align;
	
		nDstX -= nRear8;  // align;
		nRear8 <<= 3;
		nForwardLeftAlignBits0 = nRear8;
		nForwardRightAlignBits0 = 64 - nRear8;
		the->m_RecInfo.nForwardLeftAlignBits0 = nForwardLeftAlignBits0;
		the->m_RecInfo.nForwardLeftAlignBits1 = nForwardLeftAlignBits0 + 8;
		the->m_RecInfo.nForwardRightAlignBits0 = nForwardRightAlignBits0;
		the->m_RecInfo.nForwardRightAlignBits1 = nForwardRightAlignBits0 - 8;
		fdit = nDstY + nDstX;  // address aligned;
	}
#else
	the->m_RecInfo.bForwardAlign = TRUE;
#endif

	the->m_RecInfo.fxh = HALF_PERL(xint,vx);
	the->m_RecInfo.fyh = HALF_PERL(yint,vy);
	/*field based prediction*/			
	the->m_RecInfo.lfx0 = (the->m_nCodedPicturePitch << 1);
	the->m_RecInfo.lfx1 = (the->m_nCodedPicturePitch << 1);
	the->m_RecInfo.forw_mb0 = refy + fdit;
	the->m_RecInfo.ldstx = 32;
	the->m_RecInfo.dest_mb0 = the->reccoe1->coey;
	the->m_RecInfo.h = 8;
	the->m_RecInfo.w = 16;

	rec_2b_1(&the->m_RecInfo);

	the->m_RecInfo.forw_mb0 = the->reccoe->coey;
	the->m_RecInfo.back_mb0 = the->reccoe1->coey;
	the->m_RecInfo.lfx0 = 32;
	the->m_RecInfo.h = 8;
	the->m_RecInfo.w = 16;
	rec_avgblock(&the->m_RecInfo);

	if( the->dct_type ) {
		/*field dct*/
		the->m_RecInfo.lblkx = 8;
		the->m_RecInfo.blk0 = the->macro_block->coeff[0];
		the->m_RecInfo.blk1 = the->macro_block->coeff[1];
		the->m_RecInfo.lfx0 = 32;
		the->m_RecInfo.forw_mb0 = the->reccoe->coey;
		the->m_RecInfo.ldstx = 32;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.h = 8;
		the->m_RecInfo.w = 16;
		rec_addblock(&the->m_RecInfo);
	}
	else{/*frame dct*/
		/* top 4 rows */
		the->m_RecInfo.lblkx = 16;
		the->m_RecInfo.blk0 = the->macro_block->coeff[0];
		the->m_RecInfo.blk1 = the->macro_block->coeff[1];
		the->m_RecInfo.lfx0 = 32;
		the->m_RecInfo.forw_mb0 = the->reccoe->coey;
		the->m_RecInfo.ldstx = 32;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 16;
		rec_addblock(&the->m_RecInfo);
		/* bottom 4 rows */
		the->m_RecInfo.lblkx =16;
		the->m_RecInfo.blk0 = the->macro_block->coeff[2];
		the->m_RecInfo.blk1 = the->macro_block->coeff[3];
		the->m_RecInfo.lfx0 = 32;
		the->m_RecInfo.forw_mb0 = the->reccoe->coey + 16*8;
		the->m_RecInfo.ldstx = 32;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 16;
		rec_addblock(&the->m_RecInfo);
	}

	if( CHROMA420 == the->m_nChromaFormat ) {

		vx = DIV_TRUNC_ZERO(vx,2);
		vy = DIV_TRUNC_ZERO(vy,2);
		xint = DIV_TRUNC_MIN(vx,2);
		yint = DIV_TRUNC_MIN(vy,2);

		nDstY = vs ? the->m_nChromaPitch : 0;
		nDstY += ( (the->dwMbPosY >> 1 ) + (yint&~1)) * the->m_nChromaPitch;
		nDstX = ( the->dwMbPosX >> 1 ) + xint;

		// address align;		
#if __MC_ADDALIGN_
		nRear8 = nDstX & 7;	
		bFalign1 = nRear8 ? FALSE : TRUE;
		the->m_RecInfo.bForwardAlign = bFalign1;
		if( nRear8 ){  // not align;
		
			nDstX -= nRear8;  // align;
			nRear8 <<= 3;
			nForwardLeftAlignBitsChroma = nRear8;
			nForwardRightAlignBitsChroma = 64 - nRear8;
			the->m_RecInfo.nForwardLeftAlignBits0 = nForwardLeftAlignBitsChroma;
			the->m_RecInfo.nForwardLeftAlignBits1 = nForwardLeftAlignBitsChroma + 8;
			the->m_RecInfo.nForwardRightAlignBits0 = nForwardRightAlignBitsChroma;
			the->m_RecInfo.nForwardRightAlignBits1 = nForwardRightAlignBitsChroma - 8;
		}
#endif

		the->m_RecInfo.fxh = HALF_PERL(xint,vx);
		the->m_RecInfo.fyh = HALF_PERL(yint,vy);

		the->m_RecInfo.lfx0 = (the->m_nChromaPitch << 1);
		the->m_RecInfo.lfx1 = (the->m_nChromaPitch << 1);

		/*odd row*/
		fdit = nDstY + nDstX;
		the->m_RecInfo.forw_mb0 = refu + fdit;
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->reccoe1->coeuv[0];
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;

		rec_2b_1(&the->m_RecInfo);	

		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[0];
		the->m_RecInfo.back_mb0 = the->reccoe1->coeuv[0];
		the->m_RecInfo.lfx0 = 16;
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;
		rec_avgblock(&the->m_RecInfo);

		the->m_RecInfo.lfx0 = 16;
		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[0];
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.lblkx = 16;
		the->m_RecInfo.blk0 = the->macro_block->coeff[4];
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;
		rec_addblock(&the->m_RecInfo);

		the->m_RecInfo.lfx0 = (the->m_nChromaPitch << 1);
		the->m_RecInfo.lfx1 = (the->m_nChromaPitch << 1);
		the->m_RecInfo.forw_mb0 = refv + fdit;
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->reccoe1->coeuv[1];
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;

		rec_2b_1(&the->m_RecInfo);	

		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[1];
		the->m_RecInfo.back_mb0 = the->reccoe1->coeuv[1];
		the->m_RecInfo.lfx0 = 16;
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;
		rec_avgblock(&the->m_RecInfo);

		the->m_RecInfo.lfx0 = 16;
		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[1];
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.lblkx = 16;
		the->m_RecInfo.blk0 = the->macro_block->coeff[5];
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;
		rec_addblock(&the->m_RecInfo);
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void rec_mb_frame_dmv_bot(mc_decoder* the)
{
	s32 vx,vy,vs,vd;
	u8 *refy,*refv,*refu;
	s32 xint,yint,fdit;
	s32 nDstX ;
	s32 nDstY ;

#if __MC_ADDALIGN_

	s32 nRear8;
	s32 nForwardLeftAlignBits0;   
	s32 nForwardRightAlignBits0;
	s32 nForwardRightAlignBitsChroma;
	s32 nForwardLeftAlignBitsChroma;   
	b32 bFalign0,bFalign1;

#endif


	/* predict bottom field from bottom field */
	// form_prediction(forward_reference_frame,1,current_frame,1,
	//		Coded_Picture_Width<<1,Coded_Picture_Width<<1,16,8,bx,by>>1,
	//			PMV[0][0][0],PMV[0][0][1]>>1,0);

	vx = the->PMV[0][0][0];
	vy = the->PMV[0][0][1];

	vs = 1;
	vd = 0;

	refy = the->m_lpForwardPicture->lpData[0];
	refv = the->m_lpForwardPicture->lpData[2];
	refu = the->m_lpForwardPicture->lpData[1];

	/*top field*/
	xint = DIV_TRUNC_MIN(vx,2);
	yint = DIV_TRUNC_MIN(vy,2);

	/* the start address from prediction macroblock*/

	nDstX = the->dwMbPosX + xint;
	nDstY = ( the->dwMbPosY + (yint&~1)) * the->m_nCodedPicturePitch;
	nDstY += vs ? the->m_nCodedPicturePitch:0;
	fdit =  nDstY + nDstX;
	CHECK_VECTOR(fdit)

#if __MC_ADDALIGN_

	nRear8 = nDstX & 7;	
	bFalign0 = nRear8 ? FALSE : TRUE; // 
	the->m_RecInfo.bForwardAlign = bFalign0;
	if( nRear8 ){  // not align;
	
		nDstX -= nRear8;  // align;
		nRear8 <<= 3;
		nForwardLeftAlignBits0 = nRear8;
		nForwardRightAlignBits0 = 64 - nRear8;
		the->m_RecInfo.nForwardLeftAlignBits0 = nForwardLeftAlignBits0;
		the->m_RecInfo.nForwardLeftAlignBits1 = nForwardLeftAlignBits0 + 8;
		the->m_RecInfo.nForwardRightAlignBits0 = nForwardRightAlignBits0;
		the->m_RecInfo.nForwardRightAlignBits1 = nForwardRightAlignBits0 - 8;
		fdit = nDstY + nDstX;  // address aligned;
	}

#else
		the->m_RecInfo.bForwardAlign = TRUE;
#endif

	the->m_RecInfo.fxh = HALF_PERL(xint,vx);
	the->m_RecInfo.fyh = HALF_PERL(yint,vy);
	/*field based prediction*/			
	the->m_RecInfo.lfx0 = (the->m_nCodedPicturePitch << 1);
	the->m_RecInfo.lfx1 = (the->m_nCodedPicturePitch << 1);
	the->m_RecInfo.forw_mb0 = refy + fdit;
	the->m_RecInfo.ldstx = 32;
	the->m_RecInfo.dest_mb0 = the->reccoe->coey + 16;
	the->m_RecInfo.h = 8;
	the->m_RecInfo.w = 16;

	rec_2b_1(&the->m_RecInfo);

	if(CHROMA420 == the->m_nChromaFormat) {

		vx = DIV_TRUNC_ZERO(vx,2);
		vy = DIV_TRUNC_ZERO(vy,2);
		xint = DIV_TRUNC_MIN(vx,2);
		yint = DIV_TRUNC_MIN(vy,2);
		the->m_RecInfo.fxh = HALF_PERL(xint,vx);
		the->m_RecInfo.fyh = HALF_PERL(yint,vy);

		nDstY = vs ? the->m_nChromaPitch : 0;
		nDstY += ( (the->dwMbPosY >> 1 ) + (yint & ~1)) * the->m_nChromaPitch;
		nDstX = ( the->dwMbPosX >> 1 ) + xint;

		// address align;		
#if __MC_ADDALIGN_
		nRear8 = nDstX & 7;	
		bFalign1 = nRear8 ? FALSE : TRUE;
		the->m_RecInfo.bForwardAlign = bFalign1;
		if( nRear8 ){  // not align;
		
			nDstX -= nRear8;  // align;
			nRear8 <<= 3;
			nForwardLeftAlignBitsChroma = nRear8;
			nForwardRightAlignBitsChroma = 64 - nRear8;
			the->m_RecInfo.nForwardLeftAlignBits0 = nForwardLeftAlignBitsChroma;
			the->m_RecInfo.nForwardLeftAlignBits1 = nForwardLeftAlignBitsChroma + 8;
			the->m_RecInfo.nForwardRightAlignBits0 = nForwardRightAlignBitsChroma;
			the->m_RecInfo.nForwardRightAlignBits1 = nForwardRightAlignBitsChroma - 8;
		}
#endif

		fdit = nDstY + nDstX;

		the->m_RecInfo.lfx0 = (the->m_nChromaPitch << 1);
		the->m_RecInfo.lfx1 = (the->m_nChromaPitch << 1);

		/*odd row*/
		the->m_RecInfo.forw_mb0 = refu + fdit;
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->reccoe->coeuv[0] + 8;
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;

		rec_2b_1(&the->m_RecInfo);	

		the->m_RecInfo.lfx0 = (the->m_nChromaPitch << 1);
		the->m_RecInfo.lfx1 = (the->m_nChromaPitch << 1);
		the->m_RecInfo.forw_mb0 = refv + fdit;
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->reccoe->coeuv[1] + 8;
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;

		rec_2b_1(&the->m_RecInfo);		 

	}

	/* predict and add to bottom field from top field */
	// form_prediction(forward_reference_frame,0,current_frame,1,
	//		Coded_Picture_Width<<1,Coded_Picture_Width<<1,16,8,bx,by>>1,
	//			DMV[1][0],DMV[1][1],1);


	vx = the->DMV[1][0];
	vy = the->DMV[1][1];

	vs = 0;
	vd = 0;

	refy = the->m_lpForwardPicture->lpData[0];
	refv = the->m_lpForwardPicture->lpData[2];
	refu = the->m_lpForwardPicture->lpData[1];

	/*bot field*/
	xint = DIV_TRUNC_MIN(vx,2);
	yint = DIV_TRUNC_MIN(vy,2);
	the->m_RecInfo.fxh = HALF_PERL(xint,vx);
	the->m_RecInfo.fyh = HALF_PERL(yint,vy);

	/* the start address from prediction macroblock*/

	nDstX = the->dwMbPosX + xint;
	nDstY = ( the->dwMbPosY + (yint & ~1) ) * the->m_nCodedPicturePitch;
	nDstY += vs ? the->m_nCodedPicturePitch:0;
	fdit =  nDstY + nDstX;
	CHECK_VECTOR(fdit)

#if __MC_ADDALIGN_

	nRear8 = nDstX & 7;	
	bFalign0 = nRear8 ? FALSE : TRUE; // 
	the->m_RecInfo.bForwardAlign = bFalign0;
	if( nRear8 ){  // not align;
	
		nDstX -= nRear8;  // align;
		nRear8 <<= 3;
		nForwardLeftAlignBits0 = nRear8;
		nForwardRightAlignBits0 = 64 - nRear8;
		the->m_RecInfo.nForwardLeftAlignBits0 = nForwardLeftAlignBits0;
		the->m_RecInfo.nForwardLeftAlignBits1 = nForwardLeftAlignBits0 + 8;
		the->m_RecInfo.nForwardRightAlignBits0 = nForwardRightAlignBits0;
		the->m_RecInfo.nForwardRightAlignBits1 = nForwardRightAlignBits0 - 8;
		fdit = nDstY + nDstX;  // address aligned;
	}

#else
		the->m_RecInfo.bForwardAlign = TRUE;
#endif

	/*field based prediction*/			
	the->m_RecInfo.lfx0 = (the->m_nCodedPicturePitch << 1);
	the->m_RecInfo.lfx1 = (the->m_nCodedPicturePitch << 1);
	the->m_RecInfo.forw_mb0 = refy + fdit;
	the->m_RecInfo.ldstx = 32;
	the->m_RecInfo.dest_mb0 = the->reccoe1->coey + 16;
	the->m_RecInfo.h = 8;
	the->m_RecInfo.w = 16;

	rec_2b_1(&the->m_RecInfo);

	the->m_RecInfo.forw_mb0 = the->reccoe->coey + 16;
	the->m_RecInfo.back_mb0 = the->reccoe1->coey + 16;
	the->m_RecInfo.lfx0 = 32;
	the->m_RecInfo.h = 8;
	the->m_RecInfo.w = 16;
	rec_avgblock(&the->m_RecInfo);

	if(the->dct_type) {
		/*field dct*/
		the->m_RecInfo.lblkx = 8;
		the->m_RecInfo.blk0 = the->macro_block->coeff[2];
		the->m_RecInfo.blk1 = the->macro_block->coeff[3];
		the->m_RecInfo.lfx0 = 32;
		the->m_RecInfo.forw_mb0 = the->reccoe->coey + 16;
		the->m_RecInfo.ldstx = 32;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.w = 16;
		the->m_RecInfo.h = 8;
		rec_addblock(&the->m_RecInfo);
	}
	else{/*frame dct*/
	
		/* top 4 rows */
		the->m_RecInfo.lblkx =16;
		the->m_RecInfo.blk0 = the->macro_block->coeff[0] + 8;
		the->m_RecInfo.blk1 = the->macro_block->coeff[1] + 8;
		the->m_RecInfo.lfx0 = 32;
		the->m_RecInfo.forw_mb0 = the->reccoe->coey + 16;
		the->m_RecInfo.ldstx = 32;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 16;
		rec_addblock(&the->m_RecInfo);
		/* bottom 4 rows */
		the->m_RecInfo.lblkx =16;
		the->m_RecInfo.blk0 = the->macro_block->coeff[2] + 8;
		the->m_RecInfo.blk1 = the->macro_block->coeff[3] + 8;
		the->m_RecInfo.lfx0 = 32;
		the->m_RecInfo.forw_mb0 = the->reccoe->coey + 16*8 + 16;
		the->m_RecInfo.ldstx = 32;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 16;
		rec_addblock(&the->m_RecInfo);
	}

	if(CHROMA420 == the->m_nChromaFormat) {

		vx = DIV_TRUNC_ZERO(vx,2);
		vy = DIV_TRUNC_ZERO(vy,2);
		xint = DIV_TRUNC_MIN(vx,2);
		yint = DIV_TRUNC_MIN(vy,2);
		the->m_RecInfo.fxh = HALF_PERL(xint,vx);
		the->m_RecInfo.fyh = HALF_PERL(yint,vy);

		nDstY = vs ? the->m_nChromaPitch : 0;
		nDstY += ( (the->dwMbPosY >> 1 ) + (yint&~1)) * the->m_nChromaPitch;
		nDstX = ( the->dwMbPosX >> 1 ) + xint;

		// address align;		
#if __MC_ADDALIGN_
		nRear8 = nDstX & 7;	
		bFalign1 = nRear8 ? FALSE : TRUE;
		the->m_RecInfo.bForwardAlign = bFalign1;
		if( nRear8 ){  // not align;
		
			nDstX -= nRear8;  // align;
			nRear8 <<= 3;
			nForwardLeftAlignBitsChroma = nRear8;
			nForwardRightAlignBitsChroma = 64 - nRear8;
			the->m_RecInfo.nForwardLeftAlignBits0 = nForwardLeftAlignBitsChroma;
			the->m_RecInfo.nForwardLeftAlignBits1 = nForwardLeftAlignBitsChroma + 8;
			the->m_RecInfo.nForwardRightAlignBits0 = nForwardRightAlignBitsChroma;
			the->m_RecInfo.nForwardRightAlignBits1 = nForwardRightAlignBitsChroma - 8;
		}
#endif

		fdit = nDstY + nDstX;

		the->m_RecInfo.lfx0 = (the->m_nChromaPitch << 1);
		the->m_RecInfo.lfx1 = (the->m_nChromaPitch << 1);

		/*odd row*/
		the->m_RecInfo.forw_mb0 = refu + fdit;
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->reccoe1->coeuv[0] + 8;
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;

		rec_2b_1(&the->m_RecInfo);	

		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[0] + 8;
		the->m_RecInfo.back_mb0 = the->reccoe1->coeuv[0] + 8;
		the->m_RecInfo.lfx0 = 16;
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;
		rec_avgblock(&the->m_RecInfo);


		the->m_RecInfo.lfx0 = 16;
		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[0] + 8;
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.lblkx = 16;
		the->m_RecInfo.blk0 = the->macro_block->coeff[4] + 8;
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;
		rec_addblock(&the->m_RecInfo);

		the->m_RecInfo.lfx0 = (the->m_nChromaPitch << 1);
		the->m_RecInfo.lfx1 = (the->m_nChromaPitch << 1);
		the->m_RecInfo.forw_mb0 = refv + fdit;
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->reccoe1->coeuv[1] + 8;
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;

		rec_2b_1(&the->m_RecInfo);		 

		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[1] + 8;
		the->m_RecInfo.back_mb0 = the->reccoe1->coeuv[1] + 8;
		the->m_RecInfo.lfx0 = 16;
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;
		rec_avgblock(&the->m_RecInfo);


		the->m_RecInfo.lfx0 = 16;
		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[1] + 8;
		the->m_RecInfo.ldstx = 16;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.lblkx = 16;
		the->m_RecInfo.blk0 = the->macro_block->coeff[5] + 8;
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;
		rec_addblock(&the->m_RecInfo);
	}


}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void rec_mb_field_dmv(mc_decoder* the)
{
	s32 vx,vy,vs,vd;
	u8 *refy,*refv,*refu;
	s32 xint,yint,fdit;

	s32 nDstX ;
	s32 nDstY ;

	VideoFrame* lpPicture;

#if __MC_ADDALIGN_
	s32 nRear8;
	s32 nForwardLeftAlignBits0;   
	s32 nForwardRightAlignBits0;
	s32 nForwardLeftAlignBitsChroma;   
	s32 nForwardRightAlignBitsChroma;
	b32 bFalign0,bFalign1;
#endif


	// dual prime prediction //
	Dual_Prime_Arithmetic(the,the->DMV,the->dmvector,the->PMV[0][0][0],the->PMV[0][0][1]);

	//	if (Second_Field)
	//	  predframe = backward_reference_frame; /* same frame */
	//	else
	//	  predframe = forward_reference_frame; /* previous frame */	
	lpPicture = the->m_bSecondField ? the->m_lpBackwardPicture : the->m_lpForwardPicture;

	//	/* predict from field of same parity */
	//	form_prediction(forward_reference_frame,currentfield,current_frame,0,
	//	  Coded_Picture_Width<<1,Coded_Picture_Width<<1,16,16,bx,by,
	//	  PMV[0][0][0],PMV[0][0][1],0);

	vx = the->PMV[0][0][0];
	vy = the->PMV[0][0][1];

	vs = the->m_bSecondField;
	vd = 0;

	refy = lpPicture->lpData[0];
	refv = lpPicture->lpData[2];
	refu = lpPicture->lpData[1];


	/*top field*/
	xint = DIV_TRUNC_MIN(vx,2);
	yint = DIV_TRUNC_MIN(vy,2);
	the->m_RecInfo.fxh = HALF_PERL(xint,vx);
	the->m_RecInfo.fyh = HALF_PERL(yint,vy);

	/* the start address from prediction macroblock*/

	nDstX = the->dwMbPosX + xint;
	nDstY = ((the->dwMbPosY) + yint ) * ( the->m_nCodedPicturePitch << 1 );
	nDstY += vs ? the->m_nCodedPicturePitch:0;
	fdit =  nDstY + nDstX;
	CHECK_VECTOR(fdit)

#if __MC_ADDALIGN_

	nRear8 = nDstX & 7;	
	bFalign0 = nRear8 ? FALSE : TRUE; // 
	the->m_RecInfo.bForwardAlign = bFalign0;
	if( nRear8 ){  // not align;
	
		nDstX -= nRear8;  // align;
		nRear8 <<= 3;
		nForwardLeftAlignBits0 = nRear8;
		nForwardRightAlignBits0 = 64 - nRear8;
		the->m_RecInfo.nForwardLeftAlignBits0 = nForwardLeftAlignBits0;
		the->m_RecInfo.nForwardLeftAlignBits1 = nForwardLeftAlignBits0 + 8;
		the->m_RecInfo.nForwardRightAlignBits0 = nForwardRightAlignBits0;
		the->m_RecInfo.nForwardRightAlignBits1 = nForwardRightAlignBits0 - 8;
		fdit = nDstY + nDstX;  // address aligned;
	}

#else
		the->m_RecInfo.bForwardAlign = TRUE;
#endif


	/*field based prediction*/			
	the->m_RecInfo.lfx0 = (the->m_nCodedPicturePitch << 1);
	the->m_RecInfo.lfx1 = (the->m_nCodedPicturePitch << 1);
	the->m_RecInfo.forw_mb0 = refy + fdit;
	the->m_RecInfo.ldstx = 16;
	the->m_RecInfo.dest_mb0 = the->reccoe->coey;
	the->m_RecInfo.h = 16;
	the->m_RecInfo.w = 16;

	rec_2b_1(&the->m_RecInfo);

	if(CHROMA420 == the->m_nChromaFormat) {

		vx = DIV_TRUNC_ZERO(vx,2);
		vy = DIV_TRUNC_ZERO(vy,2);
		xint = DIV_TRUNC_MIN(vx,2);
		yint = DIV_TRUNC_MIN(vy,2);
		the->m_RecInfo.fxh = HALF_PERL(xint,vx);
		the->m_RecInfo.fyh = HALF_PERL(yint,vy);

		nDstY = vs ? the->m_nChromaPitch : 0;
		nDstY += ( (the->dwMbPosY >> 1 ) + yint ) * ( the->m_nChromaPitch << 1);
		nDstX = (the->dwMbPosX >> 1 ) + xint;

		// address align;		
#if __MC_ADDALIGN_
		nRear8 = nDstX & 7;	
		bFalign1 = nRear8 ? FALSE : TRUE;
		the->m_RecInfo.bForwardAlign = bFalign1;
		if( nRear8 ){  // not align;
		
			nDstX -= nRear8;  // align;
			nRear8 <<= 3;
			nForwardLeftAlignBitsChroma = nRear8;
			nForwardRightAlignBitsChroma = 64 - nRear8;
			the->m_RecInfo.nForwardLeftAlignBits0 = nForwardLeftAlignBitsChroma;
			the->m_RecInfo.nForwardLeftAlignBits1 = nForwardLeftAlignBitsChroma + 8;
			the->m_RecInfo.nForwardRightAlignBits0 = nForwardRightAlignBitsChroma;
			the->m_RecInfo.nForwardRightAlignBits1 = nForwardRightAlignBitsChroma - 8;
		}
#endif

		fdit = nDstY + nDstX;

		the->m_RecInfo.lfx0 = (the->m_nChromaPitch << 1);
		the->m_RecInfo.lfx1 = (the->m_nChromaPitch << 1);

		/*odd row*/
		the->m_RecInfo.forw_mb0 = refu + fdit;
		the->m_RecInfo.ldstx = 8;
		the->m_RecInfo.dest_mb0 = the->reccoe->coeuv[0];
		the->m_RecInfo.h = 8;
		the->m_RecInfo.w = 8;

		rec_2b_1(&the->m_RecInfo);	

		the->m_RecInfo.lfx0 = (the->m_nChromaPitch << 1);
		the->m_RecInfo.lfx1 = (the->m_nChromaPitch << 1);
		the->m_RecInfo.forw_mb0 = refv + fdit;
		the->m_RecInfo.ldstx = 8;
		the->m_RecInfo.dest_mb0 = the->reccoe->coeuv[1];
		the->m_RecInfo.h = 8;
		the->m_RecInfo.w = 8;

		rec_2b_1(&the->m_RecInfo);		 

	}


	//	/* predict from field of opposite parity */
	//	form_prediction(predframe,!currentfield,current_frame,0,
	//	  Coded_Picture_Width<<1,Coded_Picture_Width<<1,16,16,bx,by,
	//	  DMV[0][0],DMV[0][1],1);

	vx = the->DMV[0][0];
	vy = the->DMV[0][1];

	vs = !the->m_bSecondField;
	vd = 0;

	refy = lpPicture->lpData[0];
	refv = lpPicture->lpData[2];
	refu = lpPicture->lpData[1];

	/*bot field*/
	xint = DIV_TRUNC_MIN(vx,2);
	yint = DIV_TRUNC_MIN(vy,2);
	the->m_RecInfo.fxh = HALF_PERL(xint,vx);
	the->m_RecInfo.fyh = HALF_PERL(yint,vy);

	/* the start address from prediction macroblock*/

	nDstX = the->dwMbPosX + xint;
	nDstY = ((the->dwMbPosY) + yint ) * ( the->m_nCodedPicturePitch << 1 );
	nDstY += vs ? the->m_nCodedPicturePitch:0;
	fdit =  nDstY + nDstX;
	CHECK_VECTOR(fdit)

#if __MC_ADDALIGN_

	nRear8 = nDstX & 7;	
	bFalign0 = nRear8 ? FALSE : TRUE; // 
	the->m_RecInfo.bForwardAlign = bFalign0;
	if( nRear8 ){  // not align;
	
		nDstX -= nRear8;  // align;
		nRear8 <<= 3;
		nForwardLeftAlignBits0 = nRear8;
		nForwardRightAlignBits0 = 64 - nRear8;
		the->m_RecInfo.nForwardLeftAlignBits0 = nForwardLeftAlignBits0;
		the->m_RecInfo.nForwardLeftAlignBits1 = nForwardLeftAlignBits0 + 8;
		the->m_RecInfo.nForwardRightAlignBits0 = nForwardRightAlignBits0;
		the->m_RecInfo.nForwardRightAlignBits1 = nForwardRightAlignBits0 - 8;
		fdit = nDstY + nDstX;  // address aligned;
	}

#else
	the->m_RecInfo.bForwardAlign = TRUE;
#endif

	/*field based prediction*/			
	the->m_RecInfo.lfx0 = (the->m_nCodedPicturePitch << 1);
	the->m_RecInfo.lfx1 = (the->m_nCodedPicturePitch << 1);
	the->m_RecInfo.forw_mb0 = refy + fdit;
	the->m_RecInfo.ldstx = 16;
	the->m_RecInfo.dest_mb0 = the->reccoe1->coey;
	the->m_RecInfo.h = 16;
	the->m_RecInfo.w = 16;

	rec_2b_1(&the->m_RecInfo);

	the->m_RecInfo.forw_mb0 = the->reccoe->coey;
	the->m_RecInfo.back_mb0 = the->reccoe1->coey;
	the->m_RecInfo.lfx0 = 16;
	the->m_RecInfo.h = 16;
	the->m_RecInfo.w = 16;
	rec_avgblock(&the->m_RecInfo);

	/* top 4 rows */
	the->m_RecInfo.lblkx = 8;
	the->m_RecInfo.blk0 = the->macro_block->coeff[0];
	the->m_RecInfo.blk1 = the->macro_block->coeff[1];
	the->m_RecInfo.lfx0 = 16;
	the->m_RecInfo.forw_mb0 = the->reccoe->coey;
	the->m_RecInfo.ldstx = 16;
	the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
	the->m_RecInfo.h = 8;
	the->m_RecInfo.w = 16;
	rec_addblock(&the->m_RecInfo);
	/* bottom 4 rows */
	the->m_RecInfo.lblkx = 8;
	the->m_RecInfo.blk0 = the->macro_block->coeff[2];
	the->m_RecInfo.blk1 = the->macro_block->coeff[3];
	the->m_RecInfo.lfx0 = 16;
	the->m_RecInfo.forw_mb0 = the->reccoe->coey + 16*8;
	the->m_RecInfo.ldstx = 16;
	the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
	the->m_RecInfo.h = 8;
	the->m_RecInfo.w = 16;
	rec_addblock(&the->m_RecInfo);


	if(CHROMA420 == the->m_nChromaFormat) {

		vx = DIV_TRUNC_ZERO(vx,2);
		vy = DIV_TRUNC_ZERO(vy,2);
		xint = DIV_TRUNC_MIN(vx,2);
		yint = DIV_TRUNC_MIN(vy,2);
		the->m_RecInfo.fxh = HALF_PERL(xint,vx);
		the->m_RecInfo.fyh = HALF_PERL(yint,vy);

		nDstY = vs ? the->m_nChromaPitch : 0;
		nDstY += ( (the->dwMbPosY >> 1 ) + yint ) * ( the->m_nChromaPitch << 1);
		nDstX = ( the->dwMbPosX >> 1 ) + xint;

		// address align;		
#if __MC_ADDALIGN_
		nRear8 = nDstX & 7;	
		bFalign1 = nRear8 ? FALSE : TRUE;
		the->m_RecInfo.bForwardAlign = bFalign1;
		if( nRear8 ){  // not align;
		
			nDstX -= nRear8;  // align;
			nRear8 <<= 3;
			nForwardLeftAlignBitsChroma = nRear8;
			nForwardRightAlignBitsChroma = 64 - nRear8;
			the->m_RecInfo.nForwardLeftAlignBits0 = nForwardLeftAlignBitsChroma;
			the->m_RecInfo.nForwardLeftAlignBits1 = nForwardLeftAlignBitsChroma + 8;
			the->m_RecInfo.nForwardRightAlignBits0 = nForwardRightAlignBitsChroma;
			the->m_RecInfo.nForwardRightAlignBits1 = nForwardRightAlignBitsChroma - 8;
		}
#endif

		fdit = nDstY + nDstX;

		the->m_RecInfo.lfx0 = (the->m_nChromaPitch << 1);
		the->m_RecInfo.lfx1 = (the->m_nChromaPitch << 1);

		/*odd row*/
		the->m_RecInfo.forw_mb0 = refu + fdit;
		the->m_RecInfo.ldstx = 8;
		the->m_RecInfo.dest_mb0 = the->reccoe1->coeuv[0];
		the->m_RecInfo.h = 8;
		the->m_RecInfo.w = 8;

		rec_2b_1(&the->m_RecInfo);	

		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[0];
		the->m_RecInfo.back_mb0 = the->reccoe1->coeuv[0];
		the->m_RecInfo.lfx0 = 8;
		the->m_RecInfo.h = 8;
		the->m_RecInfo.w = 8;
		rec_avgblock(&the->m_RecInfo);


		the->m_RecInfo.lfx0 = 8;
		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[0];
		the->m_RecInfo.ldstx = 8;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.lblkx = 8;
		the->m_RecInfo.blk0 = the->macro_block->coeff[4];
		the->m_RecInfo.h = 8;
		the->m_RecInfo.w = 8;
		rec_addblock(&the->m_RecInfo);

		the->m_RecInfo.lfx0 = (the->m_nChromaPitch << 1);
		the->m_RecInfo.lfx1 = (the->m_nChromaPitch << 1);
		the->m_RecInfo.forw_mb0 = refv + fdit;
		the->m_RecInfo.ldstx = 8;
		the->m_RecInfo.dest_mb0 = the->reccoe1->coeuv[1];
		the->m_RecInfo.h = 8;
		the->m_RecInfo.w = 8;

		rec_2b_1(&the->m_RecInfo);		 

		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[1];
		the->m_RecInfo.back_mb0 = the->reccoe1->coeuv[1];
		the->m_RecInfo.lfx0 = 8;
		the->m_RecInfo.h = 8;
		the->m_RecInfo.w = 8;
		rec_avgblock(&the->m_RecInfo);

		the->m_RecInfo.lfx0 = 8;
		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[1];
		the->m_RecInfo.ldstx = 8;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.lblkx = 8;
		the->m_RecInfo.blk0 = the->macro_block->coeff[5];
		the->m_RecInfo.h = 8;
		the->m_RecInfo.w = 8;
		rec_addblock(&the->m_RecInfo);
	}

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void rec_mb_field_16x8(mc_decoder* the)
{
	if ( the->macroblock_type & MACROBLOCK_MOTION_FORWARD || \
		the->nPictureCodingType == P_TYPE ){

			if(the->m_nStwTop < 2){
				rec_mb_field_16x8_forward(the);
			}
	}

	if( the->macroblock_type & MACROBLOCK_MOTION_BACKWARD ){
		rec_mb_field_16x8_backward(the);
	}
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void rec_mb_field_16x8_forward(mc_decoder* the)
{
	s32 vx,vy,vs,vd;
	u8 *refy,*refv,*refu;
	s32 xint,yint,fdit;
	s32 nDstX,nDstY;

#if __MC_ADDALIGN_
	s32        nRear8;
	s32        nForwardLeftAlignBits0;   
	s32        nForwardRightAlignBits0;
	s32        nForwardRightAlignBitsChroma;
	s32        nForwardLeftAlignBitsChroma;   
	b32        bFalign0,bFalign1;
#endif

	VideoFrame* lpPicture;

	b32        bCurrenField = ( the->nPictureStructure == BOTTOM_FIELD);

	/* determine which frame to use for prediction */
	//      if ((picture_coding_type==P_TYPE) && Second_Field
	//         && (currentfield!=motion_vertical_field_select[0][0]))
	//        predframe = backward_reference_frame; /* same frame */
	//      else
	//        predframe = forward_reference_frame; /* previous frame */
	if ( (the->nPictureCodingType ==  P_TYPE) && the->m_bSecondField \
		&& (bCurrenField != the->motion_vertical_field_select[0][0] )	)  {
			lpPicture = the->m_lpBackwardPicture;
	}
	else{
		lpPicture = the->m_lpForwardPicture;
	}

	//		form_prediction(predframe,motion_vertical_field_select[0][0],current_frame,0,
	//			Coded_Picture_Width<<1,Coded_Picture_Width<<1,16,8,bx,by,
	//			PMV[0][0][0],PMV[0][0][1],stwtop);

	vx = the->PMV[0][0][0];
	vy = the->PMV[0][0][1];

	vs =  the->motion_vertical_field_select[0][0];
	vd = 0;

	refy = lpPicture->lpData[0];
	refv = lpPicture->lpData[2];
	refu = lpPicture->lpData[1];

	/*bot field*/
	xint = DIV_TRUNC_MIN(vx,2);
	yint = DIV_TRUNC_MIN(vy,2);
	the->m_RecInfo.fxh = HALF_PERL(xint,vx);
	the->m_RecInfo.fyh = HALF_PERL(yint,vy);

	/* the start address from prediction macroblock*/

	nDstX = the->dwMbPosX + xint;
	nDstY = ((the->dwMbPosY) + yint ) * ( the->m_nCodedPicturePitch << 1 );
	nDstY += vs ? the->m_nCodedPicturePitch:0;
	fdit =  nDstY + nDstX;
	CHECK_VECTOR(fdit)

#if __MC_ADDALIGN_
	nRear8 = nDstX & 7;	
	bFalign0 = nRear8 ? FALSE : TRUE; // 
	the->m_RecInfo.bForwardAlign = bFalign0;
	if( nRear8 ){  // not align;
	
		nDstX -= nRear8;  // align;
		nRear8 <<= 3;
		nForwardLeftAlignBits0 = nRear8;
		nForwardRightAlignBits0 = 64 - nRear8;
		the->m_RecInfo.nForwardLeftAlignBits0 = nForwardLeftAlignBits0;
		the->m_RecInfo.nForwardLeftAlignBits1 = nForwardLeftAlignBits0 + 8;
		the->m_RecInfo.nForwardRightAlignBits0 = nForwardRightAlignBits0;
		the->m_RecInfo.nForwardRightAlignBits1 = nForwardRightAlignBits0 - 8;
		fdit = nDstY + nDstX;  // address aligned;
	}
#else
	the->m_RecInfo.bForwardAlign = TRUE;
#endif

	/*field based prediction*/			
	the->m_RecInfo.lfx0 = (the->m_nCodedPicturePitch << 1);
	the->m_RecInfo.lfx1 = (the->m_nCodedPicturePitch << 1);
	the->m_RecInfo.forw_mb0 = refy + fdit;
	the->m_RecInfo.ldstx = 16;
	the->m_RecInfo.dest_mb0 = the->reccoe->coey;
	the->m_RecInfo.h = 8;
	the->m_RecInfo.w = 16;

	rec_2b_1(&the->m_RecInfo);

	/* top 4 rows */
	the->m_RecInfo.lblkx = 8;
	the->m_RecInfo.blk0 = the->macro_block->coeff[0];
	the->m_RecInfo.blk1 = the->macro_block->coeff[1];
	the->m_RecInfo.lfx0 = 16;
	the->m_RecInfo.forw_mb0 = the->reccoe->coey;
	the->m_RecInfo.ldstx = 16;
	the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
	the->m_RecInfo.h = 8;
	the->m_RecInfo.w = 16;
	rec_addblock(&the->m_RecInfo);


	if(CHROMA420 == the->m_nChromaFormat) {

		vx = DIV_TRUNC_ZERO(vx,2);
		vy = DIV_TRUNC_ZERO(vy,2);
		xint = DIV_TRUNC_MIN(vx,2);
		yint = DIV_TRUNC_MIN(vy,2);
		the->m_RecInfo.fxh = HALF_PERL(xint,vx);
		the->m_RecInfo.fyh = HALF_PERL(yint,vy);

		nDstY = vs ? the->m_nChromaPitch : 0;
		nDstY += ( (the->dwMbPosY >> 1 ) + yint ) * ( the->m_nChromaPitch << 1);
		nDstX = ( the->dwMbPosX >> 1 ) + xint;

		// address align;		
#if __MC_ADDALIGN_
		nRear8 = nDstX & 7;	
		bFalign1 = nRear8 ? FALSE : TRUE;
		the->m_RecInfo.bForwardAlign = bFalign1;
		if( nRear8 ){  // not align;
		
			nDstX -= nRear8;  // align;
			nRear8 <<= 3;
			nForwardLeftAlignBitsChroma = nRear8;
			nForwardRightAlignBitsChroma = 64 - nRear8;
			the->m_RecInfo.nForwardLeftAlignBits0 = nForwardLeftAlignBitsChroma;
			the->m_RecInfo.nForwardLeftAlignBits1 = nForwardLeftAlignBitsChroma + 8;
			the->m_RecInfo.nForwardRightAlignBits0 = nForwardRightAlignBitsChroma;
			the->m_RecInfo.nForwardRightAlignBits1 = nForwardRightAlignBitsChroma - 8;
		}
#endif

		fdit = nDstY + nDstX;

		the->m_RecInfo.lfx0 = (the->m_nChromaPitch << 1);
		the->m_RecInfo.lfx1 = (the->m_nChromaPitch << 1);

		/*odd row*/
		the->m_RecInfo.forw_mb0 = refu + fdit;
		the->m_RecInfo.ldstx = 8;
		the->m_RecInfo.dest_mb0 = the->reccoe->coeuv[0];
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;

		rec_2b_1(&the->m_RecInfo);	

		the->m_RecInfo.lfx0 = 8;
		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[0];
		the->m_RecInfo.ldstx = 8;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.lblkx = 8;
		the->m_RecInfo.blk0 = the->macro_block->coeff[4];
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;
		rec_addblock(&the->m_RecInfo);

		the->m_RecInfo.lfx0 = (the->m_nChromaPitch << 1);
		the->m_RecInfo.lfx1 = (the->m_nChromaPitch << 1);
		the->m_RecInfo.forw_mb0 = refv + fdit;
		the->m_RecInfo.ldstx = 8;
		the->m_RecInfo.dest_mb0 = the->reccoe->coeuv[1];
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;

		rec_2b_1(&the->m_RecInfo);		 

		the->m_RecInfo.lfx0 = 8;
		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[1];
		the->m_RecInfo.ldstx = 8;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.lblkx = 8;
		the->m_RecInfo.blk0 = the->macro_block->coeff[5];
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;
		rec_addblock(&the->m_RecInfo);
	}


	//		/* determine which frame to use for lower half prediction */
	//		if ((picture_coding_type==P_TYPE) && Second_Field
	//		 && (currentfield!=motion_vertical_field_select[1][0]))
	//			predframe = backward_reference_frame; /* same frame */
	//		else
	//			predframe = forward_reference_frame; /* previous frame */

	if ( (the->nPictureCodingType ==  P_TYPE) && the->m_bSecondField \
		&& (bCurrenField != the->motion_vertical_field_select[1][0] )	)  {
			lpPicture = the->m_lpBackwardPicture;
	}
	else{
		lpPicture = the->m_lpForwardPicture;
	}

	//		form_prediction(predframe,motion_vertical_field_select[1][0],current_frame,0,
	//			Coded_Picture_Width<<1,Coded_Picture_Width<<1,16,8,bx,by+8,
	//			PMV[1][0][0],PMV[1][0][1],stwtop);

	vx = the->PMV[1][0][0];
	vy = the->PMV[1][0][1];

	vs =  the->motion_vertical_field_select[1][0];
	vd = 0;

	refy = lpPicture->lpData[0];
	refv = lpPicture->lpData[2];
	refu = lpPicture->lpData[1];

	/*bot field*/
	xint = DIV_TRUNC_MIN(vx,2);
	yint = DIV_TRUNC_MIN(vy,2);
	the->m_RecInfo.fxh = HALF_PERL(xint,vx);
	the->m_RecInfo.fyh = HALF_PERL(yint,vy);

	/* the start address from prediction macroblock*/

	nDstX = the->dwMbPosX + xint;
	nDstY = ((the->dwMbPosY) + yint ) * ( the->m_nCodedPicturePitch << 1 );
	nDstY += vs ? the->m_nCodedPicturePitch:0;
	fdit =  nDstY + nDstX;
	CHECK_VECTOR(fdit)

#if __MC_ADDALIGN_

	nRear8 = nDstX & 7;	
	bFalign0 = nRear8 ? FALSE : TRUE; // 
	the->m_RecInfo.bForwardAlign = bFalign0;
	if( nRear8 ){  // not align;
	
		nDstX -= nRear8;  // align;
		nRear8 <<= 3;
		nForwardLeftAlignBits0 = nRear8;
		nForwardRightAlignBits0 = 64 - nRear8;
		the->m_RecInfo.nForwardLeftAlignBits0 = nForwardLeftAlignBits0;
		the->m_RecInfo.nForwardLeftAlignBits1 = nForwardLeftAlignBits0 + 8;
		the->m_RecInfo.nForwardRightAlignBits0 = nForwardRightAlignBits0;
		the->m_RecInfo.nForwardRightAlignBits1 = nForwardRightAlignBits0 - 8;
		fdit = nDstY + nDstX;  // address aligned;
	}

#else
		the->m_RecInfo.bForwardAlign = TRUE;
#endif

	/*field based prediction*/			
	the->m_RecInfo.lfx0 = (the->m_nCodedPicturePitch << 1);
	the->m_RecInfo.lfx1 = (the->m_nCodedPicturePitch << 1);
	the->m_RecInfo.forw_mb0 = refy + fdit;
	the->m_RecInfo.ldstx = 16;
	the->m_RecInfo.dest_mb0 = the->reccoe->coey + 16*8;
	the->m_RecInfo.h = 8;
	the->m_RecInfo.w = 16;

	rec_2b_1(&the->m_RecInfo);

	/* bot 8 rows */
	the->m_RecInfo.lblkx = 8;
	the->m_RecInfo.blk0 = the->macro_block->coeff[2];
	the->m_RecInfo.blk1 = the->macro_block->coeff[3];
	the->m_RecInfo.lfx0 = 16;
	the->m_RecInfo.forw_mb0 = the->reccoe->coey + 16*8;
	the->m_RecInfo.ldstx = 16;
	the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
	the->m_RecInfo.h = 8;
	the->m_RecInfo.w = 16;
	rec_addblock(&the->m_RecInfo);


	if(CHROMA420 == the->m_nChromaFormat) {

		vx = DIV_TRUNC_ZERO(vx,2);
		vy = DIV_TRUNC_ZERO(vy,2);
		xint = DIV_TRUNC_MIN(vx,2);
		yint = DIV_TRUNC_MIN(vy,2);
		the->m_RecInfo.fxh = HALF_PERL(xint,vx);
		the->m_RecInfo.fyh = HALF_PERL(yint,vy);

		nDstY = vs ? the->m_nChromaPitch : 0;
		nDstY += ( (the->dwMbPosY >> 1 ) + yint ) * ( the->m_nChromaPitch << 1);
		nDstX = ( the->dwMbPosX >> 1 ) + xint;

		// address align;		
#if __MC_ADDALIGN_
		nRear8 = nDstX & 7;	
		bFalign1 = nRear8 ? FALSE : TRUE;
		the->m_RecInfo.bForwardAlign = bFalign1;
		if( nRear8 ){  // not align;
		
			nDstX -= nRear8;  // align;
			nRear8 <<= 3;
			nForwardLeftAlignBitsChroma = nRear8;
			nForwardRightAlignBitsChroma = 64 - nRear8;
			the->m_RecInfo.nForwardLeftAlignBits0 = nForwardLeftAlignBitsChroma;
			the->m_RecInfo.nForwardLeftAlignBits1 = nForwardLeftAlignBitsChroma + 8;
			the->m_RecInfo.nForwardRightAlignBits0 = nForwardRightAlignBitsChroma;
			the->m_RecInfo.nForwardRightAlignBits1 = nForwardRightAlignBitsChroma - 8;
		}
#endif

		fdit = nDstY + nDstX;

		the->m_RecInfo.lfx0 = (the->m_nChromaPitch << 1);
		the->m_RecInfo.lfx1 = (the->m_nChromaPitch << 1);

		/*odd row*/
		the->m_RecInfo.forw_mb0 = refu + fdit;
		the->m_RecInfo.ldstx = 8;
		the->m_RecInfo.dest_mb0 = the->reccoe->coeuv[0] + 8*4;
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;

		rec_2b_1(&the->m_RecInfo);	

		the->m_RecInfo.lfx0 = 8;
		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[0]  + 8*4;
		the->m_RecInfo.ldstx = 8;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.lblkx = 8;
		the->m_RecInfo.blk0 = the->macro_block->coeff[4] + 8*4;
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;
		rec_addblock(&the->m_RecInfo);

		the->m_RecInfo.lfx0 = (the->m_nChromaPitch << 1);
		the->m_RecInfo.lfx1 = (the->m_nChromaPitch << 1);
		the->m_RecInfo.forw_mb0 = refv + fdit;
		the->m_RecInfo.ldstx = 8;
		the->m_RecInfo.dest_mb0 = the->reccoe->coeuv[1] + 8*4;
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;

		rec_2b_1(&the->m_RecInfo);		 

		the->m_RecInfo.lfx0 = 8;
		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[1] + 8*4;
		the->m_RecInfo.ldstx = 8;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.lblkx = 8;
		the->m_RecInfo.blk0 = the->macro_block->coeff[5] + 8*4;
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;
		rec_addblock(&the->m_RecInfo);
	}

}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void rec_mb_field_16x8_backward(mc_decoder* the)
{
	s32 vx,vy,vs,vd;
	u8 *refy,*refv,*refu;
	s32 xint,yint,fdit;
	s32 nDstX,nDstY;

#if __MC_ADDALIGN_
	s32        nRear8;
	s32        nForwardLeftAlignBits0;   
	s32        nForwardRightAlignBits0;
	s32        nForwardRightAlignBitsChroma;
	s32        nForwardLeftAlignBitsChroma;   
	b32        bFalign0,bFalign1;
#endif
	// backward;
	//		form_prediction(backward_reference_frame,motion_vertical_field_select[0][1],
	//		  current_frame,0,Coded_Picture_Width<<1,Coded_Picture_Width<<1,16,8,
	//		  bx,by,PMV[0][1][0],PMV[0][1][1],stwtop);

	vx = the->PMV[0][1][0];
	vy = the->PMV[0][1][1];

	vs =  the->motion_vertical_field_select[0][1];
	vd = 0;

	refy = the->m_lpBackwardPicture->lpData[0];
	refv = the->m_lpBackwardPicture->lpData[2];
	refu = the->m_lpBackwardPicture->lpData[1];

	/*bot field*/
	xint = DIV_TRUNC_MIN(vx,2);
	yint = DIV_TRUNC_MIN(vy,2);
	the->m_RecInfo.fxh = HALF_PERL(xint,vx);
	the->m_RecInfo.fyh = HALF_PERL(yint,vy);

	/* the start address from prediction macroblock*/

	nDstX = the->dwMbPosX + xint;
	nDstY = ((the->dwMbPosY) + yint ) * ( the->m_nCodedPicturePitch << 1 );
	nDstY += vs ? the->m_nCodedPicturePitch:0;
	fdit =  nDstY + nDstX;
	CHECK_VECTOR(fdit)

#if __MC_ADDALIGN_

	nRear8 = nDstX & 7;	
	bFalign0 = nRear8 ? FALSE : TRUE; // 
	the->m_RecInfo.bForwardAlign = bFalign0;
	if( nRear8 ){  // not align;
	
		nDstX -= nRear8;  // align;
		nRear8 <<= 3;
		nForwardLeftAlignBits0 = nRear8;
		nForwardRightAlignBits0 = 64 - nRear8;
		the->m_RecInfo.nForwardLeftAlignBits0 = nForwardLeftAlignBits0;
		the->m_RecInfo.nForwardLeftAlignBits1 = nForwardLeftAlignBits0 + 8;
		the->m_RecInfo.nForwardRightAlignBits0 = nForwardRightAlignBits0;
		the->m_RecInfo.nForwardRightAlignBits1 = nForwardRightAlignBits0 - 8;
		fdit = nDstY + nDstX;  // address aligned;
	}

#else
	the->m_RecInfo.bForwardAlign = TRUE;
#endif

	/*field based prediction*/			
	the->m_RecInfo.lfx0 = (the->m_nCodedPicturePitch << 1);
	the->m_RecInfo.lfx1 = (the->m_nCodedPicturePitch << 1);
	the->m_RecInfo.forw_mb0 = refy + fdit;
	the->m_RecInfo.ldstx = 16;
	the->m_RecInfo.dest_mb0 = the->reccoe->coey;
	the->m_RecInfo.h = 8;
	the->m_RecInfo.w = 16;

	rec_2b_1(&the->m_RecInfo);

	/* top 4 rows */
	the->m_RecInfo.lblkx = 8;
	the->m_RecInfo.blk0 = the->macro_block->coeff[0];
	the->m_RecInfo.blk1 = the->macro_block->coeff[1];
	the->m_RecInfo.lfx0 = 16;
	the->m_RecInfo.forw_mb0 = the->reccoe->coey;
	the->m_RecInfo.ldstx = 16;
	the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
	the->m_RecInfo.h = 8;
	the->m_RecInfo.w = 16;
	rec_addblock(&the->m_RecInfo);


	if(CHROMA420 == the->m_nChromaFormat) {

		vx = DIV_TRUNC_ZERO(vx,2);
		vy = DIV_TRUNC_ZERO(vy,2);
		xint = DIV_TRUNC_MIN(vx,2);
		yint = DIV_TRUNC_MIN(vy,2);
		the->m_RecInfo.fxh = HALF_PERL(xint,vx);
		the->m_RecInfo.fyh = HALF_PERL(yint,vy);

		nDstY = vs ? the->m_nChromaPitch : 0;
		nDstY += ( (the->dwMbPosY >> 1 ) + yint ) * ( the->m_nChromaPitch << 1);
		nDstX = ( the->dwMbPosX >> 1 ) + xint;

		// address align;		
#if __MC_ADDALIGN_
		nRear8 = nDstX & 7;	
		bFalign1 = nRear8 ? FALSE : TRUE;
		the->m_RecInfo.bForwardAlign = bFalign1;
		if( nRear8 ){  // not align;
		
			nDstX -= nRear8;  // align;
			nRear8 <<= 3;
			nForwardLeftAlignBitsChroma = nRear8;
			nForwardRightAlignBitsChroma = 64 - nRear8;
			the->m_RecInfo.nForwardLeftAlignBits0 = nForwardLeftAlignBitsChroma;
			the->m_RecInfo.nForwardLeftAlignBits1 = nForwardLeftAlignBitsChroma + 8;
			the->m_RecInfo.nForwardRightAlignBits0 = nForwardRightAlignBitsChroma;
			the->m_RecInfo.nForwardRightAlignBits1 = nForwardRightAlignBitsChroma - 8;
		}
#endif

		fdit = nDstY + nDstX;

		the->m_RecInfo.lfx0 = (the->m_nChromaPitch << 1);
		the->m_RecInfo.lfx1 = (the->m_nChromaPitch << 1);

		/*odd row*/
		the->m_RecInfo.forw_mb0 = refu + fdit;
		the->m_RecInfo.ldstx = 8;
		the->m_RecInfo.dest_mb0 = the->reccoe->coeuv[0];
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;

		rec_2b_1(&the->m_RecInfo);	

		the->m_RecInfo.lfx0 = 8;
		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[0];
		the->m_RecInfo.ldstx = 8;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.lblkx = 8;
		the->m_RecInfo.blk0 = the->macro_block->coeff[4];
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;
		rec_addblock(&the->m_RecInfo);

		the->m_RecInfo.lfx0 = (the->m_nChromaPitch << 1);
		the->m_RecInfo.lfx1 = (the->m_nChromaPitch << 1);
		the->m_RecInfo.forw_mb0 = refv + fdit;
		the->m_RecInfo.ldstx = 8;
		the->m_RecInfo.dest_mb0 = the->reccoe->coeuv[1];
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;

		rec_2b_1(&the->m_RecInfo);		 

		the->m_RecInfo.lfx0 = 8;
		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[1];
		the->m_RecInfo.ldstx = 8;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.lblkx = 8;
		the->m_RecInfo.blk0 = the->macro_block->coeff[5];
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;
		rec_addblock(&the->m_RecInfo);
	}


	//		form_prediction(backward_reference_frame,motion_vertical_field_select[1][1],
	//		  current_frame,0,Coded_Picture_Width<<1,Coded_Picture_Width<<1,16,8,
	//		  bx,by+8,PMV[1][1][0],PMV[1][1][1],stwtop);


	vx = the->PMV[1][1][0];
	vy = the->PMV[1][1][1];

	vs =  the->motion_vertical_field_select[1][1];
	vd = 0;

	refy = the->m_lpBackwardPicture->lpData[0];
	refv = the->m_lpBackwardPicture->lpData[2];
	refu = the->m_lpBackwardPicture->lpData[1];

	/*bot field*/
	xint = DIV_TRUNC_MIN(vx,2);
	yint = DIV_TRUNC_MIN(vy,2);
	the->m_RecInfo.fxh = HALF_PERL(xint,vx);
	the->m_RecInfo.fyh = HALF_PERL(yint,vy);

	/* the start address from prediction macroblock*/

	nDstX = the->dwMbPosX + xint;
	nDstY = ((the->dwMbPosY) + yint ) * ( the->m_nCodedPicturePitch << 1 );
	nDstY += vs ? the->m_nCodedPicturePitch:0;
	fdit =  nDstY + nDstX;
	CHECK_VECTOR(fdit)

#if __MC_ADDALIGN_

	nRear8 = nDstX & 7;	
	bFalign0 = nRear8 ? FALSE : TRUE; // 
	the->m_RecInfo.bForwardAlign = bFalign0;
	if( nRear8 ){  // not align;
	
		nDstX -= nRear8;  // align;
		nRear8 <<= 3;
		nForwardLeftAlignBits0 = nRear8;
		nForwardRightAlignBits0 = 64 - nRear8;
		the->m_RecInfo.nForwardLeftAlignBits0 = nForwardLeftAlignBits0;
		the->m_RecInfo.nForwardLeftAlignBits1 = nForwardLeftAlignBits0 + 8;
		the->m_RecInfo.nForwardRightAlignBits0 = nForwardRightAlignBits0;
		the->m_RecInfo.nForwardRightAlignBits1 = nForwardRightAlignBits0 - 8;
		fdit = nDstY + nDstX;  // address aligned;
	}

#else
	the->m_RecInfo.bForwardAlign = TRUE;
#endif

	/*field based prediction*/			
	the->m_RecInfo.lfx0 = (the->m_nCodedPicturePitch << 1);
	the->m_RecInfo.lfx1 = (the->m_nCodedPicturePitch << 1);
	the->m_RecInfo.forw_mb0 = refy + fdit;
	the->m_RecInfo.ldstx = 16;
	the->m_RecInfo.dest_mb0 = the->reccoe->coey + 16*8;
	the->m_RecInfo.h = 8;
	the->m_RecInfo.w = 16;

	rec_2b_1(&the->m_RecInfo);

	/* bot 8 rows */
	the->m_RecInfo.lblkx = 8;
	the->m_RecInfo.blk0 = the->macro_block->coeff[2];
	the->m_RecInfo.blk1 = the->macro_block->coeff[3];
	the->m_RecInfo.lfx0 = 16;
	the->m_RecInfo.forw_mb0 = the->reccoe->coey + 16*8;
	the->m_RecInfo.ldstx = 16;
	the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
	the->m_RecInfo.h = 8;
	the->m_RecInfo.w = 16;
	rec_addblock(&the->m_RecInfo);


	if(CHROMA420 == the->m_nChromaFormat) {

		vx = DIV_TRUNC_ZERO(vx,2);
		vy = DIV_TRUNC_ZERO(vy,2);
		xint = DIV_TRUNC_MIN(vx,2);
		yint = DIV_TRUNC_MIN(vy,2);
		the->m_RecInfo.fxh = HALF_PERL(xint,vx);
		the->m_RecInfo.fyh = HALF_PERL(yint,vy);

		nDstY = vs ? the->m_nChromaPitch : 0;
		nDstY += ( (the->dwMbPosY >> 1 ) + yint ) * ( the->m_nChromaPitch << 1);
		nDstX = ( the->dwMbPosX >> 1 ) + xint;

		// address align;		
#if __MC_ADDALIGN_
		nRear8 = nDstX & 7;	
		bFalign1 = nRear8 ? FALSE : TRUE;
		the->m_RecInfo.bForwardAlign = bFalign1;
		if( nRear8 ){ // not align;
		
			nDstX -= nRear8;  // align;
			nRear8 <<= 3;
			nForwardLeftAlignBitsChroma = nRear8;
			nForwardRightAlignBitsChroma = 64 - nRear8;
			the->m_RecInfo.nForwardLeftAlignBits0 = nForwardLeftAlignBitsChroma;
			the->m_RecInfo.nForwardLeftAlignBits1 = nForwardLeftAlignBitsChroma + 8;
			the->m_RecInfo.nForwardRightAlignBits0 = nForwardRightAlignBitsChroma;
			the->m_RecInfo.nForwardRightAlignBits1 = nForwardRightAlignBitsChroma - 8;
		}
#endif

		fdit = nDstY + nDstX;

		the->m_RecInfo.lfx0 = (the->m_nChromaPitch << 1);
		the->m_RecInfo.lfx1 = (the->m_nChromaPitch << 1);

		/*odd row*/
		the->m_RecInfo.forw_mb0 = refu + fdit;
		the->m_RecInfo.ldstx = 8;
		the->m_RecInfo.dest_mb0 = the->reccoe->coeuv[0] + 8*4;
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;

		rec_2b_1(&the->m_RecInfo);	

		the->m_RecInfo.lfx0 = 8;
		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[0]  + 8*4;
		the->m_RecInfo.ldstx = 8;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.lblkx = 8;
		the->m_RecInfo.blk0 = the->macro_block->coeff[4] + 8*4;
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;
		rec_addblock(&the->m_RecInfo);

		the->m_RecInfo.lfx0 = (the->m_nChromaPitch << 1);
		the->m_RecInfo.lfx1 = (the->m_nChromaPitch << 1);
		the->m_RecInfo.forw_mb0 = refv + fdit;
		the->m_RecInfo.ldstx = 8;
		the->m_RecInfo.dest_mb0 = the->reccoe->coeuv[1] + 8*4;
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;

		rec_2b_1(&the->m_RecInfo);		 

		the->m_RecInfo.lfx0 = 8;
		the->m_RecInfo.forw_mb0 = the->reccoe->coeuv[1] + 8*4;
		the->m_RecInfo.ldstx = 8;
		the->m_RecInfo.dest_mb0 = the->m_RecInfo.forw_mb0;
		the->m_RecInfo.lblkx = 8;
		the->m_RecInfo.blk0 = the->macro_block->coeff[5] + 8*4;
		the->m_RecInfo.h = 4;
		the->m_RecInfo.w = 8;
		rec_addblock(&the->m_RecInfo);
	}

}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

//  << start of rec;
static void rec_avgblock_mmx2(rec_mb_info* rmi)
{
#ifndef __MCP_INTRINSIC
	__asm
	{
		mov        esi,[rmi]
		push       ebx

		cmp        [esi]rec_mb_info.w,8  // if block width == 8, goto mb_width_16;
		je         block_width_8

;block_width_16:

		mov        eax,[esi]rec_mb_info.forw_mb0    // src0,dst;
		mov        ebx,[esi]rec_mb_info.back_mb0    // src1;
		mov        ecx,[esi]rec_mb_info.h           // height;
		mov        edx,[esi]rec_mb_info.lfx0        // the pitch;

next_row16:
		movq       mm0,[eax]
		pavgb      mm0,[ebx]
		movq       [eax],mm0
		movq       mm1,[eax+8]
		pavgb      mm1,[ebx+8]
		add        ebx,edx
		movq       [eax+8],mm1
		add        eax,edx

		movq       mm0,[eax]
		pavgb      mm0,[ebx]
		movq       [eax],mm0
		movq       mm1,[eax+8]
		pavgb      mm1,[ebx+8]
		add        ebx,edx
		movq       [eax+8],mm1
		add        eax,edx

		movq       mm0,[eax]
		pavgb      mm0,[ebx]
		movq       [eax],mm0
		movq       mm1,[eax+8]
		pavgb      mm1,[ebx+8]
		add        ebx,edx
		movq       [eax+8],mm1
		add        eax,edx

		movq       mm0,[eax]
		pavgb      mm0,[ebx]
		movq       [eax],mm0
		movq       mm1,[eax+8]
		pavgb      mm1,[ebx+8]
		add        ebx,edx
		movq       [eax+8],mm1
		add        eax,edx

		sub        ecx,4
		ja         next_row16
		jmp        over


block_width_8:

		mov        eax,[esi]rec_mb_info.forw_mb0    // src0,dst;
		mov        ebx,[esi]rec_mb_info.back_mb0    // src1;
		mov        ecx,[esi]rec_mb_info.h           // height;
		mov        edx,[esi]rec_mb_info.lfx0        // the pitch;

		sub        ebx,edx
		sub        eax,edx

next_row8:

		add        ebx,edx
		add        eax,edx
		movq       mm0,[eax]
		pavgb      mm0,[ebx]
		movq       [eax],mm0

		add        ebx,edx
		add        eax,edx
		movq       mm1,[eax]
		pavgb      mm1,[ebx]
		movq       [eax],mm1

		add        ebx,edx
		add        eax,edx
		movq       mm0,[eax]
		pavgb      mm0,[ebx]
		movq       [eax],mm0

		add        ebx,edx
		add        eax,edx
		sub        ecx,4
		movq       mm1,[eax]
		pavgb      mm1,[ebx]
		movq       [eax],mm1

		ja         next_row8

over:
		pop        ebx
		emms
	}

#else

	MM_DECLARE8;

	u8 *s0,*s1;

	s0 = rmi->forw_mb0;
	s1 = rmi->back_mb0;

	if( 16 == rmi->w ) {

		do{
			rmi->h -= 4;

			imm0 = *CONV_PM64(s0);
			imm1 = *CONV_PM64(s1);
			imm2 = *CONV_PM64(s0+8);
			imm3 = *CONV_PM64(s1+8);
			imm0 = _m_pavgb(imm0,imm1);
			imm2 = _m_pavgb(imm2,imm3);
			*CONV_PM64(s0) = imm0;
			*CONV_PM64(s1) = imm2;
			s0 += rmi->lfx0;
			s1 += rmi->lfx0;

			imm0 = *CONV_PM64(s0);
			imm1 = *CONV_PM64(s1);
			imm2 = *CONV_PM64(s0+8);
			imm3 = *CONV_PM64(s1+8);
			imm0 = _m_pavgb(imm0,imm1);
			imm2 = _m_pavgb(imm2,imm3);
			*CONV_PM64(s0) = imm0;
			*CONV_PM64(s1) = imm2;
			s0 += rmi->lfx0;
			s1 += rmi->lfx0;

			imm0 = *CONV_PM64(s0);
			imm1 = *CONV_PM64(s1);
			imm2 = *CONV_PM64(s0+8);
			imm3 = *CONV_PM64(s1+8);
			imm0 = _m_pavgb(imm0,imm1);
			imm2 = _m_pavgb(imm2,imm3);
			*CONV_PM64(s0) = imm0;
			*CONV_PM64(s1) = imm2;
			s0 += rmi->lfx0;
			s1 += rmi->lfx0;

			imm0 = *CONV_PM64(s0);
			imm1 = *CONV_PM64(s1);
			imm2 = *CONV_PM64(s0+8);
			imm3 = *CONV_PM64(s1+8);
			imm0 = _m_pavgb(imm0,imm1);
			imm2 = _m_pavgb(imm2,imm3);
			*CONV_PM64(s0) = imm0;
			*CONV_PM64(s1) = imm2;
			s0 += rmi->lfx0;
			s1 += rmi->lfx0;

		}while( rmi->h );
	}
	else {
		do{
			rmi->h -= 4;

			imm0 = *CONV_PM64(s0);
			imm1 = *CONV_PM64(s1);
			imm0 = _m_pavgb(imm0,imm1);
			*CONV_PM64(s0) = imm0;
			s0 += rmi->lfx0;
			s1 += rmi->lfx0;

			imm0 = *CONV_PM64(s0);
			imm1 = *CONV_PM64(s1);
			imm0 = _m_pavgb(imm0,imm1);
			*CONV_PM64(s0) = imm0;
			s0 += rmi->lfx0;
			s1 += rmi->lfx0;

			imm0 = *CONV_PM64(s0);
			imm1 = *CONV_PM64(s1);
			imm0 = _m_pavgb(imm0,imm1);
			*CONV_PM64(s0) = imm0;
			s0 += rmi->lfx0;
			s1 += rmi->lfx0;

			imm0 = *CONV_PM64(s0);
			imm1 = *CONV_PM64(s1);
			imm0 = _m_pavgb(imm0,imm1);
			*CONV_PM64(s0) = imm0;
			s0 += rmi->lfx0;
			s1 += rmi->lfx0;

		}while( rmi->h );
	}

	_m_empty();

#endif

}



// GET_8_FROM_16


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

static void rec_2b_1_mmx2(rec_mb_info* rmi)
{

#ifndef __MCP_INTRINSIC

	s32 i;

	__asm
	{
		mov        esi,[rmi]

		push       ebx

		cmp        [esi]rec_mb_info.w,8  // if block width == 8, goto mb_width_16;
		je         block_width_8

;block_width_16:

		cmp        [esi]rec_mb_info.bForwardAlign,1
		je         block_width_16_align

;block_width_16_unalign:

		mov        ecx,[esi]rec_mb_info.h
		mov        [i],ecx

		cmp        [esi]rec_mb_info.fxh,0
		jne        block_width_16_unalign_h10

		cmp        [esi]rec_mb_info.fyh,0
		jne        block_width_16_unalign_h01

		mov        eax,[esi]rec_mb_info.forw_mb0
		mov        edi,[esi]rec_mb_info.dest_mb0  //d0
		movq       mm5,[esi]rec_mb_info.nForwardLeftAlignBits0  // left >> nl;
		movq       mm6,[esi]rec_mb_info.nForwardRightAlignBits0 // right << nr;
		pxor       mm7,mm7

		sub        eax,[esi]rec_mb_info.lfx1      // inc f0
		sub        edi,[esi]rec_mb_info.ldstx     // inc dst;

block_width_16_unalign_hh00:       

		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;
		sub        [i],1 
		movq       mm0,[eax]     // 3210xxxx;
		movq       mm1,[eax+8]   // ba987654;
		psrlq      mm0,mm5       // ____3210;
		movq       mm3,mm1       // dup ba987654;
		psllq      mm1,mm6       // 7654____;
		movq       mm2,[eax+16]  // xxxxfedc;
		psrlq      mm3,mm5       // ____ba98;
		por        mm0,mm1       // 76543210;
		psllq      mm2,mm6       // fedc____;
		movq       [edi],mm0     // output dst 76543210;
		por        mm2,mm3       // fedcba98;
		movq       [edi+8],mm2                    // output dst fedcba98;

		jg         block_width_16_unalign_hh00

		jmp        over

block_width_16_unalign_h01:

		mov        eax,[esi]rec_mb_info.forw_mb0
		mov        edi,[esi]rec_mb_info.dest_mb0  //d0
		mov        edx,[esi]rec_mb_info.lfx0      // pitch;

		sub        eax,[esi]rec_mb_info.lfx1      // inc f0
		sub        edi,[esi]rec_mb_info.ldstx     // inc dst;

block_width_16_unalign_hh01:          

		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;
		sub        [i],1

		movq       mm5,[esi]rec_mb_info.nForwardLeftAlignBits0  // left >> nl;
		movq       mm6,[esi]rec_mb_info.nForwardRightAlignBits0 // right << nr;
		movq       mm0,[eax]     // 3210xxxx;
		movq       mm1,[eax+8]   // ba987654;
		psrlq      mm0,mm5       // ____3210;
		movq       mm3,mm1       // dup ba987654;
		psllq      mm1,mm6       // 7654____;
		movq       mm2,[eax+16]  // xxxxfedc;
		psrlq      mm3,mm5       // ____ba98;
		por        mm0,mm1       // top 76543210;   mm0;
		psllq      mm2,mm6       // fedc____;
		movq       mm1,[eax+edx]     // bot 3210xxxx;
		por        mm2,mm3       // top fedcba98;   mm2;			  
		movq       mm3,[eax+edx+8]   // bot ba987654;
		psrlq      mm1,mm5           // bot ____3210;
		movq       mm7,mm3           // dup bot ba987654;
		psllq      mm3,mm6           // 7654____;
		movq       mm4,[eax+edx+16]  // bot xxxxfedc;
		psrlq      mm7,mm5           // bot  ____ba98;
		por        mm1,mm3           // bot 76543210;   mm1;
		psllq      mm4,mm6           // bot fedc____;
		por        mm4,mm7           // bot fedcba98;   mm4;
		pavgb      mm0,mm1
		movq       [edi],mm0                // output 76543210;
		pavgb      mm2,mm4
		movq       [edi+8],mm2                    // output fedcba98;

		jg         block_width_16_unalign_hh01

		jmp        over

block_width_16_unalign_h10:

		cmp        [esi]rec_mb_info.fyh,0
		jne        block_width_16_unalign_h11

		mov        eax,[esi]rec_mb_info.forw_mb0
		mov        edi,[esi]rec_mb_info.dest_mb0  //d0
		sub        eax,[esi]rec_mb_info.lfx1      // inc f0
		sub        edi,[esi]rec_mb_info.ldstx     // inc dst;

block_width_16_unalign_hh10:          

		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;
		sub        [i],1                          // ecx is not used in src pitch; 

		movq       mm5,[esi]rec_mb_info.nForwardLeftAlignBits0  // left >> nl;
		movq       mm6,[esi]rec_mb_info.nForwardRightAlignBits0 // right << nr;
		movq       mm0,[eax]     // 3210xxxx;
		movq       mm1,[eax+8]   // ba987654; 
		movq       mm4,mm0       // dup 3210xxxx;
		movq       mm7,mm1       // dup ba987654;
		movq       mm3,mm1       // dup ba987654;
		psrlq      mm0,mm5       // ____3210;
		psllq      mm1,mm6       // 7654____;
		movq       mm2,[eax+16]  // xxxgfedc;
		psrlq      mm3,mm5       // ____ba98;
		por        mm0,mm1       // 76543210; mm0;
		psllq      mm2,mm6       // fedc____;  
		movq       mm5,[esi]rec_mb_info.nForwardLeftAlignBits1  // left >> nl;
		por        mm2,mm3       // fedcba98; mm2;
		movq       mm6,[esi]rec_mb_info.nForwardRightAlignBits1 // right << nr;
		movq       mm3,[eax+16]       // xxxgfedc;
		movq       mm1,mm7            // dup ba987654;
		psrlq      mm4,mm5            // _____321;
		psllq      mm7,mm6            // 87654___;
		psrlq      mm1,mm5            // _____ba9;
		por        mm4,mm7            // 87654321; mm4;
		psllq      mm3,mm6            // gfedc___;  

		por        mm1,mm3            // gfedcba9; mm1;
		pavgb      mm0,mm4
		movq       [edi],mm0                // output 76543210;
		pavgb      mm2,mm1
		movq       [edi+8],mm2                    // output fedcba98;

		jg         block_width_16_unalign_hh10

		jmp        over

block_width_16_unalign_h11:

		mov        eax,[esi]rec_mb_info.forw_mb0
		mov        edi,[esi]rec_mb_info.dest_mb0  //d0
		mov        edx,[esi]rec_mb_info.lfx0      // pitch;
		sub        eax,[esi]rec_mb_info.lfx1          // inc f0
		sub        edi,[esi]rec_mb_info.ldstx         // inc dst;

block_width_16_unalign_hh11:          

		add        eax,[esi]rec_mb_info.lfx1          // inc f0
		add        edi,[esi]rec_mb_info.ldstx         // inc dst;
		sub        [i],1

		movq       mm0,[eax]
		movq       [esi+64]rec_mb_info.nTemp,mm0
		movq       mm1,[eax+8]
		movq       [esi+72]rec_mb_info.nTemp,mm1
		movq       mm2,[eax+16]
		movq       [esi+80]rec_mb_info.nTemp,mm2
		GET_16_FROM_24([esi]rec_mb_info.nForwardLeftAlignBits0,[esi]rec_mb_info.nForwardRightAlignBits0,64,0)
		GET_16_FROM_24([esi]rec_mb_info.nForwardLeftAlignBits1,[esi]rec_mb_info.nForwardRightAlignBits1,64,16)

		movq       mm0,[eax+edx]
		movq       [esi+64]rec_mb_info.nTemp,mm0
		movq       mm1,[eax+edx+8]
		movq       [esi+72]rec_mb_info.nTemp,mm1
		movq       mm2,[eax+edx+16]
		movq       [esi+80]rec_mb_info.nTemp,mm2
		GET_16_FROM_24([esi]rec_mb_info.nForwardLeftAlignBits0,[esi]rec_mb_info.nForwardRightAlignBits0,64,32)
		GET_16_FROM_24([esi]rec_mb_info.nForwardLeftAlignBits1,[esi]rec_mb_info.nForwardRightAlignBits1,64,48)

		// begin to do 4 * 8 avg;
		movq       mm0,[esi]rec_mb_info.nTemp         // top 76543210;  mm0;
		movq       mm1,[esi+8]rec_mb_info.nTemp       // top fedcba98
		pavgb      mm0,[esi+16]rec_mb_info.nTemp      // top 87654321
		pavgb      mm1,[esi+(16+8)]rec_mb_info.nTemp    // top gfedcba9
		pavgb      mm0,[esi+32]rec_mb_info.nTemp      // bot 76543210;  mm0;
		pavgb      mm1,[esi+(32+8)]rec_mb_info.nTemp    // bot fedcba98
		pavgb      mm0,[esi+(32+16)]rec_mb_info.nTemp   // bot 87654321
		movq       [edi],mm0                          // output 76543210;
		pavgb      mm1,[esi+(32+16+8)]rec_mb_info.nTemp // bot gfedcba9
		movq       [edi+8],mm1                        // output fedcba98;
		jg         block_width_16_unalign_hh11

		jmp        over


block_width_16_align:

		mov        ecx,[esi]rec_mb_info.h
		mov        [i],ecx

		cmp        [esi]rec_mb_info.fxh,0
		jne        block_width_16_align_h10

		cmp        [esi]rec_mb_info.fyh,0
		jne        block_width_16_align_h01

		mov        eax,[esi]rec_mb_info.forw_mb0
		mov        edi,[esi]rec_mb_info.dest_mb0  //d0
		sub        eax,[esi]rec_mb_info.lfx1      // inc f0
		sub        edi,[esi]rec_mb_info.ldstx     // inc dst;

block_width_16_align_hh00:       

		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;
		movq       mm0,[eax]     // 76543210;
		movq       mm2,[eax+8]   // fedcba98;
		movq       [edi],mm0     // output dst 76543210;
		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		movq       [edi+8],mm2                    // output dst fedcba98;
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;

		movq       mm0,[eax]     // 76543210;
		movq       mm2,[eax+8]   // fedcba98;
		movq       [edi],mm0     // output dst 76543210;
		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		movq       [edi+8],mm2                    // output dst fedcba98;
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;

		movq       mm0,[eax]     // 76543210;
		movq       mm2,[eax+8]   // fedcba98;
		movq       [edi],mm0     // output dst 76543210;
		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		movq       [edi+8],mm2                    // output dst fedcba98;
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;

		sub        [i],4 
		movq       mm0,[eax]     // 76543210;
		movq       [edi],mm0     // output dst 76543210;
		movq       mm2,[eax+8]   // fedcba98;
		movq       [edi+8],mm2                    // output dst fedcba98;

		jg         block_width_16_align_hh00

		jmp        over

block_width_16_align_h01:

		mov        eax,[esi]rec_mb_info.forw_mb0
		mov        edi,[esi]rec_mb_info.dest_mb0  //d0
		mov        edx,[esi]rec_mb_info.lfx0     // pitch;
		sub        eax,[esi]rec_mb_info.lfx1      // inc f0
		sub        edi,[esi]rec_mb_info.ldstx     // inc dst;

block_width_16_align_hh01:          

		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;
		movq       mm0,[eax]           // top 76543210;
		movq       mm2,[eax+8]         // top fedcba98;
		movq       mm1,[eax+edx]       // bot 76543210;
		movq       mm4,[eax+edx+8]     // bot fedcba98;
		pavgb      mm0,mm1
		movq       [edi],mm0                // output 76543210;
		pavgb      mm2,mm4
		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		movq       [edi+8],mm2                    // output fedcba98;
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;
		sub        [i],2
		movq       mm0,[eax]           // top 76543210;
		movq       mm2,[eax+8]         // top fedcba98;
		movq       mm1,[eax+edx]       // bot 76543210;
		movq       mm4,[eax+edx+8]     // bot fedcba98;
		pavgb      mm0,mm1
		movq       [edi],mm0                // output 76543210;
		pavgb      mm2,mm4
		movq       [edi+8],mm2                    // output fedcba98;

		jg         block_width_16_align_hh01

		jmp        over

block_width_16_align_h10:

		cmp        [esi]rec_mb_info.fyh,0
		jne        block_width_16_align_h11

		mov        eax,[esi]rec_mb_info.forw_mb0
		mov        edi,[esi]rec_mb_info.dest_mb0  //d0
		sub        eax,[esi]rec_mb_info.lfx1      // inc f0
		sub        edi,[esi]rec_mb_info.ldstx     // inc dst;

block_width_16_align_hh10:          

		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;
		sub        [i],1    // ecx is not used in src pitch; 
		movq       mm0,[eax]     // 76543210;  mm0
		movq       mm2,[eax+8]   // fedcba98;  mm2;
		movq       mm1,mm0       // dup byte1;
		movq       mm3,mm2       // dup middle;
		movq       mm5,mm2       // dup middle;
		movq       mm4,[eax+16]  // xxxxxxxg;
		psrlq      mm1,8         // _7654321;
		psllq      mm3,56        // 8_______;
		psrlq      mm5,8         // _fedcba9;
		psllq      mm4,56        // g_______;
		por        mm1,mm3       // 87654321;  mm1;
		por        mm4,mm5       // gfdecba9;  mm4;

		pavgb      mm0,mm1
		movq       [edi],mm0                // output 76543210;
		pavgb      mm2,mm4
		movq       [edi+8],mm2                    // output fedcba98;

		jg         block_width_16_align_hh10

		jmp        over

block_width_16_align_h11:

		mov        eax,[esi]rec_mb_info.forw_mb0
		mov        edi,[esi]rec_mb_info.dest_mb0  //d0
		mov        edx,[esi]rec_mb_info.lfx0      // pitch;
		sub        eax,[esi]rec_mb_info.lfx1      // inc f0
		sub        edi,[esi]rec_mb_info.ldstx     // inc dst;

block_width_16_align_hh11:          

		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;
		sub        [i],1
		movq       mm0,[eax]     // top 76543210;
		movq       mm2,[eax+8]   // top fedcba98; 
		movq       [esi]rec_mb_info.nTemp,mm0     // save top 76543210;
		movq       mm4,[eax+16]  // top xxxxxxxg;
		movq       mm1,mm0       // dup byte1;
		movq       mm3,mm2       // dup byte8;
		movq       mm5,mm2       // dup middle;
		movq       [esi+8]rec_mb_info.nTemp,mm2    // save top fedcba98;

		psrlq      mm1,8         // _7654321;
		psllq      mm3,56        // 8_______;
		psrlq      mm5,8         // _fedcba9;
		psllq      mm4,56        // g_______;
		por        mm1,mm3       // 87654321;  mm1;
		por        mm4,mm5       // gfdecba9;  mm4;
		movq       [esi+16]rec_mb_info.nTemp,mm1    // save top 87654321;

		// begin to load bot data;
		movq       mm0,[eax+edx]     // bot 76543210;
		movq       [esi+24]rec_mb_info.nTemp,mm4    // save top gfedcba9;
		movq       mm2,[eax+edx+8]   // bot fedcba98; 
		movq       [esi+32]rec_mb_info.nTemp,mm0     // save bot 76543210;
		movq       mm4,[eax+edx+16]  // bot xxxxxxxg;
		movq       mm1,mm0       // dup byte1;
		movq       mm3,mm2       // dup byte8;
		movq       mm5,mm2       // dup middle;
		movq       [esi+32+8]rec_mb_info.nTemp,mm2    // save bot fedcba98;

		psrlq      mm1,8         // _7654321;
		psllq      mm3,56        // 8_______;
		psrlq      mm5,8         // _fedcba9;
		psllq      mm4,56        // g_______;
		por        mm1,mm3       // bot 87654321;  mm1;
		por        mm4,mm5       // bot gfdecba9;  mm4;
		movq       [esi+(32+16)],mm1
		movq       [esi+(32+16+8)],mm4

		movq       mm0,[esi]rec_mb_info.nTemp           // top 76543210;  mm0;
		movq       mm1,[esi+8]rec_mb_info.nTemp         // top fedcba98
		pavgb      mm0,[esi+16]rec_mb_info.nTemp        // top 87654321
		pavgb      mm1,[esi+(16+8)]rec_mb_info.nTemp    // top gfedcba9
		pavgb      mm0,[esi+32]rec_mb_info.nTemp        // bot 76543210;  mm0;
		pavgb      mm1,[esi+(32+8)]rec_mb_info.nTemp    // bot fedcba98
		pavgb      mm0,[esi+(32+16)]rec_mb_info.nTemp   // bot 87654321
		movq       [edi],mm0                            // output 76543210;
		pavgb      mm1,[esi+(32+16+8)]rec_mb_info.nTemp // bot gfedcba9
		movq       [edi+8],mm1                          // output fedcba98;
		jg         block_width_16_align_hh11

		jmp        over

block_width_8:

		cmp        [esi]rec_mb_info.bForwardAlign,1
		je         block_width_8_align


;block_width_8_unalign:

		mov        ecx,[esi]rec_mb_info.h
		mov        [i],ecx

		cmp        [esi]rec_mb_info.fxh,0
		jne        block_width_8_unalign_h10

		cmp        [esi]rec_mb_info.fyh,0
		jne        block_width_8_unalign_h01

		mov        eax,[esi]rec_mb_info.forw_mb0
		mov        edi,[esi]rec_mb_info.dest_mb0  //d0
		movq       mm5,[esi]rec_mb_info.nForwardLeftAlignBits0  // left >> nl;
		movq       mm6,[esi]rec_mb_info.nForwardRightAlignBits0 // right << nr;
		sub        eax,[esi]rec_mb_info.lfx1      // inc f0
		sub        edi,[esi]rec_mb_info.ldstx     // inc dst;

block_width_8_unalign_hh00:       

		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;
		movq       mm0,[eax]     // left of  3210xxxx;
		movq       mm1,[eax+8]   // right of ba987654;
		psllq      mm1,mm6       // 7654____;
		psrlq      mm0,mm5       // ____3210;
		por        mm0,mm1       // forw0; 76543210;
		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		movq       mm2,[eax]     // left of  3210xxxx;
		movq       [edi],mm0     // output dst 76543210;
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;
		sub        ecx,2

		movq       mm0,mm2       // dup  3210xxxx;
		movq       mm1,[eax+8]   // right of ba987654;
		psllq      mm1,mm6       // 7654____;
		psrlq      mm0,mm5       // ____3210;
		por        mm0,mm1       // forw0; 76543210;
		movq       [edi],mm0     // output dst 76543210;
		jg         block_width_8_unalign_hh00

		jmp        over

block_width_8_unalign_h01:

		mov        eax,[esi]rec_mb_info.forw_mb0
		mov        edi,[esi]rec_mb_info.dest_mb0  //d0
		mov        ecx,[esi]rec_mb_info.lfx0      // pitch;
		sub        eax,[esi]rec_mb_info.lfx1// inc f0
		sub        edi,[esi]rec_mb_info.ldstx     // inc dst;

block_width_8_unalign_hh01:          

		add        eax,[esi]rec_mb_info.lfx1// inc f0
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;
		sub        [i],1
		movq       mm5,[esi]rec_mb_info.nForwardLeftAlignBits0  // left >> nl;
		movq       mm6,[esi]rec_mb_info.nForwardRightAlignBits0 // right << nr;
		movq       mm0,[eax]     // 3210xxxx;
		movq       mm1,[eax+8]   // xxxx7654;
		psrlq      mm0,mm5       // ____3210;
		psllq      mm1,mm6       // 7654____;
		movq       mm2,[eax+ecx]     // bot 3210xxxx;
		movq       mm3,[eax+ecx+8]   // bot xxxx7654;
		psllq      mm3,mm6           // 7654____;
		psrlq      mm2,mm5           // bot ____3210;
		por        mm2,mm3           // bot; 76543210;   mm2;
		por        mm0,mm1           // top; 76543210;   mm0;
		pavgb      mm0,mm2
		movq       [edi],mm0                // output 76543210;
		jg         block_width_8_unalign_hh01

		jmp        over

block_width_8_unalign_h10:

		cmp        [esi]rec_mb_info.fyh,0
		jne        block_width_8_unalign_h11

		mov        eax,[esi]rec_mb_info.forw_mb0
		mov        edi,[esi]rec_mb_info.dest_mb0  //d0
		sub        eax,[esi]rec_mb_info.lfx1      // inc f0
		sub        edi,[esi]rec_mb_info.ldstx     // inc dst;

block_width_8_unalign_hh10:          

		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;
		dec        ecx    // ecx is not used in src pitch; 
		movq       mm5,[esi]rec_mb_info.nForwardLeftAlignBits0  // left >> nl;
		movq       mm6,[esi]rec_mb_info.nForwardRightAlignBits0 // right << nr;
		movq       mm0,[eax]     // 3210xxxx;
		movq       mm1,[eax+8]   // xxxx7654; 
		movq       mm4,mm0       // dup byte1;
		movq       mm7,mm1       // dup byte8;
		movq       mm3,mm1       // dup middle;
		psrlq      mm0,mm5       // ____3210;
		psllq      mm1,mm6       // 7654____;
		movq       mm5,[esi]rec_mb_info.nForwardLeftAlignBits1  // left >> nl;
		por        mm0,mm1       // forw0; 76543210; mm0;
		movq       mm6,[esi]rec_mb_info.nForwardRightAlignBits1 // right << nr;
		movq       mm1,mm7            // dup middle, xxx87654;
		psrlq      mm4,mm5            // _____321;
		psllq      mm7,mm6            // 87654___;
		por        mm4,mm7            // 87654321; mm4;			
		pavgb      mm0,mm4			
		movq       [edi],mm0                // output 76543210;

		jg         block_width_8_unalign_hh10

		jmp        over

block_width_8_unalign_h11:

		mov        eax,[esi]rec_mb_info.forw_mb0
		mov        edi,[esi]rec_mb_info.dest_mb0  //d0
		mov        ecx,[esi]rec_mb_info.lfx0      // pitch;
		sub        eax,[esi]rec_mb_info.lfx1      // inc f0
		sub        edi,[esi]rec_mb_info.ldstx     // inc dst;

block_width_8_unalign_hh11:     
///////////////   

		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;
		sub        [i],1
		movq       mm5,[esi]rec_mb_info.nForwardLeftAlignBits0  // left >> nl;
		movq       mm6,[esi]rec_mb_info.nForwardRightAlignBits0 // right << nr;
		movq       mm0,[eax]     // top 3210xxxx;
		movq       mm1,[eax+8]   // top xxx87654; 
		movq       mm4,mm0       // dup byte1;
		movq       mm7,mm1       // dup byte8;
		psrlq      mm0,mm5       // ____3210;
		psllq      mm1,mm6       // 7654____;
		movq       mm2,[esi]rec_mb_info.nForwardLeftAlignBits1  // left >> nl;
		por        mm0,mm1       // top; 76543210; mm0;
		movq       mm3,[esi]rec_mb_info.nForwardRightAlignBits1 // right << nr;
		movq       [esi]rec_mb_info.nTemp,mm0                              // save top 76543210;
		psrlq      mm4,mm2            // _____321;
		psllq      mm7,mm3            // 87654___;
		movq       mm0,[eax+ecx]      //  bot 3210xxxx;
		por        mm4,mm7            // top; 87654321; mm4;
		movq       mm1,[eax+ecx+8]   //  bot xxx87654; 
		movq       [esi+16]rec_mb_info.nTemp,mm4                           // save top 87654321;	

		// begin to load bot data;
		movq       mm4,mm0       // dup byte1;
		movq       mm7,mm1       // dup byte8;
		psrlq      mm0,mm5       // bot ____3210;
		psllq      mm1,mm6       // bot 7654____;
		psrlq      mm4,mm2       // _____321;
		psllq      mm7,mm3       // 87654___;
		por        mm0,mm1       // bot 76543210; mm0;

		// begin to do 4 * 8 avg;
		por        mm4,mm7                                // bot 87654321; mm4;
		pavgb      mm4,[esi+16]rec_mb_info.nTemp          // top + bot 87654321; mm4;
		pavgb      mm0,[esi]rec_mb_info.nTemp             // top + bot 76543210; mm0;
		pavgb      mm0,mm4

		movq       [edi],mm0                // output 76543210;
		jg         block_width_8_unalign_hh11

		jmp        over


block_width_8_align:

		mov        ecx,[esi]rec_mb_info.h
		mov        [i],ecx

		cmp        [esi]rec_mb_info.fxh,0
		jne        block_width_8_align_h10

		cmp        [esi]rec_mb_info.fyh,0
		jne        block_width_8_align_h01

		mov        eax,[esi]rec_mb_info.forw_mb0
		mov        edi,[esi]rec_mb_info.dest_mb0  //d0

block_width_8_align_hh00:       

		movq       mm0,[eax]     // 76543210;
		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		movq       [edi],mm0     // output dst 76543210;
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;

		movq       mm0,[eax]     // 76543210;
		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		movq       [edi],mm0     // output dst 76543210;
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;

		movq       mm0,[eax]     // 76543210;
		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		movq       [edi],mm0     // output dst 76543210;
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;

		movq       mm0,[eax]     // 76543210;
		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		movq       [edi],mm0     // output dst 76543210;
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;

		sub        ecx,4
		jg         block_width_8_align_hh00

		jmp        over

block_width_8_align_h01:

		mov        eax,[esi]rec_mb_info.forw_mb0
		mov        edi,[esi]rec_mb_info.dest_mb0  //d0
		mov        ecx,[esi]rec_mb_info.lfx0      // pitch;

		sub        eax,[esi]rec_mb_info.lfx1      // inc f0
		sub        edi,[esi]rec_mb_info.ldstx     // inc dst;

block_width_8_align_hh01:          

		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;
		movq       mm0,[eax]           // top 76543210;
		pavgb      mm0,[eax+ecx] 
		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		movq       [edi],mm0                // output 76543210;
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;
		sub        [i],2

		movq       mm0,[eax]           // top 76543210;
		pavgb      mm0,[eax+ecx]
		movq       [edi],mm0                // output 76543210;
		jg         block_width_8_align_hh01

		jmp        over

block_width_8_align_h10:

		cmp        [esi]rec_mb_info.fyh,0
		jne        block_width_8_align_h11

		mov        eax,[esi]rec_mb_info.forw_mb0
		mov        edi,[esi]rec_mb_info.dest_mb0  //d0
		sub        eax,[esi]rec_mb_info.lfx1      // inc f0
		sub        edi,[esi]rec_mb_info.ldstx     // inc dst;			

block_width_8_align_hh10:          

		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;			
		dec        ecx    // ecx is not used in src pitch; 
		movq       mm0,[eax]     // 76543210;  mm0
		movq       mm2,[eax+8]   // xxxxxxx8;  mm2;
		movq       mm1,mm0       // dup byte1;
		psllq      mm2,56        // 8_______;
		psrlq      mm1,8         // _7654321;
		por        mm1,mm2       // 87654321;  mm1;
		pavgb      mm0,mm1
		movq       [edi],mm0                // output 76543210;
		jg         block_width_8_align_hh10

		jmp        over

block_width_8_align_h11:

		mov        eax,[esi]rec_mb_info.forw_mb0
		mov        edi,[esi]rec_mb_info.dest_mb0  //d0
		mov        ecx,[esi]rec_mb_info.lfx0     // pitch;
		sub        eax,[esi]rec_mb_info.lfx1      // inc f0
		sub        edi,[esi]rec_mb_info.ldstx     // inc dst;

block_width_8_align_hh11:          

		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;
		sub        [i],1
		movq       mm0,[eax]     // top 76543210;
		movq       mm2,[eax+8]   // top xxxxxxx8; 
		movq       [esi]rec_mb_info.nTemp,mm0     // save top 76543210;
		movq       mm1,mm0       // dup byte1;
		psllq      mm2,56        // 8_______;
		psrlq      mm1,8         // _7654321;
		movq       mm0,[eax+ecx]     // bot 76543210;
		por        mm1,mm2       // top 87654321;  mm1;
		movq       mm2,[eax+ecx+8]   // bot xxxxxxx8; 

		// begin to load bot data;
		movq       mm3,mm0       // dup byte1;
		psllq      mm2,56        // 8_______;
		psrlq      mm3,8         // _7654321;
		por        mm3,mm2       // bot 87654321;  mm3;

		// begin to do 4 * 8 avg;
		pavgb      mm0,mm1                        // avg( bot 87654321 , top 87654321 )
		pavgb      mm0,mm3                        // avg( mm0, bot 87654321)
		pavgb      mm0,[esi]rec_mb_info.nTemp     // avg( mm0, top 76543210;

		movq       [edi],mm0                      // output 76543210;
		jg         block_width_8_align_hh11

over:   
		pop       ebx
		emms
	}


#else

	MM_DECLARE8;

	s32 h;
	u8* f0, *d0;

	h = rmi->h;
	f0 = rmi->forw_mb0;
	d0 = rmi->dest_mb0;

	if( 16 == rmi->w ) {

		if( !rmi->bForwardAlign ) {
			if( !rmi->fxh ) {
				if( !rmi->fyh ) {

					//block_width_16_unalign_h00
					imm5 = *CONV_PM64(&rmi->nForwardLeftAlignBits0);
					imm6 = *CONV_PM64(&rmi->nForwardRightAlignBits0);
					imm7 = _mm_setzero_si64();

					do{
						h --;
						imm0 = *CONV_PM64(f0);
						imm1 = *CONV_PM64(f0+8);
						imm0 = _m_psrlq(imm0,imm5);
						imm3 = imm1;
						imm1 = _m_psllq(imm1,imm6);
						imm2 = *CONV_PM64(f0 + 16);
						imm3 = _m_psrlq(imm3,imm5);
						imm0 = _m_por(imm0,imm1);
						imm2 = _m_psllq(imm2,imm6);
						*CONV_PM64(d0) = imm0;
						imm2 = _m_por(imm2,imm3);
						f0 += rmi->lfx1;
						*CONV_PM64(d0+8) = imm2;
						d0 += rmi->ldstx;
					}while(h);

				}
				else {
					//block_width_16_unalign_h01

					do{
						imm5 = *CONV_PM64(&rmi->nForwardLeftAlignBits0);
						imm6 = *CONV_PM64(&rmi->nForwardRightAlignBits0);
						imm0 = *CONV_PM64(f0);
						imm1 = *CONV_PM64(f0+8);
						imm0 = _m_psrlq(imm0,imm5);
						imm3 = imm1;
						imm1 = _m_psllq(imm1,imm6);
						imm2 = *CONV_PM64(f0 + 16);
						imm3 = _m_psrlq(imm3,imm5);
						imm0 = _m_por(imm0,imm1);
						imm2 = _m_psllq(imm2,imm6);
						imm1 = *CONV_PM64(f0 + rmi->lfx0);
						imm2 = _m_por(imm2,imm3);
						imm3 = *CONV_PM64(f0 + rmi->lfx0 + 8);
						imm1 = _m_psrlq(imm1,imm5);
						imm7 = imm3;
						imm3 = _m_psllq(imm3,imm6);
						imm4 = *CONV_PM64(f0 + rmi->lfx0 + 16);
						imm7 = _m_psrlq(imm7,imm5);
						imm1 = _m_por(imm1,imm3);
						imm4 = _m_por(imm4,imm7);
						imm0 = _m_pavgb(imm0,imm1);
						h --;
						*CONV_PM64(d0) = imm0;
						imm2 = _m_pavgb(imm2,imm4);
						f0 += rmi->lfx1;
						*CONV_PM64(d0+8) = imm2;
						d0 += rmi->ldstx;

					}while(h);
				}
			}
			else if ( !rmi->fyh ) {
				//block_width_16_unalign_h10

				do{
					imm5 = *CONV_PM64(&rmi->nForwardLeftAlignBits0);
					imm6 = *CONV_PM64(&rmi->nForwardRightAlignBits0);
					imm0 = *CONV_PM64(f0);
					imm1 = *CONV_PM64(f0+8);
					imm4 = imm0;
					imm7 = imm1;
					imm3 = imm1;
					imm0 = _m_psrlq(imm0,imm5);
					imm1 = _m_psllq(imm1,imm6);
					imm2 = *CONV_PM64(f0 + 16);
					imm3 = _m_psrlq(imm3,imm5);
					imm0 = _m_por(imm0,imm1);
					imm2 = _m_psllq(imm2,imm6);
					imm5 = *CONV_PM64(&rmi->nForwardLeftAlignBits1);
					imm2 = _m_por(imm2,imm3);
					imm6 = *CONV_PM64(&rmi->nForwardRightAlignBits1);
					imm3 = *CONV_PM64(f0 + 16);
					imm1 = imm7;
					imm4 = _m_psrlq(imm4,imm5);
					imm7 = _m_psllq(imm7,imm6);
					imm1 = _m_psrlq(imm1,imm5);
					imm4 = _m_por(imm4,imm7);
					imm3 = _m_psllq(imm3,imm6);
					imm1 = _m_por(imm1,imm3);
					imm0 = _m_pavgb(imm0,imm4);
					h --;
					*CONV_PM64(d0) = imm0;
					imm2 = _m_pavgb(imm2,imm1);
					f0 += rmi->lfx1;
					*CONV_PM64(d0+8) = imm2;
					d0 += rmi->ldstx;

				}while(h);

			}
			else{
				//block_width_16_unalign_h11

				do{
					imm0 = *CONV_PM64(f0);
					imm1 = *CONV_PM64(f0+8);
					imm2 = *CONV_PM64(f0+16);
					*CONV_PM64(rmi->nTemp+8) = imm0;
					*CONV_PM64(rmi->nTemp+9) = imm1;
					*CONV_PM64(rmi->nTemp+10) = imm2;
					GET_16_FROM_24(&rmi->nForwardLeftAlignBits0,&rmi->nForwardRightAlignBits0,64,0)
					GET_16_FROM_24(&rmi->nForwardLeftAlignBits1,&rmi->nForwardRightAlignBits1,64,16)

					imm0 = *CONV_PM64(f0+rmi->lfx1);
					imm1 = *CONV_PM64(f0+rmi->lfx1+8);
					imm2 = *CONV_PM64(f0+rmi->lfx1+16);
					*CONV_PM64(rmi->nTemp+8) = imm0;
					*CONV_PM64(rmi->nTemp+9) = imm1;
					*CONV_PM64(rmi->nTemp+10) = imm2;
					GET_16_FROM_24(&rmi->nForwardLeftAlignBits0,&rmi->nForwardRightAlignBits0,64,32)
					GET_16_FROM_24(&rmi->nForwardLeftAlignBits1,&rmi->nForwardRightAlignBits1,64,48)

					imm0 = *CONV_PM64(rmi->nTemp);
					imm1 = *CONV_PM64(rmi->nTemp+1);
					imm2 = *CONV_PM64(rmi->nTemp+2);
					imm3 = *CONV_PM64(rmi->nTemp+3);
					imm0 = _m_pavgb(imm0,imm2);
					imm1 = _m_pavgb(imm1,imm3);
					imm2 = *CONV_PM64(rmi->nTemp+4);
					imm3 = *CONV_PM64(rmi->nTemp+5);
					imm0 = _m_pavgb(imm0,imm2);
					imm1 = _m_pavgb(imm1,imm3);
					imm2 = *CONV_PM64(rmi->nTemp+6);
					imm3 = *CONV_PM64(rmi->nTemp+7);
					imm0 = _m_pavgb(imm0,imm2);
					imm1 = _m_pavgb(imm1,imm3);
					h --;
					*CONV_PM64(d0) = imm0;
					f0 += rmi->lfx1;
					*CONV_PM64(d0+8) = imm1;
					d0 += rmi->ldstx;

				}while(h);

			}

		}
		else {
			// block_width_16_align
			if( !rmi->fxh ) {
				if( !rmi->fyh ) {
					//block_width_16_align_h00
					do{
						h -= 4;

						imm0 = *CONV_PM64(f0);
						imm1 = *CONV_PM64(f0+8);
						*CONV_PM64(d0) = imm0;
						f0 += rmi->lfx1;
						*CONV_PM64(d0+8) = imm1;
						d0 += rmi->ldstx;

						imm0 = *CONV_PM64(f0);
						imm1 = *CONV_PM64(f0+8);
						*CONV_PM64(d0) = imm0;
						f0 += rmi->lfx1;
						*CONV_PM64(d0+8) = imm1;
						d0 += rmi->ldstx;

						imm0 = *CONV_PM64(f0);
						imm1 = *CONV_PM64(f0+8);
						*CONV_PM64(d0) = imm0;
						f0 += rmi->lfx1;
						*CONV_PM64(d0+8) = imm1;
						d0 += rmi->ldstx;

						imm0 = *CONV_PM64(f0);
						imm1 = *CONV_PM64(f0+8);
						*CONV_PM64(d0) = imm0;
						f0 += rmi->lfx1;
						*CONV_PM64(d0+8) = imm1;
						d0 += rmi->ldstx;

					}while(h);
				}
				else {
					//block_width_16_align_h01
					do{
						h -= 2;

						imm0 = *CONV_PM64(f0);
						imm2 = *CONV_PM64(f0+8);
						imm1 = *CONV_PM64(f0+rmi->lfx0);
						imm4 = *CONV_PM64(f0+rmi->lfx0+8);
						imm0 = _m_pavgb(imm0,imm1);
						imm2 = _m_pavgb(imm2,imm4);
						*CONV_PM64(d0) = imm0;
						f0 += rmi->lfx1;
						*CONV_PM64(d0+8) = imm2;
						d0 += rmi->ldstx;

						imm0 = *CONV_PM64(f0);
						imm2 = *CONV_PM64(f0+8);
						imm1 = *CONV_PM64(f0+rmi->lfx0);
						imm4 = *CONV_PM64(f0+rmi->lfx0+8);
						imm0 = _m_pavgb(imm0,imm1);
						imm2 = _m_pavgb(imm2,imm4);
						*CONV_PM64(d0) = imm0;
						f0 += rmi->lfx1;
						*CONV_PM64(d0+8) = imm2;
						d0 += rmi->ldstx;

					}while(h);

				}

			}
			else if ( !rmi->fyh ) {
				//block_width_16_align_h10
				do{
					h -- ;

					imm0 = *CONV_PM64(f0);
					imm2 = *CONV_PM64(f0+8);
					imm1 = imm0;
					imm3 = imm2;
					imm5 = imm2;
					imm4 = *CONV_PM64(f0+16);
					imm1 = _m_psrlqi(imm1,8);
					imm3 = _m_psllqi(imm3,56);
					imm5 = _m_psrlqi(imm5,8);
					imm4 = _m_psllqi(imm4,56);
					imm1 = _m_por(imm1,imm3);
					imm4 = _m_por(imm4,imm5);
					imm0 = _m_pavgb(imm0,imm1);
					imm2 = _m_pavgb(imm2,imm4);
					*CONV_PM64(d0) = imm0;
					f0 += rmi->lfx1;
					*CONV_PM64(d0+8) = imm2;
					d0 += rmi->ldstx;

				}while(h);

			}
			else{
				//block_width_16_align_h11

				do{
					h -- ;

					imm0 = *CONV_PM64(f0);
					imm2 = *CONV_PM64(f0+8);
					*CONV_PM64(rmi->nTemp) = imm0;
					imm4 = *CONV_PM64(f0+16);
					imm1 = imm0;
					imm3 = imm2;
					imm5 = imm2;
					*CONV_PM64(rmi->nTemp+1) = imm2;
					imm1 = _m_psrlqi(imm1,8);
					imm3 = _m_psllqi(imm3,56);
					imm5 = _m_psrlqi(imm5,8);
					imm4 = _m_psllqi(imm4,56);
					imm1 = _m_por(imm1,imm3);
					imm4 = _m_por(imm4,imm5);
					*CONV_PM64(rmi->nTemp+2) = imm1;
					*CONV_PM64(rmi->nTemp+3) = imm4;

					imm0 = *CONV_PM64(f0+rmi->lfx1);
					imm2 = *CONV_PM64(f0+rmi->lfx1+8);
					*CONV_PM64(rmi->nTemp+4) = imm0;
					imm4 = *CONV_PM64(f0+rmi->lfx1+16);
					imm1 = imm0;
					imm3 = imm2;
					imm5 = imm2;
					*CONV_PM64(rmi->nTemp+5) = imm2;
					imm1 = _m_psrlqi(imm1,8);
					imm3 = _m_psllqi(imm3,56);
					imm5 = _m_psrlqi(imm5,8);
					imm4 = _m_psllqi(imm4,56);
					imm1 = _m_por(imm1,imm3);
					imm4 = _m_por(imm4,imm5);
					*CONV_PM64(rmi->nTemp+6) = imm1;
					*CONV_PM64(rmi->nTemp+7) = imm4;

					imm0 = *CONV_PM64(rmi->nTemp);
					imm1 = *CONV_PM64(rmi->nTemp+1);
					imm2 = *CONV_PM64(rmi->nTemp+2);
					imm3 = *CONV_PM64(rmi->nTemp+3);
					imm0 = _m_pavgb(imm0,imm2);
					imm1 = _m_pavgb(imm1,imm3);
					imm2 = *CONV_PM64(rmi->nTemp+4);
					imm3 = *CONV_PM64(rmi->nTemp+5);
					imm0 = _m_pavgb(imm0,imm2);
					imm1 = _m_pavgb(imm1,imm3);
					imm2 = *CONV_PM64(rmi->nTemp+6);
					imm3 = *CONV_PM64(rmi->nTemp+7);
					imm0 = _m_pavgb(imm0,imm2);
					imm1 = _m_pavgb(imm1,imm3);
					h --;
					*CONV_PM64(d0) = imm0;
					f0 += rmi->lfx1;
					*CONV_PM64(d0+8) = imm1;
					d0 += rmi->ldstx;

				}while(h);

			} // h11

		} // 

	}
	else {
		//block_width_8:
		if( !rmi->bForwardAlign ) {
			if( !rmi->fxh ) {
				if( !rmi->fyh ) {
					//block_width_8_unalign_h00
					imm5 = *CONV_PM64(&rmi->nForwardLeftAlignBits0);
					imm6 = *CONV_PM64(&rmi->nForwardRightAlignBits0);

					do{
						h -= 4;

						imm0 = *CONV_PM64(f0);
						imm1 = *CONV_PM64(f0+8);
						imm1 = _m_psllq(imm1,imm6);
						imm0 = _m_psrlq(imm0,imm5);
						imm0 = _m_por(imm0,imm1);
						f0 += rmi->lfx1;
						*CONV_PM64(d0) = imm0;
						d0 += rmi->ldstx;

						imm0 = *CONV_PM64(f0);
						imm1 = *CONV_PM64(f0+8);
						imm1 = _m_psllq(imm1,imm6);
						imm0 = _m_psrlq(imm0,imm5);
						imm0 = _m_por(imm0,imm1);
						f0 += rmi->lfx1;
						*CONV_PM64(d0) = imm0;
						d0 += rmi->ldstx;

						imm0 = *CONV_PM64(f0);
						imm1 = *CONV_PM64(f0+8);
						imm1 = _m_psllq(imm1,imm6);
						imm0 = _m_psrlq(imm0,imm5);
						imm0 = _m_por(imm0,imm1);
						f0 += rmi->lfx1;
						*CONV_PM64(d0) = imm0;
						d0 += rmi->ldstx;

						imm0 = *CONV_PM64(f0);
						imm1 = *CONV_PM64(f0+8);
						imm1 = _m_psllq(imm1,imm6);
						imm0 = _m_psrlq(imm0,imm5);
						imm0 = _m_por(imm0,imm1);
						f0 += rmi->lfx1;
						*CONV_PM64(d0) = imm0;
						d0 += rmi->ldstx;

					}while(h);

				}
				else {

					//block_width_8_unalign_h01
					imm5 = *CONV_PM64(&rmi->nForwardLeftAlignBits0);
					imm6 = *CONV_PM64(&rmi->nForwardRightAlignBits0);

					do{
						h -= 2;

						imm0 = *CONV_PM64(f0);
						imm1 = *CONV_PM64(f0+8);
						imm0 = _m_psrlq(imm0,imm5);
						imm1 = _m_psllq(imm1,imm6);
						imm2 = *CONV_PM64(f0+rmi->lfx0);
						imm3 = *CONV_PM64(f0+rmi->lfx0+8);
						imm2 = _m_psrlq(imm2,imm5);
						imm3 = _m_psllq(imm3,imm6);
						imm0 = _m_por(imm0,imm1);
						imm2 = _m_por(imm2,imm3);
						imm0 = _m_pavgb(imm0,imm2);
						f0 += rmi->lfx0;
						*CONV_PM64(d0) = imm0;
						d0 += rmi->ldstx;

						imm0 = *CONV_PM64(f0);
						imm1 = *CONV_PM64(f0+8);
						imm0 = _m_psrlq(imm0,imm5);
						imm1 = _m_psllq(imm1,imm6);
						imm2 = *CONV_PM64(f0+rmi->lfx0);
						imm3 = *CONV_PM64(f0+rmi->lfx0+8);
						imm2 = _m_psrlq(imm2,imm5);
						imm3 = _m_psllq(imm3,imm6);
						imm0 = _m_por(imm0,imm1);
						imm2 = _m_por(imm2,imm3);
						imm0 = _m_pavgb(imm0,imm2);
						f0 += rmi->lfx0;
						*CONV_PM64(d0) = imm0;
						d0 += rmi->ldstx;

					}while(h);
				}
			}
			else if ( !rmi->fyh ) {
				//block_width_8_unalign_h10

				do{
					h --;

					imm5 = *CONV_PM64(&rmi->nForwardLeftAlignBits0);
					imm6 = *CONV_PM64(&rmi->nForwardRightAlignBits0);
					imm0 = *CONV_PM64(f0);
					imm1 = *CONV_PM64(f0+8);
					imm4 = imm0;
					imm7 = imm1;
					imm3 = imm1;
					imm0 = _m_psrlq(imm0,imm5);
					imm1 = _m_psllq(imm1,imm6);
					imm5 = *CONV_PM64(&rmi->nForwardLeftAlignBits1);
					imm6 = *CONV_PM64(&rmi->nForwardRightAlignBits1);
					imm0 = _m_por(imm0,imm1);
					imm1 = imm7;
					imm4 = _m_psrlq(imm4,imm5);
					imm7 = _m_psllq(imm7,imm6);
					imm4 = _m_por(imm4,imm7);
					imm0 = _m_pavgb(imm0,imm4);
					f0 += rmi->lfx0;
					*CONV_PM64(d0) = imm0;
					d0 += rmi->ldstx;

				}while(h);

			}
			else{
				//block_width_8_unalign_h11
				do{
					h --;

					imm5 = *CONV_PM64(&rmi->nForwardLeftAlignBits0);
					imm6 = *CONV_PM64(&rmi->nForwardRightAlignBits0);
					imm0 = *CONV_PM64(f0);
					imm1 = *CONV_PM64(f0+8);
					imm4 = imm0;
					imm7 = imm1;
					imm0 = _m_psrlq(imm0,imm5);
					imm1 = _m_psllq(imm1,imm6);
					imm2 = *CONV_PM64(&rmi->nForwardLeftAlignBits1);
					imm0 = _m_por(imm0,imm1);
					imm3 = *CONV_PM64(&rmi->nForwardRightAlignBits1);
					*CONV_PM64(rmi->nTemp) = imm0;
					imm4 = _m_psrlq(imm4,imm2);
					imm7 = _m_psllq(imm7,imm3);
					imm0 = *CONV_PM64(f0+rmi->lfx0);
					imm4 = _m_por(imm4,imm7);
					imm1 = *CONV_PM64(f0+rmi->lfx0+8);
					*CONV_PM64(rmi->nTemp+2) = imm4;

					imm4 = imm0;
					imm7 = imm1;
					imm0 = _m_psrlq(imm0,imm5);
					imm1 = _m_psllq(imm1,imm6);
					imm4 = _m_psrlq(imm4,imm2);
					imm7 = _m_psllq(imm7,imm3);
					imm0 = _m_por(imm0,imm1);
					imm4 = _m_por(imm4,imm7);
					imm2 = *CONV_PM64(f0+rmi->lfx0);
					imm3 = *CONV_PM64(rmi->nTemp+2);
					imm0 = _m_pavgb(imm0,imm2);
					imm4 = _m_pavgb(imm4,imm3);
					imm0 = _m_pavgb(imm0,imm4);
					f0 += rmi->lfx1;
					*CONV_PM64(d0) = imm0;
					d0 += rmi->ldstx;

				}while(h);

			}

		}
		else {
			// block_width_8_align
			if( !rmi->fxh ) {
				if( !rmi->fyh ) {
					//block_width_8_align_h00
					do{
						h -= 4;

						imm0 = *CONV_PM64(f0);
						f0 += rmi->lfx1;
						*CONV_PM64(d0) = imm0;
						d0 += rmi->ldstx;

						imm0 = *CONV_PM64(f0);
						f0 += rmi->lfx1;
						*CONV_PM64(d0) = imm0;
						d0 += rmi->ldstx;

						imm0 = *CONV_PM64(f0);
						f0 += rmi->lfx1;
						*CONV_PM64(d0) = imm0;
						d0 += rmi->ldstx;

						imm0 = *CONV_PM64(f0);
						f0 += rmi->lfx1;
						*CONV_PM64(d0) = imm0;
						d0 += rmi->ldstx;

					}while(h);
				}
				else {
					//block_width_8_align_h01
					do{
						h -= 4;

						imm0 = *CONV_PM64(f0);
						imm1 = *CONV_PM64(f0+rmi->lfx0);
						f0 += rmi->lfx1;
						imm0 = _m_pavgb(imm0,imm1);
						*CONV_PM64(d0) = imm0;
						d0 += rmi->ldstx;

						imm0 = *CONV_PM64(f0);
						imm1 = *CONV_PM64(f0+rmi->lfx0);
						f0 += rmi->lfx1;
						imm0 = _m_pavgb(imm0,imm1);
						*CONV_PM64(d0) = imm0;
						d0 += rmi->ldstx;

						imm0 = *CONV_PM64(f0);
						imm1 = *CONV_PM64(f0+rmi->lfx0);
						f0 += rmi->lfx1;
						imm0 = _m_pavgb(imm0,imm1);
						*CONV_PM64(d0) = imm0;
						d0 += rmi->ldstx;

						imm0 = *CONV_PM64(f0);
						imm1 = *CONV_PM64(f0+rmi->lfx0);
						f0 += rmi->lfx1;
						imm0 = _m_pavgb(imm0,imm1);
						*CONV_PM64(d0) = imm0;
						d0 += rmi->ldstx;

					}while(h);

				}

			}
			else if ( !rmi->fyh ) {
				//block_width_8_align_h10
				do{
					h -= 2;

					imm0 = *CONV_PM64(f0);
					imm2 = *CONV_PM64(f0+8);
					imm1 = imm0;
					imm2 = _m_psllqi(imm2,56);
					imm1 = _m_psrlqi(imm1,8);
					imm1 = _m_por(imm1,imm2);
					f0 += rmi->lfx1;
					imm0 = _m_pavgb(imm0,imm1);
					*CONV_PM64(d0) = imm0;
					d0 += rmi->ldstx;

					imm0 = *CONV_PM64(f0);
					imm2 = *CONV_PM64(f0+8);
					imm1 = imm0;
					imm2 = _m_psllqi(imm2,56);
					imm1 = _m_psrlqi(imm1,8);
					imm1 = _m_por(imm1,imm2);
					f0 += rmi->lfx1;
					imm0 = _m_pavgb(imm0,imm1);
					*CONV_PM64(d0) = imm0;
					d0 += rmi->ldstx;

				}while(h);

			}
			else{
				//block_width_8_align_h11
				do{
					h -= 2;

					imm0 = *CONV_PM64(f0);
					imm2 = *CONV_PM64(f0+8);
					imm1 = imm0;
					imm2 = _m_psllqi(imm2,56);
					imm1 = _m_psrlqi(imm1,8);
					imm1 = _m_por(imm1,imm2);
					f0 += rmi->lfx1;
					imm4 = _m_pavgb(imm0,imm1);
					imm0 = *CONV_PM64(f0);
					imm2 = *CONV_PM64(f0+8);
					imm1 = imm0;
					imm2 = _m_psllqi(imm2,56);
					imm1 = _m_psrlqi(imm1,8);
					imm1 = _m_por(imm1,imm2);
					imm0 = _m_pavgb(imm0,imm1);
					imm0 = _m_pavgb(imm0,imm4);
					*CONV_PM64(d0) = imm0;
					d0 += rmi->ldstx;

					imm0 = *CONV_PM64(f0);
					imm2 = *CONV_PM64(f0+8);
					imm1 = imm0;
					imm2 = _m_psllqi(imm2,56);
					imm1 = _m_psrlqi(imm1,8);
					imm1 = _m_por(imm1,imm2);
					f0 += rmi->lfx1;
					imm4 = _m_pavgb(imm0,imm1);
					imm0 = *CONV_PM64(f0);
					imm2 = *CONV_PM64(f0+8);
					imm1 = imm0;
					imm2 = _m_psllqi(imm2,56);
					imm1 = _m_psrlqi(imm1,8);
					imm1 = _m_por(imm1,imm2);
					imm0 = _m_pavgb(imm0,imm1);
					imm0 = _m_pavgb(imm0,imm4);
					*CONV_PM64(d0) = imm0;
					d0 += rmi->ldstx;

				}while(h);

			}

		}

	}

	_m_empty();

#endif

}
//}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static void rec_2b_1_sse2(rec_mb_info* rmi)
{

}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

//  << start of rec;
static void rec_avgblock_mmx(rec_mb_info* rmi)
{
#ifndef __MCP_INTRINSIC
	__asm
	{
		mov        esi,[rmi]
		push       ebx

		cmp        [esi]rec_mb_info.w,8  // if block width == 8, goto mb_width_16;
		je         block_width_8

;block_width_16:

		mov        eax,[esi]rec_mb_info.forw_mb0    // src0,dst;
		mov        ebx,[esi]rec_mb_info.back_mb0    // src1;
		mov        ecx,[esi]rec_mb_info.h           // height;
		mov        edx,[esi]rec_mb_info.lfx0        // the pitch;

		movq       mm1,[rec_msk_0xfe]
		movq       mm3,[rec_msk_0x01]
		sub        ebx,edx
		sub        eax,edx			

next_row16:
		add        ebx,edx
		add        eax,edx			
		movq       mm0,[eax]
		movq       mm5,mm1
		movq       mm2,[ebx]
		movq       mm6,mm3
		LXAVGB(mm0,mm2,mm5,mm6,mm7)    // avg 76543210; to mm0;
		movq       mm5,mm1
		movq       [eax],mm0
		movq       mm6,mm3
		movq       mm0,[eax+8]
		movq       mm2,[ebx+8]
		LXAVGB(mm0,mm2,mm5,mm6,mm7)    // avg 76543210; to mm0;
		add        ebx,edx
		movq       [eax+8],mm0
		add        eax,edx
		sub        ecx,2

		movq       mm0,[eax]
		movq       mm5,mm1
		movq       mm2,[ebx]
		movq       mm6,mm3
		LXAVGB(mm0,mm2,mm5,mm6,mm7)    // avg 76543210; to mm0;
		movq       mm5,mm1
		movq       [eax],mm0
		movq       mm6,mm3
		movq       mm0,[eax+8]
		movq       mm2,[ebx+8]
		LXAVGB(mm0,mm2,mm5,mm6,mm7)    // avg 76543210; to mm0;
		movq       [eax+8],mm0
		ja         next_row16
		jmp        over


block_width_8:

		mov        eax,[esi]rec_mb_info.forw_mb0    // src0,dst;
		mov        ebx,[esi]rec_mb_info.back_mb0    // src1;
		mov        ecx,[esi]rec_mb_info.h           // height;
		mov        edx,[esi]rec_mb_info.lfx0        // the pitch;
		movq       mm1,[rec_msk_0xfe]
		movq       mm3,[rec_msk_0x01]
		sub        ebx,edx
		sub        eax,edx			

next_row8:
		add        ebx,edx
		add        eax,edx			

		movq       mm0,[eax]
		movq       mm5,mm1
		movq       mm2,[ebx]
		movq       mm6,mm3
		LXAVGB(mm0,mm2,mm5,mm6,mm7)    // avg 76543210; to mm0;
		add        ebx,edx
		movq       [eax],mm0
		add        eax,edx

		movq       mm5,mm1
		movq       mm0,[eax]
		movq       mm6,mm3
		movq       mm2,[ebx]
		LXAVGB(mm0,mm2,mm5,mm6,mm7)    // avg 76543210; to mm0;
		add        ebx,edx
		movq       [eax],mm0
		add        eax,edx

		movq       mm5,mm1
		movq       mm0,[eax]
		movq       mm6,mm3
		movq       mm2,[ebx]
		LXAVGB(mm0,mm2,mm5,mm6,mm7)    // avg 76543210; to mm0;
		add        ebx,edx
		movq       [eax],mm0
		add        eax,edx
		sub        ecx,4

		movq       mm5,mm1
		movq       mm0,[eax]
		movq       mm6,mm3
		movq       mm2,[ebx]
		LXAVGB(mm0,mm2,mm5,mm6,mm7)    // avg 76543210; to mm0;
		movq       [eax],mm0
		ja         next_row8

over:
		pop        ebx
		emms
	}
#else


#endif

}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static void rec_avgblock_sse2(rec_mb_info *rmi)
{

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

static void rec_addblock_mmx(rec_mb_info* rmi)
{
#ifndef __MCP_INTRINSIC
	s32 h;
	__asm
	{
		mov        esi,[rmi]
		push       ebx
		mov        eax,[esi]rec_mb_info.h
		mov        [h],eax

		cmp        [esi]rec_mb_info.w,8  // if block width == 8, goto mb_width_16;
		je         block_width_8

;block_width_16:

		mov        edx,[esi]rec_mb_info.lblkx
		add        edx,edx                        // lblkx *= 2;
		mov        eax,[esi]rec_mb_info.forw_mb0
		mov        edi,[esi]rec_mb_info.dest_mb0  //d0
		mov        ebx,[esi]rec_mb_info.blk0
		mov        ecx,[esi]rec_mb_info.blk1
		pxor       mm7,mm7
		sub        eax,[esi]rec_mb_info.lfx0      // inc f0
		sub        edi,[esi]rec_mb_info.ldstx     // inc dst;			
		sub        ebx,edx                        // inc blk0;
		sub        ecx,edx                        // inc blk1;

block_width_16_align_hh00:       

		add        eax,[esi]rec_mb_info.lfx0      // inc f0
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;			
		add        ebx,edx                        // inc blk0;
		add        ecx,edx                        // inc blk1;
		sub        [h],1 
		movq       mm0,[eax]     // 76543210;
		movq       mm2,[eax+8]   // fedcba98;
		movq       mm1,mm0
		movq       mm3,mm2       // dup fedcba98;
		punpcklbw  mm0,mm7       // 3210;
		punpckhbw  mm1,mm7       // 7654;
		paddsw     mm0,[ebx]     // 3210 + blk3210;
		paddsw     mm1,[ebx+8]   // 7654 + blk7654;
		punpcklbw  mm2,mm7       // ba98;
		packuswb   mm0,mm1       // dst 76543210;
		punpckhbw  mm3,mm7       // fedc;
		movq       [edi],mm0     // output dst 76543210;
		paddsw     mm2,[ecx]     // ba98 + blkba98;
		paddsw     mm3,[ecx+8]   // fedc + blkfedc;
		packuswb   mm2,mm3                        // dst fedcba98;
		movq       [edi+8],mm2                    // output dst fedcba98;
		jg         block_width_16_align_hh00
		jmp        over


block_width_8:
		mov        edx,[esi]rec_mb_info.lblkx
		mov        ecx,[esi]rec_mb_info.h
		add        edx,edx                    // lblkx *= 2;
		mov        eax,[esi]rec_mb_info.forw_mb0
		mov        edi,[esi]rec_mb_info.dest_mb0  //d0
		mov        ebx,[esi]rec_mb_info.blk0
		pxor       mm7,mm7
		sub        eax,[esi]rec_mb_info.lfx0      // inc f0
		sub        ebx,edx                        // inc blk;
		sub        edi,[esi]rec_mb_info.ldstx     // inc dst;

block_width_8_align_hh00:       

		add        eax,[esi]rec_mb_info.lfx0      // inc f0
		add        ebx,edx                        // inc blk;
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;
		movq       mm0,[eax]     // 76543210;
		add        eax,[esi]rec_mb_info.lfx0      // inc f0
		movq       mm1,mm0       // dup 76543210;
		punpcklbw  mm0,mm7       // 3210;
		punpckhbw  mm1,mm7       // 7654;
		paddsw     mm0,[ebx]     // 3210 + blk3210;
		paddsw     mm1,[ebx+8]   // 7654 + blk7654;
		add        ebx,edx                        // inc blk;
		packuswb   mm0,mm1       // dst 76543210;
		movq       [edi],mm0     // output dst 76543210;
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;

		movq       mm0,[eax]     // 76543210;
		add        eax,[esi]rec_mb_info.lfx0      // inc f0
		movq       mm1,mm0       // dup 76543210;
		punpcklbw  mm0,mm7       // 3210;
		punpckhbw  mm1,mm7       // 7654;
		paddsw     mm0,[ebx]     // 3210 + blk3210;
		paddsw     mm1,[ebx+8]   // 7654 + blk7654;
		add        ebx,edx                        // inc blk;
		packuswb   mm0,mm1       // dst 76543210;
		movq       [edi],mm0     // output dst 76543210;
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;

		movq       mm0,[eax]     // 76543210;
		add        eax,[esi]rec_mb_info.lfx0      // inc f0
		movq       mm1,mm0       // dup 76543210;
		punpcklbw  mm0,mm7       // 3210;
		punpckhbw  mm1,mm7       // 7654;
		paddsw     mm0,[ebx]     // 3210 + blk3210;
		paddsw     mm1,[ebx+8]   // 7654 + blk7654;
		add        ebx,edx                        // inc blk;
		packuswb   mm0,mm1       // dst 76543210;
		movq       [edi],mm0     // output dst 76543210;
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;
		sub        ecx,4

		movq       mm0,[eax]     // 76543210;
		movq       mm1,mm0       // dup 76543210;
		punpcklbw  mm0,mm7       // 3210;
		punpckhbw  mm1,mm7       // 7654;
		paddsw     mm0,[ebx]     // 3210 + blk3210;
		paddsw     mm1,[ebx+8]   // 7654 + blk7654;
		packuswb   mm0,mm1       // dst 76543210;
		movq       [edi],mm0     // output dst 76543210;
		jg         block_width_8_align_hh00

over:
		pop        ebx
		emms
	}
#else

#endif

}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static void rec_addblock_sse2(rec_mb_info *rmi)
{

}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

static void rec_2b_1_mmx(rec_mb_info* rmi)
{
#ifndef __MCP_INTRINSIC
	s32 i;
	__asm
	{
		mov        esi,[rmi]

		push       ebx

		cmp        [esi]rec_mb_info.w,8  // if block width == 8, goto mb_width_16;
		je         block_width_8

;block_width_16:

		cmp        [esi]rec_mb_info.bForwardAlign,1
		je         block_width_16_align

		;block_width_16_unalign:

		mov        ecx,[esi]rec_mb_info.h
		mov        [i],ecx

		cmp        [esi]rec_mb_info.fxh,0
		jne        block_width_16_unalign_h10

		cmp        [esi]rec_mb_info.fyh,0
		jne        block_width_16_unalign_h01

		mov        eax,[esi]rec_mb_info.forw_mb0
		mov        edi,[esi]rec_mb_info.dest_mb0  //d0
		movq       mm5,[esi]rec_mb_info.nForwardLeftAlignBits0  // left >> nl;
		movq       mm6,[esi]rec_mb_info.nForwardRightAlignBits0 // right << nr;
		pxor       mm7,mm7
		sub        eax,[esi]rec_mb_info.lfx1      // inc f0
		sub        edi,[esi]rec_mb_info.ldstx     // inc dst;

block_width_16_unalign_hh00:       

		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;
		sub        [i],1 
		movq       mm0,[eax]     // 3210xxxx;
		movq       mm1,[eax+8]   // ba987654;
		psrlq      mm0,mm5       // ____3210;
		movq       mm3,mm1       // dup ba987654;
		psllq      mm1,mm6       // 7654____;
		movq       mm2,[eax+16]  // xxxxfedc;
		psrlq      mm3,mm5       // ____ba98;
		por        mm0,mm1       // 76543210;
		psllq      mm2,mm6       // fedc____;
		movq       [edi],mm0     // output dst 76543210;
		por        mm2,mm3       // fedcba98;
		movq       [edi+8],mm2                    // output dst fedcba98;
		jg         block_width_16_unalign_hh00

		jmp        over

block_width_16_unalign_h01:

		mov        eax,[esi]rec_mb_info.forw_mb0
		mov        edi,[esi]rec_mb_info.dest_mb0  //d0
		mov        edx,[esi]rec_mb_info.lfx0      // pitch;
		sub        eax,[esi]rec_mb_info.lfx1      // inc f0
		sub        edi,[esi]rec_mb_info.ldstx     // inc dst;

block_width_16_unalign_hh01:          

		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;
		sub        [i],1
		movq       mm5,[esi]rec_mb_info.nForwardLeftAlignBits0  // left >> nl;
		movq       mm6,[esi]rec_mb_info.nForwardRightAlignBits0 // right << nr;
		movq       mm0,[eax]     // 3210xxxx;
		movq       mm1,[eax+8]   // ba987654;
		psrlq      mm0,mm5       // ____3210;
		movq       mm3,mm1       // dup ba987654;
		psllq      mm1,mm6       // 7654____;
		movq       mm2,[eax+16]  // xxxxfedc;
		psrlq      mm3,mm5       // ____ba98;
		por        mm0,mm1       // top 76543210;   mm0;
		psllq      mm2,mm6       // fedc____;
		movq       mm1,[eax+edx]     // bot 3210xxxx;
		por        mm2,mm3       // top fedcba98;   mm2;			  
		movq       mm3,[eax+edx+8]   // bot ba987654;
		psrlq      mm1,mm5           // bot ____3210;
		movq       mm7,mm3           // dup bot ba987654;
		psllq      mm3,mm6           // 7654____;
		movq       mm4,[eax+edx+16]  // bot xxxxfedc;
		psrlq      mm7,mm5           // bot  ____ba98;
		por        mm1,mm3           // bot 76543210;   mm1;
		psllq      mm4,mm6           // bot fedc____;
		movq       mm3,[rec_msk_0x01]  // msk of bit 0;
		por        mm4,mm7           // bot fedcba98;   mm4;
		movq       mm5,mm3             // dup msk of bit 0;
		movq       mm6,[rec_msk_0xfe]  // msk of bit 15-1;
		LXAVGB(mm0,mm1,mm6,mm5,mm7)    // avg 76543210; to mm0
		movq       mm5,mm3             // dup msk of bit 0;
		movq       [edi],mm0                // output 76543210;
		movq       mm6,[rec_msk_0xfe]  // msk of bit 15-1;
		LXAVGB(mm2,mm4,mm6,mm5,mm7)    // avg fedcba98; to mm2;
		movq       [edi+8],mm2                    // output fedcba98;
		jg         block_width_16_unalign_hh01

		jmp        over

block_width_16_unalign_h10:

		cmp        [esi]rec_mb_info.fyh,0
		jne        block_width_16_unalign_h11

		mov        eax,[esi]rec_mb_info.forw_mb0
		mov        edi,[esi]rec_mb_info.dest_mb0  //d0
		sub        eax,[esi]rec_mb_info.lfx1      // inc f0
		sub        edi,[esi]rec_mb_info.ldstx     // inc dst;			

block_width_16_unalign_hh10:          

		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;			
		sub        [i],1   // ecx is not used in src pitch; 
		movq       mm5,[esi]rec_mb_info.nForwardLeftAlignBits0  // left >> nl;
		movq       mm6,[esi]rec_mb_info.nForwardRightAlignBits0 // right << nr;
		movq       mm0,[eax]     // 3210xxxx;
		movq       mm1,[eax+8]   // ba987654; 
		movq       mm4,mm0       // dup 3210xxxx;
		movq       mm7,mm1       // dup ba987654;
		movq       mm3,mm1       // dup ba987654;
		psrlq      mm0,mm5       // ____3210;
		psllq      mm1,mm6       // 7654____;
		movq       mm2,[eax+16]  // xxxgfedc;
		psrlq      mm3,mm5       // ____ba98;
		por        mm0,mm1       // 76543210; mm0;
		psllq      mm2,mm6       // fedc____;  
		movq       mm5,[esi]rec_mb_info.nForwardLeftAlignBits1  // left >> nl;
		por        mm2,mm3       // fedcba98; mm2;
		movq       mm6,[esi]rec_mb_info.nForwardRightAlignBits1 // right << nr;
		movq       mm3,[eax+16]       // xxxgfedc;
		movq       mm1,mm7            // dup ba987654;
		psrlq      mm4,mm5            // _____321;
		psllq      mm7,mm6            // 87654___;
		psrlq      mm1,mm5            // _____ba9;
		por        mm4,mm7            // 87654321; mm4;
		psllq      mm3,mm6            // gfedc___;  

		movq       mm5,[rec_msk_0x01]     // msk of bit 0;			  
		movq       mm6,[rec_msk_0xfe]     // msk of bit 15-1;
		por        mm1,mm3            // gfedcba9; mm1;
		movq       mm3,mm5                // dup msk of bit 0;
		LXAVGB(mm0,mm4,mm6,mm5,mm7)       // avg 76543210; to mm0;
		movq       mm6,[rec_msk_0xfe]  // msk of bit 15-1;
		movq       [edi],mm0                // output 76543210;
		movq       mm5,mm3             // dup msk of bit 0;
		LXAVGB(mm2,mm1,mm6,mm5,mm7)    // avg fedcba98; to mm2;
		movq       [edi+8],mm2                    // output fedcba98;
		jg         block_width_16_unalign_hh10

		jmp        over

block_width_16_unalign_h11:

		mov        eax,[esi]rec_mb_info.forw_mb0
		mov        edi,[esi]rec_mb_info.dest_mb0  //d0
		mov        edx,[esi]rec_mb_info.lfx0      // pitch;
		sub        eax,[esi]rec_mb_info.lfx1      // inc f0
		sub        edi,[esi]rec_mb_info.ldstx     // inc dst;

block_width_16_unalign_hh11:          

		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;
		sub        [i],1

		movq       mm0,[eax]
		movq       [esi+64]rec_mb_info.nTemp,mm0
		movq       mm1,[eax+8]
		movq       [esi+72]rec_mb_info.nTemp,mm1
		movq       mm2,[eax+16]
		movq       [esi+80]rec_mb_info.nTemp,mm2
		GET_16_FROM_24([esi]rec_mb_info.nForwardLeftAlignBits0,[esi]rec_mb_info.nForwardRightAlignBits0,64,0)
		GET_16_FROM_24([esi]rec_mb_info.nForwardLeftAlignBits1,[esi]rec_mb_info.nForwardRightAlignBits1,64,16)

		movq       mm0,[eax+edx]
		movq       [esi+64]rec_mb_info.nTemp,mm0
		movq       mm1,[eax+edx+8]
		movq       [esi+72]rec_mb_info.nTemp,mm1
		movq       mm2,[eax+edx+16]
		movq       [esi+80]rec_mb_info.nTemp,mm2
		GET_16_FROM_24([esi]rec_mb_info.nForwardLeftAlignBits0,[esi]rec_mb_info.nForwardRightAlignBits0,64,32)
		GET_16_FROM_24([esi]rec_mb_info.nForwardLeftAlignBits1,[esi]rec_mb_info.nForwardRightAlignBits1,64,48)

		// begin to do 4 * 8 avg;
		movq       mm0,[esi]rec_mb_info.nTemp         // top 76543210;  mm0;
		movq       mm2,[esi+16]rec_mb_info.nTemp      // top 87654321;  mm2;
		movq       mm1,[esi+32]rec_mb_info.nTemp      // bot 76543210;  mm1;
		movq       mm4,[esi+48]rec_mb_info.nTemp      // bot 87654321;  mm4;

		movq       mm3,mm0                            // dup top 76543210;
		pand       mm0,[rec_msk_0xfc]                 // top 76543210 bit 15-2;
		psrlq      mm0,2               // 
		pand       mm3,[rec_msk_0x03]  // top 76543210 bit 1-0;

		movq       mm5,mm1             // dup bot 76543210;
		pand       mm1,[rec_msk_0xfc]  // bot 76543210 bit 15-2;
		psrlq      mm1,2               //
		pand       mm5,[rec_msk_0x03]  // bot 76543210 bit 1-0;

		movq       mm6,mm2             // dup top 87654321;
		pand       mm2,[rec_msk_0xfc]  // top 87654321 bit 15-2;
		psrlq      mm2,2               //
		pand       mm6,[rec_msk_0x03]  // top 87654321 bit 1-0;

		movq       mm7,mm4             // dup bot 87654321;
		pand       mm4,[rec_msk_0xfc]  // bot 87654321 bit 15-2;
		psrlq      mm4,2               //
		pand       mm7,[rec_msk_0x03]  // bot 87654321 bit 1-0;

		paddusb    mm0,mm1             // top + bot , 76543210; bit 15-2;
		paddusb    mm2,mm4             // top + bot , 87654321; bit 15-2;
		paddusb    mm3,mm5             // t + b, 7, 1-0;
		paddusb    mm6,mm7             // t + b, 8, 1-0;
		paddusb    mm0,mm2             // t + b, 7 + 8, 15-2;
		paddusb    mm3,mm6             // t + b, 7 + 8, 1-0;
		movq       mm2,[esi+24]rec_mb_info.nTemp            // top gfedcba9; mm2;
		paddusb    mm3,[rec_msk_0x02]  // round;
		pand       mm3,[rec_msk_0xfc]  // clear bit 1-0;
		movq       mm4,[esi+(32+24)]rec_mb_info.nTemp         // bot gfedcba9; mm4;
		psrlq      mm3,2
		paddusb    mm3,mm0             // avg of 4*8;
		movq       mm0,[esi+8]rec_mb_info.nTemp              // top fedcba98; mm0;
		movq       [esi]rec_mb_info.nTemp,mm3                 // save avg of block 0;
		movq       mm1,[esi+(32+8)]rec_mb_info.nTemp          // bot fedcba98; mm1;

		movq       mm3,mm0             // dup top fedcba98;
		pand       mm0,[rec_msk_0xfc]  // top fedcba98 bit 15-2;
		psrlq      mm0,2               // 
		pand       mm3,[rec_msk_0x03]  // top fedcba98 bit 1-0;

		movq       mm5,mm1             // dup bot fedcba98;
		pand       mm1,[rec_msk_0xfc]  // bot fedcba98 bit 15-2;
		psrlq      mm1,2               //
		pand       mm5,[rec_msk_0x03]  // bot fedcba98 bit 1-0;

		movq       mm6,mm2             // dup top gfedcba9;
		pand       mm2,[rec_msk_0xfc]  // top gfedcba9 bit 15-2;
		psrlq      mm2,2               //
		pand       mm6,[rec_msk_0x03]  // top gfedcba9 bit 1-0;

		movq       mm7,mm4             // dup bot gfedcba9;
		pand       mm4,[rec_msk_0xfc]  // bot gfedcba9 bit 15-2;
		psrlq      mm4,2               //
		pand       mm7,[rec_msk_0x03]  // bot gfedcba9 bit 1-0;

		paddusb    mm0,mm1             // top + bot , fedcba98; bit 15-2;
		paddusb    mm2,mm4             // top + bot , gfedcba9; bit 15-2;
		paddusb    mm3,mm5             // t + b, f, 1-0;
		paddusb    mm6,mm7             // t + b, g, 1-0;
		paddusb    mm0,mm2             // t + b, f + g, 15-2;
		paddusb    mm3,mm6             // t + b, f + g, 1-0;
		paddusb    mm3,[rec_msk_0x02]  // round;

		pand       mm3,[rec_msk_0xfc]          // clear bit 1-0;
		psrlq      mm3,2
		movq       mm1,[esi]rec_mb_info.nTemp  // load blk0;
		movq       [edi],mm1                   // output 76543210;
		paddusb    mm3,mm0                     // avg of 4*8;
		movq       [edi+8],mm3                    // output fedcba98;
		jg         block_width_16_unalign_hh11

		jmp        over


block_width_16_align:

		mov        ecx,[esi]rec_mb_info.h
		mov        [i],ecx

		cmp        [esi]rec_mb_info.fxh,0
		jne        block_width_16_align_h10

		cmp        [esi]rec_mb_info.fyh,0
		jne        block_width_16_align_h01

		mov        eax,[esi]rec_mb_info.forw_mb0
		mov        edi,[esi]rec_mb_info.dest_mb0  //d0
		sub        eax,[esi]rec_mb_info.lfx1      // inc f0
		sub        edi,[esi]rec_mb_info.ldstx     // inc dst;

block_width_16_align_hh00:       

		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;
		movq       mm0,[eax]     // 76543210;
		movq       mm2,[eax+8]   // fedcba98;
		movq       [edi],mm0     // output dst 76543210;
		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		movq       [edi+8],mm2                    // output dst fedcba98;
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;

		movq       mm0,[eax]     // 76543210;
		movq       mm2,[eax+8]   // fedcba98;
		movq       [edi],mm0     // output dst 76543210;
		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		movq       [edi+8],mm2                    // output dst fedcba98;
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;

		movq       mm0,[eax]     // 76543210;
		movq       mm2,[eax+8]   // fedcba98;
		movq       [edi],mm0     // output dst 76543210;
		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		movq       [edi+8],mm2                    // output dst fedcba98;
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;
		sub        [i],4 

		movq       mm0,[eax]     // 76543210;
		movq       mm2,[eax+8]   // fedcba98;
		movq       [edi],mm0     // output dst 76543210;
		movq       [edi+8],mm2                    // output dst fedcba98;
		jg         block_width_16_align_hh00

		jmp        over

block_width_16_align_h01:

		mov        eax,[esi]rec_mb_info.forw_mb0
		mov        edi,[esi]rec_mb_info.dest_mb0  //d0
		mov        edx,[esi]rec_mb_info.lfx0     // pitch;
		sub        eax,[esi]rec_mb_info.lfx1      // inc f0
		sub        edi,[esi]rec_mb_info.ldstx     // inc dst;

block_width_16_align_hh01:          

		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;
		sub        [i],1
		movq       mm0,[eax]           // top 76543210;
		movq       mm2,[eax+8]         // top fedcba98;
		movq       mm3,[rec_msk_0x01]  // msk of bit 0;			  
		movq       mm1,[eax+edx]       // bot 76543210;
		movq       mm5,mm3             // dup msk of bit 0;
		movq       mm4,[eax+edx+8]     // bot fedcba98;
		movq       mm6,[rec_msk_0xfe]  // msk of bit 15-1;
		LXAVGB(mm0,mm1,mm6,mm5,mm7)    // avg 76543210; to mm0;
		movq       mm5,mm3             // dup msk of bit 0;
		movq       [edi],mm0                // output 76543210;
		movq       mm6,[rec_msk_0xfe]  // msk of bit 15-1;
		LXAVGB(mm2,mm4,mm6,mm5,mm7)    // avg fedcba98; to mm2;
		movq       [edi+8],mm2                    // output fedcba98;
		jg         block_width_16_align_hh01

		jmp        over

block_width_16_align_h10:

		cmp        [esi]rec_mb_info.fyh,0
		jne        block_width_16_align_h11

		mov        eax,[esi]rec_mb_info.forw_mb0
		mov        edi,[esi]rec_mb_info.dest_mb0  //d0
		sub        eax,[esi]rec_mb_info.lfx1      // inc f0
		sub        edi,[esi]rec_mb_info.ldstx     // inc dst;

block_width_16_align_hh10:          

		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;
		sub        [i],1    // ecx is not used in src pitch; 
		movq       mm0,[eax]     // 76543210;  mm0
		movq       mm2,[eax+8]   // fedcba98;  mm2;
		movq       mm1,mm0       // dup byte1;
		movq       mm3,mm2       // dup middle;
		movq       mm5,mm2       // dup middle;
		movq       mm4,[eax+16]  // xxxxxxxg;
		psrlq      mm1,8         // _7654321;
		psllq      mm3,56        // 8_______;
		psrlq      mm5,8         // _fedcba9;
		psllq      mm4,56        // g_______;
		por        mm1,mm3       // 87654321;  mm1;
		por        mm4,mm5       // gfdecba9;  mm4;

		movq       mm5,[rec_msk_0x01]     // msk of bit 0;			  
		movq       mm6,[rec_msk_0xfe]     // msk of bit 15-1;
		movq       mm3,mm5                // dup msk of bit 0;
		LXAVGB(mm0,mm1,mm6,mm5,mm7)       // avg 76543210; to mm0;
		movq       mm5,mm3             // dup msk of bit 0;
		movq       [edi],mm0                // output 76543210;
		movq       mm6,[rec_msk_0xfe]  // msk of bit 15-1;
		LXAVGB(mm2,mm4,mm6,mm5,mm7)    // avg fedcba98; to mm2;
		movq       [edi+8],mm2                    // output fedcba98;
		jg         block_width_16_align_hh10

		jmp        over

block_width_16_align_h11:

		mov        eax,[esi]rec_mb_info.forw_mb0
		mov        edi,[esi]rec_mb_info.dest_mb0  //d0
		mov        edx,[esi]rec_mb_info.lfx0      // pitch;
		sub        eax,[esi]rec_mb_info.lfx1      // inc f0
		sub        edi,[esi]rec_mb_info.ldstx     // inc dst;

block_width_16_align_hh11:          

		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;
		sub        [i],1
		movq       mm0,[eax]     // top 76543210;
		movq       mm2,[eax+8]   // top fedcba98; 
		movq       [esi]rec_mb_info.nTemp,mm0     // save top 76543210;
		movq       mm4,[eax+16]  // top xxxxxxxg;
		movq       mm1,mm0       // dup byte1;
		movq       mm3,mm2       // dup byte8;
		movq       mm5,mm2       // dup middle;
		movq       [esi+8]rec_mb_info.nTemp,mm2    // save top fedcba98;

		psrlq      mm1,8         // _7654321;
		psllq      mm3,56        // 8_______;
		psrlq      mm5,8         // _fedcba9;
		psllq      mm4,56        // g_______;
		por        mm1,mm3       // 87654321;  mm1;
		por        mm4,mm5       // gfdecba9;  mm4;
		movq       [esi+16]rec_mb_info.nTemp,mm1    // save top 87654321;

		// begin to load bot data;
		movq       mm0,[eax+edx]     // bot 76543210;
		movq       [esi+24]rec_mb_info.nTemp,mm4    // save top gfedcba9;
		movq       mm2,[eax+edx+8]   // bot fedcba98; 
		movq       [esi+32]rec_mb_info.nTemp,mm0     // save bot 76543210;
		movq       mm4,[eax+edx+16]  // bot xxxxxxxg;
		movq       mm1,mm0       // dup byte1;
		movq       mm3,mm2       // dup byte8;
		movq       mm5,mm2       // dup middle;
		movq       [esi+(32+8)]rec_mb_info.nTemp,mm2    // save bot fedcba98;

		psrlq      mm1,8         // _7654321;
		psllq      mm3,56        // 8_______;
		psrlq      mm5,8         // _fedcba9;
		psllq      mm4,56        // g_______;
		por        mm1,mm3       // bot 87654321;  mm1;
		por        mm4,mm5       // bot gfdecba9;  mm4;

		// begin to do 4 * 8 avg;
		movq       mm0,[esi]rec_mb_info.nTemp             // top 76543210;
		movq       [esi+(32+24)],mm4                      // save bot gfedcba9;
		movq       mm2,[esi+16]rec_mb_info.nTemp          // top 87654321;
		movq       mm4,mm1             // copy bot 87654321;
		movq       mm3,mm0             // dup top 76543210;
		pand       mm0,[rec_msk_0xfc]  // top 76543210 bit 15-2;
		psrlq      mm0,2               // 
		pand       mm3,[rec_msk_0x03]  // top 76543210 bit 1-0;
		movq       mm5,mm1             // dup bot 76543210;
		pand       mm1,[rec_msk_0xfc]  // bot 76543210 bit 15-2;
		psrlq      mm1,2               //
		pand       mm5,[rec_msk_0x03]  // bot 76543210 bit 1-0;
		movq       mm6,mm2             // dup top 87654321;
		pand       mm2,[rec_msk_0xfc]  // top 87654321 bit 15-2;
		psrlq      mm2,2               //
		pand       mm6,[rec_msk_0x03]  // top 87654321 bit 1-0;
		movq       mm7,mm4             // dup bot 87654321;
		pand       mm4,[rec_msk_0xfc]  // bot 87654321 bit 15-2;
		psrlq      mm4,2               //
		pand       mm7,[rec_msk_0x03]  // bot 87654321 bit 1-0;
		paddusb    mm0,mm1             // top + bot , 76543210; bit 15-2;
		paddusb    mm2,mm4             // top + bot , 87654321; bit 15-2;
		paddusb    mm3,mm5             // t + b, 7, 1-0;
		paddusb    mm6,mm7             // t + b, 8, 1-0;
		paddusb    mm0,mm2             // t + b, 7 + 8, 15-2;
		paddusb    mm3,mm6             // t + b, 7 + 8, 1-0;
		paddusb    mm3,[rec_msk_0x02]  // round;
		pand       mm3,[rec_msk_0xfc]  // clear bit 1-0;
		psrlq      mm3,2
		paddusb    mm3,mm0             // avg of 4*8;
		movq       mm1,[esi+32+8]rec_mb_info.nTemp          // bot fedcba98;
		movq       [esi]rec_mb_info.nTemp,mm3   // save avg of block 0;
		movq       mm0,[esi+8]rec_mb_info.nTemp             // top fedcba98;
		movq       mm2,[esi+24]rec_mb_info.nTemp            // top gfedcba9;
		movq       mm4,[esi+32+24]rec_mb_info.nTemp         // bot gfedcba9;
		movq       mm3,mm0             // dup top fedcba98;
		pand       mm0,[rec_msk_0xfc]  // top fedcba98 bit 15-2;
		psrlq      mm0,2               // 
		pand       mm3,[rec_msk_0x03]  // top fedcba98 bit 1-0;
		movq       mm5,mm1             // dup bot fedcba98;
		pand       mm1,[rec_msk_0xfc]  // bot fedcba98 bit 15-2;
		psrlq      mm1,2               //
		pand       mm5,[rec_msk_0x03]  // bot fedcba98 bit 1-0;
		movq       mm6,mm2             // dup top gfedcba9;
		pand       mm2,[rec_msk_0xfc]  // top gfedcba9 bit 15-2;
		psrlq      mm2,2               //
		pand       mm6,[rec_msk_0x03]  // top gfedcba9 bit 1-0;
		movq       mm7,mm4             // dup bot gfedcba9;
		pand       mm4,[rec_msk_0xfc]  // bot gfedcba9 bit 15-2;
		psrlq      mm4,2               //
		pand       mm7,[rec_msk_0x03]  // bot gfedcba9 bit 1-0;
		paddusb    mm0,mm1             // top + bot , fedcba98; bit 15-2;
		paddusb    mm2,mm4             // top + bot , gfedcba9; bit 15-2;
		paddusb    mm3,mm5             // t + b, f, 1-0;
		paddusb    mm6,mm7             // t + b, g, 1-0;
		paddusb    mm0,mm2             // t + b, f + g, 15-2;
		paddusb    mm3,mm6             // t + b, f + g, 1-0;
		paddusb    mm3,[rec_msk_0x02]  // round;
//		pxor       mm7,mm7             // clear mm7;
		pand       mm3,[rec_msk_0xfc]  // clear bit 1-0;
		psrlq      mm3,2
		movq       mm1,[esi]rec_mb_info.nTemp  // load blk0;
		movq       [edi],mm1                // output 76543210;
		paddusb    mm3,mm0                     // avg of 4*8;
		movq       [edi+8],mm3                    // output fedcba98;
		jg         block_width_16_align_hh11

		jmp        over

block_width_8:

		cmp        [esi]rec_mb_info.bForwardAlign,1
		je         block_width_8_align


		;block_width_8_unalign:

		mov        ecx,[esi]rec_mb_info.h
		mov        [i],ecx

		cmp        [esi]rec_mb_info.fxh,0
		jne        block_width_8_unalign_h10

		cmp        [esi]rec_mb_info.fyh,0
		jne        block_width_8_unalign_h01

		mov        eax,[esi]rec_mb_info.forw_mb0
		mov        edi,[esi]rec_mb_info.dest_mb0  //d0
		movq       mm5,[esi]rec_mb_info.nForwardLeftAlignBits0  // left >> nl;
		movq       mm6,[esi]rec_mb_info.nForwardRightAlignBits0 // right << nr;
		sub        eax,[esi]rec_mb_info.lfx1      // inc f0
		sub        edi,[esi]rec_mb_info.ldstx     // inc dst;

block_width_8_unalign_hh00:       

		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;
		movq       mm0,[eax]     // left of  3210xxxx;
		movq       mm1,[eax+8]   // right of ba987654;
		psllq      mm1,mm6       // 7654____;
		psrlq      mm0,mm5       // ____3210;
		por        mm0,mm1       // forw0; 76543210;
		add        eax,[esi]rec_mb_info.lfx1      // inc f0

		movq       mm2,[eax]     // left of  3210xxxx;
		movq       [edi],mm0     // output dst 76543210;
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;
		sub        ecx,2

		movq       mm0,mm2       // dup  3210xxxx;
		movq       mm1,[eax+8]   // right of ba987654;
		psllq      mm1,mm6       // 7654____;
		psrlq      mm0,mm5       // ____3210;
		por        mm0,mm1       // forw0; 76543210;
		movq       [edi],mm0     // output dst 76543210;

		jg         block_width_8_unalign_hh00

		jmp        over

block_width_8_unalign_h01:

		mov        eax,[esi]rec_mb_info.forw_mb0
		mov        edi,[esi]rec_mb_info.dest_mb0  //d0
		mov        ecx,[esi]rec_mb_info.lfx0      // pitch;
		sub        eax,[esi]rec_mb_info.lfx1// inc f0
		sub        edi,[esi]rec_mb_info.ldstx     // inc dst;

block_width_8_unalign_hh01:          

		add        eax,[esi]rec_mb_info.lfx1// inc f0
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;
		sub        [i],1
		movq       mm5,[esi]rec_mb_info.nForwardLeftAlignBits0  // left >> nl;
		movq       mm6,[esi]rec_mb_info.nForwardRightAlignBits0 // right << nr;
		movq       mm0,[eax]     // 3210xxxx;
		movq       mm1,[eax+8]   // xxxx7654;
		psrlq      mm0,mm5       // ____3210;
		psllq      mm1,mm6       // 7654____;
		movq       mm2,[eax+ecx]     // bot 3210xxxx;
		por        mm0,mm1       // top; 76543210;   mm0;
		movq       mm3,[eax+ecx+8]   // bot xxxx7654;
		psrlq      mm2,mm5           // bot ____3210;
		psllq      mm3,mm6           // 7654____;
		movq       mm4,[rec_msk_0x01]  // msk of bit 0;			  
		por        mm2,mm3           // bot; 76543210;   mm2;

		movq       mm6,[rec_msk_0xfe]  // msk of bit 15-1;
		movq       mm5,mm4             // dup msk of bit 0;
		LXAVGB(mm0,mm2,mm6,mm5,mm7)    // avg 76543210; to mm0;

		movq       [edi],mm0                // output 76543210;
		jg         block_width_8_unalign_hh01

		jmp        over

block_width_8_unalign_h10:

		cmp        [esi]rec_mb_info.fyh,0
		jne        block_width_8_unalign_h11

		mov        eax,[esi]rec_mb_info.forw_mb0
		mov        edi,[esi]rec_mb_info.dest_mb0  //d0
		sub        eax,[esi]rec_mb_info.lfx1      // inc f0
		sub        edi,[esi]rec_mb_info.ldstx     // inc dst;

block_width_8_unalign_hh10:          

		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;
		dec        ecx    // ecx is not used in src pitch; 
		movq       mm5,[esi]rec_mb_info.nForwardLeftAlignBits0  // left >> nl;
		movq       mm6,[esi]rec_mb_info.nForwardRightAlignBits0 // right << nr;
		movq       mm0,[eax]     // 3210xxxx;
		movq       mm1,[eax+8]   // xxxx7654; 
		movq       mm4,mm0       // dup byte1;
		movq       mm7,mm1       // dup byte8;
		movq       mm3,mm1       // dup middle;
		psrlq      mm0,mm5       // ____3210;
		psllq      mm1,mm6       // 7654____;
		movq       mm5,[esi]rec_mb_info.nForwardLeftAlignBits1  // left >> nl;
		por        mm0,mm1       // forw0; 76543210; mm0;
		movq       mm6,[esi]rec_mb_info.nForwardRightAlignBits1 // right << nr;
		movq       mm1,mm7            // dup middle, xxx87654;
		psrlq      mm4,mm5            // _____321;
		psllq      mm7,mm6            // 87654___;
		movq       mm5,[rec_msk_0x01]     // msk of bit 0;			  
		por        mm4,mm7            // 87654321; mm4;

		movq       mm6,[rec_msk_0xfe]     // msk of bit 15-1;
		movq       mm3,mm5                // dup msk of bit 0;
		LXAVGB(mm0,mm4,mm6,mm5,mm7)       // avg 76543210; to mm0;

		movq       [edi],mm0                // output 76543210;
		jg         block_width_8_unalign_hh10

		jmp        over

block_width_8_unalign_h11:

		mov        eax,[esi]rec_mb_info.forw_mb0
		mov        edi,[esi]rec_mb_info.dest_mb0  //d0
		mov        ecx,[esi]rec_mb_info.lfx0      // pitch;
		sub        eax,[esi]rec_mb_info.lfx1      // inc f0
		sub        edi,[esi]rec_mb_info.ldstx     // inc dst;

block_width_8_unalign_hh11:          

		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;
		sub        [i],1
		movq       mm5,[esi]rec_mb_info.nForwardLeftAlignBits0  // left >> nl;
		movq       mm6,[esi]rec_mb_info.nForwardRightAlignBits0 // right << nr;
		movq       mm0,[eax]     // top 3210xxxx;
		movq       mm1,[eax+8]   // top xxx87654; 
		movq       mm4,mm0       // dup byte1;
		movq       mm7,mm1       // dup byte8;
		psrlq      mm0,mm5       // ____3210;
		psllq      mm1,mm6       // 7654____;
		movq       mm2,[esi]rec_mb_info.nForwardLeftAlignBits1  // left >> nl;
		por        mm0,mm1       // top; 76543210; mm0;
		movq       mm3,[esi]rec_mb_info.nForwardRightAlignBits1 // right << nr;
		movq       [esi]rec_mb_info.nTemp,mm0     // save top 76543210;
		psrlq      mm4,mm2            // _____321;
		psllq      mm7,mm3            // 87654___;
		movq       mm0,[eax+ecx]     //  bot 3210xxxx;
		por        mm4,mm7            // top; 87654321; mm4;
		movq       mm1,[eax+ecx+8]   //  bot xxx87654; 
		movq       [esi+16]rec_mb_info.nTemp,mm4    // save top 87654321;	

		// begin to load bot data;
		movq       mm4,mm0       // dup byte1;
		movq       mm7,mm1       // dup byte8;
		psrlq      mm0,mm5       // bot ____3210;
		psllq      mm1,mm6       // bot 7654____;
		psrlq      mm4,mm2       // _____321;
		por        mm0,mm1       // bot 76543210; mm0;
		psllq      mm7,mm3       // 87654___;

		// begin to do 4 * 8 avg;
		movq       mm1,mm0                                // bot 76543210; mm1;
		por        mm4,mm7                                // bot 87654321; mm4;
		movq       mm0,[esi]rec_mb_info.nTemp             // top 76543210; mm0;
		movq       mm2,[esi+16]rec_mb_info.nTemp          // top 87654321; mm2;

		movq       mm3,mm0             // dup top 76543210;
		pand       mm0,[rec_msk_0xfc]  // top 76543210 bit 15-2;
		psrlq      mm0,2               // 
		pand       mm3,[rec_msk_0x03]  // top 76543210 bit 1-0;

		movq       mm5,mm1             // dup bot 76543210;
		pand       mm1,[rec_msk_0xfc]  // bot 76543210 bit 15-2;
		psrlq      mm1,2               //
		pand       mm5,[rec_msk_0x03]  // bot 76543210 bit 1-0;

		movq       mm6,mm2             // dup top 87654321;
		pand       mm2,[rec_msk_0xfc]  // top 87654321 bit 15-2;
		psrlq      mm2,2               //
		pand       mm6,[rec_msk_0x03]  // top 87654321 bit 1-0;

		movq       mm7,mm4             // dup bot 87654321;
		pand       mm4,[rec_msk_0xfc]  // bot 87654321 bit 15-2;
		psrlq      mm4,2               //
		pand       mm7,[rec_msk_0x03]  // bot 87654321 bit 1-0;

		paddusb    mm0,mm1             // top + bot , 76543210; bit 15-2;
		paddusb    mm2,mm4             // top + bot , 87654321; bit 15-2;
		paddusb    mm3,mm5             // t + b, 7, 1-0;
		paddusb    mm6,mm7             // t + b, 8, 1-0;
		paddusb    mm3,mm6             // t + b, 7 + 8, 1-0;
		paddusb    mm3,[rec_msk_0x02]  // round;
		pand       mm3,[rec_msk_0xfc]  // clear bit 1-0;
		psrlq      mm3,2
		paddusb    mm0,mm2             // t + b, 7 + 8, 15-2;
		paddusb    mm0,mm3             // avg of 4*8;
		movq       [edi],mm0                // output 76543210;
		jg         block_width_8_unalign_hh11

		jmp        over


block_width_8_align:

		mov        ecx,[esi]rec_mb_info.h
		mov        [i],ecx

		cmp        [esi]rec_mb_info.fxh,0
		jne        block_width_8_align_h10

		cmp        [esi]rec_mb_info.fyh,0
		jne        block_width_8_align_h01

		mov        eax,[esi]rec_mb_info.forw_mb0
		mov        edi,[esi]rec_mb_info.dest_mb0  //d0
		sub        eax,[esi]rec_mb_info.lfx1      // inc f0
		sub        edi,[esi]rec_mb_info.ldstx     // inc dst;			

block_width_8_align_hh00:       

		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;			
		movq       mm0,[eax]     // 76543210;
		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		movq       [edi],mm0     // output dst 76543210;
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;

		movq       mm0,[eax]     // 76543210;
		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		movq       [edi],mm0     // output dst 76543210;
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;

		movq       mm0,[eax]     // 76543210;
		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		movq       [edi],mm0     // output dst 76543210;
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;
		sub        ecx,4

		movq       mm0,[eax]     // 76543210;
		movq       [edi],mm0     // output dst 76543210;
		jg         block_width_8_align_hh00

		jmp        over

block_width_8_align_h01:

		mov        eax,[esi]rec_mb_info.forw_mb0
		mov        edi,[esi]rec_mb_info.dest_mb0  //d0
		mov        ecx,[esi]rec_mb_info.lfx0      // pitch;
		sub        eax,[esi]rec_mb_info.lfx1      // inc f0
		sub        edi,[esi]rec_mb_info.ldstx     // inc dst;

block_width_8_align_hh01:          

		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;
		movq       mm0,[eax]           // top 76543210;
		movq       mm5,[rec_msk_0x01]  // msk of bit 0;			  
		movq       mm1,[eax+ecx]       // bot 76543210;
		movq       mm6,[rec_msk_0xfe]  // msk of bit 15-1;
		LXAVGB(mm0,mm1,mm6,mm5,mm7)    // avg 76543210; to mm0;
		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		movq       [edi],mm0                // output 76543210;
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;
		sub        [i],2

		movq       mm0,[eax]           // top 76543210;
		movq       mm5,[rec_msk_0x01]  // msk of bit 0;			  
		movq       mm1,[eax+ecx]       // bot 76543210;
		movq       mm6,[rec_msk_0xfe]  // msk of bit 15-1;
		LXAVGB(mm0,mm1,mm6,mm5,mm7)    // avg 76543210; to mm0;
		movq       [edi],mm0                // output 76543210;
		jg         block_width_8_align_hh01

		jmp        over

block_width_8_align_h10:

		cmp        [esi]rec_mb_info.fyh,0
		jne        block_width_8_align_h11

		mov        eax,[esi]rec_mb_info.forw_mb0
		mov        edi,[esi]rec_mb_info.dest_mb0  //d0
		sub        eax,[esi]rec_mb_info.lfx1      // inc f0
		sub        edi,[esi]rec_mb_info.ldstx     // inc dst;

block_width_8_align_hh10:  

		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;
		dec        ecx    // ecx is not used in src pitch; 
		movq       mm0,[eax]     // 76543210;  mm0
		movq       mm2,[eax+8]   // xxxxxxx8;  mm2;
		movq       mm1,mm0       // dup byte1;
		psllq      mm2,56        // 8_______;
		psrlq      mm1,8         // _7654321;
		movq       mm5,[rec_msk_0x01]     // msk of bit 0;			  
		por        mm1,mm2       // 87654321;  mm1;
		movq       mm6,[rec_msk_0xfe]     // msk of bit 15-1;
		LXAVGB(mm0,mm1,mm6,mm5,mm7)       // avg 76543210; to mm0;
		movq       [edi],mm0                // output 76543210;
		jg         block_width_8_align_hh10

		jmp        over

block_width_8_align_h11:

		mov        eax,[esi]rec_mb_info.forw_mb0
		mov        edi,[esi]rec_mb_info.dest_mb0  //d0
		mov        ecx,[esi]rec_mb_info.lfx0     // pitch;
		sub        eax,[esi]rec_mb_info.lfx1      // inc f0
		sub        edi,[esi]rec_mb_info.ldstx     // inc dst;

block_width_8_align_hh11:          

		add        eax,[esi]rec_mb_info.lfx1      // inc f0
		add        edi,[esi]rec_mb_info.ldstx     // inc dst;
		sub        [i],1
		movq       mm0,[eax]     // top 76543210;
		movq       mm2,[eax+8]   // top xxxxxxx8; 
		movq       [esi]rec_mb_info.nTemp,mm0     // save top 76543210;
		movq       mm1,mm0       // dup byte1;
		psllq      mm2,56        // 8_______;
		psrlq      mm1,8         // _7654321;
		movq       mm0,[eax+ecx]     // bot 76543210;
		por        mm1,mm2       // 87654321;  mm1;
		movq       [esi+32]rec_mb_info.nTemp,mm0     // save bot 76543210;
		movq       mm2,[eax+ecx+8]   // bot xxxxxxx8; 
		movq       [esi+16]rec_mb_info.nTemp,mm1     // save top 87654321;

		// begin to load bot data;
		movq       mm1,mm0       // dup byte1;
		psllq      mm2,56        // 8_______;
		psrlq      mm1,8         // _7654321;
		por        mm1,mm2       // bot 87654321;  mm1;

		// begin to do 4 * 8 avg;
		movq       mm0,[esi]rec_mb_info.nTemp             // top 76543210;
		movq       mm2,[esi+16]rec_mb_info.nTemp          // top 87654321;
		movq       mm4,mm1             // copy bot 87654321;
		movq       mm3,mm0             // dup top 76543210;
		movq       mm1,[esi+32]rec_mb_info.nTemp  // bot 76543210l
		pand       mm0,[rec_msk_0xfc]  // top 76543210 bit 15-2;
		psrlq      mm0,2               // 
		pand       mm3,[rec_msk_0x03]  // top 76543210 bit 1-0;
		movq       mm5,mm1             // dup bot 76543210;
		pand       mm1,[rec_msk_0xfc]  // bot 76543210 bit 15-2;
		psrlq      mm1,2               //
		pand       mm5,[rec_msk_0x03]  // bot 76543210 bit 1-0;
		movq       mm6,mm2             // dup top 87654321;
		pand       mm2,[rec_msk_0xfc]  // top 87654321 bit 15-2;
		psrlq      mm2,2               //
		pand       mm6,[rec_msk_0x03]  // top 87654321 bit 1-0;
		movq       mm7,mm4             // dup bot 87654321;
		pand       mm4,[rec_msk_0xfc]  // bot 87654321 bit 15-2;
		psrlq      mm4,2               //
		pand       mm7,[rec_msk_0x03]  // bot 87654321 bit 1-0;
		paddusb    mm0,mm1             // top + bot , 76543210; bit 15-2;
		paddusb    mm2,mm4             // top + bot , 87654321; bit 15-2;
		paddusb    mm3,mm5             // t + b, 7, 1-0;
		paddusb    mm6,mm7             // t + b, 8, 1-0;
		paddusb    mm0,mm2             // t + b, 7 + 8, 15-2;
		paddusb    mm3,mm6             // t + b, 7 + 8, 1-0;
		paddusb    mm3,[rec_msk_0x02]  // round;
		pand       mm3,[rec_msk_0xfc]  // clear bit 1-0;
		psrlq      mm3,2
		paddusb    mm3,mm0             // avg of 4*8;
		movq       [edi],mm3                // output 76543210;
		jg         block_width_8_align_hh11

over:   
		pop       ebx
		emms
	}

#else

#endif


}
//}



/******************************************************** 
c source code, only used to demonstrate the compute logic;
700 rows; 
*********************************************************/

//{ s32ra coded block;
#define  _AVG_DW(A,B)  (((A&0xfefefefe)>>1)+((B&0xfefefefe)>>1)|((A|B)&0x01010101))
#define  AVG_DW(A,B,C) *((u32*)(C))=_AVG_DW(A,B)

#define  AVG4_DW(A,B,C,D,E)  \
	AVG_DW(_AVG_DW(A,B),_AVG_DW(C,D),E)


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

static void rec_avgblock_c(rec_mb_info* rmi)
{
	s32 i,j;

	u32 dwTmp[4];

	if( rmi->nPictureType == B_TYPE )	{
		if( rmi->w == 8 ){
			for(j =0 ; j<rmi->h; j++)	{
				dwTmp[0] = *((u32*)rmi->forw_mb0);
				dwTmp[1] = *((u32*)rmi->back_mb0);
				AVG_DW(dwTmp[0],dwTmp[1],rmi->forw_mb0);

				dwTmp[0] = *((u32*)(rmi->forw_mb0 + 4));
				dwTmp[1] = *((u32*)(rmi->back_mb0 + 4));
				AVG_DW(dwTmp[0],dwTmp[1],rmi->forw_mb0+4);

				rmi->forw_mb0 += rmi->lfx0;
				rmi->back_mb0 += rmi->lfx0;
			}
		}
		else{
			for(j =0 ; j<rmi->h; j++)	{
				dwTmp[0] = *((u32*)rmi->forw_mb0);
				dwTmp[1] = *((u32*)rmi->back_mb0);
				AVG_DW(dwTmp[0],dwTmp[1],rmi->forw_mb0);

				dwTmp[0] = *((u32*)(rmi->forw_mb0 + 4));
				dwTmp[1] = *((u32*)(rmi->back_mb0 + 4));
				AVG_DW(dwTmp[0],dwTmp[1],rmi->forw_mb0+4);

				dwTmp[0] = *((u32*)(rmi->forw_mb0 + 8));
				dwTmp[1] = *((u32*)(rmi->back_mb0 + 8));
				AVG_DW(dwTmp[0],dwTmp[1],rmi->forw_mb0+8);

				dwTmp[0] = *((u32*)(rmi->forw_mb0 + 12));
				dwTmp[1] = *((u32*)(rmi->back_mb0 + 12));
				AVG_DW(dwTmp[0],dwTmp[1],rmi->forw_mb0+12);

				rmi->forw_mb0 += rmi->lfx0;
				rmi->back_mb0 += rmi->lfx0;
			}

		}

		return;
	}


	// accurate code;
	if( rmi->w == 8 ){

		for(j =0 ; j<rmi->h; j++){

			rmi->forw_mb0[0] = g_pMcClip[ ( rmi->forw_mb0[0] + rmi->back_mb0[0] + 1 ) >> 1 ];
			rmi->forw_mb0[1] = g_pMcClip[ ( rmi->forw_mb0[1] + rmi->back_mb0[1] + 1 ) >> 1 ];
			rmi->forw_mb0[2] = g_pMcClip[ ( rmi->forw_mb0[2] + rmi->back_mb0[2] + 1 ) >> 1 ];
			rmi->forw_mb0[3] = g_pMcClip[ ( rmi->forw_mb0[3] + rmi->back_mb0[3] + 1 ) >> 1 ];
			rmi->forw_mb0[4] = g_pMcClip[ ( rmi->forw_mb0[4] + rmi->back_mb0[4] + 1 ) >> 1 ];
			rmi->forw_mb0[5] = g_pMcClip[ ( rmi->forw_mb0[5] + rmi->back_mb0[5] + 1 ) >> 1 ];
			rmi->forw_mb0[6] = g_pMcClip[ ( rmi->forw_mb0[6] + rmi->back_mb0[6] + 1 ) >> 1 ];
			rmi->forw_mb0[7] = g_pMcClip[ ( rmi->forw_mb0[7] + rmi->back_mb0[7] + 1 ) >> 1 ];

			rmi->forw_mb0 += rmi->lfx0;
			rmi->back_mb0 += rmi->lfx0;
		}

	}
	else{
		for(j =0 ; j<rmi->h; j++){

			for( i = 0; i < 2 ; i ++ ){
				rmi->forw_mb0[i*8+0] = g_pMcClip[ ( rmi->forw_mb0[i*8+0] + rmi->back_mb0[i*8+0] + 1 ) >> 1 ];
				rmi->forw_mb0[i*8+1] = g_pMcClip[ ( rmi->forw_mb0[i*8+1] + rmi->back_mb0[i*8+1] + 1 ) >> 1 ];
				rmi->forw_mb0[i*8+2] = g_pMcClip[ ( rmi->forw_mb0[i*8+2] + rmi->back_mb0[i*8+2] + 1 ) >> 1 ];
				rmi->forw_mb0[i*8+3] = g_pMcClip[ ( rmi->forw_mb0[i*8+3] + rmi->back_mb0[i*8+3] + 1 ) >> 1 ];
				rmi->forw_mb0[i*8+4] = g_pMcClip[ ( rmi->forw_mb0[i*8+4] + rmi->back_mb0[i*8+4] + 1 ) >> 1 ];
				rmi->forw_mb0[i*8+5] = g_pMcClip[ ( rmi->forw_mb0[i*8+5] + rmi->back_mb0[i*8+5] + 1 ) >> 1 ];
				rmi->forw_mb0[i*8+6] = g_pMcClip[ ( rmi->forw_mb0[i*8+6] + rmi->back_mb0[i*8+6] + 1 ) >> 1 ];
				rmi->forw_mb0[i*8+7] = g_pMcClip[ ( rmi->forw_mb0[i*8+7] + rmi->back_mb0[i*8+7] + 1 ) >> 1 ];
			}

			rmi->forw_mb0 += rmi->lfx0;
			rmi->back_mb0 += rmi->lfx0;
		}

	}

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

static void rec_addblock_c(rec_mb_info* rmi)
{
	s32 i,j;
	if( rmi->w == 16 ){
		for(j =0 ; j<rmi->h; j++)	{
			for(i =0; i<8; i++)	{
				rmi->dest_mb0[i]= g_pMcClip[ rmi->forw_mb0[i] + rmi->blk0[i] ];
			}
			for(i =0; i<8; i++)	{
				rmi->dest_mb0[8+i]= g_pMcClip[ rmi->forw_mb0[8+i] + rmi->blk1[i] ];
			}
			rmi->forw_mb0 += rmi->lfx0;
			rmi->dest_mb0 += rmi->ldstx;
			rmi->blk0 += rmi->lblkx;
			rmi->blk1 += rmi->lblkx;
		}
	}
	else{
		for(j =0 ; j<rmi->h; j++){
			for(i =0; i<8; i++)	{
				rmi->dest_mb0[i]= g_pMcClip[ rmi->forw_mb0[i] + rmi->blk0[i] ];
			}
			rmi->forw_mb0 += rmi->lfx0;
			rmi->dest_mb0 += rmi->ldstx;
			rmi->blk0 += rmi->lblkx;
			rmi->blk1 += rmi->lblkx;
		}
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
// accurate code;
***************************************************************************/
static void pfrm_rec_2b_1_c(rec_mb_info* rmi)
{
	s32 i,j;

	u8* src = rmi->forw_mb0 + ( rmi->bForwardAlign ? 0 : (s32) ( rmi->nForwardLeftAlignBits0 >> 3 ) );

	if( rmi->w == 16 ){   // w == 16;

		if(!rmi->fxh && !rmi->fyh){
			for (j=0; j<rmi->h; j++) {
				memcpy(rmi->dest_mb0,src,16);
				src += rmi->lfx1;
				rmi->dest_mb0 += rmi->ldstx;
			}
		}
		else if (!rmi->fxh && rmi->fyh)	{

			for (j=0; j<rmi->h; j++){
				for(i = 0; i < 16 ; i ++ ){
					rmi->dest_mb0[i] = g_pMcClip[ ( src[i] + src[i+rmi->lfx0] + 1 ) >> 1 ];
				}

				src += rmi->lfx1;
				rmi->dest_mb0 += rmi->ldstx;
			}
		}
		else if (rmi->fxh && !rmi->fyh){

			for (j=0; j<rmi->h; j++){

				for(i = 0; i < 16 ; i ++ ){
					rmi->dest_mb0[i] = g_pMcClip[ ( src[i] + src[i+1] + 1 ) >> 1 ];
				}

				src += rmi->lfx1;
				rmi->dest_mb0 += rmi->ldstx;
			}

		}
		else {
			for (j=0; j<rmi->h; j++){
				for(i = 0; i < 16 ; i ++ ){
					rmi->dest_mb0[i] = g_pMcClip[ ( src[i] + src[i+rmi->lfx0 + 1] + 1 ) >> 1 ];
				}

				src += rmi->lfx1;
				rmi->dest_mb0 += rmi->ldstx;
			}
		}

		return;
	}


	if(!rmi->fxh && !rmi->fyh){
		for (j=0; j<rmi->h; j++) {
			memcpy(rmi->dest_mb0,src,8);
			src += rmi->lfx1;
			rmi->dest_mb0 += rmi->ldstx;
		}
	}
	else if (!rmi->fxh && rmi->fyh){
		for (j=0; j<rmi->h; j++){
			for( i = 0; i < 8 ; i ++ ){
				rmi->dest_mb0[i] = g_pMcClip[ ( src[i] + src[i+rmi->lfx0] + 1 ) >> 1 ];
			}

			src += rmi->lfx1;
			rmi->dest_mb0 += rmi->ldstx;
		}
	}
	else if (rmi->fxh && !rmi->fyh){
		for (j=0; j<rmi->h; j++){
			for( i = 0; i < 8 ; i ++ ){
				rmi->dest_mb0[i] = g_pMcClip[ ( src[i] + src[i+1] + 1 ) >> 1 ];
			}

			src += rmi->lfx1;
			rmi->dest_mb0 += rmi->ldstx;
		}

	}
	else{

		for (j=0; j<rmi->h; j++){
			for(i = 0; i < 8 ; i ++ ){
				rmi->dest_mb0[i] = g_pMcClip[ ( src[i] + src[i+rmi->lfx0 + 1] + 1 ) >> 1 ];
			}

			src += rmi->lfx1;
			rmi->dest_mb0 += rmi->ldstx;
		}
	}

}
//}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static void bfrm_rec_2b_1_c(rec_mb_info* rmi)
{
	s32 i,j;

	u8* src = rmi->forw_mb0 + ( rmi->bForwardAlign ? 0 : (s32) ( rmi->nForwardLeftAlignBits0 >> 3 ) );

	if( rmi->w == 16 ){   // w == 16;

		if(!rmi->fxh && !rmi->fyh){
			for (j=0; j<rmi->h; j++) {
				memcpy(rmi->dest_mb0,src,16);
				src += rmi->lfx1;
				rmi->dest_mb0 += rmi->ldstx;
			}
		}
		else if (!rmi->fxh && rmi->fyh)	{

			for (j=0; j<rmi->h; j++){

				for(i = 0; i < 16 ; i += 4 ){
					AVG_DW(*(u32*)(src),*(u32*)(src+rmi->lfx0),rmi->dest_mb0);
					AVG_DW(*(u32*)(src+4),*(u32*)(src+rmi->lfx0+4),rmi->dest_mb0+4);
					AVG_DW(*(u32*)(src+8),*(u32*)(src+rmi->lfx0+8),rmi->dest_mb0+8);
					AVG_DW(*(u32*)(src+12),*(u32*)(src+rmi->lfx0+12),rmi->dest_mb0+12);
				}

				src += rmi->lfx1;
				rmi->dest_mb0 += rmi->ldstx;
			}
		}
		else if (rmi->fxh && !rmi->fyh){

			for (j=0; j<rmi->h; j++){

				for(i = 0; i < 16 ; i += 4 ){
					AVG_DW(*(u32*)(src),*(u32*)(src+1),rmi->dest_mb0);
					AVG_DW(*(u32*)(src+4),*(u32*)(src+1+4),rmi->dest_mb0+4);
					AVG_DW(*(u32*)(src+8),*(u32*)(src+1+8),rmi->dest_mb0+8);
					AVG_DW(*(u32*)(src+12),*(u32*)(src+1+12),rmi->dest_mb0+12);
				}

				src += rmi->lfx1;
				rmi->dest_mb0 += rmi->ldstx;
			}

		}
		else {

			for (j=0; j<rmi->h; j++){

				for(i = 0; i < 16 ; i += 4 ){
					AVG_DW(*(u32*)(src),*(u32*)(src+rmi->lfx0+1),rmi->dest_mb0);
					AVG_DW(*(u32*)(src+4),*(u32*)(src+rmi->lfx0+1+4),rmi->dest_mb0+4);
					AVG_DW(*(u32*)(src+8),*(u32*)(src+rmi->lfx0+1+8),rmi->dest_mb0+8);
					AVG_DW(*(u32*)(src+12),*(u32*)(src+rmi->lfx0+1+12),rmi->dest_mb0+12);
				}

				src += rmi->lfx1;
				rmi->dest_mb0 += rmi->ldstx;
			}
		}

		return;
	}


	if(!rmi->fxh && !rmi->fyh){
		for (j=0; j<rmi->h; j++) {
			memcpy(rmi->dest_mb0,src,8);
			src += rmi->lfx1;
			rmi->dest_mb0 += rmi->ldstx;
		}
	}
	else if (!rmi->fxh && rmi->fyh){
		for (j=0; j<rmi->h; j++){
			for(i = 0; i < 8 ; i += 4 ){
				AVG_DW(*(u32*)(src),*(u32*)(src+rmi->lfx0),rmi->dest_mb0);
				AVG_DW(*(u32*)(src+4),*(u32*)(src+rmi->lfx0+4),rmi->dest_mb0+4);
			}
			src += rmi->lfx1;
			rmi->dest_mb0 += rmi->ldstx;
		}
	}
	else if (rmi->fxh && !rmi->fyh){
		for (j=0; j<rmi->h; j++){
			for(i = 0; i < 8 ; i += 4 ){
				AVG_DW(*(u32*)(src),*(u32*)(src+1),rmi->dest_mb0);
				AVG_DW(*(u32*)(src+4),*(u32*)(src+1+4),rmi->dest_mb0+4);
			}
			src += rmi->lfx1;
			rmi->dest_mb0 += rmi->ldstx;
		}
	}
	else{
		for (j=0; j<rmi->h; j++){
			for(i = 0; i < 8 ; i += 4 ){
				AVG_DW(*(u32*)(src),*(u32*)(src+rmi->lfx0+1),rmi->dest_mb0);
				AVG_DW(*(u32*)(src+4),*(u32*)(src+rmi->lfx0+1+4),rmi->dest_mb0+4);
			}
			src += rmi->lfx1;
			rmi->dest_mb0 += rmi->ldstx;
		}
	}

}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static void rec_2b_1_c(rec_mb_info* rmi)
{
	if( rmi->nPictureType == P_TYPE ){
		pfrm_rec_2b_1_c(rmi);
	}
	else{
		bfrm_rec_2b_1_c(rmi);
	}
}





