// LxIDCT_SSE2.h: interface for the LxIDCT_SSE2 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LXIDCT_SSE2_H__909E81AF_1313_4B9F_A98E_981F3FBF793C__INCLUDED_)
#define AFX_LXIDCT_SSE2_H__909E81AF_1313_4B9F_A98E_981F3FBF793C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000




#endif // !defined(AFX_LXIDCT_SSE2_H__909E81AF_1313_4B9F_A98E_981F3FBF793C__INCLUDED_)
