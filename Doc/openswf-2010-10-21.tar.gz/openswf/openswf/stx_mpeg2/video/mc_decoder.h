
/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-11
***********************************************************************************/
#ifndef __MC_DECODER_H__
#define __MC_DECODER_H__



#include "frame_decoder.h"


#if defined( __cplusplus )
extern "C" {
#endif



//{ private data structure used to pass parameters
struct rec_mb_info
{
	s64        nTemp[8*2];   // used for save temp data in rec_mb;

	//  mmx should align to 8;
	//  left8 >> nAlignBits; right8 >> (64 - nAlignBits);
	//  dst8 = left8 | right8;
	s64        nForwardLeftAlignBits0;   
	s64        nForwardRightAlignBits0;

	s64        nForwardLeftAlignBits1;   // x half pel used;
	s64        nForwardRightAlignBits1;


	u8			*forw_mb0;
	u8			*back_mb0;
	u8			*dest_mb0;
	u8			*forw_mb1;
	u8			*back_mb1;
	u8			*dest_mb1;
	s16			*blk0;
	s16			*blk1;
	//}
	//{ halg pel flag
	u32			fxh;
	u32			fyh;
	//} 
	s32			h;
	s32			w;
	s32			lfx0;
	s32			lfx1;
	s32			lblkx;
	s32			ldstx;

	u32			bAvgFlag;
	u32			skip_bottom_field_flag;
	u32			bForwardAlign;

	s32			nPictureType;
};


struct mc_decoder
{
	rec_mb_info           m_RecInfo;

	s32                   m_nMaxVector;
	s32                   m_nMinVector;

	s32                   m_nWidth;
	s32                   m_nHeight;

	s32                   m_nCodedPicturePitch;
	s32                   m_nChromaPitch;
	s32                   m_nChromaFormat;
	s32                   m_nOutputPit;
	s32                   m_bMPEG2Flag;

	VideoFrame*           m_lpBackwardPicture;
	VideoFrame*           m_lpForwardPicture;

	s32                   m_bSecondField;
	b32                   m_bPref;
	s32                   m_nStwTop;
	s32                   m_nStwBot;

	// param
	RecCoe*		reccoe;
	RecCoe*     reccoe1;
	MacroBlock*	macro_block;

	s32			nPictureCodingType;
	s32			nPictureStructure;
	s32			bTopFieldFirst;

	s32			dct_type;
	s32			macroblock_type;
	s32			motion_type;
	s32         stwtype;
	b32			bSkipBot;
	s32			PMV[2][2][2];
	s32			motion_vertical_field_select[2][2];
	s32         DMV[2][2];       // a16;  
	s32         dmvector[2+2];   // 2+2 a16;
	u32         dwMbPosX;  // macroblock position x
	u32         dwMbPosY;  // macrolbock position y
};


void Update
(
	mc_decoder* the,
	s32 nMaxVector,
	s32 nMinVector,
	s32 nWidth,
	s32 nHeight,
	s32 nCodedPicturePitch,
	s32 nChromaPitch,
	s32 nChromaFormat,
	s32 bMPEG2Flag
);

void rec_mb(mc_decoder* the);

void UpdatePredPicture
(
	mc_decoder*  the,
	VideoFrame*  lpBackwardPicture,
	VideoFrame*  lpForwardPicture,
	s32          nOutputPit,
	s32          bSecondField,
	s32			nPictureType,
	s32			bTopFiledFirst,
	s32			nPictureStructure

);


void init_mc_decoder(u32 mmflag);

mc_decoder* create_mc_decoder(frame_decoder* fdec);

void close_mc_decoder(mc_decoder* the);





#if defined( __cplusplus )
}
#endif

#endif // __MC_DECODER_H__

