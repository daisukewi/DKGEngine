// LxIDCT.h: interface for the LxIDCT class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(__LXIDCT_H__)
#define __LXIDCT_H__

#include "stx_base_type.h"

#if defined( __cplusplus )
extern "C" {
#endif

#define CHWANG_SECOND_FIELD_SPARSE 
#define AAN_SECOND_FIELD_SPARSE

#define W1 2841 /* 2048*sqrt(2)*cos(1*pi/16) */
#define W2 2676 /* 2048*sqrt(2)*cos(2*pi/16) */
#define W3 2408 /* 2048*sqrt(2)*cos(3*pi/16) */
#define W5 1609 /* 2048*sqrt(2)*cos(5*pi/16) */
#define W6 1108 /* 2048*sqrt(2)*cos(6*pi/16) */
#define W7 565  /* 2048*sqrt(2)*cos(7*pi/16) */

#define PI 3.14159265359

#define IDCT_TAB_RC          12
#define IDCT_TAB_RC_DELTA    4
#define IDCT_TAB_RC0         (IDCT_TAB_RC - IDCT_TAB_RC_DELTA)
#define IDCT_TAB_ROUND0      (1<<(IDCT_TAB_RC0-1))
#define IDCT_TAB_RC1         (IDCT_TAB_RC + IDCT_TAB_RC_DELTA + 1)
#define IDCT_TAB_ROUND1      (1<<(IDCT_TAB_RC1-1))

#define IDCT_TAB_DC_RC0      (IDCT_TAB_RC_DELTA - 1)    // 4; 
#define IDCT_TAB_DC_RC1      (IDCT_TAB_RC_DELTA + 2)    // 6;
#define IDCT_TAB_DC_ROUND1   (1<<(IDCT_TAB_DC_RC1-1))

#define SET_NZ_MASK(A) (A)
#define SET_NZ_INF(A)  (A&0x00ffff00)

#define GET_COL_MASK(A)  ( A & 0xff )
#define GET_ROW_MASK(A)  ( A >> 24  )
#define GET_NZ_NUM(A)    ( (A >> 8) & 0xff   )
#define GET_NZ_POS(A)    ( A >> 16 )


#define IDCT_TAB_MMX_SCALE         15 
#define IDCT_TAB_MMX_RC1           ( 1 + IDCT_TAB_RC_DELTA - 1 )
#define IDCT_TAB_MMX_RD1           ( 1 << (IDCT_TAB_MMX_RC1-1) )


STX_INTERF(LxNzInf);
STX_INTERF(LxIdctInf);

struct LxNzInf{
	u8    byColMask;         // 1 << (j&7);
	u8    byBlkNz;           // byBlkNz ++;
	u8    byBlkNzPos;        // byBlkNzPos = j;
	u8    byRowMask;         // 1 << (j>>3);
};

struct LxIdctInf{
	u32   dwNzInf;          // += SET_NZ_INF
	u32   dwColMask;        // |= SET_NZ_MASK
	u8    byRowPos[8];      // byRowPos[j>>3] |= msk[j] ;    //  1 << (j&7);
};



extern u32 g_dwBlockInf[64];
extern u8  g_RowNz[256];
extern u32 g_RowPos[256];
extern u32 g_dwColMsk[8];
extern s16* const iclp;

extern DECLARE_ALIGNED_16( const s32, IDCT_TAB_AAN[8*8]);
extern DECLARE_ALIGNED_16( const s32, IDCT_TAB[8][8]);
extern DECLARE_ALIGNED_16( const s16, IDCT_TAB_ROW[8][8]);
extern DECLARE_ALIGNED_16( const s16, IDCT_TAB_COL[8][8][4] );


#define RC0        12

#define RC00       10
#define ROUND0     (1<<(RC00-1))

#define RC1        (RC0 + 5 + (RC0-RC00) )
#define ROUND1     (1<<(RC1-1))

#define MAKE_SCALE(A) ( (s32) ( A*(1<<RC0) +  (A >= 0 ? 0.5 : -0.5 ) ) )

#define C1        MAKE_SCALE(1)         // 1
#define C2        MAKE_SCALE(1.84776)   // 2 COS (PI/8) 1.84776
#define C4        MAKE_SCALE(1.41421)   // SQRT(2)  1.41421 
#define C6        MAKE_SCALE(0.76537)   // 2 SIN (PI/8)  0.76537
#define C6pC2     MAKE_SCALE(2.61313)   // C6+C2   2.61313
#define C6sC2     MAKE_SCALE(-1.08239)  //  -1.08239

#define ROLAAN    12
#define ROUNDAAN (1<<(ROLAAN-1))

void dct_coe_statistic(b32 bIntra, LxIdctInf* pos );
void Initialize_Fast_IDCT();

void idct_sparse_dc(s16* blk);
void idct_sparse_ac(s16* blk, LxIdctInf* pos );
void adder_128_c(s16 *blk,u8* dst,s32 pit);

void idct_aan(s16* blk, LxIdctInf* pos);
void idct_chw_mmx_ex(s16* blk,LxIdctInf* pos );
void idct_mmx_ex(s16* blk,LxIdctInf* pos);

void idct_mmx(s16* blk, LxIdctInf* pos);
void idct32_mmx(s16 *blk, LxIdctInf* pos);
void idct_sparse_dc_mmx(s16* blk);
void idct_sparse_ac_mmx(s16* blk,LxIdctInf* pos);
void adder_128_mmx(s16 *blk,u8* dst,s32 pit);

void idct_sse2_ex(s16* blk,LxIdctInf* pos);

void idct_sse2(s16* blk, LxIdctInf* pos);
void idct32_sse2(s16 *blk, LxIdctInf* pos);
void idct_sparse_dc_sse2(s16* blk);
void idct_sparse_ac_sse2(s16* blk,LxIdctInf* pos);
void adder_128_sse2(s16 *blk,u8* dst,s32 pit);

void idct_aan_bridge_ex(s16* blk, LxIdctInf* pos );

typedef void (*idct_proc_entry) ( s16* , LxIdctInf* );

void intel_idct_mmx_init( idct_proc_entry entry[8][8]);
void intel_idct_sse2_init( idct_proc_entry entry[8][8]);
void chw_idct_mmx_init( idct_proc_entry entry[8][8]);
void chw_idct_sse2_init( idct_proc_entry entry[8][8]);
void aan_idct_c_init( idct_proc_entry entry[8][8]);





#if defined( __cplusplus )
}
#endif



#endif // !defined(__LXIDCT_H__)
