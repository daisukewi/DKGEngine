// LxIDCT_SSE2.cpp: implementation of the LxIDCT_SSE2 class.
//
//////////////////////////////////////////////////////////////////////



#include "LxIDCT.h"
#include "LxIDCT_SSE2.h"
#include "LxIDCT_mmx.h"


/******************************************
idct begin
*******************************************/


#define BITS_INV_ACC 4 // 4 or 5 for IEEE
#define SHIFT_INV_ROW 16 - BITS_INV_ACC
#define SHIFT_INV_COL 1 + BITS_INV_ACC

#define RND_INV_ROW (1024 * (6 - BITS_INV_ACC))	//1 << (SHIFT_INV_ROW-1)
#define RND_INV_COL (16 * (BITS_INV_ACC - 3) )	// 1 << (SHIFT_INV_COL-1)
#define RND_INV_CORR (RND_INV_COL - 1)			// correction -1.0 and round

__declspec (align(16)) static short i_adder_128[8] =
{128,128,128,128,128,128,128,128}; // 


/*   idct sse2  */

__declspec(align(16)) short M128_one_corr[8] = {1,	1,	1,	1,	1,	1,	1,	1};
__declspec(align(16)) short M128_round_inv_row[8] = {RND_INV_ROW, 0, RND_INV_ROW, 0, RND_INV_ROW, 0, RND_INV_ROW, 0};
//Is16vec8 tomorrow = *(Is16vec8*)M128_round_inv_row;

__declspec(align(16)) short M128_round_inv_col[8] = {RND_INV_COL,  RND_INV_COL,  RND_INV_COL,  RND_INV_COL,	RND_INV_COL,  RND_INV_COL,  RND_INV_COL,  RND_INV_COL};
__declspec(align(16)) short M128_round_inv_corr[8]= {RND_INV_CORR, RND_INV_CORR, RND_INV_CORR, RND_INV_CORR, RND_INV_CORR, RND_INV_CORR, RND_INV_CORR, RND_INV_CORR};
//round_frw_row  dword                 RND_FRW_ROW,                RND_FRW_ROW

__declspec(align(16)) short  M128_tg_1_16[8] = {13036,  13036,  13036,  13036,	13036,  13036,  13036,  13036};	//  tg * (2<<16) + 0.5
__declspec(align(16)) short  M128_tg_2_16[8] = {27146,  27146,  27146,  27146,	27146,  27146,  27146,  27146};	//  tg * (2<<16) + 0.5
__declspec(align(16)) short  M128_tg_3_16[8] = {-21746, -21746, -21746, -21746, -21746, -21746, -21746, -21746};	//  tg * (2<<16) + 0.5
__declspec(align(16)) short  M128_cos_4_16[8] = {-19195, -19195, -19195, -19195,-19195, -19195, -19195, -19195};//  cos * (2<<16) + 0.5
//ocos_4_16      sword   23170,  23170,  23170,  23170   ; cos * (2<<15) + 0.5


//-----------------------------------------------------------------------------

// Table for rows 0,4 - constants are multiplied on cos_4_16


//movq ->	w13 w12 w09 w08 w05 w04 w01 w00
//			w15 w14 w11 w10 w07 w06 w03 w02
//			w29 w28 w25 w24 w21 w20 w17 w16
//			w31 w30 w27 w26 w23 w22 w19 w18

__declspec(align(16)) short M128_tab_i_04[] = {16384,	21407,	16384,	8867,	//movq ->	w05 w04 w01 w00
16384,	-8867,  16384, -21407,		//			w13 w12 w09 w08
16384,	8867,	-16384,	-21407,		//			w07 w06 w03 w02
-16384,	21407,  16384,  -8867,		//			w15 w14 w11 w10
22725,	19266,  19266,  -4520,		//			w21 w20 w17 w16
12873,	-22725,	4520,	-12873,		//			w29 w28 w25 w24
12873,	4520,	-22725, -12873,		//			w23 w22 w19 w18
4520,	19266,  19266,	-22725};	//			w31 w30 w27 w26

// Table for rows 1,7 - constants are multiplied on cos_1_16

__declspec(align(16)) short M128_tab_i_17[] = {22725,  29692,  22725,  12299,	//movq ->	w05 w04 w01 w00
22725,	-12299, 22725,	-29692,		//			w13 w12 w09 w08
22725,  12299,	-22725, -29692,		//			w07 w06 w03 w02
-22725,	29692,  22725,	-12299,		//			w15 w14 w11 w10
31521,  26722,  26722,  -6270,		//			w21 w20 w17 w16
17855,	-31521, 6270,	-17855,		//			w29 w28 w25 w24
17855,  6270,	-31521, -17855,		//			w23 w22 w19 w18
6270,	26722,  26722,	-31521};	//			w31 w30 w27 w26

// Table for rows 2,6 - constants are multiplied on cos_2_16

__declspec(align(16)) short M128_tab_i_26[] = {21407,  27969,  21407,  11585,	//movq ->	w05 w04 w01 w00
21407,	-11585, 21407,	-27969,		//			w13 w12 w09 w08
21407,  11585,	-21407, -27969,		//			w07 w06 w03 w02
-21407, 27969,  21407,	-11585,		//			w15 w14 w11 w10
29692,  25172,  25172,  -5906,		//			w21 w20 w17 w16
16819,	-29692, 5906,	-16819,		//			w29 w28 w25 w24
16819,  5906,	-29692, -16819,		//			w23 w22 w19 w18
5906,	25172,  25172,	-29692};	//			w31 w30 w27 w26

// Table for rows 3,5 - constants are multiplied on cos_3_16

__declspec(align(16)) short M128_tab_i_35[] = {19266,  25172,  19266,  10426,	//movq ->	w05 w04 w01 w00
19266,	-10426, 19266,	-25172,		//			w13 w12 w09 w08
19266,  10426,	-19266, -25172,		//			w07 w06 w03 w02
-19266, 25172,  19266,	-10426,		//			w15 w14 w11 w10
26722,  22654,  22654,  -5315,		//			w21 w20 w17 w16
15137,	-26722, 5315,	-15137,		//			w29 w28 w25 w24
15137,  5315,	-26722, -15137,		//			w23 w22 w19 w18
5315,	22654,  22654,	-26722};	//			w31 w30 w27 w26


//-----------------------------------------------------------------------------


//xmm7 = round_inv_row

#define DCT_8_INV_ROW_SSE2	__asm{					\
	__asm	pshuflw		xmm0, xmm0, 0xD8					\
	__asm	pshufhw		xmm0, xmm0, 0xD8															\
	__asm	pshufd		xmm3, xmm0, 0x55															\
	__asm	pshufd		xmm1, xmm0, 0															    \
	__asm	pshufd		xmm2, xmm0, 0xAA																\
	__asm	pshufd		xmm0, xmm0, 0xFF																\
	__asm	pmaddwd		xmm1, [esi]																		\
	__asm	pmaddwd		xmm2, [esi+16]																	\
	__asm	pmaddwd		xmm3, [esi+32]																	\
	__asm	pmaddwd		xmm0, [esi+48]																	\
	__asm	paddd		xmm0, xmm3																		\
	__asm	pshuflw		xmm4, xmm4, 0xD8																\
	__asm	pshufhw		xmm4, xmm4, 0xD8																\
	__asm	movdqa		xmm7, M128_round_inv_row \
	__asm	paddd		xmm1, xmm7														\
	__asm	pshufd		xmm6, xmm4, 0xAA																\
	__asm	pshufd		xmm5, xmm4, 0																	\
	__asm	pmaddwd		xmm5, [ecx]																		\
	__asm	paddd		xmm5, xmm7														                \
	__asm	pmaddwd		xmm6, [ecx+16]																	\
	__asm	pshufd		xmm7, xmm4, 0x55																\
	__asm	pmaddwd		xmm7, [ecx+32]																	\
	__asm	pshufd		xmm4, xmm4, 0xFF																\
	__asm	pmaddwd		xmm4, [ecx+48]																	\
	__asm	paddd		xmm1, xmm2																		\
	__asm	movdqa		xmm2, xmm1																		\
	__asm	psubd		xmm2, xmm0																		\
	__asm	psrad		xmm2, 12																		\
	__asm	pshufd		xmm2, xmm2, 0x1B																\
	__asm	paddd		xmm0, xmm1																		\
	__asm	psrad		xmm0, 12																		\
	__asm	paddd		xmm5, xmm6																		\
	__asm	packssdw	xmm0, xmm2																		\
	__asm	paddd		xmm4, xmm7																		\
	__asm	movdqa		xmm6, xmm5																		\
	__asm	psubd		xmm6, xmm4																		\
	__asm	psrad		xmm6, 12																		\
	__asm	paddd		xmm4, xmm5																		\
	__asm	psrad		xmm4, 12																		\
	__asm	pshufd		xmm6, xmm6, 0x1B																\
	__asm	packssdw	xmm4, xmm6																		\
}


#define DCT_8_INV_COL_8_SSE2	__asm{									    \
	__asm	movdqa		xmm6, xmm4											\
	__asm	movdqa		xmm2, xmm0											\
	__asm	movdqa		xmm3, XMMWORD PTR [edx+3*16]						\
	__asm	movdqa		xmm1, XMMWORD PTR M128_tg_3_16						\
	__asm	pmulhw		xmm0, xmm1											\
	__asm	movdqa		xmm5, XMMWORD PTR M128_tg_1_16						\
	__asm	pmulhw		xmm1, xmm3											\
	__asm	paddsw		xmm1, xmm3											\
	__asm	pmulhw		xmm4, xmm5											\
	__asm	movdqa		xmm7, XMMWORD PTR [edx+6*16]						\
	__asm	pmulhw		xmm5, [edx+1*16]									\
	__asm	psubsw		xmm5, xmm6											\
	__asm	movdqa		xmm6, xmm5											\
	__asm	paddsw		xmm4, [edx+1*16]									\
	__asm	paddsw		xmm0, xmm2											\
	__asm	paddsw		xmm0, xmm3											\
	__asm	psubsw		xmm2, xmm1											\
	__asm	movdqa		xmm1, xmm0											\
	__asm	movdqa		xmm3, XMMWORD PTR M128_tg_2_16						\
	__asm	pmulhw		xmm7, xmm3											\
	__asm	pmulhw		xmm3, [edx+2*16]									\
	__asm	paddsw		xmm0, xmm4											\
	__asm	psubsw		xmm4, xmm1											\
	__asm	paddsw		xmm0, XMMWORD PTR M128_one_corr						\
	__asm	movdqa		[edx+7*16],  xmm0									\
	__asm	psubsw		xmm5, xmm2											\
	__asm	paddsw		xmm5, XMMWORD PTR M128_one_corr						\
	__asm	paddsw		xmm6, xmm2											\
	__asm	movdqa		[edx+3*16],  xmm6									\
	__asm	movdqa		xmm1, xmm4											\
	__asm	movdqa		xmm0, XMMWORD PTR M128_cos_4_16						\
	__asm	movdqa		xmm2, xmm0						\
	__asm	paddsw		xmm4, xmm5											\
	__asm	psubsw		xmm1, xmm5											\
	__asm	paddsw		xmm7, [edx+2*16]									\
	__asm	psubsw		xmm3, [edx+6*16]									\
	__asm	movdqa		xmm6, [edx]											\
	__asm	pmulhw		xmm0, xmm1											\
	__asm	movdqa		xmm5, [edx+4*16]									\
	__asm	paddsw		xmm5, xmm6											\
	__asm	psubsw		xmm6, [edx+4*16]									\
	__asm	pmulhw		xmm2, xmm4											\
	__asm	paddsw		xmm4, xmm2											\
	__asm	movdqa		xmm2, xmm5											\
	__asm	psubsw		xmm2, xmm7											\
	__asm	por			xmm4, XMMWORD PTR M128_one_corr							\
	__asm	paddsw		xmm0, xmm1											\
	__asm	por			xmm0, XMMWORD PTR M128_one_corr							\
	__asm	paddsw		xmm5, xmm7											\
	__asm	paddsw		xmm5, XMMWORD PTR M128_round_inv_col				\
	__asm	movdqa		xmm1, xmm6											\
	__asm	movdqa		xmm7, [edx+7*16]									\
	__asm	paddsw		xmm7, xmm5											\
	__asm	psraw		xmm7, SHIFT_INV_COL									\
	__asm	movdqa		[edx], xmm7											\
	__asm	paddsw		xmm6, xmm3											\
	__asm	paddsw		xmm6, XMMWORD PTR M128_round_inv_col				\
	__asm	psubsw		xmm1, xmm3											\
	__asm	paddsw		xmm1, XMMWORD PTR M128_round_inv_corr				\
	__asm	movdqa		xmm7, xmm1											\
	__asm	movdqa		xmm3, xmm6											\
	__asm	paddsw		xmm6, xmm4											\
	__asm	paddsw		xmm2, XMMWORD PTR M128_round_inv_corr				\
	__asm	psraw		xmm6, SHIFT_INV_COL									\
	__asm	movdqa		[edx+1*16], xmm6									\
	__asm	paddsw		xmm1, xmm0											\
	__asm	psraw		xmm1, SHIFT_INV_COL									\
	__asm	movdqa		[edx+2*16],  xmm1 \
	__asm	movdqa		xmm1, [edx+3*16] 									\
	__asm	movdqa		xmm6, xmm1           							\
	__asm	psubsw		xmm7, xmm0											\
	__asm	psraw		xmm7, SHIFT_INV_COL									\
	__asm	movdqa		[edx+5*16],  xmm7									\
	__asm	psubsw		xmm5, [edx+7*16]									\
	__asm	psraw		xmm5, SHIFT_INV_COL									\
	__asm	movdqa		[edx+7*16], xmm5									\
	__asm	psubsw		xmm3, xmm4											\
	__asm	paddsw		xmm6, xmm2											\
	__asm	psubsw		xmm2, xmm1									\
	__asm	psraw		xmm6, SHIFT_INV_COL									\
	__asm	movdqa		[edx+3*16],  xmm6									\
	__asm	psraw		xmm2, SHIFT_INV_COL									\
	__asm	movdqa		[edx+4*16],  xmm2									\
	__asm	psraw		xmm3, SHIFT_INV_COL									\
	__asm	movdqa		[edx+6*16],  xmm3									\
	}




//assumes src and destination are aligned on a 16-byte boundary																					
void idct_sse2(short* blk,LxIdctInf* pos)
{

	__asm	mov			eax, [blk]
		__asm	movdqa		xmm0, XMMWORD PTR[eax]	//row 1
		__asm	movdqa		xmm4, XMMWORD PTR[eax+16*2] //row 3																
		__asm	mov			edx, [blk]
		//.................................................................//
		__asm	lea			esi, [M128_tab_i_04]
		__asm	lea			ecx, [M128_tab_i_26]
		DCT_8_INV_ROW_SSE2;	//Row 1, tab_i_04 and Row 3, tab_i_26
	__asm	movdqa		XMMWORD PTR[edx],		xmm0				
		__asm	movdqa		XMMWORD PTR[edx+16*2],	xmm4
		//.................................................................//
		__asm	movdqa		xmm0, XMMWORD PTR[eax+16*4]	//row 5
		//__asm	lea			esi, M128_tab_i_04
		__asm	movdqa		xmm4, XMMWORD PTR[eax+16*6] //row 7																
		//__asm	lea			ecx, M128_tab_i_26
		DCT_8_INV_ROW_SSE2;	//Row 5, tab_i_04 and Row 7, tab_i_26
	__asm	movdqa		XMMWORD PTR[edx+16*4],	xmm0				
		__asm	movdqa		XMMWORD PTR[edx+16*6],	xmm4
		//.................................................................//
		__asm	movdqa		xmm0, XMMWORD PTR[eax+16*3]	//row 4
		__asm	lea			esi, M128_tab_i_35
		__asm	movdqa		xmm4, XMMWORD PTR[eax+16*1] //row 2																
		__asm	lea			ecx, M128_tab_i_17
		DCT_8_INV_ROW_SSE2;	//Row 4, tab_i_35 and Row 2, tab_i_17
	__asm	movdqa		XMMWORD PTR[edx+16*3],	xmm0				
		__asm	movdqa		xmm0, XMMWORD PTR[eax+16*5]	//row 6
		__asm	movdqa		XMMWORD PTR[edx+16*1],	xmm4
		//.................................................................//
		//__asm	lea			esi, M128_tab_i_35
		__asm	movdqa		xmm4, XMMWORD PTR[eax+16*7] //row 8																
		//__asm	lea			ecx, M128_tab_i_17
		DCT_8_INV_ROW_SSE2;	//Row 6, tab_i_35 and Row 8, tab_i_17
	//__asm	movdqa		XMMWORD PTR[edx+80],		xmm0				
	//__asm	movdqa		xmm0, XMMWORD PTR [edx+80]	/* 0		/* x5 */
	//__asm	movdqa		XMMWORD PTR[edx+16*7],	xmm4
	//__asm	movdqa		xmm4, XMMWORD PTR [edx+7*16]/* 4		; x7 */	
	
	DCT_8_INV_COL_8_SSE2
		//	__asm	xmms
		//		return(EXIT_SUCCESS);
		
}


void adder_128_sse2(short *blk,unsigned char* dst,int pit)
{
	__asm
	{
		mov       ecx,[blk]
		mov       eax,[pit]
		mov       edi,[dst]
		movdqa    xmm0,[i_adder_128]
		movdqa    xmm1,[ecx]
		movdqa    xmm2,[ecx+16]
		paddsw    xmm1,xmm0
		paddsw    xmm2,xmm0
		packuswb  xmm1,xmm1
		packuswb  xmm2,xmm2
		movq      qword ptr[edi],xmm1
		movq      qword ptr[edi+eax],xmm2
		add       edi,eax
		add       edi,eax
		movdqa    xmm1,[ecx+32]
		movdqa    xmm3,[ecx+48]
		paddsw    xmm1,xmm0
		paddsw    xmm3,xmm0
		packuswb  xmm1,xmm1
		packuswb  xmm3,xmm3
		movq      qword ptr[edi],xmm1
		movq      qword ptr[edi+eax],xmm3
		add       edi,eax
		add       edi,eax
		movdqa    xmm1,[ecx+64]
		movdqa    xmm2,[ecx+80]
		paddsw    xmm1,xmm0
		paddsw    xmm2,xmm0
		packuswb  xmm1,xmm1
		packuswb  xmm2,xmm2
		movq      qword ptr[edi],xmm1
		movq      qword ptr[edi+eax],xmm2
		add       edi,eax
		add       edi,eax
		movdqa    xmm1,[ecx+96]
		movdqa    xmm3,[ecx+112]
		paddsw    xmm1,xmm0
		paddsw    xmm3,xmm0
		packuswb  xmm1,xmm1
		packuswb  xmm3,xmm3
		movq      qword ptr[edi],xmm1
		movq      qword ptr[edi+eax],xmm3
	}
}




/* 
*  idctmmx32.cpp 
*
*	Copyright (C) Alberto Vigata - January 2000 - ultraflask@yahoo.com
*
*  This file is part of FlasKMPEG, a free MPEG to MPEG/AVI converter
*	
*  FlasKMPEG is free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2, or (at your option)
*  any later version.
*   
*  FlasKMPEG is distributed in the hope that it will be useful,
*  but WITHOUTPTR ANY WARRANTY; withOUTPTR even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*   
*  You should have received a copy of the GNU General Public License
*  along with GNU Make; see the file COPYING.  If not, write to
*  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA. 
*
*/


// MMX32 iDCT algorithm  (IEEE-1180 compliant) :: idct_mmx32()
//
// MPEG2AVI
// --------
//  v0.16B33 initial release
//
// This was one of the harder pieces of work to code.
// Intel's app-note focuses on the numerical issues of the algorithm, but
// assumes the programmer is familiar with IDCT mathematics, leaving the
// form of the complete function up to the programmer's imagination.
//
//  ALGORITHM OVERVIEW
//  ------------------
// I played around with the code for quite a few hours.  I came up
// with *A* working IDCT algorithm, however I'm not sure whether my rOUTPTRine
// is "the correct one."  But rest assured, my code passes all six IEEE 
// accuracy tests with plenty of margin.
//
//   My IDCT algorithm consists of 4 steps:
//
//   1) IDCT-row transformation (using the IDCT-row function) on all 8 rows
//      This yields an intermediate 8x8 matrix.
//
//   2) intermediate matrix transpose (mandatory)
//
//   3) IDCT-row transformation (2nd time) on all 8 rows of the intermediate
//      matrix.  The OUTPTRput is the final-result, in transposed form.
//
//   4) post-transformation matrix transpose 
//      (not necessary if the INPPTRut-data is already transposed, this could
//       be done during the MPEG "zig-zag" scan, but since my algorithm
//       requires at least one transpose operation, why not re-use the
//       transpose-code.)
//
//   Although the (1st) and (3rd) steps use the SAME row-transform operation,
//   the (3rd) step uses different shift&round constants (explained later.)
//
//   Also note that the intermediate transpose (2) would not be neccessary,
//   if the subsequent operation were a iDCT-column transformation.  Since
//   we only have the iDCT-row transform, we transpose the intermediate
//   matrix and use the iDCT-row transform a 2nd time.
//
//   I had to change some constants/variables for my method to work :
//
//      As given by Intel, the #defines for SHIFT_INV_COL32 and RND_INV_COL32 are
//      wrong.  Not surprising since I'm not using a true column-transform 
//      operation, but the row-transform operation (as mentioned earlier.)
//      round_inv_col_ptr[], which is given as "4 short" values, should have the
//      same dimensions as round_inv_row_ptr[].  The corrected variables are 
//      shown.
//
//      Intel's code defines a different TABLE_PTR for each each row operation.
//      The TABLE_PTRs given are 0/4, 1/7, 2/6, and 5/3.  My code only uses row#0.
//      Using the other rows messes up the overall transform.
//
//   IMPLEMENTATION DETAILs
//   ----------------------
// 
//   I divided the algorithm's work into two subrOUTPTRines,
//    1) idct_mmx32_rows() - transforms 8 rows, then transpose
//    2) idct_mmx32_cols() - transforms 8 rows, then transpose
//       yields final result ("drop-in" direct replacement for INT32 IDCT)
//
//   The 2nd function is a clone of the 1st, with changes made only to the
//   shift&rounding instructions.
//
//      In the 1st function (rows), the shift & round instructions use 
//       SHIFT_INV_ROW32 & round_inv_row_ptr[] (renamed to r_inv_row32[])
//
//      In the 2nd function (cols)-> r_inv_col32[], and
//       SHIFT_INV_COL32 & round_inv_col_ptr[] (renamed to r_inv_col32[])
//
//   Each function contains an integrated transpose-operator, which comes
//   AFTER the primary transformation operation.  In the future, I'll optimize
//   the code to do more of the transpose-work "in-place".  Right now, I've
//   left the code as two subrOUTPTRines and a main calling function, so other
//   people can read the code more easily.
//
//   liaor@umcc.ais.org  http://members.tripod.com/~liaor
//  


//;=============================================================================
//;
//;  AP-922   http://developer.intel.com/vtune/cbts/strmsimd
//; These examples contain code fragments for first stage iDCT 8x8
//; (for rows) and first stage DCT 8x8 (for columns)
//;
//;=============================================================================
/*
mword typedef qword
qword ptr equ mword ptr */

#define BITS_INV_ACC32	4	//; 4 or 5 for IEEE
// 5 yields higher accuracy, but lessens dynamic range on the INPPTRut matrix
#define SHIFT_INV_ROW32	(16 - BITS_INV_ACC32)
#define SHIFT_INV_COL32	(1 + BITS_INV_ACC32 +14 )  // changed from Intel's val)
//#define SHIFT_INV_COL32	(1 + BITS_INV_ACC32 )

#define RND_INV_ROW32		(1 << (SHIFT_INV_ROW32-1))
#define RND_INV_COL32		(1 << (SHIFT_INV_COL32-1)) 
#define RND_INV_CORR32	(RND_INV_COL32 - 1)		//; correction -1.0 and round
//#define RND_INV_ROW32		(1024 * (6 - BITS_INV_ACC32)) //; 1 << (SHIFT_INV_ROW32-1)
//#define RND_INV_COL32		(16 * (BITS_INV_ACC32 - 3)) //; 1 << (SHIFT_INV_COL32-1)


//.data
//Align 16

__declspec (align(16)) const static long r_inv_row32[4] =
{ RND_INV_ROW32, RND_INV_ROW32,RND_INV_ROW32, RND_INV_ROW32};

__declspec (align(16)) const static long r_inv_col32[4] =
{RND_INV_COL32, RND_INV_COL32,RND_INV_COL32, RND_INV_COL32};

__declspec (align(16)) const static long r_inv_corr32[4] =
{RND_INV_CORR32, RND_INV_CORR32 ,RND_INV_CORR32, RND_INV_CORR32};

//const static short r_inv_col32[4] = 
//	{RND_INV_COL32, RND_INV_COL32, RND_INV_COL32, RND_INV_COL32};
//const static short r_inv_corr32[4] =
//	{RND_INV_CORR32, RND_INV_CORR32, RND_INV_CORR32, RND_INV_CORR32};

/* constants for the forward DCT

  //#define BITS_FRW_ACC	3 //; 2 or 3 for accuracy
  //#define SHIFT_FRW_COL	BITS_FRW_ACC
  //#define SHIFT_FRW_ROW	(BITS_FRW_ACC + 17)
  //#define RND_FRW_ROW		(262144 * (BITS_FRW_ACC - 1)) //; 1 << (SHIFT_FRW_ROW-1)
  
	const static __int64 one_corr = 0x0001000100010001;
	const static long r_frw_row[2] = {RND_FRW_ROW, RND_FRW_ROW };
	
	  //const static short tg_1_16[4] = {13036, 13036, 13036, 13036 }; //tg * (2<<16) + 0.5
	  //const static short tg_2_16[4] = {27146, 27146, 27146, 27146 }; //tg * (2<<16) + 0.5
	  //const static short tg_3_16[4] = {-21746, -21746, -21746, -21746 }; //tg * (2<<16) + 0.5
	  //const static short cos_4_16[4] = {-19195, -19195, -19195, -19195 }; //cos * (2<<16) + 0.5
	  //const static short ocos_4_16[4] = {23170, 23170, 23170, 23170 }; //cos * (2<<15) + 0.5
	  
		//concatenated TABLE_PTR, for forward DCT transformation
		const static short tg_all_16[] = {
		13036, 13036, 13036, 13036,		// tg * (2<<16) + 0.5
		27146, 27146, 27146, 27146,		//tg * (2<<16) + 0.5
		-21746, -21746, -21746, -21746,	// tg * (2<<16) + 0.5
		-19195, -19195, -19195, -19195,	//cos * (2<<16) + 0.5
		23170, 23170, 23170, 23170 };	//cos * (2<<15) + 0.5
		
		  #define tg_1_16 (tg_all_16 + 0)
		  #define tg_2_16 (tg_all_16 + 8)
		  #define tg_3_16 (tg_all_16 + 16)
		  #define cos_4_16 (tg_all_16 + 24)
		  #define ocos_4_16 (tg_all_16 + 32)
*/
/*
;=============================================================================
;
; The first stage iDCT 8x8 - inverse DCTs of rows
;
;-----------------------------------------------------------------------------
; The 8-point inverse DCT direct algorithm
;-----------------------------------------------------------------------------
;
; static const short w[32] = {
; FIX(cos_4_16), FIX(cos_2_16), FIX(cos_4_16), FIX(cos_6_16),
; FIX(cos_4_16), FIX(cos_6_16), -FIX(cos_4_16), -FIX(cos_2_16),
; FIX(cos_4_16), -FIX(cos_6_16), -FIX(cos_4_16), FIX(cos_2_16),
; FIX(cos_4_16), -FIX(cos_2_16), FIX(cos_4_16), -FIX(cos_6_16),
; FIX(cos_1_16), FIX(cos_3_16), FIX(cos_5_16), FIX(cos_7_16),
; FIX(cos_3_16), -FIX(cos_7_16), -FIX(cos_1_16), -FIX(cos_5_16),
; FIX(cos_5_16), -FIX(cos_1_16), FIX(cos_7_16), FIX(cos_3_16),
; FIX(cos_7_16), -FIX(cos_5_16), FIX(cos_3_16), -FIX(cos_1_16) };
;
; #define DCT_8_INV_ROW(x, y)

  ;{
  ; int a0, a1, a2, a3, b0, b1, b2, b3;
  ;
  ; a0 =x[0]*w[0]+x[2]*w[1]+x[4]*w[2]+x[6]*w[3];
  ; a1 =x[0]*w[4]+x[2]*w[5]+x[4]*w[6]+x[6]*w[7];
  ; a2 = x[0] * w[ 8] + x[2] * w[ 9] + x[4] * w[10] + x[6] * w[11];
  ; a3 = x[0] * w[12] + x[2] * w[13] + x[4] * w[14] + x[6] * w[15];
  ; b0 = x[1] * w[16] + x[3] * w[17] + x[5] * w[18] + x[7] * w[19];
  ; b1 = x[1] * w[20] + x[3] * w[21] + x[5] * w[22] + x[7] * w[23];
  ; b2 = x[1] * w[24] + x[3] * w[25] + x[5] * w[26] + x[7] * w[27];
  ; b3 = x[1] * w[28] + x[3] * w[29] + x[5] * w[30] + x[7] * w[31];
  ;
  ; y[0] = SHIFT_ROUND ( a0 + b0 );
  ; y[1] = SHIFT_ROUND ( a1 + b1 );
  ; y[2] = SHIFT_ROUND ( a2 + b2 );
  ; y[3] = SHIFT_ROUND ( a3 + b3 );
  ; y[4] = SHIFT_ROUND ( a3 - b3 );
  ; y[5] = SHIFT_ROUND ( a2 - b2 );
  ; y[6] = SHIFT_ROUND ( a1 - b1 );
  ; y[7] = SHIFT_ROUND ( a0 - b0 );
  ;}
  ;
  ;-----------------------------------------------------------------------------
  ;
  ; In this implementation the OUTPTRputs of the iDCT-1D are multiplied
  ; for rows 0,4 - by cos_4_16,
  ; for rows 1,7 - by cos_1_16,
  ; for rows 2,6 - by cos_2_16,
  ; for rows 3,5 - by cos_3_16
  ; and are shifted to the left for better accuracy
  ;
  ; For the constants used,
  ; FIX(float_const) = (short) (float_const * (1<<15) + 0.5)
  ;
  ;=============================================================================
  ;=============================================================================
  IF _MMX ; MMX code
  ;=============================================================================
  /*
  
	//; TABLE_PTR for rows 0,4 - constants are multiplied by cos_4_16
	const short tab_i_04[] = {
	16384, 16384, 16384, -16384,	// ; movq-> w06 w04 w02 w00
	21407, 8867, 8867, -21407,		// w07 w05 w03 w01
	16384, -16384, 16384, 16384,	//; w14 w12 w10 w08
	-8867, 21407, -21407, -8867,	//; w15 w13 w11 w09
	22725, 12873, 19266, -22725,	//; w22 w20 w18 w16
	19266, 4520, -4520, -12873,		//; w23 w21 w19 w17
	12873, 4520, 4520, 19266,		//; w30 w28 w26 w24
	-22725, 19266, -12873, -22725 };//w31 w29 w27 w25
	
	  //; TABLE_PTR for rows 1,7 - constants are multiplied by cos_1_16
	  const short tab_i_17[] = {
	  22725, 22725, 22725, -22725,	// ; movq-> w06 w04 w02 w00
	  29692, 12299, 12299, -29692,	//	; w07 w05 w03 w01
	  22725, -22725, 22725, 22725,	//; w14 w12 w10 w08
	  -12299, 29692, -29692, -12299,	//; w15 w13 w11 w09
	  31521, 17855, 26722, -31521,	//; w22 w20 w18 w16
	  26722, 6270, -6270, -17855,		//; w23 w21 w19 w17
	  17855, 6270, 6270, 26722,		//; w30 w28 w26 w24
	  -31521, 26722, -17855, -31521};	// w31 w29 w27 w25
	  
		//; TABLE_PTR for rows 2,6 - constants are multiplied by cos_2_16
		const short tab_i_26[] = {
		21407, 21407, 21407, -21407,	// ; movq-> w06 w04 w02 w00
		27969, 11585, 11585, -27969,	// ; w07 w05 w03 w01
		21407, -21407, 21407, 21407,	// ; w14 w12 w10 w08
		-11585, 27969, -27969, -11585,	//  ;w15 w13 w11 w09
		29692, 16819, 25172, -29692, 	// ;w22 w20 w18 w16
		25172, 5906, -5906, -16819, 	// ;w23 w21 w19 w17
		16819, 5906, 5906, 25172, 		// ;w30 w28 w26 w24
		-29692, 25172, -16819, -29692};	//  ;w31 w29 w27 w25
		
		  
			//; TABLE_PTR for rows 3,5 - constants are multiplied by cos_3_16
			const short tab_i_35[] = {
			19266, 19266, 19266, -19266,	//; movq-> w06 w04 w02 w00
			25172, 10426, 10426, -25172,	//; w07 w05 w03 w01
			19266, -19266, 19266, 19266,	//; w14 w12 w10 w08
			-10426, 25172, -25172, -10426,	//; w15 w13 w11 w09
			26722, 15137, 22654, -26722,	//; w22 w20 w18 w16
			22654, 5315, -5315, -15137,		//; w23 w21 w19 w17
			15137, 5315, 5315, 22654,		//; w30 w28 w26 w24
			-26722, 22654, -15137, -26722};	//; w31 w29 w27 w25
*/

// CONCATENATED TABLE_PTR, rows 0,1,2,3,4,5,6,7 (in order )
//


#define INPPTR eax		// pointer to (short *blk)
#define OUTPTR ecx		// pointer to OUTPTRput (temporary store space qwTemp[])
#define TABLE_PTR ebx	// pointer to tab_i_01234567[]

#define round_inv_row_ptr edx
#define round_inv_col_ptr edx

#define ROW_STRIDE 16 // for 8x8 matrix transposer

// private variables and functions

//temporary storage space, 8x8 of shorts

//declspec (align(16)) static __int64 qwTemp[32]; 

// the "column" transform actually transforms rows, it is
// identical to the row-transform except for the ROUNDING
// and SHIFTING coefficients.



__declspec (align(16)) static const short tab_i_01234567[] = {
	//row0, this row is required
	16384, 16384, 16384, -16384,	// ;w06 w04 w02 w00
		22725, 12873, 19266, -22725,	//; w22 w20 w18 w16
		
		16384, -16384, 16384, 16384,	//; w14 w12 w10 w08
		12873, 4520, 4520, 19266,		//; w30 w28 w26 w24
		
		21407, 8867, 8867, -21407,		// w07 w05 w03 w01
		19266, 4520, -4520, -12873,		//; w23 w21 w19 w17
		
		-8867, 21407, -21407, -8867,	//; w15 w13 w11 w09
		-22725, 19266, -12873, -22725,  //w31 w29 w27 w25
};


__inline static void idct32_rows( short *blk ); // transform rows
__inline static void idct32_cols( short *blk );  // transform "columns"


__inline
static void 
idct32_rows( short *blk )	// transform all 8 rows of 8x8 iDCT block
{
	// this subrOUTPTRine performs two operations
	// 1) iDCT row transform
	//		for( i = 0; i < 8; ++ i)
	//			DCT_8_INV_ROW_1( blk[i*8], qwTemp[i] );
	//
	// 2) transpose the matrix (which was stored in qwTemp[])
	//        qwTemp[] -> [8x8 matrix transpose] -> blk[]
	
	
	__asm 
	{
		//;------------------------------------------------------
		//DCT_8_INV_ROW_1 MACRO INPPTR:REQ, OUTPTR:REQ, TABLE_PTR:REQ

		push         TABLE_PTR
		
		mov          INPPTR, dword ptr [blk];		;// row 0
		mov          edi, 0x00;	//x = 0
		lea          round_inv_row_ptr, dword ptr [r_inv_row32]
			lea          TABLE_PTR, dword ptr [tab_i_01234567]; // row 0
		movdqa       xmm6,xmmword ptr [round_inv_row_ptr]
			movdqa       xmm7,xmmword ptr [TABLE_PTR]
			
			// for ( x = 0; x < 8; ++x )  // transform one row per iteration
lpa:
		movdqa       xmm0,xmmword ptr [INPPTR]     // X76543210
			movdqa       xmm4,xmmword ptr [INPPTR+16]     // X76543210
			pshufd       xmm0,xmm0,0xd8        //   11011000 76 32 54 10 ;
			pshuflw      xmm0,xmm0,0xd8        //   11011000 76 32 51 40 ;
			pshufhw      xmm0,xmm0,0xd8        //   11011000 73 62 51 40 ;
			pshufd       xmm1,xmm0,0xfa        //   11111010 73 73 62 62;
			pshufd       xmm0,xmm0,0x50        //   01010000 51 51 40 40;
			movdqa       xmm3,xmm1	
			movdqa       xmm2,xmm0
			pmaddwd      xmm0,xmm7                        //   x5*w22+x1*w20 x5*w18+x1*w16 x4*w06+x0*w04 x4*w02+x0*w00  mm1,mm3;
			pshufd       xmm4,xmm4,0xd8        //   11011000 76 32 54 10 ;
			pmaddwd      xmm2,xmmword ptr[TABLE_PTR+16]   //   x5*w30+x1*w28 x5*w26+x1*w24 x4*w14+x0*w12 x4*w10+x0*w08  mm5,mm0;
			pshuflw      xmm4,xmm4,0xd8        //   11011000 76 32 51 40 ;
			pmaddwd      xmm1,xmmword ptr[TABLE_PTR+32]   //   x7*w23+x3*w21 x7*w19+x3*w17 x6*w07+x2*w05 x6*w03+x2*w01  mm7,mm4;
			pshufhw      xmm4,xmm4,0xd8        //   11011000 73 62 51 40 ;
			pmaddwd      xmm3,xmmword ptr[TABLE_PTR+48]   //   x7*w31+x3*w29 x7*w27+x3*w25 x6*w15+x2*w13 x6*w11+x2*w09  mm6,mm2;
			paddd        xmm0,xmm1  // b1 b0 a1 a0;
			paddd        xmm2,xmm3  // b3 b2 a3 a2;
			movdqa       xmm1,xmm0
			punpcklqdq   xmm0,xmm2  // a3210;
			punpckhqdq   xmm1,xmm2  // b3210;
			movdqa       xmm2,xmm0  // dup a;
			pshufd       xmm5,xmm4,0xfa        //   11111010 73 73 62 62;
			paddd        xmm0,xmm1  // a3+b3 a2+b2 a1+b1 a0+b0;     y3 y2 y1 y0;
			pshufd       xmm4,xmm4,0x50        //   01010000 51 51 40 40;
			psubd        xmm2,xmm1  // a3-b3 a2-b2 a1-b1 a0-b0;     y4 y5 y6 y7
			paddd        xmm0,xmm6
			movdqa       xmm1,xmm4
			paddd        xmm2,xmm6
			movdqa       xmm3,xmm5	
			psrad        xmm0,SHIFT_INV_ROW32
			pmaddwd      xmm4,xmm7                        //   x5*w22+x1*w20 x5*w18+x1*w16 x4*w06+x0*w04 x4*w02+x0*w00  mm1,mm3;
			psrad        xmm2,SHIFT_INV_ROW32
			pmaddwd      xmm1,xmmword ptr[TABLE_PTR+16]   //   x5*w30+x1*w28 x5*w26+x1*w24 x4*w14+x0*w12 x4*w10+x0*w08  mm5,mm0;
			pshufd       xmm2,xmm2,0x1b   // 7654;
			pmaddwd      xmm5,xmmword ptr[TABLE_PTR+32]   //   x7*w23+x3*w21 x7*w19+x3*w17 x6*w07+x2*w05 x6*w03+x2*w01  mm7,mm4;
			packssdw     xmm0,xmm2        // 765433210;
			pmaddwd      xmm3,xmmword ptr[TABLE_PTR+48]   //   x7*w31+x3*w29 x7*w27+x3*w25 x6*w15+x2*w13 x6*w11+x2*w09  mm6,mm2;
			movdqa       [INPPTR],xmm0    // output;
			paddd        xmm4,xmm5  // b1 b0 a1 a0;
			paddd        xmm1,xmm3  // b3 b2 a3 a2;
			movdqa       xmm5,xmm4
			punpcklqdq   xmm4,xmm1  // a3210;
			punpckhqdq   xmm5,xmm1  // b3210;
			movdqa       xmm1,xmm4  // dup a;
			paddd        xmm4,xmm5  // a3+b3 a2+b2 a1+b1 a0+b0;     y3 y2 y1 y0;
			psubd        xmm1,xmm5  // a3-b3 a2-b2 a1-b1 a0-b0;     y4 y5 y6 y7;
			paddd        xmm4,xmm6
			paddd        xmm1,xmm6
			psrad        xmm4,SHIFT_INV_ROW32
			psrad        xmm1,SHIFT_INV_ROW32
			add          edi, 0x02
			pshufd       xmm1,xmm1,0x1b   // 7654;
			add          INPPTR, 32					// increment OUTPTRPUT pointer -> row 1
			packssdw     xmm4,xmm1        // 765433210;
			cmp          edi, 0x08;
		movdqa       [INPPTR - 16],xmm4    // output;
			jl           lpa;		// end for ( x = 0; x < 8; ++x )
		
		// transpose the matrix;
		mov			eax, [blk]
			movdqa      xmm0,[eax]     // 0  76543210 ;
			movdqa      xmm1,[eax+16]  // 1  76543210 ;
			movdqa      xmm7,xmm0      // 
			punpcklwd   xmm0,xmm1      // 13 03 12 02 11 01 10 00;
			punpckhwd   xmm7,xmm1      // 17 07 16 06 15 05 14 04;
			movdqa      xmm2,[eax+32]  // 2  76543210 ;
			movdqa      xmm3,[eax+48]  // 3  76543210 ;
			movdqa      xmm1,xmm2
			punpcklwd   xmm2,xmm3      // 33 23 32 22 31 21 30 20
			punpckhwd   xmm1,xmm3      // 37 27 36 26 35 25 34 24
			movdqa      xmm4,[eax+64]  // 4  76543210 ;
			movdqa      xmm5,[eax+80]  // 5  76543210 ;
			movdqa      xmm3,xmm0
			punpckldq   xmm0,xmm2      // 31 21 11 01 30 20 10 00
			punpckhdq   xmm3,xmm2      // 33 23 13 03 32 22 12 02
			movdqa      xmm6,[eax+96]  // 6  76543210 ;
			movdqa      xmm2,xmm7
			punpckldq   xmm7,xmm1      // 35 25 15 05 24 24 14 04
			punpckhdq   xmm2,xmm1      // 37 27 17 07 36 26 16 06
			movdqa      xmm1,xmm4
			movdqa      [eax+80],xmm2     // save xmm2;
			punpcklwd   xmm4,xmm5      // 53 43 52 42 51 41 50 40
			punpckhwd   xmm1,xmm5      // 57 47 56 46 55 45 54 44
			movdqa      xmm5,xmm6
			punpcklwd   xmm6,[eax+112] // 73 63 72 62 71 61 70 60
			punpckhwd   xmm5,[eax+112] // 77 67 76 66 75 65 74 64
			movdqa      xmm2,xmm4
			punpckldq   xmm4,xmm6      // 71 61 51 41 70 60 50 40
			punpckhdq   xmm2,xmm6      // 73 63 53 43 72 62 52 42
			movdqa      xmm6,xmm1
			punpckldq   xmm1,xmm5      // 75 65 55 45 74 64 54 44  // ????
			punpckhdq   xmm6,xmm5      // 77 67 57 47 76 66 56 46
			movdqa      xmm5,xmm0
			punpcklqdq  xmm0,xmm4      // 70 60 50 40 30 20 10 00
			punpckhqdq  xmm5,xmm4      // 71 61 51 41 31 21 11 01
			movdqa      [eax],xmm0     // output row 0;
			movdqa      xmm4,xmm3
			movdqa      [eax+16],xmm5  // ouput row 1;
			punpcklqdq  xmm3,xmm2      // 72 62 52 42 32 22 12 02
			punpckhqdq  xmm4,xmm2      // 73 63 53 43 33 23 13 03
			movdqa      [eax+32],xmm3  // ouput row 2;
			movdqa      xmm0,[eax+80]  // restore 37 27 17 07 36 26 16 06
			movdqa      [eax+48],xmm4  // ouput row 3;
			movdqa      xmm5,xmm7
			punpcklqdq  xmm7,xmm1     // 74 64 54 44 34 24 14 04;
			punpckhqdq  xmm5,xmm1     // 75 65 55 45 35 25 15 05
			movdqa      [eax+64],xmm7   // row 4;
			movdqa      xmm3,xmm0
			movdqa      [eax+80],xmm5   // row 5;
			punpcklqdq  xmm0,xmm6     // 76 66 56 46 36 26 16 06
			punpckhqdq  xmm3,xmm6     // 77 67 57 46 37 27 17 07
			movdqa      [eax+96],xmm0   // row 6;
			movdqa      [eax+112],xmm3   // row 7;
			pop         TABLE_PTR
	}
}

__inline
static void 
idct32_cols( short *blk)	// transform all 8 cols of 8x8 iDCT block
{
	__asm 
	{
		//;------------------------------------------------------
		//DCT_8_INV_ROW_1 MACRO INPPTR:REQ, OUTPTR:REQ, TABLE_PTR:REQ
		push         TABLE_PTR

		mov          INPPTR, dword ptr [blk];		;// row 0
		mov          edi, 0x00;	//x = 0
		lea          round_inv_col_ptr, dword ptr [r_inv_col32]
		lea          TABLE_PTR, dword ptr [tab_i_01234567]; // row 0
		movdqa       xmm6,xmmword ptr [round_inv_col_ptr]
		movdqa       xmm7,xmmword ptr [TABLE_PTR]
			
			// for ( x = 0; x < 8; ++x )  // transform one row per iteration
lpa:
		movdqa       xmm0,xmmword ptr [INPPTR]     // X76543210
		movdqa       xmm4,xmmword ptr [INPPTR+16]     // X76543210
		pshufd       xmm0,xmm0,0xd8        //   11011000 76 32 54 10 ;
		pshuflw      xmm0,xmm0,0xd8        //   11011000 76 32 51 40 ;
		pshufhw      xmm0,xmm0,0xd8        //   11011000 73 62 51 40 ;
		pshufd       xmm1,xmm0,0xfa        //   11111010 73 73 62 62;
		pshufd       xmm0,xmm0,0x50        //   01010000 51 51 40 40;
		movdqa       xmm3,xmm1	
		movdqa       xmm2,xmm0
		pmaddwd      xmm0,xmm7                        //   x5*w22+x1*w20 x5*w18+x1*w16 x4*w06+x0*w04 x4*w02+x0*w00  mm1,mm3;
		pshufd       xmm4,xmm4,0xd8        //   11011000 76 32 54 10 ;
		pmaddwd      xmm2,xmmword ptr[TABLE_PTR+16]   //   x5*w30+x1*w28 x5*w26+x1*w24 x4*w14+x0*w12 x4*w10+x0*w08  mm5,mm0;
		pshuflw      xmm4,xmm4,0xd8        //   11011000 76 32 51 40 ;
		pmaddwd      xmm1,xmmword ptr[TABLE_PTR+32]   //   x7*w23+x3*w21 x7*w19+x3*w17 x6*w07+x2*w05 x6*w03+x2*w01  mm7,mm4;
		pshufhw      xmm4,xmm4,0xd8        //   11011000 73 62 51 40 ;
		pmaddwd      xmm3,xmmword ptr[TABLE_PTR+48]   //   x7*w31+x3*w29 x7*w27+x3*w25 x6*w15+x2*w13 x6*w11+x2*w09  mm6,mm2;
		paddd        xmm0,xmm1  // b1 b0 a1 a0;
		paddd        xmm2,xmm3  // b3 b2 a3 a2;
		movdqa       xmm1,xmm0
		punpcklqdq   xmm0,xmm2  // a3210;
		punpckhqdq   xmm1,xmm2  // b3210;
		movdqa       xmm2,xmm0  // dup a;
		pshufd       xmm5,xmm4,0xfa        //   11111010 73 73 62 62;
		paddd        xmm0,xmm1  // a3+b3 a2+b2 a1+b1 a0+b0;     y3 y2 y1 y0;
		pshufd       xmm4,xmm4,0x50        //   01010000 51 51 40 40;
		psubd        xmm2,xmm1  // a3-b3 a2-b2 a1-b1 a0-b0;     y4 y5 y6 y7
		paddd        xmm0,xmm6
		movdqa       xmm1,xmm4
		paddd        xmm2,xmm6
		movdqa       xmm3,xmm5	
		psrad        xmm0,SHIFT_INV_COL32
		pmaddwd      xmm4,xmm7                        //   x5*w22+x1*w20 x5*w18+x1*w16 x4*w06+x0*w04 x4*w02+x0*w00  mm1,mm3;
		psrad        xmm2,SHIFT_INV_COL32
		pmaddwd      xmm1,xmmword ptr[TABLE_PTR+16]   //   x5*w30+x1*w28 x5*w26+x1*w24 x4*w14+x0*w12 x4*w10+x0*w08  mm5,mm0;
		pshufd       xmm2,xmm2,0x1b   // 7654;
		pmaddwd      xmm5,xmmword ptr[TABLE_PTR+32]   //   x7*w23+x3*w21 x7*w19+x3*w17 x6*w07+x2*w05 x6*w03+x2*w01  mm7,mm4;
		packssdw     xmm0,xmm2        // 765433210;
		pmaddwd      xmm3,xmmword ptr[TABLE_PTR+48]   //   x7*w31+x3*w29 x7*w27+x3*w25 x6*w15+x2*w13 x6*w11+x2*w09  mm6,mm2;
		movdqa       [INPPTR],xmm0    // output;
		paddd        xmm4,xmm5  // b1 b0 a1 a0;
		paddd        xmm1,xmm3  // b3 b2 a3 a2;
		movdqa       xmm5,xmm4
		punpcklqdq   xmm4,xmm1  // a3210;
		punpckhqdq   xmm5,xmm1  // b3210;
		movdqa       xmm1,xmm4  // dup a;
		paddd        xmm4,xmm5  // a3+b3 a2+b2 a1+b1 a0+b0;     y3 y2 y1 y0;
		psubd        xmm1,xmm5  // a3-b3 a2-b2 a1-b1 a0-b0;     y4 y5 y6 y7;
		paddd        xmm4,xmm6
		paddd        xmm1,xmm6
		psrad        xmm4,SHIFT_INV_COL32
		psrad        xmm1,SHIFT_INV_COL32
		add          edi, 0x02
		pshufd       xmm1,xmm1,0x1b   // 7654;
		add          INPPTR, 32					// increment OUTPTRPUT pointer -> row 1
		packssdw     xmm4,xmm1        // 765433210;
		cmp          edi, 0x08;
		movdqa       [INPPTR - 16],xmm4    // output;
		jl           lpa;		// end for ( x = 0; x < 8; ++x )
		
		///*
		// transpose the matrix;
		mov			eax, [blk]
		movdqa      xmm0,[eax]     // 0  76543210 ;
		movdqa      xmm1,[eax+16]  // 1  76543210 ;
		movdqa      xmm7,xmm0      // 
		punpcklwd   xmm0,xmm1      // 13 03 12 02 11 01 10 00;
		punpckhwd   xmm7,xmm1      // 17 07 16 06 15 05 14 04;
		movdqa      xmm2,[eax+32]  // 2  76543210 ;
		movdqa      xmm3,[eax+48]  // 3  76543210 ;
		movdqa      xmm1,xmm2
		punpcklwd   xmm2,xmm3      // 33 23 32 22 31 21 30 20
		punpckhwd   xmm1,xmm3      // 37 27 36 26 35 25 34 24
		movdqa      xmm4,[eax+64]  // 4  76543210 ;
		movdqa      xmm5,[eax+80]  // 5  76543210 ;
		movdqa      xmm3,xmm0
		punpckldq   xmm0,xmm2      // 31 21 11 01 30 20 10 00
		punpckhdq   xmm3,xmm2      // 33 23 13 03 32 22 12 02
		movdqa      xmm6,[eax+96]  // 6  76543210 ;
		movdqa      xmm2,xmm7
		punpckldq   xmm7,xmm1      // 35 25 15 05 24 24 14 04
		punpckhdq   xmm2,xmm1      // 37 27 17 07 36 26 16 06
		movdqa      xmm1,xmm4
		movdqa      [eax+80],xmm2     // save xmm2;
		punpcklwd   xmm4,xmm5      // 53 43 52 42 51 41 50 40
		punpckhwd   xmm1,xmm5      // 57 47 56 46 55 45 54 44
		movdqa      xmm5,xmm6
		punpcklwd   xmm6,[eax+112] // 73 63 72 62 71 61 70 60
		punpckhwd   xmm5,[eax+112] // 77 67 76 66 75 65 74 64
		movdqa      xmm2,xmm4
		punpckldq   xmm4,xmm6      // 71 61 51 41 70 60 50 40
		punpckhdq   xmm2,xmm6      // 73 63 53 43 72 62 52 42
		movdqa      xmm6,xmm1
		punpckldq   xmm1,xmm5      // 75 65 55 45 74 64 54 44
		punpckhdq   xmm6,xmm5      // 77 67 57 47 76 66 56 46
		movdqa      xmm5,xmm0
		punpcklqdq  xmm0,xmm4      // 70 60 50 40 30 20 10 00
		punpckhqdq  xmm5,xmm4      // 71 61 51 41 31 21 11 01
		movdqa      [eax],xmm0     // output row 0;
		movdqa      xmm4,xmm3
		movdqa      [eax+16],xmm5  // ouput row 1;
		punpcklqdq  xmm3,xmm2      // 72 62 52 42 32 22 12 02
		punpckhqdq  xmm4,xmm2      // 73 63 53 43 33 23 13 03
		movdqa      [eax+32],xmm3  // ouput row 2;
		movdqa      xmm0,[eax+80]  // restore 37 27 17 07 36 26 16 06
		movdqa      [eax+48],xmm4  // ouput row 3;
		movdqa      xmm5,xmm7
		punpcklqdq  xmm7,xmm1     // 74 64 54 44 34 24 14 04;
		punpckhqdq  xmm5,xmm1     // 75 65 55 45 35 25 15 05
		movdqa      [eax+64],xmm7   // row 4;
		movdqa      xmm3,xmm0
		movdqa      [eax+80],xmm5   // row 5;
		punpcklqdq  xmm0,xmm6     // 76 66 56 46 36 26 16 06
		punpckhqdq  xmm3,xmm6     // 77 67 57 46 37 27 17 07
		movdqa      [eax+96],xmm0   // row 6;
		movdqa      [eax+112],xmm3   // row 7;
		//*/
		pop         TABLE_PTR			
	}
}
//	
// public interface to MMX32 IDCT 8x8 operation
//
void idct32_sse2( s16 *blk , LxIdctInf* pos )
{
	// 1) iDCT row transformation
	idct32_rows( blk); // 1) transform iDCT row, and transpose
	
	// 2) iDCT column transformation
	idct32_cols( blk); // 2) transform iDCT row, and transpose
	
	// all done
}




void idct_sparse_dc_sse2(short* blk)
{
#ifdef __DEBUG_IDCT
	g_qwIdctDc ++;
	g_dwIdctDc = 1000*g_qwIdctDc / (g_qwIdctDc+g_qwIdctAc+g_qwIdct);
#endif
	__asm
	{
		mov          esi,[blk]
		movsx        eax,word ptr[esi]   // blk[0]
		add          eax,4
		sar          eax,3
		movd         xmm0,eax
		punpcklwd    xmm0,xmm0
		punpckldq    xmm0,xmm0
		punpcklqdq   xmm0,xmm0
		movdqa      [esi],xmm0
		movdqa      [esi+16],xmm0
		movdqa      [esi+32],xmm0
		movdqa      [esi+48],xmm0
		movdqa      [esi+64],xmm0
		movdqa      [esi+80],xmm0
		movdqa      [esi+96],xmm0
		movdqa      [esi+112],xmm0
	}
}


__declspec (align(16)) static int g_AcRound0[4] = {
	IDCT_TAB_ROUND0,IDCT_TAB_ROUND0,IDCT_TAB_ROUND0,IDCT_TAB_ROUND0,
};
__declspec (align(16)) static int g_DcRound1[4] = {
	IDCT_TAB_DC_ROUND1,IDCT_TAB_DC_ROUND1,IDCT_TAB_DC_ROUND1,IDCT_TAB_DC_ROUND1,
};

/***********************************************************************
***********************************************************************/
__declspec (align(16)) static short g_AcRound1[8] = {
	IDCT_TAB_MMX_RD1,IDCT_TAB_MMX_RD1,
	IDCT_TAB_MMX_RD1,IDCT_TAB_MMX_RD1,
	IDCT_TAB_MMX_RD1,IDCT_TAB_MMX_RD1,
	IDCT_TAB_MMX_RD1,IDCT_TAB_MMX_RD1,
};


#define LX_AC2(edi,i0,i1) \
__asm		movq         xmm5,mmword ptr [IDCT_TAB_COL+edx+8*i0]  \
__asm		movq         xmm6,mmword ptr [IDCT_TAB_COL+edx+8*i1]  \
__asm		punpcklqdq   xmm5,xmm5              \
__asm		punpcklqdq   xmm6,xmm6              \
__asm		pmulhw       xmm5,xmm0              \
__asm		pmulhw       xmm6,xmm0              \
__asm		paddsw       xmm5,xmm7              \
__asm		paddsw       xmm6,xmm7              \
__asm		psraw        xmm5,IDCT_TAB_MMX_RC1  \
__asm		psraw        xmm6,IDCT_TAB_MMX_RC1  \
__asm		movdqa       [edi+16*i0],xmm5       \
__asm		movdqa       [edi+16*i1],xmm6

void idct_sparse_ac_sse2(short* blk, LxIdctInf* pos)
{
	DWORD const dwRowMask = GET_ROW_MASK(pos->dwColMask);
	DWORD const dwColMask = GET_COL_MASK(pos->dwColMask);

	int hnc = g_RowPos[dwColMask];
	int vnc = g_RowPos[dwRowMask];

	int np = hnc*8 + vnc ;
	if( 0 == np ) {
		idct_sparse_dc_sse2(blk);
		return;
	}
	
	__asm
	{
		movdqa       xmm7,[g_DcRound1]
		mov          edi,[blk]
		mov          edx,[np]
		movdqa       xmm6,[g_AcRound0]
		movzx        eax,WORD PTR[edi+edx*2]
		mov          edx,[vnc]
		movd         xmm5,eax 
		mov          eax,[hnc]
		test         eax,eax
		cmove        ecx,edx
		cmovne       ecx,eax
		shl          ecx,5	

	    test         eax,eax

		punpckldq    xmm5,xmm5 
		punpcklqdq   xmm5,xmm5 
		movdqa       xmm0,[IDCT_TAB+ecx]
		pmaddwd      xmm0,xmm5
		paddd        xmm0,xmm6
		psrad        xmm0,IDCT_TAB_RC0

		je           ac_hdc

		test         edx,edx

		movdqa       xmm2,[IDCT_TAB+ecx+16]
		pmaddwd      xmm2,xmm5
		paddd        xmm2,xmm6
		psrad        xmm2,IDCT_TAB_RC0
    
		je           ac_vdc

		shl          edx,6
		packssdw     xmm0,xmm2
		movdqa       xmm7,[g_AcRound1]
		LX_AC2(edi,0,1)
		LX_AC2(edi,2,3)
		LX_AC2(edi,4,5)
		LX_AC2(edi,6,7)
		jmp          over 

ac_vdc:
		paddd          xmm0,xmm7
		psrad          xmm0,IDCT_TAB_DC_RC1
		paddd          xmm2,xmm7
		psrad          xmm2,IDCT_TAB_DC_RC1
		packssdw       xmm0,xmm2 // 76543210;
		movdqa         [edi],xmm0 
		movdqa         [edi+1*16],xmm0 
		movdqa         [edi+2*16],xmm0 
		movdqa         [edi+3*16],xmm0 
		movdqa         [edi+4*16],xmm0 
		movdqa         [edi+5*16],xmm0 
		movdqa         [edi+6*16],xmm0 
		movdqa         [edi+7*16],xmm0 
		jmp            over 

ac_hdc:
		movdqa         xmm2,[IDCT_TAB+ecx+16]
		pmaddwd        xmm2,xmm5
		paddd          xmm2,xmm6
		psrad          xmm2,IDCT_TAB_RC0

		paddd          xmm0,xmm7
		psrad          xmm0,IDCT_TAB_DC_RC1
		paddd          xmm2,xmm7
		psrad          xmm2,IDCT_TAB_DC_RC1
		packssdw       xmm0,xmm2 // 3210;
		movdqa         xmm1,xmm0
		punpcklwd      xmm0,xmm0   // 33221100
		punpckhwd      xmm1,xmm1   // 77665544
		movdqa         xmm2,xmm0
		movdqa         xmm3,xmm1
		punpckldq      xmm0,xmm0  // 11110000
		punpckhdq      xmm2,xmm2  // 33332222
		punpckldq      xmm1,xmm1  // 55554444
		punpckhdq      xmm3,xmm3  // 77776666
		movdqa         xmm4,xmm0
		movdqa         xmm5,xmm2
		movdqa         xmm6,xmm1
		movdqa         xmm7,xmm3
		punpcklqdq     xmm0,xmm0  // 0
		punpckhqdq     xmm4,xmm4  // 1
		movdqa         [edi],xmm0 
		movdqa         [edi+1*16],xmm4 
		punpcklqdq     xmm2,xmm2  // 2
		punpckhqdq     xmm5,xmm5  // 3
		movdqa         [edi+2*16],xmm2 
		movdqa         [edi+3*16],xmm5 
		punpcklqdq     xmm1,xmm1  // 4
		punpckhqdq     xmm6,xmm6  // 5
		movdqa         [edi+4*16],xmm1 
		movdqa         [edi+5*16],xmm6 
		punpcklqdq     xmm3,xmm3  // 6
		punpckhqdq     xmm7,xmm7  // 7
		movdqa         [edi+6*16],xmm3 
		movdqa         [edi+7*16],xmm7 
over:
	}
}

#undef  LX_AC



/******************************************
idct end
*******************************************/


