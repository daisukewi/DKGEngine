// LxIDCT_MMX.h: interface for the LxIDCT_MMX class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(__LXIDCT_MMX_H__)
#define __LXIDCT_MMX_H__


//#define __LXIDCT_INTRINSIC

/***********************************************************************
IDCT_CHW_SSE2_LOAD_COL  :
***********************************************************************/

#ifdef __LXIDCT_INTRINSIC


#else

#define IDCT_CHW_SSE2_LOAD_COL  \
__asm	movsx      eax, WORD ptr [esi + edx*2 ]        \
__asm   movsx      ecx, WORD ptr [esi + edx*2 + 16*1]  \
__asm	movd       xmm0,eax                            \
__asm	movd       xmm1,ecx                            \
__asm	movzx      eax, WORD ptr [esi + edx*2 + 16*2]  \
__asm	punpcklwd  xmm0,xmm1                           \
__asm   movzx      ecx, WORD ptr [esi + edx*2 + 16*3]  \
__asm	movd       xmm1,eax                            \
__asm	movd       xmm2,ecx                            \
__asm	movzx      eax, WORD ptr [esi + edx*2 + 16*4]  \
__asm	punpcklwd  xmm1,xmm2                           \
__asm   movzx      ecx, WORD ptr [esi + edx*2 + 16*5]  \
__asm	movd       xmm2,eax                            \
__asm	movd       xmm3,ecx                            \
__asm	movzx      eax, WORD ptr [esi + edx*2 + 16*6]  \
__asm	punpcklwd  xmm2,xmm3                           \
__asm   movzx      ecx, WORD ptr [esi + edx*2 + 16*7]  \
__asm	movd       xmm3,eax                            \
__asm	movd       xmm4,ecx                            \
__asm	punpckldq  xmm0,xmm1                           \
__asm	punpcklwd  xmm3,xmm4                           \
__asm	punpckldq  xmm2,xmm3                           \
__asm	punpcklqdq xmm0,xmm2   

#endif // __LXIDCT_INTRINSIC

#endif // !defined(__LXIDCT_MMX_H__)
