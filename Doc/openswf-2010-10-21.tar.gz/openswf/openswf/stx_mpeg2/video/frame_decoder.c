/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-06
***********************************************************************************/
#include "stx_async_plugin.h"
#include "stx_semaphore.h"
#include "stx_mutex.h"


#include "frame_decoder.h"

#include "table.h"
#include "LxIDCT.h"

#include "mc_decoder.h"

#include "stx_cpuid.h"

#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif

/********************************************/
#define __GET_BITS_INC__
#include "get_bits.h"
#include "get_bits.c"
/********************************************/

//#define DCT_COE_STATISTIC



s32               Get_ChromaDC_dct_diff(frame_decoder* the);
s32               Get_Luma_DC_dct_diff(frame_decoder* the);
s32               Get_macroblock_address_increment(frame_decoder* the);
s32               Get_coded_block_pattern(frame_decoder* the);
s32               Get_dmvector(frame_decoder* the);
s32               Get_motion_code(frame_decoder* the);

s32               Get_B_Spatial_macroblock_type(frame_decoder* the);
s32               Get_P_Spatial_macroblock_type(frame_decoder* the);
s32               Get_I_Spatial_macroblock_type(frame_decoder* the);
s32               Get_B_macroblock_type(frame_decoder* the);
s32               Get_P_macroblock_type(frame_decoder* the);
s32               Get_I_macroblock_type(frame_decoder* the);
s32               Get_D_macroblock_type(frame_decoder* the);
s32               Get_macroblock_type(frame_decoder* the);
void              SkippedMacroblock(frame_decoder* the);

void motion_vector
(
	frame_decoder* the,
	s32 *PMV, 
	s32 *dmvector,
	s32 h_r_size, 
	s32 v_r_size, 
	s32 dmv, 
	s32 mvscale, 
	s32 full_pel_vector
);

void decode_motion_vector
(
	s32 *pred,
	s32 r_size, 
	s32 tmotion_code, 
	s32 tmotion_residual,
	s32 full_pel_vector
);

void              macroblock_modes(frame_decoder* the);

void              Sparse_MPEG1_Intra_Block (frame_decoder* the,s32 comp, s32 dc_dct_pred[]);
void              Sparse_MPEG1_Non_Intra_Block (frame_decoder* the,s32 comp);
void              Sparse_MPEG2_Intra_Block(frame_decoder* the,s32 comp,s32 dc_dct_pred[]);
void              Sparse_MPEG2_Non_Intra_Block(frame_decoder* the,s32 comp);

void              Decode_MPEG1_Intra_Block (frame_decoder* the,s32 comp, s32 dc_dct_pred[]);
void              Decode_MPEG1_Non_Intra_Block (frame_decoder* the,s32 comp);

void              Decode_MPEG2_Intra_Block_C(frame_decoder* the,s32 comp,s32 dc_dct_pred[]);
void              Decode_MPEG2_Non_Intra_Block_C(frame_decoder* the,s32 comp);

void              Decode_MPEG2_Intra_Block_sse2(frame_decoder* the,s32 comp,s32 dc_dct_pred[]);
void              Decode_MPEG2_Non_Intra_Block_sse2(frame_decoder* the,s32 comp);

s32		Mp_Get_MPEG1_Intra_Block (frame_decoder* the,s32 comp, s32 dc_dct_pred[]);
s32		Mp_Get_MPEG1_Non_Intra_Block (frame_decoder* the,s32 comp);
s32		Mp_Get_MPEG2_Intra_Block_C(frame_decoder* the,s32 comp,s32 dc_dct_pred[]);
s32		Mp_Get_MPEG2_Non_Intra_Block_C(frame_decoder* the,s32 comp);
s32		Mp_Get_MPEG2_Intra_Block_sse2(frame_decoder* the,s32 comp,s32 dc_dct_pred[]);
s32		Mp_Get_MPEG2_Non_Intra_Block_sse2(frame_decoder* the,s32 comp);
s32		Mp_GetMacroBlock(frame_decoder* the);


STX_PRIVATE void	cpy_mb_c(frame_decoder* the,s32 nOutputPit);
STX_PRIVATE void	clear_block_c(s16* pMb,s32 nBlockCount);

#ifndef STX64
	STX_PRIVATE void	clear_block_mmx(s16* pMb,s32 nBlockCount);
	void				Decode_MPEG2_Intra_Block_mmx(frame_decoder* the,s32 comp,s32 dc_dct_pred[]);
	void				Decode_MPEG2_Non_Intra_Block_mmx(frame_decoder* the,s32 comp);
	s32   Mp_Get_MPEG2_Intra_Block_mmx(frame_decoder* the,s32 comp,s32 dc_dct_pred[]);
	s32   Mp_Get_MPEG2_Non_Intra_Block_mmx(frame_decoder* the,s32 comp);
	STX_PRIVATE void	cpy_mb_mmx(frame_decoder* the,s32 nOutputPit);
#endif

STX_PRIVATE void	cpy_mb_sse2(frame_decoder* the,s32 nOutputPit);
STX_PRIVATE void	clear_block_sse2(s16* pMb,s32 nBlockCount);


#if 1
#define fast_idct(blk,pos) \
	idct_entry[ g_RowNz[GET_ROW_MASK((pos)->dwColMask)] -1 ] \
	[ g_RowNz[GET_COL_MASK((pos)->dwColMask)] - 1 ] (blk,pos);
#else
#define fast_idct(blk,pos) idct(blk,pos)
#endif


//////////////////////////////////////////////////////////////////////////////////////////

s32               DecodeMacroblock(frame_decoder* the,b32 bDecode);

static s32        extra_bit_information (frame_decoder* the);
static s32        SliceHeader(frame_decoder* the);
static void       GetMbPos(frame_decoder* the); // when debug over, use mmx code ;

s32               StartOfSlice(frame_decoder* the);
s32               DecodeSlice(frame_decoder* the);


#ifdef USE_TABTAB

static u8 g_byM2IntraCode1[2][256];
static u8 g_byM2Code0[256];
static u8 g_byM2Code1[256];
static u8 g_byM2NonIntraSub[16] = { 16 , 16, 16 , 16, 16 , 0, 8, 0, 4, 4, 4, 4, 4, };

static PPDCTtab g_M2NonIntraTab[2][16] = {
	{ (DCTtab (*)[16])&DCTtab6, (DCTtab (*)[16])&DCTtab5,  (DCTtab (*)[16])&DCTtab4,  (DCTtab (*)[16])&DCTtab3,  (DCTtab (*)[16])&DCTtab2,
	NULL,     (DCTtab (*)[16])&DCTtab1,  NULL,      (DCTtab (*)[16])&DCTtab0 ,   NULL, NULL, NULL,(DCTtab (*)[16])&DCTtabfirst,},

	{ (DCTtab (*)[16])&DCTtab6, (DCTtab (*)[16])&DCTtab5,  (DCTtab (*)[16])&DCTtab4,  (DCTtab (*)[16])&DCTtab3,  (DCTtab (*)[16])&DCTtab2,
	NULL,     (DCTtab (*)[16])&DCTtab1,  NULL,      (DCTtab (*)[16])&DCTtab0 ,   NULL, NULL, NULL,(DCTtab (*)[16])&DCTtabnext,}
};

static PPDCTtab g_M2IntraTab[2][16] = {
	{ (DCTtab (*)[16])&DCTtab6, (DCTtab (*)[16])&DCTtab5,  (DCTtab (*)[16])&DCTtab4,  (DCTtab (*)[16])&DCTtab3,  (DCTtab (*)[16])&DCTtab2,
	NULL,     (DCTtab (*)[16])&DCTtab1,  NULL,      (DCTtab (*)[16])&DCTtab0 ,   NULL, NULL, NULL,(DCTtab (*)[16])&DCTtabnext,},

	{ (DCTtab (*)[16])&DCTtab6, (DCTtab (*)[16])&DCTtab5,  (DCTtab (*)[16])&DCTtab4,  (DCTtab (*)[16])&DCTtab3,  (DCTtab (*)[16])&DCTtab2,
	NULL,     (DCTtab (*)[16])&DCTtab1a,  NULL,      (DCTtab (*)[16])&DCTtab0a ,   NULL, NULL, NULL, (DCTtab (*)[16])&DCTtab0a,}
};


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

static void InitDctTabTab()
{
	s32 code;

	for( code = 0; code < 256; code ++ ) {

		if (code>=128){
			g_byM2Code0[code] = 3;
		}
		else if (code>=64){
			g_byM2Code0[code] = 2;
		}
		else if (code>=32){
			g_byM2Code0[code] = 1;
		}
		else if (code>=16){
			g_byM2Code0[code] = 0;
		}
		else{
			g_byM2Code0[code] = 0;
		}

		if ( ( code << 8 ) >= 16384){
			g_byM2Code1[code] = 12;
			g_byM2IntraCode1[0][code] = 12;
			g_byM2IntraCode1[1][code] = 8;
		}
		else if ( ( code << 8 ) >= 1024 ){
			g_byM2Code1[code] = 8;
			g_byM2IntraCode1[0][code] = 8;
			g_byM2IntraCode1[1][code] = 8;
		}
		else if ( ( code << 8 ) >= 512 ){
			g_byM2Code1[code] = 6;
			g_byM2IntraCode1[0][code] = 6;
			g_byM2IntraCode1[1][code] = 6;
		}
		else if ( ( code << 8 ) >= 256){
			g_byM2Code1[code] = 4;
			g_byM2IntraCode1[0][code] = 4;
			g_byM2IntraCode1[1][code] = 4;
		}
		else{
			g_byM2Code1[code] = 0;
			g_byM2IntraCode1[0][code] = 0;
			g_byM2IntraCode1[1][code] = 0;
		}
	}
}

#endif 


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

static idct_proc_entry	idct_entry[8][8];
static void				(*adder_128)(s16*,u8*,s32);
static void				(*decode_m2_intra_blk)(frame_decoder* the,s32 comp,s32 dc_pred[]);
static void				(*decode_m2_non_intra_blk)(frame_decoder* the,s32 comp);
static void				(*ClearBlock)(s16* pMb,s32 nBlockCount);
STX_PRIVATE void		(*cpy_mb)(frame_decoder* the,s32 nOutputPit);
STX_PRIVATE void		(*idct)(s16* blk,LxIdctInf* pos);

static s32				(*mp_get_m2_intra_blk)(frame_decoder* the,s32 comp,s32 dc_pred[]);
static s32				(*mp_get_m2_non_intra_blk)(frame_decoder* the,s32 comp);


void init_pre_idct(u32 mmflag )
{
	Initialize_Fast_IDCT();

	adder_128 = adder_128_c;

	aan_idct_c_init(idct_entry);

	decode_m2_intra_blk = Decode_MPEG2_Intra_Block_C;
	decode_m2_non_intra_blk = Decode_MPEG2_Non_Intra_Block_C;

	mp_get_m2_intra_blk = Mp_Get_MPEG2_Intra_Block_C;
	mp_get_m2_non_intra_blk = Mp_Get_MPEG2_Non_Intra_Block_C;

	cpy_mb = cpy_mb_c;
	ClearBlock = clear_block_c;

	idct = idct_aan;


#ifndef STX64
	if(  mmflag & MM_MMX ){
		cpy_mb = cpy_mb_mmx;
		ClearBlock = clear_block_mmx;
		decode_m2_intra_blk = Decode_MPEG2_Intra_Block_mmx;
		decode_m2_non_intra_blk = Decode_MPEG2_Non_Intra_Block_mmx;
		mp_get_m2_intra_blk = Mp_Get_MPEG2_Intra_Block_mmx;
		mp_get_m2_non_intra_blk = Mp_Get_MPEG2_Non_Intra_Block_mmx;
		adder_128 = adder_128_mmx;
		intel_idct_mmx_init(idct_entry);
		//chw_idct_mmx_init(idct_entry);
		idct = idct_mmx;
	}
#endif


	if( mmflag & MM_SSE2 ){
		cpy_mb = cpy_mb_sse2;
		ClearBlock = clear_block_sse2;
		decode_m2_intra_blk = Decode_MPEG2_Intra_Block_sse2;
		decode_m2_non_intra_blk = Decode_MPEG2_Non_Intra_Block_sse2;
		mp_get_m2_intra_blk = Mp_Get_MPEG2_Intra_Block_sse2;
		mp_get_m2_non_intra_blk = Mp_Get_MPEG2_Non_Intra_Block_sse2;
		adder_128 = adder_128_sse2;
		intel_idct_sse2_init(idct_entry);
		//chw_idct_sse2_init(idct_entry);
		idct = idct_sse2;
	}

}


stx_inline void clear_block_c(s16* pMb,s32 nBlockCount)
{
	s32 i;

	for( i = 0; i < nBlockCount; i ++ ) {
		*(s64*)(pMb) = 0;
		*(s64*)(pMb+4) = 0;
		*(s64*)(pMb+8) = 0;
		*(s64*)(pMb+12) = 0;
		*(s64*)(pMb+16) = 0;
		*(s64*)(pMb+20) = 0;
		*(s64*)(pMb+24) = 0;
		*(s64*)(pMb+28) = 0;
		*(s64*)(pMb+32) = 0;
		*(s64*)(pMb+32+4) = 0;
		*(s64*)(pMb+32+8) = 0;
		*(s64*)(pMb+32+12) = 0;
		*(s64*)(pMb+32+16) = 0;
		*(s64*)(pMb+32+20) = 0;
		*(s64*)(pMb+32+24) = 0;
		*(s64*)(pMb+32+28) = 0;
		pMb += 64;
	}

}

#ifndef STX64
stx_inline void clear_block_mmx(s16* pMb,s32 nBlockCount)
{
	__m64 imm7;
	s32 i;

	imm7 = _mm_setzero_si64();

	for( i = 0; i < nBlockCount; i ++ ) {
		*CONV_PM64(pMb) = imm7;
		*CONV_PM64(pMb+4) = imm7;
		*CONV_PM64(pMb+8) = imm7;
		*CONV_PM64(pMb+12) = imm7;
		*CONV_PM64(pMb+16) = imm7;
		*CONV_PM64(pMb+20) = imm7;
		*CONV_PM64(pMb+24) = imm7;
		*CONV_PM64(pMb+28) = imm7;
		*CONV_PM64(pMb+32) = imm7;
		*CONV_PM64(pMb+32+4) = imm7;
		*CONV_PM64(pMb+32+8) = imm7;
		*CONV_PM64(pMb+32+12) = imm7;
		*CONV_PM64(pMb+32+16) = imm7;
		*CONV_PM64(pMb+32+20) = imm7;
		*CONV_PM64(pMb+32+24) = imm7;
		*CONV_PM64(pMb+32+28) = imm7;
		pMb += 64;
	}
	_m_empty();
}
#endif



stx_inline void clear_block_sse2(s16* pMb,s32 nBlockCount)
{
	__m128i ixmm7;
	s32 i;

	ixmm7 = _mm_setzero_si128();

	for( i = 0; i < nBlockCount; i += 2 ) {

		_mm_store_si128( CONV_PXMMI(pMb+   0 ),ixmm7);
		_mm_store_si128( CONV_PXMMI(pMb+   8 ),ixmm7);
		_mm_store_si128( CONV_PXMMI(pMb+16   ),ixmm7);
		_mm_store_si128( CONV_PXMMI(pMb+24   ),ixmm7);

		_mm_store_si128( CONV_PXMMI(pMb+32   ),ixmm7);
		_mm_store_si128( CONV_PXMMI(pMb+32+8 ),ixmm7);
		_mm_store_si128( CONV_PXMMI(pMb+32+16),ixmm7);
		_mm_store_si128( CONV_PXMMI(pMb+32+24),ixmm7);

		_mm_store_si128( CONV_PXMMI(pMb+32+   0 ),ixmm7);
		_mm_store_si128( CONV_PXMMI(pMb+32+   8 ),ixmm7);
		_mm_store_si128( CONV_PXMMI(pMb+32+16   ),ixmm7);
		_mm_store_si128( CONV_PXMMI(pMb+32+24   ),ixmm7);

		_mm_store_si128( CONV_PXMMI(pMb+32+32   ),ixmm7);
		_mm_store_si128( CONV_PXMMI(pMb+32+32+8 ),ixmm7);
		_mm_store_si128( CONV_PXMMI(pMb+32+32+16),ixmm7);
		_mm_store_si128( CONV_PXMMI(pMb+32+32+24),ixmm7);

		_mm_store_si128( CONV_PXMMI(pMb+32+32+32   ),ixmm7);
		_mm_store_si128( CONV_PXMMI(pMb+32+32+32+8 ),ixmm7);
		_mm_store_si128( CONV_PXMMI(pMb+32+32+32+16),ixmm7);
		_mm_store_si128( CONV_PXMMI(pMb+32+32+32+24),ixmm7);

		pMb += 128;
	}
}




//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

#define GetBits(n)      stx_get_bits((stx_bits_window*)bsw,n)
#define GetBits1()      GetBits(1)
#define GetBits18()     GetBits(18)

#define FlushBits(n)    stx_flush_bits((stx_bits_window*)bsw,n)

#define ShowBits(n)     stx_show_bits((stx_bits_window*)bsw,n)
#define FlushBits32()   FlushBits(32)

/* align to start of next next_start_code */
#define NextStartCode() \
{ \
/* byte align */ \
/**/FlushBits(bsw->bs.nCurrentBit & 7); \
/**/while(bsw->bs.nCurrentBit>0){ \
/**//**/if(ShowBits(24) == 0x01L ) { \
/**//**//**/break; \
/**//**/}\
/**//**/FlushBits(8); \
/**/}\
}

/* ISO/IEC 13818-2 sections 6.2.5.2, 6.3.17.2, and 7.6.3: Motion vectors */
#define MotionVectors( \
	PMV,\
	dmvector,\
	motion_vertical_field_select,\
	s,\
	motion_vector_count,\
	mv_format,\
	h_r_size, \
	v_r_size, \
	dmv, \
	mvscale)\
{ \
/**/if (motion_vector_count==1) \
/**/{  \
/**//**/if (mv_format==MV_FIELD && !dmv)  \
/**//**/{  \
/**//**//**/motion_vertical_field_select[1][s] = motion_vertical_field_select[0][s] = GetBits1(); \
/**//**/} \
/**//**/motion_vector(the,PMV[0][s],dmvector,h_r_size,v_r_size,dmv,mvscale,0); \
/**//* update other motion vector predictors */  \
/**//**/PMV[1][s][0] = PMV[0][s][0];  \
/**//**/PMV[1][s][1] = PMV[0][s][1];  \
/**/}  \
/**/else  \
/**/{  \
/**//**/motion_vertical_field_select[0][s] = GetBits1();  \
/**//**/motion_vector(the,PMV[0][s],dmvector,h_r_size,v_r_size,dmv,mvscale,0); \
/**//**/motion_vertical_field_select[1][s] = GetBits1();  \
/**//**/motion_vector(the,PMV[1][s],dmvector,h_r_size,v_r_size,dmv,mvscale,0);  \
/**/}  \
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static void GetMbPos(frame_decoder* the) // when debug over, use MMX code ;
{
	BitsWindow* const bsw = the->pbsw;

	bsw->dwMbPosX += 16;

	bsw->nYuvDit[YUV_DIT_VID][0] += 16;
	bsw->nYuvDit[YUV_DIT_VID][1] += 8;

	if( (s32)bsw->dwMbPosX == the->g_lpDecoder->nCodedPictureWidth ) 	{
		// rarely through;
		bsw->dwMbPosX = 0;
		bsw->dwMbPosY += 16;
		bsw->nYuvDit[YUV_DIT_VID][0] += the->g_lpDecoder->nOutputSlicePit;
		bsw->nYuvDit[YUV_DIT_VID][1] += the->g_lpDecoder->nOutputSlicePitUV;
	}

	bsw->lpYuvAddr[YUV_ADDR_OUTPUT][0] =  bsw->current_frame[0] +
		bsw->nYuvDit[YUV_DIT_VID][0] ; 

	bsw->lpYuvAddr[YUV_ADDR_OUTPUT][1] =  bsw->current_frame[1] + 
		bsw->nYuvDit[YUV_DIT_VID][1] ;      

	bsw->lpYuvAddr[YUV_ADDR_OUTPUT][2] =  bsw->current_frame[2] + 
		bsw->nYuvDit[YUV_DIT_VID][1] ;

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

/* decode extra bit information */
/* ISO/IEC 13818-2 section 6.2.3.4. */
static s32 extra_bit_information(frame_decoder* the)
{
	BitsWindow* const bsw = the->pbsw;

	s32 Byte_Count = 0;

	while (GetBits1()){

		FlushBits(8);

		Byte_Count++;
	}

	return(Byte_Count);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

/* ISO/IEC 13818-2 section 6.2.4 */
static s32 SliceHeader(frame_decoder* the)
{
	BitsWindow* const bsw = the->pbsw;

	s32 slice_vertical_position_extension;
	s32 nQuantizerScaleCode;
	s32 slice_picture_id_enable = 0;
	s32 slice_picture_id = 0;
	s32 extra_information_slice = 0;

	slice_vertical_position_extension =
		(the->g_lpDecoder->bMPEG2Flag && the->g_lpDecoder->nVerticalSize > 2800 ) ? GetBits(3) : 0;

	if (the->g_lpDecoder->bScalableMode == SC_DP )
		the->g_bPriorityBreakPoint = GetBits(7);

	nQuantizerScaleCode = GetBits(5);

	bsw->slice_data.nQuantizerScale =
		the->g_lpDecoder->bMPEG2Flag ? 
		(bsw->pic_cod_ext.nQScaleType ? Non_Linear_quantizer_scale[nQuantizerScaleCode] : nQuantizerScaleCode<<1 ) 
		: nQuantizerScaleCode;

	/* slice_id introduced in March 1995 as part of the video corridendum
	(after the IS was drafted in November 1994) */
	if (GetBits1())	{
		//{ this is a optimazition; baojinlong, 2003-10-27
		u32 code = GetBits(8);
		bsw->slice_data.bIntraSlice = code>>7;
		slice_picture_id_enable = (code>>6) & 1;
		slice_picture_id = code & 0x3f;
		//}

		extra_information_slice = extra_bit_information(the);
	}
	else 
		bsw->slice_data.bIntraSlice = 0;

	return slice_vertical_position_extension;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

/* private prototypes */
/* get and decode motion vector and differential motion vector 
for one prediction */
void  motion_vector(frame_decoder* the,
					s32 *PMV, 
					s32 *dmvector,
					s32 h_r_size, 
					s32 v_r_size, 
					s32 dmv, 
					s32 mvscale, 
					s32 full_pel_vector)
{
	BitsWindow* const bsw = the->pbsw;
	s32 motion_code, motion_residual;

	/* horizontal component */
	/* ISO/IEC 13818-2 Table B-10 */
	motion_code = Get_motion_code(the);
	//motion_code[r][s][0] = Get_motion_code();

	motion_residual = (h_r_size!=0 && motion_code!=0) ? GetBits(h_r_size) : 0;

	decode_motion_vector(&PMV[0],h_r_size,motion_code,motion_residual,full_pel_vector);

	if (dmv) {
		dmvector[0] = Get_dmvector(the);
	}

	/* vertical component */
	motion_code = Get_motion_code(the);

	motion_residual = (v_r_size!=0 && motion_code!=0) ? GetBits(v_r_size) : 0;

	if( mvscale )  {
		PMV[1] = DIV_TRUNC_MIN(PMV[1],2);
	}

	decode_motion_vector(&PMV[1],v_r_size,motion_code,motion_residual,full_pel_vector);

	if (mvscale)    {
		PMV[1] += PMV[1];
	}

	if (dmv)    {
		dmvector[1] = Get_dmvector(the);
	}

}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

/* calculate motion vector component */
/* ISO/IEC 13818-2 section 7.6.3.1: Decoding the motion vectors */
/* Note: the arithmetic here is more elegant than that which is shown 
in 7.6.3.1.  
The end results (the->bsw.PMV[][][]) should, however, be the same.  */
/*

r_size = f_code[s][t] - 1
f = 1 << r_size
high = ( 16 * f ) -  1;
low = ( (-16) * f );
range = ( 32 * f );

if ( (f  == 1) || (motion_code[r][s][t] == 0) )
delta = motion_code[r][s][t] ;
else {
delta = ( ( Abs(motion_code[r][s][t]) - 1 ) * f ) + motion_residual[r][s][t] + 1;
if (motion_code[r][s][t] < 0)
delta = - delta;
}

prediction = PMV[r][s][t];
if ( (mv_format == "field") && (t==1) && (picture_structure == "Frame picture") )
prediction = PMV[r][s][t] DIV 2;

vector'[r][s][t]= prediction + delta;
if (vector'[r][s][t] < low )
vector'[r][s][t] = vector'[r][s][t] + range;
if (vector'[r][s][t] > high)
vector'[r][s][t] = vector'[r][s][t] - range;

if ( (mv_format == "field") && (t==1) && (picture_structure == "Frame picture") )
PMV[r][s][t] = vector'[r][s][t] * 2;
else
PMV[r][s][t] = vector'[r][s][t];
*/

void  decode_motion_vector
(
	s32 *pred,
	s32 r_size, 
	s32 tmotion_code, 
	s32 tmotion_residual,
	s32 full_pel_vector 
) 
{
	s32 lim, vec;  

	lim = 16 << r_size;   

	vec = *pred;
	vec = full_pel_vector ? DIV_TRUNC_MIN(vec,2) : vec;

	if ( tmotion_code > 0 )	{
		vec += ((tmotion_code-1)<<r_size) + tmotion_residual + 1;
		if ( vec >= lim )   {
			vec -= (lim+lim);
		}
	}
	else if ( tmotion_code < 0 ){
		vec -= ((-tmotion_code-1)<<r_size) + tmotion_residual + 1;
		if ( vec < -lim )	  {
			vec += (lim+lim);
		}
	}
	*pred = full_pel_vector ? (vec+vec) : vec;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

s32  Get_macroblock_type(frame_decoder* the)
{
	BitsWindow* const bsw = the->pbsw;
	s32 macroblock_type;

	switch (bsw->pic_header.nPictureCodingType)
	{
	case I_TYPE:
		macroblock_type = 
			the->g_lpDecoder->nPictScal ? Get_I_Spatial_macroblock_type(the) : Get_I_macroblock_type(the);
		break;
	case P_TYPE:
		macroblock_type = 
			the->g_lpDecoder->nPictScal ? Get_P_Spatial_macroblock_type(the) : Get_P_macroblock_type(the);
		break;
	case B_TYPE:
		macroblock_type = 
			the->g_lpDecoder->nPictScal ? Get_B_Spatial_macroblock_type(the) : Get_B_macroblock_type(the);
		break;
	case D_TYPE:
		macroblock_type = Get_D_macroblock_type(the);
		break;
	}

	return macroblock_type;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

s32  Get_I_macroblock_type(frame_decoder* the)
{
	BitsWindow* const bsw = the->pbsw;

	if (GetBits1())   
		return 1;
	if (!GetBits1())    
		the->g_bFaultFlag = 1;
	return 17;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

s32  Get_P_macroblock_type(frame_decoder* the)
{
	BitsWindow* const bsw = the->pbsw;

	s32 code;
	if ((code = ShowBits(6))>=8)  {
		code >>= 3;
		FlushBits(PMBtab0[code].len);
		return PMBtab0[code].val;
	}
	if (code==0){
		the->g_bFaultFlag = 1;
		return 0;
	}
	FlushBits(PMBtab1[code].len);
	return PMBtab1[code].val;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

s32  Get_B_macroblock_type(frame_decoder* the)
{
	BitsWindow* const bsw = the->pbsw;

	s32 code;

	if ((code = ShowBits(6))>=8)  {
		code >>= 2;
		FlushBits(BMBtab0[code].len);
		return BMBtab0[code].val;
	}

	if (code==0){
		the->g_bFaultFlag = 1;
		return 0;
	}
	FlushBits(BMBtab1[code].len);
	return BMBtab1[code].val;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

s32 Get_D_macroblock_type(frame_decoder* the)
{
	BitsWindow* const bsw = the->pbsw;

	if (!GetBits1()){
		the->g_bFaultFlag=1;
	}
	return 1;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

/* the->bsw.macroblock_type for pictures with spatial scalability */
s32  Get_I_Spatial_macroblock_type(frame_decoder* the)
{
	BitsWindow* const bsw = the->pbsw;

	s32 code;
	code = ShowBits(4);

	if (code==0){
		the->g_bFaultFlag = 1;
		return 0;
	}
	FlushBits(spIMBtab[code].len);
	return spIMBtab[code].val;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

s32  Get_P_Spatial_macroblock_type(frame_decoder* the)
{
	BitsWindow* const bsw = the->pbsw;

	s32 code;
	code = ShowBits(7);
	if (code<2){
		the->g_bFaultFlag = 1;
		return 0;
	}
	if (code>=16){
		code >>= 3;
		FlushBits(spPMBtab0[code].len);
		return spPMBtab0[code].val;
	}
	FlushBits(spPMBtab1[code].len);
	return spPMBtab1[code].val;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

s32 Get_B_Spatial_macroblock_type(frame_decoder* the)
{
	BitsWindow* const bsw = the->pbsw;

	s32 code;
	VLCtab const *p;

	code = ShowBits(9);

	if (code>=64){
		p = &spBMBtab0[(code>>5)-2];
	}
	else if (code>=16){
		p = &spBMBtab1[(code>>2)-4];
	}
	else if (code>=8){
		p = &spBMBtab2[code-8];
	}
	else{
		the->g_bFaultFlag = 1;
		return 0;
	}

	FlushBits(p->len);
	return p->val;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

s32 Get_motion_code(frame_decoder* the)
{
	BitsWindow* const bsw = the->pbsw;

	s32 code;
	if (GetBits1()){
		return 0;
	}

	if ((code = ShowBits(9))>=64)  {
		code >>= 6;
		FlushBits(MVtab0[code].len);
		return GetBits1()?-MVtab0[code].val:MVtab0[code].val;
	}

	if (code>=24){
		code >>= 3;
		FlushBits(MVtab1[code].len);
		return GetBits1()?-MVtab1[code].val:MVtab1[code].val;
	}

	if ((code-=12)<0){
		the->g_bFaultFlag=1;
		return 0;
	}

	FlushBits(MVtab2[code].len);

	return GetBits1() ? -MVtab2[code].val : MVtab2[code].val;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

/* get differential motion vector (for dual prime prediction) */
s32  Get_dmvector(frame_decoder* the)
{
	BitsWindow* const bsw = the->pbsw;

	if (GetBits1()){
		return GetBits1() ? -1 : 1;
	}
	else{
		return 0;
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

s32  Get_coded_block_pattern(frame_decoder* the)
{
	BitsWindow* const bsw = the->pbsw;

	s32 code;

	if ((code = ShowBits(9))>=128) {
		code >>= 4;
		FlushBits(CBPtab0[code].len);
		return CBPtab0[code].val;
	}

	if (code>=8){
		code >>= 1;
		FlushBits(CBPtab1[code].len);
		return CBPtab1[code].val;
	}

	if (code<1){
		the->g_bFaultFlag = 1;
		return 0;
	}

	FlushBits(CBPtab2[code].len);

	return CBPtab2[code].val;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

s32  Get_macroblock_address_increment(frame_decoder* the)
{
	BitsWindow* const bsw = the->pbsw;

	s32 code, val;

	val = 0;

	while ((code = ShowBits(11))<24)	{
		if (code!=15) /* if not macroblock_stuffing */		{
			if (code==8) /* if macroblock_escape */		{
				val+= 33;
			}
			else{
				the->g_bFaultFlag = 1;
				return 1;
			}
		}
		FlushBits(11);
	}

	/* macroblock_address_increment == 1 */
	/* ('1' is in the MSB position of the lookahead) */
	if (code>=1024)	{
		FlushBits(1);
		return val + 1;
	}

	/* codes 00010 ... 011xx */
	if (code>=128)	{
		/* remove leading zeros */
		code >>= 6;
		FlushBits(MBAtab1[code].len);    
		return val + MBAtab1[code].val;
	}

	/* codes 00000011000 ... 0000111xxxx */
	code-= 24; /* remove common base */
	FlushBits(MBAtab2[code].len);

	return val + MBAtab2[code].val;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

/* combined MPEG-1 and MPEG-2 stage. parse VLC and 
perform dct_diff arithmetic.

MPEG-1:  ISO/IEC 11172-2 section
MPEG-2:  ISO/IEC 13818-2 section 7.2.1 

Note: the arithmetic here is presented more elegantly than
the spec, yet the results, dct_diff, are the same.
*/

s32 Get_Luma_DC_dct_diff(frame_decoder* the)
{
	BitsWindow* const bsw = the->pbsw;

	s32 code, size, dct_diff;

	/* decode length */
	code = ShowBits(5);  

	if (code<31){
		size = DClumtab0[code].val;
		FlushBits(DClumtab0[code].len);
	}
	else{
		code = ShowBits(9) - 0x1f0;
		size = DClumtab1[code].val;
		FlushBits(DClumtab1[code].len);
	}

	if (size==0){
		dct_diff = 0;
	}
	else{

		dct_diff = GetBits(size);

		if ((dct_diff & (1<<(size-1)))==0){
			dct_diff-= (1<<size) - 1;
		}
	}

	return dct_diff;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

s32 Get_ChromaDC_dct_diff(frame_decoder* the)
{
	BitsWindow* const bsw = the->pbsw;

	s32 code, size, dct_diff;

	/* decode length */
	code = ShowBits(5);

	if (code<31){
		size = DCchromtab0[code].val;
		FlushBits(DCchromtab0[code].len);
	}
	else{
		code = ShowBits(10) - 0x3e0;
		size = DCchromtab1[code].val;
		FlushBits(DCchromtab1[code].len);
	}

	if (size==0){
		dct_diff = 0;
	}
	else{
		dct_diff = GetBits(size);
		if ((dct_diff & (1<<(size-1)))==0){
			dct_diff-= (1<<size) - 1;
		}
	}
	return dct_diff;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

/* ISO/IEC 13818-2 section 7.6.6 */
void SkippedMacroblock(frame_decoder* the)
{
	BitsWindow* const bsw = the->pbsw;

	/* reset intra_dc predictors */
	/* ISO/IEC 13818-2 section 7.2.1: DC coefficients in intra blocks */
	bsw->dc_dct_pred[0] = 0;
	bsw->dc_dct_pred[1] = 0;
	bsw->dc_dct_pred[2] = 0;

	/* reset motion vector predictors */
	/* ISO/IEC 13818-2 section 7.6.3.4: Resetting motion vector predictors */
	if (bsw->pic_header.nPictureCodingType == P_TYPE ){
		bsw->PMV[0][0][0] = 0;
		bsw->PMV[0][0][1] = 0;
		bsw->PMV[1][0][0] = 0;
		bsw->PMV[1][0][1] = 0;
	}

	/* derive motion_type */

	if ( bsw->pic_cod_ext.nPictureStructure == FRAME_PICTURE ){
		bsw->motion_type = MC_FRAME;
	}
	else{

		b32 bvalue;

		bsw->motion_type = MC_FIELD;

		/* predict from field of same parity */
		/* ISO/IEC 13818-2 section 7.6.6.1 and 7.6.6.3: P field picture and B field
		picture */

		bvalue = (b32)(bsw->pic_cod_ext.nPictureStructure == BOTTOM_FIELD);

		bsw->motion_vertical_field_select[0][0] = bvalue;
		bsw->motion_vertical_field_select[0][1] = bvalue;
	}

	/* skipped I are spatial-only predicted, */
	/* skipped P and B are temporal-only predicted */
	/* ISO/IEC 13818-2 section 7.7.6: Skipped macroblocks */

	bsw->stwtype = ( bsw->pic_header.nPictureCodingType == I_TYPE) ? 8 : 0;

	/* IMPLEMENTATION: clear MACROBLOCK_INTRA */

	//	*macroblock_type&= ~MACROBLOCK_INTRA;
	bsw->macroblock_type &= ~MACROBLOCK_INTRA;

	bsw->macroblock_type |= MACROBLOCK_SKIPPED;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

/* return==-1 means go to next picture */
/* the expression "start of DecodeSlice" is used throughout the normative
body of the MPEG specification */
s32 StartOfSlice(frame_decoder* the )
{
	BitsWindow* const bsw = the->pbsw;

	u32 code;
	s32 slice_vert_pos_ext;

	the->g_bFaultFlag = 0;

	NextStartCode();

	code = GetBits(32);

	if ( code < SLICE_START_CODE_MIN || code > SLICE_START_CODE_MAX )	{
		return(-1);  /* trigger: go to next picture */
	}

	/* decode DecodeSlice header (may change the->bsw.slice_data.nQuantizerScale) */
	slice_vert_pos_ext = SliceHeader(the);

	/* decode macroblock address increment */
	bsw->MBAinc = Get_macroblock_address_increment(the);

	if (the->g_bFaultFlag) 	{
		//		return(0);   /* trigger: go to next DecodeSlice */
		return the->g_bSecondSlice ? -1 : 0;
	}

	/* set current location */
	/* NOTE: the arithmetic used to derive macroblock_address below is
	*       equivalent to ISO/IEC 13818-2 section 6.3.17: Macroblock
	*/

	// code & 255: 1 to 0xaf = 175; 
	// slice_vert_pos_ext normaly is 0;
	// so could look up a table;
	bsw->MBA = ( ( slice_vert_pos_ext << 7 ) + ( code & 255 ) - 1 ) * the->g_lpDecoder->nMbWidth
		+ bsw->MBAinc - 1;

	if( bsw->MBA >= the->g_lpDecoder->nMBAmax ){
		return -1;
	}

	//[[ init the mb_pos value;
	// px, py use table;
	bsw->dwMbPosX = the->g_lpDecoder->vdr.lpMbPosTabX[bsw->MBA] << 4;
	bsw->dwMbPosY = the->g_lpDecoder->vdr.lpMbPosTabY[bsw->MBA] << 4;

	// dityuv init; the predyuv,yuv init;

	{
		s32 ndit = (bsw->dwMbPosY  * the->g_lpDecoder->nCodedPicturePitch) <<
			(b32)(bsw->pic_cod_ext.nPictureStructure != FRAME_PICTURE);

		bsw->nYuvDit[YUV_DIT_VID][0] = ndit + bsw->dwMbPosX;

		bsw->nYuvDit[YUV_DIT_VID][1] = (ndit >> 2) + (bsw->dwMbPosX >> 1);

		bsw->lpYuvAddr[YUV_ADDR_OUTPUT][0] = bsw->current_frame[0] + 
			bsw->nYuvDit[YUV_DIT_VID][0];

		bsw->lpYuvAddr[YUV_ADDR_OUTPUT][1] = bsw->current_frame[1] + 
			bsw->nYuvDit[YUV_DIT_VID][1];

		bsw->lpYuvAddr[YUV_ADDR_OUTPUT][2] = bsw->current_frame[2] + 
			bsw->nYuvDit[YUV_DIT_VID][1];
	}
	//]]

	bsw->MBAinc = 1; /* first macroblock in DecodeSlice: not skipped */

	/* reset all DC coefficient and motion vector predictors */
	/* ISO/IEC 13818-2 section 7.2.1: DC coefficients in intra blocks */
	bsw->dc_dct_pred[0] = 0;
	bsw->dc_dct_pred[1] = 0;
	bsw->dc_dct_pred[2] = 0;

	/* ISO/IEC 13818-2 section 7.6.3.4: Resetting motion vector predictors */
	bsw->PMV[0][0][0] = 0;
	bsw->PMV[0][0][1] = 0;
	bsw->PMV[0][1][0] = 0;
	bsw->PMV[0][1][1] = 0;
	bsw->PMV[1][0][0] = 0;
	bsw->PMV[1][0][1] = 0;
	bsw->PMV[1][1][0] = 0;
	bsw->PMV[1][1][1] = 0;

	/* successfull: trigger decode macroblocks in DecodeSlice */
	return(1);
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

/* ISO/IEC 13818-2 section 6.3.17.1: Macroblock modes */
void  macroblock_modes (frame_decoder* the)
{
	BitsWindow* const bsw = the->pbsw;

	s32 stwcode;

	static u8 stwc_table[3][4]
	= { {6,3,7,4}, {2,1,5,4}, {2,5,7,4} };

	static u8 stwclass_table[9]
	= {0, 1, 2, 1, 1, 2, 3, 3, 4};

	//motion_type=0;
	bsw->motion_type = 0;

	/* get the->bsw.macroblock_type */
	bsw->macroblock_type = Get_macroblock_type(the);

	if (the->g_bFaultFlag){
		return;
	}

	/* get spatial_temporal_weight_code */
	if (bsw->macroblock_type & MB_WEIGHT){
		if ( the->g_lpDecoder->nSpatialTemporalWeightCodeTableIndex ==0 ){
			bsw->stwtype = 4;
		}
		else{
			stwcode = GetBits(2);
			bsw->stwtype = stwc_table[the->g_lpDecoder->nSpatialTemporalWeightCodeTableIndex-1][stwcode];
		}
	}
	else{
		bsw->stwtype = (bsw->macroblock_type & MB_CLASS4) ? 8 : 0;
	}

	/* SCALABILITY: derive spatial_temporal_weight_class (Table 7-18) */
	bsw->stwclass = stwclass_table[bsw->stwtype];

	/* get nFrame/field motion type */
	if (bsw->macroblock_type & (MACROBLOCK_MOTION_FORWARD|MACROBLOCK_MOTION_BACKWARD)){
		if (bsw->pic_cod_ext.nPictureStructure==FRAME_PICTURE) {
			/* frame_lpCurBitsWin->motion_type */
			bsw->motion_type = bsw->pic_cod_ext.bFramePredFrameDct ? MC_FRAME : GetBits(2);
		}
		else {
			/* field_lpCurBitsWin->motion_type */
			bsw->motion_type = GetBits(2);
		}
	}
	else if ((bsw->macroblock_type & MACROBLOCK_INTRA) && 
		bsw->pic_cod_ext.bConcealmentMotionVectors)	{
		/* concealment motion vectors */
		bsw->motion_type = (bsw->pic_cod_ext.nPictureStructure==FRAME_PICTURE) ? MC_FRAME : MC_FIELD;
	}

	/* derive motion_vector_count, mv_format and dmv, (table 6-17, 6-18) */
	if (bsw->pic_cod_ext.nPictureStructure==FRAME_PICTURE)	{
		bsw->motion_vector_count = (bsw->motion_type==MC_FIELD && bsw->stwclass<2) ? 2 : 1;
		bsw->mv_format = (bsw->motion_type==MC_FRAME) ? MV_FRAME : MV_FIELD;
	}
	else{
		bsw->motion_vector_count = (bsw->motion_type==MC_16X8) ? 2 : 1;
		bsw->mv_format = MV_FIELD;
	}

	bsw->dmv = (bsw->motion_type==MC_DMV); /* dual prime */

	/* field mv predictions in nFrame pictures have to be scaled
	* ISO/IEC 13818-2 section 7.6.3.1 Decoding the motion vectors
	* IMPLEMENTATION: mvscale is derived for later use in motion_vectors()
	* it displaces the stage:
	*
	*    if((mv_format=="field")&&(t==1)&&(BitsWindowBase.pic_cod_ext.nPictureStructure=="Frame picture"))
	*      prediction = the->bsw.PMV[r][s][t] DIV 2;
	*/

	bsw->mvscale = ((bsw->mv_format==MV_FIELD) && (bsw->pic_cod_ext.nPictureStructure==FRAME_PICTURE));

	/* get the->bsw.dct_type (nFrame DCT / field DCT) */
	bsw->dct_type = (bsw->pic_cod_ext.nPictureStructure==FRAME_PICTURE)
		&& (!bsw->pic_cod_ext.bFramePredFrameDct)
		&& (bsw->macroblock_type & (MACROBLOCK_PATTERN|MACROBLOCK_INTRA))
		? GetBits1()
		: 0;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

/* sparse one intra coded MPEG-1 block */

void  Sparse_MPEG1_Intra_Block(frame_decoder* the,s32 comp,s32 dc_dct_pred[])
{
	BitsWindow* const bsw = the->pbsw;

	s32				val, i;
	u32				code;
	DCTtab const	*tab;

	/* ISO/IEC 11172-2 section 2.4.3.7: Block layer. */
	/* decode DC coefficients */
	if (comp < 4){
		dc_dct_pred[0] += Get_Luma_DC_dct_diff(the);
	}
	else if (comp == 4 ){
		dc_dct_pred[1] += Get_ChromaDC_dct_diff(the);
	}
	else{
		dc_dct_pred[2] += Get_ChromaDC_dct_diff(the);
	}

	if (the->g_bFaultFlag) {
		return;
	}

	/* D-pictures do not contain AC coefficients */
	if(bsw->pic_header.nPictureCodingType == D_TYPE){
		return;
	}


	/* decode AC coefficients */
	for (i=1; ; i++)	{
		code =  ShowBits(16);

		if (code>=16384)
			tab = &DCTtabnext[(code>>12)-4];
		else if (code>=1024)
			tab = &DCTtab0[(code>>8)-4];
		else if (code>=512)
			tab = &DCTtab1[(code>>6)-8];
		else if (code>=256)
			tab = &DCTtab2[(code>>4)-16];
		else if (code>=128)
			tab = &DCTtab3[(code>>3)-16];
		else if (code>=64)
			tab = &DCTtab4[(code>>2)-16];
		else if (code>=32)
			tab = &DCTtab5[(code>>1)-16];
		else if (code>=16)
			tab = &DCTtab6[code-16];
		else{
			the->g_bFaultFlag = 1;
			return;
		}

		FlushBits(tab->len);

		if (tab->run==64) {
			/* end_of_block */
			break;
		}

		if (tab->run==65){ 
			/* escape */
			val = GetBits(14);
			i+= val>>8;
			val &= 0xff;

			if (val==0 || val==128){
				FlushBits(8);
			}
		}
		else{
			i+= tab->run;
			FlushBits(1);
		}

		if (i>=64)	{
			the->g_bFaultFlag = 1;
			return;
		}
	}
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
decode one intra coded MPEG-1 block
***************************************************************************/
void  Decode_MPEG1_Intra_Block(frame_decoder* the,s32 comp,s32 dc_dct_pred[])
{
	BitsWindow* const bsw = the->pbsw;

	s32				val, i;
	s32				j;
	s32				val_sign;
	u32				code;
	DCTtab const*	tab;
	s16*          	lpblk;

	u32				dwMsk;
	LxIdctInf		inf = { 0 };

	lpblk = bsw->Macro_Block.coeff[comp];

	/* ISO/IEC 11172-2 section 2.4.3.7: Block layer. */
	/* decode DC coefficients */
	if (comp < 4)
		lpblk[0] = (dc_dct_pred[0] += Get_Luma_DC_dct_diff(the)) << 3;
	else if (comp == 4 )
		lpblk[0] = (dc_dct_pred[1] += Get_ChromaDC_dct_diff(the)) << 3;
	else
		lpblk[0] = (dc_dct_pred[2] += Get_ChromaDC_dct_diff(the)) << 3;

	if (the->g_bFaultFlag) {
		return;
	}

	/* D-pictures do not contain AC coefficients */
	if(bsw->pic_header.nPictureCodingType == D_TYPE) {
		return;
	}

	dwMsk = g_dwBlockInf[0];

#ifdef DCT_COE_STATISTIC
	inf.dwNzInf     += SET_NZ_INF(dwMsk);
#endif

	inf.dwColMask   |= SET_NZ_MASK(dwMsk);
	inf.byRowPos[0] |= SET_NZ_MASK(dwMsk);

	/* decode AC coefficients */
	for (i=1; ; i++)	{

		code =  ShowBits(16);

		if (code>=16384)
			tab = &DCTtabnext[(code>>12)-4];
		else if (code>=1024)
			tab = &DCTtab0[(code>>8)-4];
		else if (code>=512)
			tab = &DCTtab1[(code>>6)-8];
		else if (code>=256)
			tab = &DCTtab2[(code>>4)-16];
		else if (code>=128)
			tab = &DCTtab3[(code>>3)-16];
		else if (code>=64)
			tab = &DCTtab4[(code>>2)-16];
		else if (code>=32)
			tab = &DCTtab5[(code>>1)-16];
		else if (code>=16)
			tab = &DCTtab6[code-16];
		else{
			the->g_bFaultFlag = 1;
			return;
		}

		FlushBits(tab->len);

		if (tab->run==64) {
			/* end_of_block */
			break;
		}

		if (tab->run==65){ 
			/* escape */
			//      i+= GetBits(6);
			//      val = GetBits(8);
			val = GetBits(14);
			i+= val>>8;
			val &= 0xff;

			if (val==0)
				val = GetBits(8);
			else if (val==128)
				val = GetBits(8) - 256;
			else if (val>128)
				val -= 256;

			if (val_sign = (val<0))
				val = -val;
		}
		else{
			i+= tab->run;
			val = tab->nLevel;
			val_sign = GetBits1();
		}

		if (i>=64)	{
			the->g_bFaultFlag = 1;
			return;
		}

		j = scan[ZIG_ZAG][i];
		dwMsk = g_dwBlockInf[j];

#ifdef DCT_COE_STATISTIC
		inf.dwNzInf     += SET_NZ_INF(dwMsk);
#endif

		inf.dwColMask   |= SET_NZ_MASK(dwMsk);
		inf.byRowPos[j>>3] |= SET_NZ_MASK(dwMsk);

		val = ( val * bsw->slice_data.nQuantizerScale * the->g_lpDecoder->nIntraQuantizerMatrix[j] ) >> 3;

		if (val!=0) 
			val = (val-1) | 1; 

		if (!val_sign)
			lpblk[j] = (val > 2047) ?  2047 :  val; 
		else
			lpblk[j] = (val > 2048 ) ? -2048 : -val; 		
	}

	fast_idct(lpblk,&inf);

	adder_128(lpblk,
		the->bsw.sparse_info[bsw->dct_type][comp].dst,
		the->bsw.sparse_info[bsw->dct_type][comp].lx);

}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
Sparse one non-intra coded MPEG-1 block
***************************************************************************/
void   Sparse_MPEG1_Non_Intra_Block(frame_decoder* the,s32 comp)
{
	BitsWindow* const bsw = the->pbsw;

	s32		val, i;
	u32		code;
	DCTtab const *	tab;

	/* decode AC coefficients */
	//  Macro_Block.block_info[comp].nc=0;

	for (i=0; ; i++){

		code = ShowBits(16);

		if (code>=16384){
			if (i==0)
				tab = &DCTtabfirst[(code>>12)-4];
			else
				tab = &DCTtabnext[(code>>12)-4];
		}
		else if (code>=1024)
			tab = &DCTtab0[(code>>8)-4];
		else if (code>=512)
			tab = &DCTtab1[(code>>6)-8];
		else if (code>=256)
			tab = &DCTtab2[(code>>4)-16];
		else if (code>=128)
			tab = &DCTtab3[(code>>3)-16];
		else if (code>=64)
			tab = &DCTtab4[(code>>2)-16];
		else if (code>=32)
			tab = &DCTtab5[(code>>1)-16];
		else if (code>=16)
			tab = &DCTtab6[code-16];
		else{
			the->g_bFaultFlag = 1;
			return;
		}

		FlushBits(tab->len);

		if (tab->run==64){
			/* end_of_block */
			break;
		}

		if (tab->run==65) {
			/* escape */
			val = GetBits(14);
			i+= val>>8;
			val &= 0xff;

			if (val==0 || val==128){
				FlushBits(8);
			}
		}
		else{
			i+= tab->run;
			FlushBits(1);
		}

		if (i>=64){
			the->g_bFaultFlag = 1;
			return;
		}
	}
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
decode one non-intra coded MPEG-1 block
***************************************************************************/
void Decode_MPEG1_Non_Intra_Block(frame_decoder* the,s32 comp)
{
	BitsWindow* const bsw = the->pbsw;

	s16* 			lpblk;
	DCTtab const*	tab;
	s32				val, i;
	s32				j;
	s32				val_sign;
	u32				code;
	u32				dwMsk;
	LxIdctInf		inf;


	INIT_MEMBER(inf);

	lpblk = bsw->Macro_Block.coeff[comp];

	/* decode AC coefficients */


	for (i=0; ; i++){

		code = ShowBits(16);

		if (code>=16384){
			if (i==0)
				tab = &DCTtabfirst[(code>>12)-4];
			else
				tab = &DCTtabnext[(code>>12)-4];
		}
		else if (code>=1024)
			tab = &DCTtab0[(code>>8)-4];
		else if (code>=512)
			tab = &DCTtab1[(code>>6)-8];
		else if (code>=256)
			tab = &DCTtab2[(code>>4)-16];
		else if (code>=128)
			tab = &DCTtab3[(code>>3)-16];
		else if (code>=64)
			tab = &DCTtab4[(code>>2)-16];
		else if (code>=32)
			tab = &DCTtab5[(code>>1)-16];
		else if (code>=16)
			tab = &DCTtab6[code-16];
		else{
			the->g_bFaultFlag = 1;
			return;
		}

		FlushBits(tab->len);

		if (tab->run==64) {
			/* end_of_block */
			break;
		}

		if (tab->run==65){
		/* escape */
			//      i+= GetBits(6);
			//      val = GetBits(8);
			val = GetBits(14);
			i+= val>>8;
			val &= 0xff;

			if (val==0)
				val = GetBits(8);
			else if (val==128)
				val = GetBits(8) - 256;
			else if (val>128)
				val -= 256;

			if (val_sign = (val<0))
				val = -val;
		}
		else{
			i+= tab->run;
			val = tab->nLevel;
			val_sign = GetBits1();
		}

		if (i>=64){
			the->g_bFaultFlag = 1;
			return;
		}

		j = scan[ZIG_ZAG][i];
		dwMsk = g_dwBlockInf[j];

#ifdef DCT_COE_STATISTIC
		inf.dwNzInf     += SET_NZ_INF(dwMsk);
#endif

		inf.dwColMask   |= SET_NZ_MASK(dwMsk);
		inf.byRowPos[j>>3] |= SET_NZ_MASK(dwMsk);

		val = ( 
			( (val << 1 ) + 1 ) 
				* bsw->slice_data.nQuantizerScale 
					* the->g_lpDecoder->nNonIntraQuantizerMatrix[j]
		) >> 4;

		if (val!=0) 
			val = (val-1) | 1; 

		if (!val_sign)
			lpblk[j] = (val>2047) ?  2047 :  val; 
		else
			lpblk[j] = (val>2048) ? -2048 : -val; 

	}

	fast_idct(lpblk,&inf);

}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

/* Sparse one intra coded MPEG-2 block */
void   Sparse_MPEG2_Intra_Block(frame_decoder* the,s32 comp,s32 dc_dct_pred[])
{
	BitsWindow* const bsw = the->pbsw;

	s32		val, i;
	s32		cc;
	u32		code;
	DCTtab *tab;

	cc = (comp<4) ? 0 : (comp&1)+1;

	/* ISO/IEC 13818-2 section 7.2.1: decode DC coefficients */
	if (cc==0)
		dc_dct_pred[0] += Get_Luma_DC_dct_diff(the);
	else if (cc==1)
		dc_dct_pred[1] += Get_ChromaDC_dct_diff(the);
	else
		dc_dct_pred[2] += Get_ChromaDC_dct_diff(the);

	if (the->g_bFaultFlag) {
		return;
	}


	{

#ifdef USE_TABTAB
		u32				CodeIdx;
		DCTtab			(*ppt)[16];
		const b32		bVlcIntra = bsw->pic_cod_ext.nIntraVlcFormat > 0;
		const u8		*g_byCode1 = g_byM2IntraCode1[bVlcIntra];
		const PPDCTtab	*g_M2Tab  = g_M2IntraTab[bVlcIntra];
#endif

		/* decode AC coefficients */
		for (i=1; ; i++){

			code = ShowBits(16);

#ifdef USE_TABTAB

			if( code < 16 ) {
				the->g_bFaultFlag = TRUE;
				return;
			}
			CodeIdx = code < 256 ? g_byM2Code0[code] : g_byCode1[code>>8];
			ppt = g_M2Tab[CodeIdx];
			if( !ppt ){
				the->g_bFaultFlag = TRUE;
				return;
			}
			tab = &( (*ppt)[ ( code >> CodeIdx ) - g_byM2NonIntraSub[CodeIdx] ] );

#else		
			if (code>=16384 && !bsw->pic_cod_ext.nIntraVlcFormat )
				tab = &DCTtabnext[(code>>12)-4];
			else if (code>=1024){
				if (bsw->pic_cod_ext.nIntraVlcFormat)
					tab = &DCTtab0a[(code>>8)-4];
				else
					tab = &DCTtab0[(code>>8)-4];
			}
			else if (code>=512)	{
				if (bsw->pic_cod_ext.nIntraVlcFormat)
					tab = &DCTtab1a[(code>>6)-8];
				else
					tab = &DCTtab1[(code>>6)-8];
			}
			else if (code>=256)
				tab = &DCTtab2[(code>>4)-16];
			else if (code>=128)
				tab = &DCTtab3[(code>>3)-16];
			else if (code>=64)
				tab = &DCTtab4[(code>>2)-16];
			else if (code>=32)
				tab = &DCTtab5[(code>>1)-16];
			else if (code>=16)
				tab = &DCTtab6[code-16];
			else{
				the->g_bFaultFlag = 1;
				return;
			}
#endif

			FlushBits(tab->len);

			if (tab->run==64) {
				/* end_of_block */
				break;
			}

			if (tab->run==65) {
				/* escape */
				val = GetBits18();
				i+= val>>12;
				val &= 0xfff;

				if ((val&2047)==0){
					the->g_bFaultFlag = 1;
					return;
				}
			}
			else{
				i += tab->run;
				FlushBits(1);
			}

			if (i>=64){
				the->g_bFaultFlag = 1;
				return;
			}

		}

	} // block;

}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
decode one intra coded MPEG-2 block
***************************************************************************/
void   Decode_MPEG2_Intra_Block_mmx(frame_decoder* the,s32 comp,s32 dc_dct_pred[])
{
	BitsWindow* const bsw = the->pbsw;

	s32         val, i;
	s32			j;

	s32         val_sign,  cc, run;
	u32			code;

	DCTtab		*tab;
	s16			*lpblk;
	LxIdctInf	inf;
	u32			dwMsk;


#ifdef __QUANT_TABLE

	__m64 mmval,mmqmat;

	u16 (*qmat)[128][64];

	qmat = ( comp<4 || the->g_lpDecoder->nChromaFormat == CHROMA420 )
		? &the->g_lpDecoder->nIntraQuantizerMatrixTable
		: &the->g_lpDecoder->nChromaIntraQuantizerMatrixTable;

#else

	s32 *qmat;

	/* with data partitioning, data always goes to base layer */
	qmat = ( comp<4 || the->g_lpDecoder->nChromaFormat == CHROMA420 )
		? the->g_lpDecoder->nIntraQuantizerMatrix
		:  the->g_lpDecoder->nChromaIntraQuantizerMatrix;
#endif


	cc = (comp<4) ? 0 : (comp&1)+1;

	/* ISO/IEC 13818-2 section 7.2.1: decode DC coefficients */
	if (cc==0)
		val = (dc_dct_pred[0] += Get_Luma_DC_dct_diff(the));
	else if (cc==1)
		val = (dc_dct_pred[1] += Get_ChromaDC_dct_diff(the));
	else
		val = (dc_dct_pred[2] += Get_ChromaDC_dct_diff(the));

	if (the->g_bFaultFlag) {
		return;
	}

	lpblk = bsw->Macro_Block.coeff[comp];

	lpblk[0] = val << (3 - bsw->pic_cod_ext.nIntraDcPrecision );

	dwMsk = g_dwBlockInf[0];

	INIT_MEMBER(inf);

#ifdef DCT_COE_STATISTIC
	inf.dwNzInf     += SET_NZ_INF(dwMsk);
#endif // DCT_COE_STATISTIC

	inf.dwColMask = SET_NZ_MASK(dwMsk);


	{	

#ifdef USE_TABTAB
		u32				CodeIdx;
		DCTtab			(*ppt)[16];
		const b32		bVlcIntra = bsw->pic_cod_ext.nIntraVlcFormat > 0;
		const u8*		g_byCode1 = g_byM2IntraCode1[bVlcIntra];
		const PPDCTtab	*g_M2Tab  = g_M2IntraTab[bVlcIntra];
#endif // USE_TABTAB

		/* decode AC coefficients */
		for (i=1; ; i++){

			code = ShowBits(16);

#ifdef USE_TABTAB
			if( code < 16 ) {
				the->g_bFaultFlag = TRUE;_m_empty();
				return;
			}
			CodeIdx = code < 256 ? g_byM2Code0[code] : g_byCode1[code>>8];
			ppt = g_M2Tab[CodeIdx];
			tab = &( (*ppt)[ ( code >> CodeIdx ) - g_byM2NonIntraSub[CodeIdx] ] );
#else

			if ( code >= 16384 && !bsw->pic_cod_ext.nIntraVlcFormat ) {
				tab = &DCTtabnext[(code>>12)-4];
			}
			else if (code>=1024) {
				if (bsw->pic_cod_ext.nIntraVlcFormat) {
					tab = &DCTtab0a[(code>>8)-4];
				}
				else{
					tab = &DCTtab0[(code>>8)-4];
				}
			}
			else if (code>=512){
				if (bsw->pic_cod_ext.nIntraVlcFormat){
					tab = &DCTtab1a[(code>>6)-8];
				}
				else{
					tab = &DCTtab1[(code>>6)-8];
				}
			}
			else if (code>=256){
				tab = &DCTtab2[(code>>4)-16];
			}
			else if (code>=128){
				tab = &DCTtab3[(code>>3)-16];
			}
			else if (code>=64){
				tab = &DCTtab4[(code>>2)-16];
			}
			else if (code>=32){
				tab = &DCTtab5[(code>>1)-16];
			}
			else if (code>=16){
				tab = &DCTtab6[code-16];
			}
			else{
				the->g_bFaultFlag = 1;
				_m_empty();
				return;
			}
#endif  // USE TABTAB


			FlushBits(tab->len);//????????

			if (tab->run==64) /* end_of_block */ {
				break;
			}

			if (tab->run==65) /* escape */	{
				//			i+= run = GetBits(6);
				//			val = GetBits(12);
				val = GetBits18();
				i+= (run = val>>12);
				val &= 0xfff;

				if ((val&2047)==0)	{
					the->g_bFaultFlag = 1;_m_empty();
					return;
				}

				if (val_sign = (val>=2048)) {
					val = 4096 - val;
				}
			}
			else{
				i+= run = tab->run;
				val = tab->nLevel;
				val_sign = GetBits1();
			}

			if (i>=64){
				the->g_bFaultFlag = 1;	_m_empty();
				return;
			}


			j = scan[bsw->pic_cod_ext.bAlternateScan][i];

#ifdef __QUANT_TABLE
			mmval = _m_from_int(val);
			mmqmat = _m_from_int( (*qmat)[bsw->slice_data.nQuantizerScale][j] );
			mmval = _m_pmaddwd(mmval,mmqmat);
			val = _m_to_int(mmval) >> 4;
#else 
			val = (val * bsw->slice_data.nQuantizerScale * qmat[j]) >> 4;
#endif // __QUANT_TABLE

			lpblk[j] = val_sign ? -val : val;
			dwMsk = g_dwBlockInf[j];

#ifdef DCT_COE_STATISTIC
			inf.dwNzInf     += SET_NZ_INF(dwMsk);
#endif

			inf.dwColMask   |= SET_NZ_MASK(dwMsk);

		} // 

	}

	fast_idct(lpblk,&inf);

	adder_128(lpblk,
		the->bsw.sparse_info[bsw->dct_type][comp].dst,
		the->bsw.sparse_info[bsw->dct_type][comp].lx);

	_m_empty();
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
 decode one intra coded MPEG-2 block
***************************************************************************/

void   Decode_MPEG2_Intra_Block_sse2(frame_decoder* the,s32 comp,s32 dc_dct_pred[])
{
	BitsWindow* const bsw = the->pbsw;

	s32         val, i;
	s32			j;
	s32         val_sign,  cc, run;
	u32			code;

	DCTtab		*tab;
	s16			*lpblk;
	LxIdctInf	inf;
	u32			dwMsk;


#ifdef __QUANT_TABLE

	__m128i mmval,mmqmat;

	u16 (*qmat)[128][64];

	qmat = ( comp<4 || the->g_lpDecoder->nChromaFormat == CHROMA420 )
		? &the->g_lpDecoder->nIntraQuantizerMatrixTable
		: &the->g_lpDecoder->nChromaIntraQuantizerMatrixTable;

#else


	s32 *qmat;

	/* with data partitioning, data always goes to base layer */
	qmat = ( comp<4 || the->g_lpDecoder->nChromaFormat == CHROMA420 )
		? the->g_lpDecoder->nIntraQuantizerMatrix
		:  the->g_lpDecoder->nChromaIntraQuantizerMatrix;
#endif


	cc = (comp<4) ? 0 : (comp&1)+1;

	/* ISO/IEC 13818-2 section 7.2.1: decode DC coefficients */
	if (cc==0)
		val = (dc_dct_pred[0] += Get_Luma_DC_dct_diff(the));
	else if (cc==1)
		val = (dc_dct_pred[1] += Get_ChromaDC_dct_diff(the));
	else
		val = (dc_dct_pred[2] += Get_ChromaDC_dct_diff(the));

	if (the->g_bFaultFlag) {
		return;
	}

	lpblk = bsw->Macro_Block.coeff[comp];

	lpblk[0] = val << (3 - bsw->pic_cod_ext.nIntraDcPrecision );


	dwMsk = g_dwBlockInf[0];

	INIT_MEMBER(inf);

#ifdef DCT_COE_STATISTIC
	inf.dwNzInf     += SET_NZ_INF(dwMsk);
#endif // DCT_COE_STATISTIC

	inf.dwColMask = SET_NZ_MASK(dwMsk);

	{


#ifdef USE_TABTAB
		u32				CodeIdx;
		DCTtab			(*ppt)[16];
		const b32		bVlcIntra = bsw->pic_cod_ext.nIntraVlcFormat > 0;
		const u8*		g_byCode1 = g_byM2IntraCode1[bVlcIntra];
		const PPDCTtab*	g_M2Tab  = g_M2IntraTab[bVlcIntra];
#endif // USE_TABTAB

	/* decode AC coefficients */
		for (i=1; ; i++){

			code = ShowBits(16);

#ifdef USE_TABTAB
			if( code < 16 ) {
				the->g_bFaultFlag = TRUE;
				return;
			}
			CodeIdx = code < 256 ? g_byM2Code0[code] : g_byCode1[code>>8];
			ppt = g_M2Tab[CodeIdx];
			tab = &( (*ppt)[ ( code >> CodeIdx ) - g_byM2NonIntraSub[CodeIdx] ] );
#else

			if ( code >= 16384 && !bsw->pic_cod_ext.nIntraVlcFormat ) {
				tab = &DCTtabnext[(code>>12)-4];
			}
			else if (code>=1024) {
				if (bsw->pic_cod_ext.nIntraVlcFormat) {
					tab = &DCTtab0a[(code>>8)-4];
				}
				else{
					tab = &DCTtab0[(code>>8)-4];
				}
			}
			else if (code>=512){
				if (bsw->pic_cod_ext.nIntraVlcFormat){
					tab = &DCTtab1a[(code>>6)-8];
				}
				else{
					tab = &DCTtab1[(code>>6)-8];
				}
			}
			else if (code>=256){
				tab = &DCTtab2[(code>>4)-16];
			}
			else if (code>=128){
				tab = &DCTtab3[(code>>3)-16];
			}
			else if (code>=64){
				tab = &DCTtab4[(code>>2)-16];
			}
			else if (code>=32){
				tab = &DCTtab5[(code>>1)-16];
			}
			else if (code>=16){
				tab = &DCTtab6[code-16];
			}
			else{
				the->g_bFaultFlag = 1;
				return;
			}
	#endif  // USE TABTAB


			FlushBits(tab->len);//????????

			if (tab->run==64) /* end_of_block */ {
				break;
			}

			if (tab->run==65) /* escape */	{
				//			i+= run = GetBits(6);
				//			val = GetBits(12);
				val = GetBits18();
				i+= (run = val>>12);
				val &= 0xfff;

				if ((val&2047)==0)	{
					the->g_bFaultFlag = 1;
					return;
				}

				if (val_sign = (val>=2048)) {
					val = 4096 - val;
				}
			}
			else{
				i+= run = tab->run;
				val = tab->nLevel;
				val_sign = GetBits1();
			}

			if (i>=64){
				the->g_bFaultFlag = 1;
				return;
			}

			j = scan[bsw->pic_cod_ext.bAlternateScan][i];

#ifdef __QUANT_TABLE
			/*val = ( val * (*qmat)[the->bsw.slice_data.nQuantizerScale][j] ) >> 4;	*/
			mmval = _mm_cvtsi32_si128(val);
			mmqmat = _mm_cvtsi32_si128( (*qmat)[bsw->slice_data.nQuantizerScale][j] );
			mmval = _mm_madd_epi16(mmval,mmqmat);
			val = _mm_cvtsi128_si32(mmval) >> 4;
#else // __QUANT_TABLE  
			val = (val * bsw->slice_data.nQuantizerScale * qmat[j]) >> 4;
#endif // __QUANT_TABLE #else

			lpblk[j] = val_sign ? -val : val;
			dwMsk = g_dwBlockInf[j];

#ifdef DCT_COE_STATISTIC
			inf.dwNzInf     += SET_NZ_INF(dwMsk);
#endif

			inf.dwColMask   |= SET_NZ_MASK(dwMsk);

		}

	}

	fast_idct(lpblk,&inf);

	adder_128(lpblk,
		the->bsw.sparse_info[bsw->dct_type][comp].dst,
		the->bsw.sparse_info[bsw->dct_type][comp].lx);

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void   Sparse_MPEG2_Non_Intra_Block(frame_decoder* the,s32 comp)
{
	BitsWindow* const bsw = the->pbsw;

	s32		val, i;
	u32		code;
	DCTtab	*tab;

#ifdef USE_TABTAB
	u32		CodeIdx;
	DCTtab	(*ppt)[16];
#endif

	/* decode AC coefficients */
	for (i=0; ; i++)
	{
		code = ShowBits(16);

#ifdef USE_TABTAB
		if( code < 16 ) {
			the->g_bFaultFlag = 1;
			return;
		}
		CodeIdx = code < 256 ? g_byM2Code0[code] : g_byM2Code1[code>>8];
		ppt = g_M2NonIntraTab[i>0][CodeIdx];
		tab = &( (*ppt)[ ( code >> CodeIdx ) - g_byM2NonIntraSub[CodeIdx] ] );
#else
		if (code>=16384){
			if (i==0)
				tab = &DCTtabfirst[(code>>12)-4];
			else
				tab = &DCTtabnext[(code>>12)-4];
		}
		else if (code>=1024)
			tab = &DCTtab0[(code>>8)-4];
		else if (code>=512)
			tab = &DCTtab1[(code>>6)-8];
		else if (code>=256)
			tab = &DCTtab2[(code>>4)-16];
		else if (code>=128)
			tab = &DCTtab3[(code>>3)-16];
		else if (code>=64)
			tab = &DCTtab4[(code>>2)-16];
		else if (code>=32)
			tab = &DCTtab5[(code>>1)-16];
		else if (code>=16)
			tab = &DCTtab6[code-16];
		else{
			the->g_bFaultFlag = 1;
			return;
		}
#endif

		FlushBits(tab->len);

		if (tab->run==64) /* end_of_block */{
			break;
		}

		if (tab->run==65) /* escape */	{
			val = GetBits18();
			i += val >> 12;
			val &= 0xfff;

			if ((val&2047)==0)	{
				the->g_bFaultFlag = 1;
				return;
			}
		}
		else{
			i += tab->run;
			FlushBits(1);
		}

		if (i>=64)		{
			the->g_bFaultFlag = 1;
			return;
		}
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void   Decode_MPEG2_Non_Intra_Block_mmx(frame_decoder* the,s32 comp)
{
	BitsWindow* const bsw = the->pbsw;

	s32				val, i,val_sign, run;
	s32				j;

	u32				code,imul;
	u32				dwMsk;

	DCTtab*			tab;
	s16*			lpblk;
	LxIdctInf		inf;


#ifdef USE_TABTAB
	u32				CodeIdx;
	DCTtab			(*ppt)[16];
#endif


#ifdef __QUANT_TABLE

	__m64 mmval,mmqmat;

	u16 (*qmat)[128][64];

	qmat = ( comp<4 || the->g_lpDecoder->nChromaFormat == CHROMA420 )
		? &the->g_lpDecoder->nNonIntraQuantizerMatrixTable
		: &the->g_lpDecoder->nChromaNonIntraQuantizerMatrixTable;

#else

	s32 *qmat;

	/* with data partitioning, data always goes to base layer */
	qmat = (comp<4 || the->g_lpDecoder->nChromaFormat == CHROMA420 )
		? the->g_lpDecoder->nNonIntraQuantizerMatrix
		: the->g_lpDecoder->nChromaNonIntraQuantizerMatrix;
#endif


	INIT_MEMBER(inf);

	lpblk = bsw->Macro_Block.coeff[comp];

	/* decode AC coefficients */
	for (i=0; ; i++)	{

		code = ShowBits(16);

#ifdef USE_TABTAB
		if( code < 16 ) {
			the->g_bFaultFlag = 1;	_m_empty();
			return;
		}
		CodeIdx = code < 256 ? g_byM2Code0[code] : g_byM2Code1[code>>8];
		ppt = g_M2NonIntraTab[i>0][CodeIdx];
		tab = &( (*ppt)[ ( code >> CodeIdx ) - g_byM2NonIntraSub[CodeIdx] ] );
#else
		if (code>=16384)	{
			if (i==0){
				tab = &DCTtabfirst[(code>>12)-4];
			}
			else{
				tab = &DCTtabnext[(code>>12)-4];
			}
		}
		else if (code>=1024){
			tab = &DCTtab0[(code>>8)-4];
		}
		else if (code>=512){
			tab = &DCTtab1[(code>>6)-8];
		}
		else if (code>=256){
			tab = &DCTtab2[(code>>4)-16];
		}
		else if (code>=128){
			tab = &DCTtab3[(code>>3)-16];
		}
		else if (code>=64){
			tab = &DCTtab4[(code>>2)-16];
		}
		else if (code>=32){
			tab = &DCTtab5[(code>>1)-16];
		}
		else if (code>=16){
			tab = &DCTtab6[code-16];
		}
		else	{
			the->g_bFaultFlag = 1;	_m_empty();
			return;
		}
#endif

		FlushBits(tab->len);

		if (tab->run==64) /* end_of_block */{
			break;
		}

		if (tab->run==65) /* escape */	{
			//i+= run = GetBits(6);
			//val = GetBits(12);

			val = GetBits18();
			i += ( run = val >> 12 );
			val &= 0xfff;

			if ((val&2047)==0)	{
				the->g_bFaultFlag = 1;	_m_empty();
				return;
			}

			if (val_sign = (val>=2048)){
				val = 4096 - val;
			}

		}
		else{
			i+= run = tab->run;
			val = tab->nLevel;
			val_sign = GetBits1();
		}

		if (i>=64)	{
			the->g_bFaultFlag = 1;	_m_empty();
			return;
		}

		/*
		j = scan[bAlternateScan][i];
		val = (((val<<1)+1) * (*qmat)[bsw->slice_data.nQuantizerScale][j]) >> 5;
		lpblk[j] = val_sign ? -val : val;
		*/

		j = scan[bsw->pic_cod_ext.bAlternateScan][i];

#ifdef __QUANT_TABLE
		mmval = _m_from_int((val<<1)+1);
		imul = (u32)(*qmat)[bsw->slice_data.nQuantizerScale][j];
		mmqmat = _m_from_int( imul);
		mmval = _m_pmaddwd(mmval,mmqmat);
		val = _m_to_int(mmval) >> 5;
#else
		val = (((val<<1)+1) * bsw->slice_data.nQuantizerScale * qmat[j]) >> 5;
#endif

		lpblk[j] = val_sign ? -val : val;
		dwMsk = g_dwBlockInf[j];


#ifdef DCT_COE_STATISTIC
		inf.dwNzInf     += SET_NZ_INF(dwMsk);
#endif

		inf.dwColMask   |= SET_NZ_MASK(dwMsk);

	}

	fast_idct(lpblk,&inf);

	_m_empty();
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void   Decode_MPEG2_Non_Intra_Block_sse2(frame_decoder* the,s32 comp)
{
	BitsWindow* const bsw = the->pbsw;

	s32				val, i,val_sign, run;
	u32				code;
	DCTtab*			tab;
	s16*			lpblk;
	LxIdctInf		inf;
	s32				j;
	u32				dwMsk;

#ifdef USE_TABTAB
	u32				CodeIdx;
	DCTtab			(*ppt)[16];
#endif


#ifdef __QUANT_TABLE

	__m128i mmval,mmqmat;

	u16 (*qmat)[128][64];

	qmat = ( comp<4 || the->g_lpDecoder->nChromaFormat == CHROMA420 )
		? &the->g_lpDecoder->nNonIntraQuantizerMatrixTable
		: &the->g_lpDecoder->nChromaNonIntraQuantizerMatrixTable;

#else

	s32 *qmat;

	/* with data partitioning, data always goes to base layer */
	qmat = (comp<4 || the->g_lpDecoder->nChromaFormat == CHROMA420 )
		? the->g_lpDecoder->nNonIntraQuantizerMatrix
		: the->g_lpDecoder->nChromaNonIntraQuantizerMatrix;
#endif


	INIT_MEMBER(inf);

	lpblk = bsw->Macro_Block.coeff[comp];

	/* decode AC coefficients */
	for (i=0; ; i++)	{

		code = ShowBits(16);

#ifdef USE_TABTAB
		if( code < 16 ) {
			the->g_bFaultFlag = 1;
			return;
		}
		CodeIdx = code < 256 ? g_byM2Code0[code] : g_byM2Code1[code>>8];
		ppt = g_M2NonIntraTab[i>0][CodeIdx];
		tab = &( (*ppt)[ ( code >> CodeIdx ) - g_byM2NonIntraSub[CodeIdx] ] );
#else
		if (code>=16384){
			if (i==0){
				tab = &DCTtabfirst[(code>>12)-4];
			}
			else{
				tab = &DCTtabnext[(code>>12)-4];
			}
		}
		else if (code>=1024){
			tab = &DCTtab0[(code>>8)-4];
		}
		else if (code>=512){
			tab = &DCTtab1[(code>>6)-8];
		}
		else if (code>=256){
			tab = &DCTtab2[(code>>4)-16];
		}
		else if (code>=128){
			tab = &DCTtab3[(code>>3)-16];
		}
		else if (code>=64){
			tab = &DCTtab4[(code>>2)-16];
		}
		else if (code>=32){
			tab = &DCTtab5[(code>>1)-16];
		}
		else if (code>=16){
			tab = &DCTtab6[code-16];
		}
		else	{
			the->g_bFaultFlag = 1;
			return;
		}
#endif

		FlushBits(tab->len);

		if (tab->run==64) /* end_of_block */{
			break;
		}

		if (tab->run==65) /* escape */	{
			//i+= run = GetBits(6);
			//val = GetBits(12);

			val = GetBits18();
			i += ( run = val >> 12 );
			val &= 0xfff;

			if ((val&2047)==0)	{
				the->g_bFaultFlag = 1;
				return;
			}

			if (val_sign = (val>=2048)){
				val = 4096 - val;
			}

		}
		else{
			i+= run = tab->run;
			val = tab->nLevel;
			val_sign = GetBits1();
		}

		if (i>=64)	{
			the->g_bFaultFlag = 1;
			return;
		}

		/*
		j = scan[bAlternateScan][i];
		val = (((val<<1)+1) * (*qmat)[bsw->slice_data.nQuantizerScale][j]) >> 5;
		lpblk[j] = val_sign ? -val : val;
		*/
		j = scan[bsw->pic_cod_ext.bAlternateScan][i];

#ifdef __QUANT_TABLE
		mmval = _mm_cvtsi32_si128((val<<1)+1);
		mmqmat = _mm_cvtsi32_si128((u32)(*qmat)[bsw->slice_data.nQuantizerScale][j] );
		mmval = _mm_madd_epi16(mmval,mmqmat);
		val = _mm_cvtsi128_si32(mmval) >> 5;
#else
		val = (((val<<1)+1) * bsw->slice_data.nQuantizerScale * qmat[j]) >> 5;
#endif

		lpblk[j] = val_sign ? -val : val;
		dwMsk = g_dwBlockInf[j];

#ifdef DCT_COE_STATISTIC
		inf.dwNzInf     += SET_NZ_INF(dwMsk);
#endif

		inf.dwColMask   |= SET_NZ_MASK(dwMsk);

	}

	fast_idct(lpblk,&inf);
}



#if !defined ( __QUANT_TABLE) || !defined( USE_TABTAB )
#error "Decode_MPEG2_Block_C must use __QUANT_TABLE";
#endif

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static void Mp_Decode_Non_Intra_Block(frame_decoder* the,s32 comp,s32 coeff,u8* pMb)
{
	s32			i;
	u32			dwMsk;
	LxIdctInf	inf;

	s16* blk = the->bsw.Macro_Block.coeff[comp];

	INIT_MEMBER(inf);

	for( i = 0; i < coeff; i ++ ) {

		u8 const pos = pMb[0];
		blk[pos] = pMb[1] + pMb[2]*256;
		pMb += 3;

		dwMsk = g_dwBlockInf[pos];
		inf.dwColMask   |= SET_NZ_MASK(dwMsk);
		inf.byRowPos[pos>>3] |= SET_NZ_MASK(dwMsk);
	}

	fast_idct(blk,&inf);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static void Mp_Decode_Intra_Block(frame_decoder* the,s32 comp,s32 coeff,u8* pMb)
{
	BitsWindow* const bsw = the->pbsw;
	mc_decoder* const mc = the->g_lpMcDecoder;

	s32			i;
	u32			dwMsk;
	LxIdctInf	inf;

	s16* blk = the->bsw.Macro_Block.coeff[comp];

	INIT_MEMBER(inf);
	dwMsk = g_dwBlockInf[0];
	inf.dwColMask   |= SET_NZ_MASK(dwMsk);
	inf.byRowPos[0] |= SET_NZ_MASK(dwMsk);

	for( i = 0; i < coeff; i ++ ) {

		u8 const pos = pMb[0];
		blk[pos] = pMb[1] + pMb[2]*256;
		pMb += 3;

		dwMsk = g_dwBlockInf[pos];
		inf.dwColMask   |= SET_NZ_MASK(dwMsk);
		inf.byRowPos[pos>>3] |= SET_NZ_MASK(dwMsk);
	}

	fast_idct(blk,&inf);

	adder_128(blk,
		the->bsw.sparse_info[mc->dct_type][comp].dst,
		the->bsw.sparse_info[mc->dct_type][comp].lx);

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
decode one intra coded MPEG-1 block
***************************************************************************/
s32 Mp_Get_MPEG1_Intra_Block(frame_decoder* the,s32 comp,s32 dc_dct_pred[])
{
	BitsWindow* const bsw = the->pbsw;

	s32				coeff;
	s32				val, i;
	s32				j;
	s32				val_sign;
	u32				code;
	DCTtab const*	tab;
	s16          	bval;

	coeff = 0;

	/* ISO/IEC 11172-2 section 2.4.3.7: Block layer. */
	/* decode DC coefficients */
	if (comp < 4)
		bval = (dc_dct_pred[0] += Get_Luma_DC_dct_diff(the)) << 3;
	else if (comp == 4 )
		bval = (dc_dct_pred[1] += Get_ChromaDC_dct_diff(the)) << 3;
	else
		bval = (dc_dct_pred[2] += Get_ChromaDC_dct_diff(the)) << 3;


	the->pMb[0] = 0;
	the->pMb[1] = bval & 0xff;
	the->pMb[2] = bval >> 8;
	the->pMb += 3;
	coeff ++;


	if (the->g_bFaultFlag) {
		return 0;
	}

	/* D-pictures do not contain AC coefficients */
	if(bsw->pic_header.nPictureCodingType == D_TYPE) {
		return 0;
	}

	/* decode AC coefficients */
	for (i=1; ; i++)	{

		code =  ShowBits(16);

		if (code>=16384)
			tab = &DCTtabnext[(code>>12)-4];
		else if (code>=1024)
			tab = &DCTtab0[(code>>8)-4];
		else if (code>=512)
			tab = &DCTtab1[(code>>6)-8];
		else if (code>=256)
			tab = &DCTtab2[(code>>4)-16];
		else if (code>=128)
			tab = &DCTtab3[(code>>3)-16];
		else if (code>=64)
			tab = &DCTtab4[(code>>2)-16];
		else if (code>=32)
			tab = &DCTtab5[(code>>1)-16];
		else if (code>=16)
			tab = &DCTtab6[code-16];
		else{
			the->g_bFaultFlag = 1;
			return 0;
		}

		FlushBits(tab->len);

		if (tab->run==64) {
			/* end_of_block */
			break;
		}

		if (tab->run==65){ 
			/* escape */
			//      i+= GetBits(6);
			//      val = GetBits(8);
			val = GetBits(14);
			i+= val>>8;
			val &= 0xff;

			if (val==0)
				val = GetBits(8);
			else if (val==128)
				val = GetBits(8) - 256;
			else if (val>128)
				val -= 256;

			if (val_sign = (val<0))
				val = -val;
		}
		else{
			i+= tab->run;
			val = tab->nLevel;
			val_sign = GetBits1();
		}

		if (i>=64)	{
			the->g_bFaultFlag = 1;
			return 0;
		}

		j = scan[ZIG_ZAG][i];

		val = ( val * bsw->slice_data.nQuantizerScale * the->g_lpDecoder->nIntraQuantizerMatrix[j] ) >> 3;

		if (val!=0) 
			val = (val-1) | 1; 

		if (!val_sign)
			bval = (val > 2047) ?  2047 :  val; 
		else
			bval = (val > 2048 ) ? -2048 : -val; 

		the->pMb[0] = j;
		the->pMb[1] = bval & 0xff;
		the->pMb[2] = bval >> 8;
		the->pMb += 3;

		coeff ++;
	}

	return coeff;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
decode one non-intra coded MPEG-1 block
***************************************************************************/
s32 Mp_Get_MPEG1_Non_Intra_Block(frame_decoder* the,s32 comp)
{
	BitsWindow* const bsw = the->pbsw;

	s16 			bval;
	DCTtab const*	tab;
	s32				val, i;
	s32				j;
	s32				val_sign;
	u32				code;
	s32				coeff;


	coeff = 0;

	/* decode AC coefficients */

	for (i=0; ; i++){

		code = ShowBits(16);

		if (code>=16384){
			if (i==0)
				tab = &DCTtabfirst[(code>>12)-4];
			else
				tab = &DCTtabnext[(code>>12)-4];
		}
		else if (code>=1024)
			tab = &DCTtab0[(code>>8)-4];
		else if (code>=512)
			tab = &DCTtab1[(code>>6)-8];
		else if (code>=256)
			tab = &DCTtab2[(code>>4)-16];
		else if (code>=128)
			tab = &DCTtab3[(code>>3)-16];
		else if (code>=64)
			tab = &DCTtab4[(code>>2)-16];
		else if (code>=32)
			tab = &DCTtab5[(code>>1)-16];
		else if (code>=16)
			tab = &DCTtab6[code-16];
		else{
			the->g_bFaultFlag = 1;
			return 0;
		}

		FlushBits(tab->len);

		if (tab->run==64) {
			/* end_of_block */
			break;
		}

		if (tab->run==65){
			/* escape */
			//      i+= GetBits(6);
			//      val = GetBits(8);
			val = GetBits(14);
			i+= val>>8;
			val &= 0xff;

			if (val==0)
				val = GetBits(8);
			else if (val==128)
				val = GetBits(8) - 256;
			else if (val>128)
				val -= 256;

			if (val_sign = (val<0))
				val = -val;
		}
		else{
			i+= tab->run;
			val = tab->nLevel;
			val_sign = GetBits1();
		}

		if (i>=64){
			the->g_bFaultFlag = 1;
			return 0;
		}

		j = scan[ZIG_ZAG][i];

		val = ( 
			( (val << 1 ) + 1 ) 
			* bsw->slice_data.nQuantizerScale 
			* the->g_lpDecoder->nNonIntraQuantizerMatrix[j]
		) >> 4;

		if (val!=0) 
			val = (val-1) | 1; 

		if (!val_sign)
			bval = (val>2047) ?  2047 :  val; 
		else
			bval = (val>2048) ? -2048 : -val; 

		the->pMb[0] = j;
		the->pMb[1] = bval & 0xff;
		the->pMb[2] = bval >> 8;
		the->pMb += 3;

		coeff ++;

	}

	return coeff;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
decode one intra coded MPEG-2 block
***************************************************************************/
s32 Mp_Get_MPEG2_Intra_Block_C(frame_decoder* the,s32 comp,s32 dc_dct_pred[])
{
	BitsWindow* const bsw = the->pbsw;

	s32			val, i;
	s32			j;
	s32			val_sign,  cc, run;
	u32			code;
	DCTtab      *tab;
	s16			bval;
	s32			coeff;

	u16 (*qmat)[128][64];


	qmat = ( comp<4 || the->g_lpDecoder->nChromaFormat == CHROMA420 )
		? &the->g_lpDecoder->nIntraQuantizerMatrixTable
		: &the->g_lpDecoder->nChromaIntraQuantizerMatrixTable;

	cc = (comp<4) ? 0 : (comp&1)+1;

	/* ISO/IEC 13818-2 section 7.2.1: decode DC coefficients */
	if (cc==0)
		val = (dc_dct_pred[0] += Get_Luma_DC_dct_diff(the));
	else if (cc==1)
		val = (dc_dct_pred[1] += Get_ChromaDC_dct_diff(the));
	else
		val = (dc_dct_pred[2] += Get_ChromaDC_dct_diff(the));

	if (the->g_bFaultFlag) {
		return 0;
	}

	bval = val << (3 - bsw->pic_cod_ext.nIntraDcPrecision );
	the->pMb[0] = 0;
	the->pMb[1] = bval & 0xff;
	the->pMb[2] = bval >> 8;
	the->pMb += 3;
	coeff = 1;


	{
		u32		CodeIdx;
		DCTtab	(*ppt)[16];

		const b32 bVlcIntra = bsw->pic_cod_ext.nIntraVlcFormat > 0;
		const u8* g_byCode1 = g_byM2IntraCode1[bVlcIntra];
		const PPDCTtab *g_M2Tab  = g_M2IntraTab[bVlcIntra];

		/* decode AC coefficients */
		for (i=1; ; i++)
		{
			code = ShowBits(16);

			if( code < 16 ) {
				the->g_bFaultFlag = TRUE;
				return 0;
			}
			CodeIdx = code < 256 ? g_byM2Code0[code] : g_byCode1[code>>8];
			ppt = g_M2Tab[CodeIdx];
			tab = &( (*ppt)[ ( code >> CodeIdx ) - g_byM2NonIntraSub[CodeIdx] ] );

			FlushBits(tab->len); 

			if ( tab->run == 64 ) /* end_of_block */ {
				break;
			}

			if (tab->run==65) /* escape */	{
				val = GetBits18();
				i+= run = val>>12;
				val &= 0xfff;			
				if ((val&2047)==0)	{
					the->g_bFaultFlag = 1;
					return 0;
				}			
				if (val_sign = (val>=2048)) {
					val = 4096 - val;
				}
			}
			else{
				i+= run = tab->run;
				val = tab->nLevel;
				val_sign = GetBits1();
			}		

			if (i>=64){
				the->g_bFaultFlag = 1;
				return 0;
			}		

			j = scan[bsw->pic_cod_ext.bAlternateScan][i];

			val = ( val * (*qmat)[bsw->slice_data.nQuantizerScale][j] ) >> 4;
			bval = val_sign ? -val : val;

			the->pMb[0] = j;
			the->pMb[1] = bval & 0xff;
			the->pMb[2] = bval >> 8;
			the->pMb += 3;

			coeff ++;

		}

	}

	return coeff;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
decode one intra coded MPEG-2 block
***************************************************************************/
s32 Mp_Get_MPEG2_Intra_Block_mmx(frame_decoder* the,s32 comp,s32 dc_dct_pred[])
{
	BitsWindow* const bsw = the->pbsw;

	s32         val, i;
	s32			j;

	s32         val_sign,  cc, run;
	u32			code;

	DCTtab		*tab;
	s16			bval;
	s32			coeff;


#ifdef __QUANT_TABLE

	__m64 mmval,mmqmat;

	u16 (*qmat)[128][64];

	qmat = ( comp<4 || the->g_lpDecoder->nChromaFormat == CHROMA420 )
		? &the->g_lpDecoder->nIntraQuantizerMatrixTable
		: &the->g_lpDecoder->nChromaIntraQuantizerMatrixTable;

#else

	s32 *qmat;

	/* with data partitioning, data always goes to base layer */
	qmat = ( comp<4 || the->g_lpDecoder->nChromaFormat == CHROMA420 )
		? the->g_lpDecoder->nIntraQuantizerMatrix
		:  the->g_lpDecoder->nChromaIntraQuantizerMatrix;
#endif

	cc = (comp<4) ? 0 : (comp&1)+1;

	/* ISO/IEC 13818-2 section 7.2.1: decode DC coefficients */
	if (cc==0)
		val = (dc_dct_pred[0] += Get_Luma_DC_dct_diff(the));
	else if (cc==1)
		val = (dc_dct_pred[1] += Get_ChromaDC_dct_diff(the));
	else
		val = (dc_dct_pred[2] += Get_ChromaDC_dct_diff(the));

	if (the->g_bFaultFlag) {
		return 0;
	}

	bval = val << (3 - bsw->pic_cod_ext.nIntraDcPrecision );
	the->pMb[0] = 0;
	the->pMb[1] = bval & 0xff;
	the->pMb[2] = bval >> 8;
	the->pMb += 3;
	coeff = 1;

	{	

#ifdef USE_TABTAB
		u32				CodeIdx;
		DCTtab			(*ppt)[16];
		const b32		bVlcIntra = bsw->pic_cod_ext.nIntraVlcFormat > 0;
		const u8*		g_byCode1 = g_byM2IntraCode1[bVlcIntra];
		const PPDCTtab	*g_M2Tab  = g_M2IntraTab[bVlcIntra];
#endif // USE_TABTAB

		/* decode AC coefficients */
		for (i=1; ; i++){

			code = ShowBits(16);

#ifdef USE_TABTAB
			if( code < 16 ) {
				the->g_bFaultFlag = TRUE;_m_empty();
				return 0;
			}
			CodeIdx = code < 256 ? g_byM2Code0[code] : g_byCode1[code>>8];
			ppt = g_M2Tab[CodeIdx];
			tab = &( (*ppt)[ ( code >> CodeIdx ) - g_byM2NonIntraSub[CodeIdx] ] );
#else

			if ( code >= 16384 && !bsw->pic_cod_ext.nIntraVlcFormat ) {
				tab = &DCTtabnext[(code>>12)-4];
			}
			else if (code>=1024) {
				if (bsw->pic_cod_ext.nIntraVlcFormat) {
					tab = &DCTtab0a[(code>>8)-4];
				}
				else{
					tab = &DCTtab0[(code>>8)-4];
				}
			}
			else if (code>=512){
				if (bsw->pic_cod_ext.nIntraVlcFormat){
					tab = &DCTtab1a[(code>>6)-8];
				}
				else{
					tab = &DCTtab1[(code>>6)-8];
				}
			}
			else if (code>=256){
				tab = &DCTtab2[(code>>4)-16];
			}
			else if (code>=128){
				tab = &DCTtab3[(code>>3)-16];
			}
			else if (code>=64){
				tab = &DCTtab4[(code>>2)-16];
			}
			else if (code>=32){
				tab = &DCTtab5[(code>>1)-16];
			}
			else if (code>=16){
				tab = &DCTtab6[code-16];
			}
			else{
				the->g_bFaultFlag = 1;				_m_empty();
				return 0;
			}
#endif  // USE TABTAB


			FlushBits(tab->len);//????????

			if (tab->run==64) /* end_of_block */ {
				break;
			}

			if (tab->run==65) /* escape */	{
				//			i+= run = GetBits(6);
				//			val = GetBits(12);
				val = GetBits18();
				i+= (run = val>>12);
				val &= 0xfff;

				if ((val&2047)==0)	{
					the->g_bFaultFlag = 1;_m_empty();
					return 0;
				}

				if (val_sign = (val>=2048)) {
					val = 4096 - val;
				}
			}
			else{
				i+= run = tab->run;
				val = tab->nLevel;
				val_sign = GetBits1();
			}

			if (i>=64){
				the->g_bFaultFlag = 1;	_m_empty();
				return 0;
			}


			j = scan[bsw->pic_cod_ext.bAlternateScan][i];

#ifdef __QUANT_TABLE
			mmval = _m_from_int(val);
			mmqmat = _m_from_int( (*qmat)[bsw->slice_data.nQuantizerScale][j] );
			mmval = _m_pmaddwd(mmval,mmqmat);
			val = _m_to_int(mmval) >> 4;
#else 
			val = (val * bsw->slice_data.nQuantizerScale * qmat[j]) >> 4;
#endif // __QUANT_TABLE

			bval = val_sign ? -val : val;

			the->pMb[0] = j;
			the->pMb[1] = bval & 0xff;
			the->pMb[2] = bval >> 8;
			the->pMb += 3;

			coeff ++;

		} // 

	}

	_m_empty();
	return coeff;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
decode one intra coded MPEG-2 block
***************************************************************************/
s32   Mp_Get_MPEG2_Intra_Block_sse2(frame_decoder* the,s32 comp,s32 dc_dct_pred[])
{
	BitsWindow* const bsw = the->pbsw;

	s32         val, i;
	s32			j;
	s32         val_sign,  cc, run;
	u32			code;

	DCTtab		*tab;
	s16			bval;
	s32			coeff;

#ifdef __QUANT_TABLE

	__m128i mmval,mmqmat;

	u16 (*qmat)[128][64];

	qmat = ( comp<4 || the->g_lpDecoder->nChromaFormat == CHROMA420 )
		? &the->g_lpDecoder->nIntraQuantizerMatrixTable
		: &the->g_lpDecoder->nChromaIntraQuantizerMatrixTable;

#else


	s32 *qmat;

	/* with data partitioning, data always goes to base layer */
	qmat = ( comp<4 || the->g_lpDecoder->nChromaFormat == CHROMA420 )
		? the->g_lpDecoder->nIntraQuantizerMatrix
		:  the->g_lpDecoder->nChromaIntraQuantizerMatrix;
#endif

	cc = (comp<4) ? 0 : (comp&1)+1;

	/* ISO/IEC 13818-2 section 7.2.1: decode DC coefficients */
	if (cc==0)
		val = (dc_dct_pred[0] += Get_Luma_DC_dct_diff(the));
	else if (cc==1)
		val = (dc_dct_pred[1] += Get_ChromaDC_dct_diff(the));
	else
		val = (dc_dct_pred[2] += Get_ChromaDC_dct_diff(the));

	if (the->g_bFaultFlag) {
		return 0;
	}

	bval = val << (3 - bsw->pic_cod_ext.nIntraDcPrecision );
	the->pMb[0] = 0;
	the->pMb[1] = bval & 0xff;
	the->pMb[2] = bval >> 8;
	the->pMb += 3;

	coeff = 1;


	{


#ifdef USE_TABTAB
		u32				CodeIdx;
		DCTtab			(*ppt)[16];
		const b32		bVlcIntra = bsw->pic_cod_ext.nIntraVlcFormat > 0;
		const u8*		g_byCode1 = g_byM2IntraCode1[bVlcIntra];
		const PPDCTtab*	g_M2Tab  = g_M2IntraTab[bVlcIntra];
#endif // USE_TABTAB

		/* decode AC coefficients */
		for (i=1; ; i++){

			code = ShowBits(16);

#ifdef USE_TABTAB
			if( code < 16 ) {
				the->g_bFaultFlag = TRUE;
				return 0;
			}
			CodeIdx = code < 256 ? g_byM2Code0[code] : g_byCode1[code>>8];
			ppt = g_M2Tab[CodeIdx];
			tab = &( (*ppt)[ ( code >> CodeIdx ) - g_byM2NonIntraSub[CodeIdx] ] );
#else

			if ( code >= 16384 && !bsw->pic_cod_ext.nIntraVlcFormat ) {
				tab = &DCTtabnext[(code>>12)-4];
			}
			else if (code>=1024) {
				if (bsw->pic_cod_ext.nIntraVlcFormat) {
					tab = &DCTtab0a[(code>>8)-4];
				}
				else{
					tab = &DCTtab0[(code>>8)-4];
				}
			}
			else if (code>=512){
				if (bsw->pic_cod_ext.nIntraVlcFormat){
					tab = &DCTtab1a[(code>>6)-8];
				}
				else{
					tab = &DCTtab1[(code>>6)-8];
				}
			}
			else if (code>=256){
				tab = &DCTtab2[(code>>4)-16];
			}
			else if (code>=128){
				tab = &DCTtab3[(code>>3)-16];
			}
			else if (code>=64){
				tab = &DCTtab4[(code>>2)-16];
			}
			else if (code>=32){
				tab = &DCTtab5[(code>>1)-16];
			}
			else if (code>=16){
				tab = &DCTtab6[code-16];
			}
			else{
				the->g_bFaultFlag = 1;
				return 0;
			}
#endif  // USE TABTAB


			FlushBits(tab->len);//????????

			if (tab->run==64) /* end_of_block */ {
				break;
			}

			if (tab->run==65) /* escape */	{
				//			i+= run = GetBits(6);
				//			val = GetBits(12);
				val = GetBits18();
				i+= (run = val>>12);
				val &= 0xfff;

				if ((val&2047)==0)	{
					the->g_bFaultFlag = 1;
					return 0;
				}

				if (val_sign = (val>=2048)) {
					val = 4096 - val;
				}
			}
			else{
				i+= run = tab->run;
				val = tab->nLevel;
				val_sign = GetBits1();
			}

			if (i>=64){
				the->g_bFaultFlag = 1;
				return 0;
			}

			j = scan[bsw->pic_cod_ext.bAlternateScan][i];

#ifdef __QUANT_TABLE
			/*val = ( val * (*qmat)[the->bsw.slice_data.nQuantizerScale][j] ) >> 4;	*/
			mmval = _mm_cvtsi32_si128(val);
			mmqmat = _mm_cvtsi32_si128( (*qmat)[bsw->slice_data.nQuantizerScale][j] );
			mmval = _mm_madd_epi16(mmval,mmqmat);
			val = _mm_cvtsi128_si32(mmval) >> 4;
#else // __QUANT_TABLE  
			val = (val * bsw->slice_data.nQuantizerScale * qmat[j]) >> 4;
#endif // __QUANT_TABLE #else

			bval = val_sign ? -val : val;

			the->pMb[0] = j;
			the->pMb[1] = bval & 0xff;
			the->pMb[2] = bval >> 8;
			the->pMb += 3;

			coeff ++;

		}

	}

	return coeff;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
s32 Mp_Get_MPEG2_Non_Intra_Block_C(frame_decoder* the,s32 comp)
{
	BitsWindow* const bsw = the->pbsw;


	s32				val, i,val_sign, run;
	u32				code;
	s16				bval;

	s32				j;
	u16				(*qmat)[128][64];

	u32				CodeIdx;
	DCTtab			(*ppt)[16];
	DCTtab*			tab;

	s32				coeff;

	qmat = ( comp<4 || the->g_lpDecoder->nChromaFormat == CHROMA420 )
		? &the->g_lpDecoder->nNonIntraQuantizerMatrixTable
		: &the->g_lpDecoder->nChromaNonIntraQuantizerMatrixTable;

	coeff = 0;

	/* decode AC coefficients */
	for (i=0; ; i++)	{

		code = ShowBits(16);
		if( code < 16 ) {
			the->g_bFaultFlag = 1;
			return 0;
		}

		CodeIdx = code < 256 ? g_byM2Code0[code] : g_byM2Code1[code>>8];
		ppt = g_M2NonIntraTab[i>0][CodeIdx];
		tab = &( (*ppt)[ ( code >> CodeIdx ) - g_byM2NonIntraSub[CodeIdx] ] );

		FlushBits(tab->len);

		if (tab->run==64) /* end_of_block */{
			break;
		}

		if (tab->run==65) /* escape */	{
			val = GetBits18();
			i+= run = val >> 12;
			val &= 0xfff;

			if ((val&2047)==0)	{
				the->g_bFaultFlag = 1;
				return 0;
			}

			if (val_sign = (val>=2048)){
				val = 4096 - val;
			}
		}
		else{
			i+= run = tab->run;
			val = tab->nLevel;
			val_sign = GetBits1();
		}

		if ( i >= 64 )	{
			the->g_bFaultFlag = 1;
			return 0;
		}

		j = scan[bsw->pic_cod_ext.bAlternateScan][i];

		val = (((val<<1)+1) * (*qmat)[bsw->slice_data.nQuantizerScale][j]) >> 5;
		bval = val_sign ? -val : val;

		the->pMb[0] = j;
		the->pMb[1] = bval & 0xff;
		the->pMb[2] = bval >> 8;
		the->pMb += 3;

		coeff ++;

	}

	return coeff;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
s32 Mp_Get_MPEG2_Non_Intra_Block_mmx(frame_decoder* the,s32 comp)
{
	BitsWindow* const bsw = the->pbsw;

	s32				val, i,val_sign, run;
	s32				j;

	u32				code,imul;
	u32				dwMsk;

	DCTtab*			tab;
	s16 			bval;
	s32				coeff;

#ifdef USE_TABTAB
	u32				CodeIdx;
	DCTtab			(*ppt)[16];
#endif


#ifdef __QUANT_TABLE

	__m64 mmval,mmqmat;

	u16 (*qmat)[128][64];

	qmat = ( comp<4 || the->g_lpDecoder->nChromaFormat == CHROMA420 )
		? &the->g_lpDecoder->nNonIntraQuantizerMatrixTable
		: &the->g_lpDecoder->nChromaNonIntraQuantizerMatrixTable;

#else

	s32 *qmat;

	/* with data partitioning, data always goes to base layer */
	qmat = (comp<4 || the->g_lpDecoder->nChromaFormat == CHROMA420 )
		? the->g_lpDecoder->nNonIntraQuantizerMatrix
		: the->g_lpDecoder->nChromaNonIntraQuantizerMatrix;
#endif


	coeff = 0;

	/* decode AC coefficients */
	for (i=0; ; i++)	{

		code = ShowBits(16);

#ifdef USE_TABTAB
		if( code < 16 ) {
			the->g_bFaultFlag = 1;	_m_empty();
			return 0;
		}
		CodeIdx = code < 256 ? g_byM2Code0[code] : g_byM2Code1[code>>8];
		ppt = g_M2NonIntraTab[i>0][CodeIdx];
		tab = &( (*ppt)[ ( code >> CodeIdx ) - g_byM2NonIntraSub[CodeIdx] ] );
#else
		if (code>=16384)	{
			if (i==0){
				tab = &DCTtabfirst[(code>>12)-4];
			}
			else{
				tab = &DCTtabnext[(code>>12)-4];
			}
		}
		else if (code>=1024){
			tab = &DCTtab0[(code>>8)-4];
		}
		else if (code>=512){
			tab = &DCTtab1[(code>>6)-8];
		}
		else if (code>=256){
			tab = &DCTtab2[(code>>4)-16];
		}
		else if (code>=128){
			tab = &DCTtab3[(code>>3)-16];
		}
		else if (code>=64){
			tab = &DCTtab4[(code>>2)-16];
		}
		else if (code>=32){
			tab = &DCTtab5[(code>>1)-16];
		}
		else if (code>=16){
			tab = &DCTtab6[code-16];
		}
		else	{
			the->g_bFaultFlag = 1;	_m_empty();
			return 0;
		}
#endif

		FlushBits(tab->len);

		if (tab->run==64) /* end_of_block */{
			break;
		}

		if (tab->run==65) /* escape */	{
			//i+= run = GetBits(6);
			//val = GetBits(12);

			val = GetBits18();
			i += ( run = val >> 12 );
			val &= 0xfff;

			if ((val&2047)==0)	{
				the->g_bFaultFlag = 1;	_m_empty();
				return 0;
			}

			if (val_sign = (val>=2048)){
				val = 4096 - val;
			}

		}
		else{
			i+= run = tab->run;
			val = tab->nLevel;
			val_sign = GetBits1();
		}

		if (i>=64)	{
			the->g_bFaultFlag = 1;	_m_empty();
			return 0;
		}

		/*
		j = scan[bAlternateScan][i];
		val = (((val<<1)+1) * (*qmat)[bsw->slice_data.nQuantizerScale][j]) >> 5;
		lpblk[j] = val_sign ? -val : val;
		*/

		j = scan[bsw->pic_cod_ext.bAlternateScan][i];

#ifdef __QUANT_TABLE
		mmval = _m_from_int((val<<1)+1);
		imul = (u32)(*qmat)[bsw->slice_data.nQuantizerScale][j];
		mmqmat = _m_from_int( imul);
		mmval = _m_pmaddwd(mmval,mmqmat);
		val = _m_to_int(mmval) >> 5;
#else
		val = (((val<<1)+1) * bsw->slice_data.nQuantizerScale * qmat[j]) >> 5;
#endif

		bval = val_sign ? -val : val;

		the->pMb[0] = j;
		the->pMb[1] = bval & 0xff;
		the->pMb[2] = bval >> 8;
		the->pMb += 3;

		coeff ++;

	}

	_m_empty();
	
	return coeff;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
s32   Mp_Get_MPEG2_Non_Intra_Block_sse2(frame_decoder* the,s32 comp)
{
	BitsWindow* const bsw = the->pbsw;

	s32				val, i,val_sign, run;
	u32				code;
	DCTtab*			tab;
	s16				bval;
	s32				j,coeff;

#ifdef USE_TABTAB
	u32				CodeIdx;
	DCTtab			(*ppt)[16];
#endif


#ifdef __QUANT_TABLE

	__m128i mmval,mmqmat;

	u16 (*qmat)[128][64];

	qmat = ( comp<4 || the->g_lpDecoder->nChromaFormat == CHROMA420 )
		? &the->g_lpDecoder->nNonIntraQuantizerMatrixTable
		: &the->g_lpDecoder->nChromaNonIntraQuantizerMatrixTable;

#else

	s32 *qmat;

	/* with data partitioning, data always goes to base layer */
	qmat = (comp<4 || the->g_lpDecoder->nChromaFormat == CHROMA420 )
		? the->g_lpDecoder->nNonIntraQuantizerMatrix
		: the->g_lpDecoder->nChromaNonIntraQuantizerMatrix;
#endif

	coeff = 0;

	/* decode AC coefficients */
	for (i=0; ; i++)	{

		code = ShowBits(16);

#ifdef USE_TABTAB
		if( code < 16 ) {
			the->g_bFaultFlag = 1;
			return 0;
		}
		CodeIdx = code < 256 ? g_byM2Code0[code] : g_byM2Code1[code>>8];
		ppt = g_M2NonIntraTab[i>0][CodeIdx];
		tab = &( (*ppt)[ ( code >> CodeIdx ) - g_byM2NonIntraSub[CodeIdx] ] );
#else
		if (code>=16384){
			if (i==0){
				tab = &DCTtabfirst[(code>>12)-4];
			}
			else{
				tab = &DCTtabnext[(code>>12)-4];
			}
		}
		else if (code>=1024){
			tab = &DCTtab0[(code>>8)-4];
		}
		else if (code>=512){
			tab = &DCTtab1[(code>>6)-8];
		}
		else if (code>=256){
			tab = &DCTtab2[(code>>4)-16];
		}
		else if (code>=128){
			tab = &DCTtab3[(code>>3)-16];
		}
		else if (code>=64){
			tab = &DCTtab4[(code>>2)-16];
		}
		else if (code>=32){
			tab = &DCTtab5[(code>>1)-16];
		}
		else if (code>=16){
			tab = &DCTtab6[code-16];
		}
		else	{
			the->g_bFaultFlag = 1;
			return 0;
		}
#endif

		FlushBits(tab->len);

		if (tab->run==64) /* end_of_block */{
			break;
		}

		if (tab->run==65) /* escape */	{
			//i+= run = GetBits(6);
			//val = GetBits(12);

			val = GetBits18();
			i += ( run = val >> 12 );
			val &= 0xfff;

			if ((val&2047)==0)	{
				the->g_bFaultFlag = 1;
				return 0;
			}

			if (val_sign = (val>=2048)){
				val = 4096 - val;
			}

		}
		else{
			i+= run = tab->run;
			val = tab->nLevel;
			val_sign = GetBits1();
		}

		if (i>=64)	{
			the->g_bFaultFlag = 1;
			return 0;
		}

		/*
		j = scan[bAlternateScan][i];
		val = (((val<<1)+1) * (*qmat)[bsw->slice_data.nQuantizerScale][j]) >> 5;
		lpblk[j] = val_sign ? -val : val;
		*/
		j = scan[bsw->pic_cod_ext.bAlternateScan][i];

#ifdef __QUANT_TABLE
		mmval = _mm_cvtsi32_si128((val<<1)+1);
		mmqmat = _mm_cvtsi32_si128((u32)(*qmat)[bsw->slice_data.nQuantizerScale][j] );
		mmval = _mm_madd_epi16(mmval,mmqmat);
		val = _mm_cvtsi128_si32(mmval) >> 5;
#else
		val = (((val<<1)+1) * bsw->slice_data.nQuantizerScale * qmat[j]) >> 5;
#endif

		bval = val_sign ? -val : val;

		the->pMb[0] = j;
		the->pMb[1] = bval & 0xff;
		the->pMb[2] = bval >> 8;
		the->pMb += 3;

		coeff ++;
	}

	return coeff;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
s32  Mp_SkipMacroblock(frame_decoder* the)
{
	BitsWindow* const bsw = the->pbsw;
	s32 i,j,k;

	for( i = 0; i < 3; i ++ ) {
		*(u8**)the->pMb = bsw->lpYuvAddr[YUV_ADDR_OUTPUT][i];
		the->pMb += sizeof(u8*);
	}

	*(u16*)the->pMb = (u16)bsw->macroblock_type; 
	the->pMb += sizeof(u16);

	*(u16*)the->pMb = (u16)bsw->dct_type; 
	the->pMb += sizeof(u16);

	*(u16*)the->pMb = (u16)bsw->motion_type;
	the->pMb += sizeof(u16);

	*(u16*)the->pMb = (u16)bsw->stwtype;
	the->pMb += sizeof(u16);

	*(u16*)the->pMb = (u16)bsw->dwMbPosX;
	the->pMb += sizeof(u16);

	*(u16*)the->pMb = (u16)bsw->dwMbPosY;
	the->pMb += sizeof(u16);

	for( i = 0; i < 2; i ++ ) {
		for( j = 0; j < 2; j ++ ) {
			for( k = 0; k < 2; k ++ ) {
				*(s16*)the->pMb = (s16)bsw->PMV[i][j][k];
				the->pMb += sizeof(s16);
			}
		}
	}

	for( i = 0; i < 2; i ++ ) {
		for( j = 0; j < 2; j ++ ) {
			*(u16*)the->pMb = (u16)bsw->motion_vertical_field_select[i][j];
			the->pMb += sizeof(u16);
		}
	}

	for( i = 0; i < 4; i ++ ) {
		*(s16*)the->pMb = (s16)bsw->dmvector[i];
		the->pMb += sizeof(s16);
	}

	the->pMb = (u8*)( ((size_t)the->pMb + 7 ) & ~7 );

	return 1;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
decode one non-intra coded MPEG-2 block
ISO/IEC 13818-2 sections 7.2 through 7.5
***************************************************************************/
s32  Mp_GetMacroBlock(frame_decoder* the)
{
	BitsWindow* const bsw = the->pbsw;

	u8	*paddr,*pcoeff,*pMb;

	/* locals */
	s32 nQuantizerScaleCode; 
	s32 i,j,k,comp;

	/* ISO/IEC 13818-2 section 6.3.17.1: Macro-block modes 
	macroblock_modes(macroblock_type, stwtype, stwclass,
	motion_type, &motion_vector_count, &mv_format, &dmv, &mvscale,
	dct_type);*/

	macroblock_modes(the);

	if (the->g_bFaultFlag) {
		return(0);  /* trigger: go to next DecodeSlice */
	}

	if (bsw->macroblock_type & MACROBLOCK_QUANT)	{
		nQuantizerScaleCode = GetBits(5);

		/* ISO/IEC 13818-2 section 7.4.2.2: Quantizer scale factor */
		bsw->slice_data.nQuantizerScale =
			the->g_lpDecoder->bMPEG2Flag ? (bsw->pic_cod_ext.nQScaleType ? 
			Non_Linear_quantizer_scale[nQuantizerScaleCode] : nQuantizerScaleCode<<1 ) 
			: nQuantizerScaleCode;

		/* SCALABILITY: Data Partitioning */
		if (the->g_lpDecoder->bScalableMode==SC_DP)
			/* make sure the->bsw.slice_data.nQuantizerScale is valid */
			bsw->slice_data.nQuantizerScale = bsw->slice_data.nQuantizerScale;
	}

	/* motion vectors */
	/* ISO/IEC 13818-2 section 6.3.17.2: Motion vectors */

	/* decode forward motion vectors */
	if ((bsw->macroblock_type & MACROBLOCK_MOTION_FORWARD) 
		|| ((bsw->macroblock_type & MACROBLOCK_INTRA) 
		&& bsw->pic_cod_ext.bConcealmentMotionVectors))	{

			if (the->g_lpDecoder->bMPEG2Flag){
				MotionVectors((bsw->PMV),
					(bsw->dmvector),
					(bsw->motion_vertical_field_select),
					0,
					(bsw->motion_vector_count),
					(bsw->mv_format),
					(bsw->pic_cod_ext.nFCode[0][0]-1),
					(bsw->pic_cod_ext.nFCode[0][1]-1),
					(bsw->dmv),
					(bsw->mvscale));
			}
			else{
				motion_vector(
					the,
					bsw->PMV[0][0],
					bsw->dmvector,
					bsw->pic_header.nForwardFCode-1,
					bsw->pic_header.nForwardFCode-1,
					0,
					0,
					bsw->pic_header.nFullPelForwardVector);
			}
	}

	if (the->g_bFaultFlag){
		return(0);  /* trigger: go to next DecodeSlice */
	}

	/* decode backward motion vectors */
	if (bsw->macroblock_type & MACROBLOCK_MOTION_BACKWARD)	{
		if (the->g_lpDecoder->bMPEG2Flag){
			MotionVectors((bsw->PMV),
				(bsw->dmvector),
				(bsw->motion_vertical_field_select),
				1,
				(bsw->motion_vector_count),
				(bsw->mv_format),
				(bsw->pic_cod_ext.nFCode[1][0]-1),
				(bsw->pic_cod_ext.nFCode[1][1]-1),
				0,
				(bsw->mvscale));
		}
		else{
			motion_vector(
				the,
				bsw->PMV[0][1],
				bsw->dmvector,
				bsw->pic_header.nBackwardFCode-1,
				bsw->pic_header.nBackwardFCode-1,
				0,
				0,
				bsw->pic_header.nFullPelBackwardVector);
		}
	}

	if (the->g_bFaultFlag) {
		return(0);  /* trigger: go to next DecodeSlice */
	}

	if ( (bsw->macroblock_type & MACROBLOCK_INTRA) && bsw->pic_cod_ext.bConcealmentMotionVectors) {
		FlushBits(1);  
	}

	/* macroblock_pattern */
	/* ISO/IEC 13818-2 section 6.3.17.4: Coded block pattern */
	if (bsw->macroblock_type & MACROBLOCK_PATTERN)	{

		bsw->nCodedBlockPattern = Get_coded_block_pattern(the);

		if (the->g_lpDecoder->nChromaFormat==CHROMA422){
			/* coded_block_pattern_1 */
			bsw->nCodedBlockPattern = (bsw->nCodedBlockPattern<<2) | GetBits(2); 
		}
		else if (the->g_lpDecoder->nChromaFormat==CHROMA444){
			/* coded_block_pattern_2 */
			bsw->nCodedBlockPattern = (bsw->nCodedBlockPattern<<6) | GetBits(6); 
		}
	}
	else{
		bsw->nCodedBlockPattern = (bsw->macroblock_type & MACROBLOCK_INTRA) ? 
			(1<<the->g_lpDecoder->nBlockCount)-1 : 0;
	}

	if (the->g_bFaultFlag){
		return(0);  /* trigger: go to next DecodeSlice */
	}

	/* decode blocks */
	paddr = pMb = the->pMb;
	pMb += 3*sizeof(u8*);

	*(u16*)pMb = (u16)bsw->macroblock_type; 
	pMb += sizeof(u16);

	*(u16*)pMb = (u16)bsw->dct_type; 
	pMb += sizeof(u16);

	the->pMb += 3*sizeof(u8*) + 2*sizeof(u16);

	if( !(bsw->macroblock_type & MACROBLOCK_INTRA ) ) {
		the->pMb += 4*sizeof(u16) + 8*sizeof(s16) + 4*sizeof(u16) + 4*sizeof(s16);
	}

	pcoeff = the->pMb;
	the->pMb += the->g_lpDecoder->nBlockCount;

	{

		s32 coeff;

		/* SCALABILITY: Data Partitioning */
		for ( comp=0; comp< the->g_lpDecoder->nBlockCount; comp++ )	{

			coeff = 0;

			if ( bsw->nCodedBlockPattern & ( 1 << (the->g_lpDecoder->nBlockCount-1-comp) )  ) {

				if (bsw->macroblock_type & MACROBLOCK_INTRA)	{

					if (the->g_lpDecoder->bMPEG2Flag){
						coeff = mp_get_m2_intra_blk(the,comp,bsw->dc_dct_pred);
					}
					else{
						coeff = Mp_Get_MPEG1_Intra_Block(the,comp,bsw->dc_dct_pred);
					}
				}
				else{

					if ( the->g_lpDecoder->bMPEG2Flag ){
						coeff = mp_get_m2_non_intra_blk(the,comp);
					}
					else{
						coeff = Mp_Get_MPEG1_Non_Intra_Block(the,comp);
					}
				}

				if (the->g_bFaultFlag) {
					return(0);  
				}

			}

			pcoeff[comp] = (u8)coeff;

		} // for ( comp=0; comp< the->g_lpDecoder->nBlockCount; comp++ )	{

	}


	if(bsw->pic_header.nPictureCodingType == D_TYPE)	{
		/* remove end_of_macroblock (always 1, prevents startcode emulation) */
		/* ISO/IEC 11172-2 section 2.4.2.7 and 2.4.3.6 */
		GetBits1();
	}

	/* reset intra_dc predictors */
	/* ISO/IEC 13818-2 section 7.2.1: DC coefficients in intra blocks */
	if (!(bsw->macroblock_type & MACROBLOCK_INTRA)){
		bsw->dc_dct_pred[0] = bsw->dc_dct_pred[1] = bsw->dc_dct_pred[2]=0;
	}

	/* reset motion vector predictors */
	if ((bsw->macroblock_type & MACROBLOCK_INTRA) 
		&& !bsw->pic_cod_ext.bConcealmentMotionVectors)	{
			/* intra mb without concealment motion vectors */
			/* ISO/IEC 13818-2 section 7.6.3.4: Resetting motion vector predictors */
			bsw->PMV[0][0][0]=bsw->PMV[0][0][1]=
				bsw->PMV[1][0][0]=bsw->PMV[1][0][1]=0;
			bsw->PMV[0][1][0]=bsw->PMV[0][1][1]=
				bsw->PMV[1][1][0]=bsw->PMV[1][1][1]=0;
	}

	/* special "No_MC" macroblock_type case */
	/* ISO/IEC 13818-2 section 7.6.3.5: Prediction in P pictures */
	if (  (bsw->pic_header.nPictureCodingType == P_TYPE ) 
		&&  !(bsw->macroblock_type & (MACROBLOCK_MOTION_FORWARD|MACROBLOCK_INTRA)) )	{
			/* non-intra mb without forward mv in a P picture */
			/* ISO/IEC 13818-2 section 7.6.3.4: Resetting motion vector predictors */
			bsw->PMV[0][0][0] = bsw->PMV[0][0][1] =
				bsw->PMV[1][0][0] = bsw->PMV[1][0][1] = 0;

			/* derive motion_type */
			/* ISO/IEC 13818-2 section 6.3.17.1: Macroblock modes, frame_motion_type */
			if (bsw->pic_cod_ext.nPictureStructure == FRAME_PICTURE)
				bsw->motion_type = MC_FRAME;
			else{
				bsw->motion_type = MC_FIELD;
				/* predict from field of same parity */
				bsw->motion_vertical_field_select[0][0] = (bsw->pic_cod_ext.nPictureStructure==BOTTOM_FIELD);
			}
	}

	if (bsw->stwclass==4)	{
		/* purely spatially predicted macroblock */
		/* ISO/IEC 13818-2 section 7.7.5.1: Resetting motion vector predictions */
		bsw->PMV[0][0][0]=bsw->PMV[0][0][1]=
			bsw->PMV[1][0][0]=bsw->PMV[1][0][1]=0;
		bsw->PMV[0][1][0]=bsw->PMV[0][1][1]=
			bsw->PMV[1][1][0]=bsw->PMV[1][1][1]=0;
	}

	// encode macroblock info;
	for( i = 0; i < 3; i ++ ) {
		*(u8**)paddr = bsw->lpYuvAddr[YUV_ADDR_OUTPUT][i];
		paddr += sizeof(u8*);
	}

	if( !(bsw->macroblock_type & MACROBLOCK_INTRA) ){

		*(u16*)pMb = (u16)bsw->motion_type;
		pMb += sizeof(u16);

		*(u16*)pMb = (u16)bsw->stwtype;
		pMb += sizeof(u16);

		*(u16*)pMb = (u16)bsw->dwMbPosX;
		pMb += sizeof(u16);

		*(u16*)pMb = (u16)bsw->dwMbPosY;
		pMb += sizeof(u16);


		for( i = 0; i < 2; i ++ ) {
			for( j = 0; j < 2; j ++ ) {
				for( k = 0; k < 2; k ++ ) {
					*(s16*)pMb = (s16)bsw->PMV[i][j][k];
					pMb += sizeof(s16);
				}
			}
		}

		for( i = 0; i < 2; i ++ ) {
			for( j = 0; j < 2; j ++ ) {
				*(u16*)pMb = (u16)bsw->motion_vertical_field_select[i][j];
				pMb += sizeof(u16);
			}
		}

		for( i = 0; i < 4; i ++ ) {
			*(s16*)pMb = (s16)bsw->dmvector[i];
			pMb += sizeof(s16);
		}

	} // if( !(bsw->macroblock_type & MACROBLOCK_INTRA) ){

	the->pMb = (u8*)( ((size_t)the->pMb + 7 ) & ~7 );

	/* successfully decoded macroblock */
	return(1);
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
s32 Mp_Decode_MacroBlock(frame_decoder* the,u8* pMb)
{

	u8*			p;
	s32			i,j,k;
	u8			coeff[12];

	s32 const	nb = the->g_lpDecoder->nBlockCount;
	mc_decoder* const mc = the->g_lpMcDecoder;

	p = pMb;

	for( i = 0; i < 3; i ++ ) {
		the->bsw.lpYuvAddr[YUV_ADDR_OUTPUT][i] = *(u8**)pMb;
		pMb += sizeof(u8*);
	}

	mc->macroblock_type = *(u16*)pMb;
	pMb += sizeof(u16);

	mc->dct_type = *(u16*)pMb;
	pMb += sizeof(u16);


	if( !(mc->macroblock_type & MACROBLOCK_INTRA) ){

		mc->motion_type = *(u16*)pMb;
		pMb += sizeof(u16);

		mc->stwtype = *(u16*)pMb;
		pMb += sizeof(u16);

		mc->dwMbPosX = *(u16*)pMb;
		pMb += sizeof(u16);

		mc->dwMbPosY = *(u16*)pMb;
		pMb += sizeof(u16);

		//stx_assert( mc->dwMbPosX < 2048);
		//stx_assert( mc->dwMbPosY < 2048);

		for( i = 0; i < 2; i ++ ) {
			for( j = 0; j < 2; j ++ ) {
				for( k = 0; k < 2; k ++ ) {
					mc->PMV[i][j][k] = *(s16*)pMb;
					pMb += sizeof(s16);
				}
			}
		}

		for( i = 0; i < 2; i ++ ) {
			for( j = 0; j < 2; j ++ ) {
				mc->motion_vertical_field_select[i][j] = *(u16*)pMb;
				pMb += sizeof(u16);
			}
		}

		for( i = 0; i < 4; i ++ ) {
			mc->dmvector[i] = *(s16*)pMb;
			pMb += sizeof(s16);
		}
	}

	// clear block;
	ClearBlock(the->bsw.Macro_Block.coeff[0], nb );

	if( !(mc->macroblock_type & MACROBLOCK_SKIPPED) ) { // not skipped;

		memcpy(coeff,pMb,nb);
		pMb += nb;

		for( i = 0; i < nb; i ++ ) {
			if( coeff[i] ) {
				if( mc->macroblock_type & MACROBLOCK_INTRA ) {
					Mp_Decode_Intra_Block(the,i,coeff[i],pMb);
				}
				else{
					Mp_Decode_Non_Intra_Block(the,i,coeff[i],pMb);
				}
				pMb += (coeff[i]<<1)+coeff[i];
			}
		}
	}

	if( ! (mc->macroblock_type & MACROBLOCK_INTRA) ) {
		// do motion predictions;
		mc->m_bPref = FALSE;
		mc->bSkipBot = FALSE;
		rec_mb(mc);
	}

	// output directly;
	cpy_mb(the,the->g_lpDecoder->nOutputPit); 

	return ( (s32)(pMb - p) + 7 ) & ~7;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
s32 Mp_DecodeSlice(frame_decoder* the,s32* i_mb)
{
	BitsWindow* const bsw = the->pbsw;


	s32		ret;
	b32		bDecode;

	if( bsw->bNewSliceFlag )	{
		bsw->MBAinc = 0;
		ret = StartOfSlice(the);
		if( 1 != ret ){
			return(ret);
		}
		the->g_bFaultFlag = 0;
		bsw->bNewSliceFlag = FALSE;			
	}

	/* this is how we properly exit out of picture */
	if ( bsw->MBA >= the->g_lpDecoder->nMBAmax ){
		return(-1); 
	}

	/* all macroblocks decoded */

	if ( bsw->MBAinc == 0 ){
		if (!ShowBits(23) || the->g_bFaultFlag) {/* next_start_code or fault */
			//resync: /* if the->g_bFaultFlag: resynchronize to next next_start_code */
			//			g_nLastDecodeTime = timeGetTime();
			the->g_bFaultFlag = 0;
			bsw->bNewSliceFlag = TRUE;			
			return(0);     /* trigger: go to next DecodeSlice */
		}
		else{ /* neither next_start_code nor the->g_bFaultFlag */
			/* decode macroblock address increment */
			bsw->MBAinc = Get_macroblock_address_increment(the);

			if (the->g_bFaultFlag) {
				the->g_bFaultFlag = 0;
				bsw->bNewSliceFlag = TRUE;	
				return the->g_bSecondSlice ? -1 : 0;
			}
		}
	}

	if ( bsw->MBA >= the->g_lpDecoder->nMBAmax ){
		return(-1);
	}

	if ( bsw->MBAinc == 1 ){ /* not skipped */

		/* statistic the maroblock luma and chroma*/
		ret = Mp_GetMacroBlock(the);

		if( ret == -1 ) {
			return(-1);
		}

		if( ret == 0 ) {
			the->g_bFaultFlag = 0;
			bsw->bNewSliceFlag = TRUE;	
			return the->g_bSecondSlice ? -1 : 0;
		}
	}
	else{ /* Macro_Block.Macro_Block.MBAinc!=1: skipped macroblock */
		/* ISO/IEC 13818-2 section 7.6.6 */
		SkippedMacroblock(the);
		Mp_SkipMacroblock(the);
	}

	(*i_mb)++;

	/* SCALABILITY: SNR */
	/* ISO/IEC 13818-2 section 7.8 */
	/* NOTE: we currently ignore faults encountered in this routine */
	/* ISO/IEC 13818-2 section 7.6 */

	// get mb pos intra pred;
	GetMbPos(the);

	/* advance to next macroblock */
	bsw->MBA ++;
	bsw->MBAinc --;

	if ( bsw->MBA >= the->g_lpDecoder->nMBAmax) {
		return(-1); /* all macroblocks decoded */
	}

	return 1;
}



STX_RESULT Mp_DecodeFrame(frame_decoder* the, s32 i_flag, s32 nUpGradeMb )
{
	s32					ret;
	BitsWindow* const	bsw = &the->h_vdec->vdat.bsw;

	the->pbsw = bsw;

	if( FLAG_DEC_FRM_INIT == i_flag ) {
		the->g_nCurSlice = 0;
		UpdatePredPicture(
			the->g_lpMcDecoder,
			the->pCurrentPicture->lpBackwardPicture,
			the->pCurrentPicture->lpForwardPicture,
			the->g_lpDecoder->nOutputPit, 
			the->g_lpDecoder->bSecondField,
			bsw->pic_header.nPictureCodingType,
			bsw->pic_cod_ext.bTopFieldFirst,
			bsw->pic_cod_ext.nPictureStructure);
		//	ASSERT(0);
		return STX_OK;
	} // if( FLAG_DEC_FRM_INIT == i_flag ) {


	for( ; ; )	{

		STX_RESULT	i_err;
		s32			i,i_mb,*p_mb;
		u64			rdtsc;

		if( the->b_main ) {

			i_err = get_free_slice(the->h_vdec,the,&the->pSlice);

			if( STX_EOF == i_err ) {
				return STX_OK;
			}

			if( STX_OK == i_err ) {

				rdtsc = get_rdtsc();

				the->pMb = the->pSlice + 16;

				p_mb = (s32*) (the->pSlice + 8);
				*p_mb = 0;

				for( ; ; ) {

					the->g_bSecondSlice = FALSE;

					ret = Mp_DecodeSlice(the,p_mb);

					if( ret == -1 )	{ // error, abort decode;
						//xlog("bsw->dwMbPosY :%d \r\n",bsw->dwMbPosY);

						*(STX_RESULT*)the->pSlice = STX_EOF;
						add_data_slice(the->h_vdec,the,the->pSlice);
						rdtsc = get_rdtsc() - rdtsc;
						the->rdtsca += rdtsc;
						the->counta ++;
						break;
					}
					else if( ret == 0 ) { // goto new slice;
						//xlog("bsw->dwMbPosY :%d \r\n",bsw->dwMbPosY);
						if( *p_mb > 0 ) {
							*(STX_RESULT*)the->pSlice = STX_OK;
							add_data_slice(the->h_vdec,the,the->pSlice);
							rdtsc = get_rdtsc() - rdtsc;
							the->rdtsca += rdtsc;
							the->counta ++;
							break;
						}
						else{
							the->pMb = the->pSlice + 16;
							rdtsc = get_rdtsc();
							continue;
						}
					}

					if( bsw->dwMbPosX == 0 ) {

						STX_RESULT i_end;

						//xlog("bsw->dwMbPosY :%d \r\n",bsw->dwMbPosY);

						if( bsw->dwMbPosY == the->g_lpDecoder->nCodedPictureHeight 
							|| ( the->h_vdec->bUpGrade && bsw->MBA == nUpGradeMb) ) {

								i_end = STX_EOF;
						}
						else {
							i_end = STX_OK;
						}

						*(STX_RESULT*)the->pSlice = i_end;
						add_data_slice(the->h_vdec,the,the->pSlice);
						rdtsc = get_rdtsc() - rdtsc;
						the->rdtsca += rdtsc;
						the->counta ++;
						if( i_end == STX_EOF ) {
							//stx_log("a task return (add_data_slice)\r\n");
							return STX_OK;
						}
						break;
					}

				} // for( ; ; ) {

				continue; 

			} // if( STX_OK == i_err ) {

		} // if( the->b_main ) {


		i_err = get_data_slice(the->h_vdec,the,&the->pSlice);

		if( STX_OK == i_err ) {

			STX_RESULT i_end = *(STX_RESULT*)the->pSlice;

			if( STX_FAIL == i_end ) {
				add_free_slice(the->h_vdec,the,the->pSlice);
				//stx_log("b task %X return frame:STX_FAIL \r\n",the);
				return STX_OK;
			}

			i_mb = *(s32*)(the->pSlice + 8);
			//xlog("slice mb = %d \r\n",i_mb );
			the->pMb = the->pSlice + 16;

			rdtsc = get_rdtsc();
			for( i = 0; i < i_mb; i ++ ) {
				s32 j = Mp_Decode_MacroBlock(the,the->pMb);
				the->pMb += j;
			}
			rdtsc = get_rdtsc() - rdtsc;
			the->rdtscb += rdtsc;
			the->countb ++;

			add_free_slice(the->h_vdec,the,the->pSlice);

			if( STX_EOF == i_end ){
				//stx_log("b task %X return frame:STX_EOF\r\n",the);
				return STX_OK;
			}

			continue;

		} // if( STX_OK == i_err ) {

		if( STX_BOF == i_err ){
			continue;
		}

		if( STX_EOF == i_err ){
			//stx_log("b task %X return STX_EOF\r\n",the);
			return STX_OK;
		}

		return i_err;

	} // for(;;)

	return STX_OK;
}






/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
decode one intra coded MPEG-2 block
***************************************************************************/
void Decode_MPEG2_Intra_Block_C(frame_decoder* the,s32 comp,s32 dc_dct_pred[])
{
	BitsWindow* const bsw = the->pbsw;

	s32			val, i;
	s32			j;
	s32			val_sign,  cc, run;
	u32			code;
	DCTtab      *tab;
	s16			*lpblk;

	u32			dwMsk;
	LxIdctInf	inf;

	u16 (*qmat)[128][64];

	qmat = ( comp<4 || the->g_lpDecoder->nChromaFormat == CHROMA420 )
		? &the->g_lpDecoder->nIntraQuantizerMatrixTable
		: &the->g_lpDecoder->nChromaIntraQuantizerMatrixTable;

	cc = (comp<4) ? 0 : (comp&1)+1;

	/* ISO/IEC 13818-2 section 7.2.1: decode DC coefficients */
	if (cc==0)
		val = (dc_dct_pred[0] += Get_Luma_DC_dct_diff(the));
	else if (cc==1)
		val = (dc_dct_pred[1] += Get_ChromaDC_dct_diff(the));
	else
		val = (dc_dct_pred[2] += Get_ChromaDC_dct_diff(the));

	if (the->g_bFaultFlag) {
		return;
	}

	lpblk = bsw->Macro_Block.coeff[comp];

	lpblk[0] = val << (3 - bsw->pic_cod_ext.nIntraDcPrecision );


	INIT_MEMBER(inf);

	dwMsk = g_dwBlockInf[0];

#ifdef DCT_COE_STATISTIC
	inf.dwNzInf     += SET_NZ_INF(dwMsk);
#endif

	inf.dwColMask   |= SET_NZ_MASK(dwMsk);
	inf.byRowPos[0] |= SET_NZ_MASK(dwMsk);

	{
		u32		CodeIdx;
		DCTtab	(*ppt)[16];

		const b32 bVlcIntra = bsw->pic_cod_ext.nIntraVlcFormat > 0;
		const u8* g_byCode1 = g_byM2IntraCode1[bVlcIntra];
		const PPDCTtab *g_M2Tab  = g_M2IntraTab[bVlcIntra];

		/* decode AC coefficients */
		for (i=1; ; i++)
		{
			code = ShowBits(16);

			if( code < 16 ) {
				the->g_bFaultFlag = TRUE;
				return;
			}
			CodeIdx = code < 256 ? g_byM2Code0[code] : g_byCode1[code>>8];
			ppt = g_M2Tab[CodeIdx];
			tab = &( (*ppt)[ ( code >> CodeIdx ) - g_byM2NonIntraSub[CodeIdx] ] );

			FlushBits(tab->len); 

			if ( tab->run == 64 ) /* end_of_block */ {
				break;
			}

			if (tab->run==65) /* escape */	{
				val = GetBits18();
				i+= run = val>>12;
				val &= 0xfff;			
				if ((val&2047)==0)	{
					the->g_bFaultFlag = 1;
					return;
				}			
				if (val_sign = (val>=2048)) {
					val = 4096 - val;
				}
			}
			else{
				i+= run = tab->run;
				val = tab->nLevel;
				val_sign = GetBits1();
			}		

			if (i>=64){
				the->g_bFaultFlag = 1;
				return;
			}		

			j = scan[bsw->pic_cod_ext.bAlternateScan][i];

			dwMsk = g_dwBlockInf[j];

#ifdef DCT_COE_STATISTIC
			inf.dwNzInf     += SET_NZ_INF(dwMsk);
#endif
			inf.dwColMask   |= SET_NZ_MASK(dwMsk);
			inf.byRowPos[j>>3] |= SET_NZ_MASK(dwMsk);

			val = ( val * (*qmat)[bsw->slice_data.nQuantizerScale][j] ) >> 4;
			lpblk[j] = val_sign ? -val : val;
		}

#ifdef DCT_COE_STATISTIC
		dct_coe_statistic(TRUE,&inf);
#endif

		//	g_IdctFunc[nc==1][row_pos[8]==0](lpblk,row_pos);
		fast_idct(lpblk,&inf);

		adder_128(lpblk,
			the->bsw.sparse_info[bsw->dct_type][comp].dst,
			the->bsw.sparse_info[bsw->dct_type][comp].lx);

	}


}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void Decode_MPEG2_Non_Intra_Block_C(frame_decoder* the,s32 comp)
{
	BitsWindow* const bsw = the->pbsw;


	s32				val, i,val_sign, run;
	u32				code;
	s16*			lpblk;

	s32				j;
	u16				(*qmat)[128][64];

	u32				CodeIdx;
	DCTtab			(*ppt)[16];
	DCTtab*			tab;

	u32				dwMsk;

	LxIdctInf inf = {0};

	qmat = ( comp<4 || the->g_lpDecoder->nChromaFormat == CHROMA420 )
		? &the->g_lpDecoder->nNonIntraQuantizerMatrixTable
		: &the->g_lpDecoder->nChromaNonIntraQuantizerMatrixTable;

	lpblk = bsw->Macro_Block.coeff[comp];

	/* decode AC coefficients */
	for (i=0; ; i++)	{

		code = ShowBits(16);
		if( code < 16 ) {
			the->g_bFaultFlag = 1;
			return;
		}
		
		CodeIdx = code < 256 ? g_byM2Code0[code] : g_byM2Code1[code>>8];
		ppt = g_M2NonIntraTab[i>0][CodeIdx];
		tab = &( (*ppt)[ ( code >> CodeIdx ) - g_byM2NonIntraSub[CodeIdx] ] );

		FlushBits(tab->len);

		if (tab->run==64) /* end_of_block */{
			break;
		}

		if (tab->run==65) /* escape */	{
			val = GetBits18();
			i+= run = val >> 12;
			val &= 0xfff;

			if ((val&2047)==0)	{
				the->g_bFaultFlag = 1;
				return;
			}

			if (val_sign = (val>=2048)){
				val = 4096 - val;
			}
		}
		else{
			i+= run = tab->run;
			val = tab->nLevel;
			val_sign = GetBits1();
		}

		if ( i >= 64 )	{
			the->g_bFaultFlag = 1;
			return;
		}

		j = scan[bsw->pic_cod_ext.bAlternateScan][i];

		dwMsk = g_dwBlockInf[j];

#ifdef DCT_COE_STATISTIC
		inf.dwNzInf     += SET_NZ_INF(dwMsk);
#endif
		inf.dwColMask   |= SET_NZ_MASK(dwMsk);
		inf.byRowPos[j>>3] |= SET_NZ_MASK(dwMsk);

		val = (((val<<1)+1) * (*qmat)[bsw->slice_data.nQuantizerScale][j]) >> 5;
		lpblk[j] = val_sign ? -val : val;
	}

#ifdef DCT_COE_STATISTIC
	dct_coe_statistic(FALSE,&inf);
#endif

	fast_idct(lpblk,&inf);
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
decode one non-intra coded MPEG-2 block
ISO/IEC 13818-2 sections 7.2 through 7.5
***************************************************************************/
s32  DecodeMacroblock(frame_decoder* the,b32 bDecode)
{
	BitsWindow* const bsw = the->pbsw;

	/* locals */
	s32 nQuantizerScaleCode; 
	s32 comp;

	/* ISO/IEC 13818-2 section 6.3.17.1: Macro-block modes 
	macroblock_modes(macroblock_type, stwtype, stwclass,
	motion_type, &motion_vector_count, &mv_format, &dmv, &mvscale,
	dct_type);*/

	macroblock_modes(the);

	if (the->g_bFaultFlag) {
		return(0);  /* trigger: go to next DecodeSlice */
	}

	if (bsw->macroblock_type & MACROBLOCK_QUANT)	{
		nQuantizerScaleCode = GetBits(5);

		/* ISO/IEC 13818-2 section 7.4.2.2: Quantizer scale factor */
		bsw->slice_data.nQuantizerScale =
			the->g_lpDecoder->bMPEG2Flag ? (bsw->pic_cod_ext.nQScaleType ? 
			Non_Linear_quantizer_scale[nQuantizerScaleCode] : nQuantizerScaleCode<<1 ) 
			: nQuantizerScaleCode;

		/* SCALABILITY: Data Partitioning */
		if (the->g_lpDecoder->bScalableMode==SC_DP)
			/* make sure the->bsw.slice_data.nQuantizerScale is valid */
			bsw->slice_data.nQuantizerScale = bsw->slice_data.nQuantizerScale;
	}

	/* motion vectors */
	/* ISO/IEC 13818-2 section 6.3.17.2: Motion vectors */

	/* decode forward motion vectors */
	if ((bsw->macroblock_type & MACROBLOCK_MOTION_FORWARD) 
		|| ((bsw->macroblock_type & MACROBLOCK_INTRA) 
		&& bsw->pic_cod_ext.bConcealmentMotionVectors))	{

			if (the->g_lpDecoder->bMPEG2Flag){
				MotionVectors((bsw->PMV),
					(bsw->dmvector),
					(bsw->motion_vertical_field_select),
					0,
					(bsw->motion_vector_count),
					(bsw->mv_format),
					(bsw->pic_cod_ext.nFCode[0][0]-1),
					(bsw->pic_cod_ext.nFCode[0][1]-1),
					(bsw->dmv),
					(bsw->mvscale));
			}
			else{
				motion_vector(
					the,
					bsw->PMV[0][0],
					bsw->dmvector,
					bsw->pic_header.nForwardFCode-1,
					bsw->pic_header.nForwardFCode-1,
					0,
					0,
					bsw->pic_header.nFullPelForwardVector);
			}
	}

	if (the->g_bFaultFlag){
		return(0);  /* trigger: go to next DecodeSlice */
	}

	/* decode backward motion vectors */
	if (bsw->macroblock_type & MACROBLOCK_MOTION_BACKWARD)	{
		if (the->g_lpDecoder->bMPEG2Flag){
			MotionVectors((bsw->PMV),
				(bsw->dmvector),
				(bsw->motion_vertical_field_select),
				1,
				(bsw->motion_vector_count),
				(bsw->mv_format),
				(bsw->pic_cod_ext.nFCode[1][0]-1),
				(bsw->pic_cod_ext.nFCode[1][1]-1),
				0,
				(bsw->mvscale));
		}
		else{
			motion_vector(
				the,
				bsw->PMV[0][1],
				bsw->dmvector,
				bsw->pic_header.nBackwardFCode-1,
				bsw->pic_header.nBackwardFCode-1,
				0,
				0,
				bsw->pic_header.nFullPelBackwardVector);
		}
	}

	if (the->g_bFaultFlag) {
		return(0);  /* trigger: go to next DecodeSlice */
	}

	if ( (bsw->macroblock_type & MACROBLOCK_INTRA) 
		&& bsw->pic_cod_ext.bConcealmentMotionVectors) {
			FlushBits(1);  
	}

	/* macroblock_pattern */
	/* ISO/IEC 13818-2 section 6.3.17.4: Coded block pattern */
	if (bsw->macroblock_type & MACROBLOCK_PATTERN)	{
		bsw->nCodedBlockPattern = Get_coded_block_pattern(the);

		if (the->g_lpDecoder->nChromaFormat==CHROMA422){
			/* coded_block_pattern_1 */
			bsw->nCodedBlockPattern = (bsw->nCodedBlockPattern<<2) | GetBits(2); 
		}
		else if (the->g_lpDecoder->nChromaFormat==CHROMA444){
			/* coded_block_pattern_2 */
			bsw->nCodedBlockPattern = (bsw->nCodedBlockPattern<<6) | GetBits(6); 
		}
	}
	else{
		bsw->nCodedBlockPattern = (bsw->macroblock_type & MACROBLOCK_INTRA) ? 
			(1<<the->g_lpDecoder->nBlockCount)-1 : 0;
	}

	if (the->g_bFaultFlag){
		return(0);  /* trigger: go to next DecodeSlice */
	}

	/* decode blocks */

	if( bDecode ){

		/* SCALABILITY: Data Partitioning */
		for ( comp=0; comp< the->g_lpDecoder->nBlockCount; comp++ )	{

			if ( bsw->nCodedBlockPattern & ( 1 << (the->g_lpDecoder->nBlockCount-1-comp) )  )		{

				if (bsw->macroblock_type & MACROBLOCK_INTRA)	{

					if (the->g_lpDecoder->bMPEG2Flag){
						decode_m2_intra_blk(the,comp,bsw->dc_dct_pred);
					}
					else{
						Decode_MPEG1_Intra_Block(the,comp,bsw->dc_dct_pred);
					}
				}
				else{

					if ( the->g_lpDecoder->bMPEG2Flag ){
						decode_m2_non_intra_blk(the,comp);
					}
					else{
						Decode_MPEG1_Non_Intra_Block(the,comp);
					}
				}

				if (the->g_bFaultFlag) {
					return(0);  
				}
			}
		}
	}
	else{
		/* SCALABILITY: Data Partitioning */
		for ( comp=0; comp< the->g_lpDecoder->nBlockCount; comp++ )	{

			if ( bsw->nCodedBlockPattern & ( 1 << (the->g_lpDecoder->nBlockCount-1-comp) )  )		{

				if (bsw->macroblock_type & MACROBLOCK_INTRA)	{

					if (the->g_lpDecoder->bMPEG2Flag){
						Sparse_MPEG2_Intra_Block(the,comp,bsw->dc_dct_pred);
					}
					else{
						Sparse_MPEG1_Intra_Block(the,comp,bsw->dc_dct_pred);
					}
				}
				else{

					if ( the->g_lpDecoder->bMPEG2Flag ){
						Sparse_MPEG2_Non_Intra_Block(the,comp);
					}
					else{
						Sparse_MPEG1_Non_Intra_Block(the,comp);
					}
				}

				if (the->g_bFaultFlag) {
					return(0);  
				}
			}
		}
	}

	if(bsw->pic_header.nPictureCodingType == D_TYPE)	{
		/* remove end_of_macroblock (always 1, prevents startcode emulation) */
		/* ISO/IEC 11172-2 section 2.4.2.7 and 2.4.3.6 */
		GetBits1();
	}

	/* reset intra_dc predictors */
	/* ISO/IEC 13818-2 section 7.2.1: DC coefficients in intra blocks */
	if (!(bsw->macroblock_type & MACROBLOCK_INTRA))
		bsw->dc_dct_pred[0] = bsw->dc_dct_pred[1] = bsw->dc_dct_pred[2]=0;

	/* reset motion vector predictors */
	if ((bsw->macroblock_type & MACROBLOCK_INTRA) 
		&& !bsw->pic_cod_ext.bConcealmentMotionVectors)	{
			/* intra mb without concealment motion vectors */
			/* ISO/IEC 13818-2 section 7.6.3.4: Resetting motion vector predictors */
			bsw->PMV[0][0][0]=bsw->PMV[0][0][1]=
				bsw->PMV[1][0][0]=bsw->PMV[1][0][1]=0;
			bsw->PMV[0][1][0]=bsw->PMV[0][1][1]=
				bsw->PMV[1][1][0]=bsw->PMV[1][1][1]=0;
	}

	/* special "No_MC" macroblock_type case */
	/* ISO/IEC 13818-2 section 7.6.3.5: Prediction in P pictures */
	if (  (bsw->pic_header.nPictureCodingType == P_TYPE ) 
		&&  !(bsw->macroblock_type & (MACROBLOCK_MOTION_FORWARD|MACROBLOCK_INTRA)) )	{
			/* non-intra mb without forward mv in a P picture */
			/* ISO/IEC 13818-2 section 7.6.3.4: Resetting motion vector predictors */
			bsw->PMV[0][0][0] = bsw->PMV[0][0][1] =
				bsw->PMV[1][0][0] = bsw->PMV[1][0][1] = 0;

			/* derive motion_type */
			/* ISO/IEC 13818-2 section 6.3.17.1: Macroblock modes, frame_motion_type */
			if (bsw->pic_cod_ext.nPictureStructure == FRAME_PICTURE)
				bsw->motion_type = MC_FRAME;
			else{
				bsw->motion_type = MC_FIELD;
				/* predict from field of same parity */
				bsw->motion_vertical_field_select[0][0] = (bsw->pic_cod_ext.nPictureStructure==BOTTOM_FIELD);
			}
	}

	if (bsw->stwclass==4)	{
		/* purely spatially predicted macroblock */
		/* ISO/IEC 13818-2 section 7.7.5.1: Resetting motion vector predictions */
		bsw->PMV[0][0][0]=bsw->PMV[0][0][1]=
			bsw->PMV[1][0][0]=bsw->PMV[1][0][1]=0;
		bsw->PMV[0][1][0]=bsw->PMV[0][1][1]=
			bsw->PMV[1][1][0]=bsw->PMV[1][1][1]=0;
	}
	/* successfully decoded macroblock */
	return(1);

} /* DecodeMacroblock */



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
decode all macroblocks of the current picture
ISO/IEC 13818-2 section 6.3.16 
***************************************************************************/
s32 DecodeSlice(frame_decoder* the)
{
	BitsWindow* const bsw = the->pbsw;

	s32		ret,imb;
	b32		bDecode;

	//	ASSERT(0);

	if( bsw->bNewSliceFlag )	{
		bsw->MBAinc = 0;
		ret = StartOfSlice(the);
		if( 1 != ret ){
			return(ret);
		}
		the->g_bFaultFlag = 0;
		bsw->bNewSliceFlag = FALSE;			
	}

	/* this is how we properly exit out of picture */
	if ( bsw->MBA >= the->g_lpDecoder->nMBAmax ){
		return(-1); 
	}

	if( !the->g_bSliceFlag && bsw->MBA > the->g_nEndMb ){
		return(-1); 
	}
	/* all macroblocks decoded */

	if ( bsw->MBAinc == 0 ){
		if (!ShowBits(23) || the->g_bFaultFlag) {/* next_start_code or fault */
			//resync: /* if the->g_bFaultFlag: resynchronize to next next_start_code */
			//			g_nLastDecodeTime = timeGetTime();
			the->g_bFaultFlag = 0;
			bsw->bNewSliceFlag = TRUE;			
			return(0);     /* trigger: go to next DecodeSlice */
		}
		else{ /* neither next_start_code nor the->g_bFaultFlag */
			/* decode macroblock address increment */
			bsw->MBAinc = Get_macroblock_address_increment(the);

			if (the->g_bFaultFlag) {
				the->g_bFaultFlag = 0;
				bsw->bNewSliceFlag = TRUE;			
				return the->g_bSecondSlice ? -1 : 0;
			}
		}
	}

	if ( bsw->MBA >= the->g_lpDecoder->nMBAmax ){
		return(-1);
	}

	bDecode =  the->g_bSliceFlag  || ( bsw->MBA >= the->g_nStartMb && bsw->MBA < the->g_nEndMb );

	if( bDecode ){
		ClearBlock(bsw->Macro_Block.coeff[0], the->g_lpDecoder->nBlockCount );
	}

	if ( bsw->MBAinc == 1 ){ /* not skipped */

		/* statistic the maroblock luma and chroma*/

		ret = DecodeMacroblock(the,bDecode);

		if( ret == -1 ) {
			return(-1);
		}

		if( ret == 0 ) {
			the->g_bFaultFlag = 0;
			bsw->bNewSliceFlag = TRUE;			
			return the->g_bSecondSlice ? -1 : 0;
		}
	}
	else { /* Macro_Block.Macro_Block.MBAinc!=1: skipped macroblock */
		/* ISO/IEC 13818-2 section 7.6.6 */
		SkippedMacroblock(the);
	}

	/* SCALABILITY: SNR */
	/* ISO/IEC 13818-2 section 7.8 */
	/* NOTE: we currently ignore faults encountered in this routine */
	/* ISO/IEC 13818-2 section 7.6 */

	if( bDecode ){
		if( ! (bsw->macroblock_type & MACROBLOCK_INTRA) ) {
			// do motion predictions;
			mc_decoder* const mc = the->g_lpMcDecoder;

			mc->m_bPref = FALSE;
			mc->bSkipBot = FALSE;
			mc->macroblock_type = bsw->macroblock_type;
			mc->motion_type = bsw->motion_type;
			mc->dct_type = bsw->dct_type;
			mc->stwtype = bsw->stwtype;
			mc->dwMbPosX = bsw->dwMbPosX;
			mc->dwMbPosY = bsw->dwMbPosY;
			memcpy(mc->PMV,bsw->PMV,sizeof(bsw->PMV));
			memcpy(mc->motion_vertical_field_select,bsw->motion_vertical_field_select,sizeof(bsw->motion_vertical_field_select));
			memcpy(mc->dmvector,bsw->dmvector,sizeof(bsw->dmvector));
			rec_mb(mc);
		}

		// output directly;
		cpy_mb(the,the->g_lpDecoder->nOutputPit); 
	}

	// get mb pos intra pred;
	GetMbPos(the);

	/* advance to next macroblock */
	bsw->MBA ++;
	bsw->MBAinc --;

	if( !the->g_bSliceFlag && bsw->MBA > the->g_nEndMb ){
		return(-1); 
	}

	if ( bsw->MBA >= the->g_lpDecoder->nMBAmax) {
		return(-1); /* all macroblocks decoded */
	}

	return 1;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT mpeg2_decode_frame(frame_decoder* the, s32 i_flag, s32 nUpGradeMb )
{
	s32					ret;
	BitsWindow* const	bsw = &the->bsw;

	the->pbsw = bsw;

	if( FLAG_DEC_FRM_INIT == i_flag ) {

		the->g_nCurSlice = 0;

		//	TRACE1("header of frame: pgc = %X\t",vdr.pPGC);
		//	TRACE1("dwCell = %d\t",vdr.dwCell);
		//	TRACE1("dwVobuLBN = %d\t",vdr.dwVobuLBN);
		//	TRACE1("packet = %d\n",vdr.NumberStreamPacket);

		UpdatePredPicture(
			the->g_lpMcDecoder,
			the->pCurrentPicture->lpBackwardPicture,
			the->pCurrentPicture->lpForwardPicture,
			the->g_lpDecoder->nOutputPit, 
			the->g_lpDecoder->bSecondField,
			bsw->pic_header.nPictureCodingType,
			bsw->pic_cod_ext.bTopFieldFirst,
			bsw->pic_cod_ext.nPictureStructure  );

		//	ASSERT(0);

		if( the->g_bSliceFlag && the->g_nCurSlice < the->g_nStartMb ){

			for(;;){

				u32 code;

				if( bsw->bs.nTotalBytes <= 0 ) {
					return STX_OK;
				}

				code = ShowBits(32);
				if( code >= SLICE_START_CODE_MIN && code <= SLICE_START_CODE_MAX ){
					the->g_nCurSlice ++;
					if( the->g_nCurSlice >= the->g_nStartMb){
						break;
					}
				}
				FlushBits(8);
			}
		}

		return STX_OK;

	} // if( FLAG_DEC_FRM_INIT == i_flag ) {
	else if( FLAG_DEC_FRM_NORMAL == i_flag || FLAG_DEC_FRM_BOT == i_flag ) {

		for( ; ; )	{

			the->g_bSecondSlice = FALSE;
			ret = DecodeSlice(the);
			if( ret == -1 )	{
				return STX_OK;
			}

			if( the->g_bSliceFlag && ret == 0 ) {
				the->g_nCurSlice ++;
				if( the->g_nCurSlice > the->g_nEndMb ){
					return STX_OK;
				}
			}

		} // for(;;)

		return STX_OK;

	} // else if( FLAG_DEC_FRM_NORMAL == i_flag ) {
	else if( FLAG_DEC_FRM_TOP == i_flag ) {

		for( ; ; )	{

			if( bsw->MBA == nUpGradeMb ) {
				return STX_DELIVER;
			}

			the->g_bSecondSlice = FALSE;
			ret = DecodeSlice(the);
			if( ret == -1 )	{
				return STX_OK;
			}

			if( the->g_bSliceFlag && ret == 0 ) {
				the->g_nCurSlice ++;
				if( the->g_nCurSlice > the->g_nEndMb ){
					return STX_OK;
				}
			} // if( the->g_bSliceFlag && ret == 0 ) {

		} // for(;;)

		return STX_OK;

	} // else if( FLAG_DEC_FRM_TOP == i_flag ) {


	return STX_ERR_INVALID_PARAM;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE void cpy_mb_c(frame_decoder* the,s32 nOutputPit)
{
	u8* src;
	u8* dst;
	s32 i;

	src = (u8*)the->bsw.reccoe.coey;
	dst = (u8*)the->bsw.lpYuvAddr[0][0];

	for( i = 0; i < 16; i ++ ) {

		((u32*)dst)[0]= ((u32*)src)[0];
		((u32*)dst)[1]= ((u32*)src)[1];
		((u32*)dst)[2]= ((u32*)src)[2];
		((u32*)dst)[3]= ((u32*)src)[3];

		src += 16;
		dst += nOutputPit;
	}

	dst = (u8*)the->bsw.lpYuvAddr[0][1];
	nOutputPit >>= 1;

	for( i = 0; i < 8; i ++ ) {

		((u32*)dst)[0]= ((u32*)src)[0];
		((u32*)dst)[1]= ((u32*)src)[1];
		src += 8;
		dst += nOutputPit;
	}

	dst = (u8*)the->bsw.lpYuvAddr[0][2];

	for( i = 0; i < 8; i ++ ) {

		((u32*)dst)[0]= ((u32*)src)[0];
		((u32*)dst)[1]= ((u32*)src)[1];
		src += 8;
		dst += nOutputPit;
	}

}

#ifndef STX64

#define cpy_y_mmx(pit) \
	imm0 = *CONV_PM64(src);		\
	imm1 = *CONV_PM64(src+8);	\
	*CONV_PM64(dst) = imm0;		\
	*CONV_PM64(dst+8) = imm1;	\
	dst += pit;					\
	imm0 = *CONV_PM64(src+16);	\
	imm1 = *CONV_PM64(src+24);	\
	*CONV_PM64(dst) = imm0;		\
	*CONV_PM64(dst+8) = imm1;	\
	dst += pit;					\
	imm0 = *CONV_PM64(src+32);	\
	imm1 = *CONV_PM64(src+40);	\
	*CONV_PM64(dst) = imm0;		\
	*CONV_PM64(dst+8) = imm1;	\
	dst += pit;					\
	imm0 = *CONV_PM64(src+48);	\
	imm1 = *CONV_PM64(src+56);	\
	*CONV_PM64(dst) = imm0;		\
	*CONV_PM64(dst+8) = imm1;	\
	dst += pit;					\
	src += 64;

#define cpy_uv_mmx(pit) \
	imm0 = *CONV_PM64(src);		\
	*CONV_PM64(dst) = imm0;		\
	dst += pit;					\
	imm0 = *CONV_PM64(src+8);	\
	*CONV_PM64(dst) = imm0;		\
	dst += pit;					\
	imm0 = *CONV_PM64(src+16);	\
	*CONV_PM64(dst) = imm0;		\
	dst += pit;					\
	imm0 = *CONV_PM64(src+24);	\
	*CONV_PM64(dst) = imm0;		\
	dst += pit;					\
	src += 32;


STX_PRIVATE void cpy_mb_mmx(frame_decoder* the,s32 nOutputPit)
{
	MM_DECLARE8;
	u8* src;
	u8* dst;
	src = (u8*)the->bsw.reccoe.coey;
	dst = (u8*)the->bsw.lpYuvAddr[0][0];
	cpy_y_mmx(nOutputPit);
	cpy_y_mmx(nOutputPit);
	cpy_y_mmx(nOutputPit);
	cpy_y_mmx(nOutputPit);
	dst = (u8*)the->bsw.lpYuvAddr[0][1];
	nOutputPit >>= 1;
	cpy_uv_mmx(nOutputPit);
	cpy_uv_mmx(nOutputPit);
	dst = (u8*)the->bsw.lpYuvAddr[0][2];
	cpy_uv_mmx(nOutputPit);
	cpy_uv_mmx(nOutputPit);
	_m_empty();
}

#endif  // STX64



#define cpy_y_sse2(pit) \
	ixmm0 = _mm_load_si128( CONV_PXMMI(src) );		\
	_mm_store_si128(CONV_PXMMI(dst),ixmm0);			\
	dst += pit;										\
	ixmm0 = _mm_load_si128( CONV_PXMMI(src+16) );	\
	_mm_store_si128(CONV_PXMMI(dst),ixmm0);			\
	dst += pit;										\
	ixmm0 = _mm_load_si128( CONV_PXMMI(src+32) );	\
	_mm_store_si128(CONV_PXMMI(dst),ixmm0);			\
	dst += pit;										\
	ixmm0 = _mm_load_si128( CONV_PXMMI(src+48) );	\
	_mm_store_si128(CONV_PXMMI(dst),ixmm0);			\
	dst += pit;										\
	src += 64;

#define cpy_uv_sse2(pit) \
	ixmm0 = _mm_loadl_epi64( CONV_PXMMI(src) );		\
	_mm_storel_epi64(CONV_PXMMI(dst),ixmm0);		\
	dst += pit;										\
	ixmm0 = _mm_loadl_epi64( CONV_PXMMI(src+8) );	\
	_mm_storel_epi64(CONV_PXMMI(dst),ixmm0);		\
	dst += pit;										\
	ixmm0 = _mm_loadl_epi64( CONV_PXMMI(src+16) );	\
	_mm_storel_epi64(CONV_PXMMI(dst),ixmm0);		\
	dst += pit;										\
	ixmm0 = _mm_loadl_epi64( CONV_PXMMI(src+24) );	\
	_mm_storel_epi64(CONV_PXMMI(dst),ixmm0);		\
	dst += pit;										\
	src += 32;


STX_PRIVATE void cpy_mb_sse2(frame_decoder* the,s32 nOutputPit)
{
	XMMI_DECLARE8;
	u8* src;
	u8* dst;
	src = (u8*)the->bsw.reccoe.coey;
	dst = (u8*)the->bsw.lpYuvAddr[0][0];
	cpy_y_sse2(nOutputPit);
	cpy_y_sse2(nOutputPit);
	cpy_y_sse2(nOutputPit);
	cpy_y_sse2(nOutputPit);
	dst = (u8*)the->bsw.lpYuvAddr[0][1];
	nOutputPit >>= 1;
	cpy_uv_sse2(nOutputPit);
	cpy_uv_sse2(nOutputPit);
	dst = (u8*)the->bsw.lpYuvAddr[0][2];
	cpy_uv_sse2(nOutputPit);
	cpy_uv_sse2(nOutputPit);
}





/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
BitsWindow*     get_decode_window(frame_decoder* the)
{
	return &the->bsw;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void set_decode_mb(frame_decoder* the,s32 nFlag,s32 nStart,s32 nEnd)
{
	the->g_bSliceFlag = nFlag == FLAG_SLICE;
	the->g_nStartMb = nStart;
	the->g_nEndMb = nEnd;
	//	TRACE3("bSlice = %d,nStart = %d, nEnd = %d \n", g_bSliceFlag, nStart,nEnd);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void set_current_frame(frame_decoder* the,VideoFrame* pCurrentPicture)
{
	the->pCurrentPicture = pCurrentPicture;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void update_frame_size(frame_decoder* the)
{
	Update(
			the->g_lpMcDecoder,
			the->g_lpDecoder->vdr.bot_size,
			the->g_lpDecoder->vdr.top_size,
			the->g_lpDecoder->nCodedPictureWidth,
			the->g_lpDecoder->nCodedPictureHeight,
			the->g_lpDecoder->nCodedPicturePitch,
			the->g_lpDecoder->nChromaPitch,
			the->g_lpDecoder->nChromaFormat,
			the->g_lpDecoder->bMPEG2Flag
		);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
frame_decoder*	create_frame_decoder(video_decoder* h_vdec)
{
	STX_RESULT i_err;

	frame_decoder* the;

	do{

		i_err = STX_FAIL;

		the = (frame_decoder*)xlivAlloc( sizeof(frame_decoder),TRUE,16);
		if( !the ) {
			return NULL;
		}

		the->g_nStartMb = 0;
		the->g_nEndMb = 0;
		the->h_vdec = h_vdec;
		the->g_lpDecoder = &h_vdec->vdat;
		
		the->g_lpMcDecoder = create_mc_decoder(the);
		if( !the->g_lpMcDecoder ) {
			break;
		}

		i_err = STX_OK;

	}while(FALSE);
	
	if( STX_OK != i_err ) {

		close_frame_decoder(the);
		
		return NULL;
	}

	return the;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void close_frame_decoder(frame_decoder* the)
{
	close_mc_decoder(the->g_lpMcDecoder);
	the->g_lpMcDecoder = NULL;
	xlivFree(the);
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void video_decoder_initialize(u32 mmflag)
{
#ifdef USE_TABTAB
	InitDctTabTab();
#endif

	init_pre_idct(mmflag);

	init_mc_decoder(mmflag);
}




