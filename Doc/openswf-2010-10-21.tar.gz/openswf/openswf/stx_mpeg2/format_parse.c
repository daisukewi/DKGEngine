/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-11
***********************************************************************************/

#include "mpegdef.h"
#include "format_parse.h"

#include "stx_io.h"
#include "stx_io_stream.h"
#include "stx_os.h"
#include "stx_mem.h"
#include "stx_debug.h"


#ifdef __WIN32_LIB
#	include "mmreg.h"
#endif



#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif

/********************************************/
#define __GET_BITS_INC__
#include "get_bits.h"
#include "get_bits.c"
/********************************************/





STX_PRIVATE STX_RESULT sequence_extension(stx_bits_window* bs,LxVidSequence* vs);
STX_PRIVATE STX_RESULT extesion_and_user_data(stx_bits_window* bs,LxVidSequence* vs);



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT parse_mpeg1_video(u8* buf, s32 i_len, STX_VIDEOINFOHEADER2* vd2 )
{
	STX_RESULT			i_err;

	stx_bits_window*	bs;

	LxVidSequence		vs;

	INIT_MEMBER(vs);

	bs = (stx_bits_window*)xlivAlloc( sizeof(stx_bits_window),TRUE,16);

	if( !bs ) {
		return STX_FAIL;
	}

	do{
		i_err = stx_init_get_bits(bs,buf,i_len*8);
		if( STX_OK != i_err ) {
			break;
		}

		//

		i_err = STX_OK;

	}while(FALSE);

	stx_free_get_bits(bs);

	xlivFree(bs);

	return i_err;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
enum e_version{ mpeg_2p5,mpeg_reserved,mpeg_2,mpeg_1};
//00 - MPEG Version 2.5
//01 - reserved
//10 - MPEG Version 2 (ISO/IEC 13818-3)
//11 - MPEG Version 1 (ISO/IEC 11172-3) 

enum e_mode { stereo, joint_stereo, dual_channel, single_channel  };
enum e_sample_frequency { fourtyfour_point_one, fourtyeight, thirtytwo };

static s32 g_mpeg_audio_bitrate_v1[16][3] = {
	{0,0,0}, // free
	{32,32,32},
	{64,48,40},
	{96,56,48},
	{128,64,56},
	{160,80,64},
	{192,96,80},
	{224,112,96},
	{256,128,112},
	{288,160,128},
	{320,192,160},
	{352,224,192},
	{384,256,224},
	{416,320,256},
	{448,384,320},
	{0,0,0} // bad
};

static s32 g_mpeg_audio_bitrate_v2[16][2] = {
	//bitrate_index	bitrate specified (kbit/s) for Fs = 16, 22,05, 24 kHz
	//	Layer I	Layer II, Layer III
	{0,     0},   //'0000'	free	free
	{32,	8},	  //'0001'	32	8
	{48,	16},  //'0010'	48	16
	{56,	24},  //'0011'	56	24
	{64,	32},  //'0100'	64	32
	{80,	40},  //'0101'	80	40
	{96,	48},  //'0110'	96	48
	{112,	56},  //'0111'	112	56
	{128,	64},  //'1000'	128	64
	{144,	80},  //'1001'	144	80
	{160,	96},  //'1010'	160	96
	{176,	112},  //'1011'	176	112
	{192,	128},  //'1100'	192	128
	{224,	144},  //'1101'	224	144
	{256,	160},  //'1110'	256	160
	{0,0}		   //'1111'	forbidden	forbidden
};	


STX_RESULT parse_mpeg1_audio(u8* buf, s32 i_len, STX_WAVEFORMATEXTENSIBLE* wex )
{
	STX_RESULT			i_err;

	stx_bits_window*	bs;

	bs = (stx_bits_window*)xlivAlloc( sizeof(stx_bits_window),TRUE,16);

	if( !bs ) {
		return STX_FAIL;
	}

	do{

		u32 i_version;
		u32 h_layer;
		u32 h_protection_bit;
		u32 h_bitrate_index;
		u32 h_sample_frequency;
		u32 h_padding_bit;
		u32 h_mode,h_mode_extension;
		u32 h_intensity_stereo_bound;
		u32 h_copyright;
		u32 h_original;
		u32 h_number_of_subbands;

		i_err = stx_init_get_bits(bs,buf,i_len*8);
		if( STX_OK != i_err ) {
			break;
		}

		stx_get_bits(bs,11); // 0xfffffe

		i_version = stx_get_bits(bs,2);

		h_layer = stx_get_bits(bs,2);
		if ( h_layer == 0 )	{
			i_err = STX_AGAIN;
			break;
		}

		h_layer = 4 - h_layer;

		h_protection_bit = stx_get_bits(bs,1); // crc flag;

		h_bitrate_index = stx_get_bits(bs,4); //

		if( h_bitrate_index == 15)	{  // bad
			i_err = STX_AGAIN;
			break;
		}

		if (!h_bitrate_index)	{  // invalid;
			i_err = STX_AGAIN;
			break;
		}

		h_sample_frequency =  stx_get_bits(bs,2); //

		if( h_sample_frequency == 3 )	{  // reserved;
			i_err = STX_AGAIN;
			break;
		}

		h_padding_bit	= stx_get_bits(bs,1); //

		stx_get_bits(bs,1); // free

		h_mode = stx_get_bits(bs,2); //

		if (h_layer == 2)	{
			if ((((h_bitrate_index >= 1 && h_bitrate_index <= 3) || h_bitrate_index == 5) &&
				h_mode != single_channel) ||
				(h_bitrate_index >= 11 && h_mode == single_channel))	{
					i_err = STX_AGAIN;
					break;
			}
		}

		h_mode_extension = stx_get_bits(bs,2); //

		if (h_mode == joint_stereo){
			h_intensity_stereo_bound = (h_mode_extension << 2) + 4;
		}
		else  {
			h_intensity_stereo_bound = 0;
		}

		h_copyright = stx_get_bits(bs,1); //
		h_original = stx_get_bits(bs,1); //

		if (h_layer == 1) {
			h_number_of_subbands = 32;
		}
		else {
			u32 channel_bitrate = h_bitrate_index;

			if (h_mode != single_channel){
				if (channel_bitrate == 4){
					channel_bitrate = 1;
				}
				else{
					channel_bitrate -= 4;
				}
			}

			if (channel_bitrate == 1 || channel_bitrate == 2){
				if (h_sample_frequency == thirtytwo){
					h_number_of_subbands = 12;
				}
				else{
					h_number_of_subbands = 8;
				}
			}
			else{
				if (h_sample_frequency == fourtyeight || 
					(channel_bitrate >= 3 && channel_bitrate <= 5))	{
						h_number_of_subbands = 27;
				}
				else{
					h_number_of_subbands = 30;
				}
			}
		}

		if (h_intensity_stereo_bound > h_number_of_subbands){
			h_intensity_stereo_bound = h_number_of_subbands;
		}

		// fill wex;
		wex->Format.cbSize = sizeof(STX_WAVEFORMATEXTENSIBLE);

		if( 1 == h_layer ) {
			wex->Format.wFormatTag = WAVE_FORMAT_MPEGLAYER1;
			wex->SubFormat = MEDIASUBTYPE_MPEG1Audio_Layer1;
		}
		else if( 2 == h_layer ) {
			wex->Format.wFormatTag = WAVE_FORMAT_MPEGLAYER2;
			wex->SubFormat = MEDIASUBTYPE_MPEG1Audio_Layer2;
		}
		else if( 3 == h_layer ) {
			wex->Format.wFormatTag = WAVE_FORMAT_MPEGLAYER3;
			wex->SubFormat = MEDIASUBTYPE_MPEG1Audio_Layer3;
		}

		// bit rate
		if( mpeg_1 == i_version ) {
			wex->Format.nAvgBytesPerSec = g_mpeg_audio_bitrate_v1[h_bitrate_index][h_layer-1]; 
		}
		else if( mpeg_2 == i_version ) {
			u32 layer = h_layer == 1 ? 0 : 1;
			wex->Format.nAvgBytesPerSec = g_mpeg_audio_bitrate_v2[h_bitrate_index][layer]; 
		}
		wex->Format.nAvgBytesPerSec *= 1000;

		// not use
		wex->Format.nBlockAlign = 0;

		// channel
		wex->Format.nChannels = h_mode == single_channel ? 1 : 2; //
 
		// frequency
		if( h_sample_frequency == 0 ) {
			wex->Format.nSamplesPerSec = 44100;
		}
		else if(h_sample_frequency == 1){
			wex->Format.nSamplesPerSec = 48000; 
		}
		else{
			wex->Format.nSamplesPerSec = 32000;
		}

		// not use
		wex->Format.wBitsPerSample = 0;

		// not use
		wex->Samples.wReserved = 0;
		wex->Samples.wSamplesPerBlock = 0;
		wex->Samples.wValidBitsPerSample = 0;

		// not use
		wex->dwChannelMask = 0; //

		i_err = STX_OK;

	}while(FALSE);

	stx_free_get_bits(bs);

	xlivFree(bs);

	return i_err;
}


/*****************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
*****************************************************************************************/
STX_PRIVATE STX_RESULT sequence_extension(stx_bits_window* bs,LxVidSequence* vs)
{
	if( stx_get_bits_count(bs) < 44 ) {
		return STX_FAIL;
	}

	/* ISO/IEC 13818-2 section 6.2.2.3 */

	/* derive bit position for trace */
	vs->bMPEG2Flag = 1;
	vs->nProfileAndLevelIndication  = stx_get_bits(bs,8);
	vs->bProgressiveSequence        = stx_get_bits(bs,1);
	vs->nChromaFormat               = stx_get_bits(bs,2);
	vs->nHorizontalSizeExtension    = stx_get_bits(bs,2);
	vs->nVerticalSizeExtension      = stx_get_bits(bs,2);
	vs->nBitRateExtension           = stx_get_bits(bs,12);
	stx_get_bits(bs,1);
	vs->nVbvBufferSizeExtension    = stx_get_bits(bs,8);
	vs->bLowDelay                  = stx_get_bits(bs,1);
	vs->nFrameRateExtensionN       = stx_get_bits(bs,2);
	vs->nFrameRateExtensionD       = stx_get_bits(bs,5);

	vs->nHorizontalSize = (vs->nHorizontalSizeExtension<<12) | (vs->nHorizontalSize&0x0fff);
	vs->nVerticalSize = (vs->nVerticalSizeExtension<<12) | (vs->nVerticalSize&0x0fff);

	/* ISO/IEC 13818-2 does not define nBitRateValue to be composed of
	* both the original nBitRateValue parsed in sequence_header() and
	* the optional nBitRateExtension in sequence_extension_header(). 
	* However, we use it for bit stream verification purposes. 
	*/
	vs->nBitRateValue += vs->nBitRateExtension << 18;

	return STX_OK;
}


/*****************************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
*****************************************************************************************/
STX_PRIVATE STX_RESULT extesion_and_user_data(stx_bits_window* bs,LxVidSequence* vs)
{
	/* decode extension and user data */
	/* ISO/IEC 13818-2 section 6.2.2.2 */
	s32 code,ext_ID;

	stx_get_bits(bs, bs->nCurrentBit & 7 );

	for( ; ; ) {

		if( stx_get_bits_count(bs) <= 0 ) {
			return STX_OK;
		}

		code = stx_show_bits(bs,24);
		if( code != 1 ) {
			stx_get_bits(bs,8);
			continue;
		}

		stx_get_bits(bs,24);
		code = stx_get_bits(bs,8);

		if( code != _EXTENSION_START_CODE && code != _USER_DATA_START_CODE ) {
			return STX_OK;  // extension over;
		}

		if( code == _USER_DATA_START_CODE ) {
			stx_get_bits(bs,8);
			continue;
		}

		ext_ID = stx_get_bits(bs,4);

		switch (ext_ID)			{

		case SEQUENCE_EXTENSION_ID:
			if( STX_OK != sequence_extension(bs,vs) ) {
				return STX_FAIL;
			}
			break;

		case SEQUENCE_DISPLAY_EXTENSION_ID:
		case QUANT_MATRIX_EXTENSION_ID:
		case SEQUENCE_SCALABLE_EXTENSION_ID:
		case PICTURE_DISPLAY_EXTENSION_ID:
		case PICTURE_CODING_EXTENSION_ID:
		case PICTURE_SPATIAL_SCALABLE_EXTENSION_ID:
		case PICTURE_TEMPORAL_SCALABLE_EXTENSION_ID:
		case COPYRIGHT_EXTENSION_ID:
		default:
			stx_get_bits(bs,8);
			break;
		}			

	}

	// never reach;
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT parse_mpeg2_video(u8* buf, s32 i_len, STX_VIDEOINFOHEADER2* vd2 )
{
	STX_RESULT			i_err;

	stx_bits_window*	bs;

	LxVidSequence		vs;

	INIT_MEMBER(vs);


	bs = (stx_bits_window*)xlivAlloc( sizeof(stx_bits_window),TRUE,16);

	if( !bs ) {
		return STX_FAIL;
	}

	do{

		i_err = stx_init_get_bits(bs,buf,i_len*8);
		if( STX_OK != i_err ) {
			break;
		}

		// must be 0x000001b3;
		stx_get_bits(bs,32);

		vs.nHorizontalSize             = stx_get_bits(bs,12);    // 11
		vs.nVerticalSize               = stx_get_bits(bs,12);    // 23
		vs.nAspectRatioInformation     = stx_get_bits(bs,4);     // 27
		vs.nFrameRateCode              = stx_get_bits(bs,4);     // 31 4
		vs.nBitRateValue               = stx_get_bits(bs,18);    // 49;
		vs.market_bit                  = stx_get_bits(bs,1);     // 50;
		vs.nVbvBufferSizeCode          = stx_get_bits(bs,10);    // 60;
		vs.bConstrainedParametersFlag  = stx_get_bits(bs,1);     // 61

		if ( vs.bConstrainedParametersFlag ) 	{		// 62;  
			s32 i;
			for (i=0; i<64; i++) {
				stx_get_bits(bs,8);   // 63 -- 71
			}
		}

		if ( stx_get_bits(bs,1) )	{
			s32 i;
			for ( i = 0 ; i < 64; i ++ ) {
				stx_get_bits(bs,8);
			}
		}

		i_err = extesion_and_user_data(bs,&vs);

		if( STX_OK != i_err ) {
			break;
		}

		// fill vd2;
		vd2->AvgTimePerFrame = 0;
		vd2->bmiHeader.biCompression = MKTAG('M','P','G','2');
		vd2->bmiHeader.biBitCount = 24;
		vd2->bmiHeader.biWidth =  ( vs.nHorizontalSize + 15 ) & ~15;

		if( vs.bMPEG2Flag && !vs.bProgressiveSequence ) {
			vd2->bmiHeader.biHeight = ( vs.nVerticalSize + 31 ) & ~31;
		} 
		else {
			vd2->bmiHeader.biHeight = ( vs.nVerticalSize + 15 ) & ~15;
		}

		{
			f64 frate = rate_table[vs.nFrameRateCode].frame_rate / 1000.0f;
			f64 const f1sec = 1000*10000;
			vd2->AvgTimePerFrame =  (s64)( f1sec / frate );
		}


		vd2->dwBitRate = vs.nBitRateValue * 400;
		vd2->dwPictAspectRatioX = sartab[vs.nAspectRatioInformation].ratio;
		vd2->dwPictAspectRatioY = 16384;

		vd2->rcSource.left = 0;
		vd2->rcSource.top = 0;
		vd2->rcSource.right = vd2->bmiHeader.biWidth;
		vd2->rcSource.bottom = vd2->bmiHeader.biHeight;

		// << the target rect maybe not right; ignore the cropped infomation;
		vd2->rcTarget.left = 0;
		vd2->rcTarget.top = 0;
		vd2->rcTarget.right = vs.nHorizontalSize;
		vd2->rcTarget.bottom = vs.nVerticalSize;
		// >>

		i_err = STX_OK;

	}while(FALSE);

	stx_free_get_bits(bs);

	xlivFree(bs);

	return i_err;

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT parse_pcm_audio(u8* buf, s32 i_len, STX_WAVEFORMATEXTENSIBLE* wex )
{
	STX_RESULT			i_err;

	stx_bits_window*	bs;

	LxVidSequence		vs;

	INIT_MEMBER(vs);

	bs = (stx_bits_window*)xlivAlloc( sizeof(stx_bits_window),TRUE,16);

	if( !bs ) {
		return STX_FAIL;
	}

	do{
		i_err = stx_init_get_bits(bs,buf,i_len*8);
		if( STX_OK != i_err ) {
			break;
		}

		//

		i_err = STX_OK;

	}while(FALSE);

	stx_free_get_bits(bs);

	xlivFree(bs);

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT parse_ac3_audio(u8* buf, s32 i_len, STX_WAVEFORMATEXTENSIBLE* wex )
{
	STX_RESULT			i_err;

	stx_bits_window*	bs;

	LxVidSequence		vs;

	INIT_MEMBER(vs);

	bs = (stx_bits_window*)xlivAlloc( sizeof(stx_bits_window),TRUE,16);

	if( !bs ) {
		return STX_FAIL;
	}

	do{
		i_err = stx_init_get_bits(bs,buf,i_len*8);
		if( STX_OK != i_err ) {
			break;
		}

		//

		i_err = STX_OK;

	}while(FALSE);

	stx_free_get_bits(bs);

	xlivFree(bs);

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT parse_dts_audio(u8* buf, s32 i_len, STX_WAVEFORMATEXTENSIBLE* wex )
{
	STX_RESULT			i_err;

	stx_bits_window*	bs;

	LxVidSequence		vs;

	INIT_MEMBER(vs);

	bs = (stx_bits_window*)xlivAlloc( sizeof(stx_bits_window),TRUE,16);

	if( !bs ) {
		return STX_FAIL;
	}

	do{
		i_err = stx_init_get_bits(bs,buf,i_len*8);
		if( STX_OK != i_err ) {
			break;
		}

		//

		i_err = STX_OK;

	}while(FALSE);

	stx_free_get_bits(bs);

	xlivFree(bs);

	return i_err;
}
