// PrsDlg.cpp : implementation file
//

#include "stdafx.h"
#include "stx_gph_edit.h"
#include "PrsDlg.h"
#include "stx_prop_def.h"
#include "stp_pressure.h"
#include "stx_gph_editDlg.h"

#include "fcntl.h"

// PrsDlg dialog

IMPLEMENT_DYNAMIC(PrsDlg, CDialog)

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

PrsDlg::PrsDlg(CWnd* pParent /*=NULL*/)
	: CDialog(PrsDlg::IDD, pParent)
{

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

PrsDlg::~PrsDlg()
{
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
BOOL PrsDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	m_csIp = g_sz_ip4_default;
	m_csPort = g_sz_port_default;
	m_csConnum = "1";

	//m_csUrl = "D:\\project\\xliv\\bin32\\debug\\test0.flv";

	UpdateData(FALSE);

	return TRUE;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void PrsDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(PrsDlg)
	DDX_Text(pDX, IDC_IP, m_csIp);
	DDX_Text(pDX, IDC_EDIT_PORT, m_csPort);
	DDX_Text(pDX, IDC_EDIT_GPH, m_csGraph);
	DDX_Text(pDX, IDC_EDIT_NUM, m_csConnum);
	DDX_Text(pDX, IDC_EDIT_ADD_URL, m_csUrl);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(PrsDlg, CDialog)
	ON_BN_CLICKED(IDC_BTN_GPH, &PrsDlg::OnBnClickedBtnGph)
	ON_BN_CLICKED(IDC_BTN_ADD, &PrsDlg::OnBnClickedBtnAdd)
	ON_BN_CLICKED(IDC_BTN_REM, &PrsDlg::OnBnClickedBtnRem)
	ON_BN_CLICKED(IDOK, &PrsDlg::OnBnClickedOk)
	ON_BN_CLICKED(IDCANCEL, &PrsDlg::OnBnClickedCancel)
	ON_BN_CLICKED(ID_BTN_LOAD, &PrsDlg::OnBnClickedBtnLoad)
END_MESSAGE_MAP()


// PrsDlg message handlers



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void PrsDlg::OnBnClickedBtnGph()
{
	// TODO: Add your control notification handler code here

	char* sz_gph = OpenGraphFile(m_hWnd,NULL);
	if( sz_gph ) {
		HWND h_wnd;
		GetDlgItem(IDC_EDIT_GPH,&h_wnd);
		::SetWindowText(h_wnd,sz_gph);
		free(sz_gph);
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void PrsDlg::OnBnClickedBtnAdd()
{
	// TODO: Add your control notification handler code here
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void PrsDlg::OnBnClickedBtnRem()
{
	// TODO: Add your control notification handler code here
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void PrsDlg::OnBnClickedCancel()
{
	// TODO: Add your control notification handler code here
	OnCancel();
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void PrsDlg::OnBnClickedOk()
{
	// TODO: Add your control notification handler code here

	STX_RESULT  i_err;
	char		sz_ip[128];
	char		sz_port[32];
	char		sz_graph[1024];
	char		sz_url[1024];
	char		sz_num[1024];
	char*		sz_file;
	stx_xini*	h_xini;
	HWND        h_wnd;


	GetDlgItem(IDC_IP,&h_wnd);
	::GetWindowText(h_wnd,sz_ip,sizeof(sz_ip));

	GetDlgItem(IDC_EDIT_PORT,&h_wnd);
	::GetWindowText(h_wnd,sz_port,sizeof(sz_port));

	// get graph file string;
	GetDlgItem(IDC_EDIT_GPH,&h_wnd);
	::GetWindowText(h_wnd,sz_graph,sizeof(sz_graph));
	
	if( strlen(sz_graph) < 6 ) {
		AfxMessageBox("invalid graph file!");
		return;
	}

	// get URL string;
	GetDlgItem(IDC_EDIT_ADD_URL,&h_wnd);
	::GetWindowText(h_wnd,sz_url,sizeof(sz_url));

	if( strlen(sz_url) < 6 ) {
		AfxMessageBox("invalid URL!");
		return;
	}

	// get connection number;
	GetDlgItem(IDC_EDIT_NUM,&h_wnd);
	::GetWindowText(h_wnd,sz_num,sizeof(sz_num));

	if( strlen(sz_num) < 1 ) {
		AfxMessageBox("invalid connection number!");
		return;
	}

	// get file name;
	sz_file = SavePrsFile(m_hWnd,NULL);
	if( !sz_file ) {
		return;
	}

	// save to XINI file;

	
	do{
		h_xini = NULL;
		i_err = stx_ini_create(sz_file,NULL,STX_INI_CREATE_NEW|STX_INI_NO_COMMENT,0,&h_xini);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = set_prs_server(h_xini,sz_ip,(u16)atoi(sz_port));
		if( STX_OK != i_err ) {
			break;
		}

		i_err = set_prs_graph(h_xini,sz_graph);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = set_prs_connection(h_xini,atoi(sz_num));
		if( STX_OK != i_err ) {
			break;
		}

		i_err = add_prs_url(h_xini,sz_url);

	}while(FALSE);

	if( STX_OK != i_err ) {
		AfxMessageBox("internal error when save file");
	}

	if( h_xini ) {
		h_xini->close(h_xini);
	}

	free(sz_file);

	OnOK();
}


void PrsDlg::OnBnClickedBtnLoad()
{
	// TODO: Add your control notification handler code here
	STX_RESULT  i_err;
	char		sz_port[32];
	char		sz_num[32];

	char*		sz_file;
	char*		sz_graph;
	char*		sz_ip;
	char*		sz_url;
	stx_xini*	h_xini;
	HWND        h_wnd;

	sz_file = OpenPrsFile(m_hWnd,NULL);
	if( !sz_file ) {
		return;
	}

	do{
		h_xini = NULL;
		i_err = stx_ini_create(sz_file,NULL,STX_INI_READ_WRITE|STX_INI_NO_COMMENT,0,&h_xini);
		if( STX_OK != i_err ) {
			break;
		}

		u16 i_port;
		i_err = get_prs_server(h_xini,&sz_ip,&i_port);
		if( STX_OK != i_err ) {
			break;
		}
		GetDlgItem(IDC_IP,&h_wnd);
		::SetWindowText(h_wnd,sz_ip );

		GetDlgItem(IDC_EDIT_PORT,&h_wnd);
		_itoa_s(i_port,sz_port,10);
		::SetWindowText(h_wnd,sz_port );


		// get graph file string;
		sz_graph = get_prs_graph(h_xini);
		if( !sz_graph) {
			i_err = STX_FAIL;
			break;
		}
		GetDlgItem(IDC_EDIT_GPH,&h_wnd);
		::SetWindowText(h_wnd,sz_graph );

		s32 i_num = get_prs_connection(h_xini);
		if( i_num <= 0 ) {
			i_err = STX_FAIL;
			break;
		}
		GetDlgItem(IDC_EDIT_NUM,&h_wnd);
		_itoa_s(i_num,sz_num,10);
		::SetWindowText(h_wnd,sz_num );

		// get URL string;
		sz_url = get_prs_url(h_xini,0);
		GetDlgItem(IDC_EDIT_ADD_URL,&h_wnd);
		::SetWindowText(h_wnd,sz_url );

		i_err = STX_OK;

	}while(FALSE);

	if( STX_OK != i_err ) {
		AfxMessageBox("invalid file format");
	}

	if( h_xini ) {
		h_xini->close(h_xini);
	}

	free(sz_file);

	UpdateData(TRUE);
}
