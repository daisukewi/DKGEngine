/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-10
***********************************************************************************/
#pragma once



#include "base_flt_wnd.h"


static BOOL fw_PtInRect(base_flt_wnd*the,POINT pt){
	return ::PtInRect(&the->m_pos,pt);
}

STX_RESULT fw_paint(base_flt_wnd*the, HDC hdc, RECT rc );
void       fw_OnSize(base_flt_wnd*the,UINT nType, int cx, int cy);

STX_RESULT fw_OnLButtonDown(base_flt_wnd*the,UINT nFlags, CPoint point,base_pin_wnd** pp_pwnd);
STX_RESULT fw_OnLButtonUp(base_flt_wnd*the,UINT nFlags, CPoint point,RECT clip,base_pin_wnd** pp_pwnd);

BOOL       fw_OnLButtonDblClk(base_flt_wnd*the,UINT nFlags, CPoint point);
BOOL       fw_OnRButtonDown(base_flt_wnd*the,UINT nFlags, CPoint point);
BOOL       fw_OnMouseMove(base_flt_wnd*the,UINT nFlags, CPoint point);
BOOL	   fw_OnSetCursor(base_flt_wnd*the,CWnd* pWnd,UINT nHitTest,UINT message);

STX_RESULT fw_create_dlg(base_flt_wnd*the);
STX_RESULT fw_create_menu(base_flt_wnd*the,POINT point);
