// UrlDlg.cpp : implementation file
//

#include "stdafx.h"

#include "stx_gph_edit.h"
#include "UrlDlg.h"
#include "stx_all.h"


#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif

// UrlDlg dialog

IMPLEMENT_DYNAMIC(UrlDlg, CDialog)

UrlDlg::UrlDlg(CWnd* pParent /*=NULL*/)
	: CDialog(UrlDlg::IDD, pParent)
{
	m_szUrl = NULL;	
}

UrlDlg::~UrlDlg()
{
	if( m_szUrl ) {
		stx_free(m_szUrl);
	}
}

void UrlDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(UrlDlg, CDialog)
	ON_BN_CLICKED(IDOK, &UrlDlg::OnBnClickedOk)
	ON_BN_CLICKED(IDCANCEL, &UrlDlg::OnBnClickedCancel)
END_MESSAGE_MAP()


// UrlDlg message handlers


void UrlDlg::OnBnClickedOk()
{
	// TODO: Add your control notification handler code here
	CString url;
	GetDlgItem(IDC_EDIT_URL)->GetWindowText(url);

	if(m_szUrl) {
		stx_free(m_szUrl);
	}

	DECL_TRACE
	MAKE_TRACE2
	m_szUrl = smart_strdup(url.GetBuffer(url.GetLength()+1),MAP_TRACE);

	OnOK();
}

void UrlDlg::OnBnClickedCancel()
{
	// TODO: Add your control notification handler code here
	OnCancel();
}
