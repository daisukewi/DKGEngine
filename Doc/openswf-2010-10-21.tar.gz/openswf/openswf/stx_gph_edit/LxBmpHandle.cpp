/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-10
***********************************************************************************/
// LxBmpHandle.cpp: implementation of the LxBmpHandle class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include "mmsystem.h"
#include "LxBmpHandle.h"

#include "..\stx_plat\cubic_resizer.h"

static  const int nFileHeaderSize = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFO);

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

/***************************************************************************************
LxBmpHandle::LxBmpHandle()
***************************************************************************************/
LxBmpHandle::LxBmpHandle()
{
	m_bColor = FALSE;
	//m_RGBParam = g_DefaultRGBParam;
	//m_hColor = OpenRGBAdjust();

	m_bUpdate = FALSE;
	m_bSharp = FALSE;
	m_dwRotateTheta = 0;

	INIT_MEMBER(m_ResamInf);
	INIT_MEMBER(m_SrcInf);
	INIT_MEMBER(m_SharpInf);
	INIT_MEMBER(m_RotateInf);
	INIT_MEMBER(m_DstInf);

	//INIT_MEMBER(m_RotatePara);

	m_hResample = open_bicubic_resize();
	//m_hSharp = open_sharp_ctx(LX_RGB24);
	//m_hRotate = NULL;
}


/***************************************************************************************
static void ReleaseBmpHndInf(LxBmpHndInf* pInf)
***************************************************************************************/
static void ReleaseBmpHndInf(LxBmpHndInf* pInf)
{
	if( pInf->pBuf ) {
		delete []pInf->pBuf;
		pInf->pBuf = NULL;
	}
	if( pInf->hBitmap ) {
		::DeleteObject(pInf->hBitmap );
		pInf->hBitmap = NULL;
	}	
}


/***************************************************************************************
LxBmpHandle::~LxBmpHandle()
***************************************************************************************/
LxBmpHandle::~LxBmpHandle()
{
	//ReleaseBmpHndInf(&m_ColorInf);
	ReleaseBmpHndInf(&m_SrcInf);
	//ReleaseBmpHndInf(&m_SharpInf);
	//ReleaseBmpHndInf(&m_RotateInf);
	ReleaseBmpHndInf(&m_DstInf);
	//ReleaseBmpHndInf(&m_ResamInf);

	if( m_hResample ) {
		close_bicubic_resize(m_hResample);
		m_hResample = NULL;
	}

	if( m_hSharp ) {
		//close_sharp_ctx(m_hSharp);
		m_hSharp = NULL;
	}

	if( m_hColor ) {
		//CloseRGBAdjust(m_hColor);
		m_hColor = NULL;
	}

	//ReleaseRotatePara();
}


/***************************************************************************************
int LxBmpHandle::GetSrcSize(int* nWidth,int* nHeight)
***************************************************************************************/
int LxBmpHandle::GetSrcSize(int* nWidth,int* nHeight)
{
	if( !m_SrcInf.pBuf ) {
		return -1;
	}

	*nWidth = m_ResamInf.nInputWidth;
	*nHeight = m_ResamInf.nInputHeight;

	return LX_OK;
}


/***************************************************************************************
int LxBmpHandle::LoadBmp(LPCTSTR szPathName)
***************************************************************************************/
int LxBmpHandle::LoadBmp(LPCTSTR szPathName)
{
	HANDLE hFile = ::CreateFile(szPathName,								
		GENERIC_READ,
		FILE_SHARE_READ,
		NULL,
		OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL,
		NULL);	
	
	if( hFile == INVALID_HANDLE_VALUE ) {
		return -1;
	}

	DWORD dwHigh;
	m_SrcInf.nFileSize = ::GetFileSize(hFile,&dwHigh);
	m_SrcInf.pBuf = new BYTE[ m_SrcInf.nFileSize ];
	::ReadFile(hFile,m_SrcInf.pBuf,m_SrcInf.nFileSize,&dwHigh,NULL);

	m_SrcInf.pHdr = (BITMAPFILEHEADER *)m_SrcInf.pBuf;
	m_SrcInf.pBmi = (BITMAPINFO*)(m_SrcInf.pBuf + sizeof(BITMAPFILEHEADER) );
	m_ResamInf.nInputFmt = m_SrcInf.pBmi->bmiHeader.biBitCount;
	m_ResamInf.nInputWidth = m_SrcInf.pBmi->bmiHeader.biWidth;
	m_ResamInf.nInputHeight = m_SrcInf.pBmi->bmiHeader.biHeight;
	m_ResamInf.pInputBuf = m_SrcInf.pBuf + m_SrcInf.pHdr->bfOffBits;

	CloseHandle(hFile);

	m_bUpdate = TRUE;

	return LX_OK;
}

/***************************************************************************************
int LxBmpHandle::ReSampleBmp(LxResampleInf* pInf)
***************************************************************************************/
int LxBmpHandle::ReSampleBmp(LxResampleInf* pInf)
{
	CUBIC_RESIZE_PARAM TransPara;

	if( pInf->nInputFmt  != 24 && pInf->nInputFmt != 32 ) {
		return -1;
	}

	if( pInf->nOutputFmt  != 24 && pInf->nOutputFmt != 32 ) {
		return -1;
	}
	
	if( pInf->nInputFmt  != pInf->nOutputFmt  ) {
		return -1;
	}

	if( 24 == pInf->nOutputFmt )	{

		TransPara.SrcWidth  [0] = pInf->nInputWidth;
		TransPara.SrcHeight [0] = pInf->nInputHeight;
		TransPara.SrcPitch  [0] = ( ( pInf->nInputWidth* 3 + 3 ) & ~3 ) ;
		TransPara.lpSrc     [0] = pInf->pInputBuf;

		TransPara.DstWidth  [0] = pInf->nOutputWidth;
		TransPara.DstHeight [0] = pInf->nOutputHeight;
		TransPara.DstPitch  [0] = ( ( pInf->nOutputWidth* 3 + 3 ) & ~3 ) ;
		TransPara.lpDst     [0] = pInf->pOutputBuf;

		TransPara.dwFlags =  0;
		STX_PUT_RESIZE_CODE((TransPara.dwFlags),STX_RESIZE_TRUE);

		STX_PUT_ALG_CODE((TransPara.dwFlags),STX_RESIZE_ALG_BICUB);
		//STX_PUT_ALG_CODE((TransPara.dwFlags),STX_RESIZE_ALG_LAN3);
		//STX_PUT_ALG_CODE((TransPara.dwFlags),STX_RESIZE_ALG_LAN8);
		//STX_PUT_ALG_CODE((TransPara.dwFlags),STX_RESIZE_ALG_AUTO);

		STX_PUT_SIZE_CODE((TransPara.dwFlags),STX_NOT_FAST_SIZE);
		STX_PUT_INPUT_FORMAT((TransPara.dwFlags),STX_FORMAT_RGB24);
		STX_PUT_OUTPUT_FORMAT((TransPara.dwFlags),STX_FORMAT_RGB24);

	}
	else if( 32 == pInf->nOutputFmt )	{

		TransPara.SrcWidth  [0] = pInf->nInputWidth;
		TransPara.SrcHeight [0] = pInf->nInputHeight;
		TransPara.SrcPitch  [0] = ( ( pInf->nInputWidth* 4 + 3 ) & ~3 ) ;
		TransPara.lpSrc     [0] = pInf->pInputBuf;

		TransPara.DstWidth  [0] = pInf->nOutputWidth;
		TransPara.DstHeight [0] = pInf->nOutputHeight;
		TransPara.DstPitch  [0] = ( ( pInf->nOutputWidth* 4 + 3 ) & ~3 ) ;
		TransPara.lpDst     [0] = pInf->pOutputBuf;

		TransPara.dwFlags      =  0;
		STX_PUT_RESIZE_CODE((TransPara.dwFlags),STX_RESIZE_TRUE);
		STX_PUT_ALG_CODE((TransPara.dwFlags),STX_RESIZE_ALG_BICUB);
		STX_PUT_SIZE_CODE((TransPara.dwFlags),STX_NOT_FAST_SIZE);
		STX_PUT_INPUT_FORMAT((TransPara.dwFlags),STX_FORMAT_RGB32);
		STX_PUT_OUTPUT_FORMAT((TransPara.dwFlags),STX_FORMAT_RGB32);

	}

	return bicubic_resize(m_hResample,&TransPara);
}



/***************************************************************************************
int  LxBmpHandle::SaveBmp(TCHAR* szPathName , HDC hdc, int nWidth,int nHeight)
***************************************************************************************/
int  LxBmpHandle::SaveBmp(TCHAR* szPathName , HDC hdc, int nWidth,int nHeight)
{
	DWORD dwWrite;

	if( !m_SrcInf.hBitmap || !m_DstInf.hBitmap ) {
		GetResizeHandle( hdc, nWidth,nHeight);
	}

	HANDLE hFile = ::CreateFile(szPathName,								
		GENERIC_READ | GENERIC_WRITE,
		FILE_SHARE_READ,
		NULL,
		CREATE_ALWAYS,
		FILE_ATTRIBUTE_NORMAL,
		NULL);	
	
	if( hFile == INVALID_HANDLE_VALUE ) {
		return -1;
	}

	if( ( nWidth == m_SrcInf.pBmi->bmiHeader.biWidth && nHeight == m_SrcInf.pBmi->bmiHeader.biHeight ) ||
		( !nWidth && !nHeight ) ) {

		::WriteFile(hFile,m_SrcInf.pBuf,m_SrcInf.nFileSize,&dwWrite,NULL);

	}
	else {

		::WriteFile(hFile,m_DstInf.pBmi,m_DstInf.nFileSize,&dwWrite,NULL);
	}

	CloseHandle(hFile);

	return LX_OK;
}

/***************************************************************************************
HBITMAP LxBmpHandle::GetResizeHandle( HDC hdc, int nWidth,int nHeight)
***************************************************************************************/
HBITMAP LxBmpHandle::GetResizeHandle( HDC hdc, int nWidth,int nHeight)
{	
	if( nWidth != m_ResamInf.nOutputWidth || nHeight != m_ResamInf.nOutputHeight || m_bUpdate ) {
	
		m_bUpdate = FALSE;

		LxBmpHndInf* pInput;

		if( m_dwRotateTheta ) {
			pInput = &m_RotateInf;
		}
		else if( m_bSharp ) {
			pInput = &m_SharpInf;
		}
		else if( m_bColor) {
			pInput = &m_ColorInf;
		}
		else {
			pInput = &m_SrcInf;
		}
		
		if( m_DstInf.hBitmap ) {
			::SelectObject(hdc,pInput->hBitmap);
			::DeleteObject(m_DstInf.hBitmap);
			m_DstInf.hBitmap = NULL;
		}

		if( m_DstInf.pBuf ) {
			delete []m_DstInf.pBuf;
		}

		int nDstSize = ( ( ( nWidth  * m_ResamInf.nInputFmt + 31 ) & ~31 ) >> 3 ) * nHeight;

		m_DstInf.nFileSize = nDstSize + pInput->pHdr->bfOffBits;
		m_DstInf.pBuf = new BYTE [nDstSize + nFileHeaderSize + ( nHeight << 4 ) ] ;

		m_DstInf.pHdr = (BITMAPFILEHEADER *)m_DstInf.pBuf;
		m_DstInf.pBmi = (BITMAPINFO*)(m_DstInf.pBuf + sizeof(BITMAPFILEHEADER) );

		m_ResamInf.nInputWidth = pInput->pBmi->bmiHeader.biWidth;
		m_ResamInf.nInputHeight = pInput->pBmi->bmiHeader.biHeight;
		m_ResamInf.pInputBuf = pInput->pBuf + pInput->pHdr->bfOffBits;
		m_ResamInf.nOutputWidth  = nWidth ;
		m_ResamInf.nOutputHeight = nHeight ;
		m_ResamInf.nOutputFmt = m_ResamInf.nInputFmt;
		m_ResamInf.pOutputBuf = m_DstInf.pBuf + pInput->pHdr->bfOffBits;

		ReSampleBmp(&m_ResamInf);

		//<< fill the struct; 
		m_DstInf.pHdr->bfType       = *(WORD *)"BM";
		m_DstInf.pHdr->bfSize       = nDstSize + nFileHeaderSize;
		m_DstInf.pHdr->bfReserved1  = 0;
		m_DstInf.pHdr->bfReserved2  = 0;
		m_DstInf.pHdr->bfOffBits    = pInput->pHdr->bfOffBits;
		*m_DstInf.pBmi = *pInput->pBmi;
		m_DstInf.pBmi->bmiHeader.biWidth = nWidth;
		m_DstInf.pBmi->bmiHeader.biHeight = nHeight;
		//>>

		m_DstInf.hBitmap = ::CreateDIBitmap( hdc, &m_DstInf.pBmi->bmiHeader, 
			CBM_INIT, m_DstInf.pBuf + m_DstInf.pHdr->bfOffBits, m_DstInf.pBmi, DIB_RGB_COLORS );

		//<< test code;
//		SaveBmp(NULL,hdc,nWidth,nHeight);
//		SaveBmp(NULL,hdc,0,0);
		//>>
	}

	return m_DstInf.hBitmap;
} 


/***************************************************************************************
void LxBmpHandle::ReleaseRotatePara()
***************************************************************************************/
void LxBmpHandle::ReleaseRotatePara()
{
	if( m_hRotate ) {
		//close_rotate_ctx(m_hRotate);
		m_hRotate = NULL;
	}

	//INIT_MEMBER(m_RotatePara);
}

/***************************************************************************************
int LxBmpHandle::CheckRotatePara(int nWidth,int nHeight)
***************************************************************************************/
int LxBmpHandle::CheckRotatePara(int nWidth,int nHeight)
{
// 	ReleaseRotatePara();
// 
// 	m_RotatePara.dwFormat = LX_RGB24;
// 	m_RotatePara.dwTheta = m_dwRotateTheta;
// 	m_RotatePara.nSrcWidth = nWidth;
// 	m_RotatePara.nSrcHeight = nHeight;
// 	m_RotatePara.nAdjustSrcWidth = nWidth;
// 
// 	m_hRotate = open_rotate_ctx(&m_RotatePara);
// 	if( !m_hRotate ) {
// 		return -1;
// 	}

	return LX_OK;
}

/***************************************************************************************
int LxBmpHandle::ReloadEffHandle()
***************************************************************************************/
int LxBmpHandle::ReloadEffHandle()
{
	m_bUpdate = TRUE;

#if 0
	
	if( !m_dwRotateTheta && !m_bSharp && !m_bColor) {
		m_ResamInf.nInputWidth = m_SrcInf.pBmi->bmiHeader.biWidth;
		m_ResamInf.nInputHeight = m_SrcInf.pBmi->bmiHeader.biHeight;
		return LX_OK;
	}

	LxBmpHndInf* pInput = &m_SrcInf;

	if( m_bColor ) {

		ReleaseBmpHndInf(&m_ColorInf);

		m_ColorInf.nFileSize = pInput->nFileSize;
		m_ColorInf.pBuf = new BYTE[ pInput->nFileSize ];
		if( !m_ColorInf.pBuf ) {
			return -1;
		}
		m_ColorInf.pHdr = (BITMAPFILEHEADER *)m_ColorInf.pBuf;
		m_ColorInf.pBmi = (BITMAPINFO*)(m_ColorInf.pBuf + sizeof(BITMAPFILEHEADER) );
		m_ColorInf.pHdr->bfType       = *(WORD *)"BM";
		m_ColorInf.pHdr->bfSize       = pInput->pHdr->bfSize;
		m_ColorInf.pHdr->bfReserved1  = 0;
		m_ColorInf.pHdr->bfReserved2  = 0;
		m_ColorInf.pHdr->bfOffBits    = pInput->pHdr->bfOffBits;
		*m_ColorInf.pBmi = *pInput->pBmi;

		BYTE* pSrc = pInput->pBuf + pInput->pHdr->bfOffBits;
		BYTE* pDst = m_ColorInf.pBuf + m_ColorInf.pHdr->bfOffBits;
		int nWidth = pInput->pBmi->bmiHeader.biWidth;
		int nHeight = pInput->pBmi->bmiHeader.biHeight;
		int nBitCount = pInput->pBmi->bmiHeader.biBitCount;
		int pit = ( ( ( nWidth  * nBitCount + 31 ) & ~31 ) >> 3 );

		if( LX_OK != AdjustRGB(m_hColor,pSrc,pDst,nBitCount,nWidth,nHeight,pit,pit,&m_RGBParam) ) {
 			return -1;
 		}

		m_ResamInf.nInputWidth = m_ColorInf.pBmi->bmiHeader.biWidth;
		m_ResamInf.nInputHeight = m_ColorInf.pBmi->bmiHeader.biHeight;

		pInput = &m_ColorInf;
	}


	if( m_bSharp ) {

		ReleaseBmpHndInf(&m_SharpInf);

		m_SharpInf.nFileSize = pInput->nFileSize;
		m_SharpInf.pBuf = new BYTE[ pInput->nFileSize ];
		if( !m_SharpInf.pBuf ) {
			return -1;
		}
		m_SharpInf.pHdr = (BITMAPFILEHEADER *)m_SharpInf.pBuf;
		m_SharpInf.pBmi = (BITMAPINFO*)(m_SharpInf.pBuf + sizeof(BITMAPFILEHEADER) );
		m_SharpInf.pHdr->bfType       = *(WORD *)"BM";
		m_SharpInf.pHdr->bfSize       = pInput->pHdr->bfSize;
		m_SharpInf.pHdr->bfReserved1  = 0;
		m_SharpInf.pHdr->bfReserved2  = 0;
		m_SharpInf.pHdr->bfOffBits    = pInput->pHdr->bfOffBits;
		*m_SharpInf.pBmi = *pInput->pBmi;

		BYTE* pSrc = pInput->pBuf + pInput->pHdr->bfOffBits;
		BYTE* pDst = m_SharpInf.pBuf + m_SharpInf.pHdr->bfOffBits;
		int nWidth = pInput->pBmi->bmiHeader.biWidth;
		int nHeight = pInput->pBmi->bmiHeader.biHeight;
		int pit = ( ( ( nWidth  * pInput->pBmi->bmiHeader.biBitCount + 31 ) & ~31 ) >> 3 );

		//sharp_slice(m_hSharp,pSrc,pDst,nWidth,nHeight,pit,pit);

		m_ResamInf.nInputWidth = m_SharpInf.pBmi->bmiHeader.biWidth;
		m_ResamInf.nInputHeight = m_SharpInf.pBmi->bmiHeader.biHeight;

		pInput = &m_SharpInf;
	}
	if( m_dwRotateTheta ) {

		ReleaseBmpHndInf(&m_RotateInf);

		int nWidth = pInput->pBmi->bmiHeader.biWidth;
		int nHeight = pInput->pBmi->bmiHeader.biHeight;
		int nBit = pInput->pBmi->bmiHeader.biBitCount;
		int pit = ( ( ( nWidth  * nBit + 31 ) & ~31 ) >> 3 );

		if( LX_OK != CheckRotatePara(nWidth,nHeight) ) {
			return -1;
		}

		nWidth = m_RotatePara.nDstWidth;
		nHeight = m_RotatePara.nDstHeight;

		m_RotatePara.nSrcPitch[0] = pit;
		m_RotatePara.nDstPitch = ( ( ( nWidth  * nBit + 31 ) & ~31 ) >> 3 );

		int nDstSize =  m_RotatePara.nDstPitch * nHeight;

		m_RotateInf.nFileSize = nDstSize + pInput->pHdr->bfOffBits;
		m_RotateInf.pBuf = new BYTE [nDstSize + nFileHeaderSize + ( nHeight << 4 ) ] ;
		if( !m_RotateInf.pBuf ) {
			return -1;
		}
		m_RotateInf.pHdr = (BITMAPFILEHEADER *)m_RotateInf.pBuf;
		m_RotateInf.pBmi = (BITMAPINFO*)(m_RotateInf.pBuf + sizeof(BITMAPFILEHEADER) );
		m_RotateInf.pHdr->bfType       = *(WORD *)"BM";
		m_RotateInf.pHdr->bfSize       = pInput->pHdr->bfSize;
		m_RotateInf.pHdr->bfReserved1  = 0;
		m_RotateInf.pHdr->bfReserved2  = 0;
		m_RotateInf.pHdr->bfOffBits    = pInput->pHdr->bfOffBits;
		*m_RotateInf.pBmi = *pInput->pBmi;
		m_RotateInf.pBmi->bmiHeader.biWidth = nWidth;
		m_RotateInf.pBmi->bmiHeader.biHeight = nHeight;

		m_RotatePara.lpSrcY = pInput->pBuf + pInput->pHdr->bfOffBits;
		m_RotatePara.lpDstY = m_RotateInf.pBuf + m_RotateInf.pHdr->bfOffBits;

		m_RotatePara.nDstHeightStart = 0;
		m_RotatePara.nDstHeightEnd = m_RotatePara.nDstHeight;
		rotate_bitmap(m_hRotate, &m_RotatePara);

		m_ResamInf.nInputWidth = m_RotateInf.pBmi->bmiHeader.biWidth;
		m_ResamInf.nInputHeight = m_RotateInf.pBmi->bmiHeader.biHeight;
	}
#endif
	return LX_OK;
}


/***************************************************************************************
void LxBmpHandle::SetRotate(DWORD dwTheta)
***************************************************************************************/
void LxBmpHandle::SetRotate(DWORD dwTheta)
{
	if( m_dwRotateTheta != dwTheta ) {
		m_dwRotateTheta = dwTheta;
		ReloadEffHandle();
	}
}

/***************************************************************************************
void LxBmpHandle::SetSharp(BOOL bSharp)
***************************************************************************************/
void LxBmpHandle::SetSharp(BOOL bSharp)
{
	if( m_bSharp != bSharp ) {
		m_bSharp = bSharp;
		ReloadEffHandle();
	}
}

/***************************************************************************************
void LxBmpHandle::SetColor(RGB_Adjust_Param* pParam)
***************************************************************************************/
#if 0
void LxBmpHandle::SetColor(RGB_Adjust_Param* pParam)
{
	m_RGBParam = *pParam;
	m_bColor = TRUE;
	if( !memcmp(&m_RGBParam,&g_DefaultRGBParam,sizeof(RGB_Adjust_Param) ) ) {
		m_bColor = FALSE;
	}

	ReloadEffHandle();
}
#endif



