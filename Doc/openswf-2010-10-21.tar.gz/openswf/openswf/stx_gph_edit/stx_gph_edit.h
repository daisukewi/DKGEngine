/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-10
***********************************************************************************/
// stx_gph_edit.h : main header file for the PROJECT_NAME application
//

#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"		// main symbols


// Cstx_gph_editApp:
// See stx_gph_edit.cpp for the implementation of this class
//

class Cstx_gph_editApp : public CWinApp
{
public:
	Cstx_gph_editApp();

// Overrides
	public:
	virtual BOOL InitInstance();

// Implementation

	DECLARE_MESSAGE_MAP()
};

extern Cstx_gph_editApp theApp;


#define MAX_GRAPH	10

#define MENU_FILTER_RDOWN		1
#define MENU_PIN_RDOWN			2
#define MENU_CANVAS_RDOWN		3
#define MENU_FILTER_LDBCLICK	4
#define MENU_PIN_LDBCLICK		5
#define MENU_CANVAS_LDBCLICK	6


#define WM_PAINT_CANVUS		WM_USER + 600
#define WM_VIEWFLT			WM_USER + 605
#define WM_ADDFLT			WM_USER + 610
#define WM_REMFLT			WM_USER + 620
#define WM_RESIZE_FLTWND	WM_USER + 630
#define WM_DISCONNECT_PIN	WM_USER + 640
#define WM_AUTO_SOTP		WM_USER + 650

#define WM_ASPECT_RATIO		WM_USER + 700

#define WM_INPUTPIN			WM_USER + 1000
#define WM_OUTPUTPIN		WM_USER + 1100

#define WM_PLAY    		WM_USER + 1200
#define WM_STOP    		WM_USER + 1210
#define WM_PAUSE    	WM_USER + 1220
#define WM_RESUME    	WM_USER + 1230





#if _DEBUG
//#	define new DEBUG_NEW
#endif