/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-10
***********************************************************************************/
// stx_gph_edit.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"

#include "stx_gph_edit.h"
#include "stx_gph_editDlg.h"

#include "stx_all.h"
#include "stx_gbd_hnd.h"
#include "play_window.h"

#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// Cstx_gph_editApp

BEGIN_MESSAGE_MAP(Cstx_gph_editApp, CWinApp)
	ON_COMMAND(ID_HELP, &CWinApp::OnHelp)
END_MESSAGE_MAP()


// Cstx_gph_editApp construction

Cstx_gph_editApp::Cstx_gph_editApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}


// The one and only Cstx_gph_editApp object

Cstx_gph_editApp theApp;

Cstx_gph_editDlg* theGraphEdit = NULL;

stx_base_graph_builder* g_gbd = NULL;

stx_base_plugin* g_gbd_hnd = NULL;


void test_trace(char* sz_dbg)
{
	OutputDebugString(sz_dbg);
}

// Cstx_gph_editApp initialization

BOOL Cstx_gph_editApp::InitInstance()
{
	// InitCommonControlsEx() is required on Windows XP if an application
	// manifest specifies use of ComCtl32.dll version 6 or later to enable
	// visual styles.  Otherwise, any window creation will fail.
	INITCOMMONCONTROLSEX InitCtrls;
	InitCtrls.dwSize = sizeof(InitCtrls);
	// Set this to include all the common control classes you want to use
	// in your application.
	InitCtrls.dwICC = ICC_WIN95_CLASSES;
	InitCommonControlsEx(&InitCtrls);

	CWinApp::InitInstance();

	AfxEnableControlContainer();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	// of your final executable, you should remove from the following
	// the specific initialization routines you do not need
	// Change the registry key under which our settings are stored
	// TODO: You should modify this string to be something appropriate
	// such as the name of your company or organization
	SetRegistryKey(_T("StreamX graph editor"));


	if( ! init_play_window_env() ) {
		return FALSE;
	}

	g_gbd = stx_initialize(test_trace,STX_TRACE_WINDOW | STX_INIT_NETWORK | STX_INIT_THREAD );
	if( ! g_gbd ) {
		goto play_window_fail;
	}

	{
		stx_sync_inf		sync_inf;
		Cstx_gph_editDlg	dlg;

		theGraphEdit = &dlg;

		g_gbd_hnd = XCREATE(gbd_hnd,NULL);
		if( !g_gbd_hnd ) {
			goto fail;
		}

		g_gbd->set_parent(g_gbd,g_gbd_hnd);

		INIT_MEMBER(sync_inf);
		sync_inf.i_flags = CALL_GBD_RUN_START;
		if( STX_OK != g_gbd->start(g_gbd,0,&sync_inf) ) {
			goto fail;
		}

		{

			m_pMainWnd = &dlg;
			INT_PTR nResponse = dlg.DoModal();
			if (nResponse == IDOK)
			{
				// TODO: Place code here to handle when the dialog is
				//  dismissed with OK
			}
			else if (nResponse == IDCANCEL)
			{
				// TODO: Place code here to handle when the dialog is
				//  dismissed with Cancel
			}
		}

		dlg.cleanup(); // important;

		INIT_MEMBER(sync_inf);
		sync_inf.i_flags = CALL_GBD_RUN_STOP;
		g_gbd->stop(g_gbd,0,&sync_inf);

		WSACleanup();

fail:

		SAFE_XDELETE(g_gbd_hnd);
		g_gbd_hnd = NULL;
		stx_cleanup(g_gbd);

	}// block


play_window_fail:

	close_play_window_env();

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}
