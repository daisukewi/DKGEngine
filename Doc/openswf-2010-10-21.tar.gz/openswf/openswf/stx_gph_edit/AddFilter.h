/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-10
***********************************************************************************/
#pragma once


// AddFilter dialog

class AddFilter : public CDialog
{
	DECLARE_DYNAMIC(AddFilter)

public:

	AddFilter(CWnd* pParent,void* h_xini,void* h_stream,BOOL bPreview);   // standard constructor
	virtual ~AddFilter();

// Dialog Data
	enum { IDD = IDD_DLG_ADDFLT };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();

	afx_msg void OnClose();
	DECLARE_MESSAGE_MAP()


private:
	CDialog*	m_parent;
	void*		m_hxini;
	void*		m_hstream;
	BOOL		m_bPreview;

	char		m_szPath[2048];

	BOOL LoadFilters();

public:
	afx_msg void OnBnClickedBtnAddflt();
	
	void  get_last_clsid(BYTE id[16]);
	BOOL  get_path(char* sz_path,size_t i_size);
};
