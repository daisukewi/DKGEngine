/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-10
***********************************************************************************/
#include "StdAfx.h"

#include "stx_gph_edit.h"
#include "stx_gph_editdlg.h"
#include "stx_canvas.h"
#include "filter_wnd.h"

#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif

extern stx_base_graph_builder* g_gbd;
extern stx_base_plugin* g_gbd_hnd;
extern s32 g_iMaxGraph;





/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

stx_canvas::stx_canvas(HWND hwnd)
{
	canvas_create(this,hwnd,g_gbd_hnd,g_gbd);
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

stx_canvas::~stx_canvas(void)
{
	canvas_close(this);
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
s32 stx_canvas::GetHScrollRange()
{
	RECT rec;
	::GetClientRect(m_hWnd,&rec);
	return (m_view_pos.right - m_view_pos.left) - rec.right;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
s32 stx_canvas::GetVScrollRange()
{
	RECT rec;
	::GetClientRect(m_hWnd,&rec);
	return (m_view_pos.bottom - m_view_pos.top) - rec.bottom;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void stx_canvas::SetHScrollPos(s32 pos)
{
	m_pos.left -= pos;
	m_pos.right -= pos;
	m_view_pos.left -= pos;
	m_view_pos.right -= pos;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void stx_canvas::SetVScrollPos(s32 pos)
{
	m_pos.top -= pos;
	m_pos.bottom -= pos;
	m_view_pos.top -= pos;
	m_view_pos.bottom -= pos;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void stx_canvas::update_clip_rect()
{
	RECT	cln_rect;
	b32     b_left,b_top,b_right,b_bottom;
	s32		left;
	s32		top;
	s32		right;
	s32		bottom;

	::GetClientRect(m_hWnd,&cln_rect);

	b_left = m_pos.left < 0 ? FALSE : TRUE;
	b_top = m_pos.top < 0 ? FALSE : TRUE;
	b_right = m_pos.right >= cln_rect.right ? FALSE : TRUE;
	b_bottom = m_pos.bottom >= cln_rect.bottom ? FALSE : TRUE;

	left = b_left ? m_pos.left : 0;
	top = b_top ? m_pos.top : 0;
	right = b_right ? m_pos.right : cln_rect.right ;
	bottom = b_bottom ? m_pos.bottom : cln_rect.bottom ;

	SetRect(&m_clip,left,top,right,bottom);

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT stx_canvas::paint( HDC hdc  )
{
	STX_RESULT i_err;

	s32     i,j;
	HGDIOBJ	hBrush,hRestore;

	RECT	cln_rect;
	b32     b_left,b_top,b_right,b_bottom;
	s32		left;
	s32		top;
	s32		right;
	s32		bottom;
	::GetClientRect(m_hWnd,&cln_rect);

	b_left = m_pos.left < 0 ? FALSE : TRUE;
	b_top = m_pos.top < 0 ? FALSE : TRUE;
	b_right = m_pos.right >= cln_rect.right ? FALSE : TRUE;
	b_bottom = m_pos.bottom >= cln_rect.bottom ? FALSE : TRUE;

	left = b_left ? m_pos.left : 0;
	top = b_top ? m_pos.top : 0;
	right = b_right ? m_pos.right : cln_rect.right ;
	bottom = b_bottom ? m_pos.bottom : cln_rect.bottom ;

	SetRect(&m_clip,left,top,right,bottom);

	// draw grades;
	hBrush = ::CreatePen( PS_DOT,1,RGB(0,255,0) );
	hRestore = ::SelectObject(hdc,hBrush ); 
	for( i = 0; i < m_iGrades; i ++ ) {
		s32 i_start = m_pos.left + (i+1)*GRADE_WIDTH;
		if( i_start > cln_rect.left && i_start < cln_rect.right ) {
			::MoveToEx(hdc,i_start,top,(LPPOINT) NULL);
			::LineTo(hdc,i_start,bottom);
		}//if( i_start > cln_rect.left && i_start < cln_rect.right ) {
	}//for( i = 0; i < m_iGrades; i ++ ) {
	if( hRestore ) {
		::SelectObject(hdc,hRestore);
	}
	::DeleteObject(hBrush);

	// draw canvas;
	hBrush = ::CreatePen( PS_DASH,1,RGB(0,0,0) );
	hRestore = ::SelectObject(hdc,hBrush ); 
	if( b_left ) {
		::MoveToEx(hdc,left,top,(LPPOINT) NULL);
		::LineTo(hdc,left,bottom);
	}
	if( b_top ) {
		::MoveToEx(hdc,left,top,(LPPOINT) NULL);
		::LineTo(hdc,right,top);
	}
	if( b_right ) {

		// draw resize edge;
		::MoveToEx(hdc,right-RESIZE_EDGE,bottom-DUSTBIN_HEGHT,(LPPOINT) NULL);
		::LineTo(hdc,right-RESIZE_EDGE,top);

		// draw dustbin;
		::MoveToEx(hdc,right-DUSTBIN_WIDTH,bottom-DUSTBIN_HEGHT,(LPPOINT) NULL);
		::LineTo(hdc,right-DUSTBIN_WIDTH,bottom);

		::MoveToEx(hdc,right,bottom,(LPPOINT) NULL);
		::LineTo(hdc,right,top);
	}
	if( b_bottom ) {

		// draw dustbin;
		::MoveToEx(hdc,right-DUSTBIN_WIDTH,bottom-DUSTBIN_HEGHT,(LPPOINT) NULL);
		::LineTo(hdc,right,bottom-DUSTBIN_WIDTH);

		::MoveToEx(hdc,right,bottom,(LPPOINT) NULL);
		::LineTo(hdc,left,bottom);
	}
	if( hRestore ) {
		::SelectObject(hdc,hRestore);
	}
	::DeleteObject(hBrush);

	// draw filters;
	if( m_hhGrade ) {
		for( i = 0; i < m_iGrades; i ++ ) {
			stx_grade* p = m_hhGrade[i];
			for( j = 0; j < p->i_filter; j ++ ) {
				fw_paint(p->ppFilterWnd[j],hdc,m_clip);
			}//for( j = 0; j < p->i_filter; j ++ ) {
		} // for( i = 0; i < m_iGrades; i ++ ) {
	}//if( m_hhGrade ) {

	// draw connections;
	i_err = draw_connections(hdc);

	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT stx_canvas::draw_connections(HDC hdc)
{
	s32			i;
	HGDIOBJ		hBrush,hRestore;
	POINT		pt;


	// draw exist;
	for( i = 0; i < m_iAllConnectTions; i ++ ) {
		stx_connection* p = m_ppConnectRect[i];
		if( p->b_valid ) {
			hBrush = ::CreatePen(PS_SOLID,1,RGB(0,0,255));
		}
		else {
			hBrush = ::CreatePen(PS_DOT,1,RGB(0,0,255));
		}
		hRestore = ::SelectObject(hdc, hBrush); 
		pt = p->start_pos.pwnd->GetPoint(p->start_pos.pwnd);
		::MoveToEx(hdc,pt.x,pt.y,(LPPOINT) NULL);
		pt = p->end_pos.pwnd->GetPoint(p->end_pos.pwnd);
		::LineTo(hdc,pt.x,pt.y);
		if( hRestore ){
			::SelectObject(hdc, hRestore);
		}
		::DeleteObject(hBrush);
	}  // for( i = 0; i < m_iAllConnectTions; i ++ ) {

	return STX_OK;

	// drawing;
	if( m_bDrawConnection ) {
		::GetCursorPos(&pt);
		::ScreenToClient(m_hWnd,&pt);
		hBrush = ::CreatePen(PS_DOT,1,RGB(255,0,0));
		hRestore = ::SelectObject(hdc, hBrush); 
		::MoveToEx(hdc,m_start_point.x,m_start_point.y,(LPPOINT) NULL);
		::LineTo(hdc,pt.x,pt.y);
		if( hRestore ){
			::SelectObject(hdc, hRestore);
		}
		::DeleteObject(hBrush);
	} // if( m_bDrawConnection ) {

	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT stx_canvas::OnMouseMove(UINT nFlags, CPoint point)
{
	s32 i,j;
	b32 b_hit;

	b_hit = FALSE;

	for( i = 0; i < m_iGrades; i ++ ) {
		stx_grade* p = m_hhGrade[i];
		for( j = 0; j < p->i_filter; j ++ ) {
			b_hit |= fw_OnMouseMove(p->ppFilterWnd[j],nFlags,point);
		}//for( j = 0; j < p->i_filter; j ++ ) {
	} // for( i = 0; i < m_iGrades; i ++ ) {

	if( b_hit ) {
		return TRUE;
	}

	if( ! ::PtInRect(&m_pos,point) ) {
		return FALSE;
	}

	return FALSE;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT stx_canvas::OnLButtonDblClk(UINT nFlags, CPoint point)
{
	s32 i,j;

	b32 b_click = FALSE;

	m_bDrag = FALSE;

	for( i = 0; i < m_iGrades; i ++ ) {

		stx_grade* p = m_hhGrade[i];

		for( j = 0; j < p->i_filter; j ++ ) {

			b_click |= fw_OnLButtonDblClk(p->ppFilterWnd[j],nFlags,point);
		}//for( j = 0; j < p->i_filter; j ++ ) {

	} // for( i = 0; i < m_iGrades; i ++ ) {

	if( b_click ) {
		return b_click;
	}
		
	if( ::PtInRect(&m_pos,point) ) {

		return TRUE;
	}

	return FALSE;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT stx_canvas::OnLButtonDown(UINT nFlags, CPoint point)
{
	s32			i,j;
	b32			b_hit;
	STX_RESULT	i_err;

	base_pin_wnd*    pwnd;

	if(	! ::PtInRect(&m_pos,point) ) {
		return STX_OK;
	}

	b_hit = FALSE;

	for( i = 0; i < m_iGrades; i ++ ) {
		stx_grade* g = m_hhGrade[i];
		for( j = 0; j < g->i_filter; j ++ ) {
			i_err = fw_OnLButtonDown(g->ppFilterWnd[j],nFlags,point,&pwnd);
			if( STX_RET_CONNECT == i_err && base_pin_wnd_IsOutputPin(pwnd) ) {
				m_bDrawConnection = TRUE;
				m_start_pwnd = pwnd;
				m_start_point = point;
				b_hit = TRUE;
			}
			else if( STX_RET_PAINT == i_err || STX_RET_HIT == i_err || STX_RET_MOVE == i_err ) {
				b_hit = TRUE;
			}
		}
	}
	if( b_hit ) {
		return STX_RET_PAINT;
	}

	if( ::PtInRect(&m_resize,point) ) {
		m_bResize = TRUE;
		m_lastPoint = point;
		return STX_OK;
	}

	// in filter wnd;
	m_bDrag = TRUE;
	m_lastPoint = point;

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT stx_canvas::OnLButtonUp(UINT nFlags, CPoint point)
{
	STX_RESULT		i_err;
	s32				i,j;
	s32				i_mov_x;
	base_pin_wnd*   pwnd;


	base_canvas* the = (base_canvas*)this;


	if( m_bResize ) {
		m_bResize = FALSE;
		j = GRADE_WIDTH*(m_iGrades+1);
		if( j < CANVAS_MIN_WIDTH ) {
			j = CANVAS_MIN_WIDTH;
		}
		if( point.x < m_pos.left + j ) {
			point.x = m_pos.left + j;
		}
		i_mov_x = point.x - m_lastPoint.x;
		m_pos.right += i_mov_x;
		i = m_pos.right - m_pos.left;
		if( i > CANVAS_MAX_WIDTH ) {
			m_pos.right = m_pos.left + CANVAS_MAX_WIDTH;
		}
		UPDATE_RESIZE;
		UPDATE_DUSTBIN;
		UPDATE_VIEW;
		return STX_RET_PAINT;
	} // if( m_bResize ) {

	// in canvas;
	if( m_bDrag ) {

		m_bDrag = FALSE;

		// map canvas position;
		s32 i_mov_x = point.x - m_lastPoint.x;
		s32 i_mov_y = point.y - m_lastPoint.y;

		m_pos.left += i_mov_x;
		m_pos.right += i_mov_x;
		m_pos.top += i_mov_y;
		m_pos.bottom += i_mov_y;

		UPDATE_RESIZE;
		UPDATE_DUSTBIN;	
		UPDATE_VIEW;

		// update sub-window;
		for( i = 0; i < m_iGrades; i ++ ) {
			stx_grade* g = m_hhGrade[i];
			for( j = 0; j < g->i_filter; j ++ ) {
				base_flt_wnd* f = g->ppFilterWnd[j];
				fw_move(f,i_mov_x,i_mov_y,m_pos);
			} // for( j = 0; j < g->i_filter; j ++ ) {
			if( g->i_filter ) {
				canvas_sort_grade(the,g);
			}
		} // for( i = 0; i < m_iGrades; i ++ ) {

		return STX_RET_PAINT;
	} //if( m_bDrag ) {


	do{
		// update sub-window;

		for( i = 0; i < m_iGrades; i ++ ) {

			stx_grade* g = m_hhGrade[i];

			for( j = 0; j < g->i_filter; j ++ ) {

				base_flt_wnd* f = g->ppFilterWnd[j];

				i_err = fw_OnLButtonUp(f,nFlags,point,m_pos,&pwnd);

				if( STX_RET_MOVE == i_err ) {
					// check the position;
					if( canvas_check_fltwnd_pos(the,f) < 0 ) {
						return STX_FAIL;
					}// if( STX_OK != check_fltwnd_pos(f) ) {

					return STX_RET_PAINT;
				}//if( STX_RET_HIT == i_err ) {

				if( STX_RET_CONNECT == i_err && m_bDrawConnection ) {

					m_bDrawConnection = FALSE;

					if( base_pin_wnd_get_fltwnd(pwnd) != base_pin_wnd_get_fltwnd(m_start_pwnd) &&
						!base_pin_wnd_IsOutputPin(pwnd) && base_pin_wnd_IsOutputPin(m_start_pwnd) ) {

						// check minf;
						s32                i_pin;
						stx_media_type_inf minf_start;
						stx_media_type_inf minf_end;

						base_pin_wnd_get_pin_inf(pwnd,&i_pin,&minf_end);
						base_pin_wnd_get_pin_inf(m_start_pwnd,&i_pin,&minf_start);

						if( is_compatible_gid(minf_start.major_type,minf_end.major_type ) &&
							is_compatible_gid(minf_start.sub_type,minf_end.sub_type ) ) {

								// add connections;
								i_err = canvas_add_connections(the,m_start_pwnd,pwnd);
								if( STX_OK != i_err ) {
									break;
								}

								return STX_RET_PAINT;

						}//if( is_compatible_gid(min

					} // if( pwnd->IsOutputPin() && !m_start_pwnd->IsOutputPin() ) {

				} // if( STX_RET_CONNECT == i_err && m_bDrawConnection ) {

			} // for( j = 0; j < g->i_filter; j ++ ) {

		} // for( i = 0; i < m_iGrades; i ++ ) {

		i_err = STX_OK;

	}while(FALSE);

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_RESULT stx_canvas::OnRButtonDown(UINT nFlags, CPoint point)
{
	if( !::PtInRect(&m_pos,point) ) {
		return FALSE;
	}

	s32 i,j;

	for( i = 0; i < m_iGrades; i ++ ) {
		stx_grade*g = m_hhGrade[i];
		for( j = 0; j < g->i_filter; j ++ ) {
			base_flt_wnd* f = g->ppFilterWnd[j];
			if( fw_OnRButtonDown(f,nFlags,point) ) {
				return TRUE;
			}//if( f->OnRButtonDown(nFlags,point,i_type,insid) ) {
		}//for( j = 0; j < g->i_filter; j ++ ) {
	}//for( i = 0; i < m_iGrades; i ++ ) {

	return FALSE;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT stx_canvas::OnSize(UINT nType, int cx, int cy)
{
	return STX_RET_PAINT;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT stx_canvas::OnSetCursor
(CWnd* pWnd,UINT nHitTest,UINT message)
{
	return FALSE;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT	stx_canvas::OnPause()
{
	STX_RESULT i_err;

	for( ; ; ) {

		i_err = canvas_OnPause(this);

		if( STX_OK == i_err || i_err < 0 ) {
			break;
		}

		stx_sleep(1);
	}

	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT	stx_canvas::OnResume()
{
	STX_RESULT i_err;

	for( ; ; ) {

		i_err = canvas_OnResume(this);

		if( STX_OK == i_err || i_err < 0 ) {
			break;
		}

		stx_sleep(1);
	}

	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT	stx_canvas::OnStop()
{
	STX_RESULT i_err;

	for( ; ; ) {

		i_err = canvas_OnStop(this);

		if( STX_OK == i_err || i_err < 0 ) {
			break;
		}

		stx_sleep(10);
	}

	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT stx_canvas::OnRunGraph()
{
	STX_RESULT i_err;

	for( ; ; ) {

		i_err = canvas_OnRunGraph(this);

		if( STX_OK == i_err || i_err < 0 ) {
			break;
		}

		stx_sleep(1);
	}

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_RESULT stx_canvas::OnAddFilter(stx_gid clsid,char* sz_dll)
{
	return canvas_OnAddFilter(this,clsid,sz_dll);
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
analyze stream, add source filter, auto build;
***************************************************************************/
STX_RESULT stx_canvas::OnRendStream(char* sz_url)
{
	// add source filter;

	// load stream;

	// rend render for each pin;

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
have source filter, load stream to it;
grade[0], always settle new filter here;
grade[1], always settle sourde filter here;
***************************************************************************/
STX_RESULT stx_canvas::OnLoadStream(char* sz_url)
{
	STX_RESULT		i_err;
	stx_sync_inf	sync;

	for( ; ; ) {

		do{
			INIT_MEMBER(sync);
			i_err = canvas_OnLoadStream(this,sz_url,&sync);
		}while(STX_AGAIN == i_err);

		if( STX_IDLE == i_err || STX_WOUNLD_BLOCK == i_err ) {
			stx_sleep(10);
			continue;
		}

		return i_err;
	}

	// never reach;
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
have source filter, load stream to it;
grade[0], always settle new filter here;
grade[1], always settle sourde filter here;
***************************************************************************/
STX_RESULT stx_canvas::OnCloseStream( )
{
	return canvas_OnCloseStream(this);
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
found one filter to fit the pin;
***************************************************************************/
STX_RESULT stx_canvas::OnRendPin()
{
	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
auto build path, from one filter's one pin to end render;
***************************************************************************/
STX_RESULT stx_canvas::OnRendRender()
{
	return STX_OK;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
s32 stx_canvas::get_graph_caps()
{
	return (s32)canvas_get_control_caps(this);
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

s32 stx_canvas::get_graph_status()
{
	return canvas_get_graph_status(this);
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void stx_canvas::graph_cmd(u32 i_cmd)
{
	if( WM_PLAY == i_cmd){
		canvas_OnRunGraph(this);
	}
	else if( WM_STOP == i_cmd ) {
		canvas_OnStop(this);
	}
	else if( WM_PAUSE == i_cmd ) {
		canvas_OnPause(this);
	}
	else if( WM_RESUME == i_cmd ) {
		canvas_OnResume(this);
	}

}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT stx_canvas::OnAutoStop(stx_base_message* p_msg)
{
	return canvas_on_auto_stop(this,p_msg);
}
