/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-10
***********************************************************************************/
#pragma once

#include "base_canvas.h"

class stx_canvas : public base_canvas
{
public:
	stx_canvas(HWND hwnd);
	virtual ~stx_canvas(void);

	STX_RESULT paint( HDC hdc );


	STX_RESULT OnSize(UINT nType, int cx, int cy);
	STX_RESULT OnLButtonDblClk(UINT nFlags, CPoint point);
	STX_RESULT OnLButtonDown(UINT nFlags, CPoint point);
	STX_RESULT OnLButtonUp(UINT nFlags, CPoint point);

	STX_RESULT OnRButtonDown(UINT nFlags, CPoint point);
	STX_RESULT OnMouseMove(UINT nFlags, CPoint point);
	STX_RESULT OnSetCursor(CWnd* pWnd,UINT nHitTest,UINT message);
	STX_RESULT OnAutoStop(stx_base_message* p_msg);

	s32		GetHScrollRange();
	s32		GetVScrollRange();
	void	SetHScrollPos(s32 pos);
	void	SetVScrollPos(s32 pos);

	void	graph_cmd(u32 i_cmd);

	BOOL PtInRect(POINT pt)	{
		return ::PtInRect(&m_pos,pt);
	}

	STX_RESULT	OnAddFilter(stx_gid clsid,char* sz_dll);
	STX_RESULT	OnRendStream(char* sz_url);
	STX_RESULT	OnLoadStream(char* sz_url);
	STX_RESULT	OnCloseStream();
	STX_RESULT	OnRendPin();
	STX_RESULT	OnRendRender();

	STX_RESULT	OnRunGraph();
	STX_RESULT	OnPause();
	STX_RESULT	OnResume();
	STX_RESULT	OnStop();

	STX_RESULT initialize( char* sz_file){
		return canvas_initialize(this,sz_file,NULL);
	}
	STX_RESULT serialize( char* sz_file){
		return canvas_serialize(this,sz_file,NULL);
	}
	void set_dst_rect(RECT dst_rect){
		return canvas_set_dst_rect(this,dst_rect);
	}
	void show_render(b32 bShow){
		return canvas_show_render(this,bShow);
	}

	s32			get_graph_caps();
	s32			get_graph_status();

	void        update_clip_rect();
	STX_RESULT  draw_connections(HDC hdc);

};
