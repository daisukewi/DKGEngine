/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-10
***********************************************************************************/
// LxBmpHandle.h: interface for the LxBmpHandle class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LXBMPHANDLE_H__5BB4DCCD_40FF_4FFF_A32A_A74EFC2A2531__INCLUDED_)
#define AFX_LXBMPHANDLE_H__5BB4DCCD_40FF_4FFF_A32A_A74EFC2A2531__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define LX_FAIL -1
#define LX_OK    0


// #include "RGB_ADJUST.h"
// 
// struct ROTATEPARA;

typedef struct LxResampleInf{
	int     nInputFmt;             // 24,32;
	int     nInputWidth;
	int     nInputHeight;
	BYTE*   pInputBuf;

	int     nOutputFmt;            // 24,32;
	int     nOutputWidth;
	int     nOutputHeight;
	BYTE*   pOutputBuf;

}LxResampleInf;


typedef struct LxBmpHndInf{
	int                    nFileSize;
	BITMAPFILEHEADER*      pHdr;
    BITMAPINFO*            pBmi;
	BYTE*                  pBuf;
	HBITMAP                hBitmap;
}LxBmpHndInf;


//static RGB_Adjust_Param g_DefaultRGBParam = { 1024,0,0,0,0,1024};


class LxBmpHandle  
{
private:

	//RGB_Adjust_Param       m_RGBParam;

	BOOL                   m_bUpdate;
	BOOL                   m_bSharp;
	DWORD                  m_dwRotateTheta;
	BOOL                   m_bColor;

	LxResampleInf          m_ResamInf;
	HANDLE                 m_hResample;
	HANDLE                 m_hSharp;
	HANDLE                 m_hRotate;
	//ROTATEPARA             m_RotatePara;
	HANDLE                 m_hColor;

	LxBmpHndInf            m_SrcInf;
	LxBmpHndInf            m_SharpInf;
	LxBmpHndInf            m_RotateInf;
	LxBmpHndInf            m_ColorInf;
	LxBmpHndInf            m_DstInf;

	int						ReSampleBmp(LxResampleInf* pInf);
	int						ReloadEffHandle();
	void					ReleaseRotatePara();
	int						CheckRotatePara(int nWidth,int nHeight);

public:

	BITMAPINFO*            GetSrcBmi(){
		return m_SrcInf.pBmi;
	}

	int                    LoadBmp(LPCTSTR szPathName);
	int					   LoadBmpFromBuffer(const BYTE*, DWORD cbSize);
	//<< if nWidth is 0 and nHeight is 0, return source handle; ortherwise 
	//   return the resized bimap handle;
	HBITMAP                GetResizeHandle(HDC hdc,int nWidth,int nHeight); 
	//>>

	//<< if the szPathName is NULL, save in progarm path resize.bmp;
	int                    SaveBmp(TCHAR* szPathName,HDC hdc, int nWidth,int nHeight);
	//>>

	//void                   SetColor(RGB_Adjust_Param* pParam);
	void                   SetSharp(BOOL bSharp);
	void                   SetRotate(DWORD dwTheta);

	int						GetSrcSize(int* nWidth,int* nHeight);

	LxBmpHandle();
	virtual ~LxBmpHandle();

};


static BOOL GetCurrentPath(LPTSTR szPath, DWORD nSize) //nSize: n TCHARs
{
	DWORD dwRet =
		GetModuleFileName(GetModuleHandle(NULL), szPath, nSize);

	if(0 == dwRet)
	{
		return FALSE;
	}
	else
	{
		TCHAR* p = szPath;
		while(*p)++p;// let p point to '\0'
		while('\\' != *p)--p;// let p point to '\\'
		*p = '\0';// get the path
		
		return TRUE;
	}
}


#define WND_MIN_WIDTH   352/2
#define WND_MIN_HEIGHT  288/2

/***************************************************************************************
void GetFullScreenSize(SIZE &size, BOOL bWorkArea)
***************************************************************************************/
static void GetFullScreenSize(SIZE &size, BOOL bWorkArea)
{
	int nSX = GetSystemMetrics(SM_CXSCREEN);
	int nSY = GetSystemMetrics(SM_CYSCREEN);
	RECT rWorkArea;
	BOOL bResult = SystemParametersInfo(SPI_GETWORKAREA, sizeof(RECT), &rWorkArea, 0);    
	if(!bResult || !bWorkArea)
	{
		size.cx = nSX;
		size.cy = nSY;
	}
	else
	{
		size.cx = rWorkArea.right - rWorkArea.left;
		size.cy = rWorkArea.bottom - rWorkArea.top;
	}
}

/***************************************************************************************
static void ClientRectToScreen(HWND hWnd, IN OUT RECT* lpRect)
***************************************************************************************/
static void ClientRectToScreen(HWND hWnd, IN OUT RECT* lpRect)
{
	POINT top;
	POINT bottom;
	top.x = lpRect->left;
	top.y = lpRect->top;
	bottom.x = lpRect->right;
	bottom.y = lpRect->bottom;
	::ClientToScreen(hWnd, &top);
	::ClientToScreen(hWnd, &bottom);
	::SetRect(lpRect, top.x,top.y, bottom.x,bottom.y);
}

#endif // !defined(AFX_LXBMPHANDLE_H__5BB4DCCD_40FF_4FFF_A32A_A74EFC2A2531__INCLUDED_)
