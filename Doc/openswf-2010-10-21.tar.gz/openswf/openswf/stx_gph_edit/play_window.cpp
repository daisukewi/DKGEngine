/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-10
***********************************************************************************/
#include "StdAfx.h"



#include "play_window.h"

#include "ActiveMovieWindow.h"
#include "LxBmpHandle.h"

#include "resource.h"
#include "stx_gph_edit.h"
#include "stx_gph_editDlg.h"

#include "stx_canvas.h"

#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif

#ifdef _MAP_THE	
#undef _MAP_THE	
#endif	
#define _MAP_THE STX_MAP_THE(play_window)	

#ifdef _DIRECT_THE	
#undef _DIRECT_THE	
#endif	
#define _DIRECT_THE STX_DIRECT_THE(play_window)	


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API_IMP 
CREATE_STX_COM(stx_base_plugin,STX_IID_BasePlugin,play_window);


typedef struct LxVidWndInf LxVidWndInf;

struct LxVidWndInf{
	play_window*		pVidWnd;
	HWND				hWnd;
	LxVidWndInf*		next;
};

static BOOL                 g_bLxVidWndInit = FALSE;
static CRITICAL_SECTION     g_LxVidWndCritic;
static LxVidWndInf*			p_first;



__inline void lock_play_window_env()
{
	::EnterCriticalSection(&g_LxVidWndCritic);
}

__inline void unlock_play_window_env()
{
	::LeaveCriticalSection(&g_LxVidWndCritic);
}

/***************************************************************************************
BOOL Initializeplay_window()
***************************************************************************************/
BOOL init_play_window_env()
{
	if( !g_bLxVidWndInit ) {
		::InitializeCriticalSection(&g_LxVidWndCritic);
		g_bLxVidWndInit = TRUE;
	}
	return g_bLxVidWndInit;
}

/***************************************************************************************
void ReleaseLxVidWnd()
***************************************************************************************/
void close_play_window_env()
{
	if( g_bLxVidWndInit ) {
		::DeleteCriticalSection(&g_LxVidWndCritic);
		g_bLxVidWndInit = FALSE;
	}
}

/***************************************************************************************
void add_play_window(play_window* pVidWnd,HWND hWnd )
***************************************************************************************/
void add_play_window(play_window* pVidWnd,HWND hWnd )
{
	lock_play_window_env();
	LxVidWndInf* pInf = new LxVidWndInf;
	pInf->pVidWnd = pVidWnd;
	pInf->hWnd = hWnd;
	pInf->next = NULL;
	if( !p_first ) {
		p_first = pInf;
		unlock_play_window_env();
		return;
	}
	LxVidWndInf* p = p_first;
	while( p->next ) {
		p = p->next;
	}
	p->next = pInf;
	unlock_play_window_env();
}

/***************************************************************************************
void rem_play_window(play_window* pVidWnd)
***************************************************************************************/
void rem_play_window(play_window* pVidWnd)
{
	lock_play_window_env();

	LxVidWndInf* p = p_first;
	LxVidWndInf* prev = NULL;

	while( p ) {
		if( p->pVidWnd == pVidWnd ) {
			if( prev ) {
				prev->next = p->next;
			}
			else {
				p_first = p->next;
			}
			delete p;
			unlock_play_window_env();
			return;
		}
		p = p->next;
	}
	unlock_play_window_env();
}


/***************************************************************************************
static play_window* play_window_from_hwnd(HWND hWnd)
***************************************************************************************/
static play_window* play_window_from_hwnd(HWND hWnd)
{
	lock_play_window_env();
	LxVidWndInf* p = p_first;
	LxVidWndInf* prev = NULL;

	while( p ) {
		if( p->hWnd == hWnd ) {
			unlock_play_window_env();
			return p->pVidWnd;
		}
		p = p->next;
	}

	unlock_play_window_env();
	return NULL;
}




STX_COM_BEGIN(play_window);
/**/
/**/STX_PUBLIC(stx_base_plugin)
/**/STX_COM_DATA_DEFAULT(stx_base_plugin)
/**/STX_PUBLIC(stx_active_movie_wnd)
/**/HWND					m_hWnd;
/**/HINSTANCE				m_hInstance;
/**/CRITICAL_SECTION		m_Critic;
/**/LxBmpHandle*			m_pBkHnd;
/**/char*					m_szBkDir;
/**/WNDCLASSEX				m_wc;
/**/s32						m_width;
/**/s32						m_height;
/**/s32						m_aspect_ratio;
/**/s32						m_force_aspect_ratio;
/**/b32						m_bFixAspectRatio;
/**/b32						m_bFullScreen;
/**/b32						m_bMaximizeScreen;
/**/b32						m_bTopMost;
/**/u32						m_dwColorKey;
/**/stx_base_plugin*		m_hChildWndPlugin;
/**/stx_active_movie_wnd*	m_hChildActiveWnd;
/**/RECT					m_rt;
/**/RECT					m_dst_rect;
/**/
STX_COM_END();



STX_COM_FUNC_DECL_DEFAULT(stx_base_plugin,stx_base_plugin_vt);
STX_COM_FUNCIMP_DEFAULT(play_window,stx_base_plugin,stx_base_plugin_vt);

STX_COM_FUNC_DECL_DEFAULT(stx_active_movie_wnd,stx_active_movie_wnd_vt);
STX_COM_FUNCIMP_DEFAULT(play_window,stx_active_movie_wnd,stx_active_movie_wnd_vt);


/*{{{STX_MSG_PROC_DECLARE***************************************************/
STX_MSG_PROC_DECLARE(dispatch_msg)
/*}}}***********************************************************************/

/*{{{STX_MSG_ENTRY_DECLARE**************************************************/
/**/STX_MSG_ENTRY_DECLARE(on_play)
/**/STX_MSG_ENTRY_DECLARE(on_stop)
/**/STX_MSG_ENTRY_DECLARE(on_query_obj)
/**/STX_MSG_ENTRY_DECLARE(at_BreakPin)
/*}}}***********************************************************************/

/*{{{STX_BEGIN_MSG_MAP******************************************************/
STX_BEGIN_MSG_MAP(the_msg_data)
/* to do : add msg process entry here; */
/**/ON_STX_MSG(STX_MSG_Play,on_play)
/**/ON_STX_MSG(STX_MSG_Stop,on_stop)
/**/ON_STX_MSG(STX_MSG_QueryObject,on_query_obj)
/**/ON_STX_MSG(STX_MSG_BreakPin,at_BreakPin)
STX_END_MSG_MAP
/*}}}***********************************************************************/

/*{{{STX_DISPATCH_MSG_PROC**************************************************/
STX_DISPATCH_MSG_PROC( dispatch_msg,the_msg_data )
/*}}}***********************************************************************/

static const char* g_szGraphEditPlayWindow = "StreamX GraphEdit PlayWindow";

STX_COM_MAP_BEGIN(play_window)
/**/STX_COM_MAP_ITEM(STX_IID_BasePlugin)
/**/STX_COM_MAP_ITEM(STX_IID_ActiveMovieWindow)
STX_COM_MAP_END()

STX_NEW_BEGIN(play_window)
{
	STX_SET_THE(stx_base_plugin);
	STX_COM_NEW_DEFAULT(stx_base_plugin,the->stx_base_plugin_vt,stx_base_plugin_vt,
		STX_CLSID_ActiveMovieWindow,STX_CATEGORY_ActiveMovieWindow,g_szGraphEditPlayWindow);

	STX_SET_THE(stx_active_movie_wnd);
	STX_COM_NEW_DEFAULT(stx_active_movie_wnd,the->stx_active_movie_wnd_vt,stx_active_movie_wnd_vt,
		DEFAULT_CODE,DEFAULT_CODE,DEFAULT_CODE);

	the->m_hWnd = NULL;
	the->m_hInstance = NULL;
	the->m_dwColorKey = RGB(19,19,19);
	the->m_bFixAspectRatio = TRUE;
	::InitializeCriticalSection(&the->m_Critic);

	// default value;
	the->m_szBkDir = (char*)xmallocz(1024);
	if( !the->m_szBkDir ) {
		break;
	}
	GetCurrentPath(the->m_szBkDir,1024);
	stx_strcat(the->m_szBkDir,1024,"\\demo.bmp");

}
STX_NEW_END()



STX_PURE 
STX_QUERY_BEGIN(play_window)
{
	STX_COM_QUERY_DEFAULT(stx_base_plugin,the->stx_base_plugin_vt);
	STX_COM_QUERY_DEFAULT(stx_active_movie_wnd,the->stx_active_movie_wnd_vt);
}
STX_QUERY_END()


/***********************************************************************
LxVidActMVW::~LxVidActMVW()
***********************************************************************/
STX_PURE 
STX_DELETE_BEGIN(play_window)
{
	SAFE_XDELETE(the->m_hChildWndPlugin);
	SAFE_XDELETE(the->m_hChildActiveWnd);

	if( the->m_hWnd ) {
		::DestroyWindow(the->m_hWnd);
	}

	if( the->m_szBkDir){
		stx_free(the->m_szBkDir);
	}

	if( the->m_pBkHnd ) {
		delete the->m_pBkHnd;
	}

	::DeleteCriticalSection(&the->m_Critic);

	rem_play_window(the);

	STX_COM_DELETE_DEFAULT(stx_base_plugin);
	STX_COM_DELETE_DEFAULT(stx_active_movie_wnd);
}
STX_DELETE_END
(
	STX_COM_DELETE_BEGIN(stx_base_plugin)
	,
	STX_COM_DELETE_END(stx_base_plugin)
)


LRESULT WINAPI		ClientWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
STX_PRIVATE	LRESULT LxWindowProc(play_window*the,HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);


__inline	void lock_play_window(play_window* the)	{::EnterCriticalSection(&the->m_Critic);}
__inline	void unlock_play_window(play_window* the){::LeaveCriticalSection(&the->m_Critic);}

STX_PRIVATE STX_RESULT on_paint_window(play_window* the);
STX_PRIVATE STX_RESULT on_close_window(play_window* the);
STX_PRIVATE STX_RESULT on_lbtn_dbclick(play_window* the,size_t i_wparam,size_t i_lparam);
STX_PRIVATE STX_RESULT on_rbtn_down(play_window* the,size_t i_wparam,size_t i_lparam);
STX_PRIVATE STX_RESULT on_size(play_window* the,size_t i_wparam,size_t i_lparam);
STX_PRIVATE STX_RESULT on_sizing(play_window* the,size_t i_wparam,size_t i_lparam);
STX_PRIVATE STX_RESULT on_move(play_window* the,size_t i_wparam,size_t i_lparam);

STX_PRIVATE STX_RESULT on_aspect_ratio(play_window* the,stx_base_message* p_msg);

STX_PRIVATE void AdjustPlayWnd(play_window* the,u32 i_aspect);
STX_PRIVATE void FixRectScale( RECT* lpDrect, DWORD dwWhratio);
STX_PRIVATE BOOL FullScreenModeOn(play_window* the);
STX_PRIVATE BOOL FullScreenModeOff(play_window* the);
STX_PRIVATE void ControlFullScreenMode(play_window* the);
STX_PRIVATE void update_dst_rect(play_window* the);

STX_PRIVATE void decide_window_rect
	(play_window* the,u32 i_aspect, b32 b_width_prefer,RECT* p_rect);


/***************************************************************************************
LRESULT WINAPI ClientWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
***************************************************************************************/
LRESULT WINAPI ClientWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	play_window* pVidWnd = play_window_from_hwnd(hwnd);
	if( !pVidWnd ) {  // maybe WM_CREATE msg;
		return DefWindowProc( hwnd, msg, wParam, lParam) ;
	}

	return LxWindowProc(pVidWnd,hwnd,msg, wParam, lParam);
}

/***************************************************************************************
LRESULT LxWindowProc(
HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
***************************************************************************************/
LRESULT LxWindowProc
( play_window* the,HWND hwnd, UINT msg, WPARAM i_wParam, LPARAM i_lParam)
{
	STX_RESULT i_err;

	switch(msg) {

// 	case WM_ERASEBKGND:
// 		return 1L;

	case WM_PAINT:
		i_err = on_paint_window(the);
		return 0L;

// 	case WM_LBUTTONDOWN:
// 	case WM_LBUTTONUP:
// 	case WM_RBUTTONUP:
// 	case WM_RBUTTONDBLCLK:
// 	case WM_MOUSEMOVE:
// 		break;

	case WM_LBUTTONDBLCLK:
		i_err = on_lbtn_dbclick(the,i_wParam,i_lParam);
		return 0L;

	case WM_RBUTTONDOWN:
		i_err = on_rbtn_down(the,i_wParam,i_lParam);
		return 0L;

	case WM_CLOSE:
		i_err = on_close_window(the);
		return 0L;

	case WM_MOVE:
		i_err = on_move(the,i_wParam,i_lParam);
		return 0L;

	case WM_SIZE:
		i_err = on_size(the,i_wParam,i_lParam);
		return 0L;

	case WM_SIZING:
		i_err = on_sizing(the,i_wParam,i_lParam);
		return 1L;

	case WM_ASPECT_RATIO:
		i_err = on_aspect_ratio(the,(stx_base_message*)i_wParam);
		return 0L;
	}

	return ::DefWindowProc(hwnd, msg, i_wParam,i_lParam);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT on_paint_window(play_window* the)
{
	PAINTSTRUCT ps;
	HDC			h_dc,dcMem;
	HBITMAP		bmpMem;
	RECT		rectMem;
	HGDIOBJ		hOldObjMem;


	h_dc = NULL;
	dcMem = NULL;
	bmpMem = NULL;
	hOldObjMem = NULL;

	h_dc = ::BeginPaint(the->m_hWnd,&ps);

	do{

		dcMem = ::CreateCompatibleDC(h_dc);

		::GetClientRect(the->m_hWnd, &rectMem);

		if((rectMem.bottom - rectMem.top) <= 0 || (rectMem.right - rectMem.left) <= 0)	{
			break;
		}

		bmpMem = ::CreateCompatibleBitmap(h_dc, 
			::GetDeviceCaps(h_dc, HORZRES) * 2, 
			::GetDeviceCaps(h_dc, VERTRES) * 2);

		if(!bmpMem)	{
			//        ASSERT(FALSE);
			bmpMem = ::CreateCompatibleBitmap(h_dc, 
				rectMem.right-rectMem.left, rectMem.bottom-rectMem.top);

			if(!bmpMem)	{
				break;
			}
		}

		hOldObjMem = ::SelectObject(dcMem, bmpMem);
		::SetWindowOrgEx(dcMem, rectMem.left, rectMem.top, NULL);

		s32 i_status = theGraphEdit->get_graph_status();

		if( ( i_status != emStxStatusInit && i_status != emStxStatusReady ) || !the->m_pBkHnd )	{		

			HBRUSH hBrush = ::CreateSolidBrush(RGB(0,0,0));
			FillRect(dcMem, &rectMem, hBrush);
			DeleteObject(hBrush);

			BitBlt( h_dc, 
				rectMem.left, rectMem.top, 
				rectMem.right-rectMem.left, 
				rectMem.bottom-rectMem.top, 
				dcMem, 
				rectMem.left, rectMem.top,
				SRCCOPY);

		}
		else {
			HBITMAP hBk = the->m_pBkHnd->GetResizeHandle(  h_dc, 
				rectMem.right - rectMem.left,  
				rectMem.bottom - rectMem.top);

			::SelectObject(dcMem,hBk);

			::BitBlt(h_dc, 
				rectMem.left, rectMem.top, 
				rectMem.right-rectMem.left, 
				rectMem.bottom-rectMem.top, 
				dcMem, 
				rectMem.left, 
				rectMem.top, 
				SRCCOPY);		
		}

		SelectObject(dcMem, hOldObjMem);

	}while(FALSE);

	if( bmpMem ) {
		::DeleteObject(bmpMem);
	}
	if( dcMem ) {
		::DeleteDC(dcMem);
	}
	::ReleaseDC(the->m_hWnd,h_dc);

	EndPaint(the->m_hWnd, &ps);

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT on_close_window(play_window* the)
{
	theGraphEdit->on_close_play_window(&the->stx_base_plugin_vt); 
	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
extern stx_base_graph_builder* g_gbd;

STX_PURE STX_RESULT stx_active_movie_wnd_vt_xxx_create
(STX_HANDLE h,stx_base_plugin *p_parent)
{
	_MAP_THE;
	{
		STX_RESULT		i_err;
		char			class_name[64];
		stx_gid			class_gid;
		RECT			dst_rect;
		HWND			h_child_wnd;
		stx_base_com*	p;

		do{

			i_err = STX_FAIL;
			p = NULL;

			// default value;
			the->m_width = 800;
			the->m_height = 500;
			the->m_aspect_ratio = MAKE_LXRATIO( 16 , 10);

			// load background bitmap;

			the->m_pBkHnd = new LxBmpHandle;
			if( !the->m_pBkHnd ){
				break;
			}

			if( LX_OK != the->m_pBkHnd->LoadBmp(the->m_szBkDir) ) {
				::MessageBox(NULL,"demo.bmp load failed.",NULL,MB_OK);
				break;
			}

			if( LX_OK != the->m_pBkHnd->GetSrcSize(&the->m_width,&the->m_height) ) {
				break;
			}

			class_gid = stx_gid_create();
			binary_to_string(sizeof(stx_gid),(u8*)&class_gid,class_name);

			the->m_wc.cbSize = sizeof( WNDCLASSEX);
			the->m_wc.style = CS_VREDRAW | CS_HREDRAW |CS_DBLCLKS;
			the->m_wc.lpfnWndProc = ClientWndProc;
			the->m_wc.cbClsExtra = 0;
			the->m_wc.cbWndExtra = 0;
			the->m_wc.hInstance = AfxGetInstanceHandle() ;
			the->m_wc.hIcon = LoadIcon(the->m_wc.hInstance, MAKEINTRESOURCE(IDR_MAINFRAME));
			the->m_wc.hIconSm = LoadIcon(the->m_wc.hInstance, MAKEINTRESOURCE(IDR_MAINFRAME));
			the->m_wc.hCursor = LoadCursor(NULL, IDC_ARROW);
			the->m_wc.hbrBackground = (HBRUSH__ *)(GetStockObject(WHITE_BRUSH));
			the->m_wc.lpszMenuName = NULL;
			the->m_wc.lpszClassName = class_name;

			if(!RegisterClassEx(&the->m_wc))	{
				MessageBeep(0);
				break;
			}

			the->m_hWnd = CreateWindowEx(	WS_EX_ACCEPTFILES,
				class_name,
				"Active Movie Window",

				WS_POPUP 
				| WS_CAPTION
				| WS_THICKFRAME
				| WS_MINIMIZEBOX 
				| WS_MAXIMIZEBOX
				| WS_SYSMENU 
				| SC_CLOSE 
				| WS_SIZEBOX 
				| WS_CLIPCHILDREN | WS_CLIPSIBLINGS
				,

				//WS_MINIMIZEBOX | WS_MAXIMIZEBOX
				//| WS_SYSMENU | WS_POPUP | WS_THICKFRAME
				//| WS_CLIPCHILDREN | WS_CLIPSIBLINGS,

				GetSystemMetrics(SM_CXSCREEN) / 2 - the->m_width / 2 , 
				GetSystemMetrics(SM_CYSCREEN) / 8,
				the->m_width,
				the->m_height,
				NULL,
				NULL,
				the->m_wc.hInstance,
				NULL);

			if( !the->m_hWnd ) {
				break;
			}

			::ShowWindow(the->m_hWnd,SW_SHOW);

			add_play_window(the,the->m_hWnd);

			i_err = g_gbd->co_create_obj(g_gbd,STX_CLSID_ActiveMovieWindow,&p);
			if( STX_OK != i_err ){
				break;
			}

			i_err = p->query_interf(p,STX_IID_BasePlugin,(void**)&the->m_hChildWndPlugin);
			if( STX_OK != i_err ){
				break;
			}

			i_err = the->m_hChildWndPlugin->query_interf(the->m_hChildWndPlugin,
				STX_IID_ActiveMovieWindow,(void**)&the->m_hChildActiveWnd );
			if( STX_OK != i_err ){
				break;
			}

			i_err = the->m_hChildActiveWnd->create(the->m_hChildActiveWnd,&the->stx_base_plugin_vt);
			if( STX_OK != i_err ) {
				break;
			}

			::GetClientRect(the->m_hWnd,&dst_rect);
			::ClientRectToScreen(the->m_hWnd,&dst_rect);

			the->m_hChildActiveWnd->set_dst_rect(the->m_hChildActiveWnd,*(STX_RECT*)&dst_rect);

			// under vista, color key will not be used by video render;
			the->m_hChildActiveWnd->set_color_key(the->m_hChildActiveWnd,the->m_dwColorKey);

			h_child_wnd = (HWND)the->m_hChildActiveWnd->get_hwnd(the->m_hChildActiveWnd);

			::ShowWindow(h_child_wnd,SW_HIDE);

			i_err = STX_OK;

		}while(FALSE);

		SAFE_XDELETE(p);

		return i_err;

	}

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT on_lbtn_dbclick
(play_window* the,size_t i_wparam,size_t i_lparam)
{
	// maximize / restore window;
	ControlFullScreenMode(the);

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT on_rbtn_down
(play_window* the,size_t i_wparam,size_t i_lparam)
{
	STX_RESULT		i_err;
	s32				i_caps;
	s32             i_status;
	POINT			pot;
	HMENU			hMain;

	i_err = STX_FAIL;
	hMain = NULL;

	::GetCursorPos(&pot);

	i_caps = theGraphEdit->get_graph_caps();
	i_status = theGraphEdit->get_graph_status();

	// create/tack main menu;

	do{
		hMain = CreatePopupMenu();
		if( !hMain ) {
			break;
		}

		::InsertMenu(hMain, 0, MF_BYPOSITION, WM_PLAY,"play");
		::InsertMenu(hMain, 1, MF_BYPOSITION, WM_PAUSE,"pause");
		::InsertMenu(hMain, 2, MF_BYPOSITION, WM_RESUME,"resume");
		::InsertMenu(hMain, 3, MF_BYPOSITION, WM_STOP,"stop");

		if( i_caps & CTL_CAPS_PLAY_STOP ) {
			EnableMenuItem(hMain , WM_PLAY , MF_ENABLED);
			EnableMenuItem(hMain , WM_STOP , MF_ENABLED);
		}
		else{
			EnableMenuItem(hMain , WM_PLAY , MF_DISABLED);
			EnableMenuItem(hMain , WM_STOP , MF_DISABLED);
		}

		if( i_status == emStxStatusInit || i_status == emStxStatusStop ) {
			EnableMenuItem(hMain , WM_PLAY , MF_ENABLED);
			EnableMenuItem(hMain , WM_STOP , MF_DISABLED);
		}
		else{
			EnableMenuItem(hMain , WM_PLAY , MF_DISABLED);
			EnableMenuItem(hMain , WM_STOP , MF_ENABLED);
		}

		if( i_status == emStxStatusPause ) {
			EnableMenuItem(hMain , WM_RESUME , MF_ENABLED);
			EnableMenuItem(hMain , WM_PAUSE , MF_DISABLED);
		}
		else{
			EnableMenuItem(hMain , WM_RESUME , MF_DISABLED);
			EnableMenuItem(hMain , WM_PAUSE , MF_ENABLED);
		}
		
		UINT wCmd = ::TrackPopupMenu(hMain, TPM_RETURNCMD|TPM_NONOTIFY, 
			pot.x, pot.y, 0, the->m_hWnd, NULL);

		theGraphEdit->graph_cmd(wCmd);

		i_err = STX_OK;

	}while(FALSE);

	::DestroyMenu(hMain);

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT on_move
(play_window* the,size_t i_wparam,size_t i_lparam)
{
	RECT dst_rect;

	::GetClientRect(the->m_hWnd,&dst_rect);
	::ClientRectToScreen(the->m_hWnd,&dst_rect);
	theGraphEdit->set_dst_rect(dst_rect);

	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE void decide_window_rect
(play_window* the,u32 i_aspect, b32 b_width_prefer,RECT* p_rect)
{
	RECT rect_scr;
	RECT rect_client;

	RECT rc = *p_rect;

	int nWidth = rc.right - rc.left;
	int nHeight = rc.bottom - rc.top;

	::GetClientRect(the->m_hWnd,&rect_client);
	::ClientRectToScreen(the->m_hWnd, &rect_client);
	::GetWindowRect(the->m_hWnd,&rect_scr);

	int nx = rect_client.left - rect_scr.left;
	int ny = rect_scr.bottom - rect_client.bottom;
	int nc = rect_client.top - rect_scr.top;

	nWidth -= nx + nx;
	nHeight -= nc + ny;

	if( b_width_prefer ) {
		nHeight = GetHeightFromRatio(nWidth,i_aspect);
		if( nHeight < WND_MIN_HEIGHT ) {
			nHeight = WND_MIN_HEIGHT;
			nWidth = GetWidthFromRatio(nHeight,i_aspect);
		}
	}
	else {
		nWidth = GetWidthFromRatio(nHeight,i_aspect);
		if( nWidth < WND_MIN_WIDTH ) {
			nWidth = WND_MIN_WIDTH;
			nHeight = GetHeightFromRatio(nWidth,i_aspect);
		}
	}

	nWidth += nx + nx;
	nHeight += nc + ny;

	SIZE size = {0};
	::GetFullScreenSize(size,FALSE);

	if( nWidth > size.cx ) {
		nWidth = size.cx - nx - nx;
		nHeight = ::GetHeightFromRatio(nWidth,i_aspect);
		nWidth += nx + nx;
		nHeight += nc + ny;
	}

	if( nHeight > size.cy ) {
		nHeight = size.cy - nc - ny;
		nWidth = ::GetWidthFromRatio(nHeight,i_aspect);
		nWidth += nx + nx;
		nHeight += nc + ny;
	}

	rc.right = rc.left + nWidth;
	rc.bottom = rc.top + nHeight;

	*p_rect = rc;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT on_sizing
(play_window* the,size_t i_wparam,size_t i_lparam)
{
	// check aspect ratio 
	RECT  wrect;
	DWORD dwSrcRatio;
	int   nSrcWidth;
	int   nSrcHeight;

	u32   nType = (u32)i_wparam;
	RECT* prect = (RECT*)i_lparam;

	if( emStxStatusInit == theGraphEdit->get_graph_status() ) {
		if( !the->m_pBkHnd ) {
			return STX_OK;
		}
		if( LX_OK != the->m_pBkHnd->GetSrcSize(&nSrcWidth,&nSrcHeight) ) {
			return STX_OK;
		}
		dwSrcRatio = MAKE_LXRATIO(nSrcWidth,nSrcHeight);
	}
	else {
		dwSrcRatio = the->m_aspect_ratio;
	}

	BOOL bWidthPrefer = ( nType == WMSZ_RIGHT || nType == WMSZ_LEFT  ) ? TRUE:FALSE;

	RECT rc = *prect;

	decide_window_rect(the,dwSrcRatio,bWidthPrefer,&rc);

	*prect = rc;

	::GetClientRect(the->m_hWnd,&wrect);
	::InvalidateRect(the->m_hWnd,&wrect,TRUE);

	update_dst_rect(the);

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT on_size
(play_window* the,size_t i_wparam,size_t i_lparam)
{
	switch(i_wparam){

	case SIZE_MAXIMIZED:
		the->m_bMaximizeScreen = TRUE;
		update_dst_rect(the);
		break;

	case SIZE_RESTORED:
		the->m_bMaximizeScreen = FALSE;
		update_dst_rect(the);
		theGraphEdit->show_render(TRUE);
		break;

	case SIZE_MINIMIZED:
		the->m_bMaximizeScreen = FALSE;
		theGraphEdit->show_render(FALSE);
		break;
	}

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE void  AdjustPlayWnd(play_window* the,u32 i_aspect)
{
	RECT WindowRect;

	::GetClientRect(the->m_hWnd,&WindowRect);
	::ClientRectToScreen(the->m_hWnd,&WindowRect);
	WindowRect.right = WindowRect.left + the->m_width;
	WindowRect.bottom = WindowRect.top + the->m_height;

	::decide_window_rect(the,i_aspect,TRUE,&WindowRect);

	::MoveWindow(the->m_hWnd,
		WindowRect.left,
		WindowRect.top,
		WindowRect.right - WindowRect.left,
		WindowRect.bottom - WindowRect.top,
		TRUE);

	::GetClientRect(the->m_hWnd,&WindowRect);
	::InvalidateRect(the->m_hWnd,&WindowRect,TRUE);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT on_aspect_ratio
(play_window* the,stx_base_message* p_msg)
{
	// 
	stx_msg_cnt* cnt;

	cnt = p_msg->get_msg_cnt(p_msg);

	the->m_width = (s32)cnt->param.i_param[0];
	the->m_height = (s32)cnt->param.i_param[1];
	the->m_aspect_ratio = (s32)cnt->param.i_param[2];

	if( the->m_bFullScreen || the->m_bMaximizeScreen ) {
		if( the->m_bFixAspectRatio && !the->m_force_aspect_ratio ) {
			update_dst_rect(the);
		}
	}
	else if( the->m_bFixAspectRatio && !the->m_force_aspect_ratio){
		AdjustPlayWnd(the,the->m_aspect_ratio);
		update_dst_rect(the);
	}

	p_msg->signal(p_msg);

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
this function calling from kernel thread -> video render task;
so wait for winthread adjust the aspect raio, and return;
***************************************************************************/
STX_PURE STX_RESULT stx_active_movie_wnd_vt_xxx_set_aspect_ratio
(STX_HANDLE h,u32 i_width,u32 i_height,u32 i_aspect)
{
	_MAP_THE;
	{
		STX_RESULT			i_err;
		stx_base_message*	p_msg;
		stx_msg_cnt*		p_cnt;

		do{

			p_msg = XCREATE(base_msg,NULL,NULL);
			if( !p_msg ) {
				break;
			}
			p_msg->set_msg_type(p_msg,STX_MSG_TYPE_ASYNC );
			p_cnt = p_msg->get_msg_cnt(p_msg);
			p_cnt->msg_gid = STX_MSG_AspectRatio;
			p_cnt->param.i_param[0] = i_width;
			p_cnt->param.i_param[1] = i_height;
			p_cnt->param.i_param[2] = i_aspect;

			::PostMessage(the->m_hWnd,WM_ASPECT_RATIO,(WPARAM)p_msg,0);

			p_msg->wait(p_msg);

			i_err = STX_OK;

		}while(FALSE);

		SAFE_XDELETE(p_msg);

		return i_err;

	}

	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE void stx_active_movie_wnd_vt_xxx_set_dst_rect
(STX_HANDLE h,STX_RECT dst_rect)
{
	_MAP_THE;
	{

	}
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RECT 
stx_active_movie_wnd_vt_xxx_get_dst_rect(STX_HANDLE h)
{
	_MAP_THE;
	{
		RECT rec;
		::GetClientRect(the->m_hWnd,&rec);
		::ClientRectToScreen(the->m_hWnd,&rec);
		return *(STX_RECT*)&rec;
	}
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE void stx_active_movie_wnd_vt_xxx_set_color_key
(STX_HANDLE h,u32 i_color_key)
{
	_MAP_THE;
	{
		the->m_dwColorKey = i_color_key;
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE u32 
stx_active_movie_wnd_vt_xxx_get_color_key(STX_HANDLE h)
{
	_MAP_THE;
	{
		return the->m_dwColorKey;
	}
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_HANDLE 
stx_active_movie_wnd_vt_xxx_get_hwnd(STX_HANDLE h)
{
	_MAP_THE;
	return (STX_HANDLE)the->m_hWnd;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE  STX_HANDLE 
stx_active_movie_wnd_vt_xxx_get_active_hwnd(STX_HANDLE h)
{
	_MAP_THE;
	return the->m_hChildActiveWnd->get_hwnd(the->m_hChildActiveWnd);
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_HANDLE 
stx_active_movie_wnd_vt_xxx_get_hinstance(STX_HANDLE h)
{
	_MAP_THE;
	{
		return the->m_hInstance;
	}
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_plugin_vt_xxx_run
(STX_HANDLE h,stx_sync_inf* h_sync)
{
	_MAP_THE;
	{
	}

	return STX_OK;
}
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_plugin_vt_xxx_flush
(STX_HANDLE h,u32 i_flag,stx_sync_inf *h_sync)
{
	_MAP_THE;
	{
	}

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_plugin_vt_xxx_start
(STX_HANDLE h,u32 i_flag,stx_sync_inf *h_sync)
{
	_MAP_THE;
	{
	}

	return STX_OK;
}
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_plugin_vt_xxx_stop
(STX_HANDLE h,u32 i_flag,stx_sync_inf *h_sync)
{
	_MAP_THE;
	{
	}

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_plugin_vt_xxx_send_msg
(STX_HANDLE h,stx_base_message *p_msg)
{
	_MAP_THE;
	{
		return dispatch_msg(h,p_msg);
	}
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_plugin_vt_xxx_set_property
(STX_HANDLE h,stx_xio *h_xio)
{
	_MAP_THE;
	{
		// back ground file path name ???
		// auto fix aspect raito ???
		// top most ???
	}

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_plugin_vt_xxx_get_property
(STX_HANDLE h,stx_xio *h_xio)
{
	_MAP_THE;
	{
	}

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE void FixRectScale( RECT* lpDrect, DWORD dwWhratio)
{
	DWORD dheight = (lpDrect->bottom - lpDrect->top);
	DWORD dwidth = (lpDrect->right - lpDrect->left);
	DWORD dhwcoe = MAKE_LXRATIO(dwidth,dheight);

	if( dwWhratio < dhwcoe ) {
		// wide
		int ddw = dwidth - GetWidthFromRatio(dheight , dwWhratio) + 1;
		ddw >>= 1;
		lpDrect->left += ddw;
		lpDrect->right -= ddw;
	}
	else if( dwWhratio > dhwcoe ) {
		// narrow
		int ddh = dheight - GetHeightFromRatio(dwidth,dwWhratio)  + 1;
		ddh >>= 1;
		lpDrect->top += ddh;
		lpDrect->bottom -= ddh;
	}

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG STX_RESULT on_query_obj(STX_HANDLE h,stx_base_message* p_msg)
{
	_MAP_THE;
	{
		stx_gid			buf_iid;
		stx_msg_cnt*	cnt;
		s32				i_len;

		buf_iid = *(stx_gid*)p_msg->get_msg_buf(p_msg,&i_len);

		// ActiveMovieWindow
		if( IS_EQUAL_GID(STX_IID_ActiveMovieWindow,buf_iid) ) {

			the->m_hChildActiveWnd->add_ref(the->m_hChildActiveWnd);

			cnt = p_msg->get_msg_cnt(p_msg);

			cnt->param.i_param[0] = (size_t)the->m_hChildActiveWnd;

			p_msg->set_msg_close(p_msg);

			return STX_OK;

		} // if( IS_EQUAL_GID(STX_IID_ActiveMovieWindow,buf_iid) ) {

		return STX_OK;
	}
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG STX_RESULT on_play(STX_HANDLE h,stx_base_message* p_msg)
{
	_MAP_THE;
	{
		HWND h_child_wnd = (HWND)the->m_hChildActiveWnd->get_hwnd(the->m_hChildActiveWnd);
		::ShowWindow(h_child_wnd,SW_SHOW);
	}
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG STX_RESULT on_stop(STX_HANDLE h,stx_base_message* p_msg)
{
	_MAP_THE;
	{
		HWND h_child_wnd = (HWND)the->m_hChildActiveWnd->get_hwnd(the->m_hChildActiveWnd);
		::ShowWindow(h_child_wnd,SW_HIDE);
	}

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG_ENTRY STX_RESULT 
at_BreakPin(STX_HANDLE h, stx_base_message* p_msg )
{
	_MAP_THE;
	{
		HWND h_child_wnd = (HWND)the->m_hChildActiveWnd->get_hwnd(the->m_hChildActiveWnd);
		::ShowWindow(h_child_wnd,SW_HIDE);
	}
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE void ControlFullScreenMode(play_window* the)
{
	if(::IsIconic(the->m_hWnd))	{
		::ShowWindow(the->m_hWnd, SW_NORMAL);
		::BringWindowToTop(the->m_hWnd);
		::SetForegroundWindow(the->m_hWnd);
	}

	if(!the->m_bFullScreen ){
		FullScreenModeOn(the);
	}
	else{
		FullScreenModeOff(the);	
	}

	update_dst_rect(the);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE BOOL FullScreenModeOff(play_window* the)
{
	if( the->m_bFullScreen)	{

		the->m_bFullScreen = FALSE;

		LONG style = ::GetWindowLong(the->m_hWnd, GWL_STYLE);
		style |= WS_CAPTION ;
		style |= WS_BORDER ;
		style |= WS_THICKFRAME;

		::SetWindowLong(the->m_hWnd, GWL_STYLE,style);

		::MoveWindow(the->m_hWnd, the->m_rt.left, the->m_rt.top, 
			the->m_rt.right - the->m_rt.left, 
			the->m_rt.bottom - the->m_rt.top,
			TRUE);

		if( the->m_bTopMost ){
			::SetWindowPos(the->m_hWnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE);
		}
		else{
			::SetWindowPos(the->m_hWnd, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE);
		}

	}

	return TRUE;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE BOOL FullScreenModeOn(play_window* the)
{	
	if(!the->m_bFullScreen){

		the->m_bFullScreen = TRUE;

		::GetWindowRect(the->m_hWnd, &the->m_rt);

		//��ȥ���ڵı�����
		LONG style = ::GetWindowLong(the->m_hWnd, GWL_STYLE);
		style &= ~WS_CAPTION ;
		style &= ~WS_BORDER ;
		style &= ~WS_THICKFRAME;
		::SetWindowLong(the->m_hWnd, GWL_STYLE,style);

		int nScreenCX = ::GetSystemMetrics(SM_CXSCREEN);
		int nScreenCY = ::GetSystemMetrics(SM_CYSCREEN);

		::SetWindowPos(the->m_hWnd, 
			HWND_NOTOPMOST, 
			0, 
			0,
			nScreenCX, 
			nScreenCY, 
			0);

		::SetForegroundWindow(the->m_hWnd);
	}

	return TRUE;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE void update_dst_rect(play_window* the)
{
	HWND hnd;

	::GetClientRect(the->m_hWnd,&the->m_dst_rect);

	if( the->m_bFixAspectRatio ) {
		if( the->m_force_aspect_ratio ) {
			FixRectScale(&the->m_dst_rect,the->m_force_aspect_ratio);
		}
		else{
			FixRectScale(&the->m_dst_rect,the->m_aspect_ratio);
		}
	}

	the->m_hChildActiveWnd->set_dst_rect(the->m_hChildActiveWnd,the->m_dst_rect);

	hnd = (HWND)the->m_hChildActiveWnd->get_hwnd(the->m_hChildActiveWnd);

// 	{
// 		RECT rc;
// 		::GetWindowRect(hnd,&rc);
// 		stx_log("left =%d, top = %d, right = %d, bottom =%d\r\n",
// 			rc.left,rc.top,rc.right,rc.bottom);
// 	}

	::ClientRectToScreen(hnd,&the->m_dst_rect);
	theGraphEdit->set_dst_rect(the->m_dst_rect);
}

