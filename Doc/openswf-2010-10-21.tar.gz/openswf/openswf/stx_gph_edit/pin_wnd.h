/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-10
***********************************************************************************/
#pragma once

#include "base_pin_wnd.h"


STX_RESULT pin_wnd_OnLButtonDown(base_pin_wnd* the,UINT nFlags, CPoint point);
STX_RESULT pin_wnd_OnLButtonUp(base_pin_wnd* the,UINT nFlags, CPoint point);

STX_RESULT pin_wnd_paint( base_pin_wnd* the,HDC hdc , RECT rc  );
void       pin_wnd_OnSize(base_pin_wnd* the,UINT nType, int cx, int cy);
BOOL       pin_wnd_OnLButtonDblClk(base_pin_wnd* the,UINT nFlags, CPoint point);
BOOL       pin_wnd_OnRButtonDown(base_pin_wnd* the,UINT nFlags, CPoint point);
BOOL       pin_wnd_OnMouseMove(base_pin_wnd* the,UINT nFlags, CPoint point);
BOOL	   pin_wnd_OnSetCursor(base_pin_wnd* the,CWnd* pWnd,UINT nHitTest,UINT message);


STX_RESULT          pin_wnd_create_dlg(base_pin_wnd* the);
STX_RESULT          pin_wnd_create_menu(base_pin_wnd* the,POINT point);
