/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-10
***********************************************************************************/
#include "StdAfx.h"

#include "stx_gbd_hnd.h"

#include "stx_gph_edit.h"
#include "stx_gph_editDlg.h"

#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_API_IMP CREATE_STX_COM(stx_base_plugin,STX_IID_BasePlugin,gbd_hnd);


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_COM_BEGIN(gbd_hnd);
/**/
/**/STX_PUBLIC(stx_base_plugin)
/**/STX_COM_DATA_DEFAULT(stx_base_plugin)
/**/
STX_COM_END();


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_COM_FUNC_DECL_DEFAULT(stx_base_plugin,stx_base_plugin_vt);
STX_COM_FUNCIMP_DEFAULT(gbd_hnd,stx_base_plugin,stx_base_plugin_vt);





/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_COM_MAP_BEGIN(gbd_hnd)
/**/STX_COM_MAP_ITEM(STX_IID_BasePlugin)
STX_COM_MAP_END()

STX_NEW_BEGIN(gbd_hnd)
{
	STX_SET_THE(stx_base_plugin);
	STX_COM_NEW_DEFAULT(stx_base_plugin,the->stx_base_plugin_vt,stx_base_plugin_vt,
		STX_GID_NULL,STX_GID_NULL,"StreamX gbd handler");
}
STX_NEW_END()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_QUERY_BEGIN(gbd_hnd)
{
	STX_COM_QUERY_DEFAULT(stx_base_plugin,the->stx_base_plugin_vt);
}
STX_QUERY_END()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_DELETE_BEGIN(gbd_hnd)
{
	STX_COM_DELETE_DEFAULT(stx_base_plugin);
}
STX_DELETE_END
(
STX_COM_DELETE_BEGIN(stx_base_plugin)
,
STX_COM_DELETE_END(stx_base_plugin)
)

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_base_plugin_vt_xxx_send_msg
(STX_HANDLE h,stx_base_message *p_msg)
{
	STX_MAP_THE(gbd_hnd);

	return theGraphEdit->send_msg(p_msg);
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_base_plugin_vt_xxx_run(STX_HANDLE h,stx_sync_inf* h_sync)
{
	STX_MAP_THE(gbd_hnd);
	return STX_OK;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_base_plugin_vt_xxx_get_property
(STX_HANDLE h,stx_xio* h_xini)
{
	STX_MAP_THE(gbd_hnd);

	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_plugin_vt_xxx_set_property
(STX_HANDLE h,stx_xio *h_xini)
{
	STX_MAP_THE(gbd_hnd);

	return STX_ERR_NOT_SUPPORT;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_plugin_vt_xxx_flush
(STX_HANDLE h,u32 i_flag,stx_sync_inf *h_sync)
{

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_plugin_vt_xxx_start
(STX_HANDLE h,u32 i_flag,stx_sync_inf *h_sync)
{

	return STX_OK;
}
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_base_plugin_vt_xxx_stop
(STX_HANDLE h,u32 i_flag,stx_sync_inf *h_sync)
{
	return STX_OK;
}



