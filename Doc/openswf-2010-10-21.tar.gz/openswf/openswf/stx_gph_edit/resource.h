//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by stx_gph_edit.rc
//
#define ID_BTN_LOAD                     3
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_STX_GPH_EDIT_DIALOG         102
#define IDR_MAINFRAME                   128
#define IDD_DLG_ADDFLT                  129
#define IDR_MENU_MAIN                   130
#define IDD_FLT_DLG                     131
#define IDD_PIN_DLG                     132
#define IDD_DIALOG1                     133
#define IDD_URL_DLG                     133
#define IDD_PRS_DLG                     134
#define IDC_FLT_TREE                    1001
#define IDC_BTN_ADDFLT                  1002
#define IDC_BTN_APPLY                   1003
#define IDC_EDIT_PROP                   1004
#define IDC_TREE_INF                    1005
#define IDC_EDIT1                       1006
#define IDC_EDIT_URL                    1006
#define IDC_EDIT_GPH                    1006
#define IDC_BTN_BROWSE                  1007
#define IDC_BTN_GPH                     1008
#define IDC_LIST_URL                    1009
#define IDC_EDIT_ADD_URL                1010
#define IDC_BTN_ADD                     1011
#define IDC_BTN_REM                     1012
#define IDC_EDIT3                       1013
#define IDC_EDIT_NUM                    1013
#define IDC_IPADDRESS1                  1014
#define IDC_IP                          1014
#define IDC_EDIT_PORT                   1015
#define ID_GRAPH_LOADSTREAM             32771
#define ID_FILE_LOADGRAPH               32772
#define ID_FILE_NEWGRAPH                32773
#define ID_FILE_CLOSEGRAPH              32774
#define ID_FILE_SAVEGRAPH               32775
#define ID_FILE_SAVEGRAPHAS             32776
#define ID_FILTER_ADDFILTER             32777
#define ID_FILTER_ADDFILTERFROMDLL      32778
#define ID_HELP_ABOUT                   32779
#define ID_FILTER_REGISTERFILTER        32780
#define ID_FILTER_UNREGISTERFILTER      32781
#define ID_FILE_RENDFILE                32783
#define ID_GRAPH_RENDRENDER             32785
#define ID_GRAPH_PAUSE                  32786
#define ID_GRAPH_RESUME                 32787
#define ID_GRAPH_STOP                   32788
#define ID_TOOLS_SETUP                  32789
#define ID_FILE_RECENTGRAPH             32790
#define ID_FILE_EXIT                    32791
#define ID_FILE_RECENT                  32792
#define ID_FILTER_REGISTERSTREAM        32793
#define ID_FILTER_UNREGISTERSTREAM      32794
#define ID_FILE_RECENTSTREAM            32796
#define ID_GRAPH_CLOSESTREAM            32797
#define ID_GRAPH_RUNGRAPH               32798
#define ID_GRAPH_RENDPIN                32799
#define ID_GRAPH_OPENFILE               32800
#define ID_TOOLS_PRSMAKER               32801
#define ID_FILTER_VIEWFILTER            32802
#define ID_FILTER_VIEWFILTERFROMDLL     32803
#define ID_FILTER_REGISTERPROTOCOLFILTER 32804
#define ID_FILTER_UNREGISTERPROTOCOLFILTER 32805
#define ID_FILTER_REGISTERSTARTUPMODULE 32806
#define ID_FILTER_UNREGISTERSTARTUPMODULE 32807

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32808
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
