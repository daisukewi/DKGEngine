/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-10
***********************************************************************************/
#include "StdAfx.h"

#include "stx_gph_edit.h"
#include "pin_wnd.h"

#include "pin_set_dlg.h"
#include "stx_canvas.h"

#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif

extern stx_base_graph_builder* g_gbd;
extern stx_base_plugin* g_gbd_hnd;


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT  pin_wnd_create_menu(base_pin_wnd* the,POINT point)
{

	STX_RESULT	i_err;
	HMENU		hMain;
	char		sz_inf[1024];
	char		sz_gid[64];

	i_err = STX_FAIL;
	hMain = NULL;

	do{
		hMain = CreatePopupMenu();
		if( !hMain ) {
			break;
		}

		// pin index
		stx_sprintf(sz_inf,sizeof(sz_inf),"pin index = %d",the->m_iIndex );
		InsertMenu(hMain, 0, MF_BYPOSITION, WM_OUTPUTPIN,sz_inf);

		// major type
		stx_sprintf(sz_inf,sizeof(sz_inf),"major type = %s",the->m_minf.major_type_name);
		InsertMenu(hMain, 1, MF_BYPOSITION, WM_OUTPUTPIN + 1,sz_inf);

		// sub type
		stx_sprintf(sz_inf,sizeof(sz_inf),"sub type = %s",the->m_minf.sub_type_name);
		InsertMenu(hMain, 2, MF_BYPOSITION, WM_OUTPUTPIN + 2,sz_inf);

		// instance id;
		binary_to_string(sizeof(stx_gid),(u8*)&the->m_insid,sz_gid);
		stx_sprintf(sz_inf,sizeof(sz_inf),"instance id = %s",sz_gid);
		InsertMenu(hMain, 3, MF_BYPOSITION, WM_OUTPUTPIN + 3,sz_inf);

		// attach pin
		if( the->m_hPin ) {
			stx_sprintf(sz_inf,sizeof(sz_inf),"attached pin: 0x%I64X",(s64)the->m_hPin);
		}
		else {
			stx_strcpy(sz_inf,sizeof(sz_inf),"not attached");
		}
		InsertMenu(hMain, 4, MF_BYPOSITION, WM_OUTPUTPIN+4,sz_inf);

		if( the->m_hPin && the->m_hPin->is_connected(the->m_hPin,NULL)) {
			stx_strcpy(sz_inf,sizeof(sz_inf),"connected");
		}
		else {
			stx_strcpy(sz_inf,sizeof(sz_inf),"not connected");
		}
		// connected
		InsertMenu(hMain, 5, MF_BYPOSITION, WM_DISCONNECT_PIN, sz_inf);
		if( the->m_hPin && the->m_hPin->is_connected(the->m_hPin,NULL) ) {
			::CheckMenuItem(hMain, WM_DISCONNECT_PIN, MF_CHECKED);
		}

		UINT wCmd = ::TrackPopupMenu(hMain, TPM_RETURNCMD|TPM_NONOTIFY, 
			point.x, point.y, 0, the->m_hWnd, NULL);

		if( WM_DISCONNECT_PIN == wCmd && the->m_hPin && the->m_hPin->is_connected(the->m_hPin,NULL) ){
			::PostMessage(the->m_hWnd,WM_DISCONNECT_PIN,(WPARAM)the->m_fltwnd,(LPARAM)the);
		}

		i_err = STX_OK;

	}while(FALSE);

	if( hMain ) {
		::DestroyMenu(hMain);
	}

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT  pin_wnd_create_dlg(base_pin_wnd* the )
{
	// property;
	pin_set_dlg dlg(NULL,the->m_hPin);

	dlg.DoModal();

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT pin_wnd_paint( base_pin_wnd* the, HDC hdc, RECT rc  )
{
	b32     b_left,b_top,b_right,b_bottom;
	s32		left;
	s32		top;
	s32		right;
	s32		bottom;

	HGDIOBJ hBrush,hRestore;

	s32		i_pix;


	b_left = the->m_pos.left < rc.left ? FALSE : TRUE;
	b_top = the->m_pos.top < rc.top ? FALSE : TRUE;
	b_right = the->m_pos.right >= rc.right ? FALSE : TRUE;
	b_bottom = the->m_pos.bottom >= rc.bottom ? FALSE : TRUE;

	left = b_left ?  the->m_pos.left:rc.left ;
	top = b_top ? the->m_pos.top: rc.top ;
	right = b_right ? the->m_pos.right : rc.right;
	bottom = b_bottom ? the->m_pos.bottom : rc.bottom;

	if( b_left && b_top ) {

		POINT pt;
		::GetCursorPos(&pt);
		::ScreenToClient(the->m_hWnd,&pt);

		if( ::PtInRect(&the->m_pos,pt) ) {

			COLORREF c = SetTextColor(hdc,RGB(0,0,255));

			if( the->m_hPin ) {

				stx_media_type* pmt = the->m_hPin->get_media_type(the->m_hPin);
				if( !pmt) {
					return STX_FAIL;
				}
				const char* sz_type = pmt->get_subtype_name(pmt);
				if(sz_type ){
					TextOut(hdc,
						left + TITLE_LEFT, top + TITLE_TOP,
						sz_type, 
						(s32)strlen(sz_type) );
				}
				else{
					TextOut(hdc,
						left + TITLE_LEFT, top + TITLE_TOP,
						*the->m_minf.sub_type_name, 
						(s32)strlen(*the->m_minf.sub_type_name) );
				}
				pmt->release(pmt);
			}
			else{
				TextOut(hdc,
					left + TITLE_LEFT, top + TITLE_TOP,
					*the->m_minf.sub_type_name, 
					(s32)strlen(*the->m_minf.sub_type_name) );
			}

			SetTextColor(hdc,c);
		}
	}// output title;

	i_pix = the->m_bFocus ? 2 : 1;;

	if( the->m_hPin ) {
		if( the->m_hPin->is_connected(the->m_hPin,NULL)) { //solid, red;
			hBrush = ::CreatePen( PS_SOLID,i_pix,RGB(255,0,0) );
		}
		else{ //solid blue,
			hBrush = ::CreatePen( PS_SOLID,i_pix,RGB(0,0,0) );
		}
	}
	else { // dot,blue
		hBrush = ::CreatePen( PS_DOT,i_pix,RGB(0,0,0) );
	}

	hRestore = ::SelectObject(hdc,hBrush ); 

	::MoveToEx(hdc,left,top,(LPPOINT) NULL);

	if( b_left ) {
		::LineTo(hdc,left,bottom);
		::MoveToEx(hdc,left,top,(LPPOINT) NULL);
	}

	if( b_top ) {
		::LineTo(hdc,right,top);
	}

	::MoveToEx(hdc,right,bottom,(LPPOINT) NULL);

	if( b_right ) {
		::LineTo(hdc,right,top);
		::MoveToEx(hdc,right,bottom,(LPPOINT) NULL);
	}

	if( b_bottom ) {
		::LineTo(hdc,left,bottom);
	}

	if( hRestore ) {
		::SelectObject(hdc,hRestore);
	}

	if( hBrush ) {
		::DeleteObject(hBrush);
	}

	return STX_OK;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
BOOL pin_wnd_OnMouseMove(base_pin_wnd* the,UINT nFlags, CPoint point)
{
	return FALSE;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
BOOL pin_wnd_OnLButtonDblClk(base_pin_wnd* the,UINT nFlags, CPoint point)
{
	if( !::PtInRect(&the->m_pos,point)) {
		return FALSE;
	}

	pin_wnd_create_dlg(the);

	return TRUE;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

BOOL pin_wnd_OnRButtonDown(base_pin_wnd* the,UINT nFlags, CPoint point)
{
	if( !::PtInRect(&the->m_pos,point)) {
		return FALSE;
	}

	POINT pt;
	::GetCursorPos(&pt);
	pin_wnd_create_menu(the,pt);

	return TRUE;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT pin_wnd_OnLButtonDown(base_pin_wnd* the,UINT nFlags, CPoint point)
{
	if( ::PtInRect(&the->m_pos,point ) ) {
		if( !the->m_bFocus ) {
			the->m_bFocus = TRUE;
		}
		return STX_RET_CONNECT;
	}
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT pin_wnd_OnLButtonUp(base_pin_wnd* the,UINT nFlags, CPoint point)
{

	if( !::PtInRect(&the->m_pos,point)) {
		if( the->m_bFocus ) {
			the->m_bFocus = FALSE;
			return STX_RET_HIT;
		}
		return STX_OK;
	}

	if( the->m_bFocus ) {
		the->m_bFocus = FALSE;
		return STX_RET_HIT;
	}

	return STX_RET_CONNECT;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void pin_wnd_OnSize(base_pin_wnd* the,UINT nType, int cx, int cy)
{

}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
BOOL pin_wnd_OnSetCursor(base_pin_wnd* the,CWnd* pWnd,UINT nHitTest,UINT message)
{
	return FALSE;
}


