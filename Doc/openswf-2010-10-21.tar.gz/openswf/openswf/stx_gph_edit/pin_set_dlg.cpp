/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-10
***********************************************************************************/
// pin_set_dlg.cpp : implementation file
//

#include "stdafx.h"

#include "stx_gph_edit.h"
#include "pin_set_dlg.h"

#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif

// pin_set_dlg dialog

IMPLEMENT_DYNAMIC(pin_set_dlg, CDialog)

pin_set_dlg::pin_set_dlg(CWnd* pParent,stx_base_pin* h_pin)
	: CDialog(pin_set_dlg::IDD, pParent)
{
	m_hPin = h_pin;
}

pin_set_dlg::~pin_set_dlg()
{
}

void pin_set_dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(pin_set_dlg, CDialog)
	ON_BN_CLICKED(IDOK, &pin_set_dlg::OnBnClickedOk)
END_MESSAGE_MAP()


// pin_set_dlg message handlers

void pin_set_dlg::OnBnClickedOk()
{
	// TODO: Add your control notification handler code here

	CString sz_inf;

	GetDlgItem(IDC_EDIT_PROP)->GetWindowText(sz_inf);

	stx_xio*	h_stream;
	STX_RESULT	i_err;

	h_stream = NULL;
	i_err = STX_FAIL;

	do{
		DECL_TRACE

		size_t i_data;

		s32 i_len = sz_inf.GetLength();
		char* sz_buf = sz_inf.GetBuffer();

		if( !i_len ) {
			break ;
		}

		h_stream = XCREATE(stx_io_stream,NULL);
		if( !h_stream ) {
			break;
		}

		h_stream->write(h_stream,sz_buf,i_len+1,&i_data);

		i_err = m_hPin->set_property(m_hPin,h_stream );
		if( STX_OK != i_err ) {
			break;
		}

		i_err = STX_OK;

	}while(FALSE);

	if( h_stream ) {
		h_stream->close(h_stream);
	}

	OnOK();
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_RESULT  pin_set_dlg::init_prop()
{
	STX_RESULT		i_err;
	stx_xio*		h_stream;
	stx_io_op_param	inf;

	i_err = STX_FAIL;

	h_stream = NULL;
	INIT_MEMBER(inf);

	do{

		h_stream = XCREATE(stx_io_stream,NULL);
		if( !h_stream ) {
			break;
		}

		i_err = m_hPin->get_property(m_hPin,h_stream);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = h_stream->get(h_stream,STX_IO_READ_P,&inf);
		if( STX_OK != i_err ) {
			break;
		}

		GetDlgItem(IDC_EDIT_PROP)->SetWindowText(inf.buf);

		i_err = STX_OK;

	}while(FALSE);

	if( h_stream ) {
		h_stream->close(h_stream);
	}

	return i_err;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

BOOL pin_set_dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// todo;

	if( !m_hPin ) {
		GetDlgItem(IDC_EDIT_PROP)->EnableWindow(FALSE);
		GetDlgItem(IDOK)->EnableWindow(FALSE);
		return TRUE;
	}

	// init propetry;
	if( STX_OK != init_prop() ) {
		GetDlgItem(IDC_EDIT_PROP)->EnableWindow(FALSE);
		GetDlgItem(IDOK)->EnableWindow(FALSE);
		return TRUE;
	}

	return TRUE;
}
