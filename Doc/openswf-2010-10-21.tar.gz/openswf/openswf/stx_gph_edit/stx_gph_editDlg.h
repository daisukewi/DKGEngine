/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-10
***********************************************************************************/
// stx_gph_editDlg.h : header file
//

#pragma once


// Cstx_gph_editDlg dialog
class Cstx_gph_editDlg : public CDialog
{
// Construction
public:
	Cstx_gph_editDlg(CWnd* pParent = NULL);	// standard constructor
	virtual ~Cstx_gph_editDlg();

// Dialog Data
	enum { IDD = IDD_STX_GPH_EDIT_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	int LoadGraph();
	int NewGraph();
	int CloseGraph();
	int SaveGraph();

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnLoadGraph();
	afx_msg void OnNewGraph();
	afx_msg void OnRendStream();
	afx_msg void OnCloseGraph();
	afx_msg void OnSaveGraph();
	afx_msg void OnSaveGraphAs();
	afx_msg void OnViewFilter();
	afx_msg void OnViewFilterFromDLL();
	afx_msg void OnAddFilter();
	afx_msg void OnAddFilterFromDLL();
	afx_msg void OnRegisterFilter();
	afx_msg void OnUnRegisterFilter();
	afx_msg void OnRegisterStream();
	afx_msg void OnUnRegisterStream();
	afx_msg void OnRegisterProtocolFilter();
	afx_msg void OnUnRegisterProtocolFilter();
	afx_msg void OnRegisterStartModule();
	afx_msg void OnUnRegisterStartModule();
	afx_msg void OnLoadStream();
	afx_msg void OnOpenFile();
	afx_msg void OnCloseStream();
	afx_msg void OnRendPin();
	afx_msg void OnRendRender();
	afx_msg void OnRunGraph();
	afx_msg void OnPause();
	afx_msg void OnResume();
	afx_msg void OnStop();
	afx_msg void OnPrsMaker();
// 	afx_msg LRESULT OnEraseBkgnd(WPARAM wparam,LPARAM lparam) 
// 	{
// 		return 1;
// 	}
	afx_msg LRESULT	OnPaintCanvas(WPARAM wparam,LPARAM lparam);
	afx_msg LRESULT	OnAddFlt(WPARAM wparam,LPARAM lparam);
	afx_msg LRESULT	OnFltResize(WPARAM wparam,LPARAM lparam);
	afx_msg LRESULT	OnAutoStop(WPARAM wparam,LPARAM lparam);


	afx_msg void       OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void       OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void       OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void       OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void       OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void       OnSize(UINT nType, int cx, int cy);
	afx_msg void       OnSizing(UINT nType, LPRECT prect );

	afx_msg void       OnDropFiles(HDROP hDropInfo);
	afx_msg BOOL	   OnSetCursor(CWnd* pWnd,UINT nHitTest,UINT message );

	afx_msg void OnHScroll(UINT nSBCode,UINT nPos,CScrollBar* pScrollBar);
	afx_msg void OnVScroll(UINT nSBCode,UINT nPos,CScrollBar* pScrollBar);


	DECLARE_MESSAGE_MAP()


public :

	int  attach_active_movie_wnd(void* p_msg);

	void on_close_play_window(void* plugin);
	void set_dst_rect(RECT dst_rect);
	void show_render(BOOL bShow);
	int  get_graph_status();
	int  get_graph_caps();
	void graph_cmd(int i_cmd);

	void cleanup();

	void OnAddFilterDlgClosed();
	int send_msg(void* p);

private:

	char*        m_szGraphName;

	int          m_iMaxGraph;
	CStringArray m_szLastGraph;

	CMenu m_menu;
	char* m_szLastPath;

	int   LoadConfig();
	void  SaveConfig();
	void  UpdateMenu();
	void  InitMenu();
};

char*	make_filter_string(char* buf, size_t i_size,const char* sz_desc,const char* sz_ext);

char*	SaveGraphFile(HWND hwnd,char* sz_last_path);
char*	OpenGraphFile(HWND hwnd,char* sz_last_path);

char*	SavePrsFile(HWND hwnd,char* sz_last_path);
char*	OpenPrsFile(HWND hwnd,char* sz_last_path);

char*	SaveTypedFile(HWND hwnd,char* sz_last_path,const char* sz_desc,const char* sz_ext);
char*	OpenTypedFile(HWND hwnd,char* sz_last_path,const char* sz_desc,const char* sz_ext);

extern Cstx_gph_editDlg* theGraphEdit;

