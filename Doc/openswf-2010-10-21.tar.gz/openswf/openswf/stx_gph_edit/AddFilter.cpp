/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-10
***********************************************************************************/
// AddFilter.cpp : implementation file
//

#include "stdafx.h"
#include "stx_gph_edit.h"
#include "stx_gph_editDlg.h"
#include "AddFilter.h"



#include "stx_all.h"

#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif

enum stx_item_type{
	em_src,
	em_med,
	em_rnd,
	em_writer,
	em_other,
	em_filter,
	em_clsid,
	em_clsid_name,
	em_path_name,
	em_main_cat,
	em_cat_desc,
	em_comhelper, //
	em_interface, //
	em_majortype,
	em_majortype_n,
	em_majortype_name,
	em_subtype,
	em_subtype_name,
	em_stream_type,
	em_stream_type_n,
	em_stream_type_name,
	em_stream_subtype,
	em_stream_subtype_name,
};

typedef struct stx_item_data{
	enum stx_item_type type;
	stx_gid            gid;
	char*              sz_content;
}stx_item_data;

static stx_gid g_clsid;


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
static stx_item_data* create_item_data
(enum stx_item_type type,stx_gid gid,char* sz_content)
{
	stx_item_data* data;
	data = (stx_item_data*)xmallocz(sizeof(stx_item_data));
	if( !data ){
		return NULL;
	}
	data->type = type;
	data->gid = gid;
	data->sz_content = xstrdup(sz_content);
	if( !data->sz_content ) {
		stx_free( data );
		return NULL;
	}
	return data;
};


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

static void close_stx_item_data(stx_item_data* data)
{
// 	char sz_inf[2048];
// 	stx_sprintf(sz_inf,sizeof(sz_inf),"data = 0x%X\t",data);
// 	OutputDebugString(sz_inf);

	if( data->sz_content ) {

// 		stx_sprintf(sz_inf,sizeof(sz_inf),"content = %s\r\n",data->sz_content);
// 		OutputDebugString(sz_inf);

		stx_free( data->sz_content );
	}

	stx_free(data);
}


// AddFilter dialog

IMPLEMENT_DYNAMIC(AddFilter, CDialog)

AddFilter::AddFilter(CWnd* pParent /*=NULL*/,void* h_xini,void* h_stream,BOOL bPreview)
	: CDialog(AddFilter::IDD, pParent)
{
	m_parent = (CDialog*)pParent;
	m_hxini = h_xini;
	m_hstream = h_stream;
	m_bPreview = bPreview;

	INIT_MEMBER(m_szPath);
}

AddFilter::~AddFilter()
{
}

void AddFilter::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(AddFilter, CDialog)
ON_WM_CLOSE()
ON_BN_CLICKED(IDC_BTN_ADDFLT, &AddFilter::OnBnClickedBtnAddflt)
END_MESSAGE_MAP()



// AddFilter message handlers

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void  AddFilter::get_last_clsid(BYTE id[16])
{
	memcpy(id,&g_clsid,sizeof(stx_gid));
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void release_stx_item_data(CTreeCtrl*	pTree,HTREEITEM h)
{

	HTREEITEM hh = pTree->GetNextItem(h,TVGN_CHILD);
	if( hh ) {
		release_stx_item_data(pTree,hh);
		while( hh = pTree->GetNextItem(hh,TVGN_NEXT) ) {
			release_stx_item_data(pTree,hh);
		}
	}

	hh = h;
	while( h = pTree->GetNextItem(h,TVGN_NEXT) ) {
		release_stx_item_data(pTree,h);
	}

// 	char sz_inf[2048];
// 	stx_sprintf(sz_inf,sizeof(sz_inf),"hitem = 0x%X\t",hh);
// 	OutputDebugString(sz_inf);

	stx_item_data* data = (stx_item_data*)pTree->GetItemData(hh);
	if( data) {
		close_stx_item_data(data);
	}
	pTree->DeleteItem(hh);

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void AddFilter::OnClose()
{
	CTreeCtrl*	pTree = (CTreeCtrl*)GetDlgItem(IDC_FLT_TREE);

	// release all item data;
	release_stx_item_data(pTree,pTree->GetRootItem());

	((Cstx_gph_editDlg*)m_parent)->OnAddFilterDlgClosed();
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

BOOL AddFilter::OnInitDialog()
{
	CDialog::OnInitDialog();

	if( !LoadFilters() ) {
		return FALSE;
	}

	if( m_bPreview ) {
		GetDlgItem(IDC_BTN_ADDFLT)->EnableWindow(FALSE);
	}

	return TRUE;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

BOOL AddFilter::LoadFilters()
{
	// load all filters , add to treectrl;
	CTreeCtrl*	pTree = (CTreeCtrl*)GetDlgItem(IDC_FLT_TREE);

	DWORD dwStyle =  ::GetWindowLong(pTree->m_hWnd,GWL_STYLE);

	::SetWindowLong(pTree->m_hWnd,GWL_STYLE,dwStyle |(TVS_HASBUTTONS|TVS_LINESATROOT ) );

	HTREEITEM   hitem_src;
	HTREEITEM   hitem_med;
	HTREEITEM   hitem_rnd;
	HTREEITEM   hitem_writer;
	HTREEITEM   hitem_other;
	HTREEITEM   hitem_parent;
	HTREEITEM   hitem_moud;
	HTREEITEM   hitem;
	HTREEITEM   hitem_stream_type;
	HTREEITEM   hitem_major_type;
	HTREEITEM   hitem_sub_type;

	HTREEITEM   hitem_comhelper;
	HTREEITEM   hitem_interface;

	STX_RESULT			i_err;
	s32					i_filter_num;
	s32					i,j,m;
	char*				sz_gid;
	char*				sz_type;
	stx_gid				cat_gid;

	stx_xini*			h_xini;
	STX_HANDLE			h_all;
	STX_HANDLE			h_gid;
	STX_HANDLE			h_cat;
	STX_HANDLE			h_type;
	STX_HANDLE			h_name;
	STX_HANDLE			h_subtype;

	THEE				h_helper;
	THEE				h_interf;

	char				sz_cfg[1024];
	char				sz_key[1024];

	stx_item_data*      pdata;


	sz_gid = STX_NULL;
	sz_type = STX_NULL;
	h_xini = STX_NULL;
	pdata = NULL;

	i_err = STX_FAIL;

	hitem_src = pTree->InsertItem("File source");
	if( !hitem_src) {
		goto fail;
	}
	pdata = create_item_data(em_src,STX_GID_NULL,"File source");
	if( !pdata) {
		goto fail;
	}
	pTree->SetItemData(hitem_src,(DWORD_PTR)pdata);
	pdata = NULL;

	hitem_med = pTree->InsertItem("Intermediate");
	if( !hitem_med ) {
		goto fail;
	}
	pdata = create_item_data(em_med,STX_GID_NULL,"Intermediate");
	if( !pdata) {
		goto fail;
	}
	pTree->SetItemData(hitem_med,(DWORD_PTR)pdata);
	pdata = NULL;

	hitem_rnd= pTree->InsertItem("Render");
	if( !hitem_rnd ) {
		goto fail;
	}
	pdata = create_item_data(em_rnd,STX_GID_NULL,"Render");
	if( !pdata) {
		goto fail;
	}
	pTree->SetItemData(hitem_rnd,(DWORD_PTR)pdata);
	pdata = NULL;

	hitem_writer= pTree->InsertItem("Writer");
	if( !hitem_writer ) {
		goto fail;
	}
	pdata = create_item_data(em_writer,STX_GID_NULL,"Writer");
	if( !pdata) {
		goto fail;
	}
	pTree->SetItemData(hitem_writer,(DWORD_PTR)pdata);
	pdata = NULL;

	hitem_other= pTree->InsertItem("Other");
	if( !hitem_other ) {
		goto fail;
	}
	pdata = create_item_data(em_other,STX_GID_NULL,"Other");
	if( !pdata) {
		goto fail;
	}
	if( !pTree->SetItemData(hitem_other,(DWORD_PTR)pdata) ) {
		goto fail;
	}
	pdata = NULL;

	/* open StreamX xini configure file; */

	if( !m_hxini ) {

		stx_sprintf(sz_cfg,sizeof(sz_cfg),"%s\\%s",g_szStreamX_Path,g_szStreamX_Cfg);

		i_err = stx_ini_create( sz_cfg, STX_NULL, STX_INI_READ_ONLY | STX_INI_NO_COMMENT, 0,&h_xini );
		if( STX_OK != i_err ) {
			goto fail;
		}
	}
	else {
		h_xini = (stx_xini*)m_hxini;
	}

	/* all modules ; */
	i_err = h_xini->create_key( h_xini, STX_NULL, g_szStreamX_AllModule, STX_NULL, &h_all );
	if( STX_INI_OK != i_err ) {
		goto fail;
	}

	i_err = h_xini->get_sub_key_num(h_xini,h_all,&i_filter_num);
	if( STX_INI_OK != i_err ) {
		goto fail;
	}

	for( i = 0; i < i_filter_num; i ++ ) {

		// class id = <class id>;
		i_err = h_xini->get_sub_key(h_xini,h_all,i,&h_gid);
		if( STX_INI_OK != i_err ) {
			goto fail;
		}

		/* <Main category> = 1F2EA6D1-C7B3-4ae7-B22E-F89975469D9A (file source); */
		i_err = h_xini->create_key( h_xini, h_gid, g_szStreamX_MainCategory, NULL, &h_cat );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		i_err = h_xini->read_string(h_xini,h_cat,&sz_type);
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		cat_gid = stx_gid_from_string(sz_type);
		if( IS_EQUAL_GID(cat_gid,STX_CATEGORY_FileSource) ) {
			hitem_parent = hitem_src;
		}
		else if(IS_EQUAL_GID(cat_gid,STX_CATEGORY_Render) ){
			hitem_parent = hitem_rnd;
		}
		else if(IS_EQUAL_GID(cat_gid,STX_CATEGORY_FileWriter) ){
			hitem_parent = hitem_writer;
		}
		else if(IS_EQUAL_GID(cat_gid,STX_CATEGORY_IntermediateFilter) ){
			hitem_parent = hitem_med;
		}
		else {
			hitem_parent = hitem_other;
		}

		/* <filter name> = StreamX rtsp file source filter */
		i_err = h_xini->create_key( h_xini, h_gid, g_szStreamX_FilterName, NULL,  &h_cat );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		i_err = h_xini->read_string(h_xini,h_cat,&sz_type);
		if( STX_INI_OK != i_err ) {
			goto fail;
		}

		i_err = STX_FAIL;
		stx_sprintf(sz_key,sizeof(sz_key),"%s = %s",g_szStreamX_FilterName,sz_type);
		hitem_moud = pTree->InsertItem(sz_key,hitem_parent);
		if( !hitem_moud ) {
			goto fail;
		}
		pdata = create_item_data(em_filter,STX_GID_NULL,sz_type);
		if( !pdata) {
			goto fail;
		}
		if( ! pTree->SetItemData(hitem_moud,(DWORD_PTR)pdata) ) {
			goto fail;
		}
		pdata = NULL;

		// class id;
		i_err = h_xini->read_key(h_xini,h_gid,&sz_type);
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		i_err = STX_FAIL;
		stx_sprintf(sz_key,sizeof(sz_key),"Class Id = %s",sz_type);
		hitem = pTree->InsertItem(sz_key,hitem_moud);
		if( !hitem ) {
			goto fail;
		}
		pdata = create_item_data(em_clsid,stx_gid_from_string(sz_type),sz_type);
		if( !pdata) {
			goto fail;
		}
		if( ! pTree->SetItemData(hitem,(DWORD_PTR)pdata) ) {
			goto fail;
		}
		pdata = NULL;

		/* <class id name> = ; */
		i_err = h_xini->create_key( h_xini, h_gid, g_szStreamX_ClassIdName, NULL,  &h_cat );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		i_err = h_xini->read_string(h_xini,h_cat,&sz_type);
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		i_err = STX_FAIL;
		stx_sprintf(sz_key,sizeof(sz_key),"%s = %s",g_szStreamX_ClassIdName,sz_type);
		hitem = pTree->InsertItem(sz_key,hitem_moud);
		if( !hitem ) {
			goto fail;
		}
		pdata = create_item_data(em_clsid_name,STX_GID_NULL,sz_type);
		if( !pdata) {
			goto fail;
		}
		if( ! pTree->SetItemData(hitem,(DWORD_PTR)pdata) ) {
			goto fail;
		}
		pdata = NULL;


		// < Path Name > = ;
		i_err = h_xini->create_key( h_xini, h_gid, g_szStreamX_PathName, NULL,  &h_cat );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		i_err = h_xini->read_string(h_xini,h_cat,&sz_type);
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		i_err = STX_FAIL;
		stx_sprintf(sz_key,sizeof(sz_key),"%s = %s",g_szStreamX_PathName,sz_type);
		hitem = pTree->InsertItem(sz_key,hitem_moud);
		if( !hitem ) {
			goto fail;
		}
		pdata = create_item_data(em_path_name,STX_GID_NULL,sz_type);
		if( !pdata) {
			goto fail;
		}
		if( !pTree->SetItemData(hitem,(DWORD_PTR)pdata) ) {
			goto fail;
		}
		pdata = NULL;


		/* <Main category> = 1F2EA6D1-C7B3-4ae7-B22E-F89975469D9A (file source); */
		i_err = h_xini->create_key( h_xini, h_gid, g_szStreamX_MainCategory, sz_type, &h_cat );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		i_err = h_xini->read_string(h_xini,h_cat,&sz_type);
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		i_err = STX_FAIL;
		stx_sprintf(sz_key,sizeof(sz_key),"%s = %s",g_szStreamX_MainCategory,sz_type);
		hitem = pTree->InsertItem(sz_key,hitem_moud);
		if( !hitem ) {
			goto fail;
		}
		pdata = create_item_data(em_main_cat,STX_GID_NULL,sz_type);
		if( !pdata) {
			goto fail;
		}
		if( !pTree->SetItemData(hitem,(DWORD_PTR)pdata) ) {
			goto fail;
		}
		pdata = NULL;

		// < category desc > = ;
		i_err = h_xini->create_key( h_xini, h_cat, g_szStreamX_CategoryDesc, NULL, &h_name );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		i_err = h_xini->read_string(h_xini,h_name,&sz_type);
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		i_err = STX_FAIL;
		stx_sprintf(sz_key,sizeof(sz_key),"%s = %s",g_szStreamX_CategoryDesc,sz_type);
		hitem = pTree->InsertItem(sz_key,hitem_moud);
		if( !hitem ) {
			goto fail;
		}
		pdata = create_item_data(em_cat_desc,STX_GID_NULL,sz_type);
		if( !pdata) {
			goto fail;
		}
		if( !pTree->SetItemData(hitem,(DWORD_PTR)pdata) ) {
			goto fail;
		}
		pdata = NULL;


		// com helper item;

		i_err = h_xini->create_key( h_xini, h_gid, g_szStreamX_Interface, "0", &h_helper);

		if( STX_INI_OK == i_err ) {

			i_err = STX_FAIL;
			hitem_comhelper = pTree->InsertItem(g_szStreamX_Interface,hitem_moud);
			if( !hitem_comhelper ) {
				goto fail;
			}
			pdata = create_item_data(em_comhelper,STX_IID_StxComHelper,g_szStreamX_Interface);
			if( !pdata) {
				goto fail;
			}
			if( !pTree->SetItemData(hitem_comhelper,(DWORD_PTR)pdata) ) {
				goto fail;
			}
			pdata = NULL;

			i_err = h_xini->get_sub_key_num(h_xini,h_helper,&m);
			if( STX_OK != i_err ) { // skip emulator;
				goto fail;
			}

			for( j = 0; j < m; j ++ ) {

				i_err = h_xini->get_sub_key( h_xini, h_helper, j, &h_interf);
				if( STX_INI_OK != i_err ) {
					goto fail;
				}

				// read key;
				i_err = h_xini->read_key(h_xini,h_interf,&sz_gid);
				if( STX_INI_OK != i_err ) {
					goto fail;
				}

				i_err = h_xini->read_string(h_xini,h_interf,&sz_type);
				if( STX_INI_OK != i_err ) {
					goto fail;
				}
				stx_sprintf(sz_key,sizeof(sz_key),"%s = %s",sz_gid,sz_type);
				hitem_interface = pTree->InsertItem(sz_key,hitem_comhelper);
				if( !hitem_interface ) {
					goto fail;
				}
				pdata = create_item_data(em_interface,STX_GID_NULL,sz_key);
				if( !pdata) {
					goto fail;
				}
				if( !pTree->SetItemData(hitem_interface,(DWORD_PTR)pdata) ) {
					goto fail;
				}
				pdata = NULL;

			} // for( j = 0; j < m; j ++ ) {

		} // if( STX_INI_OK == i_err ) {


		i_err = h_xini->create_key( h_xini, h_gid, g_szStreamX_InputType, "0", &h_cat);
		if( STX_INI_OK == i_err ) {

			i_err = STX_FAIL;
			hitem_major_type = pTree->InsertItem(g_szStreamX_InputType,hitem_moud);
			if( !hitem_major_type ) {
				goto fail;
			}
			pdata = create_item_data(em_majortype,STX_GID_NULL,g_szStreamX_InputType);
			if( !pdata) {
				goto fail;
			}
			if( !pTree->SetItemData(hitem_major_type,(DWORD_PTR)pdata) ) {
				goto fail;
			}
			pdata = NULL;

			i_err = h_xini->get_sub_key_num(h_xini,h_cat,&m);
			if( STX_OK != i_err || m == MAX_MEDIA_TYPE ) { // skip emulator;
				goto fail;
			}


			for( j = 0; j < m; j ++ ) {

				/* Major Type - 0 = ( 73646976-0000-0010-8000-00AA00389B71 vids ); */

				stx_sprintf(sz_key,sizeof(sz_key),"%s-%d",g_szStreamX_MajorDataType,j);
				i_err = h_xini->create_key( h_xini, h_cat, sz_key, NULL, &h_type);
				if( STX_INI_OK != i_err ) {
					goto fail;
				}
				i_err = h_xini->read_string(h_xini,h_type,&sz_type);
				if( STX_INI_OK != i_err ) {
					goto fail;
				}
				i_err = STX_FAIL;
				stx_sprintf(sz_key,sizeof(sz_key),"%s-%d = %s",g_szStreamX_MajorDataType,j,sz_type);
				hitem_sub_type = pTree->InsertItem(sz_key,hitem_major_type);
				if( !hitem_sub_type ) {
					goto fail;
				}
				pdata = create_item_data(em_majortype_n,STX_GID_NULL,sz_key);
				if( !pdata) {
					goto fail;
				}
				if( !pTree->SetItemData(hitem_sub_type,(DWORD_PTR)pdata) ) {
					goto fail;
				}
				pdata = NULL;


				// major type name;
				i_err = h_xini->create_key( h_xini, h_type, 
					g_szStreamX_MajorDataTypeName,NULL, &h_name );
				if( STX_INI_OK != i_err ) {
					goto fail;
				}
				i_err = h_xini->read_string(h_xini,h_name,&sz_type);
				if( STX_INI_OK != i_err ) {
					goto fail;
				}
				i_err = STX_FAIL;
				stx_sprintf(sz_key,sizeof(sz_key),"%s = %s",g_szStreamX_MajorDataTypeName, sz_type);
				hitem = pTree->InsertItem(sz_key,hitem_sub_type);
				if( !hitem ) {
					goto fail;
				}
				pdata = create_item_data(em_majortype_name,STX_GID_NULL,sz_key);
				if( !pdata) {
					goto fail;
				}
				if( !pTree->SetItemData(hitem,(DWORD_PTR)pdata) ) {
					goto fail;
				}
				pdata = NULL;

				// sub type;
				i_err = h_xini->create_key( h_xini, h_type, g_szStreamX_SubDataType, NULL, &h_subtype);
				if( STX_INI_OK != i_err ) {
					goto fail;
				}
				i_err = h_xini->read_string(h_xini,h_subtype,&sz_type);
				if( STX_INI_OK != i_err ) {
					goto fail;
				}
				i_err = STX_FAIL;
				stx_sprintf(sz_key,sizeof(sz_key),"%s = %s",g_szStreamX_SubDataType, sz_type);
				hitem = pTree->InsertItem(sz_key,hitem_sub_type);
				if( !hitem ) {
					goto fail;
				}
				pdata = create_item_data(em_subtype,stx_gid_from_string(sz_type),sz_type);
				if( !pdata) {
					goto fail;
				}
				if( !pTree->SetItemData(hitem,(DWORD_PTR)pdata) ) {
					goto fail;
				}
				pdata = NULL;

				i_err = h_xini->create_key( h_xini, h_type, 
					g_szStreamX_SubDataTypeName, NULL, &h_name );
				if( STX_INI_OK != i_err ) {
					goto fail;
				}
				i_err = h_xini->read_string(h_xini,h_name,&sz_type);
				if( STX_INI_OK != i_err ) {
					goto fail;
				}
				i_err = STX_FAIL;
				stx_sprintf(sz_key,sizeof(sz_key),"%s = %s",g_szStreamX_SubDataTypeName, sz_type);
				hitem = pTree->InsertItem(sz_key,hitem_sub_type);
				if( !hitem ) {
					goto fail;
				}
				pdata = create_item_data(em_subtype_name,STX_GID_NULL,sz_type);
				if( !pdata) {
					goto fail;
				}
				if( !pTree->SetItemData(hitem,(DWORD_PTR)pdata) ) {
					goto fail;
				}
				pdata = NULL;

			} /* for( j = 0; j < m; j ++ ) { */

		} // if( STX_INI_OK == i_err ) {
		i_err = STX_OK;

		i_err = h_xini->create_key( h_xini, h_gid, g_szStreamX_OutputType, NULL, &h_cat );
		if( STX_INI_OK == i_err ) {

			i_err = STX_FAIL;
			hitem_stream_type = pTree->InsertItem(g_szStreamX_OutputType,hitem_moud);
			if( !hitem_stream_type ) {
				goto fail;
			}
			pdata = create_item_data(em_stream_type,STX_GID_NULL,g_szStreamX_OutputType);
			if( !pdata) {
				goto fail;
			}
			if( !pTree->SetItemData(hitem_stream_type,(DWORD_PTR)pdata) ) {
				goto fail;
			}
			pdata = NULL;

			i_err = h_xini->get_sub_key_num(h_xini,h_cat,&m);
			if( STX_OK != i_err || m == MAX_MEDIA_TYPE ) { // skip emulator;
				goto fail;
			}


			for( j = 0; j < m; j ++ ) {

				// <Major Type -j> = 
				stx_sprintf(sz_key,sizeof(sz_key),"%s-%d",g_szStreamX_MajorDataType,j);
				i_err = h_xini->create_key( h_xini, h_cat, sz_key, NULL, &h_type);
				if( STX_INI_OK != i_err ) {
					goto fail;
				}
				i_err = h_xini->read_string(h_xini,h_type,&sz_type);
				if( STX_INI_OK != i_err ) {
					goto fail;
				}
				i_err = STX_FAIL;
				stx_sprintf(sz_key,sizeof(sz_key),"%s-%d = %s",g_szStreamX_MajorDataType, j,sz_type);
				hitem_sub_type = pTree->InsertItem(sz_key,hitem_stream_type);
				if( !hitem_sub_type ) {
					goto fail;
				}
				pdata = create_item_data(em_stream_type_n,stx_gid_from_string(sz_type),sz_type);
				if( !pdata) {
					goto fail;
				}
				if( !pTree->SetItemData(hitem_sub_type,(DWORD_PTR)pdata) ) {
					goto fail;
				}
				pdata = NULL;

				// <Major Type Name> = 
				i_err = h_xini->create_key( h_xini, h_type, g_szStreamX_MajorDataTypeName,NULL, &h_name);
				if( STX_INI_OK != i_err ) {
					goto fail;
				}
				i_err = h_xini->read_string(h_xini,h_name,&sz_type);
				if( STX_INI_OK != i_err ) {
					goto fail;
				}
				i_err = STX_FAIL;
				stx_sprintf(sz_key,sizeof(sz_key),"%s = %s",g_szStreamX_MajorDataTypeName, sz_type);
				hitem = pTree->InsertItem(sz_key,hitem_sub_type);
				if( !hitem ) {
					goto fail;
				}
				pdata = create_item_data(em_stream_type_name,STX_GID_NULL,sz_type);
				if( !pdata) {
					goto fail;
				}
				if( !pTree->SetItemData(hitem,(DWORD_PTR)pdata) ) {
					goto fail;
				}
				pdata = NULL;

				// <Stream Sub Type> = 
				i_err = h_xini->create_key( h_xini, h_type, g_szStreamX_SubDataType, sz_type, &h_subtype);
				if( STX_INI_OK != i_err ) {
					goto fail;
				}
				i_err = h_xini->read_string(h_xini,h_subtype,&sz_type);
				if( STX_INI_OK != i_err ) {
					goto fail;
				}
				i_err = STX_FAIL;
				stx_sprintf(sz_key,sizeof(sz_key),"%s = %s",g_szStreamX_SubDataType, sz_type);
				hitem = pTree->InsertItem(sz_key,hitem_sub_type);
				if( !hitem ) {
					goto fail;
				}
				pdata = create_item_data(em_stream_subtype,stx_gid_from_string(sz_type),sz_type);
				if( !pdata) {
					goto fail;
				}
				if( !pTree->SetItemData(hitem,(DWORD_PTR)pdata) ) {
					goto fail;
				}
				pdata = NULL;

				// < Sub Type Name > = 
				i_err = h_xini->create_key( h_xini, h_type, g_szStreamX_SubDataTypeName, NULL, &h_name);
				if( STX_INI_OK != i_err ) {
					goto fail;
				}
				i_err = h_xini->read_string(h_xini,h_name,&sz_type);
				if( STX_INI_OK != i_err ) {
					goto fail;
				}
				i_err = STX_FAIL;
				stx_sprintf(sz_key,sizeof(sz_key),"%s = %s",g_szStreamX_SubDataTypeName, sz_type);
				hitem = pTree->InsertItem(sz_key,hitem_sub_type);
				if( !hitem ) {
					goto fail;
				}
				pdata = create_item_data(em_stream_subtype_name,STX_GID_NULL,sz_type);
				if( !pdata) {
					goto fail;
				}
				if( !pTree->SetItemData(hitem,(DWORD_PTR)pdata) ) {
					goto fail;
				}
				pdata = NULL;

				i_err = STX_OK;

			} /* for( j = 0; j < m; j ++ ) { */

		} // if( STX_INI_OK == i_err ) {
		i_err = STX_OK;

	
	} /*for( i = 0; i < i_filter_num; i ++ ) {*/

	i_err = STX_OK;

fail:

	if( pdata ) {
		close_stx_item_data(pdata);
	}

	if( h_xini ) {
		h_xini->close(h_xini);
		m_hxini = NULL;
	}

	if( m_hstream ) {
		((stx_xio*)m_hstream) ->close((stx_xio*)m_hstream);
		m_hstream = NULL;
	}

	return i_err == STX_OK;

}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void AddFilter::OnBnClickedBtnAddflt()
{
	// TODO: Add your control notification handler code here

	CTreeCtrl*	pTree = (CTreeCtrl*)GetDlgItem(IDC_FLT_TREE);

	HTREEITEM hitem = pTree->GetSelectedItem();

	if( !hitem ) {
		m_szPath[0] = 0;
		return;
	}

	HTREEITEM      h;
	stx_item_data* id;


	for( ; ; ) {
		id = (stx_item_data*)pTree->GetItemData(hitem);
		if( id->type == em_filter ) {
			break;
		}
		else if( id->type > em_filter ) {
			hitem = pTree->GetParentItem(hitem);
		}
		else {
			return;
		}
	} // for( ; ; ) {

	// first child is clsid;
	h = hitem;
	hitem = pTree->GetNextItem(hitem,TVGN_CHILD);
	id = (stx_item_data*)pTree->GetItemData(hitem);

	if( id->type != em_clsid) {

		return; // error;
	}

	// get clsid;
	g_clsid = id->gid;

	if( !m_bPreview ) {
		// post message;
		m_parent->PostMessage(WM_ADDFLT,FALSE);
		return;
	}//if( !m_bPreview ) {

	hitem = h;
	// get path;
	hitem = pTree->GetNextItem(hitem,TVGN_CHILD);
	while(hitem) {
		id = (stx_item_data*)pTree->GetItemData(hitem);
		if( id->type == em_path_name ) {
			stx_strcpy(m_szPath,sizeof(m_szPath),id->sz_content);
			m_parent->PostMessage(WM_ADDFLT,TRUE);
			// post message;
			return;
		}
		hitem = pTree->GetNextItem(hitem,TVGN_NEXT);
	}

	m_szPath[0] = 0;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

BOOL AddFilter::get_path(char* sz_path,size_t i_size)
{
	if( !m_bPreview ) {
		return FALSE;
	}

	if( m_szPath[0] ) {

		stx_strcpy(sz_path,i_size,m_szPath);
		m_szPath[0] = 0;
		return TRUE;
	}

	return FALSE;
}
