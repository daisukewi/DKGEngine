/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-10
***********************************************************************************/
// flt_set_dlg.cpp : implementation file
//

#include "stdafx.h"

#include "stx_gph_edit.h"
#include "flt_set_dlg.h"

#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif

extern stx_base_graph_builder* g_gbd;


// flt_set_dlg dialog

IMPLEMENT_DYNAMIC(flt_set_dlg, CDialog)
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

flt_set_dlg::flt_set_dlg(CWnd* pParent,stx_base_filter* hFilter)
	: CDialog(flt_set_dlg::IDD, pParent)
{
	m_hFilter = hFilter;
}
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

flt_set_dlg::~flt_set_dlg()
{

}
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void flt_set_dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

BEGIN_MESSAGE_MAP(flt_set_dlg, CDialog)
	ON_BN_CLICKED(IDC_BTN_APPLY, &flt_set_dlg::OnBnClickedBtnApply)
	ON_BN_CLICKED(IDCANCEL, &flt_set_dlg::OnBnClickedCancel)
END_MESSAGE_MAP()


// flt_set_dlg message handlers



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_RESULT flt_set_dlg::LoadFilters(stx_xini* h_xini)
{
	// load all filters , add to treectrl;
	CTreeCtrl*	pTree = (CTreeCtrl*)GetDlgItem(IDC_TREE_INF);

	DWORD dwStyle =  ::GetWindowLong(pTree->m_hWnd,GWL_STYLE);

	::SetWindowLong(pTree->m_hWnd,GWL_STYLE,dwStyle |(TVS_HASBUTTONS|TVS_LINESATROOT ) );

	HTREEITEM   hitem_src;
	HTREEITEM   hitem_med;
	HTREEITEM   hitem_rnd;
	HTREEITEM   hitem_writer;
	HTREEITEM   hitem_other;
	HTREEITEM   hitem_parent;
	HTREEITEM   hitem_moud;
	HTREEITEM   hitem;
	HTREEITEM   hitem_stream_type;
	HTREEITEM   hitem_major_type;
	HTREEITEM   hitem_sub_type;

	STX_RESULT			i_err;
	s32					i_filter_num;
	s32					i,j,m;
	char*				sz_gid;
	char*				sz_type;
	stx_gid				cat_gid;

	STX_HANDLE			h_all;
	STX_HANDLE			h_gid;
	STX_HANDLE			h_cat;
	STX_HANDLE			h_type;
	STX_HANDLE			h_name;
	STX_HANDLE			h_subtype;

	char				sz_key[1024];


	sz_gid = STX_NULL;
	sz_type = STX_NULL;
	i_err = STX_FAIL;

	hitem_src = pTree->InsertItem("File source");
	if( !hitem_src) {
		goto fail;
	}

	hitem_med = pTree->InsertItem("Intermediate");
	if( !hitem_med ) {
		goto fail;
	}

	hitem_rnd= pTree->InsertItem("Render");
	if( !hitem_rnd ) {
		goto fail;
	}

	hitem_writer= pTree->InsertItem("Writer");
	if( !hitem_writer ) {
		goto fail;
	}

	hitem_other= pTree->InsertItem("Other");
	if( !hitem_other ) {
		goto fail;
	}

	/* open StreamX xini configure file; */


	/* all modules ; */
	i_err = h_xini->create_key( h_xini, STX_NULL, g_szStreamX_AllModule, STX_NULL, &h_all );
	if( STX_INI_OK != i_err ) {
		goto fail;
	}

	i_err = h_xini->get_sub_key_num(h_xini,h_all,&i_filter_num);
	if( STX_INI_OK != i_err ) {
		goto fail;
	}

	for( i = 0; i < i_filter_num; i ++ ) {

		// class id = <class id>;
		i_err = h_xini->get_sub_key(h_xini,h_all,i,&h_gid);
		if( STX_INI_OK != i_err ) {
			goto fail;
		}

		/* <Main category> = 1F2EA6D1-C7B3-4ae7-B22E-F89975469D9A (file source); */
		i_err = h_xini->create_key( h_xini, h_gid, g_szStreamX_MainCategory, NULL, &h_cat );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		i_err = h_xini->read_string(h_xini,h_cat,&sz_type);
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		cat_gid = stx_gid_from_string(sz_type);
		if( IS_EQUAL_GID(cat_gid,STX_CATEGORY_FileSource) ) {
			hitem_parent = hitem_src;
		}
		else if(IS_EQUAL_GID(cat_gid,STX_CATEGORY_Render) ){
			hitem_parent = hitem_rnd;
		}
		else if(IS_EQUAL_GID(cat_gid,STX_CATEGORY_FileWriter) ){
			hitem_parent = hitem_writer;
		}
		else if(IS_EQUAL_GID(cat_gid,STX_CATEGORY_IntermediateFilter) ){
			hitem_parent = hitem_med;
		}
		else {
			hitem_parent = hitem_other;
		}

		/* <filter name> = StreamX rtsp file source filter */
		i_err = h_xini->create_key( h_xini, h_gid, g_szStreamX_FilterName, NULL,  &h_cat );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		i_err = h_xini->read_string(h_xini,h_cat,&sz_type);
		if( STX_INI_OK != i_err ) {
			goto fail;
		}

		i_err = STX_FAIL;
		stx_sprintf(sz_key,sizeof(sz_key),"%s = %s",g_szStreamX_FilterName,sz_type);
		hitem_moud = pTree->InsertItem(sz_key,hitem_parent);
		if( !hitem_moud ) {
			goto fail;
		}
		// class id;
		i_err = h_xini->read_key(h_xini,h_gid,&sz_type);
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		i_err = STX_FAIL;
		stx_sprintf(sz_key,sizeof(sz_key),"Class Id = %s",sz_type);
		hitem = pTree->InsertItem(sz_key,hitem_moud);
		if( !hitem ) {
			goto fail;
		}

		/* <class id name> = ; */
		i_err = h_xini->create_key( h_xini, h_gid, g_szStreamX_ClassIdName, NULL,  &h_cat );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		i_err = h_xini->read_string(h_xini,h_cat,&sz_type);
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		i_err = STX_FAIL;
		stx_sprintf(sz_key,sizeof(sz_key),"%s = %s",g_szStreamX_ClassIdName,sz_type);
		hitem = pTree->InsertItem(sz_key,hitem_moud);
		if( !hitem ) {
			goto fail;
		}


		// < Path Name > = ;
		i_err = h_xini->create_key( h_xini, h_gid, g_szStreamX_PathName, NULL,  &h_cat );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		i_err = h_xini->read_string(h_xini,h_cat,&sz_type);
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		i_err = STX_FAIL;
		stx_sprintf(sz_key,sizeof(sz_key),"%s = %s",g_szStreamX_PathName,sz_type);
		hitem = pTree->InsertItem(sz_key,hitem_moud);
		if( !hitem ) {
			goto fail;
		}


		/* <Main category> = 1F2EA6D1-C7B3-4ae7-B22E-F89975469D9A (file source); */
		i_err = h_xini->create_key( h_xini, h_gid, g_szStreamX_MainCategory, sz_type, &h_cat );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		i_err = h_xini->read_string(h_xini,h_cat,&sz_type);
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		i_err = STX_FAIL;
		stx_sprintf(sz_key,sizeof(sz_key),"%s = %s",g_szStreamX_MainCategory,sz_type);
		hitem = pTree->InsertItem(sz_key,hitem_moud);
		if( !hitem ) {
			goto fail;
		}

		// < category desc > = ;
		i_err = h_xini->create_key( h_xini, h_cat, g_szStreamX_CategoryDesc, NULL, &h_name );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		i_err = h_xini->read_string(h_xini,h_name,&sz_type);
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		i_err = STX_FAIL;
		stx_sprintf(sz_key,sizeof(sz_key),"%s = %s",g_szStreamX_CategoryDesc,sz_type);
		hitem = pTree->InsertItem(sz_key,hitem_moud);
		if( !hitem ) {
			goto fail;
		}

		i_err = h_xini->create_key( h_xini, h_gid, g_szStreamX_InputType, "0", &h_cat);
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		i_err = STX_FAIL;
		hitem_major_type = pTree->InsertItem(g_szStreamX_InputType,hitem_moud);
		if( !hitem_major_type ) {
			goto fail;
		}

		i_err = h_xini->get_sub_key_num(h_xini,h_cat,&m);
		if( STX_OK != i_err || m == MAX_MEDIA_TYPE ) { // skip emulator;
			goto fail;
		}


		for( j = 0; j < m; j ++ ) {

			/* Major Type - 0 = ( 73646976-0000-0010-8000-00AA00389B71 vids ); */

			stx_sprintf(sz_key,sizeof(sz_key),"%s-%d",g_szStreamX_MajorDataType,j);
			i_err = h_xini->create_key( h_xini, h_cat, sz_key, NULL, &h_type);
			if( STX_INI_OK != i_err ) {
				goto fail;
			}
			i_err = h_xini->read_string(h_xini,h_type,&sz_type);
			if( STX_INI_OK != i_err ) {
				goto fail;
			}
			i_err = STX_FAIL;
			stx_sprintf(sz_key,sizeof(sz_key),"%s-%d = %s",g_szStreamX_MajorDataType,j,sz_type);
			hitem_sub_type = pTree->InsertItem(sz_key,hitem_major_type);
			if( !hitem_sub_type ) {
				goto fail;
			}

			// major type name;
			i_err = h_xini->create_key( h_xini, h_type, 
				g_szStreamX_MajorDataTypeName,NULL, &h_name );
			if( STX_INI_OK != i_err ) {
				goto fail;
			}
			i_err = h_xini->read_string(h_xini,h_name,&sz_type);
			if( STX_INI_OK != i_err ) {
				goto fail;
			}
			i_err = STX_FAIL;
			stx_sprintf(sz_key,sizeof(sz_key),"%s = %s",g_szStreamX_MajorDataTypeName, sz_type);
			hitem = pTree->InsertItem(sz_key,hitem_sub_type);
			if( !hitem ) {
				goto fail;
			}

			// sub type;
			i_err = h_xini->create_key( h_xini, h_type, g_szStreamX_SubDataType, NULL, &h_subtype);
			if( STX_INI_OK != i_err ) {
				goto fail;
			}
			i_err = h_xini->read_string(h_xini,h_subtype,&sz_type);
			if( STX_INI_OK != i_err ) {
				goto fail;
			}
			i_err = STX_FAIL;
			stx_sprintf(sz_key,sizeof(sz_key),"%s = %s",g_szStreamX_SubDataType, sz_type);
			hitem = pTree->InsertItem(sz_key,hitem_sub_type);
			if( !hitem ) {
				goto fail;
			}

			i_err = h_xini->create_key( h_xini, h_type, 
				g_szStreamX_SubDataTypeName, NULL, &h_name );
			if( STX_INI_OK != i_err ) {
				goto fail;
			}
			i_err = h_xini->read_string(h_xini,h_name,&sz_type);
			if( STX_INI_OK != i_err ) {
				goto fail;
			}
			i_err = STX_FAIL;
			stx_sprintf(sz_key,sizeof(sz_key),"%s = %s",g_szStreamX_SubDataTypeName, sz_type);
			hitem = pTree->InsertItem(sz_key,hitem_sub_type);
			if( !hitem ) {
				goto fail;
			}

		} /* for( j = 0; j < m; j ++ ) { */


		i_err = h_xini->create_key( h_xini, h_gid, g_szStreamX_OutputType, NULL, &h_cat );
		if( STX_INI_OK != i_err ) {
			goto fail;
		}
		i_err = STX_FAIL;
		hitem_stream_type = pTree->InsertItem(g_szStreamX_OutputType,hitem_moud);
		if( !hitem_stream_type ) {
			goto fail;
		}

		i_err = h_xini->get_sub_key_num(h_xini,h_cat,&m);
		if( STX_OK != i_err || m == MAX_MEDIA_TYPE ) { // skip emulator;
			goto fail;
		}


		for( j = 0; j < m; j ++ ) {

			// <Major Type -j> = 
			stx_sprintf(sz_key,sizeof(sz_key),"%s-%d",g_szStreamX_MajorDataType,j);
			i_err = h_xini->create_key( h_xini, h_cat, sz_key, NULL, &h_type);
			if( STX_INI_OK != i_err ) {
				goto fail;
			}
			i_err = h_xini->read_string(h_xini,h_type,&sz_type);
			if( STX_INI_OK != i_err ) {
				goto fail;
			}
			i_err = STX_FAIL;
			stx_sprintf(sz_key,sizeof(sz_key),"%s-%d = %s",g_szStreamX_MajorDataType, j,sz_type);
			hitem_sub_type = pTree->InsertItem(sz_key,hitem_stream_type);
			if( !hitem_sub_type ) {
				goto fail;
			}

			// <Major Type Name> = 
			i_err = h_xini->create_key( h_xini, h_type, g_szStreamX_MajorDataTypeName,NULL, &h_name);
			if( STX_INI_OK != i_err ) {
				goto fail;
			}
			i_err = h_xini->read_string(h_xini,h_name,&sz_type);
			if( STX_INI_OK != i_err ) {
				goto fail;
			}
			i_err = STX_FAIL;
			stx_sprintf(sz_key,sizeof(sz_key),"%s = %s",g_szStreamX_MajorDataTypeName, sz_type);
			hitem = pTree->InsertItem(sz_key,hitem_sub_type);
			if( !hitem ) {
				goto fail;
			}

			// <Stream Sub Type> = 
			i_err = h_xini->create_key( h_xini, h_type, g_szStreamX_SubDataType, sz_type, &h_subtype);
			if( STX_INI_OK != i_err ) {
				goto fail;
			}
			i_err = h_xini->read_string(h_xini,h_subtype,&sz_type);
			if( STX_INI_OK != i_err ) {
				goto fail;
			}
			i_err = STX_FAIL;
			stx_sprintf(sz_key,sizeof(sz_key),"%s = %s",g_szStreamX_SubDataType, sz_type);
			hitem = pTree->InsertItem(sz_key,hitem_sub_type);
			if( !hitem ) {
				goto fail;
			}

			// < Sub Type Name > = 
			i_err = h_xini->create_key( h_xini, h_type, g_szStreamX_SubDataTypeName, NULL, &h_name);
			if( STX_INI_OK != i_err ) {
				goto fail;
			}
			i_err = h_xini->read_string(h_xini,h_name,&sz_type);
			if( STX_INI_OK != i_err ) {
				goto fail;
			}
			i_err = STX_FAIL;
			stx_sprintf(sz_key,sizeof(sz_key),"%s = %s",g_szStreamX_SubDataTypeName, sz_type);
			hitem = pTree->InsertItem(sz_key,hitem_sub_type);
			if( !hitem ) {
				goto fail;
			}

			i_err = STX_OK;

		} /* for( j = 0; j < m; j ++ ) { */


		if( i_err < 0 ) {
			i_err = h_xini->delete_key( h_xini, h_gid );
			if( STX_INI_OK != i_err ) {
				goto fail;
			}
		} /*if( i_err < 0 ) {*/

	} /*for( i = 0; i < i_filter_num; i ++ ) {*/

	i_err = STX_OK;

fail:

	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_RESULT  flt_set_dlg::init_tree()
{
	STX_RESULT i_err;

	stx_xini*  h_xini;
	stx_xio*   h_stream;

	CTreeCtrl*	pTree = (CTreeCtrl*)GetDlgItem(IDC_TREE_INF);
	DWORD dwStyle =  ::GetWindowLong(pTree->m_hWnd,GWL_STYLE);
	::SetWindowLong(pTree->m_hWnd,GWL_STYLE,
		dwStyle |(TVS_HASBUTTONS|TVS_LINESATROOT ) );

	i_err = STX_FAIL;
	h_xini = NULL;
	h_stream = NULL;


	do{

		h_stream = XCREATE(stx_io_stream,NULL);
		if( !h_stream ) {
			break;
		}
		i_err = stx_ini_create(NULL,h_stream,STX_INI_READ_WRITE | STX_INI_NO_COMMENT,0,&h_xini);
		if( STX_INI_OK != i_err ) {
			break;
		}
		i_err = g_gbd->get_filter_inf(g_gbd,m_hFilter,h_xini);
		if( STX_OK != i_err ) {
			break;
		}

		// add tree items;
		i_err = LoadFilters(h_xini);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = STX_OK;

	}while(FALSE);

	if( h_xini ) {
		h_xini->close(h_xini);
	}

	if( h_stream ) {
		h_stream->close(h_stream);
	}

	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

STX_RESULT  flt_set_dlg::init_prop()
{
	DECL_TRACE

	STX_RESULT		i_err;
	stx_xio*		h_stream;
	stx_io_op_param	inf;

	i_err = STX_FAIL;

	h_stream = NULL;
	INIT_MEMBER(inf);

	do{

		h_stream = XCREATE(stx_io_stream,NULL);
		if( !h_stream ) {
			break;
		}

		i_err = m_hFilter->get_property(m_hFilter,h_stream);
		if( STX_OK != i_err ) {
			i_err = STX_OK;
			break;
		}

		i_err = h_stream->get(h_stream,STX_IO_READ_P,&inf);
		if( STX_OK != i_err ) {
			break;
		}

		GetDlgItem(IDC_EDIT_PROP)->SetWindowText(inf.buf);

		i_err = STX_OK;

	}while(FALSE);

	if( h_stream ) {
		h_stream->close(h_stream);
	}

	return i_err;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

BOOL flt_set_dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// todo;

	if( !m_hFilter ) {
		return FALSE;
	}

	// init tree;
	if( STX_OK != init_tree() ) {
		return FALSE;
	}

	// init propetry;
	if( STX_OK != init_prop() ) {
		return FALSE;
	}

	return TRUE;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void flt_set_dlg::OnBnClickedBtnApply()
{
	// TODO: Add your control notification handler code here

	// get property, and create xini, and set to filters;

	CString sz_inf;

	GetDlgItem(IDC_EDIT_PROP)->GetWindowText(sz_inf);

	stx_xio*	h_stream;
	STX_RESULT	i_err;

	h_stream = NULL;
	i_err = STX_FAIL;

	do{
		DECL_TRACE

		size_t i_data;

		s32 i_len = sz_inf.GetLength();
		char* sz_buf = sz_inf.GetBuffer();

		if( !i_len ) {
			break ;
		}

		h_stream = XCREATE(stx_io_stream,NULL);
		if( !h_stream ) {
			break;
		}

		h_stream->write(h_stream,sz_buf,i_len+1,&i_data);

		i_err = m_hFilter->set_property(m_hFilter,h_stream );
		if( STX_OK != i_err ) {
			break;
		}

		i_err = STX_OK;

	}while(FALSE);

	if( h_stream ) {
		h_stream->close(h_stream);
	}

	OnOK();
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void flt_set_dlg::OnBnClickedCancel()
{
	// TODO: Add your control notification handler code here
	OnCancel();
}
