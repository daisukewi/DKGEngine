#pragma once


// UrlDlg dialog

class UrlDlg : public CDialog
{
	DECLARE_DYNAMIC(UrlDlg)

public:
	UrlDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~UrlDlg();

// Dialog Data
	enum { IDD = IDD_URL_DLG };

	char* m_szUrl;


protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedCancel();
};
