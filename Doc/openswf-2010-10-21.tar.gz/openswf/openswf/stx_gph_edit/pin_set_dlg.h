/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-10
***********************************************************************************/
#pragma once


#include "stx_all.h"

// pin_set_dlg dialog

class pin_set_dlg : public CDialog
{
	DECLARE_DYNAMIC(pin_set_dlg)

public:
	pin_set_dlg(CWnd* pParent,stx_base_pin* h_pin);   // standard constructor
	virtual ~pin_set_dlg();

// Dialog Data
	enum { IDD = IDD_PIN_DLG };

private:

	stx_base_pin*	m_hPin;
	STX_RESULT  init_prop();

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
};
