/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-10
***********************************************************************************/
#pragma once


#include "stx_all.h"

// flt_set_dlg dialog

class flt_set_dlg : public CDialog
{
	DECLARE_DYNAMIC(flt_set_dlg)

public:
	flt_set_dlg(CWnd* pParent,stx_base_filter* hFilter);   // standard constructor
	virtual ~flt_set_dlg();

// Dialog Data
	enum { IDD = IDD_FLT_DLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()


private:

	stx_base_filter*	m_hFilter;
	STX_RESULT  init_tree();
	STX_RESULT  init_prop();
	STX_RESULT  LoadFilters(stx_xini* h_xini);


public:
	afx_msg void OnBnClickedBtnApply();
	afx_msg void OnBnClickedCancel();
};
