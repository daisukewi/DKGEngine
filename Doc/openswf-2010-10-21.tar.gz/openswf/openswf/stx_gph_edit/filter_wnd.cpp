/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-10
***********************************************************************************/
#include "StdAfx.h"

#include "stx_gph_edit.h"

#include "filter_wnd.h"

#include "stx_canvas.h"

#include "flt_set_dlg.h"

#include "pin_wnd.h"

#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif


extern stx_base_graph_builder* g_gbd;
extern stx_base_plugin* g_gbd_hnd;
extern s32 g_iMaxGraph;



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT  fw_create_menu(base_flt_wnd*the,POINT point)
{
	STX_RESULT	i_err;
	s32			i;
	HMENU		hMain,hInput,hOutput;

	stx_base_pin* pin;


	i_err = STX_FAIL;
	hMain = NULL;
	hInput = NULL;
	hOutput = NULL;

	do{
		hMain = CreatePopupMenu();
		if( !hMain ) {
			break;
		}

		// input pin
		hInput = CreatePopupMenu();
		if( !hInput ) {
			break;
		}

		for( i = 0; i < the->m_iInputPin; i ++ ) {

			s32 i_pin;
			stx_media_type_inf minf;
			base_pin_wnd_get_pin_inf(the->m_hhInputPinWnd[i],&i_pin,&minf);

			InsertMenu(hInput, i, MF_BYPOSITION, WM_INPUTPIN+i,*minf.sub_type_name);
			// checked ?
			if( the->m_hhInputPinWnd[i]->GetPin(the->m_hhInputPinWnd[i]) ) {
				::CheckMenuItem(hInput, WM_INPUTPIN+i, MF_CHECKED);
			}
		}

		InsertMenu(hMain, 0, MF_BYPOSITION, 0, "input pin");
		ModifyMenu(hMain, 0, MF_BYPOSITION | MF_POPUP, (UINT)hInput, "input pin");

		// output pin;
		hOutput = CreatePopupMenu();
		if( !hOutput ) {
			break;
		}

		for( i = 0; i < the->m_iOutputPin; i ++ ) {

			s32 i_pin;
			stx_media_type_inf minf;
			base_pin_wnd_get_pin_inf((base_pin_wnd*)the->m_hhOutputPinWnd[i],&i_pin,&minf);

			InsertMenu(hOutput, i, MF_BYPOSITION, WM_OUTPUTPIN+i,*minf.sub_type_name);
			// checked ?
			if( the->m_hhOutputPinWnd[i]->GetPin(the->m_hhOutputPinWnd[i]) ) {
				::CheckMenuItem(hOutput, WM_OUTPUTPIN+i, MF_CHECKED);
			}
		}

		InsertMenu(hMain, 1, MF_BYPOSITION, 0, "output pin");
		ModifyMenu(hMain, 1, MF_BYPOSITION | MF_POPUP, (UINT)hOutput, "output pin");

		// close
		InsertMenu(hMain, 2, MF_BYPOSITION, WM_REMFLT, "remove filter");

		UINT wCmd = ::TrackPopupMenu(hMain, TPM_RETURNCMD|TPM_NONOTIFY, 
			point.x, point.y, 0, the->m_hWnd, NULL);

		if( WM_REMFLT == wCmd){
			::PostMessage(the->m_hWnd,WM_REMFLT,(WPARAM)the,0);
		}
		else if( wCmd >= WM_INPUTPIN && wCmd < WM_INPUTPIN + 100) {

			i = WM_INPUTPIN - wCmd;
			if( pin = the->m_hhInputPinWnd[i]->GetPin(the->m_hhInputPinWnd[i]) ) {
				pin->break_connect(pin);
				the->m_hhInputPinWnd[i]->ReleasePin(the->m_hhInputPinWnd[i]);
			}
		}
		else if( wCmd >= WM_OUTPUTPIN && wCmd < WM_OUTPUTPIN + 100) {

			// uncheck means bread connect;
			i = WM_OUTPUTPIN - wCmd;
			if( pin = the->m_hhInputPinWnd[i]->GetPin(the->m_hhInputPinWnd[i]) ) {
				pin->break_connect(pin);
				the->m_hhInputPinWnd[i]->ReleasePin(the->m_hhInputPinWnd[i]);
			}
		}

		i_err = STX_OK;

	}while(FALSE);


	if( STX_OK != i_err ) {
		if( hInput ) {
			::DestroyMenu(hInput);
		}
		if( hOutput) {
			::DestroyMenu(hOutput);
		}
	}

	::DestroyMenu(hMain);

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT  fw_create_dlg( base_flt_wnd* the)
{
	flt_set_dlg dlg(NULL,the->m_hFilter);

	dlg.DoModal();

	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT fw_paint(base_flt_wnd*the, HDC hdc, RECT rc  )
{

	s32     i;

	b32     b_left,b_top,b_right,b_bottom;
	s32		left;
	s32		top;
	s32		right;
	s32		bottom;

	HGDIOBJ hBrush,hRestore;

	RECT    clip;

	b_left = the->m_pos.left < rc.left ? FALSE : TRUE;
	b_top = the->m_pos.top < rc.top ? FALSE : TRUE;
	b_right = the->m_pos.right >= rc.right ? FALSE : TRUE;
	b_bottom = the->m_pos.bottom >= rc.bottom ? FALSE : TRUE;

	left = b_left ?  the->m_pos.left:rc.left;
	top = b_top ? the->m_pos.top: rc.top ;
	right = b_right ? the->m_pos.right : rc.right;
	bottom = b_bottom ? the->m_pos.bottom : rc.bottom;

	// set caption;
	if( !the->m_iTitleClip )	{
		s32		i,i_width;
		char*	sz = the->m_hFilter->get_name(the->m_hFilter);
		s32		i_len = (s32)strlen(sz);

		for( i = 0; i < i_len; i ++ ) {

			if( !GetCharWidth32(hdc,sz[i],sz[i],&i_width) ) {
				break;
			}
			the->m_iTitleWidth += i_width;
			if( the->m_iTitleWidth > FLTWND_WIDTH ) {
				the->m_iTitleClip = i;
				break;
			}
		}
	}


	if( b_left && b_top && the->m_iTitleClip) {
		char*	sz = the->m_hFilter->get_name(the->m_hFilter);
		COLORREF c = SetTextColor(hdc,RGB(0,0,255));

		if( ::PtInRect(&the->m_caption,the->m_point) ) {
			s32	i_len = (s32)strlen(sz);
			TextOut(hdc,left + TITLE_LEFT, top + TITLE_TOP,sz, i_len );
		}
		else {
			TextOut(hdc,left + TITLE_LEFT, top + TITLE_TOP,sz, the->m_iTitleClip );
		}
		SetTextColor(hdc,c);
	}// output title;

	if( the->m_bFocus ) {
		hBrush = ::CreatePen( PS_SOLID,2,RGB(0,0,255) );
	}
	else {
		hBrush = ::CreatePen( PS_SOLID,1,RGB(0,0,0) );
	}

	hRestore = ::SelectObject(hdc,hBrush ); 

	::MoveToEx(hdc,left,top,(LPPOINT) NULL);

	if( b_left ) {
		::LineTo(hdc,left,bottom);
		::MoveToEx(hdc,left,top,(LPPOINT) NULL);
	}

	if( b_top ) {
		::LineTo(hdc,right,top);
	}

	::MoveToEx(hdc,right,bottom,(LPPOINT) NULL);

	if( b_right ) {
		::LineTo(hdc,right,top);
		::MoveToEx(hdc,right,bottom,(LPPOINT) NULL);
	}

	if( b_bottom ) {
		::LineTo(hdc,left,bottom);
	}

	if( hRestore ) {
		::SelectObject(hdc,hRestore);
	}
	::DeleteObject(hBrush);

	SetRect(&clip,left,top,right,bottom);

	for( i = 0; i < the->m_iInputPin; i ++ ) {
		pin_wnd_paint(the->m_hhInputPinWnd[i],hdc,rc);
	}

	for( i = 0; i < the->m_iOutputPin; i ++ ) {
		pin_wnd_paint((base_pin_wnd*)the->m_hhOutputPinWnd[i],hdc,rc);
	}

	return STX_OK;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
BOOL fw_OnMouseMove(base_flt_wnd*the,UINT nFlags, CPoint point)
{
	s32 i;

	the->m_point = point;

	for( i = 0; i < the->m_iInputPin; i ++ ) {
		if( ::PtInRect(&the->m_hhInputPinWnd[i]->m_pos,point)) {
			pin_wnd_OnMouseMove(the->m_hhInputPinWnd[i],nFlags,point);
			return FALSE;
		}
	}

	for( i = 0; i < the->m_iOutputPin; i ++ ) {
		if( ::PtInRect(&the->m_hhOutputPinWnd[i]->m_pos,point)) {
			pin_wnd_OnMouseMove((base_pin_wnd*)the->m_hhOutputPinWnd[i],nFlags,point);
			return FALSE;
		}
	}

	return FALSE;

}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
BOOL fw_OnLButtonDblClk(base_flt_wnd*the,UINT nFlags, CPoint point)
{
	s32 i;

	s32 b_click = FALSE;

	for( i = 0; i < the->m_iInputPin; i ++ ) {
		b_click |= pin_wnd_OnLButtonDblClk(the->m_hhInputPinWnd[i],nFlags,point);
	}

	for( i = 0; i < the->m_iOutputPin; i ++ ) {
		b_click |= pin_wnd_OnLButtonDblClk((base_pin_wnd*)the->m_hhOutputPinWnd[i],nFlags,point);
	}

	if( b_click ){
		return b_click;
	}

	// filter wnd dbclick;
	if( ::PtInRect(&the->m_pos,point ) ) {

		fw_create_dlg(the);

		return TRUE;
	}
	
	return FALSE;

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT fw_OnLButtonDown
(base_flt_wnd*the,UINT nFlags, CPoint point,base_pin_wnd** pp_pwnd)
{
	s32				i;
	b32				b_hit;
	b32             b_connect;

	STX_RESULT		i_err;	

	if( ! ::PtInRect(&the->m_pos,point) ) {
		if( the->m_bFocus ){
			the->m_bFocus = FALSE;
			return STX_RET_PAINT;
		}
		return STX_OK;
	}// if( ! ::PtInRect(&m_pos,point) ) {

	the->m_bFocus = TRUE;

	//TRACE1("OnLButtonDown: name = %s\r\n",m_hFilter->get_name(m_hFilter));

	b_hit = FALSE;
	b_connect = FALSE;

	for( i = 0; i < the->m_iInputPin; i ++ ) {
		i_err = pin_wnd_OnLButtonDown(the->m_hhInputPinWnd[i],nFlags,point);
		if( STX_RET_HIT == i_err || STX_RET_PAINT == i_err ) {
			b_hit = TRUE;
		}
		else if( STX_RET_CONNECT == i_err ) {
			b_connect = TRUE;
			*pp_pwnd = the->m_hhInputPinWnd[i];
		}
	}

	for( i = 0; i < the->m_iOutputPin; i ++ ) {
		i_err = pin_wnd_OnLButtonDown((base_pin_wnd*)the->m_hhOutputPinWnd[i],nFlags,point);
		if( STX_RET_HIT == i_err || STX_RET_PAINT == i_err ) {
			b_hit = TRUE;
		}
		else if( STX_RET_CONNECT == i_err ) {
			b_connect = TRUE;
			*pp_pwnd = (base_pin_wnd*)the->m_hhOutputPinWnd[i];
		}
	}

	if( b_connect ) {
		return STX_RET_CONNECT;
	}

	if( b_hit ) {
		return STX_RET_HIT;
	}

	// in filter wnd;
	the->m_bDrag = TRUE;
	the->m_lastPoint = point;

	return STX_RET_MOVE;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT fw_OnLButtonUp
(base_flt_wnd*the,UINT nFlags, CPoint point,RECT clip,base_pin_wnd** pp_pwnd)
{
	s32			i;
	b32			b_hit;
	b32         b_connect;

	STX_RESULT	i_err;

	if( the->m_bDrag ) {

		//TRACE1("OnLButtonUp: name = %s\r\n",m_hFilter->get_name(m_hFilter));

		the->m_bDrag = FALSE;

		// map canvas position;
		s32 i_mov_x = point.x - the->m_lastPoint.x;
		s32 i_mov_y = point.y - the->m_lastPoint.y;

		fw_move(the,i_mov_x,i_mov_y,clip);

		return STX_RET_MOVE;
	}

	b_hit = FALSE;
	b_connect = FALSE;

	for( i = 0; i < the->m_iInputPin; i ++ ) {
		i_err = pin_wnd_OnLButtonUp(the->m_hhInputPinWnd[i],nFlags,point);
		if( STX_RET_HIT == i_err || STX_RET_PAINT == i_err ) {
			b_hit = TRUE;
		}
		else if( STX_RET_CONNECT == i_err ) {
			*pp_pwnd = the->m_hhInputPinWnd[i];
			b_connect = TRUE;
		}
	}//for( i = 0; i < m_iInputPin; i ++ ) {

	for( i = 0; i < the->m_iOutputPin; i ++ ) {
		i_err = pin_wnd_OnLButtonUp((base_pin_wnd*)the->m_hhOutputPinWnd[i],nFlags,point);
		if( STX_RET_HIT == i_err || STX_RET_PAINT == i_err) {
			b_hit = TRUE;
		}
		else if( STX_RET_CONNECT == i_err ) {
			*pp_pwnd = (base_pin_wnd*)the->m_hhOutputPinWnd[i];
			b_connect = TRUE;
		}
	}//for( i = 0; i < m_iOutputPin; i ++ ) {

	if( b_connect ) {
		return STX_RET_CONNECT;
	}

	if( b_hit ) {
		return STX_RET_HIT;
	}

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void fw_OnSize(base_flt_wnd*the,UINT nType, int cx, int cy)
{

}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

BOOL fw_OnSetCursor(base_flt_wnd*the,
							 CWnd* pWnd,
							 UINT nHitTest,
							 UINT message 
							 )
{

	return FALSE;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

BOOL fw_OnRButtonDown(base_flt_wnd*the,UINT nFlags, CPoint point)
{
	s32 i;


	for( i = 0; i < the->m_iInputPin; i ++ ) {
		if( the->m_hhInputPinWnd[i] ) {
			if( pin_wnd_OnRButtonDown(the->m_hhInputPinWnd[i],nFlags,point) ) {
				return TRUE;
			}
		}
	}


	for( i = 0; i < the->m_iOutputPin; i ++ ) {
		if( the->m_hhOutputPinWnd[i] ) {
			if( pin_wnd_OnRButtonDown((base_pin_wnd*)the->m_hhOutputPinWnd[i],nFlags,point) ) {
				return TRUE;
			}
		}
	}

	if( !::PtInRect(&the->m_pos,point) ) {
		return FALSE;
	}

	fw_create_menu(the,point);

	return TRUE;
}

