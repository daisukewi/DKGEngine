/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-10
***********************************************************************************/
// stx_gph_editDlg.cpp : implementation file
//

#include "stdafx.h"

#include "stx_gph_edit.h"
#include "stx_gph_editDlg.h"

#include "AddFilter.h"
#include "UrlDlg.h"

#include "stx_all.h"
#include "stx_canvas.h"

#include "LxBmpHandle.h"
#include "play_window.h"

#include "ActiveMovieWindow.h"

#include "PrsDlg.h"

#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

extern stx_base_graph_builder* g_gbd;
extern stx_base_plugin* g_gbd_hnd;

s32 g_iMaxGraph = MAX_GRAPH;

static char			g_szProgramPath[2048];
static char*		g_szCfgName = "graph_edit.xini";

static char*		g_szLastPath = "Recent Path";
static char*		g_szLastGraph = "Recent Graph";
static char*		g_szMaxLastGraph = "Max Recent Graph";

static AddFilter*	pAddFltDlg= NULL;
static stx_canvas*	g_h_canvas = NULL;
static LxBmpHandle* g_BmpHnd = NULL;


/*{{{STX_MSG_PROC_DECLARE***************************************************/
STX_MSG_PROC_DECLARE(dispatch_msg)
/*}}}***********************************************************************/

/*{{{STX_MSG_ENTRY_DECLARE**************************************************/
STX_MSG_ENTRY_DECLARE(on_query_obj)
STX_MSG_ENTRY_DECLARE(on_auto_stop)
/*}}}***********************************************************************/

/*{{{STX_BEGIN_MSG_MAP******************************************************/
STX_BEGIN_MSG_MAP(the_msg_data)
/* to do : add msg process entry here; */
ON_STX_MSG(STX_MSG_QueryObject,on_query_obj)
ON_STX_MSG(STX_MSG_AutoStop,on_auto_stop)
STX_END_MSG_MAP
/*}}}***********************************************************************/

/*{{{STX_DISPATCH_MSG_PROC**************************************************/
STX_DISPATCH_MSG_PROC( dispatch_msg,the_msg_data )
/*}}}***********************************************************************/





/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

static void GetPath(char* szPath)
{
	TCHAR* p = szPath;
	while(*p)++p;// let p point to '\0'
	while('\\' != *p)--p;// let p point to '\\'
	*p = '\0';// get the path
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
char* make_filter_string(char* buf, size_t i_size,const char* sz_desc,const char* sz_ext)
{
	char sz_media_type[] = "Valid Media Types\0";

	char sz_ext1[128];
	char sz_ext2[128];
	char sz_ext3[128];

	size_t t0,t1,t2,t3,t_all;

	memset(buf,0,i_size);
	stx_sprintf(sz_ext1,sizeof(sz_ext1),"*%s;",sz_ext);
	stx_sprintf(sz_ext2,sizeof(sz_ext2),"%s(*%s);",sz_desc,sz_ext);
	stx_sprintf(sz_ext3,sizeof(sz_ext3),"*%s",sz_ext);

	t0 = strlen(sz_media_type) + 1;
	t1 = strlen(sz_ext1) + 1;
	t2 = strlen(sz_ext2) + 1;
	t3 = strlen(sz_ext3) + 1;

	t_all =  t0 + t1 + t2 + t3;

	if( i_size < t_all ) {
		return NULL;
	}

	memcpy(buf,sz_media_type,t0);
	buf += t0;
	memcpy(buf,sz_ext1,t1);
	buf += t1;
	memcpy(buf,sz_ext2,t2);
	buf += t2;
	memcpy(buf,sz_ext3,t3);

	return buf;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
char*  OpenDllFile(HWND hwnd,char* sz_last_path)
{
	return OpenTypedFile(hwnd,sz_last_path,"dll file",".dll");
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
char*  OpenTypedFile(HWND hwnd,char* sz_last_path,const char* sz_desc,const char* sz_ext)
{
	OPENFILENAME ofn;       // common dialog box structure
	TCHAR	szFile[2562];       // buffer for file name

	szFile[0] = 0;

	TCHAR szPath[1024] = {0};

	if( !sz_last_path ) {
		GetCurrentPath(szPath,sizeof(szPath));
	}
	else{
		stx_strcpy(szPath,sizeof(szPath),sz_last_path);
	}

	char		sz_filter[1024];
	make_filter_string(sz_filter,sizeof(sz_filter),sz_desc,sz_ext);

	// Initialize OPENFILENAME
	ZeroMemory(&ofn, sizeof(ofn));
	ofn.lStructSize = sizeof(ofn);
	ofn.hwndOwner = hwnd;
	ofn.lpstrFile = szFile;
	ofn.nMaxFile = sizeof(szFile);
	ofn.nFilterIndex = 1;
	ofn.lpstrFileTitle = NULL;
	ofn.nMaxFileTitle = 0;
	ofn.lpstrFilter = sz_filter;
	ofn.lpstrDefExt = sz_ext;
	ofn.lpstrInitialDir = szPath;
	ofn.Flags = OFN_PATHMUSTEXIST | 
		OFN_FILEMUSTEXIST | 
		OFN_EXPLORER | 			
		OFN_HIDEREADONLY | 
		OFN_EXPLORER;

	// Display the Open dialog box. 
	if ( !GetOpenFileName(&ofn) ) {
		return NULL;
	}

	return stx_strdup(szFile);
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
char*  OpenGraphFile(HWND hwnd,char* sz_last_path)
{
	return OpenTypedFile(hwnd,sz_last_path,"graph file",".gph");
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
char*  SaveTypedFile(HWND hwnd,char* sz_last_path,const char* sz_desc,const char* sz_ext)
{
	OPENFILENAME ofn;       // common dialog box structure
	TCHAR szFile[2562];       // buffer for file name
	szFile[0] = 0;

	TCHAR szPath[1024] = {0};

	if( !sz_last_path ) {
		GetCurrentPath(szPath,sizeof(szPath));
	}
	else{
		stx_strcpy(szPath,sizeof(szPath),sz_last_path);
	}

	char		sz_filter[1024];
	make_filter_string(sz_filter,sizeof(sz_filter),sz_desc,sz_ext);

	// Initialize OPENFILENAME
	ZeroMemory(&ofn, sizeof(ofn));
	ofn.lStructSize = sizeof(ofn);
	ofn.hwndOwner = hwnd;
	ofn.lpstrFile = szFile;
	ofn.nMaxFile = sizeof(szFile);
	ofn.nFilterIndex = 1;
	ofn.lpstrFileTitle = NULL;
	ofn.nMaxFileTitle = 0;
	ofn.lpstrFilter = sz_filter;
	ofn.lpstrDefExt = sz_ext;
	ofn.lpstrInitialDir = szPath;
	ofn.Flags = OFN_SHOWHELP | OFN_OVERWRITEPROMPT;

	// Display the Open dialog box. 
	if ( !GetSaveFileName(&ofn) ) {
		return NULL;
	}

	return stx_strdup(szFile);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

char*  SaveGraphFile(HWND hwnd,char* sz_last_path)
{
	return SaveTypedFile(hwnd,sz_last_path,"graph file",".gph");
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
char*  SavePrsFile(HWND hwnd,char* sz_last_path)
{
	return SaveTypedFile(hwnd,sz_last_path,"prs file",".prs");
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
char*  OpenPrsFile(HWND hwnd,char* sz_last_path)
{
	return OpenTypedFile(hwnd,sz_last_path,"prs file",".prs");
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

static LPCTSTR g_szOpenFlvFilter = 
#if 0
_T(
   "Valid Media Types\0"
   "*.flv;*.vob;*.ts;*.mpg;\0"
   "flash video file(*.flv)\0"
   "*.flv;*.vob;*.ts;*.mpg\0"
   "\0"
   );
#else
_T(
   "Valid Media Types\0"
   "**.prs;*.avb;*.xliv;*.vob;*.dat;*.mpg;*.mpeg;*.mpa;*.mpe;*.ts;*.m2ts;*.mpv;*.m1v;*.m2v;*.avi;*.asf;*.wm;*.wmv;*.divx;*.mov;*.qt;*.swf;*.flv;*.ra;*.rm;*.ram;*.rmvb;*.mpga;*.wav;*.wma;*.mid;*.midi;*.rmi;*.cda;*.mp1;*.mp2;*.mp3;*.au;*.snd;*.aif;*.aiff;*.lst;\0"
  "streamx prs File(*.prs)\0"
   "*.prs\0"
   "LxLive AVB File(*.avb)\0"
   "*.avb\0"
   "LxLive XLIV File(*.xliv)\0"
   "*.xliv\0"
   "Video Object File(*.vob)\0"
   "*.vob\0"
   "VideoCD File(*.dat)\0"
   "*.dat\0"
   "MPEG Media File(*.mpg;*.mpeg;*.mpa;*.mpe;*.ts;*.m2ts;)\0"
   "*.mpg;*.mpeg;*.mpa;*.mpe;*ts;*m2ts\0"
   "MPEG Video File (*.mpv;*.m1v;*.m2v)\0"
   "*.mpv;*.m1v;*.m2v\0"
   "Windows Video File(*.avi;*.asf;*.wm;*.wmv;*.divx)\0"
   "*.avi;*.asf;*.wm;*.wmv;*.divx\0"
   "Quicktime Media File(*.mov;*.qt)\0"
   "*.mov;*.qt\0"
   "Flash File(*.swf;*.flv)\0"
   "*.swf;*.flv\0"
   "Real Media File (*.ra;*.rm;*.ram;*.rmvb)\0"
   "*.ra;*.rm;*.ram;*.rmvb\0"
   "Windows Audio File(*.wav;*.wma)\0"
   "*.wav;*.wma\0"
   "MIDI Audio File(*.mid;*.midi;*.rmi)\0"
   "*.mid;*.midi;*.rmi\0"
   "MPEG Audio File(*.mp3;*.mp2;*.mp1;)\0"
   "*.mp3;*.mp2;*.mp1\0"
   "Other Audio File(*.au;*.snd;*.aif;*.aiff)\0"
   "*.au;*.snd;*.aif;*.aiff\0"
   "Video File List(*.lst)\0"
   "*.lst\0"
   "All Files(*.*)\0"
   "*.*\0"
   "\0"
   );
#endif

char*  OpenFlvFile(HWND hwnd,char* sz_last_path)
{
	OPENFILENAME ofn;       // common dialog box structure
	TCHAR szFile[2562];       // buffer for file name
	szFile[0] = 0;

	TCHAR szPath[1024] = {0};

	if( !sz_last_path ) {
		GetCurrentPath(szPath,sizeof(szPath));
	}
	else{
		stx_strcpy(szPath,sizeof(szPath),sz_last_path);
	}

	// Initialize OPENFILENAME
	ZeroMemory(&ofn, sizeof(ofn));
	ofn.lStructSize = sizeof(ofn);
	ofn.hwndOwner = hwnd;
	ofn.lpstrFile = szFile;
	ofn.nMaxFile = sizeof(szFile);
	ofn.nFilterIndex = 1;
	ofn.lpstrFileTitle = NULL;
	ofn.nMaxFileTitle = 0;
	ofn.lpstrFilter = g_szOpenFlvFilter;
	ofn.lpstrDefExt = ".flv";
	ofn.lpstrInitialDir = szPath;
	ofn.Flags = OFN_PATHMUSTEXIST | 
		OFN_FILEMUSTEXIST | 
		OFN_EXPLORER | 			
		OFN_HIDEREADONLY | 
		OFN_EXPLORER;

	// Display the Open dialog box. 
	if ( !GetOpenFileName(&ofn) ) {
		return NULL;
	}

	return stx_strdup(szFile);
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

// Cstx_gph_editDlg dialog


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

Cstx_gph_editDlg::Cstx_gph_editDlg(CWnd* pParent /*=NULL*/)
	: CDialog(Cstx_gph_editDlg::IDD, pParent)
{
	m_szLastPath = NULL;
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	m_iMaxGraph = 0;
	m_szGraphName = NULL;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void Cstx_gph_editDlg::cleanup()
{
	if( g_BmpHnd ) {
		delete g_BmpHnd;
		g_BmpHnd = NULL;
	}

	CloseGraph();

	m_menu.DestroyMenu();

	if( pAddFltDlg ) {
		pAddFltDlg->DestroyWindow();
		delete pAddFltDlg;
		pAddFltDlg =  NULL;
	}

	SaveConfig();

	m_szLastGraph.RemoveAll();

	if( m_szGraphName ) {
		delete m_szGraphName;
	}
}

Cstx_gph_editDlg::~Cstx_gph_editDlg()
{
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

int Cstx_gph_editDlg::LoadConfig()
{
	STX_RESULT  i_err;
	STX_HANDLE  h_path;
	char*       sz_path;
	stx_xini*   h_cfg;
	s32			i,i_item;
	char        sz_key[2048];

	i_err = STX_FAIL;
	h_cfg = NULL;

	GetCurrentPath(g_szProgramPath,sizeof(g_szProgramPath));

	do{

		stx_sprintf(sz_key,sizeof(sz_key),"%s\\%s",g_szProgramPath,g_szCfgName);

		i_err = stx_ini_create( sz_key, STX_NULL, STX_INI_READ_ONLY | STX_INI_NO_COMMENT, 0,&h_cfg );
		if( STX_OK != i_err ) {
			if( STX_ERR_FILE_NOT_FOUND == i_err ) {
				i_err = stx_ini_create( sz_key, STX_NULL, STX_INI_READ_WRITE | STX_INI_NO_COMMENT, 0,&h_cfg );
				if( STX_OK != i_err ) {
					break;
				}
			}
			else {
				break;
			}
		}

		i_err = h_cfg->create_key( h_cfg, STX_NULL, g_szMaxLastGraph, NULL, &h_path );
		if( STX_INI_OK != i_err ) {
			break;
		}
		i_err = h_cfg->read_int32(h_cfg,h_path,&m_iMaxGraph);
		if( STX_INI_OK != i_err ) {
			break;
		}

		i_err = h_cfg->create_key( h_cfg, STX_NULL, g_szLastPath, g_szProgramPath, &h_path );
		if( STX_INI_OK != i_err ) {
			break;
		}

		i_err = h_cfg->read_string(h_cfg,h_path,&sz_path);
		if( STX_INI_OK != i_err ) {
			break;
		}

		m_szLastPath = stx_strdup(sz_path);
		if( !m_szLastPath ) {
			break;
		}

		i_err = h_cfg->create_key( h_cfg, STX_NULL, g_szLastGraph, NULL, &h_path );
		if( STX_INI_OK != i_err ) {
			break;
		}
		i_err = h_cfg->get_sub_key_num(h_cfg,h_path,&i_item);
		if( STX_INI_OK != i_err ) {
			break;
		}

		for( i = 0; i < i_item; i ++ ) {

			STX_HANDLE h_key;

			i_err = h_cfg->get_sub_key( h_cfg,h_path,i,&h_key );
			if( STX_INI_OK != i_err ) {
				break;
			}

			i_err = h_cfg->read_string(h_cfg,h_key,&sz_path);
			if( STX_INI_OK != i_err ) {
				break;
			}

			m_szLastGraph.Add(sz_path);

		} // for( i = 0; i < i_item; i ++ ) {

		if( STX_INI_OK != i_err ) {
			break;
		}

		i_err = STX_OK;

	}while(FALSE);

	if( h_cfg ) {
		h_cfg->close(h_cfg);
		h_cfg = NULL;
	}

	return (int)i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void Cstx_gph_editDlg::SaveConfig()
{
	STX_RESULT	i_err;
	STX_HANDLE	h_path;
	stx_xini*   h_cfg;
	char		sz_key[2048];
	s32			i,i_item;


	h_cfg = NULL;

	do{
		stx_sprintf(sz_key,sizeof(sz_key),"%s\\%s",g_szProgramPath,g_szCfgName);

		i_err = stx_ini_create( sz_key, STX_NULL, STX_INI_READ_WRITE | STX_INI_NO_COMMENT, 0,&h_cfg );
		if( STX_INI_OK != i_err ) {
			break;
		}

		i_err = h_cfg->create_key( h_cfg, STX_NULL, g_szLastPath, NULL, &h_path );
		if( STX_INI_OK != i_err ) {
			break;
		}
		if( m_szLastPath ) {
			i_err = h_cfg->write_string(h_cfg,h_path,m_szLastPath);
			if( STX_INI_OK != i_err ) {
				break;
			}
		}

		i_err = h_cfg->create_key( h_cfg, STX_NULL, g_szMaxLastGraph, NULL, &h_path );
		if( STX_INI_OK != i_err ) {
			break;
		}
		i_err = h_cfg->write_int32(h_cfg,h_path,m_iMaxGraph);
		if( STX_INI_OK != i_err ) {
			break;
		}

		i_err = h_cfg->create_key( h_cfg, STX_NULL, g_szLastGraph, g_szLastGraph, &h_path );
		if( STX_INI_OK != i_err ) {
			break;
		}

		i_item = (s32)m_szLastGraph.GetCount();

		if( i_item > m_iMaxGraph ) {
			i_item = m_iMaxGraph;
		}

		for( i = 0; i < i_item; i ++ ) {

			STX_HANDLE h_key;
			char* sz_item;
			s32 i_len;
			CString cs_item;

			stx_sprintf(sz_key,sizeof(sz_key),"%s-%d",g_szLastGraph,i);

			i_err = h_cfg->create_key( h_cfg, h_path, sz_key,sz_key, &h_key );
			if( STX_INI_OK != i_err ) {
				break;
			}

			cs_item = m_szLastGraph.GetAt(i);
			i_len = cs_item.GetLength() + 16;
			sz_item = (char*)cs_item.GetBuffer( i_len );
			i_err = h_cfg->write_string(h_cfg,h_path,sz_item);
			if( STX_INI_OK != i_err ) {
				break;
			}

		} // for( i = 0; i < i_item; i ++ ) {

	}while(FALSE);

	if( h_cfg ) {
		h_cfg->close(h_cfg);
		h_cfg = NULL;
	}

	if( m_szLastPath ) {
		free(m_szLastPath);
	}

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void Cstx_gph_editDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

BEGIN_MESSAGE_MAP(Cstx_gph_editDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()

	ON_WM_LBUTTONDBLCLK()
	ON_WM_DROPFILES()
	ON_WM_SIZE()
	ON_WM_SIZING()
	ON_WM_MOUSEWHEEL()
	ON_WM_LBUTTONDOWN()
	ON_WM_RBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_SETCURSOR()
	ON_WM_HSCROLL()
	ON_WM_VSCROLL()

	ON_MESSAGE(WM_PAINT_CANVUS, OnPaintCanvas)
	ON_MESSAGE(WM_ADDFLT, OnAddFlt)
	ON_MESSAGE(WM_RESIZE_FLTWND, OnFltResize)
	ON_MESSAGE(WM_AUTO_SOTP, OnAutoStop)
	//ON_MESSAGE(WM_ERASEBKGND, OnEraseBkgnd)

	ON_COMMAND(ID_FILE_LOADGRAPH, OnLoadGraph)
	ON_COMMAND(ID_FILE_NEWGRAPH, OnNewGraph)
	ON_COMMAND(ID_FILE_RENDFILE, OnRendStream)
	ON_COMMAND(ID_FILE_SAVEGRAPH, OnSaveGraph)
	ON_COMMAND(ID_FILE_SAVEGRAPHAS, OnSaveGraphAs)
	ON_COMMAND(ID_FILE_CLOSEGRAPH, OnCloseGraph)
	ON_COMMAND(ID_FILTER_ADDFILTER, OnAddFilter)
	ON_COMMAND(ID_FILTER_ADDFILTERFROMDLL, OnAddFilterFromDLL)
	ON_COMMAND(ID_FILTER_VIEWFILTER, OnViewFilter)
	ON_COMMAND(ID_FILTER_VIEWFILTERFROMDLL, OnViewFilterFromDLL)
	ON_COMMAND(ID_FILTER_REGISTERFILTER, OnRegisterFilter)
	ON_COMMAND(ID_FILTER_UNREGISTERFILTER, OnUnRegisterFilter)
	ON_COMMAND(ID_FILTER_REGISTERPROTOCOLFILTER, OnRegisterProtocolFilter)
	ON_COMMAND(ID_FILTER_UNREGISTERPROTOCOLFILTER, OnUnRegisterProtocolFilter)
	ON_COMMAND(ID_FILTER_REGISTERSTARTUPMODULE, OnRegisterStartModule)
	ON_COMMAND(ID_FILTER_UNREGISTERSTARTUPMODULE, OnUnRegisterStartModule)
	ON_COMMAND(ID_FILTER_REGISTERSTREAM, OnRegisterStream)
	ON_COMMAND(ID_FILTER_UNREGISTERSTREAM, OnUnRegisterStream)
	ON_COMMAND(ID_GRAPH_OPENFILE, OnOpenFile)
	ON_COMMAND(ID_GRAPH_LOADSTREAM, OnLoadStream)
	ON_COMMAND(ID_TOOLS_PRSMAKER, OnPrsMaker)
	ON_COMMAND(ID_GRAPH_CLOSESTREAM, OnCloseStream)
	ON_COMMAND(ID_GRAPH_RENDPIN, OnRendPin)
	ON_COMMAND(ID_GRAPH_RENDRENDER,OnRendRender)
	ON_COMMAND(ID_GRAPH_RUNGRAPH, OnRunGraph)
	ON_COMMAND(ID_GRAPH_PAUSE, OnPause)
	ON_COMMAND(ID_GRAPH_RESUME,OnResume)
	ON_COMMAND(ID_GRAPH_STOP,OnStop)

	//}}AFX_MSG_MAP
END_MESSAGE_MAP()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

// Cstx_gph_editDlg message handlers

BOOL Cstx_gph_editDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

// #define PI 3.14159265359
// 	const f64 g_fC1 = 1.0;
// 	const f64 g_fC2 = 2 * cos (PI/8);
// 	const f64 g_fC4 = sqrt(2.0);
// 	const f64 g_fC6 = 2 * sin (PI/8);


	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here

	m_menu.LoadMenu(IDR_MENU_MAIN);
	SetMenu(&m_menu);

	InitMenu();

	TCHAR szBmp[1024] = {0};
	GetCurrentPath(szBmp,sizeof(szBmp));
	stx_strcat(szBmp,sizeof( szBmp),"\\demo.bmp");

	g_BmpHnd = new LxBmpHandle;
	if( !g_BmpHnd ){
		return FALSE;
	}

	if( LX_OK != g_BmpHnd->LoadBmp(szBmp) ) {
		::MessageBox(NULL,"demo.bmp load failed.",NULL,MB_OK); //_CN
		return FALSE;
	}

	int   nSrcWidth,nSrcHeight;

	if( LX_OK == g_BmpHnd->GetSrcSize(&nSrcWidth,&nSrcHeight) ) {

		RECT rect_scr;
		RECT rect_client;
		::GetClientRect(m_hWnd,&rect_client);
		::ClientRectToScreen(m_hWnd, &rect_client);
		::GetWindowRect(m_hWnd,&rect_scr);

		int nx = rect_client.left - rect_scr.left;
		int ny = rect_scr.bottom - rect_client.bottom;
		int nc = rect_client.top - rect_scr.top;

		int   nSrcWidth,nSrcHeight;

		if( LX_OK == g_BmpHnd->GetSrcSize(&nSrcWidth,&nSrcHeight) ) {
			rect_scr.right = rect_scr.left + nSrcWidth + nx + nx;
			rect_scr.bottom = rect_scr.top + nSrcHeight + nc + ny;
		}
		::SetWindowPos(m_hWnd,
			NULL, 
			0,
			0, 
			rect_scr.right - rect_scr.left + 1,
			rect_scr.bottom - rect_scr.top, 
			SWP_NOZORDER|SWP_NOMOVE );
	}

	if( STX_OK != LoadConfig() ){
		return FALSE;
	}

	return TRUE;  // return TRUE  unless you set the focus to a control
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void Cstx_gph_editDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}



/***************************************************************************************
void PaintWindow(HWND hwnd,HDC hdc, RECT rect)
***************************************************************************************/
void PaintWindow(HWND hwnd,HDC hdc, RECT rect)
{
	HDC      dcMem;
	HBITMAP  bmpMem;
	RECT     rectMem;
	HGDIOBJ  hOldObjMem;

	dcMem = CreateCompatibleDC(hdc);

	GetClientRect(hwnd, &rectMem);

	if((rectMem.bottom - rectMem.top) <= 0 || (rectMem.right - rectMem.left) <= 0)	{
		DeleteDC(dcMem);
		return;
	}

	bmpMem = CreateCompatibleBitmap(hdc, 
		GetDeviceCaps(hdc, HORZRES) * 2, 
		GetDeviceCaps(hdc, VERTRES) * 2);

	if(!bmpMem)	{
		bmpMem = CreateCompatibleBitmap(hdc, 
			rectMem.right-rectMem.left, rectMem.bottom-rectMem.top);

		if(!bmpMem)	{
			DeleteDC(dcMem);
			return;
		}
	}

	hOldObjMem = SelectObject(dcMem, bmpMem);
	SetWindowOrgEx(dcMem, rectMem.left, rectMem.top, NULL);	

	if( g_h_canvas ) {
		HBRUSH hBrush = CreateSolidBrush(RGB(0,0,0));
		FillRect(dcMem, &rect, hBrush);
		DeleteObject(hBrush);		
		BitBlt( hdc, 
			rectMem.left, rectMem.top, 
			rectMem.right-rectMem.left, 
			rectMem.bottom-rectMem.top, 
			dcMem, 
			rectMem.left, rectMem.top,
			SRCCOPY);
	}
	else{

		s64 t0 = stx_get_microsec();

		HBITMAP hBk = g_BmpHnd->GetResizeHandle( 
			hdc, 
			(rect.right - rect.left ),  
			(rect.bottom - rect.top ) );

		t0 =  stx_get_microsec() - t0;

		//stx_log("paint window,resample bitmap use %"PRId64"d usec \r\n",t0);

		::SelectObject(dcMem,hBk);

		BitBlt(hdc, 
			rectMem.left, rectMem.top, 
			rectMem.right-rectMem.left, rectMem.bottom-rectMem.top, 
			dcMem, 
			rectMem.left, rectMem.top, 
			SRCCOPY);		
	}

	SelectObject(dcMem, hOldObjMem);
	DeleteObject(bmpMem);
	DeleteDC(dcMem);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void Cstx_gph_editDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{

		if( g_h_canvas ) {	
			CDialog::OnPaint();
			HDC hdc = ::GetDC(m_hWnd);
			g_h_canvas->paint(hdc);
			::ReleaseDC(m_hWnd, hdc);
			return;
		}

		RECT rt;
		PAINTSTRUCT ps;
		HDC hdc = ::BeginPaint(m_hWnd, &ps);
		::GetClientRect(m_hWnd, &rt);
		::PaintWindow(m_hWnd,hdc,rt);
		::EndPaint(m_hWnd, &ps);
	}
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR Cstx_gph_editDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
int Cstx_gph_editDlg::send_msg(void* p)
{
	return (int)dispatch_msg(this,(stx_base_message*)p);
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void Cstx_gph_editDlg::OnCloseStream( )
{
	if( g_h_canvas ) {

		g_h_canvas->OnCloseStream();

		Invalidate();
	}

}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void Cstx_gph_editDlg::OnPrsMaker( )
{
	PrsDlg dlg;

	dlg.DoModal();
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void Cstx_gph_editDlg::OnLoadStream( )
{
	UrlDlg dlg;

	s32 i_err = (s32)dlg.DoModal();

	if( IDOK != i_err ) {

		return;
	}

	if( m_szLastPath ) {
		free(m_szLastPath);
	}
	m_szLastPath = stx_strdup(dlg.m_szUrl);
	GetPath(m_szLastPath);

	i_err = (s32)g_h_canvas->OnLoadStream(dlg.m_szUrl);

	if( STX_OK != i_err ) {
		AfxMessageBox("load stream failed");
		return;
	}

	Invalidate(TRUE);		
	UpdateMenu();
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void Cstx_gph_editDlg::OnOpenFile( )
{
	STX_RESULT i_err;

	char* sz_flv = OpenFlvFile(m_hWnd,m_szLastPath);

	if( !sz_flv ) {
		return;
	}

	if( m_szLastPath ) {
		free(m_szLastPath);
	}
	m_szLastPath = stx_strdup(sz_flv);
	GetPath(m_szLastPath);

	i_err = g_h_canvas->OnLoadStream(sz_flv);

	free(sz_flv);

	if( STX_OK != i_err ) {
		AfxMessageBox("load stream failed");
		return;
	}

	Invalidate(TRUE);		
	UpdateMenu();

}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
int Cstx_gph_editDlg::LoadGraph()
{
	STX_RESULT i_err;

	char* sz_graph = OpenGraphFile(m_hWnd,m_szLastPath);

	if( !sz_graph ) {
		return STX_FAIL;
	}

	if( m_szLastPath ) {
		free(m_szLastPath);
	}
	m_szLastPath = stx_strdup(sz_graph);
	GetPath(m_szLastPath);

	i_err = STX_FAIL;

	do{

		g_h_canvas = new stx_canvas(m_hWnd);
		if(!g_h_canvas) {
			break;
		}

		i_err = g_h_canvas->initialize(sz_graph);
		if( STX_OK != i_err ){
			break;
		}

		i_err = STX_OK;

	}while(FALSE);

	free(sz_graph);

	if( i_err != STX_OK ) {
		if( g_h_canvas ){
			delete g_h_canvas;
			g_h_canvas = NULL;
		}
	}

	Invalidate();
	UpdateMenu();

	return (int)i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void Cstx_gph_editDlg::OnLoadGraph()
{
	if( g_h_canvas ) {
		delete g_h_canvas;
		g_h_canvas = NULL;
	}
	LoadGraph();
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

int Cstx_gph_editDlg::NewGraph()
{
	g_h_canvas = new stx_canvas(m_hWnd);
	if(!g_h_canvas) {
		return STX_FAIL;
	}
	return (int)g_h_canvas->initialize(NULL);
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void Cstx_gph_editDlg::OnNewGraph()
{
	CloseGraph();
	NewGraph ();

	Invalidate();
	UpdateMenu();
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

int Cstx_gph_editDlg::CloseGraph()
{
	SaveGraph();

	if( g_h_canvas ) {
		delete g_h_canvas;
		g_h_canvas = NULL;
	}

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void Cstx_gph_editDlg::OnCloseGraph()
{
	RECT rc;
	CloseGraph();
	GetClientRect(&rc);
	InvalidateRect(&rc,TRUE);
	Invalidate();
	UpdateMenu();
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
int Cstx_gph_editDlg::SaveGraph()
{
	if( !g_h_canvas ) {
		return STX_FAIL;
	}

	STX_RESULT i_err;
	char*      sz_graph;

	i_err = g_h_canvas->serialize(NULL);
	if( STX_OK != i_err ) {
		if( STX_RET_SAVE == i_err ) {
			sz_graph = SaveGraphFile(m_hWnd,m_szLastPath);
			if( !sz_graph ) {
				return STX_FAIL;
			}
			g_h_canvas->serialize(sz_graph);
			if( m_szLastPath ) {
				free(m_szLastPath);
			}
			m_szLastPath = sz_graph;
			GetPath(m_szLastPath);
		}
	}

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void Cstx_gph_editDlg::OnSaveGraph ()
{
	SaveGraph ();
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void Cstx_gph_editDlg::OnSaveGraphAs()
{
	if( !g_h_canvas ) {
		return;
	}

	STX_RESULT i_err;
	char*      sz_graph;

	sz_graph = SaveGraphFile(m_hWnd,m_szLastPath);
	if( !sz_graph ) {
		return;
	}
	g_h_canvas->serialize(sz_graph);
	if( m_szLastPath ) {
		free(m_szLastPath);
	}
	m_szLastPath = sz_graph;
	GetPath(m_szLastPath);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void Cstx_gph_editDlg::OnAddFilterDlgClosed()
{
	pAddFltDlg->DestroyWindow();
	delete pAddFltDlg;
	pAddFltDlg = NULL;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void Cstx_gph_editDlg::OnAddFilter()
{
	if( pAddFltDlg ) {
		pAddFltDlg->DestroyWindow();
		delete pAddFltDlg;
		pAddFltDlg = NULL;
	}

	pAddFltDlg = new AddFilter(this,NULL,NULL,FALSE);

	pAddFltDlg->Create(IDD_DLG_ADDFLT);
	pAddFltDlg->ShowWindow(SW_SHOW);
	pAddFltDlg->UpdateWindow();
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void Cstx_gph_editDlg::OnAddFilterFromDLL()
{
	DECL_TRACE

	STX_RESULT i_err = STX_FAIL;

	char*		sz_dll = NULL;
	stx_xio*	h_stream= NULL;
	stx_xini*	h_xini= NULL;

	do{

		sz_dll = OpenDllFile(m_hWnd,m_szLastPath);
		if( !sz_dll ) {
			return;
		}

		h_stream = XCREATE(stx_io_stream,NULL);
		if( !h_stream ) {
			break;
		}

		i_err = stx_ini_create(NULL,h_stream,STX_INI_READ_WRITE|STX_INI_NO_COMMENT,0,&h_xini);
		if( STX_INI_OK != i_err ) {
			break;
		}

		i_err = g_gbd->get_svr_inf(g_gbd,sz_dll,h_xini);
		if( STX_OK != i_err ) {
			break;
		}

		if( pAddFltDlg ) {
			pAddFltDlg->DestroyWindow();
			delete pAddFltDlg;
			pAddFltDlg = NULL;
		}
		pAddFltDlg = new AddFilter(this,h_xini,h_stream,FALSE);
		if( !pAddFltDlg ) {
			break;
		}
		pAddFltDlg->Create(IDD_DLG_ADDFLT);
		pAddFltDlg->ShowWindow(SW_SHOW);
		pAddFltDlg->UpdateWindow();

		if( m_szLastPath ) {
			free(m_szLastPath);
		}
		m_szLastPath = sz_dll;
		GetPath(m_szLastPath);

		i_err = STX_OK;

	}while(FALSE);


	if(STX_OK != i_err ) {
		AfxMessageBox("internal error;");
		if( h_xini){
			h_xini->close(h_xini);
		}
		if( h_stream ) {
			h_stream->close(h_stream);
		}
		return;
	}
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void Cstx_gph_editDlg::OnViewFilter()
{
	if( pAddFltDlg ) {
		pAddFltDlg->DestroyWindow();
		delete pAddFltDlg;
		pAddFltDlg = NULL;
	}

	pAddFltDlg = new AddFilter(this,NULL,NULL,TRUE);

	pAddFltDlg->Create(IDD_DLG_ADDFLT);
	pAddFltDlg->ShowWindow(SW_SHOW);
	pAddFltDlg->UpdateWindow();
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void Cstx_gph_editDlg::OnViewFilterFromDLL()
{
	DECL_TRACE

	STX_RESULT i_err = STX_FAIL;

	char*		sz_dll = NULL;
	stx_xio*	h_stream= NULL;
	stx_xini*	h_xini= NULL;

	do{

		sz_dll = OpenDllFile(m_hWnd,m_szLastPath);
		if( !sz_dll ) {
			return;
		}

		h_stream = XCREATE(stx_io_stream,NULL);
		if( !h_stream ) {
			break;
		}

		i_err = stx_ini_create(NULL,h_stream,STX_INI_READ_WRITE|STX_INI_NO_COMMENT,0,&h_xini);
		if( STX_INI_OK != i_err ) {
			break;
		}

		i_err = g_gbd->get_svr_inf(g_gbd,sz_dll,h_xini);
		if( STX_OK != i_err ) {
			break;
		}

		// change the attribute;
		h_xini->set_attr(h_xini,STX_INI_READ_ONLY|STX_INI_NO_COMMENT);

		if( pAddFltDlg ) {
			pAddFltDlg->DestroyWindow();
			delete pAddFltDlg;
			pAddFltDlg = NULL;
		}
		pAddFltDlg = new AddFilter(this,h_xini,h_stream,TRUE);
		if( !pAddFltDlg ) {
			break;
		}
		pAddFltDlg->Create(IDD_DLG_ADDFLT);
		pAddFltDlg->ShowWindow(SW_SHOW);
		pAddFltDlg->UpdateWindow();

		if( m_szLastPath ) {
			free(m_szLastPath);
		}
		m_szLastPath = sz_dll;
		GetPath(m_szLastPath);

		i_err = STX_OK;

	}while(FALSE);


	if(STX_OK != i_err ) {
		AfxMessageBox("internal error;");
		if( h_xini){
			h_xini->close(h_xini);
		}
		if( h_stream ) {
			h_stream->close(h_stream);
		}
		return;
	}
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void Cstx_gph_editDlg::OnRegisterStream()
{
	STX_RESULT i_err;

	i_err = g_gbd->reg_stream_default(g_gbd);

	char sz_inf[1024];
	if( STX_OK == i_err ) {
		stx_strcpy(sz_inf,sizeof(sz_inf),"register success;");
	}
	else {
		stx_strcpy(sz_inf,sizeof(sz_inf),"register failed;");
	}

	AfxMessageBox(sz_inf);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void Cstx_gph_editDlg::OnUnRegisterStream()
{
	STX_RESULT i_err;

	i_err = g_gbd->unreg_stream_default(g_gbd);

	char sz_inf[1024];
	if( STX_OK == i_err ) {
		stx_strcpy(sz_inf,sizeof(sz_inf),"unregister success;");
	}
	else {
		stx_strcpy(sz_inf,sizeof(sz_inf),"unregister failed;");
	}

	AfxMessageBox(sz_inf);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void Cstx_gph_editDlg::OnRegisterFilter()
{
	STX_RESULT i_err;

	char* sz_dll = OpenDllFile(m_hWnd,m_szLastPath);
	if( !sz_dll ) {
		return;
	}

	i_err = g_gbd->reg_svr(g_gbd,sz_dll);

	char sz_inf[1024];
	if( STX_OK == i_err ) {
		stx_sprintf(sz_inf,sizeof(sz_inf),"%s register success;",sz_dll);
	}
	else {
		stx_sprintf(sz_inf,sizeof(sz_inf),"%s register failed;",sz_dll);
	}

	if( m_szLastPath ) {
		free(m_szLastPath);
	}
	m_szLastPath = sz_dll;
	GetPath(m_szLastPath);

	AfxMessageBox(sz_inf);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void Cstx_gph_editDlg::OnUnRegisterFilter()
{
	STX_RESULT i_err;

	char* sz_dll = OpenDllFile(m_hWnd,m_szLastPath);
	if( !sz_dll ) {
		return;
	}

	i_err = g_gbd->unreg_svr(g_gbd,sz_dll);

	char sz_inf[1024];
	if( STX_OK == i_err ) {
		stx_sprintf(sz_inf,sizeof(sz_inf),"%s unregister success;",sz_dll);
	}
	else {
		stx_sprintf(sz_inf,sizeof(sz_inf),"%s unregister failed;",sz_dll);
	}

	if( m_szLastPath ) {
		free(m_szLastPath);
	}
	m_szLastPath = sz_dll;
	GetPath(m_szLastPath);

	AfxMessageBox(sz_inf);
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void Cstx_gph_editDlg::OnRegisterProtocolFilter()
{
	STX_RESULT i_err;

	char* sz_dll = OpenDllFile(m_hWnd,m_szLastPath);
	if( !sz_dll ) {
		return;
	}

	i_err = g_gbd->reg_protocol(g_gbd,sz_dll);

	char sz_inf[1024];
	if( STX_OK == i_err ) {
		stx_sprintf(sz_inf,sizeof(sz_inf),"%s register success;",sz_dll);
	}
	else if(STX_EOF == i_err ){
		stx_sprintf(sz_inf,sizeof(sz_inf),"%s no protocol filter found;",sz_dll);
	}
	else{
		stx_sprintf(sz_inf,sizeof(sz_inf),"%s register failed;",sz_dll);
	}

	if( m_szLastPath ) {
		free(m_szLastPath);
	}
	m_szLastPath = sz_dll;
	GetPath(m_szLastPath);

	AfxMessageBox(sz_inf);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void Cstx_gph_editDlg::OnUnRegisterProtocolFilter()
{
	STX_RESULT i_err;

	char* sz_dll = OpenDllFile(m_hWnd,m_szLastPath);
	if( !sz_dll ) {
		return;
	}

	i_err = g_gbd->unreg_protocol(g_gbd,sz_dll);

	char sz_inf[1024];
	if( STX_OK == i_err ) {
		stx_sprintf(sz_inf,sizeof(sz_inf),"%s unregister success;",sz_dll);
	}
	else if(STX_EOF == i_err ){
		stx_sprintf(sz_inf,sizeof(sz_inf),"%s no protocol filter found;",sz_dll);
	}
	else {
		stx_sprintf(sz_inf,sizeof(sz_inf),"%s unregister failed;",sz_dll);
	}

	if( m_szLastPath ) {
		free(m_szLastPath);
	}
	m_szLastPath = sz_dll;
	GetPath(m_szLastPath);

	AfxMessageBox(sz_inf);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void Cstx_gph_editDlg::OnRegisterStartModule()
{
	STX_RESULT i_err;

	char* sz_dll = OpenDllFile(m_hWnd,m_szLastPath);
	if( !sz_dll ) {
		return;
	}

	i_err = g_gbd->reg_dlib(g_gbd,sz_dll);

	char sz_inf[1024];
	if( STX_OK == i_err ) {
		stx_sprintf(sz_inf,sizeof(sz_inf),"%s register success;",sz_dll);
	}
	else{
		stx_sprintf(sz_inf,sizeof(sz_inf),"%s register failed;",sz_dll);
	}

	if( m_szLastPath ) {
		free(m_szLastPath);
	}
	m_szLastPath = sz_dll;
	GetPath(m_szLastPath);

	AfxMessageBox(sz_inf);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void Cstx_gph_editDlg::OnUnRegisterStartModule()
{
	STX_RESULT i_err;

	char* sz_dll = OpenDllFile(m_hWnd,m_szLastPath);
	if( !sz_dll ) {
		return;
	}

	i_err = g_gbd->unreg_dlib(g_gbd,sz_dll);

	char sz_inf[1024];
	if( STX_OK == i_err ) {
		stx_sprintf(sz_inf,sizeof(sz_inf),"%s unregister success;",sz_dll);
	}
	else {
		stx_sprintf(sz_inf,sizeof(sz_inf),"%s unregister failed;",sz_dll);
	}

	if( m_szLastPath ) {
		free(m_szLastPath);
	}
	m_szLastPath = sz_dll;
	GetPath(m_szLastPath);

	AfxMessageBox(sz_inf);
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void Cstx_gph_editDlg::OnRunGraph()
{
	if( !g_h_canvas ) {
		return;
	}

	if( emStxStatusReady != g_h_canvas->get_graph_status() ) {
		return;
	}

	STX_RESULT i_err = g_h_canvas->OnRunGraph();
	if( STX_OK != i_err ) {
		AfxMessageBox("graph starting failed");
	}

	UpdateMenu();
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void Cstx_gph_editDlg::OnStop()
{
	if( !g_h_canvas ) {
		return;
	}

	if( emStxStatusReady == g_h_canvas->get_graph_status() ) {
		return;
	}

	STX_RESULT i_err = g_h_canvas->OnStop();
	if( STX_OK != i_err ) {
		AfxMessageBox("graph stop failed");
	}

	UpdateMenu();
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void Cstx_gph_editDlg::OnPause()
{
	UpdateMenu();
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void Cstx_gph_editDlg::OnResume()
{
	UpdateMenu();
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void Cstx_gph_editDlg::OnRendRender()
{
	UpdateMenu();
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void Cstx_gph_editDlg::OnRendStream()
{
	UpdateMenu();
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void Cstx_gph_editDlg::OnRendPin()
{
	UpdateMenu();
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void Cstx_gph_editDlg::OnMouseMove(UINT nFlags, CPoint point)
{
	STX_RESULT i_err;

	if( !g_h_canvas ) {
		return;
	}

	i_err = g_h_canvas->OnMouseMove(nFlags,point );

	if( i_err < 0 ) {
		// fatal error;

		return;
	}

	if( STX_RET_PAINT == i_err ) {

		PostMessage(WM_PAINT_CANVUS);
	}

}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void Cstx_gph_editDlg::OnLButtonDblClk(UINT nFlags, CPoint point)
{
	if( !g_h_canvas ) {
		return;
	}


	if( g_h_canvas->OnLButtonDblClk(nFlags,point) ) {

	}//if( g_h_canvas->OnRButtonDown(nFlags,point,&i_type,&insid) ) {
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void Cstx_gph_editDlg::OnLButtonDown(UINT nFlags, CPoint point)
{
	if( !g_h_canvas ) {
		return;
	}

	if( STX_RET_PAINT == g_h_canvas->OnLButtonDown(nFlags,point) ) {
		//PostMessage(WM_PAINT);
		Invalidate();
	}

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void Cstx_gph_editDlg::OnRButtonDown(UINT nFlags, CPoint point)
{
	if( !g_h_canvas ) {
		return;
	}


	if( g_h_canvas->OnRButtonDown(nFlags,point) ) {


	}//if( g_h_canvas->OnRButtonDown(nFlags,point,&i_type,&insid) ) {

	//
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void Cstx_gph_editDlg::OnLButtonUp(UINT nFlags, CPoint point)
{
	if( !g_h_canvas ) {
		return;
	}

	if( STX_RET_PAINT == g_h_canvas->OnLButtonUp(nFlags,point) ) {
		//PostMessage(WM_PAINT);
		Invalidate();
	}

}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void Cstx_gph_editDlg::OnSizing(UINT nType, LPRECT prect)
{
	if( g_h_canvas ) {
		return;
	}

	DWORD dwSrcRatio;

	int   nSrcWidth,nSrcHeight;

	if( LX_OK != g_BmpHnd->GetSrcSize(&nSrcWidth,&nSrcHeight) ) {
			return;
	}
	dwSrcRatio = MAKE_LXRATIO(nSrcWidth,nSrcHeight);


	BOOL bWidthPrefer = ( nType == WMSZ_RIGHT || nType == WMSZ_LEFT  ) ? TRUE:FALSE;

	RECT rc = *prect;

	int nWidth = rc.right - rc.left;
	int nHeight = rc.bottom - rc.top;

	RECT rect_scr;
	RECT rect_client;
	::GetClientRect(m_hWnd,&rect_client);
	ClientRectToScreen(m_hWnd, &rect_client);
	::GetWindowRect(m_hWnd,&rect_scr);

	int nx = rect_client.left - rect_scr.left;
	int ny = rect_scr.bottom - rect_client.bottom;
	int nc = rect_client.top - rect_scr.top;

	nWidth -= nx + nx;
	nHeight -= nc + ny;

	if( bWidthPrefer ) {
		nHeight = GetHeightFromRatio(nWidth,dwSrcRatio);
		if( nHeight < WND_MIN_HEIGHT ) {
			nHeight = WND_MIN_HEIGHT;
			nWidth = GetWidthFromRatio(nHeight,dwSrcRatio);
		}
	}
	else {
		nWidth = GetWidthFromRatio(nHeight,dwSrcRatio);
		if( nWidth < WND_MIN_WIDTH ) {
			nWidth = WND_MIN_WIDTH;
			nHeight = GetHeightFromRatio(nWidth,dwSrcRatio);
		}
	}

	nWidth += nx + nx;
	nHeight += nc + ny;

	SIZE size = {0};
	GetFullScreenSize(size,FALSE);

	if( nWidth > size.cx ) {
		nWidth = size.cx - nx - nx;
		nHeight = GetHeightFromRatio(nWidth,dwSrcRatio);
		nWidth += nx + nx;
		nHeight += nc + ny;
	}

	if( nHeight > size.cy ) {
		nHeight = size.cy - nc - ny;
		nWidth = GetWidthFromRatio(nHeight,dwSrcRatio);
		nWidth += nx + nx;
		nHeight += nc + ny;
	}

	rc.right = rc.left + nWidth;
	rc.bottom = rc.top + nHeight;

	*prect = rc;

	return;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void Cstx_gph_editDlg::OnSize(UINT nType, int cx, int cy)
{
	Invalidate();

	if( !g_h_canvas ) {
		return;
	}

}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void Cstx_gph_editDlg::OnDropFiles(HDROP hDropInfo)
{
	if( g_h_canvas ) {
		// close graph;
	}

	//

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

BOOL Cstx_gph_editDlg::OnSetCursor(
					   CWnd* pWnd,
					   UINT nHitTest,
					   UINT message 
					   )
{
	if( CWnd::OnSetCursor(pWnd,nHitTest,message) ) {
		return TRUE;
	}

	return TRUE;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
LRESULT	Cstx_gph_editDlg::OnFltResize(WPARAM wparam,LPARAM lparam)
{
	//g_h_canvas->FltWndResized((base_flt_wnd*)wparam);
	return S_OK;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
LRESULT	Cstx_gph_editDlg::OnAddFlt(WPARAM wparam,LPARAM lparam)
{
	STX_RESULT	i_err;
	char		sz_path[2048];
	stx_gid		clsid;
	char*		sz;

	sz = NULL;
	pAddFltDlg->get_last_clsid(clsid.data);
	if( wparam ) {
		pAddFltDlg->get_path(sz_path,sizeof(sz_path));
		sz = sz_path;
	}

	i_err = g_h_canvas->OnAddFilter(clsid,sz);
	if( STX_OK != i_err ) {
		AfxMessageBox("AddFilter Failed;");
		return S_OK;
	}

	UpdateMenu();

	Invalidate();

	return S_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

LRESULT Cstx_gph_editDlg::OnPaintCanvas(WPARAM wparam,LPARAM lparam)
{
	return SendMessage(WM_PAINT);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void Cstx_gph_editDlg::OnHScroll(UINT nSBCode,UINT nPos,CScrollBar* pScrollBar)
{

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/

void Cstx_gph_editDlg::OnVScroll(UINT nSBCode,UINT nPos,CScrollBar* pScrollBar)
{

}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void  Cstx_gph_editDlg::InitMenu()
{
	HMENU hfile = GetSubMenu(m_menu,0);
	EnableMenuItem(hfile , ID_FILE_NEWGRAPH , MF_ENABLED);
	EnableMenuItem(hfile , ID_FILE_LOADGRAPH , MF_ENABLED);
	EnableMenuItem(hfile , ID_FILE_RENDFILE , MF_ENABLED);
	EnableMenuItem(hfile , ID_FILE_SAVEGRAPH , MF_DISABLED);
	EnableMenuItem(hfile , ID_FILE_SAVEGRAPHAS , MF_DISABLED);
	EnableMenuItem(hfile , ID_FILE_CLOSEGRAPH , MF_DISABLED);
	EnableMenuItem(hfile , ID_FILE_EXIT , MF_ENABLED);

	HMENU hgraph = GetSubMenu(m_menu,1);
	EnableMenuItem(hgraph , ID_GRAPH_OPENFILE , MF_DISABLED);
	EnableMenuItem(hgraph , ID_GRAPH_LOADSTREAM , MF_DISABLED);
	EnableMenuItem(hgraph , ID_GRAPH_RENDPIN , MF_DISABLED);
	EnableMenuItem(hgraph , ID_GRAPH_RENDRENDER , MF_DISABLED);
	EnableMenuItem(hgraph , ID_GRAPH_RUNGRAPH , MF_DISABLED);
	EnableMenuItem(hgraph , ID_GRAPH_PAUSE , MF_DISABLED);
	EnableMenuItem(hgraph , ID_GRAPH_RESUME , MF_DISABLED);
	EnableMenuItem(hgraph , ID_GRAPH_STOP , MF_DISABLED);
	EnableMenuItem(hgraph , ID_GRAPH_CLOSESTREAM , MF_DISABLED);

	HMENU hfilter = GetSubMenu(m_menu,2);
	EnableMenuItem(hfilter , ID_FILTER_ADDFILTER , MF_DISABLED);
	EnableMenuItem(hfilter , ID_FILTER_ADDFILTERFROMDLL , MF_DISABLED);
	EnableMenuItem(hfilter , ID_FILTER_REGISTERFILTER , MF_ENABLED);
	EnableMenuItem(hfilter , ID_FILTER_UNREGISTERFILTER , MF_ENABLED);
	EnableMenuItem(hfilter , ID_FILTER_REGISTERSTREAM , MF_ENABLED);
	EnableMenuItem(hfilter , ID_FILTER_UNREGISTERSTREAM , MF_ENABLED);

	HMENU htools = GetSubMenu(m_menu,2);
	EnableMenuItem(htools , ID_TOOLS_SETUP , MF_ENABLED);

	HMENU hhelp = GetSubMenu(m_menu,2);
	EnableMenuItem(hhelp , ID_HELP_ABOUT , MF_ENABLED);

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void  Cstx_gph_editDlg::UpdateMenu()
{
	u32 flag;

	HMENU hfile = GetSubMenu(m_menu,0);
	EnableMenuItem(hfile , ID_FILE_NEWGRAPH , MF_ENABLED);
	EnableMenuItem(hfile , ID_FILE_LOADGRAPH , MF_ENABLED);
	EnableMenuItem(hfile , ID_FILE_RENDFILE , MF_ENABLED);

	flag = g_h_canvas ? MF_ENABLED : MF_DISABLED;
	EnableMenuItem(hfile , ID_FILE_SAVEGRAPH , flag);
	EnableMenuItem(hfile , ID_FILE_SAVEGRAPHAS , flag);
	EnableMenuItem(hfile , ID_FILE_CLOSEGRAPH , flag);

	EnableMenuItem(hfile , ID_FILE_EXIT , MF_ENABLED);


	if( g_h_canvas ) {

		s32 i_status = g_h_canvas->get_graph_status();

		HMENU hgraph = GetSubMenu(m_menu,1);

		if( emStxStatusInit == i_status ){
			flag = MF_ENABLED;
			EnableMenuItem(hgraph , ID_GRAPH_OPENFILE , flag);
			EnableMenuItem(hgraph , ID_GRAPH_LOADSTREAM , flag);
			EnableMenuItem(hgraph , ID_GRAPH_RENDPIN , flag);
			EnableMenuItem(hgraph , ID_GRAPH_RENDRENDER , flag);
			flag = MF_DISABLED;
			EnableMenuItem(hgraph , ID_GRAPH_RUNGRAPH , flag);
			EnableMenuItem(hgraph , ID_GRAPH_PAUSE , flag);
			EnableMenuItem(hgraph , ID_GRAPH_RESUME , flag);
			EnableMenuItem(hgraph , ID_GRAPH_STOP , flag);
			EnableMenuItem(hgraph , ID_GRAPH_CLOSESTREAM , flag);
		}
		else if( emStxStatusReady == i_status ) {
			flag = MF_DISABLED;
			EnableMenuItem(hgraph , ID_GRAPH_OPENFILE , flag);
			EnableMenuItem(hgraph , ID_GRAPH_LOADSTREAM , flag);
			EnableMenuItem(hgraph , ID_GRAPH_RENDPIN , flag);
			EnableMenuItem(hgraph , ID_GRAPH_RENDRENDER , flag);
			EnableMenuItem(hgraph , ID_GRAPH_PAUSE , flag);
			EnableMenuItem(hgraph , ID_GRAPH_RESUME , flag);
			EnableMenuItem(hgraph , ID_GRAPH_STOP , flag);
			flag = MF_ENABLED;
			EnableMenuItem(hgraph , ID_GRAPH_RUNGRAPH , flag);
			EnableMenuItem(hgraph , ID_GRAPH_CLOSESTREAM , flag);
		}
		else if( emStxStatusPlay == i_status ) {
			flag = MF_DISABLED;
			EnableMenuItem(hgraph , ID_GRAPH_OPENFILE , flag);
			EnableMenuItem(hgraph , ID_GRAPH_LOADSTREAM , flag);
			EnableMenuItem(hgraph , ID_GRAPH_RENDPIN , flag);
			EnableMenuItem(hgraph , ID_GRAPH_RENDRENDER , flag);
			EnableMenuItem(hgraph , ID_GRAPH_RUNGRAPH , flag);
			EnableMenuItem(hgraph , ID_GRAPH_RESUME , flag);
			flag = MF_ENABLED;
			EnableMenuItem(hgraph , ID_GRAPH_PAUSE , flag);
			EnableMenuItem(hgraph , ID_GRAPH_STOP , flag);
			EnableMenuItem(hgraph , ID_GRAPH_CLOSESTREAM , flag);
		}
		else if (emStxStatusStop == i_status ) {
			flag = MF_DISABLED;
			EnableMenuItem(hgraph , ID_GRAPH_LOADSTREAM , flag);
			EnableMenuItem(hgraph , ID_GRAPH_RENDPIN , flag);
			EnableMenuItem(hgraph , ID_GRAPH_RENDRENDER , flag);
			EnableMenuItem(hgraph , ID_GRAPH_PAUSE , flag);
			EnableMenuItem(hgraph , ID_GRAPH_STOP , flag);
			flag = MF_ENABLED;
			EnableMenuItem(hgraph , ID_GRAPH_RUNGRAPH , flag);
			EnableMenuItem(hgraph , ID_GRAPH_RESUME , flag);
			EnableMenuItem(hgraph , ID_GRAPH_CLOSESTREAM , flag);
		}

		HMENU hfilter = GetSubMenu(m_menu,2);
		flag = emStxStatusInit == i_status ? MF_ENABLED : flag;
		EnableMenuItem(hfilter , ID_FILTER_ADDFILTER , flag);
		EnableMenuItem(hfilter , ID_FILTER_ADDFILTERFROMDLL , flag);
		EnableMenuItem(hfilter , ID_FILTER_REGISTERFILTER , flag);
		EnableMenuItem(hfilter , ID_FILTER_UNREGISTERFILTER , flag);
		EnableMenuItem(hfilter , ID_FILTER_REGISTERSTREAM , flag);
		EnableMenuItem(hfilter , ID_FILTER_UNREGISTERSTREAM , flag);
	}
	else {
		HMENU hgraph = GetSubMenu(m_menu,1);
		flag = MF_DISABLED;
		EnableMenuItem(hgraph , ID_GRAPH_LOADSTREAM , flag);
		EnableMenuItem(hgraph , ID_GRAPH_RENDPIN , flag);
		EnableMenuItem(hgraph , ID_GRAPH_RENDRENDER , flag);
		EnableMenuItem(hgraph , ID_GRAPH_RUNGRAPH , flag);
		EnableMenuItem(hgraph , ID_GRAPH_PAUSE , flag);
		EnableMenuItem(hgraph , ID_GRAPH_RESUME , flag);
		EnableMenuItem(hgraph , ID_GRAPH_STOP , flag);
		EnableMenuItem(hgraph , ID_GRAPH_CLOSESTREAM , flag);

		HMENU hfilter = GetSubMenu(m_menu,2);
		EnableMenuItem(hfilter , ID_FILTER_ADDFILTER , flag);
		EnableMenuItem(hfilter , ID_FILTER_ADDFILTERFROMDLL , flag);

		EnableMenuItem(hfilter , ID_FILTER_REGISTERFILTER , MF_ENABLED);
		EnableMenuItem(hfilter , ID_FILTER_UNREGISTERFILTER , MF_ENABLED);
		EnableMenuItem(hfilter , ID_FILTER_REGISTERSTREAM , MF_ENABLED);
		EnableMenuItem(hfilter , ID_FILTER_UNREGISTERSTREAM , MF_ENABLED);
	}

	HMENU htools = GetSubMenu(m_menu,2);
	EnableMenuItem(htools , ID_TOOLS_SETUP , MF_ENABLED);

	HMENU hhelp = GetSubMenu(m_menu,2);
	EnableMenuItem(hhelp , ID_HELP_ABOUT , MF_ENABLED);

}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
int  Cstx_gph_editDlg::get_graph_caps()
{
	if( !g_h_canvas ) {
		return emStxStatusInit;
	}

	return g_h_canvas->get_graph_caps();

}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
int Cstx_gph_editDlg::get_graph_status()
{
	if( !g_h_canvas ) {
		return emStxStatusInit;
	}

	return g_h_canvas->get_graph_status();
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void Cstx_gph_editDlg::set_dst_rect(RECT dst_rect)
{
	if( get_graph_status() == emStxStatusInit )  {
		return ;
	}

	g_h_canvas->set_dst_rect(dst_rect);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void Cstx_gph_editDlg::show_render(BOOL bShow)
{
	if( get_graph_status() == emStxStatusInit )  {
		return ;
	}

	g_h_canvas->show_render(bShow);
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void Cstx_gph_editDlg::graph_cmd(int i_cmd)
{
	
	if( get_graph_status() == emStxStatusInit )  {
		return ;
	}

	g_h_canvas->graph_cmd(i_cmd);

}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
int Cstx_gph_editDlg::attach_active_movie_wnd(void* p_msg)
{
	STX_RESULT				i_err;
	stx_base_message*		h_msg;
	stx_msg_cnt*			cnt;
	stx_active_movie_wnd*	h_active_wnd;
	stx_base_plugin*		h_PlayWnd = NULL;


	do{

		i_err = STX_FAIL;
		h_active_wnd = NULL;

		h_PlayWnd = XCREATE(play_window,NULL);
		if( !h_PlayWnd ) {
			break;
		}

		i_err = h_PlayWnd->query_interf(h_PlayWnd,STX_IID_ActiveMovieWindow,(void**)&h_active_wnd);
		if( STX_OK != i_err ) {
			break;
		}

		// set property;

		//

		i_err = h_active_wnd->create(h_active_wnd,NULL);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = STX_OK;

	}while(FALSE);

	SAFE_XDELETE(h_active_wnd);

	if( STX_OK != i_err ) {
		return (int)i_err;
	}

	h_msg = (stx_base_message*)p_msg;

	cnt = h_msg->get_msg_cnt(h_msg);
	
	cnt->param.i_param[0] = (size_t)h_PlayWnd;

	h_msg->set_msg_close(h_msg);

	return STX_OK;

}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
void  Cstx_gph_editDlg::on_close_play_window(void* plugin)
{
	if( g_h_canvas ) {

		s32 i_status = g_h_canvas->get_graph_status();

		if( i_status != emStxStatusInit && i_status != emStxStatusReady) {
			g_h_canvas->OnStop();
		}
	} // if( g_h_canvas ) {

	UpdateMenu();

}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_MSG STX_RESULT on_query_obj(STX_HANDLE h,stx_base_message* p_msg)
{
	Cstx_gph_editDlg* the = (Cstx_gph_editDlg*)h;

	stx_gid			buf_iid;
	s32				i_len;

	buf_iid = *(stx_gid*)p_msg->get_msg_buf(p_msg,&i_len);

	if( IS_EQUAL_GID(STX_IID_ActiveMovieWindow,buf_iid) ) {
		return the->attach_active_movie_wnd( (void*)p_msg );
	}

	if( IS_EQUAL_GID(STX_IID_GraphBuilder,buf_iid) ) {
		g_gbd->add_ref(g_gbd);
		p_msg->get_msg_cnt(p_msg)->param.i_param[0] = (size_t)g_gbd;
		p_msg->set_msg_close(p_msg);
		return STX_OK;
	}

	return STX_ERR_NOT_SUPPORT;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_RESULT on_auto_stop(STX_HANDLE h,stx_base_message* p_msg)
{
	Cstx_gph_editDlg* the = (Cstx_gph_editDlg*)h;

	the->PostMessage(WM_AUTO_SOTP);

	p_msg->set_msg_close(p_msg);

	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
LRESULT	Cstx_gph_editDlg::OnAutoStop(WPARAM wparam,LPARAM lparam)
{
	STX_RESULT i_err = g_h_canvas->OnStop();
	if( STX_OK != i_err ) {
		AfxMessageBox("graph auto stop failed");
	}

	UpdateMenu();

	return 0L;
}