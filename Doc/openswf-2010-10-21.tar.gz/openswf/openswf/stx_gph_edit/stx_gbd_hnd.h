/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-10
***********************************************************************************/
#pragma once

#include "stx_all.h"


STX_COM(gbd_hnd);

CREATE_STX_COM_DECL(stx_base_plugin,gbd_hnd);