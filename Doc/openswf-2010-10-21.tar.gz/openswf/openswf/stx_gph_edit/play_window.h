/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2009-10
***********************************************************************************/
#pragma once

#include "stx_all.h"


BOOL init_play_window_env();
void close_play_window_env();


STX_API	STX_COM(play_window);

STX_API CREATE_STX_COM_DECL(stx_base_plugin,play_window);
