#pragma once


// PrsDlg dialog

class PrsDlg : public CDialog
{
	DECLARE_DYNAMIC(PrsDlg)

public:
	PrsDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~PrsDlg();

// Dialog Data
	enum { IDD = IDD_PRS_DLG };

	CString m_csIp;
	CString m_csPort;
	CString m_csGraph;
	CString m_csUrl;
	CString m_csConnum;


protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedBtnGph();
	afx_msg void OnBnClickedBtnAdd();
	afx_msg void OnBnClickedBtnRem();
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedCancel();
	afx_msg void OnBnClickedBtnLoad();
};
