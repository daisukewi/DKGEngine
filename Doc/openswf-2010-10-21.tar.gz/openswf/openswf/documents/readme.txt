
Hello,all friends!
The openswf is a opensource project use GPL licensees.
The purpose of the project, is to implement a third party library to support
swf file playing, video file downloading, etc.
It is based on streamx frameworks library: <stx_plat>, <xbase>.
All the public header file could be located at folter <include>.
streamx framework is a pure c style coded system, 
It is original designed for some embedded os/dsp develop board that without c++ compiler supporting.
It is a fully com structured and object oriented system.
To complete the project openswf, It seemed need much more time, 
because I have some heavy develop works to do everyday, and could only update the svn file at week ends.

Any questions, please send mail to dactyle@yahoo.cn.

^@^
