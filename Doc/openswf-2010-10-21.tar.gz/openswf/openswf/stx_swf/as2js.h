/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2010-08
***********************************************************************************/
#ifndef __AS2JS_H__
#define __AS2JS_H__

#include "stx_base_type.h"


#if defined( __cplusplus )
extern "C" {
#endif



STX_RESULT as2js(u8* ascode, s32 i_len, u8** jscode);



#if defined( __cplusplus )
}
#endif


#endif // __AS2JS_H__