/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06

application/x-shockwave-flash

***********************************************************************************/
#include "stx_all.h"
#include "stx_swf.h"
#include "swf_all.h"
#include "zlib.h"
#include "as2js.h"


/********************************************/
#include "get_bits.c"
/********************************************/



#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif

#ifdef _MAP_THE	
#	undef _MAP_THE	
#endif	
#define _MAP_THE STX_MAP_THE(stx_swf)



#define lock_()		stx_waitfor_mutex(the->h_lock,INFINITE)
#define unlock_()	stx_release_mutex(the->h_lock)

#define get_bits_(n)	stx_get_bits(&the->gb,n)
#define get_sbits16_(n)	(((s16)get_bits_(n)<<(16-n))>>(16-n))
#define get_sbits32_(n)	(((s32)get_bits_(n)<<(32-n))>>(32-n))
#define get_word_		bswap_16(stx_get_bits(&the->gb,16))
#define get_dword_		bswap_32(stx_get_bits(&the->gb,32))
#define align_byte_     \
{\
	const u32 n = the->gb.nCurrentBit & 7;\
	if( n ) {\
		stx_get_bits(&the->gb,n);\
	}\
}



// {188FC3DA-A215-4217-B944-2152889E613D}
DEFINE_XGUID( STX_IID_SwfCanvas,
0x188fc3da, 0xa215, 0x4217, 0xb9, 0x44, 0x21, 0x52, 0x88, 0x9e, 0x61, 0x3d);


// {20DD317A-0000-4f3c-980F-386D499AF5D5}
DEFINE_XGUID( STX_CLSID_SwfCanvas,
0x20dd317a, 0x0, 0x4f3c, 0x98, 0xf, 0x38, 0x6d, 0x49, 0x9a, 0xf5, 0xd5);


char* g_sz_SwfCanvas = STX_PLUGIN_STRING(stx_swf);


typedef THEE (*swf_tag_create)( THEE hcan, THEE hins, u32 tag, u32 len);
STX_PRIVATE swf_tag_create create_tag[128];
STX_PRIVATE swf_tag_create create_action[256];
#define init_tag_table(tag,id) create_tag[id] = tag ## _xxx_create
#define init_action_table(action,id) create_action[id] = action ## _xxx_create

void swf_initialize()
{
	init_tag_table(End,0);
	init_tag_table(ShowFrame,1);
	init_tag_table(DefineShape,2);

	init_tag_table(PlaceObject,4);

	init_tag_table(RemoveObject,5);
	init_tag_table(DefineBits,6);
	init_tag_table(DefineButton,7);
	init_tag_table(JPEGTables,8);
	init_tag_table(SetBackgroundColor,9);
	init_tag_table(DefineFont,10);
	init_tag_table(DefineText,11);

	init_tag_table(DefineFontInfo,13);
	init_tag_table(DefineSound,14);
	init_tag_table(StartSound,15);

	init_tag_table(DefineButtonSound,17);
	init_tag_table(SoundStreamHead,18);
	init_tag_table(SoundStreamBlock,19);
	init_tag_table(DefineBitsLossless,20);
	init_tag_table(DefineBitsJPEG2,21);
	init_tag_table(DefineShape2,22);
	init_tag_table(DefineButtonCxform,23);
	init_tag_table(Protect,24);

	init_tag_table(PlaceObject2,26);
	init_tag_table(RemoveObject2,28);

	init_tag_table(DefineShape3,32);
	init_tag_table(DefineText2,33);
	init_tag_table(DefineButton2,34);
	init_tag_table(DefineBitsJPEG3,35);
	init_tag_table(DefineBitsLossless2,36);
	init_tag_table(DefineEditText,37);

	init_tag_table(DefineSprite,39);

	//init_tag_table(FrameLabel,43);
	init_tag_table(NamedAnchor,43); // swf6 or later;

	init_tag_table(SoundStreamHead2,45);
	init_tag_table(DefineMorphShape,46);
	init_tag_table(DefineFont2,48);

	init_tag_table(ExportAssets,56);
	init_tag_table(ImportAssets,57);
	init_tag_table(EnableDebugger,58);

	init_tag_table(DefineVideoStream,60);

	init_tag_table(DefineFontInfo2,62);

	init_tag_table(EnableDebugger2,64);
	init_tag_table(ScriptLimits,65);
	init_tag_table(SetTabIndex,66);

	init_tag_table(PlaceObject3,70);
	init_tag_table(ImportAssets2,71);

	init_tag_table(DefineFontAlignZones,73);
	init_tag_table(CSMTextSettings,74);
	init_tag_table(DefineFont3,75);
	init_tag_table(SymbolClass,76);
	init_tag_table(Metadata,77);
	init_tag_table(DefineScalingGrid,78);

	init_tag_table(DoABC,82);
	init_tag_table(DefineShape4,83);
	init_tag_table(DefineMorphShape2,84);

	init_tag_table(DefineSceneAndFrameLabelData,86);
	init_tag_table(DefineBinaryData,87);
	init_tag_table(DefineFontName,88);
	init_tag_table(StartSound2,89);
	init_tag_table(DefineBitsJPEG4,90);
	init_tag_table(DefineFont4,91);

	init_action_table(ActionNextFrame,0x04);
	init_action_table(ActionPreviousFrame,0x05);
	init_action_table(ActionPlay,0x06);
	init_action_table(ActionStop,0x07);
	init_action_table(ActionToggleQuality,0x08);
	init_action_table(ActionStopSounds,0x09);
	init_action_table(ActionAdd,0x0a);
	init_action_table(ActionSubtract,0x0b);
	init_action_table(ActionMultiply,0x0c);
	init_action_table(ActionDivide,0x0d);
	init_action_table(ActionEquals,0x0e);
	init_action_table(ActionLess,0x0f);
	init_action_table(ActionAnd,0x10);
	init_action_table(ActionOr,0x11);
	init_action_table(ActionNot,0x12);
	init_action_table(ActionStringEquals,0x13);
	init_action_table(ActionStringLength,0x14);
	init_action_table(ActionStringExtract,0x15);

	init_action_table(ActionPop,0x17);
	init_action_table(ActionToInteger,0x18);

	init_action_table(ActionGetVariable,0x1c);
	init_action_table(ActionSetVariable,0x1d);

	init_action_table(ActionSetTarget2,0x20);
	init_action_table(ActionStringAdd,0x21);
	init_action_table(ActionGetProperty,0x22);
	init_action_table(ActionSetProperty,0x23);
	init_action_table(ActionCloneSprite,0x24);
	init_action_table(ActionRemoveSprite,0x25);
	init_action_table(ActionTrace,0x26);
	init_action_table(ActionStartDrag,0x27);
	init_action_table(ActionEndDrag,0x28);
	init_action_table(ActionStringLess,0x29);
	init_action_table(ActionThrow,0x2a);
	init_action_table(ActionCastOp,0x2b);
	init_action_table(ActionImplementsOp,0x2c);

	init_action_table(ActionRandomNumber,0x30);
	init_action_table(ActionMBStringLength,0x31);
	init_action_table(ActionCharToAscii,0x32);
	init_action_table(ActionAsciiToChar,0x33);
	init_action_table(ActionGetTime,0x34);
	init_action_table(ActionMBStringExtract,0x35);
	init_action_table(ActionMBCharToAscii,0x36);

	init_action_table(ActionDelete,0x3a);
	init_action_table(ActionDelete2,0x3b);
	init_action_table(ActionDefineLocal,0x3c);
	init_action_table(ActionCallFunction,0x3d);
	init_action_table(ActionReturn,0x3e);
	init_action_table(ActionModulo,0x3f);
	init_action_table(ActionNewObject,0x40);
	init_action_table(ActionDefineLocal2,0x41);
	init_action_table(ActionInitArray,0x42);
	init_action_table(ActionInitObject,0x43);
	init_action_table(ActionTypeOf,0x44);
	init_action_table(ActionTargetPath,0x45);
	init_action_table(ActionEnumerate,0x46);
	init_action_table(ActionAdd2,0x47);
	init_action_table(ActionLess2,0x48);
	init_action_table(ActionEquals2,0x49);
	init_action_table(ActionToNumber,0x4a);
	init_action_table(ActionToString,0x4b);
	init_action_table(ActionPushDuplicate,0x4c);

	init_action_table(ActionGetMember,0x4e);
	init_action_table(ActionStackSwap,0x4d);
	init_action_table(ActionSetMember,0x4f);
	init_action_table(ActionIncrement,0x50);
	init_action_table(ActionDecrement,0x51);
	init_action_table(ActionCallMethod,0x52);
	init_action_table(ActionNewMethod,0x53);
	init_action_table(ActionInstanceOf,0x54);
	init_action_table(ActionEnumerate2,0x55);

	init_action_table(ActionBitAnd,0x60);
	init_action_table(ActionBitOr,0x61);
	init_action_table(ActionBitXor,0x62);
	init_action_table(ActionBitLShift,0x63);
	init_action_table(ActionBitRShift,0x64);
	init_action_table(ActionBitURShift,0x65);
	init_action_table(ActionStrictEquals,0x66);
	init_action_table(ActionGreater,0x67);
	init_action_table(ActionStringGreater,0x68);
	init_action_table(ActionExtends,0x69);

	init_action_table(ActionGotoFrame,0x81);
	init_action_table(ActionGetURL,0x83);

	init_action_table(ActionStoreRegister,0x87);
	init_action_table(ActionConstantPool,0x88);

	init_action_table(ActionWaitForFrame,0x8a);
	init_action_table(ActionSetTarget,0x8b);
	init_action_table(ActionGoToLabel,0x8c);
	init_action_table(ActionWaitForFrame2,0x8d);
	init_action_table(ActionDefineFunction2,0x8e);
	init_action_table(ActionTry,0x8f);

	init_action_table(ActionWith,0x94);
	init_action_table(ActionPush,0x96);

	init_action_table(ActionJump,0x99);

	init_action_table(ActionGetURL2,0x9a);
	init_action_table(ActionDefineFunction,0x9b);

	init_action_table(ActionIf,0x9d);	
	init_action_table(ActionCall,0x9e);
	init_action_table(ActionGotoFrame2,0x9f);
}





STX_COM_FUNC_DECL_DEFAULT(stx_swf_canvas,stx_swf_canvas_vt);

STX_COM_FUNCIMP_DEFAULT(stx_swf,stx_swf_canvas,stx_swf_canvas_vt);


/*{{{STX_MSG_ENTRY_DECLARE**************************************************/
/* to do : add msg proc entry  declaration here; */
/*STX_MSG_ENTRY_DECLARE(on_play)*/
/*}}}***********************************************************************/

/*{{{STX_BEGIN_MSG_MAP******************************************************/
STX_BEGIN_MSG_MAP(the_msg_data)
/* to do : add msg proc entry name here; */
/*ON_STX_MSG(STX_MSG_Play,on_play)*/
STX_END_MSG_MAP
/*}}}***********************************************************************/


/*{{{STX_BEGIN_MSG_RESPONSE_MAP*********************************************/
STX_BEGIN_MSG_RESPONSE_MAP(the_msg_response)
/* to do : add msg process entry name here; */
STX_END_MSG_RESPONSE_MAP
/*}}}***********************************************************************/


/*{{{STX_DISPATHCH_MSG_PROC*************************************************/
STX_DISPATCH_MSG_PROC( dispatch_msg,the_msg_data )
/*}}}***********************************************************************/


/*{{{STX_RESPONSE_MSG_PROC**************************************************/
STX_RESPONSE_MSG_PROC( response_msg,the_msg_response )
/*}}}***********************************************************************/


s32 get_encoded_u32(stx_swf* the);

STX_PRIVATE STX_RESULT	parse(stx_swf* the);
STX_PRIVATE STX_RESULT	decode_header(stx_swf* the);
STX_PRIVATE STX_RESULT	decode_tag(stx_swf* the);
STX_PRIVATE STX_RESULT	decode_attr(stx_swf* the);



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_COM_MAP_BEGIN(stx_swf)
/**/STX_COM_MAP_ITEM(STX_IID_SwfCanvas)
STX_COM_MAP_END()

STX_API_IMP	
STX_NEW_BEGIN(stx_swf)
{
	STX_SET_THE(stx_swf_canvas);
	STX_COM_NEW_DEFAULT(stx_swf_canvas,the->stx_swf_canvas_vt,stx_swf_canvas_vt,
		STX_CLSID_SwfCanvas,STX_CATEGORY_Canvas,g_sz_SwfCanvas);

	the->h_stack = stx_stack_create();
	if( !the->h_stack ) {
		break;
	}

	the->h_dec_stack = stx_stack_create();
	if( !the->h_dec_stack ) {
		break;
	}

	the->h_act_stack = stx_stack_create();
	if( !the->h_act_stack ) {
		break;
	}

	the->h_dict = stx_hash_create(2048);
	if( !the->h_dict ) {
		break;
	}

}
STX_NEW_END()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE 
STX_QUERY_BEGIN(stx_swf)
{
	STX_COM_QUERY_DEFAULT(stx_swf_canvas,the->stx_swf_canvas_vt);
}
STX_QUERY_END()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE 
STX_DELETE_BEGIN(stx_swf)
{
	/* todo : release object; */

	if( the->h_dict ) {
		swf_tag* h;
		h = (swf_tag*)stx_hash_find_first(the->h_dict);
		while( h ) {
			XDELETE(h);
			h = (swf_tag*)stx_hash_find_next(the->h_dict);
		} // while( h ) {
		stx_hash_close(the->h_dict);
	}

	SAFE_CLOSE(stx_stack_close,the->h_stack);
	SAFE_CLOSE(stx_stack_close,the->h_dec_stack);
	SAFE_CLOSE(stx_stack_close,the->h_act_stack);
	SAFE_CLOSEXIO(the->h_file);
	SAFE_XFREE(the->buffer);
	SAFE_XFREE(the->p_stream);

	stx_free_get_bits(&the->gb);

	STX_COM_DELETE_DEFAULT(stx_base_plugin);
}
STX_DELETE_END
(
STX_COM_DELETE_BEGIN(stx_base_plugin)
,
STX_COM_DELETE_END(stx_base_plugin)
)



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
s32 get_encoded_u32(stx_swf* the)
{
	s32 result = get_bits_(8);
	if (!(result & 0x00000080)){
		return result;
	}
	result = (result & 0x0000007f) | get_bits_(8)<<7;
	if (!(result & 0x00004000)){
		return result;
	}
	result = (result & 0x00003fff) | get_bits_(8)<<14;
	if (!(result & 0x00200000)){
		return result;
	}
	result = (result & 0x001fffff) | get_bits_(8)<<21;
	if (!(result & 0x10000000)){
		return result;
	}
	result = (result & 0x0fffffff) | get_bits_(8)<<28;
	return result;
}


 /***************************************************************************
 RETURN VALUE:
 INPUT:
 OUTPUT:
 NOTE:
 ***************************************************************************/
 STX_PURE STX_RESULT stx_swf_canvas_vt_plug_xxx_send_msg
 (STX_HANDLE h,stx_base_message *p_msg)
{
	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT 
stx_swf_canvas_vt_plug_xxx_run(STX_HANDLE h,stx_sync_inf* h_sync)
{
	_MAP_THE;
	return STX_OK;
}




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_swf_canvas_vt_plug_xxx_get_property
(STX_HANDLE h,stx_xio* h_xini)
{
	_MAP_THE;

	return STX_ERR_NOT_SUPPORT;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_swf_canvas_vt_plug_xxx_set_property
(STX_HANDLE h,stx_xio *h_xini)
{
	return STX_ERR_NOT_SUPPORT;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_swf_canvas_vt_plug_xxx_flush
(STX_HANDLE h,u32 i_flag,stx_sync_inf *h_sync)
{

	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_swf_canvas_vt_plug_xxx_start
(STX_HANDLE h,u32 i_flag,stx_sync_inf *h_sync)
{

	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_swf_canvas_vt_plug_xxx_stop
(STX_HANDLE h,u32 i_flag,stx_sync_inf *h_sync)
{
	return STX_OK;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_swf_canvas_vt_xxx_open
(THEE h, const char* sz_file, s32 oflag )
{
	STX_RESULT	i_err;
	_MAP_THE;

	do{
		i_err = STX_FAIL;

		the->h_file = stx_create_io_file();
		if( !the->h_file){
			break;
		}

		i_err = XCALL(open,the->h_file,sz_file,O_RDONLY);
		if( STX_OK != i_err ) {
			break;
		}

		i_err = parse(the);

	}while(FALSE);

	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_swf_canvas_vt_xxx_get_rect(THEE h, RECT* rec )
{
	_MAP_THE;
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_swf_canvas_vt_xxx_enum_button(THEE h, s32* idx, RECT* rec )
{
	_MAP_THE;
	return STX_OK;
}
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_swf_canvas_vt_xxx_get_button(THEE h, s32 idx, stx_xio* hio )
{
	_MAP_THE;
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_swf_canvas_vt_xxx_push_button(THEE h, s32 idx )
{
	_MAP_THE;
	return STX_OK;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PURE STX_RESULT stx_swf_canvas_vt_xxx_get_action
(THEE h, s32 idx, s32* i_size, char* url )
{
	_MAP_THE;
	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT parse(stx_swf* the)
{
	STX_RESULT i_err;

	i_err = decode_header(the);
	if( STX_OK != i_err ) {
		return i_err;
	}

	i_err = decode_tag(the);

	// 

	return i_err;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT decode_header(stx_swf* the)
{
	size_t		i_read;
	STX_RESULT	i_err = STX_OK;
	size_t		i_size = (size_t)XCALL(size,the->h_file);

	the->buffer = (u8*)xmallocz(i_size);
	if( !the->buffer ) {
		return STX_FAIL;
	}
	
	XCALL(seek,the->h_file,0,SEEK_SET);
	XCALL(read,the->h_file,the->buffer,i_size,&i_read);
	stx_init_get_bits(&the->gb,the->buffer,i_size);

	// compressed ?
	the->swfhdr.Signature = get_bits_(24);

	// Version detect;
	the->swfhdr.Version = get_bits_(8);

	the->swfhdr.FileLength = get_dword_;

	screate(swf_rect,the,&the->swfhdr.FrameSize);

	{
		swf_fixed8 fix;
		screate(swf_fixed8,the,&fix);
		the->swfhdr.FrameRate = fixed8_to_f32(fix);
	}

	the->swfhdr.FrameCount = get_word_;

	if( SWF_COMPRESSED_MAGIC == the->swfhdr.Signature ) {

		u8*	buf	= NULL;

		i_err = STX_FAIL;

		do{
			// use zlib to do decompress, save result at h_stream;
			size_t	i_size	= (size_t)XCALL(size,the->h_file) - 8;
			size_t	i_read	= 0;

			the->p_stream = (u8*)xmallocz(the->swfhdr.FileLength);
			if( !the->p_stream ) {
				break;
			}

			buf	= (u8*)xmallocz(i_size);
			if( !buf ) {
				break;
			}

			XCALL(seek,the->h_file,8,SEEK_SET);
			i_err = XCALL(read,the->h_file,buf,i_size,&i_read);
			if( STX_OK != i_err ) {
				break;
			}

			i_err = uncompress(the->p_stream,&the->swfhdr.FileLength,buf,i_size);
			if( i_err != Z_OK ) {
				i_err = STX_FAIL;
				break;
			}

			stx_init_get_bits(&the->gb,the->p_stream,the->swfhdr.FileLength);

		}while(FALSE);

		SAFE_XFREE(buf);

		if( STX_OK != i_err ) {
			return i_err;
		}

	} // if( SWF_COMPRESSED_MAGIC == the->swfhdr.Signature ) {


	if( the->swfhdr.Version >= 8 ) {
		// attributes
		i_err = decode_attr(the);
		if( STX_OK != i_err ) {
			return i_err;
		}
	}// if( the->swfhdr.Version >= 8 ) {


	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
stx_inline void decode_record_hdr(stx_swf* the,u32* t,s32* l)
{
	u32 tag;
	s32 len;

	tag = get_word_;
	len = tag & 0x3f;
	tag >>= 6;

	if( len == 0x3f ) {
		len = get_dword_;
	}

	*t = tag;
	*l = len;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
stx_inline void decode_action_hdr(stx_swf* the,u32* t,s32* l)
{
	u32 tag;
	s32 len = 0;

	tag = get_bits_(8);
	if( tag >= 0x80 ){
		len = get_dword_;
	}
	*t = tag;
	*l = len;
}


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT	decode_attr(stx_swf* the)
{
	u32 tag,len;

	decode_record_hdr(the,&tag,&len);

	if( TAG_FILE_ATTRIBUTES != tag ) {
		return STX_FAIL;
	}

	get_bits_(1); // reserved;
	the->attr.useDirectBlit = get_bits_(1);
	the->attr.useGPU = get_bits_(1);
	the->attr.hasMetaData = get_bits_(1);
	the->attr.hasMetaData = get_bits_(1);
	the->attr.useActionScript3 = get_bits_(1);
	get_bits_(2); // reserved;
	the->attr.useNetwork = get_bits_(1);
	get_bits_(24); // reserved;
	return STX_OK;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
STX_PRIVATE STX_RESULT	decode_tag(stx_swf* the)
{
	STX_RESULT	i_err;
	u32			tag,len;
	swf_tag*	h_tag;

	i_err = STX_OK;

	while( the->gb.nCurrentBit > 0) {

		decode_record_hdr(the,&tag,&len);

		if( tag < FF_ARRAY_ELEMS(create_tag) && create_tag[tag] ) {
			
			// create and initialize the tag;
			h_tag = (swf_tag*)create_tag[tag](the,NULL,tag,len);
			if( !h_tag ) {
				i_err = STX_FAIL;
				break;
			}

			i_err = stx_hash_add(the->h_dict,h_tag,(size_t)h_tag->ichid);
			if( STX_OK != i_err ) {
				XDELETE(h_tag);
				break;
			}
			continue;
		}

		// skip unknown tag;
		while(len>0) {
			get_bits_(8);
			len --;
		}

	} // while( the->gb.nCurrentBit > 0) {

	return i_err;
}

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
stx_inline STRING create_string(stx_swf* the)
{
	s32		i_len;
	char	st;
	char*	sp;
	char*	sz ;

	i_len = 256;
	sz = xmallocz(i_len);
	if( !sz ){
		return NULL;
	}

	sp = sz;

	for( ; ; ) {

		st = get_bits_(8);
		if( !st ){
			break;
		}

		*sp ++ = st;

		if( sp - sz == i_len ) {

			char* tt = xmallocz(i_len + 256);
			if( !tt ) {
				stx_free(sz);
				return NULL;
			}
			memcpy(tt,sz,i_len);
			stx_free(sz);
			sz = tt;
			sp = tt + i_len;
			i_len += 256;

		} // if( sp - sz == i_len ) {

	}// for( ; ; ) {

	return sz;
}



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(End,swf_tag_init)
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(End)
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ShowFrame,swf_tag_init)
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ShowFrame)
swf_release_end()




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(DefineShape,swf_tag_init)
{
	th->ishape = 1;
	th->ichid = get_word_;
	sscreate(swf_rect,the,&th->ShapeBounds);
	sscreate(SHAPEWITHSTYLE,the,&th->Shapes,th->ishape);
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(DefineShape)
{
	sdelete(SHAPEWITHSTYLE,&th->Shapes);
}
swf_release_end()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(PlaceObject,swf_tag_init)
{
	th->ichid = get_word_;		//UI16 ID of character to place
	th->Depth = get_word_;				//UI16 Depth of character
	sscreate(MATRIX,the,&th->Matrix);				//MATRIX Transform matrix data
	sscreate(CXFORM,the,&th->ColorTransform);		//(optional) CXFORM Color transform data
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(PlaceObject)
{
	sdelete(MATRIX,&th->Matrix);
	sdelete(CXFORM,&th->ColorTransform);
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(RemoveObject,swf_tag_init)
{
	th->ichid = get_word_;	//  UI16 ID of character to remove
	th->Depth = get_word_;			// UI16 Depth of character
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(RemoveObject)
{
}
swf_release_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(DefineBits,swf_tag_init)
{
	th->ichid = get_word_;
	th->JPEGData = (u8*)xmallocz(th->ilen-2);
	if( !th->JPEGData ) {
		break;
	}
	{
		u32 i;
		for( i = 0; i < th->ilen-2; i ++) {
			th->JPEGData[i] = get_bits_(8);
		}
	}
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(DefineBits)
{
	SAFE_XFREE(th->JPEGData);
}
swf_release_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(DefineButton,swf_tag_init)
{
	th->ichid = get_word_;			//  UI16  ID for this character 

	//  BUTTONRECORD[one or  Characters that make up the more]  button  
	th->i_max_btn = 16;
	th->i_btn = 0;
	th->Characters = (BUTTONRECORD**)xmallocz(sizeof(BUTTONRECORD*)*th->i_max_btn);		
	if( !th->Characters ) {
		break;
	}
	for( ; ; ) {
		th->CharacterEndFlag = stx_show_bits(&the->gb,8);	//  UI8  Must be 0 
		if( !th->CharacterEndFlag ) {
			break;
		}
		th->Characters[th->i_btn] = screate(BUTTONRECORD,the,NULL,1);
		if( !th->Characters[th->i_btn] ) {
			break;
		}

		th->i_btn ++;
		if( th->i_btn >= th->i_max_btn ) {
			s32 i;
			BUTTONRECORD** pp = (BUTTONRECORD**)xmallocz(sizeof(BUTTONRECORD*)*(th->i_max_btn+16));
			if( !pp) {
				break;
			}
			th->i_max_btn += 16;
			for( i = 0; i < th->i_act; i ++ ) {
				pp[i] = th->Characters[i];
			}
			stx_free(th->Characters);
			th->Characters = pp;
		} // if( th->i_btn >= th->i_max_btn ) {
	}
	if( th->CharacterEndFlag ) {
		break;
	}

	th->i_max_act = 16;
	th->i_act = 0;

	th->Actions = (swf_action**)xmallocz(sizeof(swf_action*)*th->i_max_act);
	if( !th->Actions ){//ACTIONRECORD [one or more] Actions to perform
		break;
	}


	for( ; ; ) {

		u16		Length;		//  If code >= 0x80, UI16 The number of bytes in the ACTIONRECORDHEADER, not
		// counting the ActionCode and Length fields

		Length = 0;
		th->ActionEndFlag = get_bits_(8);
		if( !th->ActionEndFlag ) {
			break;
		}
		if( th->ActionEndFlag >= 0x80 ) {
			Length = get_word_;
		}

		if( create_action[th->ActionEndFlag] ) {
			th->Actions[th->i_act] = (swf_action*)create_action[th->ActionEndFlag](the,NULL,th->ActionEndFlag,Length);
			if(!th->Actions[th->i_act]) {
				break;
			}
			th->i_act ++;
			if( th->i_act >= th->i_max_act ) {
				s32 i;
				swf_action** pp = (swf_action**)xmallocz(sizeof(swf_action*)*(th->i_max_act+16));
				if( !pp) {
					break;
				}
				th->i_max_act += 16;
				for( i = 0; i < th->i_act; i ++ ) {
					pp[i] = th->Actions[i];
				}
				stx_free(th->Actions);
				th->Actions = pp;
			} // if( th->i_act >= th->i_max ) {

			continue;
		} // if( create_action[ActionCode] ) {

		while(Length) {
			get_bits_(8);
			Length --;
		}

	} // while( i_len > 0 ) {

	if( th->ActionEndFlag ) {
		break;
	}

}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(DefineButton)
{
	s32 i;

	if( th->Characters ) {
		for( i = 0; i < th->i_btn; i ++ ) {
			SAFE_XCALL(release,th->Characters[i]);
		}
		stx_free(th->Characters);
	}
	if( th->Actions ) {
		for( i = 0; i < th->i_act; i ++ ) {
			SAFE_XCALL(release,th->Actions[i]);
		}
		stx_free(th->Actions);
	}

}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(JPEGTables,swf_tag_init)
{
	th->JPEGData = (u8*)xmallocz(th->ilen);
	if( !th->JPEGData ) {
		break;
	}
	{
		u32 i;
		for( i = 0; i < th->ilen; i ++ ) {
			th->JPEGData[i] = get_bits_(8);
		}
	}

}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(JPEGTables)
{
	SAFE_XFREE(th->JPEGData);
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(SetBackgroundColor,swf_tag_init)
{
	sscreate(swf_rgb,the,&th->BackgroundColor);	// RGB Color of the display background
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(SetBackgroundColor)
{
}
swf_release_end()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(DefineFont,swf_tag_init)
{
	u32 i;
	th->ichid = get_word_;				// UI16 ID for this font character
	th->nGlyphs = *stx_stack_pop(the->h_dec_stack);

	th->OffsetTable = (u16*)xmallocz(sizeof(u16)*th->nGlyphs);		// UI16[nGlyphs] Array of shape offsets
	if( !th->OffsetTable){
		break;
	}
	for( i = 0; i < th->nGlyphs; i ++ ) {
		th->OffsetTable[i] = get_word_;
	}

	//			;	// [nGlyphs] Array of Shapes.
	th->GlyphShapeTable = (SHAPE*)xmallocz(sizeof(SHAPE)*th->nGlyphs);
	if( !th->GlyphShapeTable ) {
		break;
	}
	for( i = 0; i < th->nGlyphs; i ++ ) {
		sscreate(SHAPE,the,&th->OffsetTable[i],1);
	}
	if( i != th->nGlyphs ) {
		break;
	}
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(DefineFont)
{
	SAFE_XFREE(th->OffsetTable);
	if( th->GlyphShapeTable ) {
		u32 i;
		for( i = 0; i < th->nGlyphs; i++ ) {
			sdelete(SHAPE,&th->GlyphShapeTable[i]);
		}
		stx_free(th->GlyphShapeTable);
	}
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(DefineText,swf_tag_init)
{
	th->ichid = get_word_;	// UI16 ID for this text character.
	sscreate(swf_rect,the,&th->TextBounds);	// RECT Bounds of the text.
	sscreate(MATRIX,the,&th->TextMatrix);	// Transformation matrix for the	text.
	th->GlyphBits = get_bits_(8);	// UI8 Bits in each glyph index.
	th->AdvanceBits = get_bits_(8);	// UI8 Bits in each advance value.

	//  TEXTRECORD[zero or more] Text records.
	//  UI8 Must be 0.

	th->i_max = 16;
	th->i_rec = 0;
	th->TextRecords = (TEXTRECORD**)xmallocz(sizeof(TEXTRECORD*)*th->i_max);		
	if( !th->TextRecords ) {
		break;
	}
	for( ; ; ) {
		th->EndOfRecordsFlag = stx_show_bits(&the->gb,8);	//  UI8  Must be 0 
		if( !th->EndOfRecordsFlag ) {
			break;
		}
		th->TextRecords[th->i_rec] = screate(TEXTRECORD,the,NULL,1,th->GlyphBits,th->AdvanceBits);
		if( !th->TextRecords[th->i_rec] ) {
			break;
		}

		th->i_rec ++;
		if( th->i_rec >= th->i_max ) {
			s32 i;
			TEXTRECORD** pp = (TEXTRECORD**)xmallocz(sizeof(TEXTRECORD*)*(th->i_max+16));
			if( !pp) {
				break;
			}
			th->i_max += 16;
			for( i = 0; i < th->i_rec; i ++ ) {
				pp[i] = th->TextRecords[i];
			}
			stx_free(th->TextRecords);
			th->TextRecords = pp;
		} // if( th->i_rec >= th->i_max ) {
	}
	if( th->EndOfRecordsFlag ) {
		break;
	}
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(DefineText)
{
	sdelete(swf_rect,&th->TextBounds);	// RECT Bounds of the text.
	sdelete(MATRIX,&th->TextMatrix);	// Transformation matrix for the	text.

	if( th->TextRecords ) {
		s32 i;
		for( i = 0; i < th->i_rec; i ++ ) {
			SAFE_XCALL(release,th->TextRecords[i]);
		}
		stx_free(th->TextRecords);
	}
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(DefineFontInfo,swf_tag_init)
{
	s32 i;
	th->FontID = get_word_;	// UI16 Font ID this information is for.
	th->FontNameLen = get_bits_(8);	// UI8 Length of font name.
	th->FontName = (u8*)xmallocz(th->FontNameLen+1);	// UI8[FontNameLen] Name of the font (see following).
	for( i = 0; i < th->FontNameLen; i ++ ) {
		th->FontName[i] = get_bits_(8);
	}
	th->FontFlagsReserved = get_bits_(2);	// UB[2] Reserved bit fields.
	th->FontFlagsSmallText = get_bits_(1);	// UB[1] SWF 7 file format or later: 
	//Font is small. Character glyphs are aligned on pixel boundaries  for dynamic and input text.
	th->FontFlagsShiftJIS = get_bits_(1);	// UB[1] ShiftJIS character codes.
	th->FontFlagsANSI = get_bits_(1);	// UB[1] ANSI character codes.
	th->FontFlagsItalic = get_bits_(1);	// UB[1] Font is italic.
	th->FontFlagsBold = get_bits_(1);	// UB[1] Font is bold.
	// UB[1] If 1, CodeTable is UI16 array; otherwise, CodeTable is UI8 array.
	th->FontFlagsWideCodes = get_bits_(1);
#if 0
	union{
		u16*	g16;	// If FontFlagsWideCodes,UI16[nGlyphs] Otherwise, UI8[nGlyphs]
		u8*		g8;
	}CodeTable;
#endif
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(DefineFontInfo)
{
	SAFE_XFREE(th->FontName);
}
swf_release_end()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(DefineSound,swf_tag_init)
{
	th->SoundId = get_word_;	// UI16 ID for this sound.
	th->SoundFormat = get_bits_(4);	// UB[4] Format of SoundData. See��Audio coding formats��on page 201.
	th->SoundRate = get_bits_(2);	// UB[2] The sampling rate. This is ignored for Nellymoser andSpeex co
	th->SoundSize = get_bits_(1);	// UB[1] Size of each sample. This parameter only pertains to
	th->SoundType = get_bits_(1);	// UB[1] Mono or stereo sound This is ignored for Nellymoser and Speex
	th->SoundSampleCount = get_dword_;	// UI32 Number of samples. Not affected by mono/stereo
	// UI8[size of sound data] The sound data; varies by	format.
	th->SoundData = (u8*)xmallocz(th->SoundSampleCount);	
	{
		u32 i;
		for( i = 0; i < th->SoundSampleCount; i ++ ) {
			th->SoundData[i] = get_bits_(8);
		}
	}
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(DefineSound)
{
	SAFE_XFREE(th->SoundData);
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(StartSound,swf_tag_init)
{
	th->SoundId = get_word_;	// UI16 ID of sound character to play.
	sscreate(SOUNDINFO,the,&th->SoundInfo);	// SOUNDINFO Sound style information.
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(StartSound)
{
	sdelete(SOUNDINFO,&th->SoundInfo);
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(DefineButtonSound,swf_tag_init)
{
	th->ButtonId = get_word_;	//  UI16  The ID of the button these  	sounds apply to.  
	th->ButtonSoundChar0 = get_word_;	//  UI16  Sound ID for OverUpToIdle  
	if(th->ButtonSoundChar0){
		sscreate(SOUNDINFO,the,&th->ButtonSoundInfo0);	
	}
	//  SOUNDINFO (if  Sound style for OverUpToIdle 	ButtonSoundChar0 is nonzero)   
	th->ButtonSoundChar1 = get_word_;	//  UI16  Sound ID for IdleToOverUp  
	if(th->ButtonSoundChar1){
		//  SOUNDINFO (if  Sound style for IdleToOverUp ButtonSoundChar1 is nonzero)  
		sscreate(SOUNDINFO,the,&th->ButtonSoundInfo1);	
	}
	th->ButtonSoundChar2 = get_word_;	//  UI16  Sound ID for  OverUpToOverDown  
	if(th->ButtonSoundChar2){
		//  SOUNDINFO (if  Sound style for ButtonSoundChar2 is  OverUpToOverDown 	nonzero)   
		sscreate(SOUNDINFO,the,&th->ButtonSoundInfo2);	
	}
	th->ButtonSoundChar3 = get_word_;	//  UI16  Sound ID for OverDownToOverUp 
	if(th->ButtonSoundChar3){
		//  SOUNDINFO (if  Sound style for ButtonSoundChar3 is  OverDownToOverUp 	nonzero)   
		sscreate(SOUNDINFO,the,&th->ButtonSoundInfo3);	
	}
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(DefineButtonSound)
{
	if(th->ButtonSoundChar0){
		sdelete(SOUNDINFO,&th->ButtonSoundInfo0);
	}
	if(th->ButtonSoundChar1){
		sdelete(SOUNDINFO,&th->ButtonSoundInfo1);
	}
	if(th->ButtonSoundChar2){
		sdelete(SOUNDINFO,&th->ButtonSoundInfo2);
	}
	if(th->ButtonSoundChar3){
		sdelete(SOUNDINFO,&th->ButtonSoundInfo3);
	}
}
swf_release_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(SoundStreamHead,swf_tag_init)
{
	//RECORDHEADER Header;	// Tag type = 18.
	th->Reserved = get_bits_(4);			// UB[4] Always zero.
	th->PlaybackSoundRate = get_bits_(2);	// UB[2] Playback sampling rate
	th->PlaybackSoundSize = get_bits_(1);	// UB[1] Playback sample size.	Always 1 (16 bit).
	th->PlaybackSoundType = get_bits_(1);	// UB[1] Number of playback channels:	mono or stereo.

	th->StreamSoundCompression = get_bits_(4);	// UB[4] Format of streaming sound	data.
	th->StreamSoundRate = get_bits_(2);	// UB[2] The sampling rate of the	streaming sound data.
	th->StreamSoundSize = get_bits_(1);	// UB[1] The sample size of the	streaming sound data. Always 1 (16 bit).
	th->StreamSoundType = get_bits_(1);	// UB[1] Number of channels in the	streaming sound data.
	th->StreamSoundSampleCount = get_word_;	// UI16 Average number of samples in	each SoundStreamBlock. Not
	//affected by mono/stereo	setting; for stereo sounds this is	the number of sample pairs.
	if( th->StreamSoundCompression == 2 ){
		th->LatencySeek = get_word_;	
		// If StreamSoundCompression	= 2, SI16	Otherwise absent	See ��MP3 sound data��
	}
	//on page 216. The value here	should match the  SeekSamples field in the first SoundStreamBlock for this	stream.
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(SoundStreamHead)
{
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(SoundStreamBlock,swf_tag_init)
{
	th->StreamSoundData = (u8*)xmallocz(th->ilen);
	if( !th->StreamSoundData){
		break;
	}
	{
		u32 i;
		for( i = 0; i < th->ilen; i ++ ) {
			th->StreamSoundData[i] = get_bits_(8);
		}
	}
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(SoundStreamBlock)
{
	SAFE_XFREE(th->StreamSoundData);
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(DefineBitsLossless,swf_tag_init)
{
	th->ichid = get_word_;	// 	 UI16 ID for this character
	th->BitmapFormat = get_bits_(8);	// 	 UI8 Format of compressed data
	// 	3 = 8-bit colormapped image
	// 	4 = 15-bit RGB image
	// 	5 = 24-bit RGB image
	th->BitmapWidth = get_word_;	// 	 UI16 Width of bitmap image
	th->BitmapHeight = get_word_;	// 	 UI16 Height of bitmap image
	if( th->BitmapFormat == 3 ){
		th->BitmapColorTableSize = get_bits_(8);	// 	 If BitmapFormat = 3, UI8 Otherwise absent
		// 	This value is one less than the actual number of colors in the
		// 	color table, allowing for up to 256 colors.
		// 	 If BitmapFormat = 3, COLORMAPDATA
		sscreate(COLORMAPDATA,the,&th->ZlibBitmapData.clr,th->BitmapFormat,th->BitmapColorTableSize);
	}
	else if( th->BitmapFormat == 4 || th->BitmapFormat == 3 ){
		// 	If BitmapFormat = 4 or 5, BITMAPDATA ZLIB compressed bitmap data
		sscreate(BITMAPDATA,the,&th->ZlibBitmapData.bmp,th->BitmapFormat,th->BitmapColorTableSize);
	}
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(DefineBitsLossless)
{
	if( th->BitmapFormat == 3 ){
		sdelete(COLORMAPDATA,&th->ZlibBitmapData.clr);// 	 If BitmapFormat = 3, COLORMAPDATA
	}
	else if( th->BitmapFormat == 4 || th->BitmapFormat == 3 ){
		// 	If BitmapFormat = 4 or 5, BITMAPDATA ZLIB compressed bitmap data
		sdelete(BITMAPDATA,&th->ZlibBitmapData.bmp);
	}
}
swf_release_end()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(DefineBitsJPEG2,swf_tag_init)
{
	th->ichid = get_word_;	//  UI16 ID for this character
	th->ImageData = (u8*)xmallocz(th->ilen);
	{//  UI8[data size] Compressed image data in either JPEG, PNG, or GIF89a format
		u32 i;
		for( i = 0; i < th->ilen - 2; i ++ ) {
			th->ImageData[i] = get_bits_(8);
		}
	}
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(DefineBitsJPEG2)
{
	SAFE_XFREE(th->ImageData);
}
swf_release_end()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(DefineShape2,swf_tag_init)
{
	th->ichid = get_word_;			// UI16 ID for this character.
	sscreate(swf_rect,the,&th->ShapeBounds);		// RECT Bounds of the shape.
	sscreate(SHAPEWITHSTYLE,the,&th->Shapes,2);				//  Shape information
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(DefineShape2)
{
	sdelete(swf_rect,&th->ShapeBounds);		// RECT Bounds of the shape.
	sdelete(SHAPEWITHSTYLE,&th->Shapes);				//  Shape information
}
swf_release_end()




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(DefineButtonCxform,swf_tag_init)
{
	th->ButtonId = get_word_; //  UI16  Button ID for this information  
	sscreate(CXFORM,the,&th->ButtonColorTransform); //  Character color transform  
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(DefineButtonCxform)
{
	sdelete(CXFORM,&th->ButtonColorTransform);
}
swf_release_end()




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(Protect,swf_tag_init)
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(Protect)
swf_release_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(PlaceObject2,swf_tag_init)
{
	th->PlaceFlagHasClipActions = get_bits_(1);	
	//UB[1] SWF 5 and later: has clip actions (sprite characters only)	Otherwise: always 0
	th->PlaceFlagHasClipDepth = get_bits_(1);		//UB[1] Has clip depth
	th->PlaceFlagHasName = get_bits_(1);			//UB[1] Has name
	th->PlaceFlagHasRatio = get_bits_(1);			//UB[1] Has ratio
	th->PlaceFlagHasColorTransform = get_bits_(1);	//UB[1] Has color transform
	th->PlaceFlagHasMatrix = get_bits_(1);			//UB[1] Has matrix
	th->PlaceFlagHasCharacter = get_bits_(1);		//UB[1] Places a character
	th->PlaceFlagMove = get_bits_(1);				//UB[1] Defines a character to be moved
	th->Depth = get_word_;						//UI16 Depth of character
	if(th->PlaceFlagHasCharacter){
		th->CharacterId = get_word_;				//If PlaceFlagHasCharacter UI16 ID of character to place
	}
	if( th->PlaceFlagHasMatrix ) {
		sscreate(MATRIX,the,&th->Matrix);						
		//If PlaceFlagHasMatrix MATRIX Transform matrix data
	}
	if( th->PlaceFlagHasColorTransform ) {
		sscreate(CXFORMWITHALPHA,the,&th->ColorTransform);				
		//If PlaceFlagHasColorTransform CXFORMWITHALPHA Color transform data
	}
	if( th->PlaceFlagHasRatio ) {
		th->Ratio = get_word_;						//If PlaceFlagHasRatio UI16
	}
	if( th->PlaceFlagHasName ) {
		th->Name = create_string(the);						//If PlaceFlagHasName STRING Name of character
		if(!th->Name ) {
			break;
		}
	}
	if( th->PlaceFlagHasClipDepth ) {
		//If PlaceFlagHasClipDepth UI16 Clip depth (see ��Clipping layers�� on page 32)
		th->ClipDepth = get_word_;					
	}
	if( th->PlaceFlagHasClipActions ) {
		sscreate(CLIPACTIONS,the,&th->ClipActions);				
		//If PlaceFlagHasClipActions CLIPACTIONS; SWF 5 and later:Clip Actions Data
	}
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(PlaceObject2)
{
	if( th->PlaceFlagHasMatrix ) {
		sdelete(MATRIX,&th->Matrix);						
		//If PlaceFlagHasMatrix MATRIX Transform matrix data
	}
	if( th->PlaceFlagHasColorTransform ) {
		sdelete(CXFORMWITHALPHA,&th->ColorTransform);				
		//If PlaceFlagHasColorTransform CXFORMWITHALPHA Color transform data
	}
	SAFE_XFREE(th->Name);
	if( th->PlaceFlagHasClipActions ) {
		sdelete(CLIPACTIONS,&th->ClipActions);				
		//If PlaceFlagHasClipActions CLIPACTIONS; SWF 5 and later:Clip Actions Data
	}
}
swf_release_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(RemoveObject2,swf_tag_init)
{
	th->Depth = get_word_;
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(RemoveObject2)
{
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(DefineShape3,swf_tag_init)
{
	th->ishape = 3;
	th->ichid = get_word_;		// 		UI16 ID for this character.
	sscreate(swf_rect,the,&th->ShapeBounds);	// 	RECT Bounds of the shape.
	sscreate(SHAPEWITHSTYLE,the,&th->Shapes,3);			//  Shape information.
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(DefineShape3)
{
	sdelete(swf_rect,&th->ShapeBounds);	// 	RECT Bounds of the shape.
	sdelete(SHAPEWITHSTYLE,&th->Shapes);			//  Shape information.
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(DefineText2,swf_tag_init)
{
	th->ichid = get_word_;	// UI16 ID for this text character.
	sscreate(swf_rect,the,&th->TextBounds);	// RECT Bounds of the text.
	sscreate(MATRIX,the,&th->TextMatrix);	// Transformation matrix.
	th->GlyphBits = get_bits_(8);	// UI8 Bits in each glyph index.
	th->AdvanceBits = get_bits_(8);	// UI8 Bits in each advance value.

	//TEXTRECORD**	TextRecords;	// TEXTRECORD[zero or more] Text records.
	//u8				EndOfRecordsFlag;	// UI8 Must be 0.

	th->i_max = 16;
	th->i_rec = 0;
	th->TextRecords = (TEXTRECORD**)xmallocz(sizeof(TEXTRECORD*)*th->i_max);		
	if( !th->TextRecords ) {
		break;
	}
	for( ; ; ) {
		th->EndOfRecordsFlag = stx_show_bits(&the->gb,8);	//  UI8  Must be 0 
		if( !th->EndOfRecordsFlag ) {
			break;
		}
		th->TextRecords[th->i_rec] = screate(TEXTRECORD,the,NULL,2,th->GlyphBits,th->AdvanceBits);
		if( !th->TextRecords[th->i_rec] ) {
			break;
		}

		th->i_rec ++;
		if( th->i_rec >= th->i_max ) {
			s32 i;
			TEXTRECORD** pp = (TEXTRECORD**)xmallocz(sizeof(TEXTRECORD*)*(th->i_max+16));
			if( !pp) {
				break;
			}
			th->i_max += 16;
			for( i = 0; i < th->i_rec; i ++ ) {
				pp[i] = th->TextRecords[i];
			}
			stx_free(th->TextRecords);
			th->TextRecords = pp;
		} // if( th->i_rec >= th->i_max ) {
	}
	if( th->EndOfRecordsFlag ) {
		break;
	}
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(DefineText2)
{
	sdelete(swf_rect,&th->TextBounds);	// RECT Bounds of the text.
	sdelete(MATRIX,&th->TextMatrix);	// Transformation matrix for the	text.

	if( th->TextRecords ) {
		s32 i;
		for( i = 0; i < th->i_rec; i ++ ) {
			SAFE_XCALL(release,th->TextRecords[i]);
		}
		stx_free(th->TextRecords);
	}
}
swf_release_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(DefineButton2,swf_tag_init)
{
	u16 Length;		

	th->i_btn = 2;
	th->ichid = get_word_; //   UI16  ID for this character  	
	get_bits_(7);				//ReservedFlags; //   UB[7]  Always 0  
	th->TrackAsMenu = get_bits_(1); //   UB[1]  0 = track as normal button 1 = track as menu button  
	//   UI16  Offset in bytes from start of this field to the first BUTTONCONDACTION, or 0 if no actions occur  
	th->ActionOffset = get_word_; 

	//BUTTONRECORD**	Characters; //    [one or more]  Characters that make up the button

	th->i_max_btn = 16;
	th->i_btn = 0;
	th->Characters = (BUTTONRECORD**)xmallocz(sizeof(BUTTONRECORD*)*th->i_max_btn);		
	if( !th->Characters ) {
		break;
	}
	for( ; ; ) {
		th->CharacterEndFlag = stx_show_bits(&the->gb,8);	//  UI8  Must be 0 
		if( !th->CharacterEndFlag ) {
			break;
		}
		th->Characters[th->i_btn] = screate(BUTTONRECORD,the,NULL,2);
		if( !th->Characters[th->i_btn] ) {
			break;
		}

		th->i_btn ++;
		if( th->i_btn >= th->i_max_btn ) {
			s32 i;
			BUTTONRECORD** pp = (BUTTONRECORD**)xmallocz(sizeof(BUTTONRECORD*)*(th->i_max_btn+16));
			if( !pp) {
				break;
			}
			th->i_max_btn += 16;
			for( i = 0; i < th->i_act; i ++ ) {
				pp[i] = th->Characters[i];
			}
			stx_free(th->Characters);
			th->Characters = pp;
		} // if( th->i_btn >= th->i_max_btn ) {
	}
	if( th->CharacterEndFlag ) {
		break;
	}

	th->i_max_act = 16;
	th->i_act = 0;

	th->Actions = (BUTTONCONDACTION**)xmallocz(sizeof(BUTTONCONDACTION*)*th->i_max_act);
	if( !th->Actions ){//ACTIONRECORD [one or more] Actions to perform
		break;
	}

	Length = 0;

	for( ; ; ) {

		Length = get_word_;
		if( !Length ) {
			break;
		}

		th->Actions[th->i_act] = screate(BUTTONCONDACTION,the,NULL,Length);
		if(!th->Actions[th->i_act]) {
			break;
		}
		th->i_act ++;
		if( th->i_act >= th->i_max_act ) {
			s32 i;
			BUTTONCONDACTION** pp = (BUTTONCONDACTION**)xmallocz(sizeof(BUTTONCONDACTION*)*(th->i_max_act+16));
			if( !pp) {
				break;
			}
			th->i_max_act += 16;
			for( i = 0; i < th->i_act; i ++ ) {
				pp[i] = th->Actions[i];
			}
			stx_free(th->Actions);
			th->Actions = pp;
		} // if( th->i_act >= th->i_max ) {


	} // while( i_len > 0 ) {

	if( Length ) {
		break;
	}
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(DefineButton2)
{
	s32 i;

	if( th->Characters ) {
		for( i = 0; i < th->i_btn; i ++ ) {
			SAFE_XCALL(release,th->Characters[i]);
		}
		stx_free(th->Characters);
	}
	if( th->Actions ) {
		for( i = 0; i < th->i_act; i ++ ) {
			SAFE_XCALL(release,th->Actions[i]);
		}
		stx_free(th->Actions);
	}

}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(BUTTONCONDACTION,u32 CondSize)
{
	th->CondActionSize = CondSize; // UI16 Offset in bytes from start of this field to next BUTTONCONDACTION, or 0 if last action
	th->CondIdleToOverDownj = get_bits_(1);  // UB[1] Idle to OverDown
	th->CondOutDownToIdle = get_bits_(1);  // UB[1] OutDown to Idle
	th->CondOutDownToOverDown = get_bits_(1);  // UB[1] OutDown to OverDown
	th->CondOverDownToOutDown = get_bits_(1);  // UB[1] OverDown to OutDown
	th->CondOverDownToOverUp = get_bits_(1);  //  UB[1] OverDown to OverUp
	th->CondOverUpToOverDown = get_bits_(1);  //  UB[1] OverUp to OverDown
	th->CondOverUpToIdle = get_bits_(1);  //  UB[1] OverUp to Idle
	th->CondIdleToOverUp = get_bits_(1);  //  UB[1] Idle to OverUp
	th->CondKeyPress = get_bits_(7);		//  UB[7]  SWF 4 or later: key code Otherwise: always 0 Valid key codes: 1 = left arrow 2 = right arrow 3 = home 4 = end 5 = insert 6 = delete 8 = backspace 13 = enter 14 = up arrow 15 = down arrow 16 = page up 17 = page down 18 = tab 19 = escape 32 to 126: follows ASCII  
	th->CondOverDownToIdle = get_bits_(1); //  UB[1]  OverDown to Idle  
	//s32				i_max;
	//s32				i_act;
	//swf_action**	Actions; //   [zero or more]  Actions to perform. See DoAction.  
	//u8				ActionEndFlag; //  UI8  Must be 0  

	th->i_max = 16;
	th->i_act = 0;

	th->Actions = (swf_action**)xmallocz(sizeof(swf_action*)*th->i_max);
	if( !th->Actions ){//ACTIONRECORD [one or more] Actions to perform
		break;
	}


	for( ; ; ) {

		u16		Length;		//  If code >= 0x80, UI16 The number of bytes in the ACTIONRECORDHEADER, not
		// counting the ActionCode and Length fields

		Length = 0;
		th->ActionEndFlag = get_bits_(8);
		if( !th->ActionEndFlag ) {
			break;
		}
		if( th->ActionEndFlag >= 0x80 ) {
			Length = get_word_;
		}

		if( create_action[th->ActionEndFlag] ) {
			th->Actions[th->i_act] = (swf_action*)create_action[th->ActionEndFlag](the,NULL,th->ActionEndFlag,Length);
			if(!th->Actions[th->i_act]) {
				break;
			}
			th->i_act ++;
			if( th->i_act >= th->i_max ) {
				s32 i;
				swf_action** pp = (swf_action**)xmallocz(sizeof(swf_action*)*(th->i_max+16));
				if( !pp) {
					break;
				}
				th->i_max += 16;
				for( i = 0; i < th->i_act; i ++ ) {
					pp[i] = th->Actions[i];
				}
				stx_free(th->Actions);
				th->Actions = pp;
			} // if( th->i_act >= th->i_max ) {

			continue;
		} // if( create_action[ActionCode] ) {

		while(Length) {
			get_bits_(8);
			Length --;
		}

	} // while( i_len > 0 ) {

	if( th->ActionEndFlag ) {
		break;
	}

}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(BUTTONCONDACTION)
{
	s32 i;

	if( th->Actions ) {
		for( i = 0; i < th->i_act; i ++ ) {
			SAFE_XCALL(release,th->Actions[i]);
		}
		stx_free(th->Actions);
	}

}
swf_release_end()





/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(DefineBitsJPEG3,swf_tag_init)
{
	th->ichid = get_word_;		//  UI16 ID for this character.
	th->AlphaDataOffset = get_dword_;	//  UI32 Count of bytes in ImageData.
	//  UI8[data size] Compressed image data in either JPEG, PNG, or GIF89a format
	th->ImageData = (u8*)xmallocz(th->AlphaDataOffset);	
	if( !th->ImageData) {
		break;
	}
	{
		u32 i,i_size; 
		for( i = 0; i < th->AlphaDataOffset; i ++ ) {
			th->ImageData[i] = get_bits_(8);
		}
		//  UI8[alpha data size] ZLIB compressed array OF alpha data. Only supported
		i_size = th->ilen - th->AlphaDataOffset - 6;
		th->BitmapAlphaData = (u8*)xmallocz(i_size);
		if( !th->BitmapAlphaData){
			break;
		}
		for( i = 0; i < i_size; i ++ ) {
			th->BitmapAlphaData[i] = get_bits_(8);
		}
	}
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(DefineBitsJPEG3)
{
	SAFE_XFREE(th->ImageData);
	SAFE_XFREE(th->BitmapAlphaData);
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(DefineBitsLossless2,swf_tag_init)
{
	th->ichid = get_word_;	// 	 UI16 ID for this character
	th->BitmapFormat = get_bits_(8);	// 	 UI8 Format of compressed data
	// 				3 = 8-bit colormapped image
	// 				5 = 32-bit ARGB image
	th->BitmapWidth = get_word_;	// 		UI16 Width of bitmap image
	th->BitmapHeight = get_word_;	// 		UI16 Height of bitmap image
	if( th->BitmapFormat == 3 ){
		th->BitmapColorTableSize = get_bits_(8);// 	 If BitmapFormat = 3, UI8	Otherwise absent
	}
	// 	This value is one less than the	actual number of colors in the	color table, allowing for up to	256 colors.
	sscreate(ALPHABITMAPDATA,the,&th->ZlibBitmapData,th->BitmapWidth*th->BitmapHeight,th->BitmapFormat);	
	// 	 If BitmapFormat = 3,	ALPHACOLORMAPDATA

}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(DefineBitsLossless2)
{
	sdelete(ALPHABITMAPDATA,&th->ZlibBitmapData);
}
swf_release_end()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(DefineEditText,swf_tag_init)
{
	th->ichid = get_word_;	// UI16 ID for this dynamic TEXT character.
	sscreate(swf_rect,the,&th->Bounds);	// RECT Rectangle that completely encloses the text field.
	th->HasText = get_bits_(1);	// UB[1] 0 = text field has no default text.
	//1 = text field initially displays the string specified by InitialText.
	th->WordWrap = get_bits_(1);	// UB[1] 0 = text will not wrap and will 	scroll sideways. 
	//1 = text will wrap automatically when the end of line is reached.
	th->Multiline = get_bits_(1);	// UB[1] 0 = text field is one line only.
	//1 = text field is multi-line and scrollable.
	th->Password = get_bits_(1);	// UB[1] 0 = characters are displayed as typed.
	//1 = all characters are displayed as an asterisk.
	th->ReadOnly = get_bits_(1);	// UB[1] 0 = text editing is enabled. 1 = text editing is disabled.

	th->HasTextColor = get_bits_(1);	// UB[1] 0 = use default color. 	1 = use specified color	(TextColor).
	th->HasMaxLength = get_bits_(1);	// UB[1] 0 = length of text is unlimited. 1 = maximum length of string is specified by MaxLength.
	th->HasFont = get_bits_(1);	// UB[1] 0 = use default font. 1 = use specified font (FontID) and height (FontHeight). 
	//(Can��t be true if HasFontClass is true).
	th->HasFontClass = get_bits_(1);	// UB[1] 0 = no fontClass, 1 = fontClass and Height specified for this
	//text. (can't be true if HasFont is true). Supported in Flash Player 9.0.45.0 and later.
	th->AutoSize = get_bits_(1);	// UB[1] 0 = fixed size. 1 = sizes to content (SWF 6 or later only).
	th->HasLayout = get_bits_(1);	// UB[1] Layout information provided.
	th->NoSelect = get_bits_(1);	// UB[1] Enables or disables interactive text selection.
	th->Border = get_bits_(1);	// UB[1] Causes a border to be drawn around the text field.

	th->WasStatic = get_bits_(1);	// UB[1] 0 = Authored as dynamic text 1 = Authored as static text
	th->HTML = get_bits_(1);	// UB[1] 0 = plaintext content. 1 = HTML content (see following).
	th->UseOutlines = get_bits_(1);	// UB[1] 0 = use device font. 1 = use glyph font.
	if( th->HasFont){
		th->FontID = get_word_;	// If HasFont, UI16 ID of font to use.
	}
	if( th->HasFontClass){
		// If HasFontClass, STRING Class name of font to be loaded from another SWF and used for this text.
		th->FontClass = create_string(the);	
		if( !th->FontClass ) {
			break;
		}
	}
	if( th->HasFont ) {
		th->FontHeight = get_word_;	// If HasFont, UI16 Height of font in twips.
	}
	if( th->HasTextColor){
		sscreate(swf_rgba,the,&th->TextColor);	// If HasTextColor, RGBA Color of text.
	}
	if( th->HasMaxLength){
		th->MaxLength = get_word_;	// If HasMaxLength, UI16 Text is restricted to this length.
	}
	if( th->HasLayout) {
		th->Align = get_bits_(8); //Align If HasLayout, UI8 0 = Left
		//1 = Right
		//2 = Center
		//3 = Justify
		th->LeftMargin = get_word_;	// If HasLayout, UI16 Left margin in twips.
		th->RightMargin = get_word_;	// If HasLayout, UI16 Right margin in twips.
		th->Indent = get_word_;	// If HasLayout, UI16 Indent in twips.
		th->Leading = get_word_;	// If HasLayout, SI16 Leading in twips (vertical distance between bottom of
		//descender of one line and top of ascender of the next).
	}
	

	//STRING VariableName;	// STRING Name of the variable where the
	//contents of the text field are stored. May be qualified with
	//dot syntax or slash syntax for non-global variables.
	th->VariableName = create_string(the);
	if( !th->VariableName ) {
		break;
	}

	if( th->HasText ) {
		//STRING InitialText;	// If HasText STRING Text that is initially displayed.
		th->InitialText = create_string(the);
		if( !th->InitialText ) {
			break;
		}
	}
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(DefineEditText)
{
	SAFE_XFREE(th->FontClass);
	SAFE_XFREE(th->VariableName);
	SAFE_XFREE(th->InitialText);
}
swf_release_end()




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(DefineSprite,swf_tag_init)
{
	th->Sprite = get_word_;			// ID UI16 Character ID of sprite
	th->FrameCount = get_word_;		// UI16 Number of frames in sprite
	th->ControlTags = (u8*)xmallocz(th->FrameCount);	// TAG[one or more] A series of tags
	if( !th->ControlTags ) {
		break;
	}
	{
		u32 i;
		for( i = 0; i < th->FrameCount; i ++ ) {
			th->ControlTags[i] = get_bits_(8);
		}
	}
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(DefineSprite)
{
	SAFE_XFREE(th->ControlTags);
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(NamedAnchor,swf_tag_init)
{
	// Null-terminated .	(0 is NULL)	Label for frame.
	th->szName = create_string(the);			
	if( !th->szName ) {
		break;
	}
	th->anchor = get_bits_(8);			// flag UI8 Always 1
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(NamedAnchor)
{
	SAFE_XFREE(th->szName);
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(SoundStreamHead2,swf_tag_init)
{
	get_bits_(4);//Reserved;	// UB[4] Always zero.
	th->PlaybackSoundRate = get_bits_(2);	// UB[2] Playback sampling rate.
	//0 = 5.5 kHz
	//1 = 11 kHz
	//2 = 22 kHz
	//3 = 44 kHz
	th->PlaybackSoundSize = get_bits_(1);	// UB[1] Playback sample size.
	//0 = 8-bit
	//1 = 16-bit
	th->PlaybackSoundType = get_bits_(1);	// UB[1] Number of playback channels.
	//0 = sndMono
	//1 = sndStereo
	th->StreamSoundCompression = get_bits_(4);	// UB[4] Format of SoundData. See	��Audio coding formats��	on page 201.
	th->StreamSoundRate = get_bits_(2);	// UB[2] The sampling rate of the streaming sound data.
	//5.5 kHz is not allowed for MP3.
	//0 = 5.5 kHz
	//1 = 11 kHz
	//2 = 22 kHz
	//3 = 44 kHz
	th->StreamSoundSize = get_bits_(1);	// UB[1] Size of each sample. Always 16 bit for compressed formats.
	//May be 8 or 16 bit for uncompressed formats.
	//0 = 8-bit
	//1 = 16-bit
	th->StreamSoundType = get_bits_(1);	// UB[1] Number of channels in the	streaming sound data.
	//0 = sndMono
	//1 = sndStereo

	th->StreamSoundSampleCount = get_word_;	// UI16 Average number of samples in
	//each SoundStreamBlock. Not 	affected by mono/stereo
	//setting; for stereo sounds this is 	the number of sample pairs.
	//LatencySeek If StreamSoundCompression 	= 2, SI16 	Otherwise absent
	//See MP3 sound data. The value here should match the
	//SeekSamples field in the first 	SoundStreamBlock for this stream.
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(SoundStreamHead2)
{
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(DefineMorphShape,swf_tag_init)
{
	th->ichid = get_word_;		//  UI16 ID for this character
	sscreate(swf_rect,the,&th->StartBounds);		//  RECT Bounds of the start shape
	sscreate(swf_rect,the,&th->EndBounds);			//  RECT Bounds of the end shape
	th->Offset = get_dword_;				//  UI32 Indicates offset to EndEdges
	sscreate(MORPHFILLSTYLEARRAY,the,&th->MorphFillStyles);	//  Fill style information is stored in
	// 	the same manner as for a standard shape; however, eachfill consists of interleaved
	// 	information based on a singlestyle type to accommodate	morphing.
	sscreate(MORPHLINESTYLEARRAY,the,&th->MorphLineStyles,1);	//  Line style information is stored
	// 	in the same manner as for a	standard shape; however, each
	// 	line consists of interleaved information based on a single
	// 	style type to accommodate morphing.

	sscreate(SHAPE,the,&th->StartEdges,1); // Contains the set of edges and
	//the style bits that indicate style		changes (for example, MoveTo,
	//FillStyle, and LineStyle).		Number of edges must equal		the number of edges in		EndEdges.

	sscreate(SHAPE,the,&th->EndEdges,1); //Contains only the set of edges,	with no style information.	Number of edges must equal
	// the number of edges in	StartEdges.

}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(DefineMorphShape)
{
	sdelete(MORPHFILLSTYLEARRAY,&th->MorphFillStyles);
	sdelete(MORPHLINESTYLEARRAY,&th->MorphLineStyles);
	sdelete(SHAPE,&th->StartEdges);
	sdelete(SHAPE,&th->EndEdges);
}
swf_release_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(DefineFont2,swf_tag_init)
{

	th->ichid = get_word_;	// UI16 ID for this font character.
	th->FontFlagsHasLayout = get_bits_(1);	// UB[1] Has font metrics/layoutinformation.
	th->FontFlagsShiftJIS = get_bits_(1);	// UB[1] ShiftJIS encoding.
	th->FontFlagsSmallText = get_bits_(1);	// UB[1] SWF 7 or later:Font is small. Character glyphs

	//are aligned on pixel boundaries	for dynamic and input text.

	th->FontFlagsANSI = get_bits_(1);	// UB[1] ANSI encoding.
	th->FontFlagsWideOffsets = get_bits_(1);	// UB[1] If 1, uses 32 bit offsets.
	th->FontFlagsWideCodes = get_bits_(1);	// UB[1] If 1, font uses 16-bit codes;	otherwise font uses 8 bit codes.
	th->FontFlagsItalic = get_bits_(1);	// UB[1] Italic Font.
	th->FontFlagsBold = get_bits_(1);	// UB[1] Bold Font.

	th->LanguageCode = get_dword_;	// LANGCODE SWF 5 or earlier:	always 0	SWF 6 or later:	language code
	th->FontNameLen = get_bits_(8);	// UI8 Length of name.
	th->FontName = (u8*)xmallocz(th->FontNameLen);	// UI8[FontNameLen] Name of font (see	DefineFontInfo).
	if(!th->FontName) {
		break;
	}
	{
		u32 i;
		for( i = 0; i < th->FontNameLen; i ++ ) {
			th->FontName[i] = get_bits_(8);
		}
	}

	th->NumGlyphs = get_word_; // UI16 Count of glyphs in font.	May be zero for device fonts.

	// If FontFlagsWideOffsets,UI32[NumGlyphs]	Otherwise UI16[NumGlyphs]	Same as in DefineFont.
	if( th->NumGlyphs ) {
		u32 i;
		if(th->FontFlagsWideOffsets) {
			th->OffsetTable.d32 = (u32*)xmallocz(th->NumGlyphs*sizeof(u32));
			if(!th->OffsetTable.d32){
				break;
			}
			for( i = 0; i < th->NumGlyphs; i ++ ) {
				th->OffsetTable.d32[i] = get_dword_;
			}
		}
		else{
			th->OffsetTable.d16 = (u16*)xmallocz(th->NumGlyphs*sizeof(u16));
			if(!th->OffsetTable.d16){
				break;
			}
			for( i = 0; i < th->NumGlyphs; i ++ ) {
				th->OffsetTable.d16[i] = get_word_;
			}
		}
	}

	if( th->FontFlagsWideOffsets ){
		th->CodeTableOffset = get_dword_; 
		// If FontFlagsWideOffsets,	UI32	Otherwise UI16	Byte count from start of
		//OffsetTable to start of	CodeTable.
	}
	else{
		th->CodeTableOffset = get_word_; 
	}

	if( th->NumGlyphs ){

		th->GlyphShapeTable = (SHAPE*)xmallocz(sizeof(SHAPE)*th->NumGlyphs);
		if( !th->GlyphShapeTable){
			break;
		}
		{// SHAPE[NumGlyphs] Same as in DefineFont.
			u32 i;
			for( i = 0; i < th->NumGlyphs; i ++ ) {
				sscreate(SHAPE,the,&th->GlyphShapeTable[i],2);
			}
		}

		if( th->FontFlagsWideCodes ){
			// If FontFlagsWideCodes,	UI16[NumGlyphs]	Otherwise UI8[NumGlyphs]	Sorted in ascending order.
			th->CodeTable.d16 = (u16*)xmallocz(sizeof(u16)*th->NumGlyphs);
			if( !th->CodeTable.d16){
				break;
			}
			{
				u32 i;
				for( i = 0; i < th->NumGlyphs; i ++ ) {
					th->CodeTable.d16[i] = get_word_;
				}
			}
		}
		else{
			th->CodeTable.d8 = (u8*)xmallocz(sizeof(u8)*th->NumGlyphs);
			if( !th->CodeTable.d8){
				break;
			}
			{
				u32 i;
				for( i = 0; i < th->NumGlyphs; i ++ ) {
					th->CodeTable.d8[i] = get_bits_(8);
				}
			}
		}
		//Always UCS-2 in SWF 6 or later.
	}
	
	th->FontAscent = get_word_;	// If FontFlagsHasLayout, SI16 Font ascender height.
	th->FontDescent = get_word_;	// If FontFlagsHasLayout, SI16 Font descender height.
	th->FontLeading = get_word_;	// If FontFlagsHasLayout, SI16 Font leading height (see following).

	if( th->FontFlagsHasLayout && th->NumGlyphs ) {

		u32 i;

		// If FontFlagsHasLayout,	SI16[NumGlyphs]
		//Advance value to be used for each glyph in dynamic glyph text.
		th->FontAdvanceTable = (s16*)xmallocz(th->NumGlyphs*sizeof(s16));
		if(!th->FontAdvanceTable) {
			break;
		}
		for( i = 0; i < th->NumGlyphs; i ++ ) {
			th->FontAdvanceTable[i] = get_word_;
		}

		// If FontFlagsHasLayout,RECT[NumGlyphs]
		//Not used in Flash Player through version 7 (but must be present).
		th->FontBoundsTable = (swf_rect*)xmallocz(th->NumGlyphs*sizeof(swf_rect));
		if(!th->FontBoundsTable) {
			break;
		}
		for( i = 0; i < th->NumGlyphs; i ++ ) {
			sscreate(swf_rect,the,&th->FontBoundsTable[i]);
		}
		if( i != th->NumGlyphs ) {
			break;
		}
	} // if( th->FontFlagsHasLayout && th->NumGlyphs ) {

	if( th->FontFlagsHasLayout ) {
		th->KerningCount = get_word_;// If FontFlagsHasLayout, UI16 Not used in Flash Player through
		//version 7 (always set to 0 to save	space).
		if( th->KerningCount ) {

			th->FontKerningTable = (KERNINGRECORD*)xmallocz(sizeof(KERNINGRECORD)*th->KerningCount);
			if(!th->FontKerningTable) {
				break;
			}
			{
				u32 i;
				for( i = 0; i < th->NumGlyphs; i ++ ) {
					sscreate(KERNINGRECORD,the,&th->FontKerningTable[i],th->FontFlagsWideCodes);
				}
				if( i != th->NumGlyphs ) {
					break;
				}
			}

			// If FontFlagsHasLayout,	[KerningCount]
			//Not used in Flash Player through version 7 (omit withKerningCount of 0).
		}
	}

}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(DefineFont2)
{
	u32 i;
	SAFE_XFREE(th->FontName);
	SAFE_XFREE(th->OffsetTable.d32);
	if( th->GlyphShapeTable) {
		for( i = 0;  i < th->NumGlyphs; i ++ ) {
			sdelete(SHAPE,&th->GlyphShapeTable[i]);
		}
		stx_free(th->GlyphShapeTable);
	}
	SAFE_XFREE(th->CodeTable.d16);
	SAFE_XFREE(th->FontAdvanceTable);
	if( th->FontBoundsTable) {
		for( i = 0;  i < th->NumGlyphs; i ++ ) {
			sdelete(swf_rect,&th->FontBoundsTable[i]);
		}
		stx_free(th->FontBoundsTable);
	}
	if( th->FontKerningTable) {
		for( i = 0;  i < th->NumGlyphs; i ++ ) {
			sdelete(KERNINGRECORD,&th->FontKerningTable[i]);
		}
		stx_free(th->FontKerningTable);
	}
}
swf_release_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ExportAssets,swf_tag_init)
{
	th->Count = get_word_;			// UI16 Number of assets to export
	th->nl = (ExportAssets_nl*)xmallocz(sizeof(ExportAssets_nl)*th->Count);
	if( !th->nl){
		break;
	}
	{
		u32 i;
		for( i = 0; i < th->Count; i++ ) {
			th->nl[i].Tag = get_word_;
			th->nl[i].szName = create_string(the);
			if( !th->nl[i].szName){
				break;
			}
		}
		if( i != th->Count ) {
			break;
		}
	}
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ExportAssets)
{
	if( th->nl ) {
		u32 i;
		for( i = 0; i < th->Count; i++ ) {
			SAFE_XFREE(th->nl[i].szName);
		}
		stx_free(th->nl);
	}
}
swf_release_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ImportAssets,swf_tag_init)
{
	th->URL = create_string(the);
	if( !th->URL){
		break;
	}
	th->Count = get_word_;			// UI16 Number of assets to export
	th->nl = (ExportAssets_nl*)xmallocz(sizeof(ExportAssets_nl)*th->Count);
	if( !th->nl){
		break;
	}
	{
		u32 i;
		for( i = 0; i < th->Count; i++ ) {
			th->nl[i].Tag = get_word_;
			th->nl[i].szName = create_string(the);
			if( !th->nl[i].szName){
				break;
			}
		}
		if( i != th->Count ) {
			break;
		}
	}
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ImportAssets)
{
	SAFE_XFREE(th->URL);
	if( th->nl ) {
		u32 i;
		for( i = 0; i < th->Count; i++ ) {
			SAFE_XFREE(th->nl[i].szName);
		}
		stx_free(th->nl);
	}
}
swf_release_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(EnableDebugger,swf_tag_init)
{
	th->Password = create_string(the);
	if( !th->Password ) {
		break;
	}
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(EnableDebugger)
{
	SAFE_XFREE(th->Password);
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(DefineVideoStream,swf_tag_init)
{
	th->ichid = get_word_; //  UI16  ID for this video character  
	th->NumFrames = get_word_; //  UI16  Number of VideoFrame tags that makes up this stream  
	th->Width = get_word_; //  UI16  Width in pixels  
	th->Height = get_word_;  // UI16  Height in pixels  
	th->VideoFlagsReserved = get_bits_(4); //  UB[4]  Must be 0  
	th->VideoFlagsDeblocking = get_bits_(3); //  UB[3]  000 = use VIDEOPACKET value 001 = off 
	//010 = Level 1 (Fast deblocking filter) 011 = Level 2 (VP6 only, better deblocking filter) 
	//100 = Level 3 (VP6 only, better deblocking plus fast deringing filter) 
	//101 = Level 4 (VP6 only, better deblocking plus better deringing filter) 110 = Reserved 111 = Reserved  
	th->VideoFlagsSmoothing = get_bits_(1); 
	//  UB[1]  0 = smoothing off (faster) 1 = smoothing on (higher quality)  
	th->CodecID = get_bits_(8); //  UI8  2 = Sorenson H.263 3 = Screen video (SWF 7 and later only) 
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(DefineVideoStream)
{
}
swf_release_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(DefineFontInfo2,swf_tag_init)
{
	th->FontID = get_word_;	// UI16 Font ID this information is for.
	th->FontNameLen = get_bits_(8);	// UI8 Length of font name.
	th->FontName = (u8*)xmallocz(th->FontNameLen+1);
	if( !th->FontName ){
		break;
	}
	{// UI8[FontNameLen] Name of the font.
		u32 i;
		for( i = 0; i < th->FontNameLen; i ++ ) {
			th->FontName[i] = get_bits_(8);
		}
	}
	
	th->FontFlagsReserved = get_bits_(2);	// UB[2] Reserved bit fields.
	th->FontFlagsSmallText = get_bits_(1);	// UB[1] SWF 7 or later:Font is small. Character glyphs
	//are aligned on pixel boundariesfor dynamic and input text.
	th->FontFlagsShiftJIS = get_bits_(1);	// UB[1] Always 0.
	th->FontFlagsANSI = get_bits_(1);	// UB[1] Always 0.
	th->FontFlagsItalic = get_bits_(1);	// UB[1] Font is italic.
	th->FontFlagsBold = get_bits_(1);	// UB[1] Font is bold.
	th->FontFlagsWideCodes = get_bits_(1);	// UB[1] Always 1.
	th->LanguageCode = get_bits_(8);	// Language ID.

	{
		u32 i,nGlyphs;
		nGlyphs = *stx_stack_pop(the->h_dec_stack);
		// UI16[nGlyphs] Glyph to code table in UCS-2,sorted in ascending order.
		th->CodeTable = (u16*)xmallocz(nGlyphs*sizeof(u16));
		if( !th->CodeTable ) {
			break;
		}
		for( i = 0; i < nGlyphs; i ++ ) {
			th->CodeTable[i] = get_word_;
		}
	}

}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(DefineFontInfo2)
{
	SAFE_XFREE(th->FontName);
	SAFE_XFREE(th->CodeTable);
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(EnableDebugger2,swf_tag_init)
{
	get_bits_(16);
	th->Password = create_string(the);
	if( !th->Password){
		break;
	}
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(EnableDebugger2)
{
	SAFE_XFREE(th->Password);
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ScriptLimits,swf_tag_init)
{
	// UI16 Maximum recursion depth
	th->MaxRecursionDepth = get_word_;		
	// UI16 Maximum ActionScript processing time before script stuck dialog box displays
	th->ScriptTimeoutSeconds = get_word_;	
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ScriptLimits)
{
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(SetTabIndex,swf_tag_init)
{
	th->Depth = get_word_;		// UI16 Depth of character
	th->TabIndex = get_word_;	// UI16 Tab order value
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(SetTabIndex)
{
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(PlaceObject3,swf_tag_init)
{
	th->PlaceFlagHasClipActions = get_bits_(1); // UB[1] SWF 5 and later: has clip
	// actions (sprite characters only) Otherwise: always 0

	th->PlaceFlagHasClipDepth = get_bits_(1); // UB[1] Has clip depth
	th->PlaceFlagHasName = get_bits_(1); // UB[1] Has name
	th->PlaceFlagHasRatio = get_bits_(1); // UB[1] Has ratio
	th->PlaceFlagHasColorTransform = get_bits_(1); // UB[1] Has color transform
	th->PlaceFlagHasMatrix = get_bits_(1); // UB[1] Has matrix
	th->PlaceFlagHasCharacter = get_bits_(1); // UB[1] Places a character
	th->PlaceFlagMove = get_bits_(1); // UB[1] Defines a character to be moved

	// Reserved UB[3] Must be 0
	get_bits_(3);

	th->PlaceFlagHasImage = get_bits_(1); // UB[1] Has class name or character ID of bitmap to
	// place. If PlaceFlagHasClassName, use ClassName. If PlaceFlagHasCharacter, use CharacterId
	th->PlaceFlagHasClassName = get_bits_(1); // UB[1] Has class name of object to place
	th->PlaceFlagHasCacheAsBitmap = get_bits_(1); // UB[1] Enables bitmap caching
	th->PlaceFlagHasBlendMode = get_bits_(1); // UB[1] Has blend mode
	th->PlaceFlagHasFilterList = get_bits_(1); // UB[1] Has filter list
	th->Depth = get_word_; // UI16 Depth of character

	if( th->PlaceFlagHasClassName ) {
		// If PlaceFlagHasClassName or (PlaceFlagHasImage and PlaceFlagHasCharacter), 
		//String Name of the class to place Display list tags 41
		th->ClassName = create_string(the);
		if( !th->ClassName ) {
			break;
		}
	}

	if( th->PlaceFlagHasCharacter ) {
		th->CharacterId = get_word_; // If PlaceFlagHasCharacter, UI16 ID of character to place
	}

	if( th->PlaceFlagHasMatrix ) {
		sscreate(MATRIX,the,&th->Matrix); // If PlaceFlagHasMatrix, MATRIX Transform matrix data
	}

	if( th->PlaceFlagHasColorTransform ) {
		sscreate(CXFORMWITHALPHA,the,&th->ColorTransform);		
		// If PlaceFlagHasColorTransform,CXFORMWITHALPHA Color transform data
	}

	if( th->PlaceFlagHasRatio ) {
		th->Ratio = get_word_; // If PlaceFlagHasRatio, UI16
	}

	if( th->PlaceFlagHasName ) {
		th->Name = create_string(the);
		if( !th->Name ) {
			break;
		}					// If PlaceFlagHasName, STRING Name of character
	}

	if( th->PlaceFlagHasClipDepth ) {
		th->ClipDepth = get_word_;// If PlaceFlagHasClipDepth, UI16 Clip depth (see Clipping layers)
	}

	if( th->PlaceFlagHasFilterList ) {
		sscreate(FILTERLIST,the,&th->SurfaceFilterList);	// If PlaceFlagHasFilterList,FILTERLIST
	}

	if( th->PlaceFlagHasCacheAsBitmap ) {
		th->BitmapCache = get_bits_(8);	// If PlaceFlagHasCacheAsBitmap,UI8
		// 0 = Bitmap cache disabled
		// 1-255 = Bitmap cache
		// enabled
	}

	if( th->PlaceFlagHasClipActions ) {
		sscreate(CLIPACTIONS,the,&th->ClipActions);	// If PlaceFlagHasClipActions,
		// CLIPACTIONS
		// SWF 5 and later:
		// Clip Actions Data
	}
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(PlaceObject3)
{
	SAFE_XFREE(th->ClassName);
	SAFE_XFREE(th->Name);

	if( th->PlaceFlagHasMatrix ) {
		sdelete(MATRIX,&th->Matrix); // If PlaceFlagHasMatrix, MATRIX Transform matrix data
	}

	if( th->PlaceFlagHasColorTransform ) {
		sdelete(CXFORMWITHALPHA,&th->ColorTransform);		
		// If PlaceFlagHasColorTransform,CXFORMWITHALPHA Color transform data
	}

	if( th->PlaceFlagHasFilterList ) {
		sdelete(FILTERLIST,&th->SurfaceFilterList);	// If PlaceFlagHasFilterList,FILTERLIST
	}

	if( th->PlaceFlagHasClipActions ) {
		sdelete(CLIPACTIONS,&th->ClipActions);	// If PlaceFlagHasClipActions,
		// CLIPACTIONS
		// SWF 5 and later:
		// Clip Actions Data
	}
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ImportAssets2,swf_tag_init)
{
	th->URL = create_string(the);		// URL where the source SWF file can be found
	if( !th->URL){
		break;
	}
	get_bits_(8);//Reserved UI8 Must be 1
	get_bits_(8);//Reserved UI8 Must be 0
	th->Count = get_word_;		// UI16 Number of assets to import
	th->nl = (ExportAssets_nl*)xmallocz(sizeof(ExportAssets_nl)*th->Count);
	if( !th->nl ) {
		break;
	}
	{
		u32 i;
		for( i = 0; i < th->Count; i ++ ) {
			th->nl[i].Tag = get_bits_(8);
			th->nl[i].szName = create_string(the);
			if( !th->nl[i].szName ){
				break;
			}
		}
		if( i != th->Count) {
			break;
		}
	}
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ImportAssets2)
{
	SAFE_XFREE(th->URL);
	if( th->nl ) {
		u32 i;
		for( i = 0; i < th->Count; i ++ ) {
			stx_free(th->nl[i].szName);
		}
		stx_free(th->nl);
	}
}
swf_release_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(DefineFontAlignZones,swf_tag_init)
{
	th->FontID = get_word_;			// UI16 ID of font to use, specified by DefineFont3.
	th->CSMTableHint = get_bits_(2);	
	// UB[2] Font thickness hint. Refers to the thickness of the typical stroke used in the font.
	//0 = thin
	//1 = medium
	//2 = thick
	//Flash Player maintains a selection of CSM tables for many fonts. However, if the
	//font is not found in Flash 	Player's internal table, this hint is used to choose an appropriate table.
	get_bits_(6);	//Reserved UB[6] Must be 0.

	{
		// ZONERECORD[GlyphCount] Alignment zone information for each glyph.
		u32 i;

		th->GlyphCount = *stx_stack_pop(the->h_dec_stack);
		if( th->GlyphCount ) {
			th->ZoneTable = (ZONERECORD*)xmallocz(sizeof(ZONERECORD)*th->GlyphCount);
			if( !th->ZoneTable ) {
				break;
			}
			for( i = 0; i < th->GlyphCount; i ++ ) {
				sscreate(ZONERECORD,the,&th->ZoneTable[i]);
			}
			if( i != th->GlyphCount ) {
				break;
			}
		}
	}

}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(DefineFontAlignZones)
{
	if( th->GlyphCount ) {
		u32 i;
		for( i = 0; i < th->GlyphCount; i ++ ) {
			sdelete(ZONERECORD,&th->ZoneTable);
		}
		stx_free(th->ZoneTable);
	}
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(ZONERECORD)
{
	th->NumZoneData = get_bits_(8);	// UI8 Number of ZoneData entries.	Always 2.
	th->ZoneData = (ZONEDATA*)xmallocz(sizeof(ZONEDATA)*th->NumZoneData);
	if( !th->ZoneData ) {// ZONEDATA[NumZoneData] Compressed alignment zone	information.
		break;
	}
	{
		u32 i;
		for( i = 0; i < th->NumZoneData; i ++ ) {
			sscreate(ZONEDATA,the,&th->ZoneData[i]);
		}
		if( i != th->NumZoneData ) {
			break;
		}
	}
	
	get_bits_(6);//Reserved UB[6] Must be 0.
	th->ZoneMaskY = get_bits_(1);	// UB[1] Set if there are Y alignment	zones.
	th->ZoneMaskX = get_bits_(1);	// UB[1] Set if there are X alignment	zones.
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ZONERECORD)
{
	if( th->ZoneData ) {
		u32 i;
		for( i = 0; i < th->NumZoneData; i ++ ) {
			sdelete(ZONEDATA,&th->ZoneData);
		}
		stx_free(th->ZoneData);
	}
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(ZONEDATA)
{
	th->AlignmentCoordinate = get_word_;	// FLOAT16 X (left) or Y (baseline) coordinate of the alignment zone.
	th->Range = get_word_;	// FLOAT16 Width or height of the alignment zone.
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ZONEDATA)
{
}
swf_release_end()




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(CSMTextSettings,swf_tag_init)
{
	u32 i;

	th->TextID = get_word_;	
	// UI16 ID for the DefineText,	DefineText2, or	DefineEditText to which this	tag applies.
	th->UseFlashType = get_bits_(2);	
	// UB[2] 0 = use normal renderer.	1 = use advanced text	rendering engine.
	th->GridFit = get_bits_(3);	
	// UB[3] 0 = Do not use grid fitting.	AlignmentZones and LCD	sub-pixel information will not	be used.
	//1 = Pixel grid fit. Only supported for left-aligned	dynamic text. This setting
	//provides the ultimate in advanced anti-aliased text	readability, with crisp letters	aligned to pixels.
	//2 = Sub-pixel grid fit. Align	letters to the 1/3 pixel used	by LCD monitors. Can also
	//improve quality for CRT	output.

	get_bits_(3); //Reserved UB[3] Must be 0.
	i = get_dword_;
	th->Thickness = *(f32*)&i;	// F32 The thickness attribute for the associated text field. Set	to 0.0 to use the default
	//(anti-aliasing table) value.

	i = get_dword_;	// F32 The sharpness attribute for the associated text field. Set
	th->Sharpness =  *(f32*)&i;
	//to 0.0 to use the default(anti-aliasing table) value.

	//Reserved UI8 Must be 0.
	get_bits_(8);
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(CSMTextSettings)
{
}
swf_release_end()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(DefineFont3,swf_tag_init)
{

	th->ichid = get_word_;					// UI16 ID for this font character.
	th->FontFlagsHasLayout = get_bits_(1);		// UB[1] Has font metrics/layout	information.
	th->FontFlagsShiftJIS = get_bits_(1);		// UB[1] ShiftJIS encoding.
	th->FontFlagsSmallText = get_bits_(1);		// UB[1] SWF 7 or later:	Font is small. Character glyphs
	//are aligned on pixel boundaries	for dynamic and input text.

	th->FontFlagsANSI = get_bits_(1);			// UB[1] ANSI encoding.
	th->FontFlagsWideOffsets = get_bits_(1);	// UB[1] If 1, uses 32 bit offsets.
	th->FontFlagsWideCodes = get_bits_(1);		// UB[1] Must be 1.
	th->FontFlagsItalic = get_bits_(1);		// UB[1] Italic Font.

	th->FontFlagsBold = get_bits_(1);			// UB[1] Bold Font. 	
	th->LanguageCode = get_bits_(8);	//  SWF 5 or earlier: always 0 SWF 6 or later: language code

	th->FontNameLen = get_bits_(8);			// UI8 Length of name.
	th->FontName = (u8*)xmallocz(th->FontNameLen+1);				
	// UI8[FontNameLen] Name of font (see DefineFontInfo).
	{
		u32 i;
		for( i = 0; i < th->FontNameLen; i ++ ) {
			th->FontName[i] = get_bits_(8);
		}
	}

	th->NumGlyphs = get_word_;				// UI16 Count of glyphs in font. May be zero for device fonts.
	if( th->NumGlyphs ) {
		if( th->FontFlagsWideOffsets ) {
			th->OffsetTable.d32 = (u32*)xmallocz(sizeof(u32*)*th->NumGlyphs);
			if( !th->OffsetTable.d32) {
				break;
			}
			{
				u32 i;
				for( i = 0; i < th->NumGlyphs; i ++ ) {
					th->OffsetTable.d32[i] = get_dword_;
				}
			}
		}
		else{
			th->OffsetTable.d16 = (u16*)xmallocz(sizeof(u16*)*th->NumGlyphs);
			if( !th->OffsetTable.d16) {
				break;
			}
			{
				u32 i;
				for( i = 0; i < th->NumGlyphs; i ++ ) {
					th->OffsetTable.d16[i] = get_word_;
				}
			}
		}
	}// If FontFlagsWideOffsets, UI32[NumGlyphs] Otherwise UI16[NumGlyphs] Same as in DefineFont.

	// If FontFlagsWideOffsets, UI32 Otherwise UI16
	//Byte count from start OF OffsetTable to start of CodeTable.
	if( th->FontFlagsWideOffsets ) {
		th->CodeTableOffset = get_dword_;
	}
	else{
		th->CodeTableOffset = get_word_;
	}

	if( th->NumGlyphs ) {// SHAPE[NumGlyphs] Same as in DefineFont.
		th->GlyphShapeTable = (SHAPE*)xmallocz(sizeof(SHAPE)*th->NumGlyphs);
		if( !th->GlyphShapeTable) {
			break;
		}
		{
			u32 i;
			for( i = 0; i < th->NumGlyphs; i ++ ) {
				sscreate(SHAPE,the,&th->GlyphShapeTable[i],3);
			}
			if( i != th->NumGlyphs ) {
				break;
			}
		}

		th->CodeTable = (u16*)xmallocz(th->NumGlyphs*sizeof(u16));
		if( !th->CodeTable){
			break;
		}
		{// UI16[NumGlyphs] Sorted in ascending order.Always UCS-2 in SWF 6 or later.
			u32 i;
			for( i = 0; i < th->NumGlyphs; i ++ ) {
				th->CodeTable[i] = get_word_;
			}
		}
	}

	if( th->FontFlagsHasLayout ) {
		th->FontAscent = get_word_;			// If FontFlagsHasLayout, SI16 Font ascender height.
		th->FontDescent = get_word_;		// If FontFlagsHasLayout, SI16 Font descender height.
		th->FontLeading = get_word_;		// If FontFlagsHasLayout, SI16 Font leading height (see following).
		if( th->NumGlyphs ) {
			th->FontAdvanceTable = (s16*)xmallocz(sizeof(s16)*th->NumGlyphs);
			{// If FontFlagsHasLayout, SI16[NumGlyphs]
			//Advance value to be used for each glyph in dynamic glyph text.
				u32 i;
				for( i = 0; i < th->NumGlyphs; i ++ ) {
					th->FontAdvanceTable[i] = get_word_;
				}
			}
		// If FontFlagsHasLayout, RECT[NumGlyphs]
		//Not used in Flash Player through version 7 (but must be present).
			th->FontBoundsTable = (swf_rect*)xmallocz(sizeof(swf_rect)*th->NumGlyphs);
			{// If FontFlagsHasLayout, SI16[NumGlyphs]
				u32 i;
				for( i = 0; i < th->NumGlyphs; i ++ ) {
					sscreate(swf_rect,the,&th->FontBoundsTable[i]);
				}
				if( i != th->NumGlyphs ) {
					break;
				}
			}
		}// if( th->NumGlyphs ) {
	} // if( th->FontFlagsHasLayout ) {

	th->KerningCount = get_word_;			// If FontFlagsHasLayout, UI16 Not used in Flash Player
	//through version 7 (always set to 0 to save space).

	if( th->FontFlagsHasLayout && th->KerningCount ) {
		th->FontKerningTable = (KERNINGRECORD*)xmallocz(sizeof(KERNINGRECORD)*th->KerningCount);
		if( !th->FontKerningTable) {
			break;
		}
		{// If FontFlagsHasLayout, KERNINGRECORD[KerningCount]
			u32 i;
			for( i = 0; i < th->KerningCount; i ++ ) {
				sscreate(KERNINGRECORD,the,&th->FontKerningTable[i],th->FontFlagsWideCodes);
			}
			if( i != th->KerningCount){
				break;
			}
		}
	}
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(DefineFont3)
{
	SAFE_XFREE(th->FontName);
	SAFE_XFREE(th->OffsetTable.d16);

	if( th->GlyphShapeTable) {
		u32 i;
		for( i = 0; i < th->NumGlyphs; i ++ ) {
			sdelete(SHAPE,&th->GlyphShapeTable[i]);
		}
		stx_free(th->GlyphShapeTable);
	}

	SAFE_XFREE(th->CodeTable);
	SAFE_XFREE(th->FontAdvanceTable);
	SAFE_XFREE(th->FontBoundsTable);

	if( th->FontKerningTable) {// If FontFlagsHasLayout, KERNINGRECORD[KerningCount]
		u32 i;
		for( i = 0; i < th->KerningCount; i ++ ) {
			sdelete(KERNINGRECORD,&th->FontKerningTable[i]);
		}
		stx_free(th->FontKerningTable);
	}
}
swf_release_end()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(SymbolClass,swf_tag_init)
{
	th->NumSymbols = get_word_;		// UI16 Number of symbols that will be associated by this tag.
	th->nl = (ExportAssets_nl*)xmallocz(sizeof(ExportAssets_nl)*th->NumSymbols);
	if( !th->nl ) {
		break;
	}
	{
		u32 i;
		for( i = 0; i < th->NumSymbols; i ++ ) {
			th->nl[i].Tag = get_word_;
			th->nl[i].szName = create_string(the);
			if( !th->nl[i].szName ) {
				break;
			}
		}
		if( i != th->NumSymbols ) {
			break;
		}
	}

}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(SymbolClass)
{
	if( th->nl ) {
		u32 i;
		for( i = 0; i < th->NumSymbols; i ++ ) {
			SAFE_XFREE( th->nl[i].szName );
		}
		stx_free(th->nl);
	}
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(Metadata,swf_tag_init)
{
	th->XML = create_string(the);
	if( !th->XML ) {
		break;
	}
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(Metadata)
{
	SAFE_XFREE(th->XML);
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(DefineScalingGrid,swf_tag_init)
{
	//UI16 ID of sprite or button character upon which the  scaling grid will be applied.
	th->CharacterId = get_word_;	
	sscreate(swf_rect,the,&th->Splitter);		//RECT Center region of 9-slice 	grid
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(DefineScalingGrid)
{
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(DoABC,swf_tag_init)
{
	th->Flags = get_dword_;// UI32 A 32-bit flags value, which may contain the following bits set:
	//kDoAbcLazyInitializeFlag = 1:Indicates that the ABC block should not be executed immediately, but only parsed. 
	//	a later find def may cause its scripts to execute.
	th->name = create_string(the); //  The name assigned to the byte code.
	if( !th->name) {
		break;
	}
	{
		u32 i,len;
		len = th->ilen - 5 - strlen(th->name);
		if( len ) {
			th->ABCData = (u8*)xmallocz(len);
			if( !th->ABCData ) {
				break;
			}
			for( i = 0; i < len; i ++ ) {
				th->ABCData[i] = get_bits_(8);
			}
		}
	}
	// BYTE[] A block of .abc byte code to be parsed by the ActionScript 3.0virtual machine, up to the end of the tag.

}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(DoABC)
{
	SAFE_XFREE(th->name);
	SAFE_XFREE(th->ABCData);
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(DefineShape4,swf_tag_init)
{
	th->ShapeId = get_word_; // UI16 ID for this character.
	sscreate(swf_rect,the,&th->ShapeBounds);//  RECT Bounds of the shape.
	sscreate(swf_rect,the,&th->EdgeBounds);//  RECT Bounds of the shape, excluding strokes.
	get_bits_(5);// Reserved UB[5] Must be 0.
	th->UsesFillWindingRule = get_bits_(1);//  UB[1] If 1, use fill winding rule. Minimum file format version is SWF 10
	th->UsesNonScalingStrokes = get_bits_(1);//  UB[1] If 1, the shape contains at least one non-scaling stroke.
	th->UsesScalingStrokes = get_bits_(1);//  UB[1] If 1, the shape contains at least one scaling stroke.
	sscreate(SHAPEWITHSTYLE,the,&th->Shapes,4);//  SHAPEWITHSTYLE Shape information.
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(DefineShape4)
{
	sdelete(SHAPEWITHSTYLE,&th->Shapes);
}
swf_release_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(DefineMorphShape2,swf_tag_init)
{
	th->ichid = get_word_;			// UI16 ID for this character
	sscreate(swf_rect,the,&th->StartBounds);			// RECT Bounds of the start shape
	sscreate(swf_rect,the,&th->EndBounds);				// RECT Bounds of the end shape
	sscreate(swf_rect,the,&th->StartEdgeBounds);		// RECT Bounds of the start shape,	excluding strokes
	sscreate(swf_rect,the,&th->EndEdgeBounds);			// RECT Bounds of the end shape,	excluding strokes
	get_bits_(6);//Reserved UB[6] Must be 0
	th->UsesNonScalingStrokes = get_bits_(1);	// UB[1] If 1, the shape contains at least	one non-scaling stroke.
	th->UsesScalingStrokes = get_bits_(1);		// UB[1] If 1, the shape contains at least	one scaling stroke.
	th->Offset = get_dword_;					// UI32 Indicates offset to EndEdges

	sscreate(MORPHFILLSTYLEARRAY,the,&th->MorphFillStyles);	//  Fill style information is stored in
	// 	the same manner as for a standard shape; however, eachfill consists of interleaved
	// 	information based on a singlestyle type to accommodate	morphing.
	sscreate(MORPHLINESTYLEARRAY,the,&th->MorphLineStyles,2);	//  Line style information is stored
	// 	in the same manner as for a	standard shape; however, each
	// 	line consists of interleaved information based on a single
	// 	style type to accommodate morphing.

	sscreate(SHAPE,the,&th->StartEdges,2); // Contains the set of edges and
	//the style bits that indicate style		changes (for example, MoveTo,
	//FillStyle, and LineStyle).		Number of edges must equal		the number of edges in		EndEdges.

	sscreate(SHAPE,the,&th->EndEdges,2); //Contains only the set of edges,	with no style information.	Number of edges must equal
	// the number of edges in	StartEdges.
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(DefineMorphShape2)
{
	sdelete(MORPHFILLSTYLEARRAY,&th->MorphFillStyles);
	sdelete(MORPHLINESTYLEARRAY,&th->MorphLineStyles);
	sdelete(SHAPE,&th->StartEdges);
	sdelete(SHAPE,&th->EndEdges); 
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(DefineSceneAndFrameLabelData,swf_tag_init)
{
	u32 i;

	th->SceneCount = get_encoded_u32(the);		// EncodedU32 Number of scenes

	th->sl = (anchor32*)xmallocz(sizeof(anchor32)*th->SceneCount);
	if( !th->sl ) {
		break;
	}

	for( i = 0; i < th->SceneCount; i ++ ) {
		th->sl[i].Offset = get_dword_;
		th->sl[i].szName = create_string(the);
		if( !th->sl[i].szName ) {
			break;
		}
	}
	if( i != th->SceneCount) {
		break;
	}

	th->FrameLabelCount = get_dword_; 

	th->fl = (anchor32*)xmallocz(sizeof(anchor32)*th->FrameLabelCount);
	if( !th->fl ) {
		break;
	}

	for( i = 0; i < th->FrameLabelCount; i ++ ) {
		th->fl[i].Offset = get_dword_;
		th->fl[i].szName = create_string(the);
		if( !th->fl[i].szName ) {
			break;
		}
	}
	if( i != th->FrameLabelCount) {
		break;
	}
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(DefineSceneAndFrameLabelData)
{
	if( th->sl ) {
		u32 i;
		for( i = 0; i < th->SceneCount; i ++ ) {
			SAFE_XFREE( th->sl[i].szName );
		}
		stx_free(th->sl);
	}
	if( th->fl ) {
		u32 i;
		for( i = 0; i < th->FrameLabelCount; i ++ ) {
			SAFE_XFREE( th->fl[i].szName );
		}
		stx_free(th->fl);
	}

}
swf_release_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(DefineBinaryData,swf_tag_init)
{
	th->ichid = get_word_; //  UI16  16-bit character ID  
	//Reserved  U32  Reserved space; must be 0  Data  BINARY  A blob of binary data, up to the end of the tag  
	get_dword_;
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(DefineBinaryData)
{
}
swf_release_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(DefineFontName,swf_tag_init)
{
	th->FontID = get_word_;	//  UI16 ID for this font to which this	refers
	th->FontName = create_string(the);	//  Name of the font. For fonts	starting as Type 1, this is the
	//PostScript FullName. For fonts	starting in sfnt formats such asTrueType and OpenType, this
	//is name ID 4, platform ID 1,language ID 0 (Full name, MacOS, English).
	if( !th->FontName) {
		break;
	}
	th->FontCopyright = create_string(the);	// Arbitrary string of copyright	information
	if( !th->FontCopyright) {
		break;
	}
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(DefineFontName)
{
	SAFE_XFREE(th->FontName);
	SAFE_XFREE(th->FontCopyright);
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(StartSound2,swf_tag_init)
{
	th->SoundClassName = create_string(the);	// Name of the sound class to play.
	sscreate(SOUNDINFO,the,&th->SoundInfo);	// Sound style information.
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(StartSound2)
{
	SAFE_XFREE(th->SoundClassName);
	sdelete(SOUNDINFO,&th->SoundInfo);
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(DefineBitsJPEG4,swf_tag_init)
{
	s32 i;
	th->ichid = get_word_;		// 	 UI16 ID for this character.
	th->AlphaDataOffset = get_dword_;	// 	 UI32 Count of bytes in ImageData.
	th->DeblockParam = get_word_;		// 	 UI16 Parameter to be fed into the deblocking filter. The parameter
	// 	describes a relative strength of the deblocking filter from 0-100% expressed in a
	// 	normalized 8.8 fixed point format.
	th->ImageData = (u8*)xmallocz(th->AlphaDataOffset);			
	// 	 UI8[data size] Compressed image data in either JPEG, PNG, or GIF89a format.
	if( !th->ImageData ) {
		break;
	}
	for( i = 0; i < (s32)th->AlphaDataOffset; i ++ ) {
		th->ImageData[i] = get_bits_(8);
	}
	{
		s32 ilen;
		ilen = th->ilen - 8 - th->AlphaDataOffset;
		if( ilen > 0 ) {
			// 	 UI8[alpha data size] ZLIB compressed array OF alpha data. Only supported
			th->BitmapAlphaData = (u8*) xmallocz(ilen) ;
			if( !th->BitmapAlphaData ) {
				break;
			}
			for( i = 0; i < ilen; i ++ ) {
				th->BitmapAlphaData[i] = get_bits_(8);
			}
		}
	}

}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(DefineBitsJPEG4)
{
	SAFE_XFREE(th->ImageData);
	SAFE_XFREE(th->BitmapAlphaData);
}
swf_release_end()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(DefineFont4,swf_tag_init)
{
	th->ichid = get_word_;	// UI16 ID for this font character.
	th->FontFlagsReserved = get_bits_(5);	// UB[5] Reserved bit fields.
	th->FontFlagsHasFontData = get_bits_(1);	// UB[1] Font is embedded. Font tag includes	SFNT font data block.
	th->FontFlagsItalic = get_bits_(1);	// UB[1] Italic font
	th->FontFlagsBold = get_bits_(1);	// UB[1] Bold font
	th->FontName = create_string(the);	// Name of the font.
	if(!th->FontName){
		break;
	}
	if( th->FontFlagsHasFontData) {
		sscreate(FONTDATA,the,&th->FontData,th->ilen - 4 - strlen(th->FontName));	
		// FONTDATA[0 or 1] When present, this is an OpenType
	}
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(DefineFont4)
{
	SAFE_XFREE(th->FontName);
	if(th->FontFlagsHasFontData) {
		sdelete(FONTDATA,&th->FontData);
	}
}
swf_release_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(FONTDATA,s32 ilen)
{
	s32 i;
	for( i = 0; i < ilen; i ++ ) {
		get_bits_(8);
	}
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(FONTDATA)
{
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionNextFrame,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionNextFrame)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionNextFrame)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionPreviousFrame,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionPreviousFrame)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionPreviousFrame)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionPlay,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionPlay)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionPlay)
{
}
swf_doaction_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionStop,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionStop)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionStop)
{
}
swf_doaction_end()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionToggleQuality,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionToggleQuality)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionToggleQuality)
{
}
swf_doaction_end()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionStopSounds,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionStopSounds)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionStopSounds)
{
}
swf_doaction_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionAdd,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionAdd)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionAdd)
{
	f32	a,b;
	a = *(f32*)stx_stack_pop(the->h_act_stack);
	b = *(f32*)stx_stack_pop(the->h_act_stack);
	b += a;
	stx_stack_push(the->h_act_stack,*(u32*)&b);
}
swf_doaction_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionSubtract,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionSubtract)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionSubtract)
{
	f32	a,b;
	a = *(f32*)stx_stack_pop(the->h_act_stack);
	b = *(f32*)stx_stack_pop(the->h_act_stack);
	b -= a;
	stx_stack_push(the->h_act_stack,*(u32*)&b);
}
swf_doaction_end()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionMultiply,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionMultiply)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionMultiply)
{
	f32	a,b;
	a = *(f32*)stx_stack_pop(the->h_act_stack);
	b = *(f32*)stx_stack_pop(the->h_act_stack);
	b *= a;
	stx_stack_push(the->h_act_stack,*(u32*)&b);
}
swf_doaction_end()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionDivide,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionDivide)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionDivide)
{
	f32		a,b;
	a = *(f32*)stx_stack_pop(the->h_act_stack);
	b = *(f32*)stx_stack_pop(the->h_act_stack);

	if( a != 0 ) {
		b /= a;
		stx_stack_push(the->h_act_stack,*(u32*)&b);
	}
	else{
		stx_stack_push(the->h_act_stack,(size_t)-1);
	}
}
swf_doaction_end()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionEquals,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionEquals)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionEquals)
{
	f32		a,b;
	b32		i;
	a = *(f32*)stx_stack_pop(the->h_act_stack);
	b = *(f32*)stx_stack_pop(the->h_act_stack);
	i = a == b;
	stx_stack_push(the->h_act_stack,i);
}
swf_doaction_end()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionLess,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionLess)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionLess)
{
	f32	a,b;
	b32	i;
	a = *(f32*)stx_stack_pop(the->h_act_stack);
	b = *(f32*)stx_stack_pop(the->h_act_stack);
	i = b < a;
	stx_stack_push(the->h_act_stack,i);
}
swf_doaction_end()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionAnd,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionAnd)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionAnd)
{
	f32	a,b;
	b32	i;
	a = *(f32*)stx_stack_pop(the->h_act_stack);
	b = *(f32*)stx_stack_pop(the->h_act_stack);
	i = ( a != 0 ) && ( b != 0 );
	stx_stack_push(the->h_act_stack,i);
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionOr,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionOr)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionOr)
{
	f32	a,b;
	b32	i;
	a = *(f32*)stx_stack_pop(the->h_act_stack);
	b = *(f32*)stx_stack_pop(the->h_act_stack);
	i = ( a != 0 ) || ( b != 0 );
	stx_stack_push(the->h_act_stack,i);
}
swf_doaction_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionNot,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionNot)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionNot)
{
	f32 i;
	i = *(f32*)stx_stack_pop(the->h_act_stack);
	th->Result = i == 0;
	stx_stack_push(the->h_act_stack,th->Result);
}
swf_doaction_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionStringEquals,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionStringEquals)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionStringEquals)
{
	char	*a,*b;
	b32	i;
	a = *(char**)stx_stack_pop(the->h_act_stack);
	b = *(char**)stx_stack_pop(the->h_act_stack);
	i = !strcmp(a,b);
	stx_stack_push(the->h_act_stack,i);
}
swf_doaction_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionStringLength,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionStringLength)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionStringLength)
{
	char	*a;
	u32		i;
	a = *(char**)stx_stack_pop(the->h_act_stack);
	i = strlen(a);
	stx_stack_push(the->h_act_stack,i);
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionStringExtract,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionStringExtract)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionStringExtract)
{	
	u32		count,index;
	char*	sz_src;
	char*	sz_dst;

	count = (u32)*stx_stack_pop(the->h_act_stack);
	index = (u32)*stx_stack_pop(the->h_act_stack);
	sz_src = *(char**)stx_stack_pop(the->h_act_stack);
	sz_dst = (char*)xmallocz(count + 1);
	if( !sz_dst ) {
		break;
	}
	memcpy(sz_dst,sz_src+index,count);
	stx_stack_push(the->h_act_stack,(size_t)sz_dst);
}
swf_doaction_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionPop,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionPop)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionPop)
{
	stx_stack_pop(the->h_act_stack);
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionToInteger,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionToInteger)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionToInteger)
{
}
swf_doaction_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionGetVariable,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionGetVariable)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionGetVariable)
{
}
swf_doaction_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionSetVariable,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionSetVariable)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionSetVariable)
{
}
swf_doaction_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionSetTarget2,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionSetTarget2)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionSetTarget2)
{
}
swf_doaction_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionStringAdd,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionStringAdd)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionStringAdd)
{
	u32		la,lb;
	char	*sza,*szb;
	char	*sz_dst;

	sza = *(char**)stx_stack_pop(the->h_act_stack);
	la = strlen(sza);
	szb = *(char**)stx_stack_pop(the->h_act_stack);
	lb = strlen(szb);
	sz_dst = (char*)xmallocz(la + lb + 1);
	if( !sz_dst ) {
		break;
	}
	memcpy(sz_dst,szb,lb);
	memcpy(sz_dst + lb,sza,la);
	stx_stack_push(the->h_act_stack,(size_t)sz_dst);
}
swf_doaction_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionGetProperty,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionGetProperty)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionGetProperty)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionSetProperty,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionSetProperty)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionSetProperty)
{
}
swf_doaction_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionCloneSprite,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionCloneSprite)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionCloneSprite)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionRemoveSprite,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionRemoveSprite)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionRemoveSprite)
{
}
swf_doaction_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionTrace,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionTrace)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionTrace)
{
}
swf_doaction_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionStartDrag,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionStartDrag)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionStartDrag)
{
}
swf_doaction_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionEndDrag,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionEndDrag)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionEndDrag)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionStringLess,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionStringLess)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionStringLess)
{
	char	*a,*b;
	b32	i;
	a = *(char**)stx_stack_pop(the->h_act_stack);
	b = *(char**)stx_stack_pop(the->h_act_stack);
	i = strcmp(a,b);
	stx_stack_push(the->h_act_stack,i);
}
swf_doaction_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionThrow,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionThrow)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionThrow)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionCastOp,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionCastOp)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionCastOp)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionImplementsOp,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionImplementsOp)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionImplementsOp)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionRandomNumber,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionRandomNumber)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionRandomNumber)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionMBStringLength,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionMBStringLength)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionMBStringLength)
{
}
swf_doaction_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionTargetPath,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionTargetPath)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionTargetPath)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionEnumerate,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionEnumerate)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionEnumerate)
{
}
swf_doaction_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionAdd2,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionAdd2)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionAdd2)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionLess2,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionLess2)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionLess2)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionEquals2,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionEquals2)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionEquals2)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionToNumber,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionToNumber)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionToNumber)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionCharToAscii,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionCharToAscii)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionCharToAscii)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionAsciiToChar,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionAsciiToChar)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionAsciiToChar)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionGetTime,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionGetTime)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionGetTime)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionMBStringExtract,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionMBStringExtract)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionMBStringExtract)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionMBCharToAscii,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionMBCharToAscii)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionMBCharToAscii)
{
}
swf_doaction_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionDelete,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionDelete)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionDelete)
{
}
swf_doaction_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionDelete2,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionDelete2)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionDelete2)
{
}
swf_doaction_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionDefineLocal,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionDefineLocal)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionDefineLocal)
{
}
swf_doaction_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionCallFunction,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionCallFunction)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionCallFunction)
{
}
swf_doaction_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionReturn,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionReturn)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionReturn)
{
}
swf_doaction_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionModulo,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionModulo)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionModulo)
{
}
swf_doaction_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionNewObject,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionNewObject)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionNewObject)
{
}
swf_doaction_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionDefineLocal2,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionDefineLocal2)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionDefineLocal2)
{
}
swf_doaction_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionInitArray,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionInitArray)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionInitArray)
{
}
swf_doaction_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionInitObject,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionInitObject)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionInitObject)
{
}
swf_doaction_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionTypeOf,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionTypeOf)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionTypeOf)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionToString,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionToString)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionToString)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionPushDuplicate,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionPushDuplicate)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionPushDuplicate)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionGetMember,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionGetMember)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionGetMember)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionStackSwap,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionStackSwap)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionStackSwap)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionSetMember,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionSetMember)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionSetMember)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionIncrement,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionIncrement)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionIncrement)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionDecrement,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionDecrement)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionDecrement)
{
}
swf_doaction_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionCallMethod,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionCallMethod)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionCallMethod)
{
}
swf_doaction_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionNewMethod,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionNewMethod)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionNewMethod)
{
}
swf_doaction_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionInstanceOf,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionInstanceOf)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionInstanceOf)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionEnumerate2,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionEnumerate2)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionEnumerate2)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionBitAnd,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionBitAnd)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionBitAnd)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionBitOr,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionBitOr)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionBitOr)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionBitXor,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionBitXor)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionBitXor)
{
}
swf_doaction_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionBitLShift,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionBitLShift)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionBitLShift)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionBitRShift,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionBitRShift)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionBitRShift)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionBitURShift,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionBitURShift)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionBitURShift)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionStrictEquals,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionStrictEquals)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionStrictEquals)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionGreater,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionGreater)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionGreater)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionStringGreater,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionStringGreater)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionStringGreater)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionExtends,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionExtends)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionExtends)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionGotoFrame,swf_action_init)
{
	th->Frame = get_word_;
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionGotoFrame)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionGotoFrame)
{
	// ??
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionGetURL,swf_action_init)
{
	th->UrlString = create_string(the);				//	Target URL string
	if( !th->UrlString ) {
		break;
	}
	th->TargetString = create_string(the);			//	Target string
	if( !th->TargetString ) {
		break;
	}
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionGetURL)
{
	SAFE_XFREE(th->UrlString);
	SAFE_XFREE(th->TargetString);
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
ActionGetURL instructs Flash Player to get the URL that UrlString specifies. The URL can
be of any type, including an HTML file, an image or another SWF file. If the file is playing in
a browser, the URL is displayed in the frame that TargetString specifies. The "_level0" and
"_level1" special target names are used to load another SWF file into levels 0 and 1
respectively.
***************************************************************************/
swf_doaction_begin(ActionGetURL)
{
	// change task status to doaction;

}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionStoreRegister,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionStoreRegister)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionStoreRegister)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionConstantPool,swf_action_init)
{
	th->Count = get_word_;			// UI16 Number of constants to follow
	if( th->Count) {// STRING[Count] String constants
		u32 i;
		th->ConstantPool = (STRING*)xmallocz(sizeof(STRING)*th->Count);
		if( !th->ConstantPool ) {
			break;
		}
		for( i = 0; i < th->Count; i ++ ) {
			th->ConstantPool[i] = create_string(the);
			if( !th->ConstantPool[i]) {
				break;
			}
		}
		if( i != th->Count ) {
			break;
		}
	}
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionConstantPool)
{
	if( th->ConstantPool ) {
		u32 i;
		for( i = 0; i < th->Count; i ++ ) {
			SAFE_XFREE(th->ConstantPool[i]);
		}
		stx_free(th->ConstantPool);
	}
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionConstantPool)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionWaitForFrame,swf_action_init)
{
	th->Frame = get_word_;		//UI16 Frame to wait for
	th->SkipCount = get_bits_(8);	//UI8 Number of actions to skip if frame is not loaded
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionWaitForFrame)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionWaitForFrame)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionSetTarget,swf_action_init)
{
	th->TargetName = create_string(the);
	if( !th->TargetName){
		break;
	}
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionSetTarget)
{
	SAFE_XFREE(th->TargetName);
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionSetTarget)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionGoToLabel,swf_action_init)
{
	th->Label = create_string(the);
	if( !th->Label){
		break;
	}
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionGoToLabel)
{
	SAFE_XFREE(th->Label);
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionGoToLabel)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionWaitForFrame2,swf_action_init)
{
	th->SkipCount = get_bits_(8); // UI8 The number of actions to skip
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionWaitForFrame2)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionWaitForFrame2)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionDefineFunction2,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionDefineFunction2)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionDefineFunction2)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionTry,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionTry)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionTry)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionWith,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionWith)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionWith)
{
}
swf_doaction_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionPush,swf_action_init)
{
	STX_RESULT i_err;

	th->Type = get_bits_(8); 

	i_err = STX_OK;

	switch(th->Type){
		case 0:
			th->value.str_v0 = create_string(the);
			if( !th->value.str_v0 ) {
				i_err = STX_FAIL;
			}
			break;

		case 1:
			{
				u32 i = get_dword_;
				th->value.f32_v1 = *(f32*)&i;
				break;
			}

		case 2:
			th->value.null_v2 = 0;
			break;

		case 3:
			th->value.undef_v3 = 0;
			break;

		case 4:
			th->value.reg_v4 = get_bits_(8);
			break;

		case 5:
			th->value.b32_v5 = get_bits_(1);
			break;

		case 6:
			{
				u64 l = get_dword_;
				u64 h = get_dword_;
				u64 i = (h<<32) | l;
				th->value.f64_v6 = *(f64*)&i;
				break;
			}

		case 7:
			th->value.s32_v7 = get_dword_;
			break;

		case 8:
			th->value.u8_v8 = get_bits_(8);
			break;

		case 9:
			th->value.u16_v9 = get_word_;
			break;

	}

	if( STX_OK != i_err ) {
		break;
	}

}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionPush)
{
	if( th->Type == 0 ) {
		SAFE_XFREE(th->value.str_v0);
	}
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionPush)
{
#ifdef STX64
	stx_stack_push(the->h_act_stack,(size_t)th->value.str_v0);
#else
	if( 6 == th->Type){
		u64 i = *(u64*)&th->value.f64_v6;
		stx_stack_push(the->h_act_stack,(size_t)i);
		stx_stack_push(the->h_act_stack,(size_t)(i>>32));
	}
	else{
		stx_stack_push(the->h_act_stack,(size_t)th->value.str_v0);
	}
#endif
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionJump,swf_action_init)
{
	th->BranchOffset = get_word_; // SI16 Offset
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionJump)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionJump)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionGetURL2,swf_action_init)
{
	th->SendVarsMethod = get_bits_(2);			// UB[2] 0 = None	1 = GET 	2 = POST
	get_bits_(4);								// u8 Reserved;				// UB[4] Always 0
	th->LoadTargetFlag = get_bits_(1);			// UB[1] 0 = Target is a browser window 1 = Target is a path to a sprite
	th->LoadVariablesFlag = get_bits_(1);		// UB[1] 0 = No variables to load  1 = Load variables
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionGetURL2)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionGetURL2)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionDefineFunction,swf_action_init)
{
	u32 i;
	th->FunctionName = create_string(the);	//  Function name, empty if anonymous
	if( !th->FunctionName ) {
		break;
	}
	th->NumParams = get_word_;		// UI16 # of parameters
	th->param = (STRING*)xmallocz(sizeof(STRING)*th->NumParams);
	if( !th->param ) {
		break;
	}
	for( i = 0; i < th->NumParams; i ++ ) {
		th->param[i] = create_string(the);
		if( !th->param[i] ) {
			break;
		}
	}
	if( i != th->NumParams ) {
		break;
	}
	//Parameter name 1
	//Parameter name 2
	//...
	//param N STRING Parameter name N
	th->codeSize = get_word_;		// UI16 # of bytes of code that follow

	th->code = (u8*)xmallocz(th->codeSize);
	if( !th->code ) {
		break;
	}

	for( i = 0; i < th->codeSize; i ++ ) {
		th->code[i] = get_bits_(8);
	}
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionDefineFunction)
{
	if( th->param ) {
		u32 i;
		for( i = 0; i < th->NumParams; i ++ ) {
			SAFE_XFREE( th->param[i] );
		}
		stx_free(th->param);
	} // if( th->param ) {
	SAFE_XFREE(th->code);
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionDefineFunction)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionIf,swf_action_init)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionIf)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionIf)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionCall,swf_action_init)
{
}
swf_create_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionCall)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionCall)
{
}
swf_doaction_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_create_begin(ActionGotoFrame2,swf_action_init)
{
	get_bits_(6); //u8					Reserved;		// UB[6] Always 0
	th->SceneBiasFlag = get_bits_(1);	// UB[1] Scene bias flag
	th->Playflag = get_bits_(1);		// UB[1] 0 = Go to frame and stop 	1 = Go to frame and play
	if( th->SceneBiasFlag ) {
		th->SceneBias = get_word_;
	}// If SceneBiasFlag = 1, UI16 Number to be added to frame determined by stack argument
}
swf_create_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ActionGotoFrame2)
{
}
swf_release_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_doaction_begin(ActionGotoFrame2)
{
}
swf_doaction_end()






/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(swf_rect)
{
	th->Nbits = get_bits_(5);
	th->Xmin = get_sbits32_(th->Nbits);
	th->Xmax = get_sbits32_(th->Nbits);
	th->Ymin = get_sbits32_(th->Nbits);
	th->Ymax = get_sbits32_(th->Nbits);
}
swf_create_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(swf_rect)
{
}
swf_release_end()




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(FILLSTYLEARRAY,s32 ishape)
{
	th->ishape = ishape;
	th->FillStyleCount = get_bits_(8);
	if( 0xff == th->FillStyleCount ) {
		th->FillStyleCountExtended = get_word_;
		th->FillStyleCount += th->FillStyleCountExtended;
	}
	th->FillStyles = (FILLSTYLE*)xmallocz(sizeof(FILLSTYLE)*th->FillStyleCount);
	if( !th->FillStyles ) {
		break;
	}
	{
		u32 i;
		for( i = 0; i < th->FillStyleCount; i ++ ) {
			sscreate(FILLSTYLE,the,&th->FillStyles[i],th->ishape);
		}
	}
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(FILLSTYLEARRAY)
{
	if( th->FillStyleCount && th->FillStyles) {
		u32 i;
		for( i = 0; i < th->FillStyleCount; i ++ ) {
			XDELETE(&th->FillStyles[i]);
		}
		stx_free(th->FillStyles );
	}
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(LINESTYLEARRAY,s32 ishape)
{
	th->ishape = ishape;
	th->LineStyleCount = get_bits_(8);
	if( 0xff == th->LineStyleCount ) {
		th->LineStyleCountExtended = get_word_;
		th->LineStyleCount += th->LineStyleCountExtended;
	}
	if( th->ishape >=4 ) {

		th->LineStyles.ls2  = (LINESTYLE2*)xmallocz(sizeof(LINESTYLE2)*th->LineStyleCount);
		if( !th->LineStyles.ls2 ) {
			break;
		}
		{
			u32 i;
			for( i = 0; i < th->LineStyleCount; i ++ ) {
				sscreate(LINESTYLE2,the,&th->LineStyles.ls2[i]);
			}
		}
	}
	else{

		th->LineStyles.ls = (LINESTYLE*)xmallocz(sizeof(LINESTYLE)*th->LineStyleCount);
		if( !th->LineStyles.ls ) {
			break;
		}
		{
			u32 i;
			for( i = 0; i < th->LineStyleCount; i ++ ) {
				sscreate(LINESTYLE,the,&th->LineStyles.ls[i],th->ishape);
			}
		}
	}
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(LINESTYLEARRAY)
{
	if( th->ishape >=4 ) {
		if( th->LineStyleCount && th->LineStyles.ls2) {
			u32 i;
			for( i = 0; i < th->LineStyleCount; i ++ ) {
				XDELETE(&th->LineStyles.ls2[i]);
			}
			stx_free(th->LineStyles.ls2 );
		}
	}
	else{
		if( th->LineStyleCount && th->LineStyles.ls) {
			u32 i;
			for( i = 0; i < th->LineStyleCount; i ++ ) {
				XDELETE(&th->LineStyles.ls[i]);
			}
			stx_free(th->LineStyles.ls );
		}
	}
}
swf_release_end()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(swf_rgba)
{
	th->red = get_bits_(8);
	th->green = get_bits_(8);
	th->blue = get_bits_(8);
	th->alpha = get_bits_(8);
}
swf_create_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(swf_rgba)
{
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(swf_argb)
{
	th->alpha = get_bits_(8);
	th->red = get_bits_(8);
	th->green = get_bits_(8);
	th->blue = get_bits_(8);
}
swf_create_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(swf_argb)
{
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(swf_rgb)
{
	th->red = get_bits_(8);
	th->green = get_bits_(8);
	th->blue = get_bits_(8);
}
swf_create_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(swf_rgb)
{
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(swf_fixed)
{
	th->dec = get_word_;
	th->num = get_word_;
}
swf_create_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(swf_fixed)
{
}
swf_release_end()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(swf_fixed8)
{
	th->dec = get_bits_(8);
	th->num = get_bits_(8);
}
swf_create_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(swf_fixed8)
{
}
swf_release_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(swf_fill_style_solid)
{
	th->fillStyleType = get_word_;
	sscreate(swf_rgba,the,&th->color);
}
swf_create_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(swf_fill_style_solid)
{
	XDELETE(&th->color);
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(swf_line_style)
{
	th->width = get_word_;
	sscreate(swf_rgba,the,&th->color);
}
swf_create_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(swf_line_style)
{
	XDELETE(&th->color);
}
swf_release_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(swf_style_change_record)
{
	th->typeFlag = get_bits_(1);
	th->stateNewStyles = get_bits_(1);
	th->stateLineStyle = get_bits_(1);
	th->stateFillStyle1 = get_bits_(1);
	th->stateFillStyle0 = get_bits_(1);
	th->stateMoveTo = get_bits_(1);
}
swf_create_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(swf_style_change_record)
{
}
swf_release_end()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(MATRIX)
{
	th->HasScale = get_bits_(1);		// UB[1] Has scale values if equal to 1
	if( th->HasScale ){
		th->NScaleBits = get_bits_(5);		// If HasScale = 1, UB[5] Bits in each scale value field
		th->ScaleX = get_bits_(th->NScaleBits);			// If HasScale = 1, FB[NScaleBits] x scale value
		th->ScaleY = get_bits_(th->NScaleBits);			// If HasScale = 1, FB[NScaleBits] y scale value
	}
	th->HasRotate = get_bits_(1);		// UB[1] Has rotate and skew values if equal to 1
	if( th->HasRotate ){
		th->NRotateBits = get_bits_(5);	// If HasRotate = 1, UB[5] Bits in each rotate value field
		th->RotateSkew0 = get_bits_(th->NRotateBits);		// If HasRotate = 1, FB[NRotateBits] First rotate and skew value
		th->RotateSkew1 = get_bits_(th->NRotateBits);	// If HasRotate = 1,FB[NRotateBits] Second rotate and skew value
	}

	th->NTranslateBits = get_bits_(5); // UB[5] Bits in each translate value field
	th->TranslateX = get_sbits32_(th->NTranslateBits);		// SB[NTranslateBits] x translate value in twips
	th->TranslateY = get_sbits32_(th->NTranslateBits);		// SB[NTranslateBits] y translate value in twips

}
swf_create_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(MATRIX)
{
}
swf_release_end()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(CXFORM)
{
	th->HasAddTerms = get_bits_(1);		// UB[1] Has color addition values if equal to 1
	th->HasMultTerms = get_bits_(1);	// UB[1] Has color multiply values if equal to 1
	th->Nbits = get_bits_(4);			// UB[4] Bits in each value field
	if( th->HasMultTerms ){
		th->RedMultTerm = get_sbits16_(th->Nbits);		// If HasMultTerms = 1, SB[Nbits] Red multiply value
		th->GreenMultTerm = get_sbits16_(th->Nbits);	// If HasMultTerms = 1, SB[Nbits] Green multiply value
		th->BlueMultTerm = get_sbits16_(th->Nbits);		// If HasMultTerms = 1, SB[Nbits] Blue multiply value
	}
	if( th->HasAddTerms ) {
		th->RedAddTerm = get_sbits16_(th->Nbits);		// If HasAddTerms = 1, SB[Nbits] Red addition value
		th->GreenAddTerm = get_sbits16_(th->Nbits);		// If HasAddTerms = 1, SB[Nbits] Green addition value
		th->BlueAddTerm = get_sbits16_(th->Nbits);		// If HasAddTerms = 1, SB[Nbits] Blue addition value
	}
}
swf_create_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(CXFORM)
{
}
swf_release_end()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(GRADRECORD,s32 ishape)
{
	th->Ratio = get_bits_(8); // UI8 Ratio value 
	if(th->ishape < 3 ){//  RGB (Shape1 or Shape2) RGBA (Shape3) Color of gradient
		sscreate(swf_rgb,the,&th->Color.rgb);
	}
	else{
		sscreate(swf_rgba,the,&th->Color.rgba);
	}
}
swf_create_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(GRADRECORD)
{
	if(th->ishape < 3 ){
		sdelete(swf_rgb,&th->Color.rgb);
	}
	else{
		sdelete(swf_rgba,&th->Color.rgba);
	}
}
swf_release_end()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(GRADIENT,s32 ishape)
{
	th->ishape = ishape;
	th->SpreadMode = get_bits_(2);	//  UB[2] 0 = Pad mode
	// 1 = Reflect mode
	// 2 = Repeat mode
	// 3 = Reserved
	th->InterpolationMode = get_bits_(2);	//  UB[2] 0 = Normal RGB mode interpolation 1 = Linear RGB mode interpolation
	// 2 and 3 = Reserved
	th->NumGradients = get_bits_(4);		//  UB[4] 1 to 15
	if( th->NumGradients ) {
		//  GRADRECORD[nGrads] Gradient records (see following)
		th->GradientRecords = (GRADRECORD*)xmallocz(sizeof(GRADRECORD)*th->NumGradients) ;
		if( !th->GradientRecords){
			break;
		}
		{
			u8 i;
			for( i = 0; i < th->NumGradients; i ++ ) {
				sscreate(GRADRECORD,the,&th->GradientRecords[i],th->ishape);
			}
		}
	}
}
swf_create_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(GRADIENT)
{
	if( th->NumGradients && th->GradientRecords) {
		u8 i;
		for( i = 0; i < th->NumGradients; i ++ ) {
			sdelete(GRADRECORD,&th->GradientRecords[i]);
		}
		stx_free(th->GradientRecords);
	}
}
swf_release_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(FOCALGRADIENT,s32 ishape)
{
	th->ishape = ishape;
	th->SpreadMode = get_bits_(2);
	th->InterpolationMode = get_bits_(2);
	th->NumGradients = get_bits_(4);
	if( th->NumGradients ) {
		u8 i;
		th->GradientRecords = (GRADRECORD*)xmallocz(sizeof(GRADRECORD)*th->NumGradients);
		if( !th->GradientRecords ){
			break;
		}
		for( i = 0; i < th->NumGradients; i ++ ) {
			sscreate(GRADRECORD,the,&th->GradientRecords[i],ishape);
		}
	}
	sscreate(swf_fixed8,the,&th->FocalPoint);
}
swf_create_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(FOCALGRADIENT)
{
	if( th->NumGradients && th->GradientRecords) {
		u8 i;
		for( i = 0; i < th->NumGradients; i ++ ) {
			sdelete(GRADRECORD,&th->GradientRecords[i]);
		}
	}
	sdelete(swf_fixed8,&th->FocalPoint);
}
swf_release_end()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(FILLSTYLE,s32 ishape)
{
	th->ishape = ishape;
	th->FillStyleType = get_bits_(8);
	if( th->FillStyleType == 0 && th->ishape == 3 ) {
		sscreate(swf_rgba,the,&th->Color);
	}
	else {
		sscreate(swf_rgb,the,&th->rgb);
	}
	if( 0x10 == th->FillStyleType || 0x12 == th->FillStyleType || 0x13 == th->FillStyleType ) {
		sscreate(MATRIX,the,&th->GradientMatrix);
	}
	if(0x10 == th->FillStyleType || 0x12 == th->FillStyleType) {
		sscreate(GRADIENT,the,&th->Gradient.grade,th->ishape);
	}
	else if(0x13 == th->FillStyleType) {
		sscreate(FOCALGRADIENT,the,&th->Gradient.focal,th->ishape);
	}
	if( 0x40 == th->FillStyleType || 0x41 == th->FillStyleType  || 0x42 == th->FillStyleType || 0x43 == th->FillStyleType ) {
		th->BitmapId = get_word_;
		sscreate(MATRIX,the,&th->BitmapMatrix);
	}
}
swf_create_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(FILLSTYLE)
{
	if( th->FillStyleType == 0 && th->ishape == 3 ) {
		sdelete(swf_rgba,&th->Color);
	}
	else {
		sdelete(swf_rgb,&th->rgb);
	}
	if( 0x10 == th->FillStyleType || 0x12 == th->FillStyleType || 0x13 == th->FillStyleType ) {
		sdelete(MATRIX,&th->GradientMatrix);
	}
	if(0x10 == th->FillStyleType || 0x12 == th->FillStyleType) {
		sdelete(GRADIENT,&th->Gradient.grade);
	}
	else if(0x13 == th->FillStyleType) {
		sdelete(FOCALGRADIENT,&th->Gradient.focal);
	}
	if( 0x40 == th->FillStyleType || 0x41 == th->FillStyleType  || 0x42 == th->FillStyleType || 0x43 == th->FillStyleType ) {
		sdelete(MATRIX,&th->BitmapMatrix);
	}
}
swf_release_end()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(LINESTYLE,s32 ishape)
{
	th->ishape = ishape;
	th->Width = get_word_; // UI16 Width of line in twips.
	if( th->ishape < 3 ) {
		sscreate(swf_rgb,the,&th->Color.rgb);
	}
	else{// 
		sscreate(swf_rgba,the,&th->Color.rgba);
	}
}
swf_create_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(LINESTYLE)
{
}
swf_release_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(LINESTYLE2)
{
	th->Width = get_word_;				//	UI16 Width of line in twips.
	th->StartCapStyle = get_bits_(2);		//  UB[2] Start cap style:
	// 0 = Round cap
	// 1 = No cap
	// 2 = Square cap
	th->JoinStyle = get_bits_(2);			// UB[2] Join style:
	// 0 = Round join
	// 1 = Bevel join
	// 2 = Miter join
	th->HasFillFlag = get_bits_(1);		//  UB[1] If 1, fill is defined in FillType. If 0, uses Color field.
	th->NoHScaleFlag = get_bits_(1);		// UB[1] If 1, stroke thickness will not scale if the object is scaled horizontally.
	th->NoVScaleFlag = get_bits_(1);		// UB[1] If 1, stroke thickness will not scale if the object is scaled vertically.
	th->PixelHintingFlag = get_bits_(1);	//  UB[1] If 1, all anchors will be aligned to full pixels.
	get_bits_(5);// Reserved UB[5] Must be 0.
	
	th->NoClose = get_bits_(1);	// UB[1] If 1, stroke will not be closed if the stroke��s last point matches its first point. 
	// Flash Player will apply caps instead of a join.
	th->EndCapStyle = get_bits_(2);			//  UB[2] End cap style:
	// 0 = Round cap
	// 1 = No cap
	// 2 = Square cap
	if( th->JoinStyle == 2 ) {
		th->MiterLimitFactor = get_word_; //  If JoinStyle = 2, UI16 Miter limit factor is an 8.8 fixed-point value.
	}
	if( !th->HasFillFlag ) {// Color If HasFillFlag = 0, RGBA Color value including alpha channel.
		sscreate(swf_rgba,the,&th->Color);
	}
	else {// If HasFillFlag = 1, FILLSTYLE Fill style for this stroke.
		sscreate(FILLSTYLE,the,&th->FillType,th->ishape);
	}	
}
swf_create_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(LINESTYLE2)
{
	if( !th->HasFillFlag ) {// Color If HasFillFlag = 0, RGBA Color value including alpha channel.
		sdelete(swf_rgba,&th->Color);
	}
	else {// If HasFillFlag = 1, FILLSTYLE Fill style for this stroke.
		sdelete(FILLSTYLE,&th->FillType);
	}	
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(GRADIENTBEVELFILTER)
{
	th->NumColors = get_bits_(8);			//UI8 Number of colors in the gradient
	if( th->NumColors ) {
		u32 i;
		th->GradientColors = (swf_rgba*)xmallocz(sizeof(swf_rgba)*th->NumColors);//RGBA[NumColors] Gradient colors
		if(!th->GradientColors){
			break;
		}
		for( i = 0; i < th->NumColors; i ++ ) {
			sscreate(swf_rgba,the,&th->GradientColors[i]);
		}
		th->GradientRatio = (u8*)xmallocz(th->NumColors);		//UI8[NumColors] Gradient ratios
		if(!th->GradientRatio){
			break;
		}
	}// if( th->NumColors ) {
	sscreate(swf_fixed,the,&th->BlurX);				//FIXED Horizontal blur amount
	sscreate(swf_fixed,the,&th->BlurY);				//FIXED Vertical blur amount
	sscreate(swf_fixed,the,&th->Angle);				//FIXED Radian angle of the gradient bevel
	sscreate(swf_fixed,the,&th->Distance);			//FIXED Distance of the gradient bevel
	sscreate(swf_fixed8,the,&th->Strength);			//FIXED8 Strength of the gradient bevel
	th->InnerShadow = get_bits_(1);		//UB[1] Inner bevel mode Knockout UB[1] Knockout mode
	th->CompositeSource = get_bits_(1);	//UB[1] Composite source Always 1
	th->OnTop = get_bits_(1);				//UB[1] OnTop mode
	th->Passes = get_bits_(4);				//UB[4] Number of blur passes
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(GRADIENTBEVELFILTER)
{
	if( th->NumColors ) {
		u32 i;
		if(th->GradientColors){
			for( i = 0; i < th->NumColors; i ++ ) {
				sdelete(swf_rgba,&th->GradientColors[i]);
			}
			stx_free(th->GradientColors);
		}
		SAFE_XFREE(th->GradientRatio);
	}// if( th->NumColors ) {
}
swf_release_end()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(GRADIENTGLOWFILTER )
{
	th->NumColors = get_bits_(8);		// 	 UI8 Number of colors in the gradient
	if( th->NumColors ) {
		u32 i;
		th->GradientColors = (swf_rgba*)xmallocz(sizeof(swf_rgba)*th->NumColors);//RGBA[NumColors] Gradient colors
		if(!th->GradientColors){
			break;
		}
		for( i = 0; i < th->NumColors; i ++ ) {
			sscreate(swf_rgba,the,&th->GradientColors[i]);
		}
		th->GradientRatio = (u8*)xmallocz(th->NumColors);		//UI8[NumColors] Gradient ratios
		if(!th->GradientRatio){
			break;
		}
	}// if( th->NumColors ) {
	sscreate(swf_fixed,the,&th->BlurX);			// 	 FIXED Horizontal blur amount
	sscreate(swf_fixed,the,&th->BlurY);			// 	 FIXED Vertical blur amount
	sscreate(swf_fixed,the,&th->Angle);			// 	 FIXED Radian angle of the gradient glow
	sscreate(swf_fixed,the,&th->Distance);		// 	 FIXED Distance of the gradient glow
	sscreate(swf_fixed8,the,&th->Strength);		// 	 FIXED8 Strength of the gradient glow
	th->InnerShadow = get_bits_(1);	// 	 UB[1] Inner glow mode
	th->Knockout = get_bits_(1);		// 	 UB[1] Knockout mode
	th->CompositeSource = get_bits_(1);// 	 UB[1] Composite source Always 1
	th->OnTop = get_bits_(1);			// 	 UB[1] OnTop mode
	th->Passes = get_bits_(4);			// 	 UB[4] Number of blur passes
}
swf_create_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(GRADIENTGLOWFILTER)
{
	if( th->NumColors ) {
		u32 i;
		if(th->GradientColors){
			for( i = 0; i < th->NumColors; i ++ ) {
				sdelete(swf_rgba,&th->GradientColors[i]);
			}
			stx_free(th->GradientColors);
		}
		SAFE_XFREE(th->GradientRatio);
	}// if( th->NumColors ) {
}
swf_release_end()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(BEVELFILTER)
{
	sscreate(swf_rgba,the,&th->ShadowColor);		// 	 RGBA Color of the shadow
	sscreate(swf_rgba,the,&th->HighlightColor);		// 	 RGBA Color of the highlight
	sscreate(swf_fixed,the, &th->BlurX);				// 	 FIXED Horizontal blur amount
	sscreate(swf_fixed,the, &th->BlurY);				// 	 FIXED Vertical blur amount
	sscreate(swf_fixed,the, &th->Angle);				// 	 FIXED Radian angle of the drop shadow
	sscreate(swf_fixed,the, &th->Distance);			// 	 FIXED Distance of the drop shadow
	sscreate(swf_fixed8,the,&th->Strength);			// 	 FIXED8 Strength of the drop shadow
	th->InnerShadow = get_bits_(1);						// 	 UB[1] Inner shadow mode
	th->Knockout = get_bits_(1);						// 	 UB[1] Knockout mode
	th->CompositeSource = get_bits_(1);					// 	 UB[1] Composite source Always 1
	th->OnTop = get_bits_(1);							// 	 UB[1] OnTop mode
	th->Passes = get_bits_(4);							// 	 UB[4] Number of blur passes
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(BEVELFILTER)
{
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(GLOWFILTER)
{
	sscreate(swf_rgba,the,&th->GlowColor);			//  RGBA Color of the shadow
	sscreate(swf_fixed,the,&th->BlurX);				//	FIXED Horizontal blur amount
	sscreate(swf_fixed,the,&th->BlurY);				//  FIXED Vertical blur amount
	sscreate(swf_fixed8,the,&th->Strength);			//  FIXED8 Strength of the glow
	th->InnerGlow = get_bits_(1);			//  UB[1] Inner glow mode
	th->Knockout = get_bits_(1);			//  UB[1] Knockout mode
	th->CompositeSource = get_bits_(1);	//	UB[1] Composite source Always 1
	th->Passes = get_bits_(5);				//	UB[5] Number of blur
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(GLOWFILTER)
{
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(DROPSHADOWFILTER)
{
	sscreate(swf_rgba,the,&th->DropShadowColor);	//  RGBA Color of the shadow
	sscreate(swf_fixed,the, &th->BlurX);				//  FIXED Horizontal blur amount
	sscreate(swf_fixed,the, &th->BlurY);				//  FIXED Vertical blur amount
	sscreate(swf_fixed,the, &th->Angle);				//  FIXED Radian angle of the drop shadow
	sscreate(swf_fixed,the, &th->Distance);			//  FIXED Distance of the drop shadow
	sscreate(swf_fixed8,the,&th->Strength);			//  FIXED8 Strength of the drop shadow
	th->InnerShadow = get_bits_(1);		//  UB[1] Inner shadow mode 
	th->Knockout = get_bits_(1);			//  UB[1] Knockout mode
	th->CompositeSource = get_bits_(1);	//  UB[1] Composite source Always 1
	th->Passes = get_bits_(5);				//  UB[5] Number of blur passes
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(DROPSHADOWFILTER)
{
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(BLURFILTER)
{
	sscreate(swf_fixed,the, &th->BlurX);			//  FIXED Horizontal blur amount
	sscreate(swf_fixed,the, &th->BlurY);			// FIXED Vertical blur amount
	th->Passes = get_bits_(5);			//  UB[5] Number of blur passes
	get_bits_(3);// Reserved UB[3] Must be 0
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(BLURFILTER)
{
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(CONVOLUTIONFILTER)
{
	u32 val;
	th->MatrixX = get_bits_(8);		// UI8 Horizontal matrix size
	th->MatrixY = get_bits_(8);		// UI8 Vertical matrix size
	val = get_dword_;
	th->Divisor = *(f32*)&val;		//  FLOAT Divisor applied to the matrix values
	val = get_dword_;
	th->Bias = *(f32*)&val;			//  FLOAT Bias applied to the matrix values
	{//  FLOAT[MatrixX * MatrixY] Matrix values
		s32 i;
		s32 i_size = th->MatrixX * th->MatrixY;
		if( i_size ) {
			th->Matrix = (f32*)xmallocz(sizeof(f32)*i_size);
			if( !th->Matrix ) {
				break;
			}
		}
		for( i = 0; i < i_size; i ++ ) {
			val = get_dword_;
			th->Matrix[i] = *(f32*)&val;
		}
	}
	sscreate(swf_rgba,the,&th->DefaultColor);	// RGBA Default color for pixels outside the image
	get_bits_(6);// Reserved UB[6] Must be 0
	th->Clamp = get_bits_(1);			//  UB[1] Clamp mode
	th->PreserveAlpha = get_bits_(1);	// UB[1] Preserve the alpha
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(CONVOLUTIONFILTER)
{
	SAFE_XFREE(th->Matrix);
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(COLORMATRIXFILTER)
{
	s32 i;
	for( i = 0; i < 20; i ++ ) {
		u32 val = get_dword_;
		th->Matrix[i] = *(f32*)val;
	}
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(COLORMATRIXFILTER)
{
}
swf_release_end()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(ALPHABITMAPDATA,s32 i_size,s32 i_bmpfmt)
{
	s32 i;
	th->i_fmt = i_bmpfmt;
	th->BitmapPixelData = xmallocz(sizeof(swf_argb)*i_size);
	if( !th->BitmapPixelData ) {
		break;
	}
	// zlib ????
	for( i = 0; i < i_size; i ++ ) {
		sscreate(swf_argb,the,&th->BitmapPixelData[i]);
	}
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ALPHABITMAPDATA)
{
	SAFE_XFREE(th->BitmapPixelData );
}
swf_release_end()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(ALPHACOLORMAPDATA,s32 i_table,s32 i_data)
{
	s32 i;
	th->ColorTableRGB = (swf_rgba*)xmallocz(sizeof(swf_rgba)*i_table);
	if( !th->ColorTableRGB ) {
		break;
	}
	for( i = 0; i < i_table; i ++ ) {
		sscreate(swf_rgba,the,&th->ColorTableRGB[i]);
	}
	th->ColormapPixelData = (u8*)xmallocz(i_data);
	if( !th->ColormapPixelData ) {
		break;
	}
	for( i = 0; i < i_data; i ++ ) {
		th->ColormapPixelData[i] = get_bits_(8);
	}

}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ALPHACOLORMAPDATA)
{
	SAFE_XFREE(th->ColorTableRGB);
	SAFE_XFREE(th->ColormapPixelData);
}
swf_release_end()




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(PIX24)
{
	th->Pix24Reserved = get_bits_(8);	// UI8 Always 0
	th->Pix24Red = get_bits_(8);		// UI8 Red value
	th->Pix24Green = get_bits_(8);		// UI8 Green value
	th->Pix24Blue = get_bits_(8);		// UI8 Blue value
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(PIX24)
{
}
swf_release_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(PIX15)
{
	th->Pix15Reserved = get_bits_(1);	//  UB[1] Always 0
	th->Pix15Red = get_bits_(5);		//  UB[5] Red value
	th->Pix15Green = get_bits_(5);		//  UB[5] Green value
	th->Pix15Blue = get_bits_(5);		//  UB[5] Blue value
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(PIX15)
{
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(BITMAPDATA,s32 i_fmt,s32 i_data)
{
	s32 i;

	if( i_fmt == 4 ) {// 	 If BitmapFormat = 4,PIX15[image data size]
		th->BitmapPixelData.p15 = (PIX15*)xmallocz(sizeof(PIX15)*i_data);
		if( !th->BitmapPixelData.p15) {
			break;
		}
		for( i = 0; i < i_data; i ++ ) {
			sscreate(PIX15,the,&th->BitmapPixelData.p15[i]);
		}
	}
	else {// 	If BitmapFormat = 5,PIX24[image data size]
		th->BitmapPixelData.p24 = (PIX24*)xmallocz(sizeof(PIX24)*i_data);
		if( !th->BitmapPixelData.p24) {
			break;
		}
		for( i = 0; i < i_data; i ++ ) {
			sscreate(PIX24,the,&th->BitmapPixelData.p24[i]);
		}

	}
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(BITMAPDATA)
{
	SAFE_XFREE(th->BitmapPixelData.p24);
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(COLORMAPDATA,s32 i_table,s32 i_data)
{
	s32 i;
	th->ColorTableRGB = (swf_rgb*)xmallocz(sizeof(swf_rgb)*i_table);
	if( !th->ColorTableRGB ) {
		break;
	}
	for( i = 0; i < i_table; i ++ ) {
		sscreate(swf_rgb,the,&th->ColorTableRGB[i]);
	}
	th->ColormapPixelData = (u8*)xmallocz(i_data);
	if( !th->ColormapPixelData ) {
		break;
	}
	for( i = 0; i < i_data; i ++ ) {
		th->ColormapPixelData[i] = get_bits_(8);
	}
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(COLORMAPDATA)
{
	SAFE_XFREE(th->ColorTableRGB);
	SAFE_XFREE(th->ColormapPixelData);
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(ShapeRecord)
{
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(ShapeRecord)
{
}
swf_release_end()

/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(SHAPE,s32 ishape)
{
	th->ishape = ishape;
	th->NumFillBits = get_bits_(4);		// UB[4] Number of fill index bits.
	th->NumLineBits = get_bits_(4);		// UB[4] Number of line index bits.

	th->i_rec = 0;
	th->i_max = 16;
	th->ShapeRecords = (ShapeRecord**)xmallocz(sizeof(ShapeRecord*)*th->i_max);
	if( !th->ShapeRecords ) {
		break;
	}

	for( ; ; ) {

		u32 i_typ;
		u32 i_sty;

		i_typ = get_bits_(1);
		if( i_typ ) {
			i_sty = get_bits_(1);
			if( i_sty ) {
				th->ShapeRecords[th->i_rec] = screate(StraightEdgeRecord,the,NULL);
			}
			else{
				th->ShapeRecords[th->i_rec] = screate(CurvedEdgeRecord,the,NULL);
			}
		}
		else {
			i_sty = stx_show_bits(&the->gb,5);
			if( i_sty ) {
				th->ShapeRecords[th->i_rec] = screate(StyleChangeRecord,the,NULL,ishape,&th->NumLineBits,&th->NumFillBits);
			}
			else{
				th->ShapeRecords[th->i_rec] = screate(EndShapeRecord,the,NULL);
				break;
			}
		}
		if( !th->ShapeRecords[th->i_rec] ) {
			break;
		}

		th->i_rec ++;

		if( th->i_rec >= th->i_max ) {
			s32 i;
			ShapeRecord** pp = (ShapeRecord**)xmallocz(sizeof(ShapeRecord*)*(th->i_max+16));
			if( !pp) {
				break;
			}
			th->i_max += 16;
			for( i = 0; i < th->i_rec; i ++ ) {
				pp[i] = th->ShapeRecords[i];
			}
			stx_free(th->ShapeRecords);
			th->ShapeRecords = pp;
		}

	} //for( ; ; ) { 

	if( !th->ShapeRecords[th->i_rec] ) {
		break;
	}
	// SHAPERECORD[one or more] Shape records (see following).

}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(SHAPE)
{
	s32 i;
	if( th->ShapeRecords ) {
		for( i = 0; i < th->i_rec; i ++ ) {
				SAFE_XCALL(release,th->ShapeRecords[i]);
		}
		stx_free(th->ShapeRecords);
	}
}
swf_release_end()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(CurvedEdgeRecord)
{
	th->TypeFlag = 1;		// UB[1] This is an edge record. Always 1.
	th->StraightFlag = 0;	// UB[1] Curved edge. Always 0.
	th->NumBits = get_bits_(4);		// UB[4] Number of bits per value (2 less than the actual number).
	th->ControlDeltaX = get_sbits32_(th->NumBits + 2);	//  SB[NumBits+2] X control point change.
	th->ControlDeltaY = get_sbits32_(th->NumBits + 2);	//  SB[NumBits+2] Y control point change.
	th->AnchorDeltaX = get_sbits32_(th->NumBits + 2);	// SB[NumBits+2] X anchor point change.
	th->AnchorDeltaY = get_sbits32_(th->NumBits + 2);	// SB[NumBits+2] Y anchor point change.
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(CurvedEdgeRecord)
{
}
swf_release_end()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(StraightEdgeRecord)
{
	th->TypeFlag = 1;			//  UB[1] This is an edge record.Always 1.
	th->StraightFlag = 1;		//  UB[1] Straight edge.Always 1.
	th->NumBits = get_bits_(4);			//  UB[4] Number of bits per value(2 less than the actual number).
	th->GeneralLineFlag = get_bits_(1);	//  UB[1] General Line equals 1.Vert/Horz Line equals 0.
	if( !th->GeneralLineFlag ) {
		//  If GeneralLineFlag = 0,SB[1] Vertical Line equals 1.Horizontal Line equals 0.
		th->VertLineFlag = get_bits_(1);		
	}
	// If GeneralLineFlag = 1 or if VertLineFlag = 0,SB[NumBits+2]X delta.
	th->DeltaX = get_sbits32_(th->NumBits+2);				
	// If GeneralLineFlag = 1 or if VertLineFlag = 1,SB[NumBits+2]Y
	th->DeltaY = get_sbits32_(th->NumBits+2);				
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(StraightEdgeRecord)
{
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(StyleChangeRecord,s32 ishape,s32* LineBits,s32* FillBits)
{
	th->ishape = ishape;
	th->TypeFlag = 0;				//   UB[1] Non-edge record flag.Always 0.
	th->StateNewStyles = get_bits_(1);			// 	 UB[1] New styles flag. Used by DefineShape2 and DefineShape3 only.
	th->StateLineStyle = get_bits_(1);			// 	 UB[1] Line style change flag.
	th->StateFillStyle1 = get_bits_(1);		// 	 UB[1] Fill style 1 change flag.
	th->StateFillStyle0 = get_bits_(1);		// 	 UB[1] Fill style 0 change flag.
	th->StateMoveTo = get_bits_(1);			// 	 UB[1] Move to flag.
	th->MoveBits = get_bits_(5);				// 	 If StateMoveTo, UB[5] Move bit count.
	// 	 If StateMoveTo, SB[MoveBits] Delta X value.
	th->MoveDeltaX = get_sbits32_(th->MoveBits);				
	// 	 If StateMoveTo, SB[MoveBits] Delta Y value.
	th->MoveDeltaY = get_sbits32_(th->MoveBits);				
	if( th->StateFillStyle0){
		// 	 If StateFillStyle0, UB[FillBits] Fill 0 Style.
		th->FillStyle0 = get_bits_(*FillBits);				
	}
	if( th->StateFillStyle1 ) {
		// 	 If StateFillStyle1, UB[FillBits] Fill 1 Style.
		th->FillStyle1 = get_bits_(*FillBits);
	}
	if( th->StateLineStyle ) {
		// 	 If StateLineStyle, UB[LineBits] Line Style.
		th->linestyles = get_bits_(*LineBits);				
	}
	if( th->StateNewStyles){
		sscreate(FILLSTYLEARRAY,the,&th->FillStyles,ishape);	// 	 If StateNewStyles,	Array of new fill styles.
		sscreate(LINESTYLEARRAY,the,&th->LineStyles,ishape);	// 	 If StateNewStyles,	Array of new line styles.
		// 	 If StateNewStyles, UB[4] Number of fill index bits for new styles.
		*FillBits = th->NumFillBits = get_bits_(4);				
		// 	 If StateNewStyles, UB[4] Number of line index bits for new styles.
		*LineBits = th->NumLineBits = get_bits_(4);				
	}
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(StyleChangeRecord)
{
	if( th->StateNewStyles){
		sdelete(FILLSTYLEARRAY,&th->FillStyles);
		sdelete(LINESTYLEARRAY,&th->LineStyles);
	}
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(EndShapeRecord)
{
	get_bits_(5);
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(EndShapeRecord)
{
}
swf_release_end()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(SHAPEWITHSTYLE,s32 ishape)
{
	th->ishape = ishape;
	sscreate(FILLSTYLEARRAY,the,&th->FillStyles,ishape);		// 	  Array of fill styles.
	sscreate(LINESTYLEARRAY,the,&th->LineStyles,ishape);		// 	  Array of line styles.
	th->NumFillBits = get_bits_(4);			// 	 UB[4] Number of fill index bits.
	th->NumLineBits = get_bits_(4);			// 	 UB[4] Number of line index bits.

	th->i_rec = 0;
	th->i_max = 16;
	th->ShapeRecords = (ShapeRecord**)xmallocz(sizeof(ShapeRecord*)*th->i_max);
	if( !th->ShapeRecords ) {
		break;
	}

	for( ; ; ) {

		u32 i_typ;
		u32 i_sty;

		i_typ = get_bits_(1);
		if( i_typ ) {
			i_sty = get_bits_(1);
			if( i_sty ) {
				th->ShapeRecords[th->i_rec] = screate(StraightEdgeRecord,the,NULL);
			}
			else{
				th->ShapeRecords[th->i_rec] = screate(CurvedEdgeRecord,the,NULL);
			}
		}
		else {
			i_sty = stx_show_bits(&the->gb,5);
			if( i_sty ) {
				th->ShapeRecords[th->i_rec] = screate(StyleChangeRecord,the,NULL,ishape,&th->NumLineBits,&th->NumFillBits);
			}
			else{
				th->ShapeRecords[th->i_rec] = screate(EndShapeRecord,the,NULL);
				break;
			}
		}
		if( !th->ShapeRecords[th->i_rec] ) {
			break;
		}

		th->i_rec ++;

		if( th->i_rec >= th->i_max ) {
			s32 i;
			ShapeRecord** pp = (ShapeRecord**)xmallocz(sizeof(ShapeRecord*)*(th->i_max+16));
			if( !pp) {
				break;
			}
			th->i_max += 16;
			for( i = 0; i < th->i_rec; i ++ ) {
				pp[i] = th->ShapeRecords[i];
			}
			stx_free(th->ShapeRecords);
			th->ShapeRecords = pp;
		}

	} //for( ; ; ) { 

	if( !th->ShapeRecords[th->i_rec] ) {
		break;
	}

	// 	 [one or more] Shape records (see following).
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(SHAPEWITHSTYLE)
{
	sdelete(FILLSTYLEARRAY,&th->FillStyles);		// 	  Array of fill styles.
	sdelete(LINESTYLEARRAY,&th->LineStyles);		// 	  Array of line styles.
	if( th->ShapeRecords ) {
		s32 i;
		for( i = 0; i < th->i_rec; i ++ ) {
			SAFE_XCALL(release,th->ShapeRecords[i]);
		}
		stx_free(th->ShapeRecords);
	}

}
swf_release_end()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(CXFORMWITHALPHA)
{
	th->HasAddTerms = get_bits_(1);		// UB[1] Has color addition values if equal to 1
	th->HasMultTerms = get_bits_(1);		// UB[1] Has color multiply values if equal to 1
	th->Nbits = get_bits_(4);				// UB[4] Bits in each value field
	if( th->HasMultTerms ){
		th->RedMultTerm = get_sbits16_(th->Nbits);		// If HasMultTerms = 1, SB[Nbits] Red multiply value
		th->GreenMultTerm = get_sbits16_(th->Nbits);		// If HasMultTerms = 1, SB[Nbits] Green multiply value
		th->BlueMultTerm = get_sbits16_(th->Nbits);		// If HasMultTerms = 1, SB[Nbits] Blue multiply value
		th->AlphaMultTerm = get_sbits16_(th->Nbits);		// If HasMultTerms = 1, SB[Nbits] Alpha multiply value
		th->RedAddTerm = get_sbits16_(th->Nbits);			// If HasAddTerms = 1, SB[Nbits] Red addition value
		th->GreenAddTerm = get_sbits16_(th->Nbits);		// If HasAddTerms = 1, SB[Nbits] Green addition value
		th->BlueAddTerm = get_sbits16_(th->Nbits);		// If HasAddTerms = 1, SB[Nbits] Blue addition value
		th->AlphaAddTerm = get_sbits16_(th->Nbits);		// If HasAddTerms = 1, SB[Nbits] Transparency addition value
	}
}
swf_create_end();
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(CXFORMWITHALPHA)
{
}
swf_release_end()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(CLIPEVENTFLAGS)
{
	th->ClipEventKeyUp = get_bits_(1);				// UB[1] Key up event
	th->ClipEventKeyDown = get_bits_(1);			// UB[1] Key down event
	th->ClipEventMouseUp = get_bits_(1);			// UB[1] Mouse up event
	th->ClipEventMouseDown = get_bits_(1);			// UB[1] Mouse down event
	th->ClipEventMouseMove = get_bits_(1);			// UB[1] Mouse move event
	th->ClipEventUnload = get_bits_(1);			// UB[1] Clip unload event
	th->ClipEventEnterFrame = get_bits_(1);		// UB[1] Frame event
	th->ClipEventLoad = get_bits_(1);				// UB[1] Clip load event
	th->ClipEventDragOver = get_bits_(1);			// UB[1] SWF 6 and later: mouse	drag over event Otherwise: always 0
	th->ClipEventRollOut = get_bits_(1);			// UB[1] SWF 6 and later: mouse   rollout eventOtherwise: always 0
	th->ClipEventRollOver = get_bits_(1);			// UB[1] SWF 6 and later: mouse   rollover eventOtherwise: always 0
	th->ClipEventReleaseOutside = get_bits_(1);	// UB[1] SWF 6 and later: mouse  release outside event Otherwise: always 0.
	th->ClipEventRelease = get_bits_(1);			// UB[1] SWF 6 and later: mouse release inside event Otherwise: always 0
	th->ClipEventPress = get_bits_(1);				// UB[1] SWF 6 and later: mouse press event Otherwise: always 0
	th->ClipEventInitialize = get_bits_(1);		// UB[1] SWF 6 and later: initialize event Otherwise: always 0
	th->ClipEventData = get_bits_(1);				// UB[1] Data received event
	th->rb5 = get_bits_(5);						// Reserved If SWF version >= 6, UB[5] Always 0
	th->ClipEventConstruct = get_bits_(1);			// If SWF version >= 6, UB[1] SWF 7 and later: construct   event Otherwise: always 0
	th->ClipEventKeyPress = get_bits_(1);			// If SWF version >= 6, UB[1] Key press event
	th->ClipEventDragOut = get_bits_(1);			// If SWF version >= 6, UB[1] Mouse drag out event
	th->rb8 = get_bits_(8);						// Reserved If SWF version >= 6, UB[8] Always 0
}
swf_create_end();
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(CLIPEVENTFLAGS)
{
}
swf_release_end()




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(REGISTERPARAM)
{
	th->Register = get_bits_(8);
	th->ParamName = create_string(the);
	if( !th->ParamName ) {
		break;
	}
}
swf_create_end();
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(REGISTERPARAM)
{
}
swf_release_end()




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(CLIPACTIONRECORD)
{
	s32 i_len;

	sscreate(CLIPEVENTFLAGS,the,&th->EventFlags);			//Events to which this handler applies

	//UI32 Offset in bytes from end of this field to next CLIPACTIONRECORD (or ClipActionEndFlag)
	th->ActionRecordSize = get_dword_;	

	i_len = th->ActionRecordSize;
	
	if( th->EventFlags.ClipEventKeyPress ) {
		//If EventFlags contain ClipEventKeyPress: UI8 Otherwise absent  Key code to trap
		// (see ��DefineButton2�� on page 226)
		th->KeyCode = get_bits_(8);		
		i_len --;
	}

	th->i_max = 16;
	th->i_act = 0;

	th->Actions = (swf_action**)xmallocz(sizeof(swf_action*)*th->i_max);
	if( !th->Actions ){//ACTIONRECORD [one or more] Actions to perform
		break;
	}

	while( i_len > 0 ) {

		u8		ActionCode;	//  UI8 An action code
		u16		Length;		//  If code >= 0x80, UI16 The number of bytes in the ACTIONRECORDHEADER, not
		// counting the ActionCode and Length fields

		Length = 0;
		ActionCode = get_bits_(8);
		i_len --;
		if( ActionCode >= 0x80 ) {
			Length = get_word_;
			i_len -= 2;
		}

		i_len -= Length;

		if( create_action[ActionCode] ) {
			th->Actions[th->i_act] = (swf_action*)create_action[ActionCode](the,NULL,ActionCode,Length);
			if(!th->Actions[th->i_act]) {
				break;
			}
			th->i_act ++;
			if( th->i_act >= th->i_max ) {
				s32 i;
				swf_action** pp = (swf_action**)xmallocz(sizeof(swf_action*)*(th->i_max+16));
				if( !pp) {
					break;
				}
				th->i_max += 16;
				for( i = 0; i < th->i_act; i ++ ) {
					pp[i] = th->Actions[i];
				}
				stx_free(th->Actions);
				th->Actions = pp;
			} // if( th->i_act >= th->i_max ) {

			continue;
		} // if( create_action[ActionCode] ) {

		while(Length) {
			get_bits_(8);
			Length --;
		}

	} // while( i_len > 0 ) {
}
swf_create_end();
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(CLIPACTIONRECORD)
{
	s32 i;

	sdelete(CLIPEVENTFLAGS,&th->EventFlags);//Events to which this handler applies

	if( th->Actions ) {
		for( i = 0; i < th->i_act; i ++ ) {
			if(th->Actions[i]){
				th->Actions[i]->release(th->Actions[i]);
			}
		}
		stx_free(th->Actions);
	}
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(CLIPACTIONS)
{
	u32 flag;

	get_word_;	//Reserved			UI16 Must be 0
	sscreate(CLIPEVENTFLAGS,the,&th->AllEventFlags);		//CLIPEVENTFLAGS All events used in these clip actions

	th->i_max = 32;
	th->i_act = 0;
	th->ClipActionRecords = (CLIPACTIONRECORD**)xmallocz(sizeof(CLIPACTIONRECORD*)*32);
	if( !th->ClipActionRecords ){//CLIPACTIONRECORD[one or more] Individual event handlers
		break;
	}
	for( ; ; ) {
		flag = stx_show_bits(&the->gb,16);
		if( !flag ) {
			//  If SWF version <= 5, UI16 If SWF version >= 6, UI32 Must be 0
			if( the->swfhdr.Version >= 6 ) {
				th->ClipActionEndFlag = get_dword_;
			}
			else{
				th->ClipActionEndFlag = get_word_;
			}
			break;
		}
		th->ClipActionRecords[th->i_act] = screate(CLIPACTIONRECORD,the,NULL);
		if( !th->ClipActionRecords[th->i_act] ) {
			break;
		}
		th->i_act ++;
		if( th->i_act >= th->i_max ) {
			s32 i;
			CLIPACTIONRECORD** pp = (CLIPACTIONRECORD**)xmallocz(sizeof(CLIPACTIONRECORD*)*(th->i_max+32));
			if( !pp) {
				break;
			}
			th->i_max += 32;
			for( i = 0; i < th->i_act; i ++ ) {
				pp[i] = th->ClipActionRecords[i];
			}
			stx_free(th->ClipActionRecords);
			th->ClipActionRecords = pp;
		}
	}
	if( flag && !th->ClipActionRecords[th->i_act] ) {
		break;
	}
}
swf_create_end();
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(CLIPACTIONS)
{
	s32 i;

	sdelete(CLIPEVENTFLAGS,&th->AllEventFlags);//Events to which this handler applies

	if( th->ClipActionRecords ) {
		for( i = 0; i < th->i_act; i ++ ) {
			if(th->ClipActionRecords[i]){
				th->ClipActionRecords[i]->release(th->ClipActionRecords[i]);
			}
		}
		stx_free(th->ClipActionRecords);
	}
}
swf_release_end()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(BUTTONRECORD,s32 ibtn)
{
	th->ibtn = ibtn;
	th->ButtonReserved = get_bits_(2);	//  UB[2]  Reserved bits; always 0  
	//  UB[1]  0 = No blend mode  1 = Has blend mode (SWF 8  and later only)  
	th->ButtonHasBlendMode = get_bits_(1);	
	//  UB[1]  0 = No filter list  1 = Has filter list (SWF 8 and   later only)  
	th->ButtonHasFilterList = get_bits_(1);	
	th->ButtonStateHitTest = get_bits_(1);	//  UB[1]  Present in hit test state  
	th->ButtonStateDown = get_bits_(1);	//  UB[1]  Present in down state  
	th->ButtonStateOver = get_bits_(1);	//  UB[1]  Present in over state  
	th->ButtonStateUp = get_bits_(1);	//  UB[1]  Present in up state  
	th->CharacterID = get_word_;	//  UI16  ID of character to place  
	th->PlaceDepth = get_word_;	//  UI16  Depth at which to place  	character  
	//  Transformation matrix for 	character placement  
	sscreate(MATRIX,the,&th->PlaceMatrix);
	if( th->ibtn == 2 ) {
		//  If within DefineButton2,  Character color transform  
		sscreate(CXFORMWITHALPHA,the,&th->ColorTransform);
		if( th->ButtonHasFilterList ) {
			//  If within DefineButton2 and  List of filters on this button  ButtonHasFilterList = 1, FILTERLIST   
			sscreate(FILTERLIST,the,&th->filterlist); 
		}
		if(th->ButtonHasBlendMode ){
			th->BlendMode = get_bits_(8);	
			//  If within DefineButton2 and  ButtonHasBlendMode = 1, UI8  
		}
	} // if( th->ibtn == 2 ) {
}
swf_create_end();
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(BUTTONRECORD)
{
	sdelete(MATRIX,&th->PlaceMatrix);
	if( th->ibtn == 2 ) {
		//  If within DefineButton2,  Character color transform  
		sdelete(CXFORMWITHALPHA,&th->ColorTransform);
		if( th->ButtonHasFilterList ) {
			//  If within DefineButton2 and  List of filters on this button  ButtonHasFilterList = 1, FILTERLIST   
			sdelete(FILTERLIST,&th->filterlist); 
		}
	} // if( th->ibtn == 2 ) {
}
swf_release_end()




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(TEXTRECORD,s32 itext,s32 gb,s32 ab)
{
	th->i_text = itext;
	th->TextRecordType = get_bits_(1);		// UB[1] Always 1.
	th->StyleFlagsReserved = get_bits_(3);	// UB[3] Always 0.
	th->StyleFlagsHasFont = get_bits_(1);	// UB[1] 1 if text font specified.
	th->StyleFlagsHasColor = get_bits_(1);	// UB[1] 1 if text color specified.
	th->StyleFlagsHasYOffset = get_bits_(1);	// UB[1] 1 if y offset specified.
	th->StyleFlagsHasXOffset = get_bits_(1);	// UB[1] 1 if x offset specified.
	if( th->StyleFlagsHasFont ) {
		th->FontID = get_word_;	// If StyleFlagsHasFont, UI16 Font ID for following text.
		if( 2 == th->i_text ) {
			sscreate(swf_rgba,the,&th->TextColor.rgba);
		}
		else{
			sscreate(swf_rgb,the,&th->TextColor.rgb);
		}
	}// If StyleFlagsHasColor, RGB If this record is part of a DefineText2 tag, 
	//	RGBA Font color for following text.

	if( th->StyleFlagsHasXOffset ) {
		th->XOffset = get_word_;
		// If StyleFlagsHasXOffset, SI16 x offset for following text.
	}
	if( th->StyleFlagsHasYOffset ) {
		th->YOffset = get_word_;
		// If StyleFlagsHasYOffset, SI16 y offset for following text.
	}

	th->TextHeight = get_word_;	// If hasFont, UI16 Font height for following text.
	th->GlyphCount = get_bits_(8);	// UI8 Number of glyphs in record.
	th->GlyphEntries = (GLYPHENTRY*)xmallocz(sizeof(GLYPHENTRY)*th->GlyphCount);
	if( !th->GlyphEntries ) {
		break;
	}
	{
		u32 i;
		for( i = 0; i < th->GlyphCount; i ++ ) {
			sscreate(GLYPHENTRY,the,&th->GlyphEntries[i],gb,ab);
		}
	}
	// GLYPHENTRY[GlyphCount] Glyph entry (see following).
}
swf_create_end();
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(TEXTRECORD)
{
	if( th->StyleFlagsHasFont ) {
		if( 2 == th->i_text ) {
			sdelete(swf_rgba,&th->TextColor.rgba);
		}
		else{
			sdelete(swf_rgb,&th->TextColor.rgb);
		}
	}// If StyleFlagsHasColor, RGB If this record is part of a DefineText2 tag, 
	//	RGBA Font color for following text.

	if( th->GlyphEntries ) {
		u32 i;
		for( i = 0; i < th->GlyphCount; i ++ ) {
			sdelete(GLYPHENTRY,&th->GlyphEntries[i]);
		}
		stx_free(th->GlyphEntries);
	}
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(GLYPHENTRY,s32 gb,s32 ab)
{
	s32 i;
	th->GlyphIndex = (u8*)xmallocz(ab);	// UB[GlyphBits] Glyph index into current font.
	if( th->GlyphIndex ) {
		for( i = 0; i < gb; i ++ ) {
			th->GlyphIndex[i] = get_bits_(8);
		}
	}
	th->GlyphAdvance = (s8*)xmallocz(ab);	// SB[AdvanceBits] x advance value for glyph
	if( th->GlyphAdvance ) {
		for( i = 0; i < ab; i ++ ) {
			th->GlyphAdvance[i] = get_bits_(8);
		}
	}
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(GLYPHENTRY)
{
	SAFE_XFREE(th->GlyphIndex);
	SAFE_XFREE(th->GlyphAdvance);
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(SOUNDINFO)
{
	get_bits_(2);	//Reserved UB[2] Always 0.
	th->SyncStop = get_bits_(1);	// UB[1] Stop the sound now.
	th->SyncNoMultiple = get_bits_(1);	// UB[1] Don��t start the sound if already playing.
	th->HasEnvelope = get_bits_(1);	// UB[1] Has envelope information.
	th->HasLoops = get_bits_(1);	// UB[1] Has loop information.
	th->HasOutPoint = get_bits_(1);	// UB[1] Has out-point information.
	th->HasInPoint = get_bits_(1);	// UB[1] Has in-point information.
	if( th->HasInPoint ){
		th->InPoint = get_dword_;	// If HasInPoint, UI32 Number of samples to skip at	beginning of sound.
	}
	if(th->HasOutPoint){
		th->OutPoint = get_dword_;	// If HasOutPoint, UI32 Position in samples of last	sample to play.
	}
	if(th->HasLoops){
		th->LoopCount = get_word_;	// If HasLoops, UI16 Sound loop count.
	}
	if(th->HasEnvelope ) {
		u32 i;
		th->EnvPoints = get_bits_(8);	// If HasEnvelope, UI8 Sound Envelope point count.
		th->EnvelopeRecords = (SOUNDENVELOPE*)xmallocz(sizeof(SOUNDENVELOPE)*th->EnvPoints);
		for( i = 0; i < th->EnvPoints; i ++ ) {
			sscreate(SOUNDENVELOPE,the,&th->EnvelopeRecords[i]);	
			// If HasEnvelope,	SOUNDENVELOPE[EnvPoints]	Sound Envelope records.
		}
	}
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(SOUNDINFO)
{
	if(th->HasEnvelope && th->EnvelopeRecords) {
		s32 i;
		for( i = 0; i < th->EnvPoints; i ++ ) {
			sdelete(SOUNDENVELOPE,&th->EnvelopeRecords[i]);	
			// If HasEnvelope,	SOUNDENVELOPE[EnvPoints]	Sound Envelope records.
		}
		stx_free(th->EnvelopeRecords);
	}
}
swf_release_end()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(SOUNDENVELOPE)
{
	th->Pos44 = get_dword_;	// UI32 Position of envelope point	as a number of 44 kHz	samples. Multiply
	// accordingly;	if using a	sampling rate less than 44	kHz.
	th->LeftLevel = get_word_;	// UI16 Volume level for left	channel. Minimum is 0,	maximum is 32768.
	th->RightLevel = get_word_;	// UI16 Volume level for right	channel. Minimum is 0,	maximum is 32768.
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(SOUNDENVELOPE)
{
}
swf_release_end()




/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(FILTERLIST)
{
	th->NumberOfFilters = get_bits_(8);	// UI8 Number of Filters
	// [NumberOfFilters] List of filters
	th->Filters = (FILTER**)xmallocz(sizeof(FILTER*)*th->NumberOfFilters);
	if( !th->Filters ) {
		break;
	}
	{
		s32 i;

		for( i = 0; i < th->NumberOfFilters; i ++ ){

			u32 id = get_bits_(8);

			if( 0 == id ) {
				th->Filters[i] = screate(DROPSHADOWFILTER,the,NULL);
			}
			else if( 1 == id ) {
				th->Filters[i] = screate(BLURFILTER,the,NULL);
			}
			else if( 2 == id ) {
				th->Filters[i] = screate(GLOWFILTER,the,NULL);
			}
			else if( 3 == id ) {
				th->Filters[i] = screate(BEVELFILTER,the,NULL);
			}
			else if( 4 == id ) {
				th->Filters[i] = screate(GRADIENTGLOWFILTER,the,NULL);
			}
			else if( 5 == id ) {
				th->Filters[i] = screate(CONVOLUTIONFILTER,the,NULL);
			}
			else if( 6 == id ) {
				th->Filters[i] = screate(COLORMATRIXFILTER,the,NULL);
			}
			else if( 7 == id ) {
				th->Filters[i] = screate(GRADIENTBEVELFILTER,the,NULL);
			}

			if( !th->Filters[i] ) {
				break;
			}

		}
	}
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(FILTERLIST)
{
	if( th->Filters ) {
		s32 i;
		for( i = 0; i < th->NumberOfFilters; i ++ ) {
			SAFE_XCALL(release,th->Filters[i]);
		}
		stx_free(th->Filters);
	}
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(FILTER)
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(FILTER)
swf_release_end()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(MORPHLINESTYLEARRAY,s32 ishape)
{
	th->ishape = ishape;
	th->LineStyleCount = get_bits_(8); // UI8 Count of line styles.
	if( 0xff == th->LineStyleCount){// If count = 0xFF UI16 Extended count OF line styles.
		th->LineStyleCountExtended = get_word_;
		th->LineStyleCount += th->LineStyleCountExtended;
	}

	// Array of line styles.

	if( th->ishape == 2 ) {// MORPHLINESTYLE2[count], (if MorphShape2)
		th->LineStyles.s2 = (MORPHLINESTYLE2*)xmallocz(sizeof(MORPHLINESTYLE2)*th->LineStyleCount);
		if( !th->LineStyles.s2){
			break;
		}
		{
			u32 i;
			for( i = 0; i < th->LineStyleCount; i ++ ) {
				sscreate(MORPHLINESTYLE2,the,&th->LineStyles.s2[i]);
			}
			if( i != th->LineStyleCount ){
				break;
			}
		}
	}
	else{// MORPHLINESTYLE[count], (if MorphShape1) 
		th->LineStyles.s = (MORPHLINESTYLE*)xmallocz(sizeof(MORPHLINESTYLE)*th->LineStyleCount);
		if( !th->LineStyles.s){
			break;
		}
		{
			u32 i;
			for( i = 0; i < th->LineStyleCount; i ++ ) {
				sscreate(MORPHLINESTYLE,the,&th->LineStyles.s[i]);
			}
			if( i != th->LineStyleCount ){
				break;
			}
		}
	}
}
swf_create_end();
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(MORPHLINESTYLEARRAY)
{
	if( th->ishape == 2 ) {
		if( th->LineStyles.s2){
			u32 i;
			for( i = 0; i < th->LineStyleCount; i ++ ) {
				sdelete(MORPHLINESTYLE2,&th->LineStyles.s2[i]);
			}
			stx_free(th->LineStyles.s2);
		}
	}
	else{
		if( th->LineStyles.s){
			u32 i;
			for( i = 0; i < th->LineStyleCount; i ++ ) {
				sdelete(MORPHLINESTYLE,&th->LineStyles.s[i]);
			}
			stx_free(th->LineStyles.s);
		}
	}
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(MORPHFILLSTYLEARRAY)
{
	th->FillStyleCount = get_bits_(8);			// Count = UI8 Count of fill styles.
	if( 0xff == th->FillStyleCount ) {
		th->FillStyleCountExtended = get_word_;	// If Count = 0xFF 	UI16 Extended count of fill styles.
		th->FillStyleCount += th->FillStyleCountExtended;
	}
	th->FillStyles = (MORPHFILLSTYLE*)xmallocz(sizeof(MORPHFILLSTYLE)*th->FillStyleCount);
	if( !th->FillStyles) {
		break;
	}
	{// MORPHFILLSTYLE[count] Array of fill styles.
		u32 i;
		for( i = 0; i < th->FillStyleCount; i ++ ) {
			sscreate(MORPHFILLSTYLE,the,&th->FillStyles);
		}
		if( i != th->FillStyleCount ) {
			break;
		}
	}
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(MORPHFILLSTYLEARRAY)
{
	if( th->FillStyles) {
		u32 i;
		for( i = 0; i < th->FillStyleCount; i ++ ) {
			sdelete(MORPHFILLSTYLE,&th->FillStyles);
		}
		stx_free(th->FillStyles);
	}
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(MORPHFILLSTYLE)
{
	th->fillStyleType = get_bits_(8);// UI8 Type of fill style
	//0x00 = solid fill
	//0x10 = linear gradient fill
	//0x12 = radial gradient fill
	//0x40 = repeating bitmap
	//0x41 = clipped bitmap fill
	//0x42 = non-smoothed repeating bitmap
	//0x43 = non-smoothed clipped bitmap
	if( 0x00 == th->fillStyleType ){
		sscreate(swf_rgba,the,&th->StartColor);
		// If type = 0x00, RGBA Solid fill color with opacity information for start shape.
		sscreate(swf_rgba,the,&th->EndColor);
		// If type = 0x00, RGBA Solid fill color with opacity information for end shape.
	}

	if( 0x10 == th->fillStyleType || 0x12 == th->fillStyleType){
		sscreate(MATRIX,the,&th->StartGradientMatrix);
		// If type = 0x10 or 0x12, MATRIX Matrix for gradient fill for start shape.
		sscreate(MATRIX,the,&th->EndGradientMatrix);
		// If type = 0x10 or 0x12, MATRIX Matrix for gradient fill for end shape.
		sscreate(MORPHGRADIENT,the,&th->Gradient);
		// If type = 0x10 or 0x12, MORPHGRADIENT Gradient fill.
	}

	if( th->fillStyleType >= 0x40 && th->fillStyleType <= 0x43 ) {
		th->BitmapId = get_word_;
		//  If type = 0x40, 0x41, 0x42 or 0x43, UI16 ID of bitmap character for fill.
		sscreate(MATRIX,the,&th->StartBitmapMatrix);
		//  If type = 0x40, 0x41, 0x42 or 0x43,Matrix for bitmap fill for start shape.
		sscreate(MATRIX,the,&th->EndBitmapMatrix);
		//  If type = 0x40, 0x41, 0x42 or 0x43, Matrix for bitmap fill for end shape.
	}

}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(MORPHFILLSTYLE)
{
	if( 0x10 == th->fillStyleType || 0x12 == th->fillStyleType){
		sdelete(MATRIX,&th->StartGradientMatrix);
		// If type = 0x10 or 0x12, MATRIX Matrix for gradient fill for start shape.
		sdelete(MATRIX,&th->EndGradientMatrix);
		// If type = 0x10 or 0x12, MATRIX Matrix for gradient fill for end shape.
		sdelete(MORPHGRADIENT,&th->Gradient);
		// If type = 0x10 or 0x12, MORPHGRADIENT Gradient fill.
	}

	if( th->fillStyleType >= 0x40 && th->fillStyleType <= 0x43 ) {
		//  If type = 0x40, 0x41, 0x42 or 0x43, UI16 ID of bitmap character for fill.
		sdelete(MATRIX,&th->StartBitmapMatrix);
		//  If type = 0x40, 0x41, 0x42 or 0x43,Matrix for bitmap fill for start shape.
		sdelete(MATRIX,&th->EndBitmapMatrix);
		//  If type = 0x40, 0x41, 0x42 or 0x43, Matrix for bitmap fill for end shape.
	}
}
swf_release_end()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(MORPHLINESTYLE)
{
	th->StartWidth = get_word_; // UI16 Width of line in start shape in twips.
	th->EndWidth = get_word_;	// UI16 Width of line in end shape in twips.
	// RGBA Color value including alpha	channel information for start		shape.
	sscreate(swf_rgba,the,&th->StartColor); 
	sscreate(swf_rgba,the,&th->EndColor);	
	// RGBA Color value including alpha	channel information for end		shape.
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(MORPHLINESTYLE)
{

}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(MORPHLINESTYLE2)
{
	th->StartWidth = get_word_;	// UI16 Width of line in start shape in	twips.
	th->EndWidth = get_word_;	// UI16 Width of line in end shape in	twips.
	th->StartCapStyle = get_bits_(2);	// UB[2] Start-cap style:
	//0 = Round cap
	//1 = No cap
	//2 = Square cap
	th->JoinStyle = get_bits_(2);	// UB[2] Join style:
	//0 = Round join
	//1 = Bevel join
	//2 = Miter join
	th->HasFillFlag = get_bits_(1);	
	// UB[1] If 1, fill is defined in FillType.If 0, uses StartColor and	EndColor fields.

	th->NoHScaleFlag = get_bits_(1);	// UB[1] If 1, stroke thickness will not scale if the object is scaled horizontally.
	th->NoVScaleFlag = get_bits_(1);	// UB[1] If 1, stroke thickness will not scale if the object is scaled vertically.
	th->PixelHintingFlag = get_bits_(1);	// UB[1] If 1, all anchors will be aligned to full pixels.
	//Reserved UB[5] Must be 0.
	th->NoClose = get_bits_(1);	// UB[1] If 1, stroke will not be closed if the stroke��s last point matches
	//its first point. Flash Player will apply caps instead of a join.
	th->EndCapStyle = get_bits_(2);	// UB[2] End-cap style:
	//0 = Round cap
	//1 = No cap
	//2 = Square cap

	if(th->JoinStyle == 2 ) {
		th->MiterLimitFactor = get_word_;	
		// If JoinStyle = 2, UI16 Miter limit factor as an 8.8 fixed-point value.
	}

	if( !th->HasFillFlag){
		sscreate(swf_rgba,the,&th->StartColor);	
		// If HasFillFlag = 0, RGBA Color value including alpha channel information for start shape.
		sscreate(swf_rgba,the,&th->EndColor);	
		// If HasFillFlag = 0, RGBA Color value including alpha channel information for End shape.
	}
	else {
		sscreate(MORPHFILLSTYLE,the,&th->FillType);	
		// If HasFillFlag = 1,MORPHFILLSTYLE Fill style
	}

}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(MORPHLINESTYLE2)
{
	if( th->HasFillFlag){
		sdelete(MORPHFILLSTYLE,&th->FillType);	
		// If HasFillFlag = 1,MORPHFILLSTYLE Fill style
	}

}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(KERNINGRECORD,b32 b_wide)
{
	if( b_wide ) {
		th->FontKerningCode1 = get_word_;		
		// If FontFlagsWideCodes,	UI16 Otherwise UI8 Character; code of the left	character.
		th->FontKerningCode2 = get_word_;		
		//  If FontFlagsWideCodes,	UI16 Otherwise UI8 Character; code of the right	character.
	}
	else{
		th->FontKerningCode1 = get_bits_(8);		
		th->FontKerningCode2 = get_bits_(8);		
	}

	th->FontKerningAdjustment = get_word_;	//  SI16 Adjustment relative to left	character��s advance value.

}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(KERNINGRECORD)
{

}
swf_release_end()



/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(MORPHGRADIENT)
{
	th->NumGradients = get_bits_(8);		// UI8 1 to 8.	
	th->GradientRecords = (MORPHGRADRECORD*)xmallocz(sizeof(MORPHGRADRECORD)*th->NumGradients);
	if(!th->GradientRecords) {
		break;
	}
	// 	[NumGradients] Gradient records (seefollowing).
	{
		u32 i;
		for( i = 0; i < th->NumGradients; i++ ) {
			sscreate(MORPHGRADRECORD,the,&th->GradientRecords[i]);	
		}
		if( i != th->NumGradients ) {
			break;
		}
	}
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(MORPHGRADIENT)
{
	if( th->GradientRecords) {
		u32 i;
		for( i = 0; i < th->NumGradients; i++ ) {
			sdelete(MORPHGRADRECORD,&th->GradientRecords[i]);	
		}
		stx_free(th->GradientRecords);
	}
}
swf_release_end()


/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_base_create_begin(MORPHGRADRECORD)
{
	th->StartRatio = get_bits_(8);	// UI8 Ratio value for start shape.
	sscreate(swf_rgba,the,&th->StartColor); //  RGBA Color of gradient for start shape.
	th->EndRatio = get_bits_(8);	//  UI8 Ratio value for end shape.
	sscreate(swf_rgba,the,&th->EndColor);	//  RGBA Color of gradient for end shape.
}
swf_create_end()
/***************************************************************************
RETURN VALUE:
INPUT:
OUTPUT:
NOTE:
***************************************************************************/
swf_release_begin(MORPHGRADRECORD)
{
}
swf_release_end()












#undef lock_
#undef unlock_
