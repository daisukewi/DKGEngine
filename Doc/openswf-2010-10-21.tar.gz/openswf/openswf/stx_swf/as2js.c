/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2010-08
***********************************************************************************/
#include "stx_all.h"
#include "as2js.h"

#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif




STX_RESULT as2js(u8* ascode, s32 i_len, u8** jscode)
{

	return STX_OK;
}