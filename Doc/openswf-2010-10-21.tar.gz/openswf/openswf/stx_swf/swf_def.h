/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/
#ifndef __SWF_DEF_H__
#define __SWF_DEF_H__


#include "base_class.h"


STX_INTERF(swf_base);
STX_INTERF(swf_tag);
STX_INTERF(swf_action);




/*{{{**********************************************************************************/
#define swf_base_def(...) \
	THEE	hcan;\
	THEE	hins;\
	s32		ishape;\
	THEE	hstack;\
	_STX_PURE THEE			(*create)( THEE hcan, THEE hins, ## __VA_ARGS__ );\
	_STX_PURE s32			(*release)( THEE h )

struct swf_base{
	swf_base_def();
};

#define  swf_base_decl(BASE,...) \
	THEE		BASE ## _xxx_create(THEE hcan, THEE hins, ## __VA_ARGS__ );\
	s32			BASE ## _xxx_release( THEE h )

#define swf_base_begin(BASE,...) \
	swf_base_decl(BASE, ## __VA_ARGS__);\
	struct BASE{\
		swf_base_def(## __VA_ARGS__);

#define swf_base_end() }

#define swf_base_init(VT,BASE) \
	STX_VT_INIT(VT,BASE,create);\
	STX_VT_INIT(VT,BASE,release)
/*}}}**********************************************************************************/


/*{{{**********************************************************************************/
#define swf_tag_def(...) \
	swf_base_def( ## __VA_ARGS__);\
	u32		itag;\
	u32		ilen;\
	u32		ichid

struct swf_tag{
	swf_tag_def();
};

#define  swf_tag_decl(TAG,...) \
	swf_base_decl(TAG, ## __VA_ARGS__ )

#define swf_tag_begin(TAG,...) \
	swf_tag_decl(TAG, ## __VA_ARGS__);\
	struct TAG{\
		swf_tag_def( ## __VA_ARGS__);

#define swf_tag_end() }

#define swf_tag_init(VT,TAG) swf_base_init(VT,TAG)
/*}}}**********************************************************************************/




/*{{{**********************************************************************************/
#define swf_action_def(...) \
	swf_base_def(## __VA_ARGS__);\
	u32		itag;\
	u32		ilen;\
	_STX_PURE STX_RESULT	(*doaction)( THEE h )

struct swf_action{
	swf_action_def();
};

#define swf_action_decl(ACT,...) \
	swf_base_decl(ACT,## __VA_ARGS__);\
	STX_RESULT	ACT ## _xxx_doaction(THEE h)

#define swf_action_begin(ACT,...) \
	swf_action_decl(ACT, ## __VA_ARGS__);\
	struct ACT{\
		swf_action_def( ## __VA_ARGS__);

#define swf_action_end() }


#define swf_action_init(VT,ACT) \
	swf_base_init(VT,ACT);\
	STX_VT_INIT(VT,ACT,doaction);\
	th->hstack = stx_stack_create();\
	if( !th->hstack ) {\
		break;\
	}

/*}}}**********************************************************************************/



/*{{{**********************************************************************************/
#define swf_base_create_begin(BASE,...) \
	THEE BASE ## _xxx_create(THEE hcan, THEE hins, ## __VA_ARGS__ )\
{\
	BASE*		th;\
	stx_swf*	the = (stx_swf*)hcan;\
	do{\
		th = (BASE*)hins;\
		if( !th) {\
			th = (BASE*)xmallocz(sizeof(BASE));\
			if( !th ){\
				break;\
			}\
			th->hins = hins;\
		}\
		th->hcan = hcan;\
		swf_base_init((*th),BASE);\
		{

#define swf_create_begin(TAG,INIT,...) \
THEE TAG ## _xxx_create(THEE hcan, THEE hins,u32 tag, u32 ilen, ## __VA_ARGS__ )\
{\
	TAG*		th;\
	stx_swf*	the = (stx_swf*)hcan;\
	do{\
		th = (TAG*)hins;\
		if( !th) {\
			th = (TAG*)xmallocz(sizeof(TAG));\
			if( !th ){\
				break;\
			}\
			th->hins = hins;\
		}\
		th->itag = tag;\
		th->ilen = ilen;\
		th->hcan = hcan;\
		INIT((*th),TAG);\
		{

#define swf_create_end() \
		}\
	}while(FALSE);\
	align_byte_;\
	return th;\
}

#define swf_release_begin(TAG) \
s32 TAG ## _xxx_release(THEE h)\
{\
	TAG* th = (TAG*)h;\
	stx_swf* the = th->hcan;\
	{

#define swf_release_end() \
	}\
	if( th->hstack ) {\
		stx_stack_close(th->hstack);\
	}\
	if( th->hins ) {\
		stx_free(th->hins);\
	}\
	return 0;\
}

#define swf_doaction_begin(TAG,...) \
STX_RESULT TAG ## _xxx_doaction(THEE h , ## __VA_ARGS__)\
{\
	STX_RESULT i_err = STX_FAIL;\
	TAG* th = (TAG*)h;\
	stx_swf* the = (stx_swf*)th->hcan;\
	do{

#define swf_doaction_end() \
	}while(FALSE);\
	return i_err;\
}





#define EMPTYINIT(A,B)
#define screate(TAG,...)	TAG ## _xxx_create(## __VA_ARGS__)
#define sscreate(TAG,...)	if( ! screate(TAG, ## __VA_ARGS__) ) break
#define sdelete(TAG,th)		TAG ## _xxx_release(th)
#define ssdelete(TAG,th)	if(h)sdelete(TAG,th)
/*}}}**********************************************************************************/




#define SWF_COMPRESSED_MAGIC	((s32)('C'|('W'<<8)|('S'<<16))) //"CWS"
#define SWF_UNCOMPRESSED_MAGIC	((s32)('F'|('W'<<8)|('S'<<16))) //"FWS"


enum swf_tag_id{
	TAG_END = 0,
	TAG_SHOW_FRAME,
	TAG_DEFINE_SHAPE,
	TAG_PLACE_OBJECT = 4,
	TAG_REMOVE_OBJECT,
	TAG_DEFINE_BITS,
	TAG_DEFINE_BUTTON,
	TAG_JPEG_TABLES,
	TAG_SET_BACKGROUND_COLOR,
	TAG_DEFINE_FONT,
	TAG_DEFINE_TEXT,
	TAG_DO_ACTION,
	TAG_DEFINE_FONT_INFO,
	TAG_DEFINE_SOUND,
	TAG_START_SOUND,
	TAG_DEFINE_BUTTON_SOUND,
	TAG_SOUND_STREAM_HEAD,
	TAG_SOUND_STREAM_BLOCK,
	TAG_DEFINE_BITS_LOSSLESS,
	TAG_DEFINE_BITS_JPEG2,
	TAG_DEFINE_SHAPE2,
	TAG_DEFINE_BUTTON_CXFORM,
	TAG_PROTECT,
	TAG_PLACE_OBJECT2 = 26,
	TAG_REMOVE_OBJECT2 = 28,
	TAG_DEFINE_SHAPE3 = 32,
	TAG_DEFINE_TEXT2,
	TAG_DEFINE_BUTTON2,
	TAG_DEFINE_BITS_JPEG3,
	TAG_DEFINE_BITS_LOSSLESS2,
	TAG_DEFINE_EDIT_TEXT,
	TAG_DEFINE_SPRITE = 39,
	TAG_FRAME_LABEL = 43,
	TAG_SOUND_STREAM_HEAD2 = 45,
	TAG_DEFINE_MORPH_SHAPE,
	TAG_DEFINE_FONT2 = 48,
	TAG_EXPORT_ASSETS = 56,
	TAG_IMPORT_ASSETS,
	TAG_ENABLE_DEBUGGER,
	TAG_DO_INIT_ACTION,
	TAG_DEFINE_VIDEO_STREAM,
	TAG_VIDEO_FRAME,
	TAG_DEFINE_FONT_INFO2,
	TAG_ENABLE_DEBUGGER2 = 64,
	TAG_SCRIPT_LIMITS,
	TAG_SET_TAB_INDEX,
	TAG_FILE_ATTRIBUTES = 69,
	TAG_PLACE_OBJECT3,
	TAG_IMPORT_ASSETS2,
	TAG_DEFINE_FONT_ALIGN_ZONES = 73,
	TAG_DEFINE_CSM_TEXT_SETTINGS,
	TAG_DEFINE_FONT3,
	TAG_SYMBOL_CLASS,
	TAG_METADATA,
	TAG_DEFINE_SCALING_GRID,
	TAG_DO_ABC = 82,
	TAG_DEFINE_SHAPE4,
	TAG_DEFINE_MORPH_SHAPE2,
	TAG_DEFINE_SCENE_AND_FRAME_LABEL_DATA = 86,
	TAG_DEFINE_BINARY_DATA,
	TAG_DEFINE_FONT_NAME = 88,
	TAG_DEFINE_START_SOUND2 = 89,
	TAG_DEFINE_BITS_JPEG4 = 90,
	TAG_DEFINE_FONT4 = 91
};

enum swf_fill_styles{
	FILL_STYLE_SOLID = 0x00,
	FILL_STYLE_LINEAR_GRADIENT = 0x10,
	FILL_STYLE_RADIAL_GRADIENT = 0x12,
	FILL_STYLE_FOCAL_RADIAL_GRADIENT = 0x13,
	FILL_STYLE_REPEATING_BITMAP = 0x40,
	FILL_STYLE_CLIPPED_BITMAP = 0x41,
	FILL_STYLE_NON_SMOOTHED_CLIPPED_BITMAP = 0x43
};



STX_INTERF(swf_rgba);
STX_INTERF(swf_argb);
STX_INTERF(swf_rgb);
STX_INTERF(swf_fixed);
STX_INTERF(swf_fixed8);
STX_INTERF(swf_fill_style_solid);
STX_INTERF(swf_line_style);
STX_INTERF(swf_file_attributes);
STX_INTERF(swf_style_change_record);

STX_INTERF(swf_rect);

STX_INTERF(MATRIX);
STX_INTERF(CXFORM);
STX_INTERF(PlaceObject);
STX_INTERF(PlaceObject3);
STX_INTERF(PlaceObject2);
STX_INTERF(ShowFrame);
STX_INTERF(RemoveObject);
STX_INTERF(RemoveObject2);
STX_INTERF(SetBackgroundColor);
STX_INTERF(FrameLabel);
STX_INTERF(NamedAnchor);
STX_INTERF(Protect);
STX_INTERF(End);
STX_INTERF(ExportAssets);
STX_INTERF(ImportAssets);
STX_INTERF(EnableDebugger);
STX_INTERF(EnableDebugger2);
STX_INTERF(ScriptLimits);
STX_INTERF(SetTabIndex);
STX_INTERF(ImportAssets2);
STX_INTERF(SymbolClass);
STX_INTERF(Metadata);
STX_INTERF(DefineScalingGrid);
STX_INTERF(DefineSceneAndFrameLabelData);

STX_INTERF(CXFORMWITHALPHA);
STX_INTERF(CLIPEVENTFLAGS);
STX_INTERF(ACTIONRECORDHEADER);

STX_INTERF(CLIPACTIONRECORD);
STX_INTERF(CLIPACTIONS);
STX_INTERF(FILTERLIST);

STX_INTERF(swf_header);

STX_INTERF(DefineSprite);
STX_INTERF(DefineShape);
STX_INTERF(DefineShape2);
STX_INTERF(DefineShape3);
STX_INTERF(DefineShape4);

STX_INTERF(SHAPEWITHSTYLE);
STX_INTERF(FILLSTYLEARRAY);
STX_INTERF(FILLSTYLE);
STX_INTERF(LINESTYLEARRAY);
STX_INTERF(LINESTYLE);
STX_INTERF(LINESTYLE2);
STX_INTERF(swf_shape);


STX_INTERF(ShapeRecord);
STX_INTERF(EndShapeRecord);
STX_INTERF(StyleChangeRecord);
STX_INTERF(StraightEdgeRecord);
STX_INTERF(CurvedEdgeRecord);
STX_INTERF(GRADIENT);
STX_INTERF(FOCALGRADIENT);
STX_INTERF(GRADRECORD);
STX_INTERF(DefineBits);
STX_INTERF(JPEGTables);
STX_INTERF(DefineBitsJPEG2);
STX_INTERF(DefineBitsJPEG3);
STX_INTERF(DefineBitsLossless);
STX_INTERF(COLORMAPDATA);
STX_INTERF(BitmapData);
STX_INTERF(PIX15);
STX_INTERF(PIX24);
STX_INTERF(DefineBitsLossless2);
STX_INTERF(ALPHACOLORMAPDATA);
STX_INTERF(ALPHABITMAPDATA);
STX_INTERF(DefineBitsJPEG4);
STX_INTERF(FILTER);
STX_INTERF(COLORMATRIXFILTER);
STX_INTERF(CONVOLUTIONFILTER);
STX_INTERF(BLURFILTER);
STX_INTERF(DROPSHADOWFILTER);
STX_INTERF(GLOWFILTER);
STX_INTERF(BEVELFILTER);
STX_INTERF(GRADIENTGLOWFILTER);
STX_INTERF(GRADIENTBEVELFILTER);

STX_INTERF(BITMAPDATA);
STX_INTERF(RECORDHEADER);

STX_INTERF(ActionGotoFrame);
STX_INTERF(ActionGetURL);
STX_INTERF(ActionNextFrame);
STX_INTERF(ActionPreviousFrame);
STX_INTERF(ActionPlay);
STX_INTERF(ActionStop);
STX_INTERF(ActionToggleQuality);
STX_INTERF(ActionStopSounds);
STX_INTERF(ActionWaitForFrame);
STX_INTERF(ActionSetTarget);
STX_INTERF(ActionGoToLabel);
STX_INTERF(ActionPush);
STX_INTERF(ActionPop);
STX_INTERF(ActionAdd);
STX_INTERF(ActionSubtract);
STX_INTERF(ActionMultiply);
STX_INTERF(ActionDivide);
STX_INTERF(ActionEquals);

STX_INTERF(ActionLess);
STX_INTERF(ActionAnd);
STX_INTERF(ActionOr);
STX_INTERF(ActionNot);
STX_INTERF(ActionStringEquals);
STX_INTERF(ActionStringLength);
STX_INTERF(ActionStringAdd);
STX_INTERF(ActionStringExtract);
STX_INTERF(ActionStringLess);

STX_INTERF(ActionMBStringLength);
STX_INTERF(ActionMBStringExtract);
STX_INTERF(ActionToInteger);
STX_INTERF(ActionCharToAscii);
STX_INTERF(ActionAsciiToChar);
STX_INTERF(ActionMBCharToAscii);
STX_INTERF(ActionMBAsciiToChar);

STX_INTERF(ActionJump);
STX_INTERF(ActionIf);
STX_INTERF(ActionCall);
STX_INTERF(ActionGetVariable);
STX_INTERF(ActionSetVariable);
STX_INTERF(ActionGetURL2);

STX_INTERF(ActionGotoFrame2);
STX_INTERF(ActionSetTarget2);
STX_INTERF(ActionGetProperty);
STX_INTERF(ActionSetProperty);
STX_INTERF(ActionCloneSprite);
STX_INTERF(ActionRemoveSprite);
STX_INTERF(ActionStartDrag);
STX_INTERF(ActionEndDrag);
STX_INTERF(ActionWaitForFrame2);
STX_INTERF(ActionTrace);

STX_INTERF(ActionGetTime);
STX_INTERF(ActionRandomNumber);
STX_INTERF(ActionCallFunction);
STX_INTERF(ActionCallMethod);
STX_INTERF(ActionConstantPool);
STX_INTERF(ActionDefineFunction);
STX_INTERF(ActionDefineLocal);
STX_INTERF(ActionDefineLocal2);

STX_INTERF(ActionDelete);
STX_INTERF(ActionDelete2);
STX_INTERF(ActionEnumerate);
STX_INTERF(ActionEquals2);
STX_INTERF(ActionGetMember);
STX_INTERF(ActionInitArray);
STX_INTERF(ActionInitObject);
STX_INTERF(ActionNewMethod);

STX_INTERF(ActionNewObject);
STX_INTERF(ActionSetMember);
STX_INTERF(ActionTargetPath);
STX_INTERF(ActionWith);
STX_INTERF(ActionToNumber);
STX_INTERF(ActionToString);
STX_INTERF(ActionTypeOf);
STX_INTERF(ActionAdd2);
STX_INTERF(ActionLess2);
STX_INTERF(ActionModulo);
STX_INTERF(ActionBitAnd);

STX_INTERF(ActionBitLShift);
STX_INTERF(ActionBitOr);
STX_INTERF(ActionBitRShift);
STX_INTERF(ActionBitURShift);
STX_INTERF(ActionBitXor);
STX_INTERF(ActionDecrement);
STX_INTERF(ActionIncrement);
STX_INTERF(ActionPushDuplicate);

STX_INTERF(ActionReturn);
STX_INTERF(ActionStackSwap);
STX_INTERF(ActionStoreRegister);
STX_INTERF(DoInitAction);
STX_INTERF(ActionInstanceOf);
STX_INTERF(ActionEnumerate2);
STX_INTERF(ActionStrictEquals);

STX_INTERF(ActionGreater);
STX_INTERF(ActionStringGreater);
STX_INTERF(ActionDefineFunction2);
STX_INTERF(ActionExtends);
STX_INTERF(ActionCastOp);
STX_INTERF(ActionImplementsOp);
STX_INTERF(ActionTry);
STX_INTERF(ActionThrow);

STX_INTERF(DoABC);
STX_INTERF(REGISTERPARAM);

STX_INTERF(DefineMorphShape);
STX_INTERF(DefineMorphShape2);
STX_INTERF(MORPHFILLSTYLE);
STX_INTERF(MORPHFILLSTYLEARRAY);
STX_INTERF(MORPHLINESTYLEARRAY);
STX_INTERF(MORPHGRADIENT);
STX_INTERF(MORPHGRADRECORD);

STX_INTERF(MORPHLINESTYLE);
STX_INTERF(MORPHLINESTYLE2);
STX_INTERF(SHAPE);

STX_INTERF(DefineFont);
STX_INTERF(DefineFontInfo);
STX_INTERF(DefineFontInfo2);
STX_INTERF(DefineFont2);
STX_INTERF(KERNINGRECORD);

STX_INTERF(DefineFont3);
STX_INTERF(DefineFontAlignZones);
STX_INTERF(ZONERECORD);
STX_INTERF(ZONEDATA);
STX_INTERF(DefineFontName);
STX_INTERF(DefineText);
STX_INTERF(TEXTRECORD);
STX_INTERF(GLYPHENTRY);
STX_INTERF(DefineText2);
STX_INTERF(DefineEditText);
STX_INTERF(CSMTextSettings);
STX_INTERF(DefineFont4);
STX_INTERF(FONTDATA);

STX_INTERF(DefineSound);
STX_INTERF(SOUNDINFO);
STX_INTERF(StartSound);
STX_INTERF(StartSound2);
STX_INTERF(SOUNDENVELOPE);
STX_INTERF(SoundStreamHead);
STX_INTERF(SoundStreamHead2);
STX_INTERF(SoundStreamBlock);
STX_INTERF(MP3STREAMSOUNDDATA);
STX_INTERF(MP3SOUNDDATA);
STX_INTERF(ADPCMSOUNDDATA);
STX_INTERF(ADPCMMONOPACKET);
STX_INTERF(ADPCMSTEREOPACKET);
STX_INTERF(MP3FRAME);
STX_INTERF(BUTTONRECORD);
STX_INTERF(DefineButton);
STX_INTERF(DefineButton2);
STX_INTERF(BUTTONCONDACTION);
STX_INTERF(DefineButtonCxform);
STX_INTERF(DefineButtonSound);
STX_INTERF(DefineSprite);

STX_INTERF(SCREENVIDEOPACKET);
STX_INTERF(IMAGEBLOCK);
STX_INTERF(DefineVideoStream);
STX_INTERF(DefineBinaryData);


typedef char* STRING;


struct RECORDHEADER{//  (short)
	u16 TagCodeAndLength;//  UI16 Upper 10 bits: tag type Lower 6 bits: tag length
};

struct RECORDHEADER2{
	u16 TagCodeAndLength;	// UI16 Tag type and length of 0x3F Packed together as in short header 	
	s32 Length;				// SI32 Length of tag
};



swf_base_begin(swf_rect)
	b32	Nbits;	//UB[5] Bits used for each subsequent field
	s32 Xmin;	//SB[Nbits] x minimum position for rectangle in twips
	s32 Xmax;	//SB[Nbits] x maximum position for rectangle in twips
	s32 Ymin;	//SB[Nbits] y minimum position for rectangle in twips
	s32 Ymax;	//SB[Nbits] y maximum position for rectangle in twips
swf_base_end();

swf_base_begin(swf_rgba)
	u8 red;
	u8 green;
	u8 blue;
	u8 alpha;
swf_base_end();

swf_base_begin(swf_argb)
	u8 alpha;
	u8 red;
	u8 green;
	u8 blue;
swf_base_end();

swf_base_begin(swf_rgb)
	u8 red;
	u8 green;
	u8 blue;
swf_base_end();

swf_base_begin(swf_fixed)
	u16		dec;
	u16		num;
swf_base_end();

swf_base_begin(swf_fixed8)
	u8		dec;
	u8		num;
swf_base_end();

swf_base_begin(swf_fill_style_solid)
	u16			 fillStyleType;
	swf_rgba	 color;
swf_base_end();

swf_base_begin(swf_line_style)
	u16			width;
	swf_rgba	color;
swf_base_end();

struct swf_file_attributes{
	b32 useDirectBlit;
	b32 useGPU;
	b32 hasMetaData;
	b32 useActionScript3;
	b32 useNetwork;
};

swf_base_begin(swf_style_change_record)
	b32 typeFlag;
	b32 stateNewStyles;
	b32 stateLineStyle;
	b32 stateFillStyle1;
	b32 stateFillStyle0;
	b32 stateMoveTo;
swf_base_end();


swf_base_begin(MATRIX)
	b32			HasScale;		// UB[1] Has scale values if equal to 1
	u32			NScaleBits;		// If HasScale = 1, UB[5] Bits in each scale value field
	u32			ScaleX;			// If HasScale = 1, FB[NScaleBits] x scale value
	u32			ScaleY;			// If HasScale = 1, FB[NScaleBits] y scale value
	b32			HasRotate;		// UB[1] Has rotate and skew values if equal to 1
	u32			NRotateBits;	// If HasRotate = 1, UB[5] Bits in each rotate value field
	u32			RotateSkew0;	// If HasRotate = 1, FB[NRotateBits] First rotate and skew value
	u32			RotateSkew1;	// If HasRotate = 1,FB[NRotateBits] Second rotate and skew value
	u32			NTranslateBits; // UB[5] Bits in each translate value field
	s32			TranslateX;		// SB[NTranslateBits] x translate value in twips
	s32			TranslateY;		// SB[NTranslateBits] y translate value in twips
swf_base_end();


swf_base_begin(CXFORM)
	b32			HasAddTerms;	// UB[1] Has color addition values if equal to 1
	b32			HasMultTerms;	// UB[1] Has color multiply values if equal to 1
	u16			Nbits;			// UB[4] Bits in each value field
	s16			RedMultTerm;	// If HasMultTerms = 1, SB[Nbits] Red multiply value
	s16			GreenMultTerm;	// If HasMultTerms = 1, SB[Nbits] Green multiply value
	s16			BlueMultTerm;	// If HasMultTerms = 1, SB[Nbits] Blue multiply value
	s16			RedAddTerm;		// If HasAddTerms = 1, SB[Nbits] Red addition value
	s16			GreenAddTerm;	// If HasAddTerms = 1, SB[Nbits] Green addition value
	s16			BlueAddTerm;	// If HasAddTerms = 1, SB[Nbits] Blue addition value
swf_base_end();


swf_base_begin(GRADRECORD,s32 ishape)
	u8 Ratio; // UI8 Ratio value 
	union{
		swf_rgb		rgb;
		swf_rgba	rgba;
	}Color;//  RGB (Shape1 or Shape2) RGBA (Shape3) Color of gradient
swf_base_end();

swf_base_begin(FOCALGRADIENT,s32 ishape)
	u8			SpreadMode;			//UB[2] 0 = Pad mode
	// 1 = Reflect mode
	// 2 = Repeat mode
	// 3 = Reserved
	u8			InterpolationMode;	// UB[2] 0 = Normal RGB mode interpolation
	// 1 = Linear RGB mode interpolation
	// 2 and 3 = Reserved
	u8			NumGradients;		// UB[4] 1 to 15
	GRADRECORD* GradientRecords;	//  GRADRECORD[nGrads] Gradient records (see following)
	swf_fixed8	FocalPoint;			// FIXED8 Focal point location
swf_base_end();


swf_base_begin(GRADIENT,s32 ishape)
	u8			SpreadMode;	//  UB[2] 0 = Pad mode
	// 1 = Reflect mode
	// 2 = Repeat mode
	// 3 = Reserved
	u8			InterpolationMode;	//  UB[2] 0 = Normal RGB mode interpolation 1 = Linear RGB mode interpolation
	// 2 and 3 = Reserved
	u8			NumGradients;		//  UB[4] 1 to 15
	GRADRECORD* GradientRecords;//  GRADRECORD[nGrads] Gradient records (see following)
swf_base_end();

swf_base_begin(FILLSTYLE,s32 ishape)
	u8			FillStyleType;	// UI8 Type of fill style:
	// 0x00 = solid fill
	// 0x10 = linear gradient fill
	// 0x12 = radial gradient fill
	// 0x13 = focal radial gradient fill(SWF 8 file format and later only)
	// 0x40 = repeating bitmap fill
	// 0x41 = clipped bitmap fill
	// 0x42 = non-smoothed repeating bitmap
	// 0x43 = non-smoothed clipped bitmap
	swf_rgba	Color;			// If type = 0x00, RGBA (if Shape3);
	swf_rgb		rgb;			// (if Shape1 or Shape2) Solid fill color with opacity information.
	MATRIX		GradientMatrix;	//  If type = 0x10, 0x12, or 0x13,Matrix for gradient fill.
	union {
		GRADIENT		grade;	// 	If type = 0x10 or 0x12, GRADIENT  Gradient fill.
		FOCALGRADIENT	focal;	//	If type = 0x13, FOCALGRADIENT(SWF 8 and later only)
	}Gradient;

	u16			BitmapId;		// If type = 0x40, 0x41, 0x42 or 0x43,UI16 ID of bitmap character for fill.
	MATRIX		BitmapMatrix;	// If type = 0x40, 0x41, 0x42 or 0x43, Matrix for bitmap

swf_base_end();


swf_base_begin(LINESTYLEARRAY,s32 ishape)
	u32			LineStyleCount; // UI8 Count of line styles.
	u16			LineStyleCountExtended; // If LineStyleCount = 0xFF, UI16 Extended count of line styles.
	union{
		LINESTYLE* ls;			// If Shape1, Shape2, or Shape3,LINESTYLE[count]
		LINESTYLE2* ls2;		// If Shape4,LINESTYLE2[count]
	}LineStyles;						
swf_base_end();


swf_base_begin(LINESTYLE,s32 ishape)
	u16				Width;	// UI16 Width of line in twips.
	union {
		swf_rgb		rgb;	// Color RGB (Shape1 or Shape2) RGBA (Shape3)
		swf_rgba	rgba;
	}Color;					// Color value including alpha channel information for Shape3.
swf_base_end();


swf_base_begin(LINESTYLE2)
	u16 Width;				//	UI16 Width of line in twips.
	u8	StartCapStyle;		//  UB[2] Start cap style:
	// 0 = Round cap
	// 1 = No cap
	// 2 = Square cap
	u8	JoinStyle;			// UB[2] Join style:
	// 0 = Round join
	// 1 = Bevel join
	// 2 = Miter join
	b32 HasFillFlag;		//  UB[1] If 1, fill is defined in FillType. If 0, uses Color field.
	b32 NoHScaleFlag;		// UB[1] If 1, stroke thickness will not scale if the object is scaled horizontally.
	b32 NoVScaleFlag;		// UB[1] If 1, stroke thickness will not scale if the object is scaled vertically.
	b32 PixelHintingFlag;	//  UB[1] If 1, all anchors will be aligned to full pixels.
	// Reserved UB[5] Must be 0.
	b32	NoClose;			// UB[1] If 1, stroke will not be closed if the stroke��s last point matches its first point. 
	// Flash Player will apply caps instead of a join.
	u8	EndCapStyle;			//  UB[2] End cap style:
	// 0 = Round cap
	// 1 = No cap
	// 2 = Square cap
	u16			MiterLimitFactor;	//  If JoinStyle = 2, UI16 Miter limit factor is an 8.8 fixed-point value.
	swf_rgba	Color;				// Color If HasFillFlag = 0, RGBA Color value including alpha channel.
	FILLSTYLE	FillType;			// If HasFillFlag = 1, FILLSTYLE Fill style for this stroke.
swf_base_end();

swf_base_begin(FILLSTYLEARRAY,s32 ishape)
	u32				FillStyleCount;		//  UI8 Count of fill styles.
	//  If FillStyleCount = 0xFF, UI16 Extended count of fill styles. 
	//  Supported only for Shape2 and Shape3.
	u16				FillStyleCountExtended;	
	FILLSTYLE*		FillStyles;			//  FILLSTYLE[FillStyleCount] Array of fill styles.
swf_base_end();


swf_base_begin(FILTER)
swf_base_end();


swf_base_begin(GRADIENTBEVELFILTER)
	u8			NumColors;			//UI8 Number of colors in the gradient
	swf_rgba*	GradientColors;		//RGBA[NumColors] Gradient colors
	u8*			GradientRatio;		//UI8[NumColors] Gradient ratios
	swf_fixed	BlurX;				//FIXED Horizontal blur amount
	swf_fixed	BlurY;				//FIXED Vertical blur amount
	swf_fixed	Angle;				//FIXED Radian angle of the gradient bevel
	swf_fixed	Distance;			//FIXED Distance of the gradient bevel
	swf_fixed8	Strength;			//FIXED8 Strength of the gradient bevel
	b32			InnerShadow;		//UB[1] Inner bevel mode Knockout UB[1] Knockout mode
	b32			CompositeSource;	//UB[1] Composite source Always 1
	b32			OnTop;				//UB[1] OnTop mode
	u8			Passes;				//UB[4] Number of blur passes
swf_base_end();


swf_base_begin(GRADIENTGLOWFILTER)
	u8				NumColors;		// 	 UI8 Number of colors in the gradient
	swf_rgba*		GradientColors;	// 	 RGBA[NumColors] Gradient colors
	u8*				GradientRatio;	// 	 UI8[NumColors] Gradient ratios
	swf_fixed		BlurX;			// 	 FIXED Horizontal blur amount
	swf_fixed		BlurY;			// 	 FIXED Vertical blur amount
	swf_fixed		Angle;			// 	 FIXED Radian angle of the gradient glow
	swf_fixed		Distance;		// 	 FIXED Distance of the gradient glow
	swf_fixed8		Strength;		// 	 FIXED8 Strength of the gradient glow
	b32				InnerShadow;	// 	 UB[1] Inner glow mode
	b32				Knockout;		// 	 UB[1] Knockout mode
	b32				CompositeSource;// 	 UB[1] Composite source Always 1
	b32				OnTop;			// 	 UB[1] OnTop mode
	u8				Passes;			// 	 UB[4] Number of blur passes
swf_base_end();


swf_base_begin(BEVELFILTER)
	swf_rgba		ShadowColor;		// 	 RGBA Color of the shadow
	swf_rgba		HighlightColor;		// 	 RGBA Color of the highlight
	swf_fixed		BlurX;				// 	 FIXED Horizontal blur amount
	swf_fixed		BlurY;				// 	 FIXED Vertical blur amount
	swf_fixed		Angle;				// 	 FIXED Radian angle of the drop shadow
	swf_fixed		Distance;			// 	 FIXED Distance of the drop shadow
	swf_fixed8		Strength;			// 	 FIXED8 Strength of the drop shadow
	b32				InnerShadow;		// 	 UB[1] Inner shadow mode
	b32				Knockout;			// 	 UB[1] Knockout mode
	b32				CompositeSource;	// 	 UB[1] Composite source Always 1
	b32				OnTop;				// 	 UB[1] OnTop mode
	u8				Passes;				// 	 UB[4] Number of blur passes
swf_base_end();


swf_base_begin(GLOWFILTER)
	swf_rgba		GlowColor;			//  RGBA Color of the shadow
	swf_fixed		BlurX;				//	FIXED Horizontal blur amount
	swf_fixed		BlurY;				//  FIXED Vertical blur amount
	swf_fixed8		Strength;			//  FIXED8 Strength of the glow
	b32				InnerGlow;			//  UB[1] Inner glow mode
	b32				Knockout;			//  UB[1] Knockout mode
	b32				CompositeSource;	//	UB[1] Composite source Always 1
	u8				Passes;				//	UB[5] Number of blur
swf_base_end();


swf_base_begin(DROPSHADOWFILTER)
	swf_rgba	DropShadowColor;	//  RGBA Color of the shadow
	swf_fixed	BlurX;				//  FIXED Horizontal blur amount
	swf_fixed	BlurY;				//  FIXED Vertical blur amount
	swf_fixed	Angle;				//  FIXED Radian angle of the drop shadow
	swf_fixed	Distance;			//  FIXED Distance of the drop shadow
	swf_fixed8	Strength;			//  FIXED8 Strength of the drop shadow
	b32			InnerShadow;		//  UB[1] Inner shadow mode 
	b32			Knockout;			//  UB[1] Knockout mode
	b32			CompositeSource;	//  UB[1] Composite source Always 1
	u8			Passes;				//  UB[5] Number of blur passes
swf_base_end();


swf_base_begin(BLURFILTER)
	swf_fixed	BlurX;			//  FIXED Horizontal blur amount
	swf_fixed	BlurY;			// FIXED Vertical blur amount
	u8			Passes;			//  UB[5] Number of blur passes
	// Reserved UB[3] Must be 0
swf_base_end();


swf_base_begin(CONVOLUTIONFILTER)
	u8			MatrixX;		// UI8 Horizontal matrix size
	u8			MatrixY;		// UI8 Vertical matrix size
	f32			Divisor;		//  FLOAT Divisor applied to the matrix values
	f32			Bias;			//  FLOAT Bias applied to the matrix values
	f32*		Matrix;			//  FLOAT[MatrixX * MatrixY] Matrix values
	swf_rgba	DefaultColor;	// RGBA Default color for pixels outside the image
	// Reserved UB[6] Must be 0
	b32			Clamp;			//  UB[1] Clamp mode
	b32			PreserveAlpha;	// UB[1] Preserve the alpha
swf_base_end();


swf_base_begin(COLORMATRIXFILTER)
	f32 Matrix[20]; // FLOAT[20] Color matrix values
swf_base_end();


swf_tag_begin(DefineBitsJPEG4,u32 tag,u32 len)
	// 	Header RECORDHEADER (long) Tag type = 90.
	//u16 CharacterID;		// 	 UI16 ID for this character.
	u32 AlphaDataOffset;	// 	 UI32 Count of bytes in ImageData.
	u16 DeblockParam;		// 	 UI16 Parameter to be fed into the deblocking filter. The parameter
	// 	describes a relative strength of the deblocking filter from 0-100% expressed in a
	// 	normalized 8.8 fixed point format.
	u8* ImageData;			// 	 UI8[data size] Compressed image data in either JPEG, PNG, or GIF89a format.
	u8* BitmapAlphaData;	// 	 UI8[alpha data size] ZLIB compressed array OF alpha data. Only supported
	// 	when tag contains JPEG data. One byte per pixel. Total size after decompression must
	// 	equal (width * height) of JPEG image.
swf_tag_end();



swf_base_begin(ALPHABITMAPDATA,s32 i_size,s32 i_bmpfmt)
	s32			i_fmt;
	swf_argb*	BitmapPixelData;		//  ARGB[image data size] Array of pixel colors. Number of
	// entries is BitmapWidth * BitmapHeight. The RGB data must already be multiplied by
	// the alpha channel value
swf_base_end();

swf_base_begin(ALPHACOLORMAPDATA,s32 i_table,s32 i_data)
	swf_rgba* ColorTableRGB;	//  RGBA[color table size] Defines the mapping from color
								// indices to RGBA values.Number of RGBA values is BitmapColorTableSize + 1.
	u8* ColormapPixelData;		//  UI8[image data size] Array of color indices. Number
	// of entries is BitmapWidth * BitmapHeight, subject to padding (see note preceding this table).
swf_base_end();


swf_tag_begin(DefineBitsLossless2,u32 tag,u32 len)
	// 	Header RECORDHEADER (long) Tag type = 36
	//u16		CharacterID;	 	 UI16 ID for this character
	u8		BitmapFormat;	// 	 UI8 Format of compressed data
							// 				3 = 8-bit colormapped image
							// 				5 = 32-bit ARGB image
	u16		BitmapWidth;	// 		UI16 Width of bitmap image
	u16		BitmapHeight;	// 		UI16 Height of bitmap image
	u8		BitmapColorTableSize;// 	 If BitmapFormat = 3, UI8	Otherwise absent
	// 	This value is one less than the	actual number of colors in the	color table, allowing for up to	256 colors.
	ALPHABITMAPDATA ZlibBitmapData;	// 	 If BitmapFormat = 3,	ALPHACOLORMAPDATA
	// 	If BitmapFormat = 4 or 5,ALPHABITMAPDATA ZLIB compressed bitmap data
swf_tag_end();

swf_base_begin(PIX24)
	u8 Pix24Reserved;	// UI8 Always 0
	u8 Pix24Red;		// UI8 Red value
	u8 Pix24Green;		// UI8 Green value
	u8 Pix24Blue;		// UI8 Blue value
swf_base_end();

swf_base_begin(PIX15)
	b32		Pix15Reserved;	//  UB[1] Always 0
	u8		Pix15Red;		//  UB[5] Red value
	u8		Pix15Green;		//  UB[5] Green value
	u8		Pix15Blue;		//  UB[5] Blue value
swf_base_end();


swf_base_begin(BITMAPDATA,s32 i_fmt,s32 i_data)
	union{
		PIX15* p15;// 	 If BitmapFormat = 4,PIX15[image data size]
		PIX24* p24;// 	If BitmapFormat = 5,PIX24[image data size]
	}BitmapPixelData;
	// 	Array of pixel colors. Number of entries is BitmapWidth *
	// 	BitmapHeight, subject to padding (see note above).
swf_base_end();


swf_base_begin(COLORMAPDATA,s32 i_table,s32 i_data)
	swf_rgb*	ColorTableRGB;		// RGB[color table size] Defines the mapping from color
									// indices to RGB values. Number of RGB values is BitmapColorTableSize + 1.
	u8*			ColormapPixelData;	//  UI8[image data size] Array of color indices. Number
									// of entries is BitmapWidth * BitmapHeight, subject to
									// padding (see note preceding this table).
swf_base_end();



swf_tag_begin(DefineBitsLossless,u32 tag,u32 len)
	// 	Header RECORDHEADER (long) Tag type = 20
	//u16		CharacterID;	// 	 UI16 ID for this character
	u8		BitmapFormat;	// 	 UI8 Format of compressed data
							// 	3 = 8-bit colormapped image
							// 	4 = 15-bit RGB image
							// 	5 = 24-bit RGB image
	u16		BitmapWidth;	// 	 UI16 Width of bitmap image
	u16		BitmapHeight;	// 	 UI16 Height of bitmap image
	u8		BitmapColorTableSize;	// 	 If BitmapFormat = 3, UI8 Otherwise absent
									// 	This value is one less than the actual number of colors in the
									// 	color table, allowing for up to 256 colors.
	union{
		COLORMAPDATA clr;// 	 If BitmapFormat = 3, COLORMAPDATA
		BITMAPDATA	 bmp;// 	If BitmapFormat = 4 or 5, BITMAPDATA ZLIB compressed bitmap data		
	}ZlibBitmapData;
swf_tag_end();


swf_tag_begin(DefineBitsJPEG2,u32 tag,u32 len)
	// Header RECORDHEADER (long) Tag type = 21
	//u16 CharacterID;	//  UI16 ID for this character
	u8* ImageData;		//  UI8[data size] Compressed image data in either JPEG, PNG, or GIF89a format
swf_tag_end();


swf_tag_begin(DefineBitsJPEG3,u32 tag,u32 len)
	// Header RECORDHEADER (long) Tag type = 35.
	//u16		CharacterID;		//  UI16 ID for this character.
	u32		AlphaDataOffset;	//  UI32 Count of bytes in ImageData.
	u8*		ImageData;			//  UI8[data size] Compressed image data in either JPEG, PNG, or GIF89a format
	u8*		BitmapAlphaData;	//  UI8[alpha data size] ZLIB compressed array OF alpha data. Only supported
	// when tag contains JPEG data. One byte per pixel. Total size after decompression must
	// equal (width * height) of JPEG image.
swf_tag_end();



swf_tag_begin(JPEGTables,u32 tag,u32 len)
	// Header RECORDHEADER Tag type = 8
	u8* JPEGData;// JPEGData UI8[encoding data size] JPEG encoding table
swf_tag_end();

swf_tag_begin(DefineBits,u32 tag,u32 len)
	// Header RECORDHEADER (long) Tag type = 6
	//u16 CharacterID;	// UI16 ID for this character
	u8* JPEGData;		//  UI8[image data size] JPEG compressed image
swf_tag_end();



swf_base_begin(ShapeRecord)
	b32 TypeFlag;		// UB[1] This is an edge record. Always 1.
swf_base_end();

swf_base_begin(CurvedEdgeRecord)
	b32 TypeFlag;		// UB[1] This is an edge record. Always 1.
	b32 StraightFlag;	// UB[1] Curved edge. Always 0.
	u8	NumBits;		// UB[4] Number of bits per value (2 less than the actual number).
	s32 ControlDeltaX;	//  SB[NumBits+2] X control point change.
	s32 ControlDeltaY;	//  SB[NumBits+2] Y control point change.
	s32 AnchorDeltaX;	// SB[NumBits+2] X anchor point change.
	s32 AnchorDeltaY;	// SB[NumBits+2] Y anchor point change.
swf_base_end();

swf_base_begin(StraightEdgeRecord)
	b32 TypeFlag;			//  UB[1] This is an edge record.Always 1.
	b32 StraightFlag;		//  UB[1] Straight edge.Always 1.
	u8	NumBits;			//  UB[4] Number of bits per value(2 less than the actual number).
	b32 GeneralLineFlag;	//  UB[1] General Line equals 1.Vert/Horz Line equals 0.
	b32 VertLineFlag;		//  If GeneralLineFlag = 0,SB[1] Vertical Line equals 1.Horizontal Line equals 0.
	s32	DeltaX;				// If GeneralLineFlag = 1 or if VertLineFlag = 0,SB[NumBits+2]X delta.
	s32 DeltaY;				// If GeneralLineFlag = 1 or if VertLineFlag = 1,SB[NumBits+2]Y
swf_base_end();


swf_base_begin(StyleChangeRecord,s32 ishape,s32* LineBits,s32* FillBits)
	b32 TypeFlag;				//   UB[1] Non-edge record flag.Always 0.
	b32 StateNewStyles;			// 	 UB[1] New styles flag. Used by DefineShape2 and DefineShape3 only.
	b32 StateLineStyle;			// 	 UB[1] Line style change flag.
	b32 StateFillStyle1;		// 	 UB[1] Fill style 1 change flag.
	b32 StateFillStyle0;		// 	 UB[1] Fill style 0 change flag.
	b32 StateMoveTo;			// 	 UB[1] Move to flag.
	u8  MoveBits;				// 	 If StateMoveTo, UB[5] Move bit count.
	s32 MoveDeltaX;				// 	 If StateMoveTo, SB[MoveBits] Delta X value.
	s32 MoveDeltaY;				// 	 If StateMoveTo, SB[MoveBits] Delta Y value.
	u32 FillStyle0;				// 	 If StateFillStyle0, UB[FillBits] Fill 0 Style.
	u32 FillStyle1;				// 	 If StateFillStyle1, UB[FillBits] Fill 1 Style.
	u32 linestyles;				// 	 If StateLineStyle, UB[LineBits] Line Style.
	FILLSTYLEARRAY FillStyles;	// 	 If StateNewStyles,	Array of new fill styles.
	LINESTYLEARRAY LineStyles;	// 	 If StateNewStyles,	Array of new line styles.
	u8 NumFillBits;				// 	 If StateNewStyles, UB[4] Number of fill index bits for new styles.
	u8 NumLineBits;				// 	 If StateNewStyles, UB[4] Number of line index bits for new styles.
swf_base_end();

swf_base_begin(EndShapeRecord)
	b32		TypeFlag;			//  UB[1] Non-edge record flag.Always 0.
	u8		EndOfShape;			//  UB[5] End of shape flag.Always 0.
swf_base_end();


swf_base_begin(SHAPE,s32 ishape)
	s32				i_max;
	s32				i_rec;
	s32				NumFillBits;		// UB[4] Number of fill index bits.
	s32				NumLineBits;		// UB[4] Number of line index bits.
	ShapeRecord**	ShapeRecords;		// SHAPERECORD[one or more] Shape records (see following).
swf_base_end();


swf_base_begin(SHAPEWITHSTYLE,s32 ishape)
	s32				i_max;
	s32				i_rec;
	FILLSTYLEARRAY	FillStyles;		// 	  Array of fill styles.
	LINESTYLEARRAY	LineStyles;		// 	  Array of line styles.
	s32				NumFillBits;	// 	 UB[4] Number of fill index bits.
	s32				NumLineBits;	// 	 UB[4] Number of line index bits.
	ShapeRecord**	ShapeRecords;	// 	 [one or more] Shape records (see following).
swf_base_end();


swf_tag_begin(DefineShape,u32 tag,u32 len)
	// Header RECORDHEADER Tag type = 2.
	//u16				ShapeId;		// UI16 ID for this character.
	swf_rect		ShapeBounds;	//  RECT Bounds of the shape.
	SHAPEWITHSTYLE	Shapes;			//  Shape information.
swf_tag_end();

swf_tag_begin(DefineShape2,u32 tag,u32 len)
	// Header RECORDHEADER Tag type = 22.
	//u16				ShapeId;			// UI16 ID for this character.
	swf_rect		ShapeBounds;		// RECT Bounds of the shape.
	SHAPEWITHSTYLE	Shapes;				//  Shape information
swf_tag_end();


swf_tag_begin(DefineShape3,u32 tag,u32 len)
	// Header RECORDHEADER Tag type = 32.
	//u16				ShapeId;		// 		UI16 ID for this character.
	swf_rect		ShapeBounds;	// 	RECT Bounds of the shape.
	SHAPEWITHSTYLE	Shapes;			//  Shape information.
swf_tag_end();


swf_tag_begin(DefineShape4,u32 tag,u32 len)
	// Header RECORDHEADER Tag type = 83.
	u16				ShapeId; // UI16 ID for this character.
	swf_rect		ShapeBounds;//  RECT Bounds of the shape.
	swf_rect		EdgeBounds;//  RECT Bounds of the shape, excluding strokes.
	// Reserved UB[5] Must be 0.
	b32				UsesFillWindingRule;//  UB[1] If 1, use fill winding rule. Minimum file format version is SWF 10
	b32				UsesNonScalingStrokes;//  UB[1] If 1, the shape contains at least one non-scaling stroke.
	b32				UsesScalingStrokes;//  UB[1] If 1, the shape contains at least one scaling stroke.
	SHAPEWITHSTYLE	Shapes;//  SHAPEWITHSTYLE Shape information.
swf_tag_end();

swf_tag_begin(DefineSprite,u32 tag,u32 len)
	//RECORDHEADER header;	// Tag type = 39
	u16		Sprite;			// ID UI16 Character ID of sprite
	u16		FrameCount;		// UI16 Number of frames in sprite
	u8*		ControlTags;	// TAG[one or more] A series of tags
swf_tag_end();


struct swf_header{
	s32			Signature;
	s32			Version;
	s32			FileLength;
	RECT		FrameSize;		//  Frame size in twips
	f32			FrameRate; 		//	Frame delay in 8.8 fixed number of frames per second.
	u16			FrameCount;		//  Total number of frames in file
};


swf_tag_begin(PlaceObject,u32 tag,u32 len)
	//Header RECORDHEADER Tag type = 4
	u16		CharacterId;		//UI16 ID of character to place
	u16		Depth;				//UI16 Depth of character
	MATRIX	Matrix;				//MATRIX Transform matrix data
	CXFORM	ColorTransform;		//(optional) CXFORM Color transform data
swf_tag_end();


swf_base_begin(CXFORMWITHALPHA)
	b32		HasAddTerms;		// UB[1] Has color addition values if equal to 1
	b32		HasMultTerms;		// UB[1] Has color multiply values if equal to 1
	u16		Nbits;				// UB[4] Bits in each value field
	s16		RedMultTerm;		// If HasMultTerms = 1, SB[Nbits] Red multiply value
	s16		GreenMultTerm;		// If HasMultTerms = 1, SB[Nbits] Green multiply value
	s16		BlueMultTerm;		// If HasMultTerms = 1, SB[Nbits] Blue multiply value
	s16		AlphaMultTerm;		// If HasMultTerms = 1, SB[Nbits] Alpha multiply value
	s16		RedAddTerm;			// If HasAddTerms = 1, SB[Nbits] Red addition value
	s16		GreenAddTerm;		// If HasAddTerms = 1, SB[Nbits] Green addition value
	s16		BlueAddTerm;		// If HasAddTerms = 1, SB[Nbits] Blue addition value
	s16		AlphaAddTerm;		// If HasAddTerms = 1, SB[Nbits] Transparency addition value
swf_tag_end();

swf_base_begin(CLIPEVENTFLAGS)
	b32 ClipEventKeyUp;				// UB[1] Key up event
	b32 ClipEventKeyDown;			// UB[1] Key down event
	b32 ClipEventMouseUp;			// UB[1] Mouse up event
	b32 ClipEventMouseDown;			// UB[1] Mouse down event
	b32 ClipEventMouseMove;			// UB[1] Mouse move event
	b32 ClipEventUnload;			// UB[1] Clip unload event
	b32 ClipEventEnterFrame;		// UB[1] Frame event
	b32 ClipEventLoad;				// UB[1] Clip load event
	b32 ClipEventDragOver;			// UB[1] SWF 6 and later: mouse	drag over event Otherwise: always 0
	b32 ClipEventRollOut;			// UB[1] SWF 6 and later: mouse   rollout eventOtherwise: always 0
	b32 ClipEventRollOver;			// UB[1] SWF 6 and later: mouse   rollover eventOtherwise: always 0
	b32 ClipEventReleaseOutside;	// UB[1] SWF 6 and later: mouse  release outside event Otherwise: always 0.
	b32 ClipEventRelease;			// UB[1] SWF 6 and later: mouse release inside event Otherwise: always 0
	b32 ClipEventPress;				// UB[1] SWF 6 and later: mouse press event Otherwise: always 0
	b32 ClipEventInitialize;		// UB[1] SWF 6 and later: initialize event Otherwise: always 0
	b32 ClipEventData;				// UB[1] Data received event
	u8  rb5;						// Reserved If SWF version >= 6, UB[5] Always 0
	b32 ClipEventConstruct;			// If SWF version >= 6, UB[1] SWF 7 and later: construct   event Otherwise: always 0
	b32 ClipEventKeyPress;			// If SWF version >= 6, UB[1] Key press event
	b32 ClipEventDragOut;			// If SWF version >= 6, UB[1] Mouse drag out event
	u8  rb8;						// Reserved If SWF version >= 6, UB[8] Always 0
swf_base_end();


swf_base_begin(ACTIONRECORDHEADER)
	u8		ActionCode;	//  UI8 An action code
	u16		Length;		//  If code >= 0x80, UI16 The number of bytes in the ACTIONRECORDHEADER, not
						// counting the ActionCode and Length fields
swf_tag_end();


//{{ action of swf3;
swf_action_begin(ActionGotoFrame,u32 tag,u32 len)
	//ACTIONRECORDHEADER	header;	// ActionGotoFrame  ActionCode = 0x81; Length is always 2
	u16					Frame;	//  UI16 Frame index
swf_action_end();

swf_action_begin(ActionGetURL,u32 tag,u32 len)
	//ACTIONRECORDHEADER	header;					//	ActionGotoFrame  ActionCode = 0x83;
	STRING				UrlString;				//	Target URL string
	STRING				TargetString;			//	Target string
swf_action_end();

swf_action_begin(ActionNextFrame,u32 tag,u32 len)
	//ACTIONRECORDHEADER	header; //ACTIONRECORDHEADER ActionCode = 0x04
swf_action_end();

swf_action_begin(ActionPreviousFrame,u32 tag,u32 len)
	//ACTIONRECORDHEADER	header; //ACTIONRECORDHEADER ActionCode = 0x05
swf_action_end();

swf_action_begin(ActionPlay,u32 tag,u32 len)
	//ACTIONRECORDHEADER	header; //ACTIONRECORDHEADER ActionCode = 0x06
swf_action_end();

swf_action_begin(ActionStop,u32 tag,u32 len)
	//ACTIONRECORDHEADER	header; //ACTIONRECORDHEADER ActionCode = 0x07
swf_action_end();

swf_action_begin(ActionToggleQuality,u32 tag,u32 len)
	//ACTIONRECORDHEADER	header; //ACTIONRECORDHEADER ActionCode = 0x08
swf_action_end();

swf_action_begin(ActionStopSounds,u32 tag,u32 len)
	//ACTIONRECORDHEADER	header; //ACTIONRECORDHEADER ActionCode = 0x09
swf_action_end();


swf_action_begin(ActionWaitForFrame,u32 tag,u32 len)
	//ACTIONRECORDHEADER	header;		//ACTIONRECORDHEADER ActionCode = 0x8a
	u16					Frame;		//UI16 Frame to wait for
	u8					SkipCount;	//UI8 Number of actions to skip if frame is not loaded
swf_action_end();

swf_action_begin(ActionSetTarget,u32 tag,u32 len)
	//ACTIONRECORDHEADER	header;		//ACTIONRECORDHEADER ActionCode = 0x8B
	STRING				TargetName; //Target of action target
swf_action_end();

swf_action_begin(ActionGoToLabel,u32 tag,u32 len)
	//ACTIONRECORDHEADER	header;		//ActionCode = 0x8C
	STRING				Label;		//Frame label
swf_action_end();
//}} action of swf3;



//{{ action of swf4
swf_action_begin(ActionPush,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionPush ACTIONRECORDHEADER ActionCode = 0x96
	u8 Type; 
	union{
		// String If Type = 0, STRING Null-terminated character string
		STRING  str_v0;			//  UI8 0 = string literal
		// Float If Type = 1, FLOAT 32-bit IEEE single-precision little-endian floating-point value
		f32		f32_v1;			// 1 = floating-point literal
		// The following types are available in SWF5 and later:
		THEE    null_v2;		// 2 = null
		size_t  undef_v3;		// 3 = undefined

		// RegisterNumber If Type = 4, UI8 Register number
		u8		reg_v4;			// 4 = register

		// 	Boolean If Type = 5, UI8 Boolean value
		b32		b32_v5;			// 5 = Boolean
		// 	Double If Type = 6, DOUBLE 64-bit IEEE double-precision LITTLEENDIAN double value
		f64     f64_v6;			// 6 = double
		// 	Integer If Type = 7, UI32 32-bit little-endian integer
		s32		s32_v7;			// 7 = integer
		// 	Constant8 If Type = 8, UI8 Constant pool index (for indexes < 256)		(see ActionConstantPool)
		u8		u8_v8;			// 8 = constant 8
		// 	Constant16 If Type = 9, UI16 Constant pool index (for indexes >= 256)		(see ActionConstantPool)
		u16		u16_v9;			// 9 = constant 16
	}value;	
swf_action_end();


swf_action_begin(ActionPop,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionPop ACTIONRECORDHEADER ActionCode = 0x17
swf_action_end();

swf_action_begin(ActionAdd,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionAdd ACTIONRECORDHEADER ActionCode = 0x0A
swf_action_end();

swf_action_begin(ActionSubtract,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionSubtract ACTIONRECORDHEADER ActionCode = 0x0B
swf_action_end();

swf_action_begin(ActionMultiply,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionMultiply ACTIONRECORDHEADER ActionCode = 0x0C
swf_action_end();

swf_action_begin(ActionDivide,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; // ActionCode = 0x0D
swf_action_end();

swf_action_begin(ActionEquals,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x0E
swf_action_end();

swf_action_begin(ActionLess,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x0F
swf_action_end();

swf_action_begin(ActionAnd,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x10
swf_action_end();

swf_action_begin(ActionOr,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x11
swf_action_end();

swf_action_begin(ActionNot,u32 tag,u32 len)
	//ACTIONRECORDHEADER	header; //ActionCode = 0x12
	b32					Result; // Boolean
swf_action_end();

swf_action_begin(ActionStringEquals,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x13
swf_action_end();

swf_action_begin(ActionStringLength,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x14
swf_action_end();

swf_action_begin(ActionStringAdd,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x21
swf_action_end();

swf_action_begin(ActionStringExtract,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x15
swf_action_end();

swf_action_begin(ActionStringLess,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x29
swf_action_end();

swf_action_begin(ActionMBStringLength,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x31
swf_action_end();

swf_action_begin(ActionMBStringExtract,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x35
swf_action_end();

swf_action_begin(ActionToInteger,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x18
swf_action_end();

swf_action_begin(ActionCharToAscii,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; // ActionCode = 0x32
swf_action_end();

swf_action_begin(ActionAsciiToChar,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x33
swf_action_end();

swf_action_begin(ActionMBCharToAscii,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x36
swf_action_end();

swf_action_begin(ActionMBAsciiToChar,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x37
swf_action_end();

swf_action_begin(ActionJump,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x99
	s16 BranchOffset; // SI16 Offset
swf_action_end();

swf_action_begin(ActionIf,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x9D
	s16 BranchOffset; // SI16 Offset
swf_action_end();

swf_action_begin(ActionCall,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x9E
swf_action_end();

swf_action_begin(ActionGetVariable,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x1C
swf_action_end();

swf_action_begin(ActionSetVariable,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x1D
swf_action_end();

swf_action_begin(ActionGetURL2,u32 tag,u32 len)
	//ACTIONRECORDHEADER header;	// ActionCode = 0x9A; Length is always 1
	u8 SendVarsMethod;			// UB[2] 0 = None	1 = GET 	2 = POST
	u8 Reserved;				// UB[4] Always 0
	b32 LoadTargetFlag;			// UB[1] 0 = Target is a browser window 1 = Target is a path to a sprite
	b32 LoadVariablesFlag;		// UB[1] 0 = No variables to load  1 = Load variables
swf_action_end();


swf_action_begin(ActionGotoFrame2,u32 tag,u32 len)
	//ACTIONRECORDHEADER	header;			// ActionCode = 0x9F
	u8					Reserved;		// UB[6] Always 0
	b32					SceneBiasFlag;	// UB[1] Scene bias flag
	b32					Playflag;		// UB[1] 0 = Go to frame and stop 	1 = Go to frame and play
	u16					SceneBias;		// If SceneBiasFlag = 1, UI16 Number to be added to frame determined by stack argument
swf_action_end();


swf_action_begin(ActionSetTarget2,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x20
swf_action_end();

swf_action_begin(ActionGetProperty,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x22
swf_action_end();

enum property{
	_X = 0, //0
	_Y,		//1
	_xscale, //2
	_yscale, //3
	_currentframe, //4
	_totalframes, //5
	_alpha, //6
	_visible, //7
	_width, //8
	_height, //9
	_rotation, // 10
	_target, // 11
	_framesloaded, // 12
	_name, // 13
	_droptarget, // 14
	_url, // 15
	_highquality, // 16
	_focusrect, // 17
	_soundbuftime, // 18
	_quality, // 19
	_xmouse, // 20
	_ymouse, // 21
};

swf_action_begin(ActionSetProperty,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x23
swf_action_end();

swf_action_begin(ActionCloneSprite,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x24
swf_action_end();

swf_action_begin(ActionRemoveSprite,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x25
swf_action_end();

swf_action_begin(ActionStartDrag,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x27
swf_action_end();

swf_action_begin(ActionEndDrag,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x28
swf_action_end();

swf_action_begin(ActionWaitForFrame2,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x8D; Length is always 1
	u8 SkipCount; // UI8 The number of actions to skip
swf_action_end();

swf_action_begin(ActionTrace,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x26
swf_action_end();

swf_action_begin(ActionGetTime,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x34
swf_action_end();

swf_action_begin(ActionRandomNumber,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x30
swf_action_end();

//}} action of swf4


//{{ action of swf5
swf_action_begin(ActionCallFunction,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x3D
swf_action_end();


swf_action_begin(ActionCallMethod,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x52
swf_action_end();


swf_action_begin(ActionConstantPool,u32 tag,u32 len)
	//ACTIONRECORDHEADER	header;			//ActionCode = 0x88
	u16					Count;			// UI16 Number of constants to follow
	STRING*				ConstantPool;	// STRING[Count] String constants
swf_action_end();


swf_action_begin(ActionDefineFunction,u32 tag,u32 len)
	//ACTIONRECORDHEADER	header;			//ActionCode = 0x9B
	STRING				FunctionName;	//  Function name, empty if anonymous
	u16					NumParams;		// UI16 # of parameters
	STRING*				param;			//Parameter name 1
										//Parameter name 2
										//...
										//param N STRING Parameter name N
	u16					codeSize;		// UI16 # of bytes of code that follow
	u8*					code;
swf_action_end();

swf_action_begin(ActionDefineLocal,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x3C
swf_action_end();

swf_action_begin(ActionDefineLocal2,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x41
swf_action_end();

swf_action_begin(ActionDelete,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x3A
swf_action_end();

swf_action_begin(ActionDelete2,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x3B
swf_action_end();

swf_action_begin(ActionEnumerate,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x46
swf_action_end();

swf_action_begin(ActionEquals2,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x49
swf_action_end();

swf_action_begin(ActionGetMember,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x4E
swf_action_end();

swf_action_begin(ActionInitArray,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x42
swf_action_end();

swf_action_begin(ActionInitObject,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x43
swf_action_end();

swf_action_begin(ActionNewMethod,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x53
swf_action_end();

swf_action_begin(ActionNewObject,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x40
swf_action_end();

swf_action_begin(ActionSetMember,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x4F
swf_action_end();

swf_action_begin(ActionTargetPath,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x45
swf_action_end();

swf_action_begin(ActionWith,u32 tag,u32 len)
	//ACTIONRECORDHEADER header;	//	ActionCode = 0x94
	u16 iSize;					//	UI16 # of bytes of code that follow
swf_action_end();

swf_action_begin(ActionToNumber,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x4A
swf_action_end();

swf_action_begin(ActionToString,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x4B
swf_action_end();

swf_action_begin(ActionTypeOf,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x44
swf_action_end();

swf_action_begin(ActionAdd2,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x47
swf_action_end();

swf_action_begin(ActionLess2,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x48
swf_action_end();

swf_action_begin(ActionModulo,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x3F
swf_action_end();

swf_action_begin(ActionBitAnd,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x60
swf_action_end();

swf_action_begin(ActionBitLShift,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x63
swf_action_end();

swf_action_begin(ActionBitOr,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x61
swf_action_end();

swf_action_begin(ActionBitRShift,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x64
swf_action_end();

swf_action_begin(ActionBitURShift,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x65
swf_action_end();

swf_action_begin(ActionBitXor,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x62
swf_action_end();

swf_action_begin(ActionDecrement,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x51
swf_action_end();

swf_action_begin(ActionIncrement,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x50
swf_action_end();

swf_action_begin(ActionPushDuplicate,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x4C
swf_action_end();

swf_action_begin(ActionReturn,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x3E
swf_action_end();

swf_action_begin(ActionStackSwap,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x4D
swf_action_end();

swf_action_begin(ActionStoreRegister,u32 tag,u32 len)
	//ACTIONRECORDHEADER	header;			//ActionCode = 0x87
	u8					RegisterNumber; //UI8
swf_action_end();


//}} action of swf5


//{{action of swf6

swf_tag_begin(DoInitAction,u32 tag,u32 len)
	//RECORDHEADER	Header;			//  Tag type = 59
	u16				SpriteID;		// UI16 Sprite to which these actions apply
	swf_action**	Actions;		// [zero or more] List of actions to perform
	u8				ActionEndFlag;	// UI8 Always set to 0
swf_tag_end();


swf_action_begin(ActionInstanceOf,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x54
swf_action_end();

swf_action_begin(ActionEnumerate2,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x55
swf_action_end();

swf_action_begin(ActionStrictEquals,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x66
swf_action_end();

swf_action_begin(ActionGreater,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x67
swf_action_end();

swf_action_begin(ActionStringGreater,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x68
swf_action_end();
//}} swf6 action;


//{{ swf7 action;
swf_base_begin(REGISTERPARAM)
	u8 Register;	//  UI8 For each parameter to the function,
					// a register can be specified.
					// If the register specified is zero, the
					// parameter is created as a variable
					// named ParamName in the activation
					// object, which can be referenced with
					// ActionGetVariable and
					// ActionSetVariable.
					// If the register specified is nonzero,
					// the parameter is copied into the
					// register, and it can be referenced
					// with ActionPush and
					// ActionStoreRegister, and no
					// variable is created in the activation
					// object.
	STRING ParamName; // Parameter name
swf_base_end();


swf_action_begin(ActionDefineFunction2,u32 tag,u32 len)
	//ACTIONRECORDHEADER	header;				// ActionCode = 0x8E
	STRING				FunctionName;		// Name of function, empty if anonymous
	u16					NumParams;			// UI16 # of parameters
	u8					RegisterCount;		// UI8 Number of registers to allocate, up to 255 registers (from 0 to 254)
	b32					PreloadParentFlag;	// UB[1] 0 = Don��t preload _parent into register 1 = Preload _parent into register
	b32					PreloadRootFlag;	// UB[1] 0 = Don��t preload _root into register 	1 = Preload _root into register
	b32					SuppressSuperFlag;	// UB[1] 0 = Create super variable 1 = Don��t create super variable

	// 	PreloadSuperFlag UB[1] 0 = Don��t preload super into		register		1 = Preload super into		register
	b32 PreloadSuperFlag;
	// 	SuppressArgumentsFlag UB[1] 0 = Create arguments		variable		1 = Don��t create arguments		variable
	b32 SuppressArgumentsFlag;
	// 	 UB[1] 0 = Don��t preload arguments		into register		1 = Preload arguments into		register
	b32 PreloadArgumentsFlag;
	// 	 UB[1] 0 = Create this variable		1 = Don��t create this variable
	b32 SuppressThisFlag;
	// 	 UB[1] 0 = Don��t preload this into		register		1 = Preload this into register
	b32 PreloadThisFlag;
	// 	Reserved UB[7] Always 0
	// 	 UB[1] 0 = Don��t preload _global		into register		1 = Preload _global into		register
	b32 PreloadGlobalFlag;
	REGISTERPARAM* Parameters;	// 	 REGISTERPARAM[NumParams] See REGISTERPARAM,		following
	u16 codeSize;// 	 UI16 # of bytes of code that follow
	// 
	u8 Register;	// 	 UI8 For each parameter to the function,
					// 		a register can be specified.
					// 		If the register specified is zero, the
					// 		parameter is created as a variable
					// 		named ParamName in the activation
					// 		object, which can be referenced with
					// 		ActionGetVariable and
					// 		ActionSetVariable.
					// 		If the register specified is nonzero,
					// 		the parameter is copied into the
					// 		register, and it can be referenced
					// 		with ActionPush and
					// 		ActionStoreRegister, and no
					// 		variable is created in the activation
					// 		object.
	STRING ParamName; // 	  Parameter name
swf_action_end();


swf_action_begin(ActionExtends,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x69
swf_action_end();

swf_action_begin(ActionCastOp,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x2B
swf_action_end();

swf_action_begin(ActionImplementsOp,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x2C
swf_action_end();

swf_action_begin(ActionTry,u32 tag,u32 len)
	//ACTIONRECORDHEADER header;	//ActionCode = 0x8F
								//Reserved UB[5] Always zero
	b32 CatchInRegisterFlag;	//UB[1] 0 - Do not put caught objectinto register (instead, store innamed variable)
								//1 - Put caught object into register (do not store in named variable)
	b32 FinallyBlockFlag;		// UB[1] 0 - No finally block 1 - Has finally block
	b32 CatchBlockFlag;			// UB[1] 0 - No catch block 1 - Has catch block
	u16 TrySize;				// UI16 Length of the try block
	u16 CatchSize;				// UI16 Length of the catch block
	u16 FinallySize;			// UI16 Length of the finally block
	STRING CatchName;			// If CatchInRegisterFlag = 0, Name of the catch variable
	u8 CatchRegister;			// If CatchInRegisterFlag = 1, UI8 Register to catch into
	u8* TryBody;				// UI8[TrySize] Body of the try block
	u8* CatchBody;				// UI8[CatchSize] Body of the catch block, if any
	u8* FinallyBody;			// UI8[FinallySize] Body of the finally block, if any
swf_action_end();

swf_action_begin(ActionThrow,u32 tag,u32 len)
	//ACTIONRECORDHEADER header; //ActionCode = 0x2A
swf_action_end();

//}} swf7 action;



//{{ swf9 action
swf_tag_begin(DoABC,u32 tag,u32 len)
	//RECORDHEADER Header; //  Tag type = 82
	u32 Flags;// UI32 A 32-bit flags value, which may contain the following bits set:
	//kDoAbcLazyInitializeFlag = 1:Indicates that the ABC block should not be executed immediately, but only parsed. 
	//	a later find def may cause its scripts to execute.
	STRING name; //  The name assigned to the byte code.
	u8* ABCData; // BYTE[] A block of .abc byte code to be parsed by the ActionScript 3.0virtual machine, up to the end of the tag.
swf_action_end();
//}} swf9 action



swf_base_begin(CLIPACTIONRECORD)
	s32				i_max;
	s32				i_act;
	CLIPEVENTFLAGS	EventFlags;			//Events to which this handler applies
	u32				ActionRecordSize;	//UI32 Offset in bytes from end of this field to next CLIPACTIONRECORD (or ClipActionEndFlag)
	s8				KeyCode;			//If EventFlags contain ClipEventKeyPress: UI8 Otherwise absent  Key code to trap (see ��DefineButton2�� on page 226)
	swf_action**	Actions;			//ACTIONRECORD [one or more] Actions to perform
swf_base_end();


swf_base_begin(CLIPACTIONS)
	s32					i_max;
	s32					i_act;
	//Reserved			UI16 Must be 0
	CLIPEVENTFLAGS		AllEventFlags;		//CLIPEVENTFLAGS All events used in these clip actions
	CLIPACTIONRECORD**	ClipActionRecords;	//CLIPACTIONRECORD[one or more] Individual event handlers
	u32					ClipActionEndFlag;	// If SWF version <= 5, UI16 If SWF version >= 6, UI32 Must be 0
swf_base_end();


swf_tag_begin(PlaceObject2,u32 tag,u32 len)
	//Header RECORDHEADER Tag type = 26
	b32				PlaceFlagHasClipActions;	//UB[1] SWF 5 and later: has clip actions (sprite characters only)	Otherwise: always 0
	b32				PlaceFlagHasClipDepth;		//UB[1] Has clip depth
	b32				PlaceFlagHasName;			//UB[1] Has name
	b32				PlaceFlagHasRatio;			//UB[1] Has ratio
	b32				PlaceFlagHasColorTransform;	//UB[1] Has color transform
	b32				PlaceFlagHasMatrix;			//UB[1] Has matrix
	b32				PlaceFlagHasCharacter;		//UB[1] Places a character
	b32				PlaceFlagMove;				//UB[1] Defines a character to be moved
	u16				Depth;						//UI16 Depth of character
	u16				CharacterId;				//If PlaceFlagHasCharacter UI16 ID of character to place
	MATRIX			Matrix;						//If PlaceFlagHasMatrix MATRIX Transform matrix data
	CXFORMWITHALPHA ColorTransform;				//If PlaceFlagHasColorTransform CXFORMWITHALPHA Color transform data
	u16				Ratio;						//If PlaceFlagHasRatio UI16
	STRING			Name;						//If PlaceFlagHasName STRING Name of character
	u16				ClipDepth;					//If PlaceFlagHasClipDepth UI16 Clip depth (see ��Clipping layers�� on page 32)
	CLIPACTIONS		ClipActions;				//If PlaceFlagHasClipActions CLIPACTIONS; SWF 5 and later:Clip Actions Data
swf_tag_end();


swf_base_begin(Filter)
	u8 FilterID;		//  UI8			0 = Has DropShadowFilter
						// 				1 = Has BlurFilter
						// 				2 = Has GlowFilter
						// 				3 = Has BevelFilter
						// 				4 = Has GradientGlowFilter
						// 				5 = Has ConvolutionFilter
						// 				6 = Has ColorMatrixFilter
						// 				7 = Has GradientBevelFilter
	union{
		DROPSHADOWFILTER	DropShadowFilter; // If FilterID = 0,DROPSHADOWFILTER Drop Shadow filter
		BLURFILTER			BlurFilter; // If FilterID = 1, BLURFILTER Blur filter
		GLOWFILTER			GlowFilter; // If FilterID = 2, GLOWFILTER Glow filter
		BEVELFILTER			BevelFilter;//  If FilterID = 3, BEVELFILTER Bevel filter
		GRADIENTGLOWFILTER	GradientGlowFilter;//  If FilterID = 4, GRADIENTGLOWFILTER Gradient Glow filter
		CONVOLUTIONFILTER	ConvolutionFilter; // If FilterID = 5, CONVOLUTIONFILTER Convolution filter
		COLORMATRIXFILTER	ColorMatrixFilter;//  If FilterID = 6, COLORMATRIXFILTER Color Matrix filter
		GRADIENTBEVELFILTER GradientBevelFilter;//  If FilterID = 7, GRADIENTBEVELFILTER Gradient Bevel filter
	}filter;
swf_base_end();

swf_base_begin(FILTERLIST)
	u8			NumberOfFilters;	// UI8 Number of Filters
	FILTER**	Filters;				// [NumberOfFilters] List of filters
swf_base_end();


swf_tag_begin(PlaceObject3,u32 tag,u32 len)

	// Header RECORDHEADER Tag type = 70

	u32					PlaceFlagHasClipActions; // UB[1] SWF 5 and later: has clip
												// actions (sprite characters only) Otherwise: always 0

	u32					PlaceFlagHasClipDepth; // UB[1] Has clip depth
	u32					PlaceFlagHasName; // UB[1] Has name
	u32					PlaceFlagHasRatio; // UB[1] Has ratio
	u32					PlaceFlagHasColorTransform; // UB[1] Has color transform
	u32					PlaceFlagHasMatrix; // UB[1] Has matrix
	u32					PlaceFlagHasCharacter; // UB[1] Places a character
	u32					PlaceFlagMove; // UB[1] Defines a character to be moved

	// Reserved UB[3] Must be 0

	u32					PlaceFlagHasImage; // UB[1] Has class name or character ID of bitmap to
							// place. If PlaceFlagHasClassName, use ClassName. If PlaceFlagHasCharacter, use CharacterId
	u32					PlaceFlagHasClassName; // UB[1] Has class name of object to place
	u32					PlaceFlagHasCacheAsBitmap; // UB[1] Enables bitmap caching
	u32					PlaceFlagHasBlendMode; // UB[1] Has blend mode
	u32					PlaceFlagHasFilterList; // UB[1] Has filter list
	u16					Depth; // UI16 Depth of character
	STRING				ClassName; // If PlaceFlagHasClassName or (PlaceFlagHasImage and PlaceFlagHasCharacter), String Name of the class to place Display list tags 41
	u16					CharacterId; // If PlaceFlagHasCharacter, UI16 ID of character to place
	MATRIX				Matrix; // If PlaceFlagHasMatrix, MATRIX Transform matrix data
	CXFORMWITHALPHA		ColorTransform;		// If PlaceFlagHasColorTransform,CXFORMWITHALPHA Color transform data
	u16					Ratio; // If PlaceFlagHasRatio, UI16
	STRING				Name;					// If PlaceFlagHasName, STRING Name of character
	u16					ClipDepth; // If PlaceFlagHasClipDepth, UI16 Clip depth (see Clipping layers)
	FILTERLIST			SurfaceFilterList;	// If PlaceFlagHasFilterList,FILTERLIST
									// List of filters on this object
									// BlendMode If PlaceFlagHasBlendMode, UI8 0 or 1 = normal
									// 2 = layer
									// 3 = multiply
									// 4 = screen
									// 5 = lighten
									// 6 = darken
									// 7 = difference
									// 8 = add
									// 9 = subtract
									// 10 = invert
									// 11 = alpha
									// 12 = erase
									// 13 = overlay
									// 14 = hardlight
									// Values 15 to 255 are
									// reserved.

	u8				BitmapCache;	// If PlaceFlagHasCacheAsBitmap,UI8
									// 0 = Bitmap cache disabled
									// 1-255 = Bitmap cache
									// enabled

	CLIPACTIONS		ClipActions;	// If PlaceFlagHasClipActions,
									// CLIPACTIONS
									// SWF 5 and later:
									// Clip Actions Data
swf_tag_end();


swf_tag_begin(ShowFrame,u32 tag,u32 len)
	//RECORDHEADER Header;  // RECORDHEADER Tag type = 1
swf_tag_end();

swf_tag_begin(RemoveObject,u32 tag,u32 len)
	//RECORDHEADER	Header;			//  Tag type = 5
	//u16				CharacterId;	//  UI16 ID of character to remove
	u16				Depth;			// UI16 Depth of character
swf_tag_end();

swf_tag_begin(RemoveObject2,u32 tag,u32 len)
	//RECORDHEADER Header;	// Tag type = 28
	u16	Depth;				// UI16 Depth of character
swf_tag_end();

swf_tag_begin(SetBackgroundColor,u32 tag,u32 len)
	//RECORDHEADER	Header;				// Tag type = 9
	swf_rgb			BackgroundColor;	// RGB Color of the display background
swf_tag_end();

swf_tag_begin(FrameLabel,u32 tag)
	//RECORDHEADER	Header;			// Tag type = 43
	STRING 			szName;			//Label for frame
swf_tag_end();

swf_tag_begin(NamedAnchor,u32 tag,u32 len)
	//RECORDHEADER	Header;			// Tag type = 43
	STRING			szName;			// Null-terminated .	(0 is NULL)	Label for frame.
	u8				anchor;			// flag UI8 Always 1
swf_tag_end();

swf_tag_begin(Protect,u32 tag,u32 len)
	//RECORDHEADER Header; // Tag type = 24
swf_tag_end();

swf_tag_begin(End,u32 tag,u32 len)
	//RECORDHEADER	Header; // Tag type = 0
swf_tag_end();


STX_INTERF(ExportAssets_nl);
struct ExportAssets_nl{
		u16		Tag;		//	UI16 First character ID to export
	    STRING	szName;		//	Identifier for first exported character
};

swf_tag_begin(ExportAssets,u32 tag,u32 len)
	//RECORDHEADER	Header;			// Tag type = 56
	u16				Count;			// UI16 Number of assets to export
	ExportAssets_nl *nl;
swf_tag_end();

swf_tag_begin(ImportAssets,u32 tag,u32 len)
	//RECORDHEADER	Header;		//	Tag type = 57
	STRING			URL;		//	URL where the source SWF file can be found
	u16				Count;		//	UI16 Number of assets to import
	ExportAssets_nl *nl;
swf_tag_end();

swf_tag_begin(EnableDebugger,u32 tag,u32 len)
	//RECORDHEADER	Header;		//Tag type = 58
	STRING			Password;	//Null-terminated STRING. (0	is NULL)
swf_tag_end();

swf_tag_begin(EnableDebugger2,u32 tag,u32 len)
	//RECORDHEADER Header;		// Tag type = 64
	//Reserved UI16 Always 0
	STRING Password;			// Null-terminated STRING.(0 is NULL) MD5-encrypted password
swf_tag_end();

swf_tag_begin(ScriptLimits,u32 tag,u32 len)
	//RECORDHEADER	Header;					// Tag type = 65
	u16				MaxRecursionDepth;		// UI16 Maximum recursion depth
	u16				ScriptTimeoutSeconds;	// UI16 Maximum ActionScript processing time before script stuck dialog box displays
swf_tag_end();


swf_tag_begin(SetTabIndex,u32 tag,u32 len)
	//RECORDHEADER	Header;		// Tag type = 66
	u16				Depth;		// UI16 Depth of character
	u16				TabIndex;	// UI16 Tab order value
swf_tag_end();

swf_tag_begin(ImportAssets2,u32 tag,u32 len)
	//RECORDHEADER	Header;		// Tag type = 71
	STRING				URL;		// URL where the source SWF file can be found
	//Reserved UI8 Must be 1
	//Reserved UI8 Must be 0
	u16					Count;		// UI16 Number of assets to import
	ExportAssets_nl*	nl;
swf_tag_end();


swf_tag_begin(SymbolClass,u32 tag,u32 len)
	//RECORDHEADER		Header;			// Tag type = 76
	u16					NumSymbols;		// UI16 Number of symbols that will be associated by this tag.
	ExportAssets_nl*	nl;
swf_tag_end();


swf_tag_begin(Metadata,u32 tag,u32 len)
	//RECORDHEADER	Header;		// Tag type = 77
	STRING			XML;		// XML Metadata
swf_tag_end();

swf_tag_begin(DefineScalingGrid,u32 tag,u32 len)
	//RECORDHEADER	Header;			// Tag type = 78
	u16				CharacterId;	//UI16 ID of sprite or button character upon which the  scaling grid will be applied.
	swf_rect		Splitter;		//RECT Center region of 9-slice 	grid
swf_tag_end();

STX_INTERF(anchor32);
struct anchor32{
	u32		Offset;
	STRING	szName;
};

swf_tag_begin(DefineSceneAndFrameLabelData,u32 tag,u32 len)
	//RECORDHEADER	Header;			// Tag type = 86
	u32				SceneCount;		// EncodedU32 Number of scenes
	// Offset1 EncodedU32 Frame offset for scene 1
	// Name1 STRING Name of scene 1
	// ... ... ...
	// OffsetN EncodedU32 Frame offset for scene N
	// NameN STRING Name of scene N
	anchor32 *sl;

	u32 FrameLabelCount; // EncodedU32 Number of frame labels
	//FrameNum1 EncodedU32 Frame number of frame label #1 (zero-based,global to symbol)
	//FrameLabel1 STRING Frame label string of framelabel #1
	//...
	anchor32 *fl;
swf_tag_end();


swf_base_begin(MORPHGRADRECORD)
	u8			StartRatio;	// UI8 Ratio value for start shape.
	swf_rgba	StartColor; //  RGBA Color of gradient for start shape.
	u8			EndRatio;	//  UI8 Ratio value for end shape.
	swf_rgba	EndColor;	//  RGBA Color of gradient for end shape.
swf_base_end();

swf_base_begin(MORPHGRADIENT)
	u8					NumGradients;		// UI8 1 to 8.	
	MORPHGRADRECORD*	GradientRecords;	// 	[NumGradients] Gradient records (seefollowing).
swf_base_end();


swf_base_begin(MORPHFILLSTYLE)
	u8				fillStyleType;// UI8 Type of fill style
	//0x00 = solid fill
	//0x10 = linear gradient fill
	//0x12 = radial gradient fill
	//0x40 = repeating bitmap
	//0x41 = clipped bitmap fill
	//0x42 = non-smoothed repeating bitmap
	//0x43 = non-smoothed clipped bitmap
	swf_rgba		StartColor;// If type = 0x00, RGBA Solid fill color with opacity information for start shape.
	swf_rgba		EndColor;// If type = 0x00, RGBA Solid fill color with opacity information for end shape.
	MATRIX			StartGradientMatrix;// If type = 0x10 or 0x12, MATRIX Matrix for gradient fill for start shape.
	MATRIX			EndGradientMatrix;// If type = 0x10 or 0x12, MATRIX Matrix for gradient fill for end shape.

	MORPHGRADIENT	Gradient;// If type = 0x10 or 0x12, MORPHGRADIENT Gradient fill.
	u16				BitmapId;//  If type = 0x40, 0x41, 0x42 or 0x43, UI16 ID of bitmap character for fill.
	MATRIX			StartBitmapMatrix;//  If type = 0x40, 0x41, 0x42 or 0x43,Matrix for bitmap fill for start shape.
	MATRIX			EndBitmapMatrix;//  If type = 0x40, 0x41, 0x42 or 0x43, Matrix for bitmap fill for end shape.
swf_base_end();


swf_base_begin(MORPHFILLSTYLEARRAY)
	u32					FillStyleCount;			// Count = UI8 Count of fill styles.
	u16					FillStyleCountExtended;	// If Count = 0xFF 	UI16 Extended count of fill styles.
	MORPHFILLSTYLE*		FillStyles;				// MORPHFILLSTYLE[count] Array of fill styles.
swf_base_end();



swf_base_begin(MORPHLINESTYLE)
	u16			StartWidth; // UI16 Width of line in start shape in twips.
	u16			EndWidth;	// UI16 Width of line in end shape in twips.
	swf_rgba	StartColor; // RGBA Color value including alpha	channel information for start		shape.
	swf_rgba	EndColor;	// RGBA Color value including alpha	channel information for end		shape.
swf_base_end();


swf_base_begin(MORPHLINESTYLE2)
	u16 StartWidth;	// UI16 Width of line in start shape in	twips.
	u16 EndWidth;	// UI16 Width of line in end shape in	twips.
	u8 StartCapStyle;	// UB[2] Start-cap style:
	//0 = Round cap
	//1 = No cap
	//2 = Square cap
	u8  JoinStyle;	// UB[2] Join style:
	//0 = Round join
	//1 = Bevel join
	//2 = Miter join
	b32 HasFillFlag;	// UB[1] If 1, fill is defined in FillType.If 0, uses StartColor and	EndColor fields.

	b32 NoHScaleFlag;	// UB[1] If 1, stroke thickness will not scale if the object is scaled horizontally.
	b32 NoVScaleFlag;	// UB[1] If 1, stroke thickness will not scale if the object is scaled vertically.
	b32 PixelHintingFlag;	// UB[1] If 1, all anchors will be aligned to full pixels.
	//Reserved UB[5] Must be 0.
	b32 NoClose;	// UB[1] If 1, stroke will not be closed if the stroke��s last point matches
	//its first point. Flash Player will apply caps instead of a join.
	u8 EndCapStyle;	// UB[2] End-cap style:
	//0 = Round cap
	//1 = No cap
	//2 = Square cap
	u16 MiterLimitFactor;	// If JoinStyle = 2, UI16 Miter limit factor as an 8.8 fixed-point value.
	swf_rgba StartColor;	// If HasFillFlag = 0, RGBA Color value including alpha channel information for start shape.
	swf_rgba EndColor;	// If HasFillFlag = 0, RGBA Color value including alpha channel information for End shape.
	MORPHFILLSTYLE FillType;	// If HasFillFlag = 1,MORPHFILLSTYLE Fill style
swf_base_end();


swf_base_begin(MORPHLINESTYLEARRAY,s32 ishape)
	u32		LineStyleCount; // UI8 Count of line styles.
	u16		LineStyleCountExtended; // If count = 0xFF UI16 Extended count OF line styles.
	union{
		MORPHLINESTYLE*	s;// MORPHLINESTYLE[count], (if MorphShape1) 
		MORPHLINESTYLE2* s2;// MORPHLINESTYLE2[count], (if MorphShape2)
	}LineStyles; // Array of line styles.
swf_base_end();




swf_tag_begin(DefineMorphShape,u32 tag,u32 len)
	//RECORDHEADER		Header;				// Tag type = 46
	//u16					CharacterId;		//  UI16 ID for this character
	swf_rect			StartBounds;		//  RECT Bounds of the start shape
	swf_rect			EndBounds;			//  RECT Bounds of the end shape
	u32					Offset;				//  UI32 Indicates offset to EndEdges
	MORPHFILLSTYLEARRAY MorphFillStyles;	//  Fill style information is stored in
	// 	the same manner as for a standard shape; however, eachfill consists of interleaved
	// 	information based on a singlestyle type to accommodate	morphing.
	MORPHLINESTYLEARRAY MorphLineStyles;	//  Line style information is stored
	// 	in the same manner as for a	standard shape; however, each
	// 	line consists of interleaved information based on a single
	// 	style type to accommodate morphing.

	SHAPE StartEdges; // Contains the set of edges and
	//the style bits that indicate style		changes (for example, MoveTo,
	//FillStyle, and LineStyle).		Number of edges must equal		the number of edges in		EndEdges.
	
	SHAPE EndEdges; //Contains only the set of edges,	with no style information.	Number of edges must equal
	// the number of edges in	StartEdges.
swf_tag_end();

swf_tag_begin(DefineMorphShape2,u32 tag,u32 len)
	//RECORDHEADER	Header;					// Tag type = 84
	//u16				CharacterId;			// UI16 ID for this character
	swf_rect		StartBounds;			// RECT Bounds of the start shape
	swf_rect		EndBounds;				// RECT Bounds of the end shape
	swf_rect		StartEdgeBounds;		// RECT Bounds of the start shape,	excluding strokes
	swf_rect		EndEdgeBounds;			// RECT Bounds of the end shape,	excluding strokes
	//Reserved UB[6] Must be 0
	b32				UsesNonScalingStrokes;	// UB[1] If 1, the shape contains at least	one non-scaling stroke.
	b32				UsesScalingStrokes;		// UB[1] If 1, the shape contains at least	one scaling stroke.
	u32				Offset;					// UI32 Indicates offset to EndEdges

	MORPHFILLSTYLEARRAY MorphFillStyles;	//  Fill style information is stored in
	// 	the same manner as for a standard shape; however, eachfill consists of interleaved
	// 	information based on a singlestyle type to accommodate	morphing.
	MORPHLINESTYLEARRAY MorphLineStyles;	//  Line style information is stored
	// 	in the same manner as for a	standard shape; however, each
	// 	line consists of interleaved information based on a single
	// 	style type to accommodate morphing.

	SHAPE StartEdges; // Contains the set of edges and
	//the style bits that indicate style		changes (for example, MoveTo,
	//FillStyle, and LineStyle).		Number of edges must equal		the number of edges in		EndEdges.

	SHAPE EndEdges; //Contains only the set of edges,	with no style information.	Number of edges must equal
	// the number of edges in	StartEdges.
swf_tag_end();


swf_tag_begin(DefineFont,u32 tag,u32 len)
	//RECORDHEADER	Header;				// Tag type = 10
	//u16				FontID;				// UI16 ID for this font character
	u32				nGlyphs;
	u16*			OffsetTable;		// UI16[nGlyphs] Array of shape offsets
	SHAPE*			GlyphShapeTable;	// [nGlyphs] Array of Shapes.
swf_tag_end();

swf_tag_begin(DefineFontInfo,u32 tag,u32 len)
	//RECORDHEADER Header;	// Tag type = 13.
	u16		FontID;	// UI16 Font ID this information is for.
	u8		FontNameLen;	// UI8 Length of font name.
	u8*		FontName;	// UI8[FontNameLen] Name of the font (see following).
	u8		FontFlagsReserved;	// UB[2] Reserved bit fields.
	b32		FontFlagsSmallText;	// UB[1] SWF 7 file format or later: 
	//Font is small. Character glyphs are aligned on pixel boundaries  for dynamic and input text.
	b32		FontFlagsShiftJIS;	// UB[1] ShiftJIS character codes.
	b32		FontFlagsANSI;	// UB[1] ANSI character codes.
	b32		FontFlagsItalic;	// UB[1] Font is italic.
	b32		FontFlagsBold;	// UB[1] Font is bold.
	b32		FontFlagsWideCodes;	// UB[1] If 1, CodeTable is UI16 array; otherwise, CodeTable is UI8 array.
	union{
		u16*	g16;	// If FontFlagsWideCodes,UI16[nGlyphs] Otherwise, UI8[nGlyphs]
		u8*		g8;
	}CodeTable;
swf_tag_end();

enum swf_langcode{
	Latin = 1, //(the western languages covered by Latin-1: English, French, German, and so on)
	Japanese,
	Korean,
	sChinese,
	tChinese,
};
typedef enum swf_langcode swf_langcode;


swf_tag_begin(DefineFontInfo2,u32 tag,u32 len)
	//RECORDHEADER Header;	// Tag type = 62.
	u16 FontID;	// UI16 Font ID this information is for.
	u8 FontNameLen;	// UI8 Length of font name.
	u8* FontName;	// UI8[FontNameLen] Name of the font.
	u8 FontFlagsReserved;	// UB[2] Reserved bit fields.
	b32 FontFlagsSmallText;	// UB[1] SWF 7 or later:Font is small. Character glyphs
	//are aligned on pixel boundariesfor dynamic and input text.
	b32 FontFlagsShiftJIS;	// UB[1] Always 0.
	b32 FontFlagsANSI;	// UB[1] Always 0.
	b32 FontFlagsItalic;	// UB[1] Font is italic.
	b32 FontFlagsBold;	// UB[1] Font is bold.
	b32 FontFlagsWideCodes;	// UB[1] Always 1.
	swf_langcode LanguageCode;	// Language ID.
	u16 *CodeTable;// UI16[nGlyphs] Glyph to code table in UCS-2,sorted in ascending order.
swf_tag_end();


swf_base_begin(KERNINGRECORD,b32 b_wide)
	u16 FontKerningCode1;		// If FontFlagsWideCodes,	UI16 Otherwise UI8 Character; code of the left	character.
	u16 FontKerningCode2;		//  If FontFlagsWideCodes,	UI16 Otherwise UI8 Character; code of the right	character.
	s16 FontKerningAdjustment;	//  SI16 Adjustment relative to left	character��s advance value.
swf_base_end();


swf_tag_begin(DefineFont2,u32 tag,u32 len)
	//RECORDHEADER Header;	// Tag type = 48.
	//u16 FontID;	// UI16 ID for this font character.
	b32 FontFlagsHasLayout;	// UB[1] Has font metrics/layoutinformation.
	b32 FontFlagsShiftJIS;	// UB[1] ShiftJIS encoding.
	b32 FontFlagsSmallText;	// UB[1] SWF 7 or later:Font is small. Character glyphs
	//are aligned on pixel boundaries	for dynamic and input text.
	b32 FontFlagsANSI;	// UB[1] ANSI encoding.
	b32 FontFlagsWideOffsets;	// UB[1] If 1, uses 32 bit offsets.
	b32 FontFlagsWideCodes;	// UB[1] If 1, font uses 16-bit codes;	otherwise font uses 8 bit codes.
	b32 FontFlagsItalic;	// UB[1] Italic Font.
	b32 FontFlagsBold;	// UB[1] Bold Font.

	u32 LanguageCode;	// LANGCODE SWF 5 or earlier:	always 0	SWF 6 or later:	language code
	u8  FontNameLen;	// UI8 Length of name.
	u8*  FontName;	// UI8[FontNameLen] Name of font (see	DefineFontInfo).
	u16 NumGlyphs; // UI16 Count of glyphs in font.	May be zero for device fonts.
	union{
		u32* d32;
		u16* d16;
	}OffsetTable;	// If FontFlagsWideOffsets,UI32[NumGlyphs]	Otherwise UI16[NumGlyphs]	Same as in DefineFont.
	
	u32 CodeTableOffset; // If FontFlagsWideOffsets,	UI32	Otherwise UI16	Byte count from start of
	//OffsetTable to start of	CodeTable.
	SHAPE* GlyphShapeTable;	// SHAPE[NumGlyphs] Same as in DefineFont.

	union{
		u16* d16;
		u8* d8;
	}CodeTable;	// If FontFlagsWideCodes,	UI16[NumGlyphs]	Otherwise UI8[NumGlyphs]	Sorted in ascending order.
	//Always UCS-2 in SWF 6 or later.
	s16 FontAscent;	// If FontFlagsHasLayout, SI16 Font ascender height.
	s16 FontDescent;	// If FontFlagsHasLayout, SI16 Font descender height.
	s16 FontLeading;	// If FontFlagsHasLayout, SI16 Font leading height (see following).
	s16* FontAdvanceTable;	// If FontFlagsHasLayout,	SI16[NumGlyphs]
	//Advance value to be used for each glyph in dynamic glyph text.
	swf_rect* FontBoundsTable;	// If FontFlagsHasLayout,RECT[NumGlyphs]
	//Not used in Flash Player through version 7 (but must be present).
	u16 KerningCount;	// If FontFlagsHasLayout, UI16 Not used in Flash Player through
	//version 7 (always set to 0 to save	space).
	KERNINGRECORD* FontKerningTable;	// If FontFlagsHasLayout,	[KerningCount]
	//Not used in Flash Player through version 7 (omit withKerningCount of 0).
swf_tag_end();



swf_tag_begin(DefineFont3,u32 tag,u32 len)
	//RECORDHEADER Header;	// Tag type = 75.
	//u16 FontID;	// UI16 ID for this font character.
	b32 FontFlagsHasLayout;	// UB[1] Has font metrics/layout	information.
	b32 FontFlagsShiftJIS;	// UB[1] ShiftJIS encoding.
	b32 FontFlagsSmallText;	// UB[1] SWF 7 or later:	Font is small. Character glyphs
	//are aligned on pixel boundaries	for dynamic and input text.
	b32 FontFlagsANSI;	// UB[1] ANSI encoding.
	b32 FontFlagsWideOffsets;	// UB[1] If 1, uses 32 bit offsets.
	b32 FontFlagsWideCodes;	// UB[1] Must be 1.
	b32 FontFlagsItalic;	// UB[1] Italic Font.

	b32 FontFlagsBold;	// UB[1] Bold Font. 	
	swf_langcode LanguageCode; // LANGCODE SWF 5 or earlier: always 0 SWF 6 or later: language code
	u8  FontNameLen;	// UI8 Length of name.
	u8*  FontName;	// UI8[FontNameLen] Name of font (see DefineFontInfo).
	u16 NumGlyphs;	// UI16 Count of glyphs in font. May be zero for device fonts.
	union{
		u32* d32;
		u16* d16;
	}OffsetTable;	// If FontFlagsWideOffsets, UI32[NumGlyphs] Otherwise UI16[NumGlyphs] Same as in DefineFont.
	u32 CodeTableOffset;	// If FontFlagsWideOffsets, UI32 Otherwise UI16
	//Byte count from start OF OffsetTable to start of CodeTable.
	SHAPE* GlyphShapeTable;	// SHAPE[NumGlyphs] Same as in DefineFont.
	u16* CodeTable;	// UI16[NumGlyphs] Sorted in ascending order.Always UCS-2 in SWF 6 or later.
	s16 FontAscent;	// If FontFlagsHasLayout, SI16 Font ascender height.

	s16 FontDescent;	// If FontFlagsHasLayout, SI16 Font descender height.
	s16 FontLeading;	// If FontFlagsHasLayout, SI16 Font leading height (see following).
	s16 *FontAdvanceTable;	// If FontFlagsHasLayout, SI16[NumGlyphs]
	//Advance value to be used for each glyph in dynamic glyph text.
	swf_rect* FontBoundsTable;	// If FontFlagsHasLayout, RECT[NumGlyphs]
	//Not used in Flash Player through version 7 (but must be present).

	u16 KerningCount;	// If FontFlagsHasLayout, UI16 Not used in Flash Player
	//through version 7 (always set to 0 to save space).
	KERNINGRECORD* FontKerningTable;	// If FontFlagsHasLayout, KERNINGRECORD[KerningCount]
	//Not used in Flash Player through version 7 (omit with KerningCount of 0).
swf_tag_end();

swf_base_begin(ZONEDATA)
	f16 AlignmentCoordinate;	// FLOAT16 X (left) or Y (baseline) coordinate of the alignment zone.
	f16 Range;	// FLOAT16 Width or height of the alignment zone.
swf_base_end();

swf_base_begin(ZONERECORD)
	u8			NumZoneData;	// UI8 Number of ZoneData entries.	Always 2.
	ZONEDATA*	ZoneData;	// ZONEDATA[NumZoneData] Compressed alignment zone	information.
	//Reserved UB[6] Must be 0.
	b32 ZoneMaskY;	// UB[1] Set if there are Y alignment	zones.
	b32 ZoneMaskX;	// UB[1] Set if there are X alignment	zones.
swf_base_end();


swf_tag_begin(DefineFontAlignZones,u32 tag,u32 len)
	//RECORDHEADER	Header;			// Tag type = 73.
	u16				FontID;			// UI16 ID of font to use, specified by DefineFont3.
	u8				CSMTableHint;	// UB[2] Font thickness hint. Refers to the thickness of the typical stroke used in the font.
	//0 = thin
	//1 = medium
	//2 = thick
	//Flash Player maintains a selection of CSM tables for many fonts. However, if the
	//font is not found in Flash 	Player's internal table, this hint is used to choose an appropriate table.
	//Reserved UB[6] Must be 0.
	u32				GlyphCount;
	ZONERECORD*		ZoneTable;	// ZONERECORD[GlyphCount] Alignment zone information for each glyph.
swf_tag_end();


swf_tag_begin(DefineFontName,u32 tag,u32 len)
	//RECORDHEADER Header;	//  Tag type = 88
	u16 FontID;	//  UI16 ID for this font to which this	refers
	STRING FontName;	//  Name of the font. For fonts	starting as Type 1, this is the
	//PostScript FullName. For fonts	starting in sfnt formats such asTrueType and OpenType, this
	//is name ID 4, platform ID 1,language ID 0 (Full name, MacOS, English).
	STRING FontCopyright;	// Arbitrary string of copyright	information
swf_tag_end();

swf_base_begin(GLYPHENTRY,s32 gb,s32 ab)
	u8* GlyphIndex;	// UB[GlyphBits] Glyph index into current font.
	s8* GlyphAdvance;	// SB[AdvanceBits] x advance value for glyph
swf_base_end();


swf_base_begin(TEXTRECORD,s32 itext,s32 gb,s32 ab)
	s32 i_text;
	b32 TextRecordType;		// UB[1] Always 1.
	u8	StyleFlagsReserved;	// UB[3] Always 0.
	b32 StyleFlagsHasFont;	// UB[1] 1 if text font specified.
	b32 StyleFlagsHasColor;	// UB[1] 1 if text color specified.
	b32 StyleFlagsHasYOffset;	// UB[1] 1 if y offset specified.
	b32 StyleFlagsHasXOffset;	// UB[1] 1 if x offset specified.
	u16 FontID;	// If StyleFlagsHasFont, UI16 Font ID for following text.
	union{
		swf_rgb		rgb;
		swf_rgba	rgba;
	}TextColor;	// If StyleFlagsHasColor, RGB If this record is part of a DefineText2 tag, RGBA Font color for following text.
	s16 XOffset;	// If StyleFlagsHasXOffset, SI16 x offset for following text.
	s16 YOffset;	// If StyleFlagsHasYOffset, SI16 y offset for following text.
	u16 TextHeight;	// If hasFont, UI16 Font height for following text.
	u8 GlyphCount;	// UI8 Number of glyphs in record.
	GLYPHENTRY* GlyphEntries;	// GLYPHENTRY[GlyphCount] Glyph entry (see following).
swf_base_end();

swf_tag_begin(DefineText,u32 tag,u32 len)
	//RECORDHEADER Header;	// Tag type = 11.
	//u16				CharacterID;	// UI16 ID for this text character.
	swf_rect		TextBounds;	// RECT Bounds of the text.
	MATRIX			TextMatrix;	// Transformation matrix for the	text.
	u8				GlyphBits;	// UI8 Bits in each glyph index.
	u8				AdvanceBits;	// UI8 Bits in each advance value.

	s32				i_max;
	s32				i_rec;
	TEXTRECORD**	TextRecords;	//  TEXTRECORD[zero or more] Text records.
	u8				EndOfRecordsFlag;	//  UI8 Must be 0.
swf_tag_end();

swf_tag_begin(DefineText2,u32 tag,u32 len)
	//RECORDHEADER	Header;			// Tag type = 33.
	//u16				CharacterID;	// UI16 ID for this text character.
	swf_rect		TextBounds;	// RECT Bounds of the text.
	MATRIX			TextMatrix;	// Transformation matrix.
	u8				GlyphBits;	// UI8 Bits in each glyph index.
	u8				AdvanceBits;	// UI8 Bits in each advance value.

	s32				i_max;
	s32				i_rec;
	TEXTRECORD**	TextRecords;	// TEXTRECORD[zero or more] Text records.
	u8				EndOfRecordsFlag;	// UI8 Must be 0.
swf_tag_end();


swf_tag_begin(DefineEditText,u32 tag,u32 len)
	//RECORDHEADER Header;	// Tag type = 37.
	//u16 CharacterID;	// UI16 ID for this dynamic TEXT character.
	swf_rect Bounds;	// RECT Rectangle that completely encloses the text field.
	b32 HasText;	// UB[1] 0 = text field has no default text.
	//1 = text field initially displays the string specified by InitialText.
	b32 WordWrap;	// UB[1] 0 = text will not wrap and will 	scroll sideways. 
	//1 = text will wrap automatically when the end of line is reached.
	b32 Multiline;	// UB[1] 0 = text field is one line only.
	//1 = text field is multi-line and scrollable.
	b32 Password;	// UB[1] 0 = characters are displayed as typed.
	//1 = all characters are displayed as an asterisk.
	b32 ReadOnly;	// UB[1] 0 = text editing is enabled. 1 = text editing is disabled.

	b32 HasTextColor;	// UB[1] 0 = use default color. 	1 = use specified color	(TextColor).
	b32 HasMaxLength;	// UB[1] 0 = length of text is unlimited. 1 = maximum length of string is specified by MaxLength.
	b32 HasFont;	// UB[1] 0 = use default font. 1 = use specified font (FontID) and height (FontHeight). 
	//(Can��t be true if HasFontClass is true).
	b32 HasFontClass;	// UB[1] 0 = no fontClass, 1 = fontClass and Height specified for this
	//text. (can't be true if HasFont is true). Supported in Flash Player 9.0.45.0 and later.
	b32 AutoSize;	// UB[1] 0 = fixed size. 1 = sizes to content (SWF 6 or later only).
	b32 HasLayout;	// UB[1] Layout information provided.
	b32 NoSelect;	// UB[1] Enables or disables interactive text selection.
	b32 Border;	// UB[1] Causes a border to be drawn around the text field.

	b32 WasStatic;	// UB[1] 0 = Authored as dynamic text 1 = Authored as static text
	b32 HTML;	// UB[1] 0 = plaintext content. 1 = HTML content (see following).
	b32 UseOutlines;	// UB[1] 0 = use device font. 1 = use glyph font.
	u16 FontID;	// If HasFont, UI16 ID of font to use.
	STRING FontClass;	// If HasFontClass, STRING Class name of font to be loaded from another SWF and used for this text.
	u16 FontHeight;	// If HasFont, UI16 Height of font in twips.
	swf_rgba TextColor;	// If HasTextColor, RGBA Color of text.
	u16 MaxLength;	// If HasMaxLength, UI16 Text is restricted to this length.
	u8	Align;		// If HasLayout, UI8 0 = Left
	//1 = Right
	//2 = Center
	//3 = Justify
	u16 LeftMargin;	// If HasLayout, UI16 Left margin in twips.
	u16 RightMargin;	// If HasLayout, UI16 Right margin in twips.
	u16 Indent;	// If HasLayout, UI16 Indent in twips.
	s16 Leading;	// If HasLayout, SI16 Leading in twips (vertical distance between bottom of
	//descender of one line and top of ascender of the next).
	STRING VariableName;	// STRING Name of the variable where the
	//contents of the text field are stored. May be qualified with
	//dot syntax or slash syntax for non-global variables.
	STRING InitialText;	// If HasText STRING Text that is initially displayed.
swf_tag_end();

swf_tag_begin(CSMTextSettings,u32 tag,u32 len)
	//RECORDHEADER Header;	// Tag type = 74.
	u16		TextID;	// UI16 ID for the DefineText,	DefineText2, or	DefineEditText to which this	tag applies.
	u8		UseFlashType;	// UB[2] 0 = use normal renderer.	1 = use advanced text	rendering engine.
	u8		GridFit;	// UB[3] 0 = Do not use grid fitting.	AlignmentZones and LCD	sub-pixel information will not	be used.
	//1 = Pixel grid fit. Only supported for left-aligned	dynamic text. This setting
	//provides the ultimate in advanced anti-aliased text	readability, with crisp letters	aligned to pixels.
	//2 = Sub-pixel grid fit. Align	letters to the 1/3 pixel used	by LCD monitors. Can also
	//improve quality for CRT	output.

	//Reserved UB[3] Must be 0.
	f32		Thickness;	// F32 The thickness attribute for the associated text field. Set	to 0.0 to use the default
	//(anti-aliasing table) value.

	f32		Sharpness;	// F32 The sharpness attribute for the associated text field. Set
	//to 0.0 to use the default(anti-aliasing table) value.

	//Reserved UI8 Must be 0.
swf_tag_end();



swf_base_begin(FONTDATA,s32 ilen)
swf_base_end();


swf_tag_begin(DefineFont4,u32 tag,u32 len)
	//RECORDHEADER Header;	// Tag type = 91
	//u16			FontID;	// UI16 ID for this font character.
	u8			FontFlagsReserved;	// UB[5] Reserved bit fields.
	b32			FontFlagsHasFontData;	// UB[1] Font is embedded. Font tag includes	SFNT font data block.
	b32			FontFlagsItalic;	// UB[1] Italic font
	b32			FontFlagsBold;	// UB[1] Bold font
	STRING		FontName;	// Name of the font.
	FONTDATA	FontData;	// FONTDATA[0 or 1] When present, this is an OpenType
	//CFF font, as defined in the OpenType	specification at www.microsoft.com/
	//typography/otspec. The following	tables must be present: ��CFF ��, ��cmap��,
	//��head��, ��maxp��, ��OS/2��, ��post��, and	either (a) ��hhea�� and ��hmtx��, or (b)
	//��vhea��, ��vmtx��, and ��VORG��. The ��cmap��	table must include one of the following
	//kinds of Unicode ��cmap�� subtables: (0,	4), (0, 3), (3, 10), (3, 1), or (3, 0)
	//[notation: (platform ID, platformspecific	encoding ID)]. Tables such as
	//��GSUB��, ��GPOS��, ��GDEF��, and ��BASE��	may also be present.	Only present for embedded fonts.
swf_tag_end();

enum swf_audio_fmt{
	em_Uncprne = 0, // native-endian v1
	em_ADPCM = 1, //  v1
	em_MP3 = 2, //  v4
	em_Uncprle = 3, // v4
	em_Nellymoser16kHz  = 4, //  v10
	em_Nellymoser8kHz  = 5, //  v10
	em_Nellymoser  = 6, //  v6
	em_Speex  = 11, //  v10
};

typedef enum swf_audio_fmt swf_audio_fmt;


swf_tag_begin(DefineSound,u32 tag,u32 len)
	//RECORDHEADER Header;	// Tag type = 14
	u16 SoundId;	// UI16 ID for this sound.

	u8 SoundFormat;	// UB[4] Format of SoundData. See��Audio coding formats��on page 201.
	u8 SoundRate;	// UB[2] The sampling rate. This is ignored for Nellymoser andSpeex codecs.
// 	5.5kHz is not allowed for MP3.
// 	0 = 5.5 kHz
// 	1 = 11 kHz
// 	2 = 22 kHz
// 	3 = 44 kHz
	b32 SoundSize;	// UB[1] Size of each sample. This parameter only pertains to
	//uncompressed formats. This is ignored for compressed formats which always decode to 16 bits internally.
	//0 = snd8Bit
	//1 = snd16Bit
	b32 SoundType;	// UB[1] Mono or stereo sound This is ignored for Nellymoser and Speex.
	//0 = sndMono
	//1 = sndStereo
	u32 SoundSampleCount;	// UI32 Number of samples. Not affected by mono/stereo
	//setting; for stereo sounds this is the number of sample pairs.
	u8* SoundData;	// UI8[size of sound data] The sound data; varies by	format.
swf_tag_end();


swf_base_begin(SOUNDENVELOPE)
	u32 Pos44;	// UI32 Position of envelope point	as a number of 44 kHz	samples. Multiply
	// accordingly;	if using a	sampling rate less than 44	kHz.
	u16 LeftLevel;	// UI16 Volume level for left	channel. Minimum is 0,	maximum is 32768.
	u16 RightLevel;	// UI16 Volume level for right	channel. Minimum is 0,	maximum is 32768.
swf_base_end();

swf_base_begin(SOUNDINFO)
	//Reserved UB[2] Always 0.
	b32 SyncStop;	// UB[1] Stop the sound now.
	b32 SyncNoMultiple;	// UB[1] Don��t start the sound if already playing.
	b32 HasEnvelope;	// UB[1] Has envelope information.
	b32 HasLoops;	// UB[1] Has loop information.
	b32 HasOutPoint;	// UB[1] Has out-point information.
	b32 HasInPoint;	// UB[1] Has in-point information.

	u32 InPoint;	// If HasInPoint, UI32 Number of samples to skip at	beginning of sound.
	u32 OutPoint;	// If HasOutPoint, UI32 Position in samples of last	sample to play.
	u16 LoopCount;	// If HasLoops, UI16 Sound loop count.
	u8 EnvPoints;	// If HasEnvelope, UI8 Sound Envelope point count.
	SOUNDENVELOPE* EnvelopeRecords;	// If HasEnvelope,	SOUNDENVELOPE[EnvPoints]	Sound Envelope records.
swf_base_end();

swf_tag_begin(StartSound,u32 tag,u32 len)
	//RECORDHEADER	Header;		// Tag type = 15.
	u16				SoundId;	// UI16 ID of sound character to play.
	SOUNDINFO		SoundInfo;	// SOUNDINFO Sound style information.
swf_tag_end();

swf_tag_begin(StartSound2,u32 tag,u32 len)
	//RECORDHEADER Header;	// Tag type = 89.
	STRING SoundClassName;	// Name of the sound class to play.
	SOUNDINFO SoundInfo;	// Sound style information.
swf_tag_end();


swf_tag_begin(SoundStreamHead,u32 tag,u32 len)
	//RECORDHEADER Header;	// Tag type = 18.
	u8 Reserved;			// UB[4] Always zero.
	u8 PlaybackSoundRate;	// UB[2] Playback sampling rate
	//0 = 5.5 kHz
	//1 = 11 kHz
	//2 = 22 kHz
	//3 = 44 kHz
	b32 PlaybackSoundSize;	// UB[1] Playback sample size.	Always 1 (16 bit).
	b32 PlaybackSoundType;	// UB[1] Number of playback channels:	mono or stereo.
	//0 = sndMono
	//1 = sndStereo

	u8 StreamSoundCompression;	// UB[4] Format of streaming sound	data.
	//1 = ADPCM SWF 4 and later only:
	//2 = MP3
	u8 StreamSoundRate;	// UB[2] The sampling rate of the	streaming sound data.
	// 	0 = 5.5 kHz
	// 	1 = 11 kHz
	// 	2 = 22 kHz
	// 	3 = 44 kHz
	b32 StreamSoundSize;	// UB[1] The sample size of the	streaming sound data. Always 1 (16 bit).
	b32 StreamSoundType;	// UB[1] Number of channels in the	streaming sound data.
	//0 = sndMono
	//1 = sndStereo
	u16 StreamSoundSampleCount;	// UI16 Average number of samples in	each SoundStreamBlock. Not
	//affected by mono/stereo	setting; for stereo sounds this is	the number of sample pairs.
	s16 LatencySeek;	// If StreamSoundCompression	= 2, SI16	Otherwise absent	See ��MP3 sound data��
	//on page 216. The value here	should match the  SeekSamples field in the first SoundStreamBlock for this	stream.
swf_tag_end();

swf_tag_begin(SoundStreamHead2,u32 tag,u32 len)
	//RECORDHEADER Header;	// Tag type = 45
	u8 Reserved;	// UB[4] Always zero.
	u8 PlaybackSoundRate;	// UB[2] Playback sampling rate.
	//0 = 5.5 kHz
	//1 = 11 kHz
	//2 = 22 kHz
	//3 = 44 kHz
	b32 PlaybackSoundSize;	// UB[1] Playback sample size.
	//0 = 8-bit
	//1 = 16-bit
	b32 PlaybackSoundType;	// UB[1] Number of playback channels.
	//0 = sndMono
	//1 = sndStereo
	u8 StreamSoundCompression;	// UB[4] Format of SoundData. See	��Audio coding formats��	on page 201.
	u8 StreamSoundRate;	// UB[2] The sampling rate of thestreaming sound data.
	//5.5 kHz is not allowed for MP3.
	//0 = 5.5 kHz
	//1 = 11 kHz
	//2 = 22 kHz
	//3 = 44 kHz
	b32 StreamSoundSize;	// UB[1] Size of each sample. Always 16 bit for compressed formats.
	//May be 8 or 16 bit for uncompressed formats.
	//0 = 8-bit
	//1 = 16-bit
	b32 StreamSoundType;	// UB[1] Number of channels in the	streaming sound data.
	//0 = sndMono
	//1 = sndStereo

	u16 StreamSoundSampleCount;	// UI16 Average number of samples in
	//each SoundStreamBlock. Not 	affected by mono/stereo
	//setting; for stereo sounds this is 	the number of sample pairs.
	//LatencySeek If StreamSoundCompression 	= 2, SI16 	Otherwise absent
	//See MP3 sound data. The value here should match the
	//SeekSamples field in the first 	SoundStreamBlock for this stream.
swf_tag_end();


swf_tag_begin(SoundStreamBlock,u32 tag,u32 len)
	//RECORDHEADER Header;	// (long) Tag type = 19.
	u8* StreamSoundData;	// UI8[size of compressed data] Compressed sou
swf_tag_end();

swf_base_begin(MP3FRAME)
	u16 Syncword;	// UB[11] Frame sync. 	All bits must be set.
	u8  MpegVersion;	// UB[2] MPEG2.5 is an extension to MPEG2 that handles very low
	//bitrates, allowing the use of lower sampling frequencies.
	//0 = MPEG Version 2.5
	//1 = reserved
	//2 = MPEG Version 2
	//3 = MPEG Version 1
	u8 Layer;	// UB[2] Layer is always equal to 1 for MP3 headers in SWF files. The
	//��3�� in MP3 refers to the Layer,not the MpegVersion.
	//0 = reserved
	//1 = Layer III
	//2 = Layer II
	//3 = Layer I
	b32 ProtectionBit;	// UB[1] If ProtectionBit == 0, a 16-bit CRC follows the header
	//0 = Protected by CRC
	//1 = Not protected
	u8 Bitrate;	// UB[4] Bitrates are in thousands of bits per second. For example, 128
		//means 128000 bps. Value MPEG1 MPEG2.x
		//---------------------
		//0 free free
		//1 32 8
		//2 40 16
		//3 48 24
		//4 56 32
		//5 64 40
		//6 80 48
		//7 96 56
		//8 112 64
		//9 128 80
		//10 160 96
		//11 192 112
		//12 224 128
		//13 256 144
		//14 320 160
		//15 bad bad
	u8 SamplingRate;	// UB[2] Sampling rate in Hz. Value MPEG1 MPEG2
	//MPEG2.5
	//-------------------------
	//0 44100 22050 11025
	//1 48000 24000 12000
	//2 32000 16000 8000
	//-- -- --
	b32 PaddingBit;	// UB[1] Padding is used to fit the bitrate exactly.
	//0 = frame is not padded
	//1 = frame is padded with one extra slot
	//Reserved UB[1]

	u8 ChannelMode;	// UB[2] Dual-channel files are made of
		//two independent monochannels. Each one uses	exactly half the bitrate of the	file.
		//0 = Stereo
		//1 = Joint stereo (Stereo)
		//2 = Dual channel
		//2 = Single channel (Mono)
	u8		ModeExtension;	// UB[2]
	b32		Copyright;	// UB[1] 0 = Audio is not copyrighted		1 = Audio is copyrighted
	b32		Original;	// UB[1] 0 = Copy of original media		1 = Original media
	u8		Emphasis;	// UB[2] 0 = none		1 = 50/15 ms		2 = reserved		3 = CCIT J.17
	u8*		SampleData;	// UB[size of sample data*] The encoded audio samples.
swf_base_end();

swf_base_begin(MP3SOUNDDATA)
	s16 SeekSamples;	//SI16 Number of samples to skip.
	MP3FRAME* Mp3Frames;	// [zero or more] Array of MP3 frames.
swf_base_end();

swf_base_begin(MP3STREAMSOUNDDATA)
	u16 SampleCount;	// UI16 Number of samples	represented by this block. Not
	//affected by mono/stereo	setting; for stereo sounds this	is the number of sample pairs.
	MP3SOUNDDATA Mp3SoundData;	// MP3 frames with SeekSamples values.
swf_base_end();

swf_base_begin(ADPCMMONOPACKET)
	s16 InitialSample;	// SI16 First sample. Identical to first sample in uncompressed sound.
	u8  InitialIndex;	// UB[6] Initial index into the ADPCM StepSizeTable.*
	u8* AdpcmCodeData;	// UB[4095 *(AdpcmCodeSize+2)] 4095 ADPCM codes. Each sample is (AdpcmCodeSize + 2) bits.
};

swf_base_begin(ADPCMSTEREOPACKET)
	s16 InitialSampleLeft;	// SI16 First sample for left channel. Identical to first sample in uncompressed 	sound.
	u8 InitialIndexLeft;	// UB[6] Initial index into the ADPCM StepSizeTable* for left channel.
	s16 InitialSampleRight;	// SI16 First sample for right	channel. Identical to first	sample in uncompressed	sound.
	u8 InitialIndexRight;	// UB[6] Initial index into the	ADPCM StepSizeTable* for right channel
	u8* AdpcmCodeData;	// UB[8190 * (AdpcmCodeSize+2)] 4095 ADPCM codes per	channel, 
	//total 8190. Each sample is (AdpcmCodeSize + 2) bits.Channel;data is interleaved left, then right.
swf_base_end();

swf_base_begin(ADPCMSOUNDDATA)
	u8 AdpcmCodeSize;	// UB[2]
	//0 = 2 bits/sample
	//1 = 3 bits/sample
	//2 = 4 bits/sample
	//3 = 5 bits/sample
	//Bits per ADPCM code less 2.The actual size of each code is AdpcmCodeSize + 2.
	union{
		ADPCMMONOPACKET*	monodata;
		ADPCMSTEREOPACKET*	sterodata;
	}AdpcmPackets;	// If SoundType = mono, ADPCMMONOPACKET[one or more]
	//If SoundType = stereo,ADPCMSTEREOPACKET[one or more]
swf_base_end();
//}} sound;



//{{ button;
enum button_state{
	//Roll Over  Mouse enters the hit area while the mouse button is up.  Button changes from up to over state.  
	IdleToOverUp,  
	//Roll Out  Mouse leaves the hit area while the mouse button is up.  Button changes from over to up state.  
	OverUpToIdle,  
	//Press Mouse button is pressed Button changes from while the mouse is inside over to down state. the hit area. 
	OverUpToOverDown, 
	//Release Mouse button is Button changes from released while the down to over state. mouse is inside the hit area. 
	OverDownToOverUp, 
	// Drag Over Mouse is dragged inside Button changes from the hit area while the over to down state. mouse button is down. 
	OutDownToOverDown, 
	// Drag Out Mouse is dragged Button changes from outside the hit area while down to over state. the mouse button is down. 
	OverDownToOutDown, 
	// Release Mouse button is Button changes from Outside released outside the hit over to up state. 
	//area while the mouse is captured. 
	OutDownToIdle, 
	// Drag Over Mouse is dragged inside Button changes from up the hit area while the to down state. mouse button is down. 
	IdleToOverDown, 
	// Drag Out Mouse is dragged Button changes from outside the hit area while down to up state. the mouse button is down
	OverDownToIdle, 
};
typedef enum button_state button_state;



swf_base_begin(BUTTONRECORD,s32 ibtn)
	s32 ibtn;
	u8	ButtonReserved;	//  UB[2]  Reserved bits; always 0  
	b32 ButtonHasBlendMode;	//  UB[1]  0 = No blend mode  1 = Has blend mode (SWF 8  and later only)  
	b32 ButtonHasFilterList;	//  UB[1]  0 = No filter list  1 = Has filter list (SWF 8 and   later only)  
	b32 ButtonStateHitTest;	//  UB[1]  Present in hit test state  
	b32 ButtonStateDown;	//  UB[1]  Present in down state  
	b32 ButtonStateOver;	//  UB[1]  Present in over state  
	b32 ButtonStateUp;	//  UB[1]  Present in up state  
	u16 CharacterID;	//  UI16  ID of character to place  
	u16 PlaceDepth;	//  UI16  Depth at which to place  	character  
	MATRIX  PlaceMatrix;	//  Transformation matrix for 	character placement  
	CXFORMWITHALPHA   ColorTransform;	//  If within DefineButton2,  Character color transform  

	FILTERLIST	filterlist; //  If within DefineButton2 and  List of filters on this button  ButtonHasFilterList = 1, FILTERLIST   
	u8			BlendMode;	//  If within DefineButton2 and  ButtonHasBlendMode = 1, UI8  
	// 0 or 1 = normal  
	//2 = layer 3 = multiply 4 = screen  
	//5 = lighten 6 = darken  
	//7 = difference  
	//8 = add  
	//9 = subtract  
	//10 = invert  
	//11 = alpha 12 = erase  
	//13 = overlay 14 = hardlight Values 
	//15 to 255 are reserved.  
swf_base_end();

swf_tag_begin(DefineButton,u32 tag,u32 len)
	//RECORDHEADER	Header;				//  Tag type = 7  
	//u16				ButtonId;			//  UI16  ID for this character  
	s32				i_max_btn;
	s32				i_btn;
	BUTTONRECORD**	Characters;			//  BUTTONRECORD[one or  Characters that make up the more]  button  
	u8				CharacterEndFlag;	//  UI8  Must be 0  
	s32				i_max_act;
	s32				i_act;
	swf_action**	Actions;			//  ACTIONRECORD[zero or  Actions to perform more]   
	u8				ActionEndFlag;		//  UI8  Must be 0  
swf_tag_end();


swf_tag_begin(DefineButton2,u32 tag,u32 len)
	//RECORDHEADER	Header; //  Tag type = 34  
	//u16					ButtonId; //   UI16  ID for this character  
	//ReservedFlags; //   UB[7]  Always 0  
	b32					TrackAsMenu; //   UB[1]  0 = track as normal button 1 = track as menu button  
	u16					ActionOffset; //   UI16  Offset in bytes from start of this field to the first BUTTONCONDACTION, or 0 if no actions occur  
	s32					i_max_btn;
	s32					i_btn;
	BUTTONRECORD**		Characters; //    [one or more]  Characters that make up the button  
	u8					CharacterEndFlag; // UI8 Must be 0

	s32					i_max_act;
	s32					i_act;
	BUTTONCONDACTION**	Actions; // [zero or more] Actions to execute at particular button events
swf_tag_end();

swf_base_begin(BUTTONCONDACTION,u32 CondSize)
	u16				CondActionSize; // UI16 Offset in bytes from start of this field to next BUTTONCONDACTION, or 0 if last action
	b32				CondIdleToOverDownj;  // UB[1] Idle to OverDown
	b32				CondOutDownToIdle;  // UB[1] OutDown to Idle
	b32				CondOutDownToOverDown;  // UB[1] OutDown to OverDown
	b32				CondOverDownToOutDown;  // UB[1] OverDown to OutDown
	b32				CondOverDownToOverUp;  //  UB[1] OverDown to OverUp
	b32				CondOverUpToOverDown;  //  UB[1] OverUp to OverDown
	b32				CondOverUpToIdle;  //  UB[1] OverUp to Idle
	b32				CondIdleToOverUp;  //  UB[1] Idle to OverUp
	u8				CondKeyPress;		//  UB[7]  SWF 4 or later: key code Otherwise: always 0 Valid key codes: 1 = left arrow 2 = right arrow 3 = home 4 = end 5 = insert 6 = delete 8 = backspace 13 = enter 14 = up arrow 15 = down arrow 16 = page up 17 = page down 18 = tab 19 = escape 32 to 126: follows ASCII  
	b32				CondOverDownToIdle; //  UB[1]  OverDown to Idle  
	s32				i_max;
	s32				i_act;
	swf_action**	Actions; //   [zero or more]  Actions to perform. See DoAction.  
	u8				ActionEndFlag; //  UI8  Must be 0  
swf_base_end();

swf_tag_begin(DefineButtonCxform,u32 tag,u32 len)
	//RECORDHEADER	Header; //  Tag type = 23  
	u16				ButtonId; //  UI16  Button ID for this information  
	CXFORM			ButtonColorTransform; //  Character color transform  
swf_tag_end();

swf_tag_begin(DefineButtonSound,u32 tag,u32 len)
	//RECORDHEADER	Header;	//  Tag type = 17  
	u16				ButtonId;	//  UI16  The ID of the button these  	sounds apply to.  
	u16				ButtonSoundChar0;	//  UI16  Sound ID for OverUpToIdle  
	SOUNDINFO		ButtonSoundInfo0;	//  SOUNDINFO (if  Sound style for OverUpToIdle 	ButtonSoundChar0 is nonzero)   
	u16				ButtonSoundChar1;	//  UI16  Sound ID for IdleToOverUp  
	SOUNDINFO		ButtonSoundInfo1;	//  SOUNDINFO (if  Sound style for IdleToOverUp ButtonSoundChar1 is nonzero)   
	u16				ButtonSoundChar2;	//  UI16  Sound ID for  OverUpToOverDown  
	SOUNDINFO		ButtonSoundInfo2;	//  SOUNDINFO (if  Sound style for ButtonSoundChar2 is  OverUpToOverDown 	nonzero)   
	u16				ButtonSoundChar3;	//  UI16  Sound ID for OverDownToOverUp  
	SOUNDINFO		ButtonSoundInfo3;	//  SOUNDINFO (if  Sound style for ButtonSoundChar3 is  OverDownToOverUp 	nonzero)   
swf_tag_end();
//}} button;



//{{ video
swf_base_begin(IMAGEBLOCK)
	u16 DataSize;	//  UB[16] Note: UB[16] is not the same as UI16; 
	//no byte swapping occurs.  Size of the compressed block data that follows. If this is an interframe, and this block is not changed since the last keyframe, DataSize is 0 and the Data field is absent.  
	u8* Data;	//  If DataSize > 0, UI8[DataSize]  Pixel data compressed using ZLIB. 
	//Pixels are ordered from bottom left to top right in rows. Each pixel is three bytes: B, G, R.  
swf_base_end();

swf_base_begin(SCREENVIDEOPACKET)
	u8	BlockWidth;	//  UB[4]  Pixel width of each block in the grid. 
	//This value is stored as (actualWidth / 16) - 1, so possible block sizes are a multiple of 16 and not more than 256.  
	u16 ImageWidth;	//  UB[12]  Pixel width of the full image.  
	u8	BlockHeight;	//  UB[4]  Pixel height of each block in the grid. 
	//This value is stored as (actualHeight / 16) - 1, so possible block sizes are a multiple of 16 and not more than 256.  
	u16 ImageHeight;	//  UB[12]  Pixel height of the full image.  
	IMAGEBLOCK* ImageBlocks;	//  [n]  Blocks of image data. 
	//See preceding for details of how to calculate n. Blocks are ordered from bottom left to top right, in rows.  
swf_base_end();


swf_tag_begin(DefineVideoStream,u32 tag,u32 len)
	//RECORDHEADER  Header;  // Tag type = 60  
	//u16 CharacterID; //  UI16  ID for this video character  
	u16 NumFrames; //  UI16  Number of VideoFrame tags that makes up this stream  
	u16 Width; //  UI16  Width in pixels  
	u16 Height;  // UI16  Height in pixels  
	u8 VideoFlagsReserved; //  UB[4]  Must be 0  
	u8 VideoFlagsDeblocking; //  UB[3]  000 = use VIDEOPACKET value 001 = off 
	//010 = Level 1 (Fast deblocking filter) 011 = Level 2 (VP6 only, better deblocking filter) 
	//100 = Level 3 (VP6 only, better deblocking plus fast deringing filter) 
	//101 = Level 4 (VP6 only, better deblocking plus better deringing filter) 110 = Reserved 111 = Reserved  
	b32 VideoFlagsSmoothing; //  UB[1]  0 = smoothing off (faster) 1 = smoothing on (higher quality)  
	u8 CodecID; //  UI8  2 = Sorenson H.263 3 = Screen video (SWF 7 and later only) 
	//4 = VP6 (SWF 8 and later only) 5 = VP6 video with alpha channel (SWF 8 and later only)  
swf_tag_end();

swf_tag_begin(DefineBinaryData,u32 tag,u32 len)
	//RECORDHEADER  Header; //  Tag type = 87  
	//u16 Tag; //  UI16  16-bit character ID  
	//Reserved  U32  Reserved space; must be 0  Data  BINARY  A blob of binary data, up to the end of the tag  
swf_tag_end();
//}} video


#include "stx_swf.h"

#define __M4V_GET_BITS_INC__
#include "get_bits.h"



STX_COM_BEGIN(stx_swf);
/**/
/**/STX_PUBLIC( stx_swf_canvas )
/**/STX_COM_DATA_DEFAULT(stx_swf_canvas)
/**/
/* other members; */
/**/stx_xio*					h_file;
/**/u8*							buffer;
/**/stx_bits_window				gb;
/**/swf_header					swfhdr;
/**/u8*							p_stream;
/**/swf_file_attributes			attr;
/**/THEE						h_dict; // use character id as key;
/**/
/**/THEE						h_run;
/**/THEE						h_lock;
/**/THEE						h_task;
/**/s64							i_file_time;
/**/s64							i_start_time;
/**/s64							i_start_sample_time;
/**/
/**/THEE						h_stack;
/**/THEE						h_act_stack;
/**/THEE						h_dec_stack;
/**/
/**/
/**/
STX_COM_END();





stx_inline f32 fixed_to_f32(swf_fixed fix){
	return (f32)fix.num + (f32)fix.dec / 65536.f;
}

stx_inline f32 fixed8_to_f32(swf_fixed8 fix){
	return (f32)fix.num + (f32)fix.dec / 256.f;
}


#if defined( __cplusplus )
extern "C" {
#endif

	void swf_initialize();

	f32 f16_to_f32(f16 y);
	f64 f16_to_f64(f16 val);
	f16 f32_to_f16(f32 i);
	f16 f64_to_f16(f64 y);

#if defined( __cplusplus )
}
#endif



#endif // __SWF_DEF_H__