/********************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2010-08
*********************************************************************/

#ifndef __SWF_CLIPBOARDFORMATS_H__
#define __SWF_CLIPBOARDFORMATS_H__

#include "swf_def.h" 

#if defined( __cplusplus )
	extern "C" {
#endif


#if defined( __cplusplus )
}
#endif

#endif // __SWF_CLIPBOARDFORMATS_H__
