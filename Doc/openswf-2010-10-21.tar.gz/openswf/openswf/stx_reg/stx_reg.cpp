/***********************************************************************************
STREAMX FRAMEWORK SOURCE;
AUTHOR: JIN LONG BAO
CREATE TIME:2008-06
***********************************************************************************/
// stx_reg.cpp : Defines the entry point for the console application.
//

#include "stx_all.h"



#define __STX_SERVICE_API_C__
#include "stx_service_api.c"

#ifdef __USE_STX_DEBUG__
static const char __THIS_FILE__[] = __FILE__;
#endif




#ifdef __USE_STX_DEBUG__
#	define test_trace dbg_output
#else
#	define test_trace NULL
#endif


#define  REGOPTSTR "vrup:s:d:VRUP:S:D:"


#ifdef __WIN32_LIB

void usage()
{
	stx_printf(
		"usage:\n"
		"\t regsvr -r -p C:\\plug\\myplugin.dll //register plugin\n"
		"\t regsvr -u -p C:\\plug\\myplugin.dll //unregister plugin\n"
		"\t regsvr -r -s C:\\plug\\myplugin.dll //register service\n"
		"\t regsvr -u -s C:\\plug\\myplugin.dll //unregister service\n"
		"\t regsvr -r -d C:\\plug\\myplugin.dll //register cached dll\n"
		"\t regsvr -u -d C:\\plug\\myplugin.dll //unregister cached dll\n");

}



int main(int argc, char* argv[])
{

	//First thing to do is to read command-line arguments.
	s32						ch;
	char*					optarg;

	stx_base_graph_builder* h_gbd = NULL;
	THEE					hopt = NULL;
	u32						i_flag = 0;
	b32						b_reg = TRUE;
	STX_RESULT				i_err = STX_FAIL;


	i_flag |= STX_INIT_NETWORK;
	//i_flag |= STX_TRACE_CONSOLE;
	i_flag |= STX_TRACE_WINDOW;

	// create graph builder;
	h_gbd = i_service_api_init(test_trace,i_flag);
	if( ! h_gbd ) {
		// fatal, need not restart;
		goto fail;
	}

	hopt = create_opt(argc,argv,REGOPTSTR);
	if( !hopt ) {
		goto fail;
	}

	while ((ch = get_opt(hopt)) != EOF){
		// opt: means requires option
		switch(ch){

			case 'v': 
			case 'V':
				usage();
				goto fail;

			case 'r': 
			case 'R':
				continue;

			case 'u': 
			case 'U':
				b_reg = FALSE;
				continue;

			case 'p': 
			case 'P':
				optarg = get_optarg(hopt);
				if( b_reg ){
					i_err = h_gbd->reg_svr(h_gbd,optarg);
					if( STX_OK != i_err ) {
						stx_printf("register plugin <%s> failed\n",optarg);
					}
					else {
						stx_printf("register plugin <%s> success\n",optarg);
					}
				}
				else{
					i_err = h_gbd->unreg_svr(h_gbd,optarg);
					if( STX_OK != i_err ) {
						stx_printf("unregister plugin <%s> failed\n",optarg);
					}
					else {
						stx_printf("unregister plugin <%s> success\n",optarg);
					}
				}
				goto fail;

			case 's': 
			case 'S':
				optarg = get_optarg(hopt);
				if( b_reg ) {
					i_err = h_gbd->reg_protocol(h_gbd,optarg);
					if( STX_OK != i_err ) {
						stx_printf("register service <%s> failed\n",optarg);
					}
					else {
						stx_printf("register service <%s> success\n",optarg);
					}
				}
				else {
					i_err = h_gbd->unreg_protocol(h_gbd,optarg);
					if( STX_OK != i_err ) {
						stx_printf("unregister service <%s> failed\n",optarg);
					}
					else {
						stx_printf("unregister service <%s> success\n",optarg);
					}
				}
				goto fail;

			case 'd': 
			case 'D':
				optarg = get_optarg(hopt);
				if( b_reg ) {
					i_err = h_gbd->reg_dlib(h_gbd,optarg);
					if( STX_OK != i_err ) {
						stx_printf("register cached dll <%s> failed\n",optarg);
					}
					else {
						stx_printf("register cached dll <%s> success\n",optarg);
					}
				}
				else {
					i_err = h_gbd->unreg_dlib(h_gbd,optarg);
					if( STX_OK != i_err ) {
						stx_printf("unregister cached dll <%s> failed\n",optarg);
					}
					else {
						stx_printf("unregister cached dll <%s> success\n",optarg);
					}
				}
				goto fail;

			case '?':
				stx_printf("command error <%s>\n", get_opterr(hopt) );
				goto fail;


			default:
				stx_printf("unknown command <%s>\n", (char*)&ch );
				break;
		}
	}


fail:

	if( hopt ) {
		close_opt(hopt);
	}

	i_service_api_close(h_gbd);

	stx_printf("\npress any key to continue\n");

	getchar();

	return (int)i_err;

}


#endif // __WIN32_LIB