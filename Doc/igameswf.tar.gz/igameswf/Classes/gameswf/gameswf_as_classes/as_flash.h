// as_flash.h	-- Julien Hamaide <julien.hamaide@gmail.com>	2008

// This source code has been donated to the Public Domain.  Do
// whatever you want with it.


#ifndef GAMESWF_AS_FLASH_H
#define GAMESWF_AS_FLASH_H

#include "gameswf/gameswf_action.h"	// for as_object

namespace gameswf
{
	as_object* flash_init(player* player);
}

#endif
